package com.tools.migrator;

public class AVSJVSReplacerFour {

	public static String replacecoreFunctionCall3(String newString) {

		String returnString = null;
		String tableObjectName = null;
		returnString = newString;

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_MDY_SLASH", "DATE_FORMAT.DATE_FORMAT_MDY_SLASH");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_DIFF", "DATE_FORMAT.DATE_FORMAT_DIFF");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_DMLY_NOSLASH",
				"DATE_FORMAT.DATE_FORMAT_DMLY_NOSLASH");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_MDSY_SLASH", "DATE_FORMAT.DATE_FORMAT_MDSY_SLASH");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_ISO8601", "DATE_FORMAT.DATE_FORMAT_ISO8601");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_ISO8601_EXTENDED",
				"DATE_FORMAT.DATE_FORMAT_ISO8601_EXTENDED");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_DAY_OF_MONTH",
				"DATE_FORMAT.DATE_FORMAT_DAY_OF_MONTH");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_MDY_PERIOD", "DATE_FORMAT.DATE_FORMAT_MDY_PERIOD");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_QUARTER_YEAR",
				"DATE_FORMAT.DATE_FORMAT_QUARTER_YEAR");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_MD_SLASH_IGNORE_YEAR",
				"DATE_FORMAT.DATE_FORMAT_MD_SLASH_IGNORE_YEAR");

		newString = Replacer.simpleReplace(newString, "NUM_DATE_FORMAT_TYPES", "DATE_FORMAT.NUM_DATE_FORMAT_TYPES");

		newString = Replacer.simpleReplace(newString, "DATE_LOCALE", "");

		newString = Replacer.simpleReplace(newString, "DATE_LOCALE_DEFAULT", "DATE_LOCALE.DATE_LOCALE_DEFAULT");

		newString = Replacer.simpleReplace(newString, "DATE_LOCALE_EUROPE", "DATE_LOCALE.DATE_LOCALE_EUROPE");

		newString = Replacer.simpleReplace(newString, "DATE_LOCALE_ASIA", "DATE_LOCALE.DATE_LOCALE_ASIA");

		newString = Replacer.simpleReplace(newString, "ASK_TEXT_DATA_TYPES", "");

		newString = Replacer.simpleReplace(newString, "ASK_DOUBLE", "ASK_TEXT_DATA_TYPES.ASK_DOUBLE");

		newString = Replacer.simpleReplace(newString, "ASK_FILENAME", "ASK_TEXT_DATA_TYPES.ASK_FILENAME");

		newString = Replacer.simpleReplace(newString, "ASK_NUM_TEXT_DATA_TYPES",
				"ASK_TEXT_DATA_TYPES.ASK_NUM_TEXT_DATA_TYPES");

		newString = Replacer.simpleReplace(newString, "PFOLIO_RESULT_TYPE", "");

		newString = Replacer.simpleReplace(newString, "PV_RESULT", "PFOLIO_RESULT_TYPE.PV_RESULT");

		newString = Replacer.simpleReplace(newString, "DELTA_RESULT", "PFOLIO_RESULT_TYPE.DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "GAMMA_RESULT", "PFOLIO_RESULT_TYPE.GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_DELTA_RESULT", "PFOLIO_RESULT_TYPE.TRAN_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GAMMA_RESULT", "PFOLIO_RESULT_TYPE.TRAN_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "VEGA_RESULT", "PFOLIO_RESULT_TYPE.VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_VEGA_RESULT", "PFOLIO_RESULT_TYPE.TRAN_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "THETA_RESULT", "PFOLIO_RESULT_TYPE.THETA_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_RESULT", "PFOLIO_RESULT_TYPE.FX_RESULT");

		newString = Replacer.simpleReplace(newString, "HMAP_RESULT", "PFOLIO_RESULT_TYPE.HMAP_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_PRIOR_RESULT", "PFOLIO_RESULT_TYPE.CFLOW_PRIOR_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_CURRENT_RESULT",
				"PFOLIO_RESULT_TYPE.CFLOW_CURRENT_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_FUTURE_RESULT", "PFOLIO_RESULT_TYPE.CFLOW_FUTURE_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_PROJECTED_RESULT",
				"PFOLIO_RESULT_TYPE.CFLOW_PROJECTED_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_BY_TYPE_RESULT",
				"PFOLIO_RESULT_TYPE.CFLOW_BY_TYPE_RESULT");

		newString = Replacer.simpleReplace(newString, "BROKERS_FEE_RESULT", "PFOLIO_RESULT_TYPE.BROKERS_FEE_RESULT");

		newString = Replacer.simpleReplace(newString, "PAYMENT_DATE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PAYMENT_DATE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_CLOSEOUT_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_CLOSEOUT_RESULT");

		newString = Replacer.simpleReplace(newString, "COST_OF_CARRY_RESULT",
				"PFOLIO_RESULT_TYPE.COST_OF_CARRY_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_ACCRUED_INTEREST_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_ACCRUED_INTEREST_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_DAILY_ACCRUED_INTEREST_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_DAILY_ACCRUED_INTEREST_RESULT");

		newString = Replacer.simpleReplace(newString, "MARKET_PRICE_RESULT", "PFOLIO_RESULT_TYPE.MARKET_PRICE_RESULT");

		newString = Replacer.simpleReplace(newString, "INDEX_RATE_RESULT", "PFOLIO_RESULT_TYPE.INDEX_RATE_RESULT");

		newString = Replacer.simpleReplace(newString, "POSITIVE_PV_RESULT", "PFOLIO_RESULT_TYPE.POSITIVE_PV_RESULT");

		newString = Replacer.simpleReplace(newString, "NEGATIVE_PV_RESULT", "PFOLIO_RESULT_TYPE.NEGATIVE_PV_RESULT");

		newString = Replacer.simpleReplace(newString, "INCOME_EXPENSE_CFLOW_RESULT",
				"PFOLIO_RESULT_TYPE.INCOME_EXPENSE_CFLOW_RESULT");

		newString = Replacer.simpleReplace(newString, "PRINCIPAL_NOTNL_CFLOW_RESULT",
				"PFOLIO_RESULT_TYPE.PRINCIPAL_NOTNL_CFLOW_RESULT");

		newString = Replacer.simpleReplace(newString, "CALC_PRICE_RESULT", "PFOLIO_RESULT_TYPE.CALC_PRICE_RESULT");

		newString = Replacer.simpleReplace(newString, "FUTURE_PHYSICALS_RESULT",
				"PFOLIO_RESULT_TYPE.FUTURE_PHYSICALS_RESULT");

		newString = Replacer.simpleReplace(newString, "POSITIVE_CFLOW_FUTURE_RESULT",
				"PFOLIO_RESULT_TYPE.POSITIVE_CFLOW_FUTURE_RESULT");

		newString = Replacer.simpleReplace(newString, "NEGATIVE_CFLOW_FUTURE_RESULT",
				"PFOLIO_RESULT_TYPE.NEGATIVE_CFLOW_FUTURE_RESULT");

		newString = Replacer.simpleReplace(newString, "POSITIVE_CFLOW_PROJECTED_RESULT",
				"PFOLIO_RESULT_TYPE.POSITIVE_CFLOW_PROJECTED_RESULT");

		newString = Replacer.simpleReplace(newString, "NEGATIVE_CFLOW_PROJECTED_RESULT",
				"PFOLIO_RESULT_TYPE.NEGATIVE_CFLOW_PROJECTED_RESULT");

		newString = Replacer.simpleReplace(newString, "ACCRUED_FWD_PREMIUM_RESULT",
				"PFOLIO_RESULT_TYPE.ACCRUED_FWD_PREMIUM_RESULT");

		newString = Replacer.simpleReplace(newString, "FWD_PREMIUM_RESULT", "PFOLIO_RESULT_TYPE.FWD_PREMIUM_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_ACCRUED_FWD_PREMIUM_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_ACCRUED_FWD_PREMIUM_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_FWD_PREMIUM_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_FWD_PREMIUM_RESULT");

		newString = Replacer.simpleReplace(newString, "CURRENT_POSITION_RESULT",
				"PFOLIO_RESULT_TYPE.CURRENT_POSITION_RESULT");

		newString = Replacer.simpleReplace(newString, "INDEX_BETA_RESULT", "PFOLIO_RESULT_TYPE.INDEX_BETA_RESULT");

		newString = Replacer.simpleReplace(newString, "DELTA_EQUIVALENT_RESULT",
				"PFOLIO_RESULT_TYPE.DELTA_EQUIVALENT_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_LISTING_RESULT", "PFOLIO_RESULT_TYPE.TRAN_LISTING_RESULT");

		newString = Replacer.simpleReplace(newString, "PV_BY_PROJ_IDX_RESULT",
				"PFOLIO_RESULT_TYPE.PV_BY_PROJ_IDX_RESULT");

		newString = Replacer.simpleReplace(newString, "PHYSICAL_CURRENT_RESULT",
				"PFOLIO_RESULT_TYPE.PHYSICAL_CURRENT_RESULT");

		newString = Replacer.simpleReplace(newString, "PHYSICAL_EQUIV_CURRENT_RESULT",
				"PFOLIO_RESULT_TYPE.PHYSICAL_EQUIV_CURRENT_RESULT");

		newString = Replacer.simpleReplace(newString, "UNREALIZED_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.UNREALIZED_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "UNREALIZED_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.UNREALIZED_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "UNREALIZED_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.UNREALIZED_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_MTD_RESULT", "PFOLIO_RESULT_TYPE.CFLOW_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_YTD_RESULT", "PFOLIO_RESULT_TYPE.CFLOW_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BROKERS_FEE_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BROKERS_FEE_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BROKERS_FEE_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BROKERS_FEE_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "ACCRUED_INTEREST_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.ACCRUED_INTEREST_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "ACCRUED_INTEREST_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.ACCRUED_INTEREST_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_BY_TYPE_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.CFLOW_BY_TYPE_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_BY_TYPE_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.CFLOW_BY_TYPE_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_AMENDMENTS_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_AMENDMENTS_RESULT");

		newString = Replacer.simpleReplace(newString, "BUYOUT_CFLOW_RESULT", "PFOLIO_RESULT_TYPE.BUYOUT_CFLOW_RESULT");

		newString = Replacer.simpleReplace(newString, "FUTURE_PHYSICALS_CONTRACTS_RESULT",
				"PFOLIO_RESULT_TYPE.FUTURE_PHYSICALS_CONTRACTS_RESULT");

		newString = Replacer.simpleReplace(newString, "TRADE_PX_RESULT", "PFOLIO_RESULT_TYPE.TRADE_PX_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_PNL_RESULT", "PFOLIO_RESULT_TYPE.REALIZED_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "UNREALIZED_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.UNREALIZED_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "PV_WITHOUT_RESETS_RESULT",
				"PFOLIO_RESULT_TYPE.PV_WITHOUT_RESETS_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_RESETS_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_RESETS_RESULT");

		newString = Replacer.simpleReplace(newString, "NOSTRO_POSITION_RESULT",
				"PFOLIO_RESULT_TYPE.NOSTRO_POSITION_RESULT");

		newString = Replacer.simpleReplace(newString, "PHYSICAL_CONTRACT_CURRENT_RESULT",
				"PFOLIO_RESULT_TYPE.PHYSICAL_CONTRACT_CURRENT_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_CANCELLATION_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_CANCELLATION_RESULT");

		newString = Replacer.simpleReplace(newString, "SETTLE_ACCRUED_INTEREST_RESULT",
				"PFOLIO_RESULT_TYPE.SETTLE_ACCRUED_INTEREST_RESULT");

		newString = Replacer.simpleReplace(newString, "ACCRUED_INTEREST_RESULT",
				"PFOLIO_RESULT_TYPE.ACCRUED_INTEREST_RESULT");

		newString = Replacer.simpleReplace(newString, "DAILY_ACCRUED_INTEREST_RESULT",
				"PFOLIO_RESULT_TYPE.DAILY_ACCRUED_INTEREST_RESULT");

		newString = Replacer.simpleReplace(newString, "OUTSTANDING_DEBT_FIXED_RESULT",
				"PFOLIO_RESULT_TYPE.OUTSTANDING_DEBT_FIXED_RESULT");

		newString = Replacer.simpleReplace(newString, "EOY_OUTSTANDING_DEBT_FIXED_RESULT",
				"PFOLIO_RESULT_TYPE.EOY_OUTSTANDING_DEBT_FIXED_RESULT");

		newString = Replacer.simpleReplace(newString, "BREAK_EVEN_RATE_RESULT",
				"PFOLIO_RESULT_TYPE.BREAK_EVEN_RATE_RESULT");

		newString = Replacer.simpleReplace(newString, "CURRENT_FIXED_RATE_RESULT",
				"PFOLIO_RESULT_TYPE.CURRENT_FIXED_RATE_RESULT");

		newString = Replacer.simpleReplace(newString, "CURRENT_FLOAT_RATE_RESULT",
				"PFOLIO_RESULT_TYPE.CURRENT_FLOAT_RATE_RESULT");

		newString = Replacer.simpleReplace(newString, "CURRENT_STRIKE_RATE_RESULT",
				"PFOLIO_RESULT_TYPE.CURRENT_STRIKE_RATE_RESULT");

		newString = Replacer.simpleReplace(newString, "BOOK_VALUE_RESULT", "PFOLIO_RESULT_TYPE.BOOK_VALUE_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_UNREALIZED_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_UNREALIZED_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_REALIZED_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_REALIZED_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_REALIZED_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_REALIZED_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_UNREALIZED_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_UNREALIZED_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_UNREALIZED_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_UNREALIZED_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_UNREALIZED_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_UNREALIZED_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_ACCRUED_INTEREST_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_ACCRUED_INTEREST_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_ACCRUED_INTEREST_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_ACCRUED_INTEREST_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_ACCRUED_INTEREST_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_ACCRUED_INTEREST_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CFLOW_BY_TYPE_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CFLOW_BY_TYPE_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_CFLOW_BY_TYPE_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_CFLOW_BY_TYPE_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_CFLOW_BY_TYPE_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_CFLOW_BY_TYPE_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "DURATION_RESULT", "PFOLIO_RESULT_TYPE.DURATION_RESULT");

		newString = Replacer.simpleReplace(newString, "MOD_DURATION_RESULT", "PFOLIO_RESULT_TYPE.MOD_DURATION_RESULT");

		newString = Replacer.simpleReplace(newString, "CONVEXITY_RESULT", "PFOLIO_RESULT_TYPE.CONVEXITY_RESULT");

		newString = Replacer.simpleReplace(newString, "MARKET_YIELD_RESULT", "PFOLIO_RESULT_TYPE.MARKET_YIELD_RESULT");

		newString = Replacer.simpleReplace(newString, "OUTSTANDING_DEBT_FLOAT_RESULT",
				"PFOLIO_RESULT_TYPE.OUTSTANDING_DEBT_FLOAT_RESULT");

		newString = Replacer.simpleReplace(newString, "EOY_OUTSTANDING_DEBT_FLOAT_RESULT",
				"PFOLIO_RESULT_TYPE.EOY_OUTSTANDING_DEBT_FLOAT_RESULT");

		newString = Replacer.simpleReplace(newString, "CF_ACCRUED_INTEREST_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.CF_ACCRUED_INTEREST_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "CF_ACCRUED_INTEREST_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.CF_ACCRUED_INTEREST_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "VALUE_AT_RISK_RESULT",
				"PFOLIO_RESULT_TYPE.VALUE_AT_RISK_RESULT");

		newString = Replacer.simpleReplace(newString, "MCARLO_CONFIG_PARAMS_RESULT",
				"PFOLIO_RESULT_TYPE.MCARLO_CONFIG_PARAMS_RESULT");

		newString = Replacer.simpleReplace(newString, "MCARLO_TRIAL_MTMS_RESULT",
				"PFOLIO_RESULT_TYPE.MCARLO_TRIAL_MTMS_RESULT");

		newString = Replacer.simpleReplace(newString, "MCARLO_VALUE_AT_RISK_RESULT",
				"PFOLIO_RESULT_TYPE.MCARLO_VALUE_AT_RISK_RESULT");

		newString = Replacer.simpleReplace(newString, "VEGA_GAMMA_RESULT", "PFOLIO_RESULT_TYPE.VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "VAR_BY_TRAN_RESULT", "PFOLIO_RESULT_TYPE.VAR_BY_TRAN_RESULT");

		newString = Replacer.simpleReplace(newString, "PV_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.PV_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "NV_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.NV_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "DELTA_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.DELTA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "GAMMA_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.GAMMA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "RHO_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.RHO_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "RHORHO_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.RHORHO_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "VEGA_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "THETA_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.THETA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "VOL_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.VOL_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PRICE_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.PRICE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "STRIKE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.STRIKE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "SIZE_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.SIZE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "AVG_HIST_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.AVG_HIST_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "AVG_PROJ_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.AVG_PROJ_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "DAYS_FROM_START_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.DAYS_FROM_START_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "DAYS_TO_END_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.DAYS_TO_END_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "DELTA_EQUIVALENT_FV_RESULT",
				"PFOLIO_RESULT_TYPE.DELTA_EQUIVALENT_FV_RESULT");

		newString = Replacer.simpleReplace(newString, "GAMMA_EQUIVALENT_FV_RESULT",
				"PFOLIO_RESULT_TYPE.GAMMA_EQUIVALENT_FV_RESULT");

		newString = Replacer.simpleReplace(newString, "VEGA_FV_RESULT", "PFOLIO_RESULT_TYPE.VEGA_FV_RESULT");

		newString = Replacer.simpleReplace(newString, "GAMMA_EQUIVALENT_RESULT",
				"PFOLIO_RESULT_TYPE.GAMMA_EQUIVALENT_RESULT");

		newString = Replacer.simpleReplace(newString, "QUICK_UNREALIZED_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.QUICK_UNREALIZED_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "PV_TOTAL_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PV_TOTAL_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "NV_TOTAL_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.NV_TOTAL_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "UNDERLYING_RESULT", "PFOLIO_RESULT_TYPE.UNDERLYING_RESULT");

		newString = Replacer.simpleReplace(newString, "AVG_START_DATE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.AVG_START_DATE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "AVG_END_DATE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.AVG_END_DATE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "VAR_BY_INDEX_GRIDPOINT_RESULT",
				"PFOLIO_RESULT_TYPE.VAR_BY_INDEX_GRIDPOINT_RESULT");

		newString = Replacer.simpleReplace(newString, "VAR_BY_VOL_GRIDPOINT_RESULT",
				"PFOLIO_RESULT_TYPE.VAR_BY_VOL_GRIDPOINT_RESULT");

		newString = Replacer.simpleReplace(newString, "VAR_RAW_GPT_INFO_RESULT",
				"PFOLIO_RESULT_TYPE.VAR_RAW_GPT_INFO_RESULT");

		newString = Replacer.simpleReplace(newString, "VAR_BY_INDEX_RESULT", "PFOLIO_RESULT_TYPE.VAR_BY_INDEX_RESULT");

		newString = Replacer.simpleReplace(newString, "VAR_BY_VOL_RESULT", "PFOLIO_RESULT_TYPE.VAR_BY_VOL_RESULT");

		newString = Replacer.simpleReplace(newString, "VAR_CORRELATION_MATRIX_RESULT",
				"PFOLIO_RESULT_TYPE.VAR_CORRELATION_MATRIX_RESULT");

		newString = Replacer.simpleReplace(newString, "CF_ACCRUED_INTEREST_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.CF_ACCRUED_INTEREST_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "ACCRUED_INTEREST_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.ACCRUED_INTEREST_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "YIELD_CURVE_RESULT", "PFOLIO_RESULT_TYPE.YIELD_CURVE_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CFLOW_PRIOR_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CFLOW_PRIOR_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CFLOW_CURRENT_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CFLOW_CURRENT_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_PV_RESULT", "PFOLIO_RESULT_TYPE.BASE_PV_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_PHYSICAL_EQUIV_CURRENT_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_PHYSICAL_EQUIV_CURRENT_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_UNREALIZED_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_UNREALIZED_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_UNREALIZED_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_UNREALIZED_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_UNREALIZED_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_UNREALIZED_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CFLOW_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CFLOW_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CFLOW_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CFLOW_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_UNREALIZED_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_UNREALIZED_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CFLOW_BY_TYPE_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CFLOW_BY_TYPE_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_ACCRUED_INTEREST_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_ACCRUED_INTEREST_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_ACCRUED_INTEREST_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_ACCRUED_INTEREST_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_ACCRUED_INTEREST_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_ACCRUED_INTEREST_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FX_PL_REALIZED_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.FX_PL_REALIZED_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CFLOW_BY_TYPE_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CFLOW_BY_TYPE_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_BUYOUT_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_BUYOUT_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_VEGA_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "GAMMA_YIELD_CURVE_RESULT",
				"PFOLIO_RESULT_TYPE.GAMMA_YIELD_CURVE_RESULT");

		newString = Replacer.simpleReplace(newString, "INDEX_EFF_RATE_RESULT",
				"PFOLIO_RESULT_TYPE.INDEX_EFF_RATE_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_VEGA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "MCARLO_VAR_STATISTICS_RESULT",
				"PFOLIO_RESULT_TYPE.MCARLO_VAR_STATISTICS_RESULT");

		newString = Replacer.simpleReplace(newString, "MCARLO_VAR_DECOMP_RESULT",
				"PFOLIO_RESULT_TYPE.MCARLO_VAR_DECOMP_RESULT");

		newString = Replacer.simpleReplace(newString, "DELTA_VAR_RESULT", "PFOLIO_RESULT_TYPE.DELTA_VAR_RESULT");

		newString = Replacer.simpleReplace(newString, "VEGA_VAR_RESULT", "PFOLIO_RESULT_TYPE.VEGA_VAR_RESULT");

		newString = Replacer.simpleReplace(newString, "VOL_EFF_INPUT_RESULT",
				"PFOLIO_RESULT_TYPE.VOL_EFF_INPUT_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_VEGA_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_CORRELATION_VEGA_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_CORRELATION_VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "CORRELATION_VEGA_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.CORRELATION_VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "CORRELATION_VEGA_RESULT",
				"PFOLIO_RESULT_TYPE.CORRELATION_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_CORR_VEGA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_CORR_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_CORRELATION_VEGA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_CORRELATION_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "REMAINING_SIZE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.REMAINING_SIZE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "CURRENT_NOTIONAL_RESULT",
				"PFOLIO_RESULT_TYPE.CURRENT_NOTIONAL_RESULT");

		newString = Replacer.simpleReplace(newString, "IN_THE_MONEY_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.IN_THE_MONEY_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "CONTRACT_ALLOCATION_RESULT",
				"PFOLIO_RESULT_TYPE.CONTRACT_ALLOCATION_RESULT");

		newString = Replacer.simpleReplace(newString, "CAPITALIZATION_GAIN_RESULT",
				"PFOLIO_RESULT_TYPE.CAPITALIZATION_GAIN_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_FUTURE_BY_DEAL_RESULT",
				"PFOLIO_RESULT_TYPE.CFLOW_FUTURE_BY_DEAL_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_PROJECTED_BY_DEAL_RESULT",
				"PFOLIO_RESULT_TYPE.CFLOW_PROJECTED_BY_DEAL_RESULT");

		newString = Replacer.simpleReplace(newString, "OUTPUT_YIELD_CURVE_RESULT",
				"PFOLIO_RESULT_TYPE.OUTPUT_YIELD_CURVE_RESULT");

		newString = Replacer.simpleReplace(newString, "OUTPUT_GAMMA_YIELD_CURVE_RESULT",
				"PFOLIO_RESULT_TYPE.OUTPUT_GAMMA_YIELD_CURVE_RESULT");

		newString = Replacer.simpleReplace(newString, "INDEX_OUTPUT_RESULT", "PFOLIO_RESULT_TYPE.INDEX_OUTPUT_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_DELTA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "CALC_YIELD_RESULT", "PFOLIO_RESULT_TYPE.CALC_YIELD_RESULT");

		newString = Replacer.simpleReplace(newString, "WORST_CASE_PV_RESULT",
				"PFOLIO_RESULT_TYPE.WORST_CASE_PV_RESULT");

		newString = Replacer.simpleReplace(newString, "VOLUME_PRIOR_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.VOLUME_PRIOR_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PRICE_PRIOR_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PRICE_PRIOR_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "VOLUME_CURRENT_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.VOLUME_CURRENT_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PRICE_CURRENT_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PRICE_CURRENT_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "VOLUME_FUTURE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.VOLUME_FUTURE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PRICE_FUTURE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PRICE_FUTURE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PERIOD_START_DATE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PERIOD_START_DATE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PERIOD_END_DATE_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PERIOD_END_DATE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "SETTLEMENT_TYPE_RESULT",
				"PFOLIO_RESULT_TYPE.SETTLEMENT_TYPE_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_VEGA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_VEGA_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_DELTA_SIDE_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_DELTA_SIDE_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_DELTA_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_DELTA_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_PNL_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_PNL_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "FEE_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.FEE_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "FEE_PV_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.FEE_PV_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "ACCRUED_MTM_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.ACCRUED_MTM_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "INVENTORY_EQUIV_RESULT",
				"PFOLIO_RESULT_TYPE.INVENTORY_EQUIV_RESULT");

		newString = Replacer.simpleReplace(newString, "CUM_OVERNIGHT_PHYSICAL_EQUIV_RESULT",
				"PFOLIO_RESULT_TYPE.CUM_OVERNIGHT_PHYSICAL_EQUIV_RESULT");

		newString = Replacer.simpleReplace(newString, "OVERNIGHT_PHYSICAL_EQUIV_RESULT",
				"PFOLIO_RESULT_TYPE.OVERNIGHT_PHYSICAL_EQUIV_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_OVERNIGHT_PHYSICAL_EQUIV_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_OVERNIGHT_PHYSICAL_EQUIV_RESULT");

		newString = Replacer.simpleReplace(newString, "DF_BY_LEG_RESULT", "PFOLIO_RESULT_TYPE.DF_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PAYMENT_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PAYMENT_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "UNREALIZED_PNL_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.UNREALIZED_PNL_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "CASH_MONTH_INFO_RESULT",
				"PFOLIO_RESULT_TYPE.CASH_MONTH_INFO_RESULT");

		newString = Replacer.simpleReplace(newString, "CFLOW_BY_DAY_RESULT", "PFOLIO_RESULT_TYPE.CFLOW_BY_DAY_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_DELTA_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_DELTA_SIDE_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_DELTA_SIDE_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_DELTA_SIDE_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_DELTA_SIDE_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_CROSS_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_CROSS_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "DISCOUNT_MARGIN_RESULT",
				"PFOLIO_RESULT_TYPE.DISCOUNT_MARGIN_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_CUM_OVERNIGHT_PHYSICAL_EQUIV_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_CUM_OVERNIGHT_PHYSICAL_EQUIV_RESULT");

		newString = Replacer.simpleReplace(newString, "BROKERS_FEE_INFO_RESULT",
				"PFOLIO_RESULT_TYPE.BROKERS_FEE_INFO_RESULT");

		newString = Replacer.simpleReplace(newString, "PRC_MODEL_CFG_RESULT",
				"PFOLIO_RESULT_TYPE.PRC_MODEL_CFG_RESULT");

		newString = Replacer.simpleReplace(newString, "AMENDED_MTM_DETAIL_RESULT",
				"PFOLIO_RESULT_TYPE.AMENDED_MTM_DETAIL_RESULT");

		newString = Replacer.simpleReplace(newString, "CANCEL_MTM_DETAIL_RESULT",
				"PFOLIO_RESULT_TYPE.CANCEL_MTM_DETAIL_RESULT");

		newString = Replacer.simpleReplace(newString, "MTM_DETAIL_RESULT", "PFOLIO_RESULT_TYPE.MTM_DETAIL_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_VEGA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_VEGA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_CORR_VEGA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_CORR_VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_CORR_VEGA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_CORR_VEGA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_CORR_VEGA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_CORR_VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "CORR_EFF_INPUT_RESULT",
				"PFOLIO_RESULT_TYPE.CORR_EFF_INPUT_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_CROSS_VEGA_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_CROSS_VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "WEIGHTED_AVG_LIFE_RESULT",
				"PFOLIO_RESULT_TYPE.WEIGHTED_AVG_LIFE_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_OUTPUT_DELTA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_OUTPUT_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_OUTPUT_DELTA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_OUTPUT_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "PERIOD_ACCRUED_INTEREST_TO_RESULT",
				"PFOLIO_RESULT_TYPE.PERIOD_ACCRUED_INTEREST_TO_RESULT");

		newString = Replacer.simpleReplace(newString, "PERIOD_ACCRUED_INTEREST_THRU_RESULT",
				"PFOLIO_RESULT_TYPE.PERIOD_ACCRUED_INTEREST_THRU_RESULT");

		newString = Replacer.simpleReplace(newString, "TRADING_MARGIN_RESULT",
				"PFOLIO_RESULT_TYPE.TRADING_MARGIN_RESULT");

		newString = Replacer.simpleReplace(newString, "CF_PERIOD_ACCRUED_INTEREST_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.CF_PERIOD_ACCRUED_INTEREST_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_CROSS_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_CROSS_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_CROSS_VEGA_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_CROSS_VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_PAR_INDEX_DELTA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_PAR_INDEX_DELTA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_PAR_OUTPUT_DELTA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_PAR_OUTPUT_DELTA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_PAR_VOL_VEGA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_PAR_VOL_VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_PAR_COR_VEGA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_PAR_COR_VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "VOLUME_NEAR_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.VOLUME_NEAR_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PRICE_NEAR_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.PRICE_NEAR_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "COST_OF_CARRY_DETAIL_RESULT",
				"PFOLIO_RESULT_TYPE.COST_OF_CARRY_DETAIL_RESULT");

		newString = Replacer.simpleReplace(newString, "YIELD_TO_NEXT_RESULT",
				"PFOLIO_RESULT_TYPE.YIELD_TO_NEXT_RESULT");

		newString = Replacer.simpleReplace(newString, "PRICE_BY_PRICEBAND_RESULT",
				"PFOLIO_RESULT_TYPE.PRICE_BY_PRICEBAND_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_OUTPUT_CROSS_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_OUTPUT_CROSS_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_IMPACT_OF_OUTPUT_CROSS_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_GPT_IMPACT_OF_OUTPUT_CROSS_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "PNL_DETAIL_RESULT", "PFOLIO_RESULT_TYPE.PNL_DETAIL_RESULT");

		newString = Replacer.simpleReplace(newString, "SIM_RESULT_CFG_RESULT",
				"PFOLIO_RESULT_TYPE.SIM_RESULT_CFG_RESULT");

		newString = Replacer.simpleReplace(newString, "PNL_DETAIL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.PNL_DETAIL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "PNL_DETAIL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.PNL_DETAIL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "STTL_ACCR_INT_STATIC_RESULT",
				"PFOLIO_RESULT_TYPE.STTL_ACCR_INT_STATIC_RESULT");

		newString = Replacer.simpleReplace(newString, "SPOT_SETTLE_ACCRUED_INTEREST_RESULT",
				"PFOLIO_RESULT_TYPE.SPOT_SETTLE_ACCRUED_INTEREST_RESULT");

		newString = Replacer.simpleReplace(newString, "REPLACEMENT_VALUE_RESULT",
				"PFOLIO_RESULT_TYPE.REPLACEMENT_VALUE_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_TRAN_GPT_DELTA_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_TRAN_GPT_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_DELTA_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_TRAN_GPT_DELTA_SIDE_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_TRAN_GPT_DELTA_SIDE_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_TRAN_GPT_DELTA_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_TRAN_GPT_DELTA_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_INDEX_RATES_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_INDEX_RATES_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_TRAN_GPT_OUTPUT_DELTA_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_TRAN_GPT_OUTPUT_DELTA_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_COST_OF_CARRY",
				"PFOLIO_RESULT_TYPE.IMPACT_COST_OF_CARRY");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_VOL_EFF_INPUT_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_VOL_EFF_INPUT_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_TRAN_GPT_VEGA_BY_LEG_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_TRAN_GPT_VEGA_BY_LEG_RESULT");

		newString = Replacer.simpleReplace(newString, "PNL_EXPLAINED_SUMMARY_RESULT",
				"PFOLIO_RESULT_TYPE.PNL_EXPLAINED_SUMMARY_RESULT");

		newString = Replacer.simpleReplace(newString, "PNL_SUMMARY_RESULT", "PFOLIO_RESULT_TYPE.PNL_SUMMARY_RESULT");

		newString = Replacer.simpleReplace(newString, "RESETS_MTM_DETAIL_RESULT",
				"PFOLIO_RESULT_TYPE.RESETS_MTM_DETAIL_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_MARGIN_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_MARGIN_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_CLOSEOUT_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_CLOSEOUT_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_MARGIN_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_MARGIN_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_CLOSEOUT_PNL_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_CLOSEOUT_PNL_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_MARGIN_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_MARGIN_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_CLOSEOUT_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_CLOSEOUT_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_MARGIN_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_MARGIN_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_CLOSEOUT_PNL_MTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_CLOSEOUT_PNL_MTD_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_MARGIN_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_MARGIN_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_CLOSEOUT_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_CLOSEOUT_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_MARGIN_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_MARGIN_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_CLOSEOUT_PNL_YTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_CLOSEOUT_PNL_YTD_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_MARGIN_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_MARGIN_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "REALIZED_CLOSEOUT_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.REALIZED_CLOSEOUT_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_MARGIN_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_MARGIN_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REALIZED_CLOSEOUT_PNL_LTD_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REALIZED_CLOSEOUT_PNL_LTD_RESULT");

		newString = Replacer.simpleReplace(newString, "FUTURES_MARGIN_PRICE_RESULT",
				"PFOLIO_RESULT_TYPE.FUTURES_MARGIN_PRICE_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_SPOT_FX_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_SPOT_FX_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_SPOT_FX_DETAIL_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_SPOT_FX_DETAIL_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_PNL_EXPLAINED_SUMMARY_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_PNL_EXPLAINED_SUMMARY_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_TRAN_GPT_CROSS_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_TRAN_GPT_CROSS_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "NEXT_DAY_TRAN_GPT_CROSS_VEGA_GAMMA_RESULT",
				"PFOLIO_RESULT_TYPE.NEXT_DAY_TRAN_GPT_CROSS_VEGA_GAMMA_RESULT");

		newString = Replacer.simpleReplace(newString, "TRANSACTION_STATUS_RESULT",
				"PFOLIO_RESULT_TYPE.TRANSACTION_STATUS_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_VOLUME_CHANGE_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_VOLUME_CHANGE_RESULT");

		newString = Replacer.simpleReplace(newString, "IMPACT_OF_OPTION_EXERCISE_RESULT",
				"PFOLIO_RESULT_TYPE.IMPACT_OF_OPTION_EXERCISE_RESULT");

		newString = Replacer.simpleReplace(newString, "HISTORICAL_CASH_CHANGES_RESULT",
				"PFOLIO_RESULT_TYPE.HISTORICAL_CASH_CHANGES_RESULT");

		newString = Replacer.simpleReplace(newString, "BASE_REPLACEMENT_VALUE_RESULT",
				"PFOLIO_RESULT_TYPE.BASE_REPLACEMENT_VALUE_RESULT");

		newString = Replacer.simpleReplace(newString, "SIM_LOG_RESULT", "PFOLIO_RESULT_TYPE.SIM_LOG_RESULT");

		newString = Replacer.simpleReplace(newString, "CALC_PRICE_CLEAN_RESULT",
				"PFOLIO_RESULT_TYPE.CALC_PRICE_CLEAN_RESULT");

		newString = Replacer.simpleReplace(newString, "CALC_PRICE_DIRTY_RESULT",
				"PFOLIO_RESULT_TYPE.CALC_PRICE_DIRTY_RESULT");

		newString = Replacer.simpleReplace(newString, "MARKET_PRICE_CLEAN_RESULT",
				"PFOLIO_RESULT_TYPE.MARKET_PRICE_CLEAN_RESULT");

		newString = Replacer.simpleReplace(newString, "MARKET_PRICE_DIRTY_RESULT",
				"PFOLIO_RESULT_TYPE.MARKET_PRICE_DIRTY_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_CALC_PRICE_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_CALC_PRICE_RESULT");

		newString = Replacer.simpleReplace(newString, "TRAN_MKT_PRICE_RESULT",
				"PFOLIO_RESULT_TYPE.TRAN_MKT_PRICE_RESULT");

		newString = Replacer.simpleReplace(newString, "YIELD_TO_CALL_RESULT",
				"PFOLIO_RESULT_TYPE.YIELD_TO_CALL_RESULT");

		newString = Replacer.simpleReplace(newString, "YIELD_TO_WORST_RESULT",
				"PFOLIO_RESULT_TYPE.YIELD_TO_WORST_RESULT");

		newString = Replacer.simpleReplace(newString, "YIELD_TO_MAT_RESULT", "PFOLIO_RESULT_TYPE.YIELD_TO_MAT_RESULT");

		newString = Replacer.simpleReplace(newString, "NUM_RESULT_TYPES", "PFOLIO_RESULT_TYPE.NUM_RESULT_TYPES");

		newString = Replacer.simpleReplace(newString, "COL_INVALID", "COL_TYPE_ENUM.COL_INVALID");

		newString = Replacer.simpleReplace(newString, "COL_PTR", "COL_TYPE_ENUM.COL_PTR");

		newString = Replacer.simpleReplace(newString, "COL_INT_ARRAY", "COL_TYPE_ENUM.COL_INT_ARRAY");

		newString = Replacer.simpleReplace(newString, "COL_DOUBLE_ARRAY", "COL_TYPE_ENUM.COL_DOUBLE_ARRAY");

		newString = Replacer.simpleReplace(newString, "COL_STRING_ARRAY", "COL_TYPE_ENUM.COL_STRING_ARRAY");

		newString = Replacer.simpleReplace(newString, "ROW_HEADER", "COL_TYPE_ENUM.ROW_HEADER");

		newString = Replacer.simpleReplace(newString, "COL_HEADER", "COL_TYPE_ENUM.COL_HEADER");

		newString = Replacer.simpleReplace(newString, "COL_ERROR", "COL_TYPE_ENUM.COL_ERROR");

		newString = Replacer.simpleReplace(newString, "COL_DATE_TIME", "COL_TYPE_ENUM.COL_DATE_TIME");

		newString = Replacer.simpleReplace(newString, "COL_BYTE_ARRAY", "COL_TYPE_ENUM.COL_BYTE_ARRAY");

		newString = Replacer.simpleReplace(newString, "COL_TRAN", "COL_TYPE_ENUM.COL_TRAN");

		newString = Replacer.simpleReplace(newString, "COL_IVL_LIST", "COL_TYPE_ENUM.COL_IVL_LIST");

		newString = Replacer.simpleReplace(newString, "COL_SSEL_IVL_LIST", "COL_TYPE_ENUM.COL_SSEL_IVL_LIST");

		newString = Replacer.simpleReplace(newString, "COL_MSEL_IVL_LIST", "COL_TYPE_ENUM.COL_MSEL_IVL_LIST");

		newString = Replacer.simpleReplace(newString, "COL_DATE_TIME_ARRAY", "COL_TYPE_ENUM.COL_DATE_TIME_ARRAY");

		newString = Replacer.simpleReplace(newString, "COL_CLOB", "COL_TYPE_ENUM.COL_CLOB");

		newString = Replacer.simpleReplace(newString, "COL_DATE", "COL_TYPE_ENUM.COL_DATE");

		newString = Replacer.simpleReplace(newString, "COL_XML", "COL_TYPE_ENUM.COL_XML");

		newString = Replacer.simpleReplace(newString, "COL_HPA", "COL_TYPE_ENUM.COL_HPA");

		newString = Replacer.simpleReplace(newString, "COL_UINT", "COL_TYPE_ENUM.COL_UINT");

		newString = Replacer.simpleReplace(newString, "COL_CELL", "COL_TYPE_ENUM.COL_CELL");

		newString = Replacer.simpleReplace(newString, "COL_INT64", "COL_TYPE_ENUM.COL_INT64");

		newString = Replacer.simpleReplace(newString, "COL_UINT64", "COL_TYPE_ENUM.COL_UINT64");

		newString = Replacer.simpleReplace(newString, "NUM_COL_TYPE_ENUM", "COL_TYPE_ENUM.NUM_COL_TYPE_ENUM");

		newString = Replacer.simpleReplace(newString, "ROW_DATA", "ROW_TYPE_ENUM.ROW_DATA");

		newString = Replacer.simpleReplace(newString, "ROW_GROUP_SUM", "ROW_TYPE_ENUM.ROW_GROUP_SUM");

		newString = Replacer.simpleReplace(newString, "ROW_TITLE", "ROW_TYPE_ENUM.ROW_TITLE");

		newString = Replacer.simpleReplace(newString, "ROW_HDR", "ROW_TYPE_ENUM.ROW_HDR");

		newString = Replacer.simpleReplace(newString, "ROW_GROUP_HDR", "ROW_TYPE_ENUM.ROW_GROUP_HDR");

		newString = Replacer.simpleReplace(newString, "NUM_ROW_TYPE_ENUM", "ROW_TYPE_ENUM.NUM_ROW_TYPE_ENUM");

		newString = Replacer.simpleReplace(newString, "OPTION_SETTLEMENT_TYPE", "");

		newString = Replacer.simpleReplace(newString, "COL_FORMAT_BASE_ENUM", "");

		newString = Replacer.simpleReplace(newString, "NOTNL_BASE", "COL_FORMAT_BASE_ENUM.NOTNL_BASE");

		newString = Replacer.simpleReplace(newString, "BASE_THOUSAND", "COL_FORMAT_BASE_ENUM.BASE_THOUSAND");

		newString = Replacer.simpleReplace(newString, "BASE_MILLION", "COL_FORMAT_BASE_ENUM.BASE_MILLION");

		newString = Replacer.simpleReplace(newString, "BASE_BILLION", "COL_FORMAT_BASE_ENUM.BASE_BILLION");

		newString = Replacer.simpleReplace(newString, "NUM_COL_FORMAT_BASE",
				"COL_FORMAT_BASE_ENUM.NUM_COL_FORMAT_BASE");

		newString = Replacer.simpleReplace(newString, "DBTYPE_ORACLE", "DBTYPE_ENUM.DBTYPE_ORACLE");

		newString = Replacer.simpleReplace(newString, "DBTYPE_MSSQL", "DBTYPE_ENUM.DBTYPE_MSSQL");

		newString = Replacer.simpleReplace(newString, "DBTYPE_TYPE_NOT_SET", "DBTYPE_ENUM.DBTYPE_TYPE_NOT_SET");

		newString = Replacer.simpleReplace(newString, "DBTYPE_SYBASE", "DBTYPE_ENUM.DBTYPE_SYBASE");

		return returnString;
	}

}
