package com.tools.migrator;

public class AVSJVSReplacerOne {

	public static String replacecoreFunctionCall(String s) {

		String inputString = s.trim();
		String newString = s.trim();
		String returnString = null;
		String tableObjectName = null;
		String temp = null;
		returnString = newString;
		int index = 0, commaIdx = 0;

		if (newString.contains("TABLE_SetTableName")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_SetTableName"));
			temp = newString.substring(newString.indexOf("TABLE_SetTableName"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_AddRowsWithValues")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddRowsWithValues"));
			temp = newString.substring(newString.indexOf("TABLE_AddRowsWithValues"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_CloneTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CloneTable"));
			temp = newString.substring(newString.indexOf("TABLE_CloneTable"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_AddRow") && !newString.contains("TABLE_AddRowsWithValues")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddRow"));
			temp = newString.substring(newString.indexOf("TABLE_AddRow"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_AddNumRows")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddNumRows"));
			temp = newString.substring(newString.indexOf("TABLE_AddNumRows"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_IsTableValid")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_IsTableValid"));
			temp = newString.substring(newString.indexOf("TABLE_IsTableValid") , newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_InsertColN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_InsertColN"));
			temp = newString.substring(newString.indexOf("TABLE_InsertColN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_AddCols")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddCols"));
			temp = newString.substring(newString.indexOf("TABLE_AddCols") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_AddCol")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddCol"));
			temp = newString.substring(newString.indexOf("TABLE_AddCol") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_AddFormulaColumn")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddFormulaColumn"));
			temp = newString.substring(newString.indexOf("TABLE_AddFormulaColumn") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_AddGroupByN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddGroupByN"));
			temp = newString.substring(newString.indexOf("TABLE_AddGroupByN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_AddGroupBy")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddGroupBy"));
			temp = newString.substring(newString.indexOf("TABLE_AddGroupBy") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_AddLockHideTableAllGroupRows")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddLockHideTableAllGroupRows"));
			temp = newString.substring(newString.indexOf("TABLE_AddLockHideTableAllGroupRows") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_AddLockHideTableEntry")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_AddLockHideTableEntry"));
			temp = newString.substring(newString.indexOf("TABLE_AddLockHideTableEntry") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ApplyTableDiffs")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ApplyTableDiffs"));
			temp = newString.substring(newString.indexOf("TABLE_ApplyTableDiffs") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_CalculateFormulaColumn")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CalculateFormulaColumn"));
			temp = newString.substring(newString.indexOf("TABLE_CalculateFormulaColumn") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CalculateFormulaColumnN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CalculateFormulaColumnN"));
			temp = newString.substring(newString.indexOf("TABLE_CalculateFormulaColumnN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ClearRowsByType")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ClearRowsByType"));
			temp = newString.substring(newString.indexOf("TABLE_ClearRowsByType") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ColConvertDateTimeToIntN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColConvertDateTimeToIntN"));
			temp = newString.substring(newString.indexOf("TABLE_ColConvertDateTimeToIntN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ColConvertDateTimeToInt")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColConvertDateTimeToInt"));
			temp = newString.substring(newString.indexOf("TABLE_ColConvertDateTimeToInt") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ColConvertIntToDateTimeN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColConvertIntToDateTimeN"));
			temp = newString.substring(newString.indexOf("TABLE_ColConvertIntToDateTimeN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ColConvertIntToDateTime")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColConvertIntToDateTime"));
			temp = newString.substring(newString.indexOf("TABLE_ColConvertIntToDateTime") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ColHideN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColHideN"));
			temp = newString.substring(newString.indexOf("TABLE_ColHideN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ColShowN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColShowN"));
			temp = newString.substring(newString.indexOf("TABLE_ColShowN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ColShow")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColShow"));
			temp = newString.substring(newString.indexOf("TABLE_ColShow") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_CompareRows")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CompareRows"));
			temp = newString.substring(newString.indexOf("TABLE_CompareRows") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CompressColByteArray")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CompressColByteArray"));
			temp = newString.substring(newString.indexOf("TABLE_CompressColByteArray") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_ConvertColToString")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ConvertColToString"));
			temp = newString.substring(newString.indexOf("TABLE_ConvertColToString") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_ConvertStringCol")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ConvertStringCol"));
			temp = newString.substring(newString.indexOf("TABLE_ConvertStringCol") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyArrayDataGroupsAddCols")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyArrayDataGroupsAddCols"));
			temp = newString.substring(newString.indexOf("TABLE_CopyArrayDataGroupsAddCols") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyArrayDataGroups")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyArrayDataGroups"));
			temp = newString.substring(newString.indexOf("TABLE_CopyArrayDataGroups") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyArrayDataRowsAddCols")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyArrayDataRowsAddCols"));
			temp = newString.substring(newString.indexOf("TABLE_CopyArrayDataRowsAddCols") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyArrayDataRows")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyArrayDataRows"));
			temp = newString.substring(newString.indexOf("TABLE_CopyArrayDataRows") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColAppendN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColAppendN"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColAppendN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColAppendN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColAppendN"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColAppendN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColAppend")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColAppend"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColAppend") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColDistinctRangeN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColDistinctRangeN"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColDistinctRangeN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColDistinctRange")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColDistinctRange"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColDistinctRange") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColDistinctN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColDistinctN"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColDistinctN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyCol")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyCol"));
			temp = newString.substring(newString.indexOf("TABLE_CopyCol") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColFormatDateN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColFormatDateN"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColFormatDateN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColFormatDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColFormatDate"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColFormatDate") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColFormatN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColFormatN"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColFormatN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColFormat")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColFormat"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColFormat") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColFromRefN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColFromRefN"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColFromRefN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyColFromRef")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyColFromRef"));
			temp = newString.substring(newString.indexOf("TABLE_CopyColFromRef") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowAddRangeByColName")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowAddRangeByColName"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowAddRangeByColName") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowAddRange")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowAddRange"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowAddRange") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowAddByColName")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowAddByColName"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowAddByColName") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowAddAllByColName")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowAddAllByColName"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowAddAllByColName") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowAddAll")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowAddAll"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowAddAll") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowAdd")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowAdd"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowAdd") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowByColName")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowByColName"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowByColName") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowInsertAfter")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowInsertAfter"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowInsertAfter") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyRowInsertBefore")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyRowInsertBefore"));
			temp = newString.substring(newString.indexOf("TABLE_CopyRowInsertBefore") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyTableFormatted")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyTableFormatted"));
			temp = newString.substring(newString.indexOf("TABLE_CopyTableFormatted") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyTableToTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CopyTableToTable"));
			temp = newString.substring(newString.indexOf("TABLE_CopyTableToTable") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CreateDefaultFooterTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CreateDefaultFooterTable"));
			temp = newString.substring(newString.indexOf("TABLE_CreateDefaultFooterTable") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_CreateTableFromArray")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CreateTableFromArray"));
			temp = newString.substring(newString.indexOf("TABLE_CreateTableFromArray") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetColByName")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetColByName"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetColByName") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetColByNum")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetColByNum"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetColByNum") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetColRow")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetColRow"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetColRow") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetDouble")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetDouble"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetDouble") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetInt")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetInt"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetInt") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetRow")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetRow"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetRow") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetString")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetString"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetString") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CurSetTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_CurSetTable"));
			temp = newString.substring(newString.indexOf("TABLE_CurSetTable") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DelColN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DelColN"));
			temp = newString.substring(newString.indexOf("TABLE_DelColN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DeleteFormulaColumnN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DeleteFormulaColumnN"));
			temp = newString.substring(newString.indexOf("TABLE_DeleteFormulaColumnN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DeleteFormulaColumn")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DeleteFormulaColumn"));
			temp = newString.substring(newString.indexOf("TABLE_DeleteFormulaColumn") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DeleteWhereN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DeleteWhereN"));
			temp = newString.substring(newString.indexOf("TABLE_DeleteWhereN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DeleteWhere")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DeleteWhere"));
			temp = newString.substring(newString.indexOf("TABLE_DeleteWhere") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DeleteWhereStringN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DeleteWhereStringN"));
			temp = newString.substring(newString.indexOf("TABLE_DeleteWhereStringN") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DeleteWhereString")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DeleteWhereString"));
			temp = newString.substring(newString.indexOf("TABLE_DeleteWhereString") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_DeleteWhereValue")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_DeleteWhereValue"));
			temp = newString.substring(newString.indexOf("TABLE_DeleteWhereValue") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GoHome")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goHome();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GoLastCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goLastCol();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GoLastRow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goLastRow();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GoLeft")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goLeft();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GoRight")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goRight();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GoUp")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goUp();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupByFormatted")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".groupByFormatted();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideColNames")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideColNames();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideFooter")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideFooter();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideHeader")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideHeader();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideFooter")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideFooter();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideRowNames")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideRowNames();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideSumBreaks")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideSumBreaks();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideTitleBreaks")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideTitleBreaks();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideTitles")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".hideTitles();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_InitFormattedDiffTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".initFormattedDiffTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsDebugOn")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".isDebugOn();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsTableFinite")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".isTableFinite();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_MakeTableUnique")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".makeTableUnique();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_NoFormatNumerical")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".noFormatNumerical();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_NoFormatPrint")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".noFormatPrint();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_NoFormatRef")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".noFormatRef();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_NoQuoteStrings")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".noQuoteStrings();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".printTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_QuoteStrings")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".quoteStrings();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowAllHide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".rowAllHide();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowAllShow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".rowAllShow();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowHideData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".rowHideData();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowHideSum")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".rowHideSum();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowShowData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".rowShowData();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowShowSum")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".rowShowSum();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetCallbackCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetCallbackCol();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetCallbackEditData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetCallbackEditData();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetCallbackName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetCallbackName();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetCallbackRow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetCallbackRow();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetCallbackType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetCallbackType();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetMenuSelect")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetMenuSelect();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetMenu")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetMenu();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetMsgDataType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetMsgDataType();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetMsgScope")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetMsgScope();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetMsgSubType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetMsgSubType();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetMsgType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetMsgType();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetSubscribedMessages")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetSubscribedMessages();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetTimerMilliseconds")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetTimerMilliseconds();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetTimerName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".scriptDataGetTimerName();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowShowSum")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".rowShowSum();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetDebugOff")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setDebugOff();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetDebugOn")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setDebugOn();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetFull")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setFull();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetLite")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setLite();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetOfficialDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setOfficialDateTime();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetRowHeaderJustifyCenter")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setRowHeaderJustifyCenter();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetRowHeaderJustifyLeft")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setRowHeaderJustifyLeft();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetRowHeaderJustifyRight")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".setRowHeaderJustifyRight();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowBreakAllCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showBreakAllCol();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowBreakOnSumCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showBreakOnSumCol();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowColNames")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showColNames();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowFooter")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showFooter();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowHeader")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showHeader();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowRowNames")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showRowNames();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowSumBreaks")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showSumBreaks();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowTitleBreaks")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showTitleBreaks();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowTitles")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".showTitles();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SpaceSep")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".spaceSep();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_TimeStamp")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".timeStamp();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ViewTreeViewTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".viewTreeViewTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ViewTranTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".viewTranTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DistinctRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".distinctRows();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetFooterTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getFooterTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetGroupIndent")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getGroupIndent();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetFullFlag")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getFullFlag();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetHeaderTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getHeaderTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetNumCols")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getNumCols();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetNumRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getNumRows();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetPageLength")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getPageLength();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetPageMedia")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getPageMedia();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetPivotStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getPivotStatus();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowHeaderJustify")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getRowHeaderJustify();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowHeaderWidth")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getRowHeaderWidth();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowNameHideStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getRowNameHideStatus();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetSumAboveChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getSumAboveChar();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetSumBelowChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getSumBelowChar();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetSumBreakPosition")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getSumBreakPosition();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetSumNamePrefix")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getSumNamePrefix();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GoDown")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goDown();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_GoFirstCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goFirstCol();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GoFirstRow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".goFirstRow();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatTitlesForPrinting")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".formatTitlesForPrinting();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetAllocTableSize")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getAllocTableSize();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetAppSumRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getAppSumRows();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetBodyFont")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getBodyFont();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetBodyFontSize")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getBodyFontSize();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetTitleAboveChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTitleAboveChar();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetTitleBelowChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTitleBelowChar();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetTitleBreakPosition")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTitleBreakPosition();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindGroupSum")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".findGroupSum();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_FormatNumerical")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".formatNumerical();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatPrint")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".formatPrint();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatRef")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".formatRef();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillSum")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".fillSum();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillSumPreOrdered")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".fillSumPreOrdered();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillClear")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".fillClear();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_Fill") && !newString.contains("TABLE_FillAddDataN")
				&& !newString.contains("TABLE_FillClear") && !newString.contains("TABLE_FillAddMatchStringN")
				&& !newString.contains("TABLE_FillAddMatchN") && !newString.contains("TABLE_FillSetSourceTable")
				&& !newString.contains("TABLE_FillAddMatchIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fill();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_ClearDataRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".clearDataRows();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_Destroy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".destroy();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_DefaultFormat")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".defaultFormat();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_ViewTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".viewTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillClearData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fillClearData();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CalculateAllFormulaColumns")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".calculateAllFormulaColumns();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ClearGroupBy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".clearGroupBy();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ClearSumRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".clearSumRows();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ClearTitleRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".clearTitleRows();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ColAllHide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".colAllHide();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ColAllShow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".colAllShow();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CommaSep")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".commaSep();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CondenseTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".condenseTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_CreateDefaultHeaderTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".createDefaultHeaderTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CreateLockHideInfoTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".createLockHideInfoTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CurGetColName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".curGetColName();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CurGetCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".curGetCol();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CurGetDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".curGetDouble();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CurGetInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".curGetInt();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CurGetRow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".curGetRow();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CurGetString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".curGetString();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CurGetTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".curGetTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillClearMatch")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fillClearMatch();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillClearData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fillClearData();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillDistinct")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fillDistinct();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillPreOrdered")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fillPreOrdered();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_ExportCSVString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".exportCSVString();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_MathSubColConstN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathSubColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathSubColConst")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathSubColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathSubColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathSubCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathSubCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathSubCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SumColRangeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sumColRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SumColRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sumColRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_CopyColDistinct")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".copyColDistinct("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathMultColConstN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathMultColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathMultColConst")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathMultColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathMultColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathMultCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathMultCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathMultCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathAddColConstN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathAddColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathAddColConst")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathAddColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathAddColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathAddCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;

		}

		if (newString.contains("TABLE_MathBucketCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathBucketCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;

		}
		if (newString.contains("TABLE_MathCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;

		}

		if (newString.contains("TABLE_MathAddCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathAddCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathColConstDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathColConstDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathColConstInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathColConstInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathDivColConstN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathDivColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathDivColConst")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathDivColConst("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathDivCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathDivCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_MathPowColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathPowCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathPowCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathPowCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_MathRoundColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathRoundCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_MathRoundCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathRoundCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsRef")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsRef("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsNotnl")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnl("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColValIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DelCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".delCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_CopyColFromRef")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".copyColFromRef("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_CopyColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".copyCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SortCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sortCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_GetDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_MathDivColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathDivCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_MathABSColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathABSCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_MathABSCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathABSCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColName("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColTitleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColTitle("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;

		}

		if (newString.contains("TABLE_SetTableN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTableSumRowName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTableSumRowName("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTableToByteArrayN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTableToByteArray("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTableToByteArray")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTableToByteArray("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTitleAboveChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTitleAboveChar("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTitleBelowChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTitleBelowChar("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTitleBreakPosition")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTitleBreakPosition("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetXmlN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setXml("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetXml")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setXml("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTitleFormat")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTitleFormat("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTranN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTran("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTran("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowGroupSumBreakN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".showGroupSumBreak("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ShowGroupSumBreak")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".showGroupSumBreak("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SortColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sortCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_StringIsNull")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".stringIsNull("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_StringIsNullN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".stringIsNull("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SumRangeDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sumRangeDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SumRangeDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sumRangeDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SumRangeIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sumRangeInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SumRangeInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".sumRangeInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SwapRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".swapRows("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_TableToXMLString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".tableToXMLString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_Transpose")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".transpose("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_TuneGrowth")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".tuneGrowth("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_TuneSizing")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".tuneSizing("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_UncompressColByteArray")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".uncompressColByteArray("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_UnsortedFindDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".unsortedFindDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_UnsortedFindDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".unsortedFindDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_UnsortedFindIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".unsortedFindInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_UnsortedFindInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".unsortedFindInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_UnsortedFindStringN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".unsortedFindString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_UnsortedFindString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".unsortedFindString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_ViewTableAsHtml")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".viewTableAsHtml("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ViewTableWithPivotConfig")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".viewTableWithPivotConfig("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ViewTableWithPivot")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".viewTableWithPivot("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAs128thN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAs128th("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAs128th")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAs128th("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAs32ndN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAs32nd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAs32nd")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAs32nd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAs64thN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAs64th("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAs64th")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAs64th("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsAbsNotnlAcctN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsAbsNotnlAcct("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsAbsNotnlAcct")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsAbsNotnlAcct("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsBoolN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsBool("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsBool")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsBool("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsBPSN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsBPS("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsBPS")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsBPS("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateDayStartTimeEndN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateDayStartTimeEnd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateDayStartTimeEnd")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateDayStartTimeEnd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateDayStartTimeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateDayStartTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateDayStartTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateDayStartTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateTime24HREndN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateTime24HREnd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsDateTime24HREnd")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateTime24HREnd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateTime24HRN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateTime24HR("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateTime24HR")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateTime24HR("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateTimeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDateN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsDoubleStripN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDoubleStrip("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDoubleStrip")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDoubleStrip("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsLatitudeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsLatitude("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsLatitude")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsLatitude("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsLongitudeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsLongitude("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsLongitude")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsLongitude("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlAcctN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlAcct("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlAcct")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlAcct("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlCcyN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlCcy("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlCcy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlCcy("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlDecimalsN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlDecimals("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlDecimals")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlDecimals("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlStripN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlStrip("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlStrip")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnlStrip("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsNotnlN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsNotnl("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsPymtPeriodN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsPymtPeriod("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsPymtPeriod")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsPymtPeriod("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsRateN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsRate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsRate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsRate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsRefN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsRef("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTableWithChangedFlagN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTableWithChangedFlag("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTableWithChangedFlag")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTableWithChangedFlag("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTableN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTime24HREndN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTime24HREnd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsTime24HREnd")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTime24HREnd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTime24HRN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTime24HR("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetColFormatAsTime24HR")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTime24HR("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTimeHoDN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTimeHoD("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTimeHoD")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTimeHoD("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTimeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTranfN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTranf("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsTranf")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsTranf("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsUIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsUInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatAsUInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatAsUInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatNoneN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatNone("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColFormatNone")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColFormatNone("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColGroupSumStatusN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColGroupSumStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColHeaderJustifyCenterN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColHeaderJustifyCenter("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColHeaderJustifyCenter")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColHeaderJustifyCenter("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColHeaderJustifyLeftN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColHeaderJustifyLeft("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColHeaderJustifyLeft")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColHeaderJustifyLeft("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColHeaderJustifyRightN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColHeaderJustifyRight("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColHeaderJustifyRight")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColHeaderJustifyRight("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColHideStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColHideStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColIncrementIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColIncrementInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColIncrementInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColIncrementInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColNameN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColName("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColSeparator")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColSeparator("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColSumStatusN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColSumStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColSumStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColSumStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColTitle")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColTitle("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColTypeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValDateTimeByPartsN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValDateTimeByParts("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValDateTimeByParts")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValDateTimeByParts("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValDateTimeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setColValString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetDateTimeByPartsN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDateTimeByParts("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetDateTimeByParts")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDateTimeByParts("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetDateTimeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetGroupIndent")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setGroupIndent("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetPageLength")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPageLength("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetPageMedia")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPageMedia("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetPivotStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPivotStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetRowHeaderWidth")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRowHeaderWidth("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetRowHideStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRowHideStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetRowLockHideStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRowLockHideStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetRowNameGroupIndented")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRowNameGroupIndented("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetRowName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRowName("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetRowSumCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRowSumCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetRowValues")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRowValues("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetSumBelowChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSumBelowChar("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_SetSumAboveChar")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSumAboveChar("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetSumBreakPosition")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSumBreakPosition("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetSumFormat")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSumFormat("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetSumNamePrefix")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSumNamePrefix("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowSumCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getRowSumCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getRowType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowHideStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getRowHideStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowLockHideStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getRowLockHideStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetRowName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getRowName("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetGroupCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getGroupCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetGroupEndRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getGroupEndRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetGroupStartRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getGroupStartRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetGroupSumBreakN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getGroupSumBreak("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetGroupSumBreak")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getGroupSumBreak("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetTableFromByteArrayN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getTableFromByteArray("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetTableFromByteArray")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getTableFromByteArray("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetNomN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getNom("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetNom")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getNom("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetTranN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getTran("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getTran("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetXmlN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getXml("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetXml")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getXml("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColType")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "TABLE_GetColType", ".getColType");
				returnString = newString.replaceFirst("TABLE_GetColType\\([^)]*\\)", replacement);
				newString = returnString;
			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getColType("
						+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}

		if (newString.contains("TABLE_GraphTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".graphTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupCreateRowLabel")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupCreateRowLabel("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupFormatted")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupFormatted("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupSumHdrN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupSumHdr("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupSumHdr")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupSumHdr("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupTitleAboveN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupTitleAbove("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_GroupTitleAbove")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupTitleAbove("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupTitleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupTitle("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupTitle")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupTitle("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupTitlePositionedN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupTitlePositioned("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GroupTitlePositioned")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupTitlePositioned("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideGroupSumBreakN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".hideGroupSumBreak("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_HideGroupSumBreak")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".hideGroupSumBreak("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_InputFromCSVFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".inputFromCSVFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_InputFromFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".inputFromFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_InsertRowAfter")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".insertRowAfter("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_InsertRowBefore")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".insertRowBefore("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsColFiniteN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isColFinite("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsColFinite")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isColFinite("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsColNumericalN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isColNumerical("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsColNumerical")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isColNumerical("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsColNumValid")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isColNumValid("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsRowNumValid")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isRowNumValid("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_IsValueFinite")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isValueFinite("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_LinearInterp")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".linearInterp("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_LoadPackedFromFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".loadPackedFromFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_LoadTableFromFileWithHeader")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".loadTableFromFileWithHeader("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ModifyFormulaColumnN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".modifyFormulaColumn("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ModifyFormulaColumn")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".modifyFormulaColumn("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_OutputByOutputType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".outputByOutputType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PackToFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".packToFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintCell")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printCell("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintRowBreak")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printRowBreak("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintRow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printRow("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintTableAppendToFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printTableAppendToFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintTableDumpToFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printTableDumpToFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintTableToFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printTableToFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintTableToHtml")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printTableToHtml("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_PrintTableToTtx")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".printTableToTtx("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowHide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".rowHide("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_RowShow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".rowShow("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_AddWidget")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataAddWidget("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_DeleteWidget")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataDeleteWidget("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_EndTimer")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataEndTimer("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetRowSelectStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataGetRowSelectStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetWidgetMenuSelect")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataGetWidgetMenuSelect("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetWidgetMenu")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataGetWidgetMenu("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_GetWidgetString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataGetWidgetString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_MessageSubscribe")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataMessageSubscribe("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_MessageUnSubscribe")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataMessageUnSubscribe("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_ModifyWidget")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataModifyWidget("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_MoveListBox")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataMoveListBox("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetMenuSelect")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetMenuSelect("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetMenu")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetMenu("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetPostTreeviewCallback")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetPostTreeviewCallback("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetRefreshType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetRefreshType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetRowSelectStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetRowSelectStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetTimer")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetTimer("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetWidgetMenu")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetWidgetMenu("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ScriptData_SetWidgetString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".scriptDataSetWidgetString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetAppSumRows")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setAppSumRows("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetBodyFontSize")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setBodyFontSize("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetBodyFont")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setBodyFont("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetByteArray_FromTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setByteArrayFromTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetByteArray")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setByteArray("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetCellTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCellTran("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetClobN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setClob("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetClob")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setClob("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetDateTimeN_Time")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_GetDateTimeN_Date")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetDateTime_Time")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetDateTime_Date")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetDateTimeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_GetDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetByteArray")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getByteArray("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellFormat")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellFormat("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellTran("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetCellType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCellType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetClobN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getClob("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetClob")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getClob("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColFormatN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColFormat("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColFormat")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColFormat("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColFormatParamN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColFormatParam("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColFormatParam")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColFormatParam("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColFormatTableN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColFormatTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColFormatTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColFormatTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColHeaderJustify")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColHeaderJustify("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColHideStatusN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColHideStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColHideStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColHideStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColName("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColNum")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColNum("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColSeparator")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColSeparator("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColSumStatusN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColSumStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColSumStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColSumStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColTitleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColTitle("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_GetColTitle")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getColTitle("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetJustifyCenterN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetJustifyCenter("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetJustifyCenter")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetJustifyCenter("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetJustifyLeftN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetJustifyLeft("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetJustifyLeft")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetJustifyLeft("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetJustifyRightN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetJustifyRight("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetJustifyRight")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetJustifyRight("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetTableWidth")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetTableWidth("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetWidthN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetWidth("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatSetWidth")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatSetWidth("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindIntFormattedRangeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findIntFormattedRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindIntFormattedRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findIntFormattedRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindIntFormattedN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findIntFormatted("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindIntFormatted")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findIntFormatted("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindIntRangeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findIntRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindIntRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findIntRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindRowGrouped")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findRowGrouped("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindRowTypeRangeStart")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findRowTypeRangeStart("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindRowTypeRangeEnd")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findRowTypeRangeEnd("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindRowTypeRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findRowTypeRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindStringRangeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findStringRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindStringRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findStringRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindStringN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindTableRangeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findTableRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindTableRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findTableRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindTableN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatColDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatColDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatGetJustifyN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatGetJustify("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatGetJustify")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatGetJustify("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatGetWidthN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatGetWidth("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatGetWidth")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatGetWidth("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatGetWidthN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindDoubleRangeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findDoubleRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindDoubleRange")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findDoubleRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FindGroupEndByGroups")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".findGroupEndByGroups("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddDataN") && !newString.contains("TABLE_FillAddMatchStringN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddData("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddData") && !newString.contains("TABLE_FillAddMatchString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddData("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchStringN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchString("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatch("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchByTypeN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchByType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchByType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchByType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatch")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatch("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchIntN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillAddMatchInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillAddMatchInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillSetSourceTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillSetSourceTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_DelRow")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".delRow("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DiffTablesDetail")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTablesDetail("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DiffTablesFormattedWithType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTablesFormattedWithType("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DiffTablesFormatted")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTablesFormatted("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DumpTableToFile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".dumpTableToFile("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ExcelSave")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".excelSave("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_ExcelView")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".excelView("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DiffTables")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTables("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_DiffTables")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTables("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillRemoveDataN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillRemoveData("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillRemoveData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillRemoveData("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillRemoveMatchN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillRemoveMatch("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FillRemoveMatch")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".fillRemoveMatch("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_DiffTables")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTables("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DiffTables")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTables("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DiffTables")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".diffTables("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DeleteWhereValueN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_SetString")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setString("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TABLE_CopyRowAddAll")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim()
					+ ".copyRowAddAll(" + newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_SetColValStringN")) {
			temp = newString.substring(newString.indexOf("TABLE_SetColValStringN"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_SetColValStringN"), temp.indexOf(")") + 1);
			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_CopyTable")) {
			temp = newString.substring(newString.indexOf("TABLE_CopyTable"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_CopyTable"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GetColName")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_GetColName"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_GetColName"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_GetColType")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_GetColType"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_GetColType"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;

		}
		if (newString.contains("TABLE_GetNumCols")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_GetNumCols"));
			temp = newString.substring(newString.indexOf("TABLE_GetNumCols"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_SetColGroupSumStatus")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_SetColGroupSumStatus"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_SetColGroupSumStatus"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_GetRowType")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_GetRowType"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_GetRowType"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_SetDoubleN")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_SetDoubleN"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_SetDoubleN"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_SetDouble")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_SetDouble"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_SetDouble"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_Sum")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_Sum"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_Sum"), tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_ClearRows")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_ClearRows"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_ClearRows"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_InsertRowBefore")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_InsertRowBefore"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_InsertRowBefore"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_SetRowType")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_SetRowType"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_SetRowType"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_CopyRow")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_CopyRow"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_CopyRow"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_Pivot")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_Pivot"));
			temp = newString.substring(newString.indexOf("TABLE_Pivot"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_SetTableTitle")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_SetTableTitle"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_SetTableTitle"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;

		}

		if (newString.contains("TABLE_CopyRowAddAllByColName")) {
			temp = newString.substring(newString.indexOf("TABLE_CopyRowAddAllByColName"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_CopyRowAddAllByColName"), temp.indexOf(")") + 1);
			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;

		}
		if (newString.contains("TABLE_GetIntN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_GetIntN"));
			temp = newString.substring(newString.indexOf("TABLE_GetIntN"), newString.length());
			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_GetInt")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_GetInt"));
			temp = newString.substring(newString.indexOf("TABLE_GetInt"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GetTableTitle")) {
			temp = newString.substring(newString.indexOf("TABLE_GetTableTitle"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_GetTableTitle"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_GetTableName")) {
			temp = newString.substring(newString.indexOf("TABLE_GetTableName"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_GetTableName"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GetTableSize")) {
			temp = newString.substring(newString.indexOf("TABLE_GetTableSize"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_GetTableSize"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GetTableN")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_GetTableN"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_GetTableN"),
					tableObjectName.indexOf(")") + 1);
			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;

		}

		if (newString.contains("TABLE_GetTable")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_GetTable"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_GetTable"),
					tableObjectName.indexOf(")") + 1);
			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;

		}

		if (newString.contains("TABLE_GetString") || newString.contains("TABLE_GetStringN")) {
			temp = newString.substring(newString.indexOf("TABLE_GetString"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_GetString"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;

		}
		if (newString.contains("TABLE_GetNumRows")) {
			temp = newString.substring(newString.indexOf("TABLE_GetNumRows"), newString.length());
			temp = temp.substring(temp.indexOf("TABLE_GetNumRows"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GetDoubleN")) {
			do {
				temp = newString.substring(newString.indexOf("TABLE_GetDoubleN"), newString.length());
				temp = temp.substring(temp.indexOf("TABLE_GetDoubleN"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getDouble("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("TABLE_GetDoubleN"));

		}
		if (newString.contains("TABLE_GetDouble")) {
			do {
				temp = newString.substring(newString.indexOf("TABLE_GetDouble"), newString.length());
				temp = temp.substring(temp.indexOf("TABLE_GetDouble"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getDouble("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("TABLE_GetDouble"));

		}
		if (newString.contains("TABLE_GetColNum")) {
			do {
				tableObjectName = newString.substring(0, newString.indexOf("TABLE_GetColNum"));
				temp = newString.substring(newString.indexOf("TABLE_GetColNum"), newString.length());
				tableObjectName += temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim() + ".getColNum("
						+ temp.substring(temp.indexOf(",") + 1, temp.length());
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("TABLE_GetColNum"));
		}

		if (newString.contains("TABLE_Select") && !newString.contains("show_msg") && !newString.contains("//")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_Select"));
			temp = newString.substring(newString.indexOf("TABLE_Select") + 1, newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		newString = simpleReplace(newString, "TABLE_LoadFromDbWithSQL", "DBaseTable.loadFromDbWithSQL");

		newString = simpleReplace(newString, "TABLE_GetTableDefInTable", "Util.getTableDefInTable");

		newString = simpleReplace(newString, "TABLE_New", "Table.tableNew");

		if (newString.contains("TABLE_GetColTypeN")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "TABLE_GetColTypeN", ".getColType");
				returnString = newString.replaceFirst("TABLE_GetColTypeN\\([^)]*\\)", replacement);
				newString = returnString;
			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getColType("
						+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}

		if (newString.contains("TABLE_GroupSumN")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_GroupSumN"));
			temp = newString.substring(newString.indexOf("TABLE_GroupSumN"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GroupSum")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_GroupSum"));
			temp = newString.substring(newString.indexOf("TABLE_GroupSum"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TABLE_GroupBy")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_GroupBy"));
			temp = newString.substring(newString.indexOf("TABLE_GroupBy"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_Group")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_Group"));
			temp = newString.substring(newString.indexOf("TABLE_Group"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_ColHide")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_ColHide"));
			temp = newString.substring(newString.indexOf("TABLE_ColHide"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_RowHide")) {
			tableObjectName = newString.substring(0, newString.indexOf("TABLE_RowHide"));
			temp = newString.substring(newString.indexOf("TABLE_RowHide"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		newString = simpleReplace(newString, "TABLE_LoadSrun", "SimResult.tableLoadSrun");

		newString = simpleReplace(newString, "TABLE_QueryInsert", "Query.tableQueryInsert");

		if (newString.contains("TABLE_AddArrayDataCols")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_AddArrayDataCols"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_AddArrayDataCols"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		newString = simpleReplace(newString, "TIME_GetServerTimeHMS()", "Util.timeGetServerTimeHMS()");

		newString = simpleReplace(newString, "TIME_GetServerTime()", "Util.timeGetServerTime()");

		newString = simpleReplace(newString, "DATE_FORMAT_IMM", "DATE_FORMAT.DATE_FORMAT_IMM");

		newString = simpleReplace(newString, "DATE_FORMAT_MINIMAL", "DATE_FORMAT.DATE_FORMAT_MINIMAL");

		newString = simpleReplace(newString, "DATE_FORMAT_DEFAULT", "DATE_FORMAT.DATE_FORMAT_DEFAULT");

		newString = simpleReplace(newString, "DATE_FORMAT_DMY_NOSLASH", "DATE_FORMAT.DATE_FORMAT_DMY_NOSLASH");

		newString = simpleReplace(newString, "DATE_LOCALE_US", "DATE_LOCALE.DATE_LOCALE_US");

		newString = simpleReplace(newString, "DATE_NumGBDBetweenForIndex", "OCalendar.numGBDBetweenForIndex");

		newString = simpleReplace(newString, "DATE_SetReleaseDatesForCurrency", "Util.setReleaseDatesForCurrency");

		newString = simpleReplace(newString, "DATE_SetCurrentDate", "Util.setCurrentDate");

		newString = simpleReplace(newString, "DATE_ProcessingDate", "Util.processingDate");

		newString = simpleReplace(newString, "DATE_JumpGBDForIndex", "OCalendar.jumpGBDForIndex");

		newString = simpleReplace(newString, "DATE_JumpMonths", "OCalendar.jumpMonths");

		newString = simpleReplace(newString, "DATE_MDYtoDate", "OCalendar.mdyToDate");

		newString = simpleReplace(newString, "DATE_Today", "OCalendar.today");

		newString = simpleReplace(newString, "DATE_ParseStringWithHolId", "OCalendar.parseStringWithHolId");

		newString = simpleReplace(newString, "DATE_ParseString", "OCalendar.parseString");

		newString = simpleReplace(newString, "DATE_Print", "OCalendar.print");

		newString = simpleReplace(newString, "DATE_GetStartOfQuarter", "OCalendar.getStartOfQuarter");

		newString = simpleReplace(newString, "DATE_GetTradingDate", "Util.getTradingDate");

		newString = simpleReplace(newString, "DATE_GetMonthStr", "OCalendar.getMonthStr");

		newString = simpleReplace(newString, "Date_IsDaylightSavings", "OCalendar.dateIsDaylightSavings");

		newString = simpleReplace(newString, "DATE_GetMonth", "OCalendar.getMonth");

		newString = simpleReplace(newString, "DATE_GetEOM", "OCalendar.getEOM");

		newString = simpleReplace(newString, "DATE_IsHoliday", "OCalendar.isHoliday");

		newString = simpleReplace(newString, "DATE_GetEOY", "OCalendar.getEOY");

		newString = simpleReplace(newString, "DATE_IsGbd", "OCalendar.isGbd");

		newString = simpleReplace(newString, "DATE_GetYear", "OCalendar.getYear");

		newString = simpleReplace(newString, "DATE_GetLgbdForCurrency", "OCalendar.getLgbdForCurrency");

		newString = simpleReplace(newString, "DATE_GetLgbd", "OCalendar.getLgbd");

		newString = simpleReplace(newString, "DATE_GetReleaseDatesForCurrency", "Util.getReleaseDatesForCurrency");

		newString = simpleReplace(newString, "DATE_GetNgbdForCurrency", "OCalendar.getNgbdForCurrency");

		newString = simpleReplace(newString, "DATE_GetNgbd", "OCalendar.getNgbd");

		newString = simpleReplace(newString, "DATE_FormatJdForDbAccess", "OCalendar.formatJdForDbAccess");

		newString = simpleReplace(newString, "DATE_FormatJd", "OCalendar.formatJd");

		newString = simpleReplace(newString, "DATE_ConvertYYYYMMDDToJd", "OCalendar.convertYYYYMMDDToJd");

		newString = simpleReplace(newString, "DATE_ConvertYYYYMMToJd", "OCalendar.convertYYYYMMToJd");

		newString = simpleReplace(newString, "DATE_DayCountFactor", "Instrument.dayCountFactor");

		newString = simpleReplace(newString, "DATE_StrToDate", "OCalendar.strToDate");

		newString = simpleReplace(newString, "DATE_GetServerDate", "OCalendar.getServerDate");

		newString = simpleReplace(newString, "DATE_GasDay", "Util.gasDay");

		newString = simpleReplace(newString, "DATE_GetBusinessDate", "Util.getBusinessDate");

		newString = simpleReplace(newString, "DATE_GetDaysDelayedForIndexAndRefSource",
				"Index.getDaysDelayedForIndexAndRefSource");

		newString = simpleReplace(newString, "DATE_GetDaysDelayedForIndex", "Index.getDaysDelayedForIndex");

		newString = simpleReplace(newString, "DATE_GetDayOfWeek", "OCalendar.getDayOfWeek");

		newString = simpleReplace(newString, "DATE_GetEndOfQuarter", "OCalendar.getEndOfQuarter");

		newString = simpleReplace(newString, "DATE_GetDay", "OCalendar.getDay");

		newString = simpleReplace(newString, "DATE_GetSOM", "OCalendar.getSOM");

		newString = simpleReplace(newString, "DATE_GetSOY", "OCalendar.getSOY");

		newString = simpleReplace(newString, "day_is_in_bitmap", "Power.dayisInBitmap");

		newString = simpleReplace(newString, "STR_StripBlanks", "Str.stripBlanks");

		if (newString.contains("STR_Equal")) {
			do {

				/*
				 * temp = newString.substring(newString.indexOf("STR_Equal"),
				 * newString.length()); temp = temp.substring(temp.indexOf("STR_Equal"),
				 * temp.indexOf(")")+1); tableObjectName = temp.substring(temp.indexOf("(") + 1,
				 * temp.indexOf(",")).trim(); tableObjectName = tableObjectName + ".equals("+
				 * temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				 * tableObjectName = newString.replace(temp, tableObjectName);
				 */

				temp = newString.substring(newString.indexOf("STR_Equal"), newString.length());
				index = getnthMatchIdx(temp);

				commaIdx = getCommaIdx(temp, index);

				temp = temp.substring(temp.indexOf("STR_Equal"), index + 1);

				tableObjectName = temp.substring(temp.indexOf("(") + 1, commaIdx).trim();

				tableObjectName = tableObjectName + ".equals(" + temp.substring(commaIdx + 1, temp.length()).trim();
				tableObjectName = newString.replace(temp, tableObjectName);

				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("STR_Equal"));
		}

		/*
		 * temp = newString.substring(newString.indexOf("STR_IntToStr"),
		 * newString.indexOf(";") + 1); tableObjectName = newString.substring(0,
		 * newString.indexOf("STR_IntToStr")); temp = temp.substring(temp.indexOf("(") +
		 * 1, temp.indexOf(")")) .trim(); if(temp.contains("(")){
		 * temp+=").toString());"; }else{ temp+=".toString());"; } tableObjectName +=
		 * temp;
		 */

		newString = simpleReplace(newString, "STR_IntToStr", "Str.intToStr");

		if (newString.contains("STR_IEqual")) {
			do {
				temp = newString.substring(newString.indexOf("STR_IEqual"), newString.length());
				temp = temp.substring(temp.indexOf("STR_IEqual"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".equalsIgnoreCase("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);

				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("STR_IEqual"));

		}

		newString = simpleReplace(newString, "STR_StrToInt", "Str.strToInt");

		newString = simpleReplace(newString, "STR_IsInt", "Str.isInt");

		newString = simpleReplace(newString, "STR_IsNotEmpty", "Str.isNotEmpty");

		newString = simpleReplace(newString, "STR_IsEmpty", "Str.isEmpty");

		newString = simpleReplace(newString, "STR_FindSubString", "Str.findSubString");

		newString = simpleReplace(newString, "STR_Substr", "Str.substr");

		if (newString.contains("STR_ToLower")) {
			temp = newString.substring(newString.indexOf("STR_ToLower"), newString.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".toLowerCase()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("STR_ContainsSubString")) {
			do {
				temp = newString.substring(newString.indexOf("STR_ContainsSubString"), newString.length());
				temp = temp.substring(temp.indexOf("STR_ContainsSubString"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".containsSubString("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("STR_ContainsSubString"));
		}
		if (newString.contains("STR_Len")) {
			tableObjectName = newString.substring(newString.indexOf("STR_Len"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("STR_Len"), tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".length()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("DT_AddHoursToDateTime")) {
			do {
				temp = newString.substring(newString.indexOf("DT_AddHoursToDateTime"), newString.length());
				temp = temp.substring(temp.indexOf("DT_AddHoursToDateTime"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".addHoursToDateTime("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("DT_AddHoursToDateTime"));
		}
		if (newString.contains("DT_AddMinutesToDateTime")) {
			do {
				temp = newString.substring(newString.indexOf("DT_AddMinutesToDateTime"), newString.length());
				temp = temp.substring(temp.indexOf("DT_AddMinutesToDateTime"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".addMinutesToDateTime("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("DT_AddMinutesToDateTime"));
		}
		if (newString.contains("DT_AddSecondsToDateTime")) {
			do {
				temp = newString.substring(newString.indexOf("DT_AddSecondsToDateTime"), newString.length());
				temp = temp.substring(temp.indexOf("DT_AddSecondsToDateTime"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".addSecondsToDateTime("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("DT_AddSecondsToDateTime"));
		}
		if (newString.contains("DT_ConvertFromGMT")) {
			do {
				temp = newString.substring(newString.indexOf("DT_ConvertFromGMT"), newString.length());
				temp = temp.substring(temp.indexOf("DT_ConvertFromGMT"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".convertFromGMT("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("DT_ConvertFromGMT"));
		}

		if (newString.contains("DT_ConvertFromGMT")) {
			do {
				temp = newString.substring(newString.indexOf("DT_ConvertFromGMT"), newString.length());
				temp = temp.substring(temp.indexOf("DT_ConvertFromGMT"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".convertToGMT("
						+ temp.substring(temp.indexOf(",") + 1, temp.indexOf(")") + 1).trim();
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("DT_ConvertFromGMT"));
		}
		if (newString.contains("DT_Destroy")) {
			temp = newString.substring(newString.indexOf("DT_Destroy"), newString.length());
			temp = temp.substring(temp.indexOf("DT_Destroy"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".destroy()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_FormatDateTimeForDbAccess")) {
			temp = newString.substring(newString.indexOf("DT_FormatDateTimeForDbAccess"), newString.length());
			temp = temp.substring(temp.indexOf("DT_FormatDateTimeForDbAccess"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".formatForDbAccess()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_GetDate")) {
			temp = newString.substring(newString.indexOf("DT_GetDate"), newString.length());
			temp = temp.substring(temp.indexOf("DT_GetDate"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getDate()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_GetTime")) {
			temp = newString.substring(newString.indexOf("DT_GetTime"), newString.length());
			temp = temp.substring(temp.indexOf("DT_GetTime"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getTime()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_IsNull")) {
			temp = newString.substring(newString.indexOf("DT_IsNull"), newString.length());
			temp = temp.substring(temp.indexOf("DT_IsNull"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".isNull()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_SetDateTime")) {
			temp = newString.substring(newString.indexOf("DT_SetDateTime"), newString.length());
			temp = temp.substring(temp.indexOf("DT_SetDateTime"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".setDateTime()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_SetDate")) {
			temp = newString.substring(newString.indexOf("DT_SetDate"), newString.length());
			temp = temp.substring(temp.indexOf("DT_SetDate"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".setDate()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_SetTime")) {
			temp = newString.substring(newString.indexOf("DT_SetTime"), newString.length());
			temp = temp.substring(temp.indexOf("DT_SetTime"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".setTime()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = simpleReplace(newString, "DT_StrToDateTime", "ODateTime.strToDateTime");

		newString = simpleReplace(newString, "DT_ToString", "Str.dtToString");

		newString = simpleReplace(newString, "DT_New()", "ODateTime.dtNew()");

		newString = simpleReplace(newString, "EXIT_Fail()", "Util.exitFail()");

		newString = simpleReplace(newString, "EXIT_Succeed()", "Util.exitSucceed()");

		newString = simpleReplace(newString, "abs(", "Math.abs(");

		newString = simpleReplace(newString, "ROW_GROUP_SUM", "ROW_TYPE_ENUM.ROW_GROUP_SUM");

		newString = simpleReplace(newString, "SETTLEMENT_TYPE_PHYSICAL",
				"OPTION_SETTLEMENT_TYPE.SETTLEMENT_TYPE_PHYSICAL.toInt()");

		newString = simpleReplace(newString, "SETTLEMENT_TYPE_CASH",
				"OPTION_SETTLEMENT_TYPE.SETTLEMENT_TYPE_CASH.toInt()");

		newString = simpleReplace(newString, "SETTLEMENT_TYPE_PHYSICAL_INTERNAL",
				"OPTION_SETTLEMENT_TYPE.SETTLEMENT_TYPE_PHYSICAL_INTERNAL.toInt()");

		newString = simpleReplace(newString, "COMMODITY_TOOLSET", "TOOLSET_ENUM.COMMODITY_TOOLSET.toInt()");

		newString = simpleReplace(newString, "ASK_SetAvsTable", "Ask.setAvsTable");

		newString = simpleReplace(newString, "ASK_SetTextEdit", "Ask.setTextEdit");

		newString = simpleReplace(newString, "ASK_ViewTable", "Ask.viewTable");

		newString = simpleReplace(newString, "ASK_Ok", "Ask.ok");

		newString = simpleReplace(newString, "ASK_STRING", "ASK_TEXT_DATA_TYPES.ASK_STRING");

		newString = simpleReplace(newString, "ASK_DATE", "ASK_TEXT_DATA_TYPES.ASK_DATE");

		newString = simpleReplace(newString, "ASK_INT", "ASK_TEXT_DATA_TYPES.ASK_INT");

		newString = simpleReplace(newString, "ASK_SINGLE_SELECT", "ASK_SELECT_TYPES.ASK_SINGLE_SELECT.toInt()");

		newString = simpleReplace(newString, "ASK_MULTI_SELECT", "ASK_SELECT_TYPES.ASK_MULTI_SELECT.toInt()");

		if (newString.equals("end:") || newString.equals("goto end;") || newString.equals("EXIT_SCRIPT:")) {
			returnString = "";
		}

		returnString = AVSJVSReplacerTwo.replacecoreFunctionCall1(newString);
		returnString = AVSJVSReplacerThree.replacecoreFunctionCall2(returnString);
		returnString = AVSJVSReplacerFour.replacecoreFunctionCall3(returnString);
		returnString = ReplaceCoreFunctionEnumCall.ReplaceCoreFunction_EnumCall(returnString);
		returnString = ReplaceCoreFunctionEnumCall.ReplaceApiCallInsideArguments(returnString);

		return (returnString);
	}

	public static int getnthMatchIdx(String newString) {
		String temp;
		int openbcnt = 0, closebcnt = 0, index = 0;
		if (newString.contains("STR_Equal")) {
			temp = newString.substring(newString.indexOf("STR_Equal"), newString.length());

			int count = temp.length();
			for (int i = 0; i < count; i++) {
				String ch = temp.substring(i, i + 1);
				if (ch.equals("(")) {
					openbcnt++;
				}
				if (ch.equals(")")) {
					break;
				}
			}
			for (int i = 1; i <= count; i++) {
				String ch = temp.substring(i, i + 1);
				if (ch.equals(")")) {
					closebcnt++;
				}
				if (openbcnt == closebcnt) {
					index = i;
					break;
				}
			}

		}
		return index;
	}

	public static int getCommaIdx(String newString, int idx) {
		int i, index = 0;
		for (i = idx; i >= 0; i--) {
			String ch = newString.substring(i - 1, i);
			if (ch.equals(",")) {
				index = i - 1;
				break;
			}
		}
		return index;
	}

	private static String simpleReplace(String newString, String target, String replacement) {
		if (newString.contains(target)) {
			return newString.replace(target, replacement);
		}
		return newString;
	}

}
