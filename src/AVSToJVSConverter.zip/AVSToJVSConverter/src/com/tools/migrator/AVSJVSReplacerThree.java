package com.tools.migrator;

public class AVSJVSReplacerThree {

	public static String replacecoreFunctionCall2(String newString) {

		String returnString = null;
		String tableObjectName = null;
		String temp = null;
		returnString = newString;

		if (newString.contains("COMM_GetHourlyQuantityTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getHourlyQuantityTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("COMM_SetHourlyQuantity")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setHourlyQuantitye("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("compute_total_seconds_in_GMT_date_range")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".computeTotalSecondsInGMTDateRange("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_AddHoursToDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".addHoursToDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_AddMinutesToDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".addMinutesToDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_AddSecondsToDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".addSecondsToDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_ConvertFromGMT")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".convertFromGMT("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_AddSecondsToDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".addSecondsToDateTime("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_ConvertToGMT")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".convertToGMT("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("DT_Destroy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".destroy()";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_FormatDateTimeForDbAccess")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".formatForDbAccess()";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_GetDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getDate()";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_GetTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getTime()";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_SetDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDate()";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_SetDateTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDate()";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("DT_SetTime")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setTime()";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("ETAG_Clear")) {
			temp = newString.substring(newString.indexOf("ETAG_Clear"), newString.length());
			temp = temp.substring(temp.indexOf("ETAG_Clear"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("ETAG_GetNthPhysicalSegmentMarketSN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getNthPhysicalSegmentMarketSN("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("ETAG_GetNthPhysicalSegmentPhysicalSN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getNthPhysicalSegmentMarketSN("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("ETAG_Process")) {
			temp = newString.substring(newString.indexOf("ETAG_Process"), newString.length());
			temp = temp.substring(temp.indexOf("ETAG_Process"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("ETAGF_GetField")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getField("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("ETAGF_GetFieldDouble")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getFieldDouble("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("ETAGF_GetFieldInt")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getFieldInt("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("ETAGF_GroupAdd")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".groupAdd("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("ETAGF_SetField")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setField("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("HYBRID_GetComponentVTranFromTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getComponentVTranFromTran("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_AccruedInterestForAvgRate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".accruedInterestForAvgRate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_AdjustForDefaults")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".adjustForDefaults("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_CalcOtcPaperYieldToRate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".calcOtcPaperYieldToRate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_ChangeLoanDepBuySell")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".changeLoanDepBuySell("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_ChangeLoanDepCurrency")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".changeLoanDepCurrency("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_ChangeLoanDepInsType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".changeLoanDepInsType("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetCompOnlyPeriod")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getCompOnlyPeriod("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_AvgRateForAccounting")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".avgRateForAccounting("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_ComputeResults")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".computeResults("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_ComputeResultsByParam")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".computeResultsByParam("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_ConvertPriceToYield")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".convertPriceToYield("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("convertYieldToPrice")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".convertYieldToPrice("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetFloatSpread")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getFloatSpread("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_InsertByStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".insertByStatus("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_InsertByStatusNoRegen")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".insertByStatusNoRegen("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_IsolateLocationTier")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".isolateLocationTier("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_LoadNotnlFromProfile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".loadNotnlFromProfile("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_LoadPhyCfc")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".loadPhyCfc("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_LoadProfileData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".loadProfileData("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_LoadPymtsFromProfile")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".loadPymtsFromProfile("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetMatDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getMatDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetNotnlForSide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getNotnlForSide("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetNumDaysAccrued")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getNumDaysAccrued("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetNumTiersForLocation")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getNumTiersForLocation("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetPriceInputFormat")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getPriceInputFormat("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetProjIndex")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getProjIndex("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetPymtPeriod")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getPymtPeriod("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetRateForSide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getRateForSide("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_GetStartDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".getStartDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_LoadVolFromOption")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".loadVolFromOption("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_PriceToYield")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".priceToYield("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_RegenPartial")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".regenPartial("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SaveProfileNotnlAtDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".saveProfileNotnlAtDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("INS_SetAmortizationTerm")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setAmortizationTerm("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetBook")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setBook("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetCallNoticeSpecifiedDateBalance")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCallNoticeSpecifiedDateBalance("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetCompAndPymtPeriod")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setCompAndPymtPeriod("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetDailyVolume")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDailyVolume("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetDiscIndex")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setDiscIndex("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetExternalBunit")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setExternalBunit("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetExternalLentity")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setExternalLentity("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetExternalPortfolio")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setExternalPortfolio("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetFirstResetOnSide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setFirstResetOnSide("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_SetFixedRate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setFixedRate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetFloatSpd")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setFloatSpd("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetFrontRollDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setFrontRollDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetHeaderTicker")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setHeaderTicker("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetInternalBunit")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setInternalBunit("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetInternalLentity")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setInternalLentity("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetInternalPortfolio")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setInternalPortfolio("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetMatDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setMatDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetNotnl")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setNotnl("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetPeriodVolume")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPeriodVolume("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetPriceAndSave")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPriceAndSave("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetProjIndex")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setProjIndex("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetPymtDateOffset")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPymtDateOffset("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetPymtDateOffsetOnSide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPymtDateOffsetOnSide("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetPymtPeriod")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setPymtPeriod("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetRateOnSide")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setRateOnSide("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetReference")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setReference("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetSettleDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSettleDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetStartDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setStartDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetSymbolicMatDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSymbolicMatDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetSymbolicSettleDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSymbolicSettleDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetSymbolicStartDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setSymbolicStartDate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SetYldBasis")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".setYldBasis("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SolveFloatSpd_DefaultArgs_Wrap")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".solveFloatSpd("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SolveFloatSpd_DefaultArgs_Wrap")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".solveFloatSpd("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SolveRate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".solveRate("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_SolveRateForDeal")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".solveRateForDeal("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_TableToTranScheduleDetail")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".tableToTranScheduleDetail("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_TranScheduleDetailToTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".tranScheduleDetailToTable("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_UpdateBondFutAddUnderlying")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".updateBondFutAddUnderlying("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_UpdateBondFutWithCheapestToDeliver")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".updateBondFutWithCheapestToDeliver("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" INS_YieldToPrice")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".yieldToPrice("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" MATH_CalcIRR")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathCalcIRR("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains(" MATH_CalcIRRN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".mathCalcIRR("
					+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("HGS_DefaultQuantities")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_DefaultQuantities",
						".defaultQuantities");
				returnString = newString.replaceFirst("HGS_DefaultQuantities\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".defaultQuantities()";
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_Free")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_Free", ".free");
				returnString = newString.replaceFirst("HGS_Free\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				temp = newString.substring(newString.indexOf("HGS_Free"), newString.length());
				temp = temp.substring(temp.indexOf("HGS_Free"), temp.indexOf(")") + 1);

				returnString = newString.replace(temp, Replacer.convertindexCall(temp));
				newString = returnString;
			}
		}
		if (newString.contains("HGS_GetCapacityTable")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_GetCapacityTable",
						".getCapacityTable");
				returnString = newString.replaceFirst("HGS_GetCapacityTable\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getCapacityTable("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_GetDealQuantity")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_GetDealQuantity", ".getDealQuantity");
				returnString = newString.replaceFirst("HGS_GetDealQuantity\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getDealQuantity("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_GetFuelDataTable")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_GetFuelDataTable",
						".getFuelDataTable");
				returnString = newString.replaceFirst("HGS_GetFuelDataTable\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				temp = newString.substring(newString.indexOf("HGS_GetFuelDataTable"), newString.length());
				temp = temp.substring(temp.indexOf("HGS_GetFuelDataTable"), temp.indexOf(")") + 1);

				returnString = newString.replace(temp, Replacer.convertindexCall(temp));
				newString = returnString;
			}
		}
		if (newString.contains("HGS_GetImbalanceTable")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_GetImbalanceTable",
						".getImbalanceTable");
				returnString = newString.replaceFirst("HGS_GetImbalanceTable\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getImbalanceTable("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_GetInterconnectQuantity")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_GetInterconnectQuantity",
						".getInterconnectQuantity");
				returnString = newString.replaceFirst("HGS_GetInterconnectQuantity\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".getInterconnectQuantity("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_LoadConfig")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_LoadConfig", ".loadConfig");
				returnString = newString.replaceFirst("HGS_LoadConfig\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".loadConfig("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_Reload")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_Reload", ".reload");
				returnString = newString.replaceFirst("HGS_Reload\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				temp = newString.substring(newString.indexOf("HGS_Reload"), newString.length());
				temp = temp.substring(temp.indexOf("HGS_Reload"), temp.indexOf(")") + 1);

				returnString = newString.replace(temp, Replacer.convertindexCall(temp));
				newString = returnString;
			}
		}

		if (newString.contains("HGS_SetAutoNominate")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetAutoNominate", ".setAutoNominate");
				returnString = newString.replaceFirst("HGS_SetAutoNominate\\([^)]*\\)", replacement);
				newString = returnString;

			} else

			{
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setAutoNominate("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetAutoUpdate")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetAutoUpdate", ".setAutoUpdate");
				returnString = newString.replaceFirst("HGS_SetAutoUpdate\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setAutoUpdate("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetBalancingZone")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetBalancingZone",
						".setBalancingZone");
				returnString = newString.replaceFirst("HGS_SetBalancingZone\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setBalancingZone("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetDealQuantity")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetDealQuantity", ".setDealQuantity");
				returnString = newString.replaceFirst("HGS_SetDealQuantity\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setDealQuantity("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetEndDate")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetEndDate", ".setEndDate");
				returnString = newString.replaceFirst("HGS_SetEndDate\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setEndDate("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetGasDay")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetGasDay", ".setGasDay");
				returnString = newString.replaceFirst("HGS_SetGasDay\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setGasDay("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetInterconnectQuantity")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetInterconnectQuantity",
						".setInterconnectQuantity");
				returnString = newString.replaceFirst("HGS_SetInterconnectQuantity\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setInterconnectQuantity("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetIntLegalEntity")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetIntLegalEntity",
						".setIntLegalEntity");
				returnString = newString.replaceFirst("HGS_SetIntLegalEntity\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setIntLegalEntity("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetRollPriorImbalances")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetInterconnectQuantity",
						".setInterconnectQuantity");
				returnString = newString.replaceFirst("HGS_SetInterconnectQuantity\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setRollPriorImbalances("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetStartDate")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetStartDate", ".setStartDate");
				returnString = newString.replaceFirst("HGS_SetStartDate\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setStartDate("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}
		if (newString.contains("HGS_SetZeroLimits")) {
			if (newString.contains("if") || newString.contains("while")) {
				String replacement = Replacer.convertFunctionCall(newString, "HGS_SetZeroLimits", ".setZeroLimits");
				returnString = newString.replaceFirst("HGS_SetZeroLimits\\([^)]*\\)", replacement);
				newString = returnString;

			} else {
				tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
				tableObjectName = tableObjectName + ".setZeroLimits("
						+ newString.substring(newString.indexOf(",") + 1, newString.length()).trim();
				returnString = tableObjectName;
				newString = tableObjectName;
			}
		}

		if (newString.contains("INS_AmendValidated")) {
			temp = newString.substring(newString.indexOf("INS_AmendValidated"), newString.length());
			temp = temp.substring(temp.indexOf("INS_AmendValidated"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("INS_CalcOtcPaperRateToYield")) {
			temp = newString.substring(newString.indexOf("INS_CalcOtcPaperRateToYield"), newString.length());
			temp = temp.substring(temp.indexOf("INS_CalcOtcPaperRateToYield"), temp.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("INS_ComputeResetCompoundedAmount")) {
			temp = newString.substring(newString.indexOf("INS_ComputeResetCompoundedAmount"), newString.length());
			temp = temp.substring(temp.indexOf("INS_ComputeResetCompoundedAmount"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".computeResetCompoundedAmount()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("INS_Copy")) {
			temp = newString.substring(newString.indexOf("INS_Copy"), newString.length());
			temp = temp.substring(temp.indexOf("INS_Copy"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".copy()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("INS_Destroy")) {
			temp = newString.substring(newString.indexOf("INS_Destroy"), newString.length());
			temp = temp.substring(temp.indexOf("INS_Destroy"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".destroy()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_FixPriorResets")) {
			temp = newString.substring(newString.indexOf("INS_FixPriorResets"), newString.length());
			temp = temp.substring(temp.indexOf("INS_FixPriorResets"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".fixPriorResets()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_FixupInsForReval")) {
			temp = newString.substring(newString.indexOf("INS_FixupInsForReval"), newString.length());
			temp = temp.substring(temp.indexOf("INS_FixupInsForReval"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".fixupInsForReval()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GenerateHistoricalCallNoticeReport")) {
			temp = newString.substring(newString.indexOf("INS_GenerateHistoricalCallNoticeReport"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GenerateHistoricalCallNoticeReport"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".generateHistoricalCallNoticeReport()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetAmortPeriod")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));

			newString = returnString;
		}
		if (newString.contains("INS_GetBook")) {
			temp = newString.substring(newString.indexOf("INS_GetBook"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetBook"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getBook()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_GetDealNum")) {
			temp = newString.substring(newString.indexOf("INS_GetDealNum"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetDealNum"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getDealNum()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetDiscIndex")) {
			temp = newString.substring(newString.indexOf("INS_GetDiscIndex"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetDiscIndex"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getDiscIndex()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;

		}
		if (newString.contains("INS_GetExternalBunit")) {
			temp = newString.substring(newString.indexOf("INS_GetExternalBunit"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetExternalBunit"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getExternalBunit()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetExternalLentity")) {
			temp = newString.substring(newString.indexOf("INS_GetExternalLentity"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetExternalLentity"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getExternalLentity()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetExternalPortfolio")) {
			temp = newString.substring(newString.indexOf("INS_GetExternalPortfolio"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetExternalPortfolio"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getExternalPortfolio()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetFixedFloat")) {
			temp = newString.substring(newString.indexOf("INS_GetFixedFloat"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetFixedFloat"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getFixedFloat()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetFixedRate")) {
			temp = newString.substring(newString.indexOf("INS_GetFixedRate"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetFixedRate"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getFixedRate()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_GetHourlyVolumePricingDetails")) {
			temp = newString.substring(newString.indexOf("INS_GetHourlyVolumePricingDetails"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetHourlyVolumePricingDetails"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getHourlyVolumePricingDetails()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetInputDate")) {
			temp = newString.substring(newString.indexOf("INS_GetInputDate"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetInputDate"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getInputDate()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetInsNum")) {
			temp = newString.substring(newString.indexOf("INS_GetInsNum"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetInsNum"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getInsNum()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetInternalBunit")) {
			temp = newString.substring(newString.indexOf("INS_GetInternalBunit"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetInternalBunit"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getInternalBunit()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetInternalLentity")) {
			temp = newString.substring(newString.indexOf("INS_GetInternalLentity"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetInternalLentity"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getInternalLentity()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetInternalPortfolio")) {
			temp = newString.substring(newString.indexOf("INS_GetInternalPortfolio"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetInternalPortfolio"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getInternalPortfolio()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_GetLocations")) {
			temp = newString.substring(newString.indexOf("INS_GetLocations"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetLocations"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getLocations()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_GetReference")) {
			temp = newString.substring(newString.indexOf("INS_GetReference"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetReference"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getReference()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_GetTranNum")) {
			temp = newString.substring(newString.indexOf("INS_GetTranNum"), newString.length());
			temp = temp.substring(temp.indexOf("INS_GetTranNum"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getTranNum()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_HeaderToTable")) {
			temp = newString.substring(newString.indexOf("INS_HeaderToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_HeaderToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".headerToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_HolidayToTable")) {
			temp = newString.substring(newString.indexOf("INS_HolidayToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_HolidayToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".holidayToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_IasDataToTable")) {
			temp = newString.substring(newString.indexOf("INS_IasDataToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_IasDataToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".iasDataToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_IasVrToTable")) {
			temp = newString.substring(newString.indexOf("INS_IasVrToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_IasVrToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".iasVrToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_InsToTable")) {
			temp = newString.substring(newString.indexOf("INS_InsToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_InsToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".insToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_InsToTableRaw")) {
			temp = newString.substring(newString.indexOf("INS_InsToTableRaw"), newString.length());
			temp = temp.substring(temp.indexOf("INS_InsToTableRaw"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".insToTableRaw()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_LoadResetRollConv")) {
			temp = newString.substring(newString.indexOf("INS_LoadResetRollConv"), newString.length());
			temp = temp.substring(temp.indexOf("INS_LoadResetRollConv"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".loadResetRollConv()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_LogcashToTable")) {
			temp = newString.substring(newString.indexOf("INS_LogcashToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_LogcashToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".logcashToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_MiscInsToTable")) {
			temp = newString.substring(newString.indexOf("INS_MiscInsToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_MiscInsToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".miscInsToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_OffsetUniqueInstrument")) {
			temp = newString.substring(newString.indexOf("INS_OffsetUniqueInstrument"), newString.length());
			temp = temp.substring(temp.indexOf("INS_OffsetUniqueInstrument"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".offsetUniqueInstrument()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_OptionToTable")) {
			temp = newString.substring(newString.indexOf("INS_OptionToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_OptionToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".optionToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_ParamToTable")) {
			temp = newString.substring(newString.indexOf("INS_ParamToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_ParamToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".paramToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_PhyscashToTable")) {
			temp = newString.substring(newString.indexOf("INS_PhyscashToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_PhyscashToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".physcashToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_PrepareForPricing")) {
			temp = newString.substring(newString.indexOf("INS_PrepareForPricing"), newString.length());
			temp = temp.substring(temp.indexOf("INS_PrepareForPricing"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".prepareForPricing()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_PriceBandToTable")) {
			temp = newString.substring(newString.indexOf("INS_PriceBandToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_PriceBandToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".priceBandToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_ProfileToTable")) {
			temp = newString.substring(newString.indexOf("INS_ProfileToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_ProfileToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".profileToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_PwrDailyPricingDetailsToTable")) {
			temp = newString.substring(newString.indexOf("INS_PwrDailyPricingDetailsToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_PwrDailyPricingDetailsToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".pwrDailyPricingDetailsToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_PwrHourlyPricingDetailsToTable")) {
			temp = newString.substring(newString.indexOf("INS_PwrHourlyPricingDetailsToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_PwrHourlyPricingDetailsToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".pwrHourlyPricingDetailsToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_PwrPhysParamToTable")) {
			temp = newString.substring(newString.indexOf("INS_PwrPhysParamToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_PwrPhysParamToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".pwrPhysParamToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_Regen")) {
			temp = newString.substring(newString.indexOf("INS_Regen"), newString.length());
			temp = temp.substring(temp.indexOf("INS_Regen"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".regen()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_RemoveCflowData")) {
			temp = newString.substring(newString.indexOf("INS_RemoveCflowData"), newString.length());
			temp = temp.substring(temp.indexOf("INS_RemoveCflowData"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".removeCflowData()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_ResetHolidayToTable")) {
			temp = newString.substring(newString.indexOf("INS_ResetHolidayToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_ResetHolidayToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".resetHolidayToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_ResetToTable")) {
			temp = newString.substring(newString.indexOf("INS_ResetToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_ResetToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".resetToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains("INS_RevalidateSharedIns")) {
			temp = newString.substring(newString.indexOf("INS_RevalidateSharedIns"), newString.length());
			temp = temp.substring(temp.indexOf("INS_RevalidateSharedIns"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".revalidateSharedIns()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains("INS_SetDefaultSymbolicDates")) {
			temp = newString.substring(newString.indexOf("INS_SetDefaultSymbolicDates"), newString.length());
			temp = temp.substring(temp.indexOf("INS_SetDefaultSymbolicDates"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".setDefaultSymbolicDates()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		if (newString.contains(" INS_TranScheduleToTable")) {
			temp = newString.substring(newString.indexOf("INS_TranScheduleToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_TranScheduleToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".tranScheduleToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}
		if (newString.contains(" INS_TranToTable")) {
			temp = newString.substring(newString.indexOf("INS_TranToTable"), newString.length());
			temp = temp.substring(temp.indexOf("INS_TranToTable"), temp.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".tranToTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "abs", "Math.abs");

		newString = Replacer.simpleReplace(newString, "ACCT_AuthorizeFxRateSetById", "Acct.authorizeFxRateSetById");

		newString = Replacer.simpleReplace(newString, "ACCT_CalculateFxRates", "Acct.calculateFxRates");

		newString = Replacer.simpleReplace(newString, "ACCT_CreatePostingParametersUploadTable",
				"Acct.createPostingParametersUploadTable");

		newString = Replacer.simpleReplace(newString, "ACCT_DefaultCurrencyPairsTable",
				"Acct.defaultCurrencyPairsTable");

		newString = Replacer.simpleReplace(newString, "ACCT_DefineManualEntry", "Acct.defineManualEntry");

		newString = Replacer.simpleReplace(newString, "ACCT_DefineManualEntryR", "Acct.defineManualEntryR");

		newString = Replacer.simpleReplace(newString, "ACCT_DefinePostingParameter", "Acct.definePostingParameter");

		newString = Replacer.simpleReplace(newString, "ACCT_DeleteFasHistoryEntry", "Acct.deleteFasHistoryEntry");

		newString = Replacer.simpleReplace(newString, "ACCT_DelProcessGroup", "Acct.delProcessGroup");

		newString = Replacer.simpleReplace(newString, "ACCT_DisauthorizeFxRateSetById",
				"Acct.disauthorizeFxRateSetById");

		newString = Replacer.simpleReplace(newString, "ACCT_DisplayFxRateMatrixTable", "Acct.displayFxRateMatrixTable");

		newString = Replacer.simpleReplace(newString, "ACCT_ExportFxRateMemapTable", "Acct.exportFxRateMemapTable");

		newString = Replacer.simpleReplace(newString, "ACCT_ExportFxRatePairTable", "Acct.exportFxRatePairTable");

		newString = Replacer.simpleReplace(newString, "ACCT_ExportFxRateSetTable", "Acct.exportFxRateSetTable");

		newString = Replacer.simpleReplace(newString, "ACCT_ExportHistoricFxRateTable",
				"Acct.exportHistoricFxRateTable");

		newString = Replacer.simpleReplace(newString, "ACCT_ForceReverseIncrementalEntry",
				"Acct.forceReverseIncrementalEntry");

		newString = Replacer.simpleReplace(newString, "ACCT_GetFxRateSetIdByName", "Acct.getFxRateSetIdByName");

		newString = Replacer.simpleReplace(newString, "ACCT_GetFxRateSetNameById", "Acct.getFxRateSetNameById");

		newString = Replacer.simpleReplace(newString, "ACCT_GetSimForDate", "Acct.getSimForDate");

		newString = Replacer.simpleReplace(newString, "ACCT_GetSystemBaseCurrency", "Acct.getSystemBaseCurrencyId");

		newString = Replacer.simpleReplace(newString, "ACCT_GetSystemBaseCurrencyN", "Acct.getSystemBaseCurrencyName");

		newString = Replacer.simpleReplace(newString, "ACCT_ImportFxRateMemap", "Acct.importFxRateMemap");

		newString = Replacer.simpleReplace(newString, "ACCT_ImportFxRatePairTable", "Acct.importFxRatePairTable");

		newString = Replacer.simpleReplace(newString, "ACCT_ImportFxRateSetTable", "Acct.importFxRateSetTable");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertAcctBalanceHistory", "Acct.insertAcctBalanceHistory");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertFasHistory", "Acct.insertFasHistory");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertPostingParamInfo", "Acct.insertPostingParamInfo");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertPostingParamInfoTypes",
				"Acct.insertPostingParamInfoTypes");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertPPSEntriesTable", "Acct.insertPPSEntriesTable");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertPPSEntry", "Acct.insertPPSEntry");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertProcessGroup", "Acct.insertProcessGroup");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertSubledgerInfo", "Acct.insertSubledgerInfo");

		newString = Replacer.simpleReplace(newString, "ACCT_InsertSubledgerInfo", "Acct.insertSubledgerInfoTypes");

		newString = Replacer.simpleReplace(newString, "ACCT_LockFxRates", "Acct.lockFxRates");

		newString = Replacer.simpleReplace(newString, "ACCT_ModifyFasHistoryEntry", "Acct.modifyFasHistoryEntry");

		newString = Replacer.simpleReplace(newString, "ACCT_MoveManEntryStatus", "Acct.moveManEntryStatus");

		newString = Replacer.simpleReplace(newString, "ACCT_MoveManEntryStatus", "Acct.moveManEntryStatus");

		newString = Replacer.simpleReplace(newString, "ACCT_NewFxRatePairTable", "Acct.newFxRatePairTable");

		newString = Replacer.simpleReplace(newString, "ACCT_NewFxRateSetCcyTable", "Acct.newFxRateSetCcyTable");

		newString = Replacer.simpleReplace(newString, "ACCT_NewFxRateSetTable", "Acct.newFxRateSetTable");

		newString = Replacer.simpleReplace(newString, "ACCT_PostManualEntries", "Acct.postManualEntries");

		newString = Replacer.simpleReplace(newString, "ACCT_PostManualEntriesForDate", "Acct.postManualEntriesForDate");

		newString = Replacer.simpleReplace(newString, "ACCT_PostManualEntriesForDate", "Acct.postManualEntriesForDate");

		newString = Replacer.simpleReplace(newString, "ACCT_RecastBalanceHistory", "Acct.recastBalanceHistory");

		newString = Replacer.simpleReplace(newString, "ACCT_RecastBalanceHistory", "Acct.recastBalanceHistory");

		newString = Replacer.simpleReplace(newString, "ACCT_RemoveOrphanedPPSEntries", "Acct.removeOrphanedPPSEntries");

		newString = Replacer.simpleReplace(newString, "ACCT_ReverseFasHistory", "Acct.reverseFasHistory");

		newString = Replacer.simpleReplace(newString, "ACCT_SwitchEvent_Criteria", "Acct.switchEventCriteria");

		newString = Replacer.simpleReplace(newString, "ACCT_SwitchEvent_Criteria", "Acct.switchEventCriteria");

		newString = Replacer.simpleReplace(newString, "ACCT_UnlockFxRates", "Acct.unlockFxRates");

		newString = Replacer.simpleReplace(newString, "ACCT_UpdateFasHistoryProcessFlag",
				"Acct.updateFasHistoryProcessFlag");

		newString = Replacer.simpleReplace(newString, "ACCT_UpdatePPSEntryTable", "Acct.updatePPSEntryTable");

		newString = Replacer.simpleReplace(newString, "ACCT_UpdatePPSSentToGL", "Acct.updatePPSSentToGL");

		newString = Replacer.simpleReplace(newString, "ACCT_UploadFxRates", "Acct.uploadFxRates");

		newString = Replacer.simpleReplace(newString, "ACCT_UploadPostingParameters", "Acct.uploadPostingParameters");

		newString = Replacer.simpleReplace(newString, "AFE_CreateServiceRequestArgTable",
				"Afe.createServiceRequestArgTable");

		newString = Replacer.simpleReplace(newString, "AFE_IssueServiceRequestByID", "Afe.issueServiceRequestByID");

		newString = Replacer.simpleReplace(newString, "AFE_IssueServiceRequestByName", "Afe.issueServiceRequestByName");

		newString = Replacer.simpleReplace(newString, "AFE_IssueServiceRequestWithTableArg",
				"Afe.issueServiceRequestWithTableArg");

		newString = Replacer.simpleReplace(newString, "AFS_CopyAllUserFiles", "Afe.copyAllUserFiles");

		newString = Replacer.simpleReplace(newString, "AFS_CreateLink", "Afe.createLink");

		newString = Replacer.simpleReplace(newString, "AFS_DeleteAllUserFiles", "Afe.deleteAllUserFiles");

		newString = Replacer.simpleReplace(newString, "AFS_DeleteFileNames", "Afe.deleteFileNames");

		newString = Replacer.simpleReplace(newString, "AFS_DeleteTable", "Afe.deleteTable");

		newString = Replacer.simpleReplace(newString, "AFS_DeleteUserFile", "Afe.deleteUserFile");

		newString = Replacer.simpleReplace(newString, "AFS_RetrieveTable", "Afe.retrieveTable");

		newString = Replacer.simpleReplace(newString, "AFS_SaveTable", "Afe.saveTable");

		newString = Replacer.simpleReplace(newString, "ALERT_ChangeStatusAlert", "Broadcast.alertChangeStatusAlert");

		newString = Replacer.simpleReplace(newString, "ALERT_CloseForAllAlert", "Broadcast.alertCloseForAllAlert");

		newString = Replacer.simpleReplace(newString, "ALERT_CreateNewAlert", "Broadcast.alertCreateNewAlert");

		newString = Replacer.simpleReplace(newString, "ALERT_GetReceiverGroups", "Broadcast.alertGetReceiverGroups");

		newString = Replacer.simpleReplace(newString, "ALERT_GetReceivers", "Broadcast.alertGetReceivers");

		newString = Replacer.simpleReplace(newString, "ALERT_GetReceivers", "Broadcast.alertGetReceivers");

		newString = Replacer.simpleReplace(newString, "ALERT_ProcessPendingAlerts",
				"Broadcast.alertProcessPendingAlerts");

		newString = Replacer.simpleReplace(newString, "ANE_GetNextMessage", "Ane.getNextMessage");

		newString = Replacer.simpleReplace(newString, "ANE_ProcessNextMessage", "Ane.processNextMessage");

		newString = Replacer.simpleReplace(newString, "ANE_PruneMessageQueue", "Ane.pruneMessageQueue");

		newString = Replacer.simpleReplace(newString, "ARCHIVE_ArchiveDB", "DataMaint.archiveDB");

		newString = Replacer.simpleReplace(newString, "ARCHIVE_IsOperationValid", "DataMaint.isOperationValid");

		newString = Replacer.simpleReplace(newString, "STR_Concat", "Str.concat");

		newString = Replacer.simpleReplace(newString, "STR_Copy", "Str.copy");

		newString = Replacer.simpleReplace(newString, "STR_Count", "Str.count");

		newString = Replacer.simpleReplace(newString, "STR_DoubleToStr", "Str.doubleToStr");

		newString = Replacer.simpleReplace(newString, "STR_Field", "Str.field");

		newString = Replacer.simpleReplace(newString, "STR_IsNull", "Str.isNull");

		newString = Replacer.simpleReplace(newString, "STR_FormatAs128th", "Str.formatAs128th");

		newString = Replacer.simpleReplace(newString, "STR_FormatAs64th", "Str.formatAs64th");

		newString = Replacer.simpleReplace(newString, "STR_FormatAs32nd", "Str.formatAs32nd");

		newString = Replacer.simpleReplace(newString, "STR_FindLastSubString", "Str.findLastSubString");

		newString = Replacer.simpleReplace(newString, "STR_FixSqlStr", "DBase.fixSqlStr");

		newString = Replacer.simpleReplace(newString, "Xstring_Append", "Str.xstringAppend");

		newString = Replacer.simpleReplace(newString, "Xstring_Destroy", "Str.xstringDestroy");

		newString = Replacer.simpleReplace(newString, "Xstring_GetString", "Str.xstringGetString");

		newString = Replacer.simpleReplace(newString, "Xstring_New", "Str.xstringNew");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsBps", "Str.formatAsBps");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsDouble", "Str.formatAsDouble");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsNotnl", "Str.formatAsNotnl");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsNotnlAcct", "Str.formatAsNotnlAcct");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsNotnlCcy", "Str.formatAsNotnlCcy");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsPercent", "Str.formatAsPercent");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsPymtPeriod", "Str.formatAsPymtPeriod");

		newString = Replacer.simpleReplace(newString, "STR_FormatAsRate", "Str.formatAsRate");

		newString = Replacer.simpleReplace(newString, "STR_InputAs128th", "Str.inputAs128th");

		newString = Replacer.simpleReplace(newString, "STR_InputAs64th", "Str.inputAs64th");

		newString = Replacer.simpleReplace(newString, "STR_InputAs32nd", "Str.inputAs32nd");

		newString = Replacer.simpleReplace(newString, "STR_InputAsBps", "Str.inputAsBps");

		newString = Replacer.simpleReplace(newString, "STR_InputAsDouble", "Str.inputAsDouble");

		newString = Replacer.simpleReplace(newString, "STR_InputAsNotnl", "Str.inputAsNotnl");

		newString = Replacer.simpleReplace(newString, "STR_InputAsPymtPeriod", "Str.inputAsPymtPeriod");

		newString = Replacer.simpleReplace(newString, "STR_InputAsRate", "Str.inputAsRate");

		newString = Replacer.simpleReplace(newString, "STR_IsDouble", "Str.isDouble");

		newString = Replacer.simpleReplace(newString, "STR_New", "Str.strNew");

		newString = Replacer.simpleReplace(newString, "STR_PureString", "Str.pureString");

		newString = Replacer.simpleReplace(newString, "STR_ReadFromFile", "Str.readFromFile");

		newString = Replacer.simpleReplace(newString, "STR_StrDateTimeToDate", "ODateTime.strDateTimeToDate");

		newString = Replacer.simpleReplace(newString, "STR_StrDateTimeToTime", "ODateTime.strDateTimeToTime");

		if (newString.contains("STR_ToUpper")) {
			temp = newString.substring(newString.indexOf("STR_ToUpper"), newString.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".toUpperCase()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "STR_StrToDouble", "Str.strToDouble");

		newString = Replacer.simpleReplace(newString, "NOM_AllocateMeasurementVolumes",
				"GasScheduling.allocateMeasurementVolumes");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddICDeliveryRow", "NomCreate.addICDeliveryRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddICReceiptRow", "NomCreate.addICReceiptRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddInventoryDeliveryRow",
				"NomCreate.addInventoryDeliveryRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddInventoryReceiptRow",
				"NomCreate.addInventoryReceiptRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddPSIDeliveryRow", "NomCreate.addPSIDeliveryRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddPSIReceiptRow", "NomCreate.addPSIReceiptRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddPurchaseRow", "NomCreate.addPurchaseRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddSaleRow", "NomCreate.addSaleRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddTransitDeliveryRow",
				"NomCreate.addTransitDeliveryRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAddTransitReceiptRow",
				"NomCreate.addTransitReceiptRow");

		newString = Replacer.simpleReplace(newString, "NOM_BookingAttachPathingTable", "NomCreate.attachPathingTable");

		newString = Replacer.simpleReplace(newString, "NOM_BookingCreateCommSchedData",
				"NomCreate.createCommSchedData");

		newString = Replacer.simpleReplace(newString, "NOM_BookingCreateData", "NomCreate.createData");

		newString = Replacer.simpleReplace(newString, "NOM_BookingDestroyData", "NomCreate.Destroy");

		newString = Replacer.simpleReplace(newString, "NOM_BookingSetDealGrouping", "NomCreate.setDealGrouping");

		newString = Replacer.simpleReplace(newString, "NOM_Create", "Nomination.create");

		if (newString.contains("NOM_Copy")) {

			tableObjectName = newString.substring(newString.indexOf("NOM_Copy"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_Copy"), tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("NOM_Destroy")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_Destroy"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_Destroy"), tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".destroy()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("NOM_Duplicate")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_Duplicate"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_Duplicate"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".duplicate()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("NOM_GetCurrentPath")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_GetCurrentPath"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_GetCurrentPath"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("NOM_GetCurrentPathForDecrease")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_GetCurrentPathForDecrease"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_GetCurrentPathForDecrease"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		newString = Replacer.simpleReplace(newString, "NOM_GetNumNoms", "Nomination.getNumNoms");

		newString = Replacer.simpleReplace(newString, "NOM_GetNumTrans", "Nomination.getNumTrans");
		if (newString.contains("NOM_GetOldPath")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_GetOldPath"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_GetOldPath"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("NOM_Process")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_Process"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_Process"), tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("NOM_ProcessDescribe")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_ProcessDescribe"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_ProcessDescribe"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		newString = Replacer.simpleReplace(newString, "NOM_Query", "NomCreate.NOM_Query");
		if (newString.contains("NOM_Rates")) {
			tableObjectName = newString.substring(newString.indexOf("NOM_Rates"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_Rates"), tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getRates()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("NOM_RatesWithTable")) {

			tableObjectName = newString.substring(newString.indexOf("NOM_RatesWithTable"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("NOM_RatesWithTable"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("VAR_AddIndexMapToVaRDef")) {

			tableObjectName = newString.substring(newString.indexOf("VAR_AddIndexMapToVaRDef"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_AddIndexMapToVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_AddIndexToVaRDef")) {

			tableObjectName = newString.substring(newString.indexOf("VAR_AddIndexToVaRDef"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_AddIndexToVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_AddVolatilityMapToVaRDef")) {

			tableObjectName = newString.substring(newString.indexOf("VAR_AddVolatilityMapToVaRDef"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_AddVolatilityMapToVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_AddVolatilityToVaRDef")) {

			tableObjectName = newString.substring(newString.indexOf("VAR_AddVolatilityToVaRDef"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_AddVolatilityToVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("VAR_CopyVaRDef")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_CopyVaRDef"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_CopyVaRDef"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".copyVaRDef()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("VAR_GetVaRDefCorrelations")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_GetVaRDefCorrelations"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_GetVaRDefCorrelations"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getVaRDefCorrelations()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_GetVaRDefID")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_GetVaRDefID"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_GetVaRDefID"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getVaRDefID()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_GetVaRDefIndexDatasets")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_GetVaRDefIndexDatasets"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_GetVaRDefIndexDatasets"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getVaRDefIndexDatasets()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_GetVaRDefIndexMappings")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_GetVaRDefIndexMappings"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_GetVaRDefIndexMappings"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getVaRDefIndexMappings()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_GetVaRDefName")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_GetVaRDefName"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_GetVaRDefName"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getVaRDefName()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_GetVaRDefVolatilityDatasets")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_GetVaRDefVolatilityDatasets"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_GetVaRDefVolatilityDatasets"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getVaRDefVolatilityDatasets()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_GetVaRDefVolatilityMappings")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_GetVaRDefVolatilityMappings"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_GetVaRDefVolatilityMappings"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".getVaRDefVolatilityMappings()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ReleaseVaRDef")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_ReleaseVaRDef"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_ReleaseVaRDef"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".releaseVaRDef()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("NOM_Retrieve")) {
			tableObjectName = newString.replace("NOM_Retrieve", "Nomination.retrieve");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("NOM_RetrieveByQid")) {
			tableObjectName = newString.replace("NOM_RetrieveByQid", "Nomination.retrieveByQid");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("NOM_UpdateUnpathedNomImbalance")) {
			tableObjectName = newString.replace("NOM_UpdateUnpathedNomImbalance",
					"GasScheduling.updateUnpathedNomImbalance");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeDeltaVaR")) {
			tableObjectName = newString.replace("VAR_ComputeDeltaVaR", "ValueAtRisk.computeDeltaVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeGptVaR")) {
			tableObjectName = newString.replace("VAR_ComputeGptVaR", "ValueAtRisk.computeGptVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeIndexAndVolatilityGptVaR")) {
			tableObjectName = newString.replace("VAR_ComputeIndexAndVolatilityGptVaR",
					"ValueAtRisk.computeIndexAndVolatilityGptVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeIndexAndVolatilityVaR")) {
			tableObjectName = newString.replace("VAR_ComputeIndexAndVolatilityVaR",
					"ValueAtRisk.computeIndexAndVolatilityVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeIndexGptVaR")) {
			tableObjectName = newString.replace("VAR_ComputeIndexGptVaR", "ValueAtRisk.computeIndexGptVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("VAR_ComputeIndexVaR")) {
			tableObjectName = newString.replace("VAR_ComputeIndexVaR", "ValueAtRisk.computeIndexVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeVaR")) {
			tableObjectName = newString.replace("VAR_ComputeVaR", "ValueAtRisk.computeVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeVegaVaR")) {
			tableObjectName = newString.replace("VAR_ComputeVegaVaR", "ValueAtRisk.computeVegaVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeVolatilityGptVaR")) {
			tableObjectName = newString.replace("VAR_ComputeVolatilityGptVaR", "ValueAtRisk.computeVolatilityGptVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ComputeVolatilityVaR")) {
			tableObjectName = newString.replace("VAR_ComputeVolatilityVaR", "ValueAtRisk.computeVolatilityVaR");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_DecomposeCorrelationMatrix")) {
			tableObjectName = newString.replace("VAR_DecomposeCorrelationMatrix",
					"ValueAtRisk.decomposeCorrelationMatrix");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ExportVaRDefs")) {
			tableObjectName = newString.replace("VAR_ExportVaRDefs", "ValueAtRisk.exportVaRDefs");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_GetShockVectorForTrial")) {
			tableObjectName = newString.replace("VAR_GetShockVectorForTrial", "ValueAtRisk.getShockVectorForTrial");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_ImportVaRDefs")) {
			tableObjectName = newString.replace("VAR_ImportVaRDefs", "ValueAtRisk.importVaRDefs");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_LoadVaRDef")) {
			tableObjectName = newString.replace("VAR_LoadVaRDef", "ValueAtRisk.loadVaRDef");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("VAR_NewVaRDef")) {
			tableObjectName = newString.replace("VAR_NewVaRDef", "ValueAtRisk.newVaRDef");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("VOL_AddOptimizationIns")) {
			tableObjectName = newString.replace("VOL_AddOptimizationIns", "Volatility.addOptimizationIns");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_AddOptimizationIns", "Volatility.addOptimizationIns");

		if (newString.contains("VOL_CalcCor")) {
			tableObjectName = newString.replace("VOL_CalcCor", "Volatility.calcCor");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_CalcCor", "Volatility.calcCor");

		if (newString.contains("VOL_CalcVol")) {
			tableObjectName = newString.replace("VOL_CalcVol", "Volatility.calcVol");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_CalcVol", "Volatility.calcVol");

		if (newString.contains("VOL_CalibrateBlackScholesVolatilities")) {
			tableObjectName = newString.replace("VOL_CalibrateBlackScholesVolatilities",
					"Volatility.calibrateBlackScholesVolatilities");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_CalibrateBlackScholesVolatilities",
				"Volatility.calibrateBlackScholesVolatilities");

		if (newString.contains("VOL_CalibrateBlackScholesVolatilitiesFromTable")) {
			tableObjectName = newString.replace("VOL_CalibrateBlackScholesVolatilitiesFromTable",
					"Volatility.calibrateBlackScholesVolatilitiesFromTable");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_CalibrateBlackScholesVolatilitiesFromTable",
				"Volatility.calibrateBlackScholesVolatilitiesFromTable");

		if (newString.contains("VOL_CreateOptimizationTable")) {
			tableObjectName = newString.replace("VOL_CreateOptimizationTable", "Volatility.createOptimizationTable");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_CreateOptimizationTable",
				"Volatility.createOptimizationTable");

		if (newString.contains("VOL_DefaultKeysTableForVol")) {
			tableObjectName = newString.replace("VOL_DefaultKeysTableForVol", "Volatility.defaultKeysTableForVol");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_DefaultKeysTableForVol",
				"Volatility.defaultKeysTableForVol");

		if (newString.contains("VOL_ExportVolCorData")) {
			tableObjectName = newString.replace("VOL_ExportVolCorData", "Volatility.exportVolCorData");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_ExportVolCorData", "Volatility.exportVolCorData");

		if (newString.contains("VOL_ExportVolCorDefs")) {
			tableObjectName = newString.replace("VOL_ExportVolCorDefs", "Volatility.exportVolCorDefs");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_ExportVolCorDefs", "Volatility.exportVolCorDefs");

		if (newString.contains("VOL_GetCorData")) {
			tableObjectName = newString.replace("VOL_GetCorData", "Volatility.getCorData");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_GetCorData", "Volatility.getCorData");

		if (newString.contains("VOL_GetVolData")) {
			tableObjectName = newString.replace("VOL_GetVolData", "Volatility.getVolData");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_GetVolData", "Volatility.getVolData");

		if (newString.contains("VOL_ImportVolCorData")) {
			tableObjectName = newString.replace("VOL_ImportVolCorData", "Volatility.importVolCorData");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_ImportVolCorData", "Volatility.importVolCorData");

		if (newString.contains("VOL_ImportVolCorDefs")) {
			tableObjectName = newString.replace("VOL_ImportVolCorDefs", "Volatility.importVolCorDefs");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		newString = Replacer.simpleReplace(newString, "VOL_ImportVolCorDefs", "Volatility.importVolCorDefs");

		if (newString.contains("VOL_ListAllCorrelations")) {
			tableObjectName = newString.replace("VOL_ListAllCorrelations", "Volatility.listAllCorrelations");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_ListAllCorrelations", "Volatility.listAllCorrelations");

		if (newString.contains("VOL_ListAllVolShadows")) {
			tableObjectName = newString.replace("VOL_ListAllVolShadows", "Volatility.listAllVolShadows");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_ListAllVolShadows", "Volatility.listAllVolShadows");

		if (newString.contains("VOL_LoadClose")) {
			tableObjectName = newString.replace("VOL_LoadClose", "Volatility.loadClose");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_LoadClose", "Volatility.loadClose");

		if (newString.contains("VOL_LoadCloseCorsForIndexes")) {
			tableObjectName = newString.replace("VOL_LoadCloseCorsForIndexes", "Volatility.loadCloseCorsForIndexes");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_LoadCloseCorsForIndexes",
				"Volatility.loadCloseCorsForIndexes");

		if (newString.contains("VOL_LoadCloseVolsForIndexes")) {
			tableObjectName = newString.replace("VOL_LoadCloseVolsForIndexes", "Volatility.loadCloseVolsForIndexes");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_LoadCloseVolsForIndexes",
				"Volatility.loadCloseVolsForIndexes");

		if (newString.contains("VOL_LoadCorClose")) {
			tableObjectName = newString.replace("VOL_LoadCorClose", "Volatility.loadCorClose");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_LoadCorClose", "Volatility.loadCorClose");

		if (newString.contains("VOL_LoadCorUniversal")) {
			tableObjectName = newString.replace("VOL_LoadCorUniversal", "Volatility.loadCorUniversal");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_LoadCorUniversal", "Volatility.loadCorUniversal");

		if (newString.contains("VOL_LoadUniversal")) {
			tableObjectName = newString.replace("VOL_LoadUniversal", "Volatility.loadUniversal");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_LoadUniversal", "Volatility.loadUniversal");

		if (newString.contains("VOL_LoadUniversalCorsForIndexes")) {
			tableObjectName = newString.replace("VOL_LoadUniversalCorsForIndexes",
					"Volatility.loadUniversalCorsForIndexes");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_LoadUniversalCorsForIndexes",
				"Volatility.loadUniversalCorsForIndexes");

		if (newString.contains("VOL_LoadUniversalVolsForIndexes")) {
			tableObjectName = newString.replace("VOL_LoadUniversalVolsForIndexes",
					"Volatility.loadUniversalVolsForIndexes");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		newString = Replacer.simpleReplace(newString, "VOL_LoadUniversalVolsForIndexes",
				"Volatility.loadUniversalVolsForIndexes");

		if (newString.contains("VOL_OptimizeParam")) {
			tableObjectName = newString.replace("VOL_OptimizeParam", "Volatility.optimizeParam");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_OptimizeParam", "Volatility.optimizeParam");

		if (newString.contains("VOL_OptimizeParamFixedAlpha")) {
			tableObjectName = newString.replace("VOL_OptimizeParamFixedAlpha", "Volatility.optimizeParamFixedAlpha");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_OptimizeParamFixedAlpha",
				"Volatility.optimizeParamFixedAlpha");

		if (newString.contains("VOL_OutputTableForVol")) {
			tableObjectName = newString.replace("VOL_OutputTableForVol", "Volatility.outputTableForVol");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_OutputTableForVol", "Volatility.outputTableForVol");

		if (newString.contains("VOL_RemoveBidOfferData")) {
			tableObjectName = newString.replace("VOL_RemoveBidOfferData", "Volatility.removeBidOfferData");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		newString = Replacer.simpleReplace(newString, "VOL_RemoveBidOfferData", "Volatility.removeBidOfferData");

		if (newString.contains("VOL_Rename")) {
			tableObjectName = newString.replace("VOL_Rename", "Volatility.rename");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_Rename", "Volatility.rename");

		if (newString.contains("VOL_SaveClose")) {
			tableObjectName = newString.replace("VOL_SaveClose", "Volatility.saveClose");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		newString = Replacer.simpleReplace(newString, "VOL_SaveClose", "Volatility.saveClose");

		if (newString.contains("VOL_SaveCorClose")) {
			tableObjectName = newString.replace("VOL_SaveCorClose", "Volatility.saveCorClose");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_SaveCorClose", "Volatility.saveCorClose");

		if (newString.contains("VOL_SaveCorUniversal")) {
			tableObjectName = newString.replace("VOL_SaveCorUniversal", "Volatility.saveCorUniversal");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_SaveCorUniversal", "Volatility.saveCorUniversal");

		if (newString.contains("VOL_SaveUniversal")) {
			tableObjectName = newString.replace("VOL_SaveUniversal", "Volatility.saveUniversal");
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		newString = Replacer.simpleReplace(newString, "VOL_SaveUniversal", "Volatility.saveUniversal");

		if (newString.contains("VOL_UpdateCorData")) {
			tableObjectName = newString.replace("VOL_UpdateCorData", "Volatility.updateCorData");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "VOL_UpdateCorData", "Volatility.updateCorData");

		if (newString.contains("VOL_UpdateVolData")) {
			tableObjectName = newString.replace("VOL_UpdateVolData", "Volatility.updateVolData");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("ETAG_Clear")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".clear();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "NOM_RatePPACheck", "Rate.checkPPA");

		newString = Replacer.simpleReplace(newString, "NOM_GetNom", "Nomination.getNom");

		newString = Replacer.simpleReplace(newString, "NOM_GetTran", "Nomination.getTran");

		newString = Replacer.simpleReplace(newString, "NOM_PositionExpandDailyVolume", "NomPosition.expandDailyVolume");

		newString = Replacer.simpleReplace(newString, "NOM_PositionExpandHourlyVolume",
				"NomPosition.positionExpandHourlyVolume");

		newString = Replacer.simpleReplace(newString, "NOM_PositionPageTruncateArrays", "NomPosition.truncateArrays");

		newString = Replacer.simpleReplace(newString, "VOL_UpdateVolData", "Volatility.updateVolData");

		newString = Replacer.simpleReplace(newString, "WFLOW_GetExecutionLog", "Workflow.getExecutionLog");

		newString = Replacer.simpleReplace(newString, "WFLOW_GetStatus", "Workflow.getStatus");

		newString = Replacer.simpleReplace(newString, "WFLOW_GetStatusAll", "Workflow.getStatusAll");

		newString = Replacer.simpleReplace(newString, "WFLOW_PingRunSite", "Workflow.pingRunSite");

		newString = Replacer.simpleReplace(newString, "WFLOW_StartWorkflow", "Workflow.startWorkflow");

		newString = Replacer.simpleReplace(newString, "WFLOW_StopWorkflow", "Workflow.stopWorkflow");

		newString = Replacer.simpleReplace(newString, "verify_error_log_table", "Transaction.verifyerrorLogTable");

		newString = Replacer.simpleReplace(newString, "VERSION_Compare", "Util.versionCompare");

		newString = Replacer.simpleReplace(newString, "UTIL_GetEnergyConversionFactors",
				"Transaction.utilGetEnergyConversionFactors");

		newString = Replacer.simpleReplace(newString, "UTIL_GetHourlyEnergyConversionFactors",
				"Transaction.utilGetHourlyEnergyConversionFactors");

		newString = Replacer.simpleReplace(newString, "UTIL_GetHeatRateConversionFactors",
				"Util.utilGetHeatRateConversionFactors");

		newString = Replacer.simpleReplace(newString, "UTIL_GetHourlyHeatRateConversionFactors",
				"Util.utilGetHourlyHeatRateConversionFactors");

		newString = Replacer.simpleReplace(newString, "UTIL_GetUnitTypeFromUnit", "Util.utilGetUnitTypeFromUnit");

		newString = Replacer.simpleReplace(newString, "UTIL_LicenseReview", "Util.utilLicenseReview");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshCache", "Util.utilRefreshCache");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshClientPickListCache",
				"Util.utilRefreshClientPickListCache");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshIndexCache", "Util.utilRefreshIndexCache");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshIndexDataCache", "Util.utilRefreshIndexDataCache");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshSharedMemoryGlobally",
				"Util.utilRefreshSharedMemoryGlobally");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshSharedMemoryLocally",
				"Util.utilRefreshSharedMemoryLocally");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshSharedMemorySynchronously",
				"Util.utilRefreshSharedMemorySynchronously");

		newString = Replacer.simpleReplace(newString, "UTIL_RefreshVolatilityCache", "Util.utilRefreshVolatilityCache");

		newString = Replacer.simpleReplace(newString, "UTIL_SaveEnergyConversionFactors",
				"Transaction.utilSaveEnergyConversionFactors");

		newString = Replacer.simpleReplace(newString, "USER_CACHE_Clear", "UserCache.clear");

		newString = Replacer.simpleReplace(newString, "USER_CACHE_Get", "UserCache.get");

		newString = Replacer.simpleReplace(newString, "USER_CACHE_SetError", "UserCache.setError");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_FillProperties",
				"Ref.userDATAWORKSHEETFillProperties");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetAuxiliaryData",
				"Ref.userDATAWORKSHEETGetAuxiliaryData");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetCallbackAction",
				"Ref.userDATAWORKSHEETGetCallbackAction");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetCallbackCol",
				"Ref.userDATAWORKSHEETGetCallbackCol");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetCallbackEvent",
				"Ref.userDATAWORKSHEETGetCallbackEvent");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetCallbackRow",
				"Ref.userDATAWORKSHEETGetCallbackRow");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetColKey",
				"Ref.userDATAWORKSHEETGetColKey");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetColReadOnly",
				"Ref.userDATAWORKSHEETGetColReadOnly");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetData", "Ref.userDATAWORKSHEETGetData");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetDefinitionName",
				"Ref.userDATAWORKSHEETGetDefinitionName");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetProperties",
				"Ref.userDATAWORKSHEETGetProperties");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_GetUserTableName",
				"Ref.userDATAWORKSHEETGetUserTableName");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_InitGlobalProperties",
				"Ref.userDATAWORKSHEETInitGlobalProperties");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_InitProperties",
				"Ref.userDATAWORKSHEETInitProperties");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_RemoveStateColumns",
				"Ref.userDATAWORKSHEETRemoveStateColumns");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SaveUserTable",
				"Ref.userDATAWORKSHEETSaveUserTable");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetAllTables",
				"Ref.userDATAWORKSHEETSetAllTables");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetAreaForExtraButtons",
				"Ref.userDATAWORKSHEETSetAreaForExtraButtons");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetColFormattedString",
				"Ref.userDATAWORKSHEETSetColFormattedString");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetColKey",
				"Ref.userDATAWORKSHEETSetColKey");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetColReadOnly",
				"Ref.userDATAWORKSHEETSetColReadOnly");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetDataAndProperties",
				"Ref.userDATAWORKSHEETSetDataAndProperties");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetDisableAddRow",
				"Ref.userDATAWORKSHEETSetDisableAddRow");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetDisableDelRow",
				"Ref.userDATAWORKSHEETSetDisableDelRow");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetDisableReload",
				"Ref.userDATAWORKSHEETSetDisableReload");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetDisableSave",
				"Ref.userDATAWORKSHEETSetDisableSave");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetPicklistValues",
				"Ref.userDATAWORKSHEETSetDisableAddRow");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetRefreshDataTable",
				"Ref.userDATAWORKSHEETSetRefreshDataTable");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetRowInserted",
				"Ref.userDATAWORKSHEETSetRowInserted");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetRowUpdated",
				"Ref.userDATAWORKSHEETSetRowUpdated");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_SetWindowTitle",
				"Ref.userDATAWORKSHEETSetWindowTitle");

		newString = Replacer.simpleReplace(newString, "USER_DATA_WORKSHEET_ViewTransaction",
				"Ref.userDATAWORKSHEETViewTransaction");

		newString = Replacer.simpleReplace(newString, "UserCanAccess", "Util.userCanAccess");

		newString = Replacer.simpleReplace(newString, "unit_conversion_factor", "Util.unitconversionFactor");

		newString = Replacer.simpleReplace(newString, "UnlinkDealFromComposer", "Transaction.unlinkDealFromComposer");

		newString = Replacer.simpleReplace(newString, "UPDATE_Browser", "Query.updateBrowser");

		newString = Replacer.simpleReplace(newString, "UPDATE_CreateTableFromBrowser",
				"Query.updateCreateTableFromBrowser");

		newString = Replacer.simpleReplace(newString, "UPDATE_CreateTableFromQuery",
				"Query.updateCreateTableFromQuery");

		newString = Replacer.simpleReplace(newString, "UPGRADE_Abs", "Upgrades.abs");

		newString = Replacer.simpleReplace(newString, "UPGRADE_AcctEntriesHeaderUniqIndexString",
				"Upgrades.acctEntriesHeaderUniqIndexString");

		newString = Replacer.simpleReplace(newString, "UPGRADE_AddBAVFlagsToTranScheduleDetailsForOldDeals",
				"Upgrades.addBAVFlagsToTranScheduleDetailsForOldDeals");

		newString = Replacer.simpleReplace(newString, "UPGRADE_AddFuelToCommScheduleDeliveryAndCommScheduleHeader",
				"Upgrades.addFuelToCommScheduleDeliveryAndCommScheduleHeader");

		newString = Replacer.simpleReplace(newString, "UPGRADE_AddScheduleDeliveryDetailForScheduleDelivery",
				"Upgrades.addScheduleDeliveryDetailForScheduleDelivery");

		newString = Replacer.simpleReplace(newString, "UPGRADE_AvsScriptDetailToClob",
				"Upgrades.avsScriptDetailToClob");

		newString = Replacer.simpleReplace(newString, "UPGRADE_BlobTranScheduleDetails",
				"Upgrades.blobTranScheduleDetails");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertABSInstruments",
				"Upgrades.convertABSInstruments");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertFXPairs", "Upgrades.convertFXPairs");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertGasPhysTlinkDetail",
				"Upgrades.convertGasPhysTlinkDetail");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertRemainingInstruments",
				"Upgrades.convertRemainingInstruments");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertToParentChildStructure",
				"Upgrades.convertToParentChildStructure");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertTSeriesAnalysisCfgIECfgsToStdIEDefs",
				"Upgrades.convertTSeriesAnalysisCfgIECfgsToStdIEDefs");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertTSeriesDataCfgIECfgsToStdIEDefs",
				"Upgrades.convertTSeriesDataCfgIECfgsToStdIEDefs");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ConvertTSeriesDataIECfgsToStdIEDefs",
				"Upgrades.convertTSeriesDataIECfgsToStdIEDefs");

		newString = Replacer.simpleReplace(newString, "UPGRADE_Correct_StepUp_Bond_ABS_Spreads",
				"Upgrades.correctStepUpBondABSSpreads");

		newString = Replacer.simpleReplace(newString, "UPGRADE_CreateConfigurableVolDomainsFromLegacyVolDomains",
				"Upgrades.createConfigurableVolDomainsFromLegacyVolDomains");

		newString = Replacer.simpleReplace(newString, "UPGRADE_CreateGridProperties", "Upgrades.createGridProperties");

		newString = Replacer.simpleReplace(newString, "UPGRADE_DateConfigsForDayStartTime",
				"Upgrades.dateConfigsForDayStartTime");

		newString = Replacer.simpleReplace(newString, "UPGRADE_FixDealSideVolumePrecision",
				"Upgrades.fixDealSideVolumePrecision");

		newString = Replacer.simpleReplace(newString, "UPGRADE_FixupTranScheduleDetailsForOldDeals",
				"Upgrades.fixupTranScheduleDetailsForOldDeals");

		newString = Replacer.simpleReplace(newString, "UPGRADE_FixVolumeTypesForCMotion",
				"Upgrades.fixVolumeTypesForCMotion");

		newString = Replacer.simpleReplace(newString, "UPGRADE_Fx", "Upgrades.fx");

		newString = Replacer.simpleReplace(newString, "UPGRADE_GenericUpgradeScriptProcess",
				"Upgrades.genericUpgradeScriptProcess");

		newString = Replacer.simpleReplace(newString, "UPGRADE_GlobalEnvSettings", "Upgrades.globalEnvSettings");

		newString = Replacer.simpleReplace(newString, "UPGRADE_InsPymtFmlaVariableDefn",
				"Upgrades.insPymtFmlaVariableDefn");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadConnexScripts", "Upgrades.loadConnexScripts");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadCustomerJBOClasses",
				"Upgrades.loadCustomerJBOClasses");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadCustomerScripts", "Upgrades.loadCustomerScripts");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadCustomScripts", "Upgrades.loadCustomScripts");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadDealEntryScreenDefinitions",
				"Upgrades.loadDealEntryScreenDefinitions");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadGuiDefinitions", "Upgrades.loadGuiDefinitions");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadStandardJBOClasses",
				"Upgrades.loadStandardJBOClasses");

		newString = Replacer.simpleReplace(newString, "UPGRADE_LoadStandardScripts", "Upgrades.loadStandardScripts");

		newString = Replacer.simpleReplace(newString, "UPGRADE_PWRFixupBestAvailableForOldDeals",
				"Upgrades.pWRFixupBestAvailableForOldDeals");

		newString = Replacer.simpleReplace(newString, "UPGRADE_Remap_SPT_To_FP_CF_FOR_ABS",
				"Upgrades.remapSPTToFPCFFORABS");

		newString = Replacer.simpleReplace(newString, "UPGRADE_RemoveCorrelationBidOfferData",
				"Upgrades.removeCorrelationBidOfferData");

		newString = Replacer.simpleReplace(newString, "UPGRADE_ResetAvgCompoundPeriodForLogicalLeg",
				"Upgrades.resetAvgCompoundPeriodForLogicalLeg");

		newString = Replacer.simpleReplace(newString, "UPGRADE_SetFXDefaultCurrency", "Upgrades.setFXDefaultCurrency");

		newString = Replacer.simpleReplace(newString, "UPGRADE_SetFXDefaults", "Upgrades.setFXDefaults");

		newString = Replacer.simpleReplace(newString, "UPGRADE_SetPPAConfigurationDefaults",
				"Upgrades.setPPAConfigurationDefaults");

		newString = Replacer.simpleReplace(newString, "UPGRADE_SetSystemBaseCurrency",
				"Upgrades.setSystemBaseCurrency");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateABSInstruments", "Upgrades.updateABSInstruments");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateBarAndBarHistoryTables",
				"Upgrades.updateBarAndBarHistoryTables");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateBarrierOptionsV52toV53",
				"Upgrades.updateBarrierOptionsV52toV53");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateBarrierOptionsV53toV60",
				"Upgrades.updateBarrierOptionsV53toV60");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateBlackSwaptionScenarioPricingModelConfig",
				"Upgrades.updateBlackSwaptionScenarioPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateCommoditySchedulingForDaylightSavings",
				"Upgrades.updateCommoditySchedulingForDaylightSavings");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateContractDetailEntitlementsEffectiveDates",
				"Upgrades.updateContractDetailEntitlementsEffectiveDates");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateCTLSetupConfig", "Upgrades.updateCTLSetupConfig");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateDailyStorageBalances",
				"Upgrades.updateDailyStorageBalances");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateEnergyConversionEffectiveDates",
				"Upgrades.updateEnergyConversionEffectiveDates");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateIndexLinkedBondDailyRefIndexDay",
				"Upgrades.updateIndexLinkedBondDailyRefIndexDay");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateMCarloScenarioPricingModelConfig",
				"Upgrades.updateMCarloScenarioPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdatePwrLocations", "Upgrades.updatePwrLocations");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdatePwrPhysTables", "Upgrades.updatePwrPhysTables");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateRateDefsForHourly",
				"Upgrades.updateRateDefsForHourly");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateRepoDealsForDVPProcessing",
				"Upgrades.updateRepoDealsForDVPProcessing");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateScenarioLocaleSpecificStrings",
				"Upgrades.updateScenarioLocaleSpecificStrings");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateScenarioPricingModelMappings",
				"Upgrades.updateScenarioPricingModelMappings");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateScenarioVaRConfigs",
				"Upgrades.updateScenarioVaRConfigs");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateScenarioVegaConfigs",
				"Upgrades.updateScenarioVegaConfigs");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateStructSecDealsForPoolFactorAndAllinRate",
				"Upgrades.updateStructSecDealsForPoolFactorAndAllinRate");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateStructuredSecuritiesDealsForOriginalFaceAmount",
				"Upgrades.updateStructuredSecuritiesDealsForOriginalFaceAmount");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateSwingConstraintsForHourly",
				"Upgrades.updateSwingConstraintsForHourly");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateSwingRightsForHourly",
				"Upgrades.updateSwingRightsForHourly");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateTaxEvents", "Upgrades.updateTaxEvents");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateTaxJurisdictionEntity",
				"Upgrades.updateTaxJurisdictionEntity");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateWellheadProduct",
				"Upgrades.updateWellheadProduct");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateTaxTranTypeLicensing",
				"Upgrades.updateTaxTranTypeLicensing");

		newString = Replacer.simpleReplace(newString, "UPGRADE_UpdateTrinomialScenarioPricingModelConfig",
				"Upgrades.updateTrinomialScenarioPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "truncate", "Math.truncate");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisCorrelationDestinations",
				"TimeSeries.analysisCorrelationDestinations");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisCorrelations",
				"TimeSeries.analysisCorrelations");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisListAllConfigurations",
				"TimeSeries.analysisListAllConfigurations");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisReturns", "TimeSeries.analysisReturns");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisReturnsStatistics",
				"TimeSeries.analysisReturnsStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisSaveDatasets",
				"TimeSeries.analysisSaveDatasets");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisSaveDatasets",
				"TimeSeries.analysisSaveDatasets");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisValuesStatistics",
				"TimeSeries.analysisValuesStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisValuesStatistics",
				"TimeSeries.analysisValuesStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisVolatilitiesStatistics",
				"TimeSeries.analysisVolatilitiesStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_AnalysisVolatilityDestinations",
				"TimeSeries.analysisVolatilityDestinations");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeEWMACorrelations",
				"TimeSeries.computeEWMACorrelations");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeEWMACorrelationsUsingMLE",
				"TimeSeries.computeEWMACorrelationsUsingMLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeEWMAVolatilities",
				"TimeSeries.computeEWMAVolatilities");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeEWMACorrelationsUsingMLE",
				"TimeSeries.computeEWMACorrelationsUsingMLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeEWMAVolatilityStatistics",
				"TimeSeries.computeEWMAVolatilityStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeGARCHVolatilities",
				"TimeSeries.computeGARCHVolatilities");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeGARCHVolatilityStatistics",
				"TimeSeries.computeGARCHVolatilityStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeReturns", "TimeSeries.computeReturns");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeReturnsStatistics",
				"TimeSeries.computeReturnsStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeReturnsStatistics",
				"TimeSeries.computeReturnsStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeSMAVolatilities",
				"TimeSeries.computeSMAVolatilities");

		newString = Replacer.simpleReplace(newString, "TSERIES_ComputeValueStatistics",
				"TimeSeries.computeValueStatistics");

		newString = Replacer.simpleReplace(newString, "TSERIES_ExportAnalysisConfigs",
				"TimeSeries.exportAnalysisConfigs");

		newString = Replacer.simpleReplace(newString, "TSERIES_ExportAnalysisConfigs",
				"TimeSeries.exportAnalysisConfigs");

		newString = Replacer.simpleReplace(newString, "TSERIES_GenerateCurrentData", "TimeSeries.generateCurrentData");

		newString = Replacer.simpleReplace(newString, "TSERIES_GenerateCurrentDataForAnalysisConfig",
				"TimeSeries.generateCurrentDataForAnalysisConfig");

		newString = Replacer.simpleReplace(newString, "TSERIES_ImportAnalysisConfigs",
				"TimeSeries.importAnalysisConfigs");

		newString = Replacer.simpleReplace(newString, "TSERIES_ImportDataConfigs", "TimeSeries.importDataConfigs");

		newString = Replacer.simpleReplace(newString, "TSERIES_LoadCloseForObjects", "TimeSeries.loadCloseForObjects");

		newString = Replacer.simpleReplace(newString, "TSERIES_LoadData", "TimeSeries.loadData");

		newString = Replacer.simpleReplace(newString, "TSERIES_LoadDataConfig", "TimeSeries.loadDataConfig");

		newString = Replacer.simpleReplace(newString, "TSERIES_LoadDataForDates", "TimeSeries.loadDataForDates");

		newString = Replacer.simpleReplace(newString, "TSERIES_LoadDataForLatestNObservations",
				"TimeSeries.loadDataForLatestNObservations");

		newString = Replacer.simpleReplace(newString, "TSERIES_LoadUniversalForObjects",
				"TimeSeries.loadUniversalForObjects");

		newString = Replacer.simpleReplace(newString, "TSERIES_SaveData", "TimeSeries.saveData");

		newString = Replacer.simpleReplace(newString, "TSERIES_SaveHistoricalReturns",
				"TimeSeries.saveHistoricalReturns");

		newString = Replacer.simpleReplace(newString, "TSERIES_SaveVolatilitiesAndCorrelations",
				"TimeSeries.saveVolatilitiesAndCorrelations");

		newString = Replacer.simpleReplace(newString, "ASK_EditTable", "Ask.editTable");

		newString = Replacer.simpleReplace(newString, "ASK_EditTable_SetColReadOnly", "Ask.editTableSetColReadOnly");

		newString = Replacer.simpleReplace(newString, "ASK_EditTable_SetColReadOnlyN", "Ask.editTableSetColReadOnly");

		newString = Replacer.simpleReplace(newString, "ASK_EditTable_SetRowModCol", "Ask.editTableSetRowModCol");

		newString = Replacer.simpleReplace(newString, "ASK_EditTable_SetRowModColN", "Ask.editTableSetRowModCol");

		newString = Replacer.simpleReplace(newString, "ASK_GetString", "Ask.getString");

		newString = Replacer.simpleReplace(newString, "ASK_Ok", "Ask.ok");

		newString = Replacer.simpleReplace(newString, "ASK_OkCancel", "Ask.okCancel");

		newString = Replacer.simpleReplace(newString, "ASK_SetAvsTable", "Ask.setAvsTable");

		newString = Replacer.simpleReplace(newString, "ASK_SetEnterpriseTable", "Ask.setEnterpriseTable");

		newString = Replacer.simpleReplace(newString, "ASK_SetRefTable", "Ask.setRefTable");

		newString = Replacer.simpleReplace(newString, "ASK_SetTextEdit", "Ask.setTextEdit");

		newString = Replacer.simpleReplace(newString, "ASK_SetUSER_Picklist", "Ask.setUSERPicklist");

		newString = Replacer.simpleReplace(newString, "ASK_ViewTable", "Ask.viewTable");

		newString = Replacer.simpleReplace(newString, "ASK_YesNoCancel", "Ask.yesNoCancel");

		newString = Replacer.simpleReplace(newString, "autoroll_dates", "EndOfDay.autoRollDates");

		newString = Replacer.simpleReplace(newString, "avg", "Math.avg");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_AddComponent", "Ref.benchmarkAddComponent");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_CreateDefinition", "Ref.benchmarkCreateDefinition");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_DeleteComponent", "Ref.benchmarkDeleteComponent");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_DeleteDefinition", "Ref.benchmarkDeleteDefinition");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_RetrieveDefinition",
				"Ref.benchmarkRetrieveDefinition");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_UpdateComponent", "Ref.benchmarkUpdateComponent");

		newString = Replacer.simpleReplace(newString, "BLAST_ArgTable", "Blast.argTable");

		newString = Replacer.simpleReplace(newString, "BLAST_FindToken", "Blast.findToken");

		newString = Replacer.simpleReplace(newString, "BLAST_GetToken", "Blast.getToken");

		newString = Replacer.simpleReplace(newString, "BLAST_GetTokenDouble", "Blast.getTokenDouble");

		newString = Replacer.simpleReplace(newString, "BLAST_GetTokenInt", "Blast.getTokenInt");

		newString = Replacer.simpleReplace(newString, "BLAST_GetTokenTable", "Blast.getTokenTable");

		newString = Replacer.simpleReplace(newString, "BLAST_LogComment", "Blast.logComment");

		newString = Replacer.simpleReplace(newString, "BLAST_LogMsg", "Blast.logMsg");

		newString = Replacer.simpleReplace(newString, "BLAST_LogMsgFailed", "Blast.logMsgFailed");

		newString = Replacer.simpleReplace(newString, "BLAST_LogMsgPassed", "Blast.logMsgPassed");

		newString = Replacer.simpleReplace(newString, "BLAST_LogMsgTerminated", "Blast.logMsgTerminated");

		newString = Replacer.simpleReplace(newString, "BLAST_SetToken", "Blast.setToken");

		newString = Replacer.simpleReplace(newString, "BLAST_SetTokenDouble", "Blast.setTokenDouble");

		newString = Replacer.simpleReplace(newString, "BLAST_SetTokenInt", "Blast.setTokenInt");

		newString = Replacer.simpleReplace(newString, "BLAST_SetTokenTable", "Blast.setTokenTable");

		newString = Replacer.simpleReplace(newString, "BLAST_TokenIsGrid", "Blast.tokenIsGrid");

		newString = Replacer.simpleReplace(newString, "BLOOMBERG_CloseConnection", "DataFeed.closeConnection");

		newString = Replacer.simpleReplace(newString, "BLOOMBERG_IsConnectionOpened", "DataFeed.isConnectionOpened");

		newString = Replacer.simpleReplace(newString, "BLOOMBERG_OpenConnection", "DataFeed.openConnection");

		newString = Replacer.simpleReplace(newString, "BLOOMBERG_RetrieveInstrumentInfo",
				"DataFeed.retrieveInstrumentInfo");

		newString = Replacer.simpleReplace(newString, "BLOOMBERG_SetInsFieldList", "DataFeed.setInsFieldList");

		newString = Replacer.simpleReplace(newString, "BROADCAST_GetChannelNames", "Broadcast.getChannelNames");

		newString = Replacer.simpleReplace(newString, "BROADCAST_GetReceiverNames", "Broadcast.getReceiverNames");

		newString = Replacer.simpleReplace(newString, "BROADCAST_SendMessage", "Broadcast.sendMessage");

		newString = Replacer.simpleReplace(newString, "BROADCAST_SendMessageToList", "Broadcast.sendMessageToList");

		newString = Replacer.simpleReplace(newString, "BROKER_AmendCashTransaction", "Broker.amendCashTransaction");

		newString = Replacer.simpleReplace(newString, "BROKER_GetMatchedDeals", "Broker.getMatchedDeals");

		newString = Replacer.simpleReplace(newString, "BROKER_GetProvisionals", "Broker.getProvisionals");

		newString = Replacer.simpleReplace(newString, "BROKER_GetTranProvisional", "Broker.getTranProvisional");

		newString = Replacer.simpleReplace(newString, "BROKER_ModifyProvisionalCurrency",
				"Broker.modifyProvisionalCurrency");

		newString = Replacer.simpleReplace(newString, "BROKER_ModifyProvisionalRate", "Broker.modifyProvisionalRate");

		newString = Replacer.simpleReplace(newString, "BROKER_ModifyProvisionalUnit", "Broker.modifyProvisionalUnit");

		newString = Replacer.simpleReplace(newString, "BROKER_ModifyReservedAmount", "Broker.modifyReservedAmount");

		newString = Replacer.simpleReplace(newString, "BROKER_ProcessBrokerFees", "Broker.processBrokerFees");

		newString = Replacer.simpleReplace(newString, "BROKER_SelectBroker", "Broker.selectBroker");

		newString = Replacer.simpleReplace(newString, "BROKER_SelectFeeDefinition", "Broker.selectFeeDefinition");

		newString = Replacer.simpleReplace(newString, "BROKER_SetProvisional", "Broker.setProvisional");

		newString = Replacer.simpleReplace(newString, "BROKER_UndoCashTransaction", "Broker.undoCashTransaction");

		newString = Replacer.simpleReplace(newString, "calc_call_notice_adjusted_accr_between",
				"Transaction.calccallNoticeAdjustedAccrBetween");

		newString = Replacer.simpleReplace(newString, "CDS_ExportCreditDerivSetup",
				"TradeMaint.cdsExportCreditDerivSetup");

		newString = Replacer.simpleReplace(newString, "CDS_ImportCreditDerivSetup",
				"TradeMaint.cdsImportCreditDerivSetup");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_ByDefinition", "TradeMaint.closeoutByDefinition");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_FifoAvgPriceByBunit",
				"TradeMaint.closeoutFifoAvgPriceByBunit");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_FifoAvgPriceByPfolioIns",
				"TradeMaint.closeoutFifoAvgPriceByPfolioIns");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_FifoAvgPriceByPfolios",
				"TradeMaint.closeoutFifoAvgPriceByPfolios");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_FifoAvgPriceByQid",
				"TradeMaint.closeoutFifoAvgPriceByQid");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_FifoAvgPriceByQidDateRange",
				"TradeMaint.closeoutFifoAvgPriceByQidDateRange");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_InsertMatch", "TradeMaint.closeoutInsertMatch");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_LifoAvgPriceByPfolios",
				"TradeMaint.closeoutLifoAvgPriceByPfolios");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_LifoAvgPriceByQid",
				"TradeMaint.closeoutLifoAvgPriceByQid");

		newString = Replacer.simpleReplace(newString, "CLOSEOUT_LifoAvgPriceByQidDateRange",
				"TradeMaint.closeoutLifoAvgPriceByQidDateRange");

		newString = Replacer.simpleReplace(newString, "CLUSTER_GetId", "Services.clusterGetId");

		newString = Replacer.simpleReplace(newString, "CLUSTER_GetName", "Services.clusterGetName");

		newString = Replacer.simpleReplace(newString, "CLUSTER_GetStatus", "Services.clusterGetStatus");

		newString = Replacer.simpleReplace(newString, "CLUSTER_Restart", "Services.clusterRestart");

		newString = Replacer.simpleReplace(newString, "CLUSTER_RetrieveConfiguration",
				"Services.clusterRetrieveConfiguration");

		newString = Replacer.simpleReplace(newString, "CLUSTER_RetrieveConfigurationAll",
				"Services.clusterRetrieveConfigurationAll");

		newString = Replacer.simpleReplace(newString, "CLUSTER_Start", "Services.clusterStart");

		newString = Replacer.simpleReplace(newString, "CLUSTER_Stop", "Services.clusterStop");

		newString = Replacer.simpleReplace(newString, "convert_from_base_unit", "Transaction.convertFromBaseUnit");

		newString = Replacer.simpleReplace(newString, "convert_to_base_unit", "Transaction.convertToBaseUnit");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_Insert", "Util.corpACTIONInsert");

		newString = Replacer.simpleReplace(newString, "create_phys_delivery_table",
				"Transaction.createphysDeliveryTable");

		newString = Replacer.simpleReplace(newString, "CreateExportTable", "Export.createExportTable");

		newString = Replacer.simpleReplace(newString, "CreateImportTable", "Import.createImportTable");

		newString = Replacer.simpleReplace(newString, "CreateOrUpdateComposerDeal",
				"Transaction.createOrUpdateComposerDeal");

		newString = Replacer.simpleReplace(newString, "Credit_Batch_Complete", "CreditRiskBatch.batchComplete");

		newString = Replacer.simpleReplace(newString, "Credit_Batch_Evaluate_Trans",
				"CreditRiskBatch.batchEvaluateTrans");

		newString = Replacer.simpleReplace(newString, "Credit_Batch_Init", "CreditRiskBatch.batchInit");

		newString = Replacer.simpleReplace(newString, "Credit_Batch_Query_Deals", "CreditRiskBatch.batchQueryDeals");

		newString = Replacer.simpleReplace(newString, "CREDIT_CreateInquiryTable", "Credit.createInquiryTable");

		newString = Replacer.simpleReplace(newString, "CREDIT_CreateLimitTable", "Credit.createLimitTable");

		newString = Replacer.simpleReplace(newString, "Credit_ExportLimits", "CreditRiskUtil.exportLimits");

		newString = Replacer.simpleReplace(newString, "CREDIT_GetExceptionByID", "CreditRiskUtil.getExceptionByID");

		newString = Replacer.simpleReplace(newString, "CREDIT_GetMaturityBuckets", "CreditRiskUtil.getMaturityBuckets");

		newString = Replacer.simpleReplace(newString, "Credit_ImportLimits", "CreditRiskUtil.importLimits");

		newString = Replacer.simpleReplace(newString, "CREDIT_IsBatchRunning", "Credit.isBatchRunning");

		newString = Replacer.simpleReplace(newString, "CREDIT_IsDealCheckRunning", "Credit.isDealCheckRunning");

		newString = Replacer.simpleReplace(newString, "CREDIT_IsPreCheckRunning", "Credit.isPreCheckRunning");

		newString = Replacer.simpleReplace(newString, "CREDIT_IsUpdateScriptRunning", "Credit.isUpdateScriptRunning");

		newString = Replacer.simpleReplace(newString, "CREDIT_MapExternalToInternalIds",
				"Credit.mapExternalToInternalIds");

		newString = Replacer.simpleReplace(newString, "CREDIT_MapInternalToExternalIds",
				"Credit.mapInternalToExternalIds");

		newString = Replacer.simpleReplace(newString, "CREDIT_PopulateLimitTable", "Credit.populateLimitTable");

		newString = Replacer.simpleReplace(newString, "CREDIT_ResumeMonitoring", "Credit.resumeMonitoring");

		newString = Replacer.simpleReplace(newString, "Credit_Retrieve_Ins", "CreditRiskUtil.retrieveIns");

		newString = Replacer.simpleReplace(newString, "Credit_Retrieve_Num_Ins", "CreditRiskUtil.retrieveNumIns");

		newString = Replacer.simpleReplace(newString, "CREDIT_RetrieveCurrentUsages", "Credit.retrieveCurrentUsages");

		newString = Replacer.simpleReplace(newString, "CREDIT_RetrieveExposureLinesCriteria",
				"CreditRiskUtil.retrieveExposureLinesCriteria");

		newString = Replacer.simpleReplace(newString, "CREDIT_RetrieveOnlineStatus", "Credit.retrieveOnlineStatus");

		newString = Replacer.simpleReplace(newString, "CREDIT_RunBatchTask", "Credit.runBatchTask");

		newString = Replacer.simpleReplace(newString, "CREDIT_SetLimits", "Credit.setLimits");

		newString = Replacer.simpleReplace(newString, "Credit_Setup_Argt_For_Credit_Check",
				"CreditRiskUtil.setupArgtForCreditCheck");

		newString = Replacer.simpleReplace(newString, "CREDIT_StartMonitoring", "Credit.startMonitoring");

		newString = Replacer.simpleReplace(newString, "CREDIT_StopMonitoring", "Credit.stopMonitoring");

		newString = Replacer.simpleReplace(newString, "CREDIT_SuspendMonitoring", "Credit.suspendMonitoring");

		newString = Replacer.simpleReplace(newString, "CREDIT_UpdateExceptionUserInfo",
				"CreditRiskUtil.updateExceptionUserInfo");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_DeleteTemplateFileFromDB",
				"Crystal.deleteTemplateFileFromDB");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_ExportDynamicReport", "Crystal.exportDynamicReport");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_ExportReport", "Crystal.exportReport");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_ExportTemplateFileFromDB",
				"Crystal.exportTemplateFileFromDB");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_GetRptDir", "Crystal.getRptDir");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_ImportTemplateFileToDB",
				"Crystal.importTemplateFileToDB");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_PrintDynamicReport", "Crystal.printDynamicReport");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_PrintReport", "Crystal.printReport");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_RunTaskById", "Crystal.runTaskById");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_RunTaskByName", "Crystal.runTaskByName");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_ViewDynamicReport", "Crystal.viewDynamicReport");

		newString = Replacer.simpleReplace(newString, "CRYSTAL_ViewReport", "Crystal.viewReport");

		newString = Replacer.simpleReplace(newString, "DATE_ConvertYYYYMMDDToJd", "OCalendar.convertYYYYMMDDToJd");

		newString = Replacer.simpleReplace(newString, "DATE_ConvertYYYYMMToJd", "OCalendar.convertYYYYMMToJd");

		newString = Replacer.simpleReplace(newString, "DATE_DayCountFactor", "Instrument.dayCountFactor");

		newString = Replacer.simpleReplace(newString, "DATE_FormatJd", "OCalendar.formatJd");

		newString = Replacer.simpleReplace(newString, "DATE_FormatJdForDbAccess", "OCalendar.formatJdForDbAccess");

		newString = Replacer.simpleReplace(newString, "DATE_GasDay", "Util.gasDay");

		newString = Replacer.simpleReplace(newString, "DATE_GetBusinessDate", "Util.getBusinessDate");

		newString = Replacer.simpleReplace(newString, "DATE_GetDay", "OCalendar.getDay");

		newString = Replacer.simpleReplace(newString, "DATE_GetDayOfWeek", "OCalendar.getDayOfWeek");

		newString = Replacer.simpleReplace(newString, "DATE_GetDaysDelayedForIndex", "Index.getDaysDelayedForIndex");

		newString = Replacer.simpleReplace(newString, "DATE_GetDaysDelayedForIndexAndRefSource",
				"Index.getDaysDelayedForIndexAndRefSource");

		newString = Replacer.simpleReplace(newString, "DATE_GetEndOfQuarter", "OCalendar.getEndOfQuarter");

		newString = Replacer.simpleReplace(newString, "DATE_GetEOM", "OCalendar.getEOM");

		newString = Replacer.simpleReplace(newString, "DATE_GetEOY", "OCalendar.getEOY");

		newString = Replacer.simpleReplace(newString, "DATE_GetLgbd", "OCalendar.getLgbd");

		newString = Replacer.simpleReplace(newString, "DATE_GetLgbdForCurrency", "OCalendar.getLgbdForCurrency");

		newString = Replacer.simpleReplace(newString, "DATE_GetMonth", "OCalendar.getMonth");

		newString = Replacer.simpleReplace(newString, "DATE_GetMonthStr", "OCalendar.getMonthStr");

		newString = Replacer.simpleReplace(newString, "DATE_GetNgbd", "OCalendar.getNgbd");

		newString = Replacer.simpleReplace(newString, "DATE_GetNgbdForCurrency", "OCalendar.getNgbdForCurrency");

		newString = Replacer.simpleReplace(newString, "DATE_GetReleaseDatesForCurrency",
				"Util.getReleaseDatesForCurrency");

		newString = Replacer.simpleReplace(newString, "DATE_GetServerDate", "OCalendar.getServerDate");

		newString = Replacer.simpleReplace(newString, "DATE_GetSOM", "OCalendar.getSOM");

		newString = Replacer.simpleReplace(newString, "DATE_GetSOY", "OCalendar.getSOY");

		newString = Replacer.simpleReplace(newString, "DATE_GetStartOfQuarter", "OCalendar.getStartOfQuarter");

		newString = Replacer.simpleReplace(newString, "DATE_GetTradingDate", "Util.getTradingDate");

		newString = Replacer.simpleReplace(newString, "DATE_GetYear", "OCalendar.getYear");

		newString = Replacer.simpleReplace(newString, "Date_IsDaylightSavings", "OCalendar.dateIsDaylightSavings");

		newString = Replacer.simpleReplace(newString, "DATE_IsGbd", "OCalendar.isGbd");

		newString = Replacer.simpleReplace(newString, "DATE_IsHoliday", "OCalendar.isHoliday");

		newString = Replacer.simpleReplace(newString, "DATE_JumpGBDForIndex", "OCalendar.jumpGBDForIndex");

		newString = Replacer.simpleReplace(newString, "DATE_JumpMonths", "OCalendar.jumpMonths");

		newString = Replacer.simpleReplace(newString, "DATE_MDYtoDate", "OCalendar.mdyToDate");

		newString = Replacer.simpleReplace(newString, "DATE_NumGBDBetweenForIndex", "OCalendar.numGBDBetweenForIndex");

		newString = Replacer.simpleReplace(newString, "DATE_ParseString", "OCalendar.parseString");

		newString = Replacer.simpleReplace(newString, "DATE_ParseStringWithHolId", "OCalendar.parseStringWithHolId");

		newString = Replacer.simpleReplace(newString, "DATE_Print", "OCalendar.print");

		newString = Replacer.simpleReplace(newString, "DATE_ProcessingDate", "Util.processingDate");

		newString = Replacer.simpleReplace(newString, "DATE_SetCurrentDate", "Util.setCurrentDate");

		newString = Replacer.simpleReplace(newString, "DATE_SetReleaseDatesForCurrency",
				"Util.setReleaseDatesForCurrency");

		newString = Replacer.simpleReplace(newString, "DATE_StrToDate", "OCalendar.strToDate");

		newString = Replacer.simpleReplace(newString, "DATE_Today", "OCalendar.today");

		newString = Replacer.simpleReplace(newString, "day_is_in_bitmap", "Power.dayisInBitmap");

		newString = Replacer.simpleReplace(newString, "DB_RetrieveErrorInfo", "DBUserTable.dbRetrieveErrorInfo");

		newString = Replacer.simpleReplace(newString, "DBASE_CreateTableOfQueryResults",
				"DBase.createTableOfQueryResults");

		newString = Replacer.simpleReplace(newString, "DBASE_GetBCPFlag", "DBase.getBCPFlag");

		newString = Replacer.simpleReplace(newString, "DBASE_GetBCPFlagFromEnv", "DBase.getBCPFlagFromEnv");

		newString = Replacer.simpleReplace(newString, "DBASE_GetDbType", "DBase.getDbType");

		newString = Replacer.simpleReplace(newString, "DBASE_RunProc", "DBase.runProc");

		newString = Replacer.simpleReplace(newString, "DBASE_RunProcFillTable", "DBase.runProcFillTable");

		newString = Replacer.simpleReplace(newString, "DBASE_RunQueryWithIdList", "DBase.runQueryWithIdList");

		newString = Replacer.simpleReplace(newString, "DBASE_RunSql", "DBase.runSql");

		newString = Replacer.simpleReplace(newString, "DBASE_RunSqlFillTable", "DBase.runSqlFillTable");

		newString = Replacer.simpleReplace(newString, "DBASE_SetBCPFlag", "DBase.setBCPFlag");

		newString = Replacer.simpleReplace(newString, "DBMAINT_BCPIn", "DBMaint.bcpIn");

		newString = Replacer.simpleReplace(newString, "DBMAINT_Connect", "DBMaint.connect");

		newString = Replacer.simpleReplace(newString, "DBMAINT_CreateTable", "DBMaint.createTable");

		newString = Replacer.simpleReplace(newString, "DBMAINT_DeleteData", "DBMaint.deleteData");

		newString = Replacer.simpleReplace(newString, "DBMAINT_Disconnect", "DBMaint.disconnect");

		newString = Replacer.simpleReplace(newString, "DBMAINT_DisplayErrorInfo", "DBMaint.displayErrorInfo");

		newString = Replacer.simpleReplace(newString, "DBMAINT_ExecProc", "DBMaint.execProc");

		newString = Replacer.simpleReplace(newString, "DBMAINT_ExecSql", "DBMaint.execSql");

		newString = Replacer.simpleReplace(newString, "DBMAINT_FindMissingInternalIdentifiers",
				"DBMaint.findMissingInternalIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBMAINT_GenerateNewInternalIdentifiers",
				"DBMaint.generateNewInternalIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBMAINT_LoadGroupIdentifiers", "DBMaint.loadGroupIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBMAINT_LoadTable", "DBMaint.loadTable");

		newString = Replacer.simpleReplace(newString, "DBMAINT_ReadData", "DBMaint.readData");

		newString = Replacer.simpleReplace(newString, "DBMAINT_RetrieveErrorInfo", "DBMaint.retrieveErrorInfo");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SaveData", "DBMaint.saveData");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SetDebug", "DBMaint.setDebug");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SSQL_Is_Valid", "DBMaint.ssqlIsValid");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SSQL_New", "DBMaint.ssqlNew");

		newString = Replacer.simpleReplace(newString, "DBMAINT_UpdateNewInternalIdentifiers",
				"DBMaint.updateNewInternalIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBTABLE_BcpIn", "DBUserTable.bcpIn");

		newString = Replacer.simpleReplace(newString, "DBTABLE_BcpInTempDb", "DBUserTable.bcpInTempDb");

		newString = Replacer.simpleReplace(newString, "DBTABLE_BcpInWithFill", "DBUserTable.bcpInWithFill");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Clear", "DBUserTable.clear");

		newString = Replacer.simpleReplace(newString, "DBTABLE_ClearAllAccess", "DBUserTable.clearAllAccess");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Create", "DBUserTable.create");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Delete", "DBUserTable.delete");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Drop", "DBUserTable.drop");

		newString = Replacer.simpleReplace(newString, "DBTABLE_GetAccess", "DBUserTable.getAccess");

		newString = Replacer.simpleReplace(newString, "DBTABLE_GetAccessSecurityGroups",
				"DBUserTable.getAccessSecurityGroups");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Insert", "DBUserTable.insert");

		newString = Replacer.simpleReplace(newString, "DBTABLE_List", "DBUserTable.list");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Load", "DBUserTable.load");

		newString = Replacer.simpleReplace(newString, "DBTABLE_SaveUserTable", "DBUserTable.saveUserTable");

		newString = Replacer.simpleReplace(newString, "DBTABLE_SetAccess", "DBUserTable.setAccess");

		newString = Replacer.simpleReplace(newString, "DBTABLE_SetAccessSecurityGroups",
				"DBUserTable.setAccessSecurityGroups");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Structure", "DBUserTable.structure");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Update", "DBUserTable.update");

		newString = Replacer.simpleReplace(newString, "DBTABLE_UserTableIsValid", "DBUserTable.userTableIsValid");

		newString = Replacer.simpleReplace(newString, "DEBUG_SetLevel", "Debug.setLevel");

		newString = Replacer.simpleReplace(newString, "DEBUG_SetTypeStatus", "Debug.setTypeStatus");

		newString = Replacer.simpleReplace(newString, "DoubleToInt", "Math.doubleToInt");

		newString = Replacer.simpleReplace(newString, "DW_ConvertScenarioResults",
				"DataWarehouse.convertScenarioResults");

		newString = Replacer.simpleReplace(newString, "DW_ConvertValuationData", "DataWarehouse.convertValuationData");

		newString = Replacer.simpleReplace(newString, "DW_CreateExtractionLogEntry",
				"DataWarehouse.createExtractionLogEntry");

		newString = Replacer.simpleReplace(newString, "DW_CreateExtractionLogTable",
				"DataWarehouse.createExtractionLogTable");

		newString = Replacer.simpleReplace(newString, "DW_ExtractCorrelationData",
				"DataWarehouse.extractCorrelationData");

		newString = Replacer.simpleReplace(newString, "DW_ExtractIndexRatesPricesData",
				"DataWarehouse.extractIndexRatesPricesData");

		newString = Replacer.simpleReplace(newString, "DW_ExtractPriceIndexOutputData",
				"DataWarehouse.extractPriceIndexOutputData");

		newString = Replacer.simpleReplace(newString, "DW_ExtractRateIndexOutputData",
				"DataWarehouse.extractRateIndexOutputData");

		newString = Replacer.simpleReplace(newString, "DW_ExtractScenarioResults",
				"DataWarehouse.extractScenarioResults");

		newString = Replacer.simpleReplace(newString, "DW_ExtractSimResults", "DataWarehouse.extractSimResults");

		newString = Replacer.simpleReplace(newString, "DW_ExtractValuationData", "DataWarehouse.extractValuationData");

		newString = Replacer.simpleReplace(newString, "DW_ExtractVolatilityData",
				"DataWarehouse.extractVolatilityData");

		newString = Replacer.simpleReplace(newString, "DW_InsertResults", "DataWarehouse.insertResults");

		newString = Replacer.simpleReplace(newString, "DW_PurgeExtractedResults",
				"DataWarehouse.purgeExtractedResults");

		newString = Replacer.simpleReplace(newString, "DW_SetExtractionRecordStatus",
				"DataWarehouse.setExtractionRecordStatus");

		newString = Replacer.simpleReplace(newString, "DW_UpdateETLStatus", "DataWarehouse.updateETLStatus");

		newString = Replacer.simpleReplace(newString, "EOD_ComFut_Get_Roll_Events",
				"TradeMaint.eodComFutGetRollEvents");

		newString = Replacer.simpleReplace(newString, "EOD_ComFut_Process_Roll_Tran_Table",
				"TradeMaint.eodComFutProcessRollTranTable");

		newString = Replacer.simpleReplace(newString, "EOD_ComFutProcessMultiEventRollTranTable",
				"TradeMaint.eodComFutProcessMultiEventRollTranTable");

		newString = Replacer.simpleReplace(newString, "EOD_CreateResetTable", "EndOfDay.createResetTable");

		newString = Replacer.simpleReplace(newString, "EOD_FX_MarkToMarket", "TradeMaint.eodFXMarkToMarket");

		newString = Replacer.simpleReplace(newString, "EOD_Generate_Inventory", "TradeMaint.eodGenerateInventory");

		newString = Replacer.simpleReplace(newString, "EOD_Get_Roll_Tran_Table", "TradeMaint.eodGetRollTranTable");

		newString = Replacer.simpleReplace(newString, "EOD_Mature_Master_Ins", "TradeMaint.eodMatureMasterIns");

		newString = Replacer.simpleReplace(newString, "EOD_Mature_Trades", "TradeMaint.eodMatureTrades");

		newString = Replacer.simpleReplace(newString, "EOD_Mature_Trades_By_Portfolio",
				"TradeMaint.eodMatureTradesByPortfolio");

		newString = Replacer.simpleReplace(newString, "EOD_Position_Processing", "TradeMaint.eodPositionProcessing");

		newString = Replacer.simpleReplace(newString, "EOD_ResetDealsByQid", "EndOfDay.resetDealsByQid");

		newString = Replacer.simpleReplace(newString, "EOD_ResetDealsByQidIndex", "EndOfDay.resetDealsByQidIndex");

		newString = Replacer.simpleReplace(newString, "EOD_ResetDealsByQidTable", "EndOfDay.resetDealsByQidTable");

		newString = Replacer.simpleReplace(newString, "EOD_ResetDealsByTranList", "EndOfDay.resetDealsByTranList");

		newString = Replacer.simpleReplace(newString, "EOD_ResetDealsByTranListIndex",
				"EndOfDay.resetDealsByTranListIndex");

		newString = Replacer.simpleReplace(newString, "EOD_ResetDealsByTranListTable",
				"EndOfDay.resetDealsByTranListTable");

		newString = Replacer.simpleReplace(newString, "EOD_RollbackResetsByQid", "EndOfDay.rollbackResetsByQid");

		newString = Replacer.simpleReplace(newString, "EOD_RollbackResetsByQidIndex",
				"EndOfDay.rollbackResetsByQidIndex");

		newString = Replacer.simpleReplace(newString, "EOD_RollbackResetsByTranList",
				"EndOfDay.rollbackResetsByTranList");

		newString = Replacer.simpleReplace(newString, "EOD_RollbackResetsByTranListIndex",
				"EndOfDay.rollbackResetsByTranListIndex");

		newString = Replacer.simpleReplace(newString, "EOD_SetRollTranSourcesTable",
				"TradeMaint.eodSetRollTranSourcesTable");

		newString = Replacer.simpleReplace(newString, "EOD_Update_Bar_Inventory", "TradeMaint.eodUpdateBarInventory");

		newString = Replacer.simpleReplace(newString, "EOD_Update_Corporate_Actions",
				"TradeMaint.eodUpdateCorporateActions");

		newString = Replacer.simpleReplace(newString, "ERROR_InitLog", "Util.errorInitLog");

		newString = Replacer.simpleReplace(newString, "ERROR_InitScriptErrorLog", "Util.errorInitScriptErrorLog");

		newString = Replacer.simpleReplace(newString, "ERROR_LogMessage", "Util.errorLogMessage");

		newString = Replacer.simpleReplace(newString, "ERROR_WriteString", "Util.errorWriteString");

		newString = Replacer.simpleReplace(newString, "euro_conversion", "Transaction.euroconversion");

		newString = Replacer.simpleReplace(newString, "EVENT_ChangeOpenToFutDeliveryOpen",
				"Transaction.eventChangeOpenToFutDeliveryOpen");

		newString = Replacer.simpleReplace(newString, "EVENT_Explode", "Acct.eventExplode");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeByQueryResultTranDate",
				"Acct.eventExplodeByQueryResultTranDate");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeByTradeDate", "Acct.eventExplodeByTradeDate");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeDateSeqCheck", "Acct.eventExplodeDateSeqCheck");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeGroup", "Acct.eventExplodeGroup");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeGroupByProcessingDate",
				"Acct.eventExplodeGroupByProcessingDate");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeGroupByTradeDate",
				"Acct.eventExplodeGroupByTradeDate");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeP", "Acct.eventExplodeP");

		newString = Replacer.simpleReplace(newString, "EVENT_ExplodeR", "Acct.eventExplodeR");

		newString = Replacer.simpleReplace(newString, "EVENT_GetAccountingDate", "Acct.eventGetAccountingDate");

		newString = Replacer.simpleReplace(newString, "EVENT_SetAccountingDate", "Acct.eventSetAccountingDate");

		newString = Replacer.simpleReplace(newString, "EXPORT_AddObject", "Export.addObject");

		newString = Replacer.simpleReplace(newString, "EXPORT_CreditRatingSourceTable",
				"Util.exportCreditRatingSourceTable");

		newString = Replacer.simpleReplace(newString, "EXPORT_CreditRatingTable", "Util.exportCreditRatingTable");

		newString = Replacer.simpleReplace(newString, "EXPORT_ExportDataToDB", "Export.exportDataToDB");

		newString = Replacer.simpleReplace(newString, "EXPORT_ExportDataToFile", "Export.exportDataToFile");

		newString = Replacer.simpleReplace(newString, "EXPORT_ExportDestroyTable", "Export.exportDestroyTable");

		newString = Replacer.simpleReplace(newString, "EXPORT_ExportSetWriteMode", "Export.exportSetWriteMode");

		newString = Replacer.simpleReplace(newString, "EXPORT_GetSource", "Export.getSource");

		newString = Replacer.simpleReplace(newString, "EXPORT_PartyCreditRatingTable",
				"Util.exportPartyCreditRatingTable");

		newString = Replacer.simpleReplace(newString, "EXPORT_SetDestination", "Export.setDestination");

		newString = Replacer.simpleReplace(newString, "EXPORT_SetSource", "Export.setSource");

		newString = Replacer.simpleReplace(newString, "extend_ltp_deal_for_phys_delivery",
				"Transaction.extendltpDealForPhysDelivery");

		newString = Replacer.simpleReplace(newString, "FILE_DeleteFileFromDB", "FileUtil.deleteFileFromDB");

		newString = Replacer.simpleReplace(newString, "FILE_ExportFileFromDB", "FileUtil.exportFileFromDB");

		newString = Replacer.simpleReplace(newString, "FILE_GetFileSuffix", "FileUtil.getFileSuffix");

		newString = Replacer.simpleReplace(newString, "FILE_ImportFileToDB", "FileUtil.importFileToDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectory_DeleteContents",
				"FileUtil.userDirectoryDeleteContents");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectory_DeleteContentsAndDirectory",
				"FileUtil.userDirectoryDeleteContentsAndDirectory");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryContents", "FileUtil.userDirectoryContents");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryCreate", "FileUtil.userDirectoryCreate");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryDelete", "FileUtil.userDirectoryDelete");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryExists", "FileUtil.userDirectoryExists");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryGetGroupPermission",
				"FileUtil.userDirectoryGetGroupPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryGetOwnerId",
				"FileUtil.userDirectoryGetOwnerId");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryGetOwnerName",
				"FileUtil.userDirectoryGetOwnerName");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryGetOwnerPermission",
				"FileUtil.userDirectoryGetOwnerPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryGetPublicPermission",
				"FileUtil.userDirectoryGetPublicPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryGetSecurityGroupId",
				"FileUtil.userDirectoryGetSecurityGroupId");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryGetSecurityGroupName",
				"FileUtil.userDirectoryGetSecurityGroupName");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectoryRename", "FileUtil.userDirectoryRename");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectorySetGroupPermission",
				"FileUtil.userDirectorySetGroupPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectorySetOwnerId",
				"FileUtil.userDirectorySetOwnerId");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectorySetOwnerName",
				"FileUtil.userDirectorySetOwnerName");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectorySetOwnerPermission",
				"FileUtil.userDirectorySetOwnerPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectorySetPublicPermission",
				"FileUtil.userDirectorySetPublicPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectorySetSecurityGroupId",
				"FileUtil.userDirectorySetSecurityGroupId");

		newString = Replacer.simpleReplace(newString, "FILE_UserDirectorySetSecurityGroupName",
				"FileUtil.userDirectorySetSecurityGroupName");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileCopy", "FileUtil.userFileCopy");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileExists", "FileUtil.userFileExists");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetGroupPermission",
				"FileUtil.userFileGetGroupPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetOwnerId", "FileUtil.userFileGetOwnerId");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetOwnerName", "FileUtil.userFileGetOwnerName");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetOwnerPermission",
				"FileUtil.userFileGetOwnerPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetPublicPermission",
				"FileUtil.userFileGetPublicPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetSecurityGroupId",
				"FileUtil.userFileGetSecurityGroupId");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetSecurityGroupName",
				"FileUtil.userFileGetSecurityGroupName");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileGetType", "FileUtil.userFileGetType");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileLoadBinaryFromDB",
				"FileUtil.userFileLoadBinaryFromDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileLoadTableFromDB",
				"FileUtil.userFileLoadTableFromDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileLoadTextFromDB", "FileUtil.userFileLoadTextFromDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileLoadXMLFromDB", "FileUtil.userFileLoadXMLFromDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileRename", "FileUtil.userFileRename");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSaveBinaryToDB", "FileUtil.userFileSaveBinaryToDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSaveTableToDB", "FileUtil.userFileSaveTableToDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSaveTextToDB", "FileUtil.userFileSaveTextToDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSaveXMLToDB", "FileUtil.userFileSaveXMLToDB");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSetGroupPermission",
				"FileUtil.userFileSetGroupPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSetOwnerId", "FileUtil.userFileSetOwnerId");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSetOwnerName", "FileUtil.userFileSetOwnerName");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSetOwnerPermission",
				"FileUtil.userFileSetOwnerPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSetPublicPermission",
				"FileUtil.userFileSetPublicPermission");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSetSecurityGroupId",
				"FileUtil.userFileSetSecurityGroupId");

		newString = Replacer.simpleReplace(newString, "FILE_UserFileSetSecurityGroupName",
				"FileUtil.userFileSetSecurityGroupName");

		newString = Replacer.simpleReplace(newString, "GET_DEBUG", "Debug.getDEBUG");

		newString = Replacer.simpleReplace(newString, "get_default_lentity_for_bunit", "Ref.getDefaultLentityForBunit");

		newString = Replacer.simpleReplace(newString, "get_gptid_for_3m", "Index.getGptIdFor3m");

		newString = Replacer.simpleReplace(newString, "get_total_seconds_from_increment_type",
				"Power.gettotalSecondsFromIncrementType");

		newString = Replacer.simpleReplace(newString, "GetEnv", "Util.getEnv");

		newString = Replacer.simpleReplace(newString, "GetUnitConversionFactor", "Transaction.getUnitConversionFactor");

		newString = Replacer.simpleReplace(newString, "gp_idx_subgroup_from_location",
				"TradeMaint.gpidxSubgroupFromLocation");

		newString = Replacer.simpleReplace(newString, "HEDGE_AdjustTradeDelta", "TradeMaint.hedgeAdjustTradeDelta");

		newString = Replacer.simpleReplace(newString, "HEDGE_ApplyTradeParameters",
				"TradeMaint.hedgeApplyTradeParameters");

		newString = Replacer.simpleReplace(newString, "HEDGE_ComputeHedgeDelta", "TradeMaint.hedgeComputeHedgeDelta");

		newString = Replacer.simpleReplace(newString, "HEDGE_ComputeHedgeVolumes",
				"TradeMaint.hedgeComputeHedgeVolumes");

		newString = Replacer.simpleReplace(newString, "HEDGE_ComputeTradeDelta", "TradeMaint.hedgeComputeTradeDelta");

		newString = Replacer.simpleReplace(newString, "HEDGE_CreateArgt", "TradeMaint.hedgeCreateArgt");

		newString = Replacer.simpleReplace(newString, "HEDGE_CreateHedgeTable", "TradeMaint.hedgeCreateHedgeTable");

		newString = Replacer.simpleReplace(newString, "HEDGE_GetHedge", "TradeMaint.hedgeGetHedge");

		newString = Replacer.simpleReplace(newString, "HEDGE_GetHedgeTable", "TradeMaint.hedgeGetHedgeTable");

		newString = Replacer.simpleReplace(newString, "HEDGE_GetNumHedges", "TradeMaint.hedgeGetNumHedges");

		newString = Replacer.simpleReplace(newString, "HEDGE_GetTrade", "TradeMaint.hedgeGetTrade");

		newString = Replacer.simpleReplace(newString, "HEDGE_SetHedgeForTrade", "TradeMaint.hedgeSetHedgeForTrade");

		newString = Replacer.simpleReplace(newString, "HEDGE_SetHedgeTable", "TradeMaint.hedgeSetHedgeTable");

		newString = Replacer.simpleReplace(newString, "HEDGE_SetVolumesOnHedge", "TradeMaint.hedgeSetVolumesOnHedge");

		newString = Replacer.simpleReplace(newString, "HEDGE_UnLink", "TradeMaint.hedgeUnLink");

		newString = Replacer.simpleReplace(newString, "HEDGE_UpdateLink", "TradeMaint.hedgeUpdateLink");

		newString = Replacer.simpleReplace(newString, "HGS_AddShipperCode", "HGasScheduling.addShipperCode");

		newString = Replacer.simpleReplace(newString, "HGS_IsNull", "HGasScheduling.getIsNull");

		newString = Replacer.simpleReplace(newString, "HGS_New", "HGasScheduling.hgsNew");

		newString = Replacer.simpleReplace(newString, "hour_is_in_bitmap", "Power.hourisInBitmap");

		newString = Replacer.simpleReplace(newString, "iif", "Math.iif");

		newString = Replacer.simpleReplace(newString, "IMPORT_AddObject", "Import.addObject");

		newString = Replacer.simpleReplace(newString, "IMPORT_CreateBarTable", "Import.createBarTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_CreditRatingSourceTable",
				"Util.importCreditRatingSourceTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_CreditRatingTable", "Util.importCreditRatingTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_EXPORT_CreateCreditRatingSourceTable",
				"Util.importEXPORTCreateCreditRatingSourceTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_EXPORT_CreateCreditRatingTable",
				"Util.importEXPORTCreateCreditRatingTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_EXPORT_CreatePartyCreditRatingTable",
				"Util.importEXPORTCreatePartyCreditRatingTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_EXPORT_RunDefinition", "Ref.importEXPORTRunDefinition");

		newString = Replacer.simpleReplace(newString, "IMPORT_GetDestination", "Import.getDestination");

		newString = Replacer.simpleReplace(newString, "IMPORT_GetImportDir", "Util.importGetImportDir");

		newString = Replacer.simpleReplace(newString, "IMPORT_ImportDataFromDB", "Import.importDataFromDB");

		newString = Replacer.simpleReplace(newString, "IMPORT_ImportDataFromFile", "Import.importDataFromFile");

		newString = Replacer.simpleReplace(newString, "IMPORT_ImportDataFromMultiFiles",
				"Import.importDataFromMultiFiles");

		newString = Replacer.simpleReplace(newString, "IMPORT_ImportDestroyTable", "Import.importDestroyTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_InsertBar", "Import.insertBar");

		newString = Replacer.simpleReplace(newString, "import_log_error", "Transaction.importlogError");

		newString = Replacer.simpleReplace(newString, "IMPORT_PartyCreditRatingTable",
				"Util.importPartyCreditRatingTable");

		newString = Replacer.simpleReplace(newString, "IMPORT_SetSource", "Import.setSource");

		newString = Replacer.simpleReplace(newString, "INDEX_AddGptToIndex", "Index.addGptToIndex");

		newString = Replacer.simpleReplace(newString, "INDEX_Calc", "Index.calc");

		newString = Replacer.simpleReplace(newString, "INDEX_CreateInputTableForAdjustedPrices",
				"Index.createInputTableForAdjustedPrices");

		newString = Replacer.simpleReplace(newString, "INDEX_CreateTableForGpts", "Index.createTableForGpts");

		newString = Replacer.simpleReplace(newString, "INDEX_ExportData", "Index.exportData");

		newString = Replacer.simpleReplace(newString, "INDEX_ExportDataForConfig", "Index.exportDataForConfig");

		newString = Replacer.simpleReplace(newString, "INDEX_ExportDefs", "Index.exportDefs");

		newString = Replacer.simpleReplace(newString, "INDEX_GetAdjustedPricesForSuperIndex",
				"Index.getAdjustedPricesForSuperIndex");

		newString = Replacer.simpleReplace(newString, "INDEX_GetComponent", "Index.getComponent");

		newString = Replacer.simpleReplace(newString, "INDEX_GetContractSize", "Index.getContractSize");

		newString = Replacer.simpleReplace(newString, "INDEX_GetDateSeqLabel", "Index.getDateSeqLabel");

		newString = Replacer.simpleReplace(newString, "INDEX_GetGptDefTable", "Index.getGptDefTable");

		newString = Replacer.simpleReplace(newString, "INDEX_GetGroup", "Index.getGroup");

		newString = Replacer.simpleReplace(newString, "INDEX_GetInfoDate", "Index.getInfoDate");

		newString = Replacer.simpleReplace(newString, "INDEX_GetInfoDateTimeDate", "Index.getInfoDateTimeDate");

		newString = Replacer.simpleReplace(newString, "INDEX_GetInfoDateTimeTime", "Index.getInfoDateTimeTime");

		newString = Replacer.simpleReplace(newString, "INDEX_GetInfoDoubleValue", "Index.getInfoDoubleValue");

		newString = Replacer.simpleReplace(newString, "INDEX_GetInfoIntValue", "Index.getInfoIntValue");

		newString = Replacer.simpleReplace(newString, "INDEX_GetInfoStringValue", "Index.getInfoStringValue");

		newString = Replacer.simpleReplace(newString, "INDEX_GetInfoTime", "Index.getInfoTime");

		newString = Replacer.simpleReplace(newString, "INDEX_GetOutput", "Index.getOutput");

		newString = Replacer.simpleReplace(newString, "INDEX_GetSubgroupByName", "Index.getSubgroupByName");

		newString = Replacer.simpleReplace(newString, "INDEX_ImportCurveAdjustmentFile",
				"Index.importCurveAdjustmentFile");

		newString = Replacer.simpleReplace(newString, "INDEX_ImportCurveMatrixFile", "Index.importCurveMatrixFile");

		newString = Replacer.simpleReplace(newString, "INDEX_ImportData", "Index.importData");

		newString = Replacer.simpleReplace(newString, "INDEX_ImportDataForConfig", "Index.importDataForConfig");

		newString = Replacer.simpleReplace(newString, "INDEX_ImportDefs", "Index.importDefs");

		newString = Replacer.simpleReplace(newString, "INDEX_ImportIndex", "Index.importIndex");

		newString = Replacer.simpleReplace(newString, "INDEX_ImportMdoTicker", "Index.importMdoTicker");

		newString = Replacer.simpleReplace(newString, "INDEX_ListAllIndexes", "Index.listAllIndexes");

		newString = Replacer.simpleReplace(newString, "INDEX_ListDirectChildren", "Index.listDirectChildren");

		newString = Replacer.simpleReplace(newString, "INDEX_ListDirectParents", "Index.listDirectParents");

		newString = Replacer.simpleReplace(newString, "INDEX_LoadAllDefs", "Index.loadAllDefs");

		newString = Replacer.simpleReplace(newString, "INDEX_LoadAllGpts", "Index.loadAllGpts");

		newString = Replacer.simpleReplace(newString, "INDEX_LoadAllGptsForVB", "Index.loadAllGptsForVB");

		newString = Replacer.simpleReplace(newString, "INDEX_RefreshDb", "Index.refreshDb");

		newString = Replacer.simpleReplace(newString, "INDEX_RefreshDbList", "Index.refreshDbList");

		newString = Replacer.simpleReplace(newString, "INDEX_RefreshList", "Index.refreshList");

		newString = Replacer.simpleReplace(newString, "INDEX_RefreshShm", "Index.refreshShm");

		newString = Replacer.simpleReplace(newString, "INDEX_RemoveGptFromIndex", "Index.removeGptFromIndex");

		newString = Replacer.simpleReplace(newString, "INDEX_RenameById", "Index.renameById");

		newString = Replacer.simpleReplace(newString, "INDEX_RenameByName", "Index.renameByName");

		newString = Replacer.simpleReplace(newString, "INDEX_ReplaceThisInGptFormula", "Index.replaceThisInGptFormula");

		newString = Replacer.simpleReplace(newString, "INDEX_RetrieveHistoricalFxRatesByCurrency",
				"Index.retrieveHistoricalFxRatesByCurrency");

		newString = Replacer.simpleReplace(newString, "INDEX_SaveHistoricalFxRates", "Index.saveHistoricalFxRates");

		newString = Replacer.simpleReplace(newString, "INDEX_SaveHistoricalPrices", "Index.saveHistoricalPrices");

		newString = Replacer.simpleReplace(newString, "INDEX_SetCurveLabel", "Index.setCurveLabel");

		newString = Replacer.simpleReplace(newString, "INDEX_UpdateGpts", "Index.updateGpts");

		newString = Replacer.simpleReplace(newString, "INDEX_UpdatePersonalGpts", "Index.updatePersonalGpts");

		newString = Replacer.simpleReplace(newString, "IndexDateToEff", "Index.indexDateToEff");

		newString = Replacer.simpleReplace(newString, "IndexDelayedDateToEff", "Index.indexDelayedDateToEff");

		newString = Replacer.simpleReplace(newString, "INS_AddManyCflowFromTable", "Instrument.addManyCflowFromTable");

		newString = Replacer.simpleReplace(newString, "INS_AllocResetForTable", "Instrument.allocResetForTable");

		newString = Replacer.simpleReplace(newString, "INS_BlobInstruments", "Instrument.blobInstruments");

		newString = Replacer.simpleReplace(newString, "INS_CallNoticeAddRowToGlobalRateMatrix",
				"Instrument.callNoticeAddRowToGlobalRateMatrix");

		newString = Replacer.simpleReplace(newString, "INS_CallNoticeAuthorizeGlobalRateMatrix",
				"Instrument.callNoticeAuthorizeGlobalRateMatrix");

		newString = Replacer.simpleReplace(newString, "INS_CallNoticeDeleteFromGlobalRateMatrix",
				"Instrument.callNoticeDeleteFromGlobalRateMatrix");

		newString = Replacer.simpleReplace(newString, "INS_CallNoticeRetrieveGlobalRateMatrix",
				"Instrument.callNoticeRetrieveGlobalRateMatrix");

		newString = Replacer.simpleReplace(newString, "INS_CallNoticeRetrieveLinkedAccounts",
				"Instrument.callNoticeRetrieveLinkedAccounts");

		newString = Replacer.simpleReplace(newString, "INS_CheckVolumeConstraint", "Instrument.checkVolumeConstraint");

		newString = Replacer.simpleReplace(newString, "INS_CreateCallNoticeFromInsAndCashFlowDate",
				"Instrument.createCallNoticeFromInsAndCashFlowDate");

		newString = Replacer.simpleReplace(newString, "INS_GenerateCallNoticeInterestPayment",
				"Instrument.generateCallNoticeInterestPayment");

		newString = Replacer.simpleReplace(newString, "INS_GenerateCallNoticeMovementReport",
				"Instrument.generateCallNoticeMovementReport");

		newString = Replacer.simpleReplace(newString, "INS_GetBaseInsType", "Instrument.getBaseInsType");

		newString = Replacer.simpleReplace(newString, "INS_InsertComponentData", "Instrument.insertComponentData");

		newString = Replacer.simpleReplace(newString, "INS_IsNull", "Instrument.isNull");

		newString = Replacer.simpleReplace(newString, "INS_Retrieve", "Instrument.retrieve");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveCallNoticeNoticeDateBalance",
				"Instrument.retrieveCallNoticeNoticeDateBalance");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveCallNoticeSettleDateAccountRate",
				"Instrument.retrieveCallNoticeSettleDateAccountRate");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveCallNoticeSettleDateBalance",
				"Instrument.retrieveCallNoticeSettleDateBalance");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveCallNoticeSpecifiedDateAccountRate",
				"Instrument.retrieveCallNoticeSpecifiedDateAccountRate");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveCallNoticeSpecifiedDateBalance",
				"Instrument.retrieveCallNoticeSpecifiedDateBalance");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveCopy", "Instrument.retrieveCopy");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveIssueProceeds", "Instrument.retrieveIssueProceeds");

		newString = Replacer.simpleReplace(newString, "INS_RetrieveSymbolicMaturityDate",
				"Instrument.retrieveSymbolicMaturityDate");

		newString = Replacer.simpleReplace(newString, "INS_TableToOption", "Instrument.tableToOption");

		newString = Replacer.simpleReplace(newString, "INS_TableToParam", "Instrument.tableToParam");

		newString = Replacer.simpleReplace(newString, "INS_TableToPhyscash", "Instrument.tableToPhyscash");

		newString = Replacer.simpleReplace(newString, "INS_TableToProfile", "Instrument.tableToProfile");

		newString = Replacer.simpleReplace(newString, "INS_TableToReset", "Instrument.tableToReset");

		newString = Replacer.simpleReplace(newString, "INS_UpdateOptionOpenEvent", "Instrument.updateOptionOpenEvent");

		newString = Replacer.simpleReplace(newString, "InsertTransferPrice", "Transaction.insertTransferPrice");

		newString = Replacer.simpleReplace(newString, "IntToDouble", "Math.intToDouble");

		newString = Replacer.simpleReplace(newString, "is_commodity_index", "Index.isCommodityIndex");

		newString = Replacer.simpleReplace(newString, "LinkDealToComposer", "Transaction.linkDealToComposer");

		newString = Replacer.simpleReplace(newString, "map_phys_delivery_date_to_pump_date",
				"Transaction.mapphysDeliveryDateToPumpDate");

		newString = Replacer.simpleReplace(newString, "MATH_CalcBV", "Transaction.mathCalcBV");

		newString = Replacer.simpleReplace(newString, "MATH_CalcBVByPymt", "Transaction.mathCalcBVByPymt");

		newString = Replacer.simpleReplace(newString, "MATH_CalcCompoundedRate", "Math.mathCalcCompoundedRate");

		newString = Replacer.simpleReplace(newString, "MATH_Exp", "Math.mathExp");

		newString = Replacer.simpleReplace(newString, "MATH_IsFinite", "Math.mathIsFinite");

		newString = Replacer.simpleReplace(newString, "MATH_LinearInterp", "Math.mathLinearInterp");

		newString = Replacer.simpleReplace(newString, "MATH_Log", "Math.mathLog");

		newString = Replacer.simpleReplace(newString, "MATH_Log10", "Math.mathLog10");

		newString = Replacer.simpleReplace(newString, "MATH_LogLinearInterp", "Math.mathLogLinearInterp");

		newString = Replacer.simpleReplace(newString, "MATH_Normal", "Math.mathNormal");

		newString = Replacer.simpleReplace(newString, "MATH_Power", "Math.mathPower");

		newString = Replacer.simpleReplace(newString, "max", "Math.max");

		newString = Replacer.simpleReplace(newString, "MDD_RetrieveData", "Index.mddRetrieveData");

		newString = Replacer.simpleReplace(newString, ".*\\bmin\\b.*", "Math.min");

		newString = Replacer.simpleReplace(newString, "minute_is_in_bitmap", "Power.minuteisInBitmap");

		newString = Replacer.simpleReplace(newString, "MKTD_Cleanup", "Sim.cleanup");

		newString = Replacer.simpleReplace(newString, "MKTD_CreateMktdTable", "Sim.createMktdTable");

		newString = Replacer.simpleReplace(newString, "MKTD_GatherPrices", "Sim.gatherPrices");

		newString = Replacer.simpleReplace(newString, "MKTD_GetPfolio", "Sim.getPfolio");

		newString = Replacer.simpleReplace(newString, "MKTD_InsertMarginCashTrades", "Sim.insertMarginCashTrades");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadAllCloseMdoMktd", "Sim.loadAllCloseMdoMktd");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadAllCloseMktd", "Sim.loadAllCloseMktd");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadAllMdoMktd", "Sim.loadAllMdoMktd");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadAllMktd", "Sim.loadAllMktd");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadCloseIndexList", "Sim.loadCloseIndexList");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadCloseMdoMktdForIndex", "Sim.loadCloseMdoMktdForIndex");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadIndexList", "Sim.loadIndexList");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadMarginCallDataByQid", "Sim.loadMarginCallDataByQid");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadMdoMktdForIndex", "Sim.loadMdoMktdForIndex");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadMktdByQid", "Sim.loadMktdByQid");

		newString = Replacer.simpleReplace(newString, "MKTD_LoadPersonalIndexList", "Sim.loadPersonalIndexList");

		newString = Replacer.simpleReplace(newString, "MKTD_PrepareForReval", "Sim.prepareForReval");

		newString = Replacer.simpleReplace(newString, "MKTD_PrepareForRevalBySimDef", "Sim.prepareForRevalBySimDef");

		newString = Replacer.simpleReplace(newString, "MKTD_UndoMarginCashByQid", "Sim.undoMarginCashByQid");

		newString = Replacer.simpleReplace(newString, "MQ_GetData", "MQSeries.getData");

		newString = Replacer.simpleReplace(newString, "MQ_GetQueueMgr", "MQSeries.getQueueMgr");

		newString = Replacer.simpleReplace(newString, "MQ_Init", "MQSeries.init");

		newString = Replacer.simpleReplace(newString, "MQ_PutData", "MQSeries.putData");

		newString = Replacer.simpleReplace(newString, "NERC_EndurIDFromPublishedID", "ETag.endurIDFromPublishedID");

		newString = Replacer.simpleReplace(newString, "NERC_PublishedIDFromEndurID", "ETag.publishedIDFromEndurID");

		newString = Replacer.simpleReplace(newString, "NERC_RetreiveTable", "ETag.retrieveTable");

		newString = Replacer.simpleReplace(newString, "NETBACK_ExtractCreate", "NetbackExtract.create");

		newString = Replacer.simpleReplace(newString, "NETBACK_ExtractPurge", "NetbackExtract.purge");

		newString = Replacer.simpleReplace(newString, "NETBACK_ExtractQueryAddInfoField",
				"NetbackExtract.queryAddInfoField");

		newString = Replacer.simpleReplace(newString, "NETBACK_ExtractQueryAddProdMonth",
				"NetbackExtract.queryAddProdMonth");

		newString = Replacer.simpleReplace(newString, "NETBACK_ExtractQueryCreate", "NetbackExtract.queryCreate");

		newString = Replacer.simpleReplace(newString, "NETBACK_ExtractQueryDestroy", "NetbackExtract.queryDestroy");

		newString = Replacer.simpleReplace(newString, "NGL_CommProcessGeneration_CreateTable",
				"ProcessingModel.nglCommProcessGenerationCreateTable");

		newString = Replacer.simpleReplace(newString, "NGL_CommProcessGeneration_CreateTable_AddFee",
				"ProcessingModel.nglCommProcessGenerationCreateTableAddFee");

		newString = Replacer.simpleReplace(newString, "NGL_CommProcessGeneration_CreateTable_AddInlet",
				"ProcessingModel.nglCommProcessGenerationCreateTableAddInlet");

		newString = Replacer.simpleReplace(newString, "NGL_CommProcessGeneration_CreateTable_AddOutlet",
				"ProcessingModel.nglCommProcessGenerationCreateTableAddOutlet");

		newString = Replacer.simpleReplace(newString, "NGL_CommProcessGeneration_CreateTransaction",
				"ProcessingModel.nglCommProcessGenerationCreateTransaction");

		newString = Replacer.simpleReplace(newString, "NGL_ComponentAnalysisTable_MapFromModelSimKoptTable",
				"ProcessingModel.nglComponentAnalysisTableMapFromModelSimKoptTable");

		newString = Replacer.simpleReplace(newString, "NGL_CreateCommProcFromModelData",
				"ProcessingModel.nglCreateCommProcFromModelData");

		newString = Replacer.simpleReplace(newString, "NGL_LoadAutoSimPlantTable",
				"ProcessingModel.nglLoadAutoSimPlantTable");

		newString = Replacer.simpleReplace(newString, "NGL_ModelSimSave", "ProcessingModel.nglModelSimSave");

		newString = Replacer.simpleReplace(newString, "NGL_PlantInletVolTable_MapFromModelSimFinTable",
				"ProcessingModel.nglPlantInletVolTableMapFromModelSimFinTable");

		newString = Replacer.simpleReplace(newString, "NGL_RetrieveComponentAnalysis",
				"ProcessingModel.nglRetrieveComponentAnalysis");

		newString = Replacer.simpleReplace(newString, "NGL_RetrieveModels", "ProcessingModel.nglRetrieveModels");

		newString = Replacer.simpleReplace(newString, "NGL_RetrievePlantInletVols",
				"ProcessingModel.nglRetrievePlantInletVols");

		newString = Replacer.simpleReplace(newString, "NOM_BookingSetDealGrouping", "NomCreate.setDealGrouping");

		newString = Replacer.simpleReplace(newString, "normal_inverse", "Math.normalinverse");

		newString = Replacer.simpleReplace(newString, "NOTES_AddGeneralField", "NotesDoc.addGeneralField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddHeaderField", "NotesDoc.addHeaderField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddOptionField", "NotesDoc.addOptionField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddParamField", "NotesDoc.addParamField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddParamFieldList", "NotesDoc.addParamFieldList");

		newString = Replacer.simpleReplace(newString, "NOTES_AddPartyField", "NotesDoc.addPartyField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddPhysCashField", "NotesDoc.addPhysCashField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddPhysCashFieldList", "NotesDoc.addPhysCashFieldList");

		newString = Replacer.simpleReplace(newString, "NOTES_AddProfileField", "NotesDoc.addProfileField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddProfileFieldList", "NotesDoc.addProfileFieldList");

		newString = Replacer.simpleReplace(newString, "NOTES_AddResetField", "NotesDoc.addResetField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddResetFieldList", "NotesDoc.addResetFieldList");

		newString = Replacer.simpleReplace(newString, "NOTES_AddTranField", "NotesDoc.addTranField");

		newString = Replacer.simpleReplace(newString, "NOTES_AddTranFieldList", "NotesDoc.addTranFieldList");

		newString = Replacer.simpleReplace(newString, "NOTES_DocInit", "NotesDoc.docInit");

		newString = Replacer.simpleReplace(newString, "NOTES_DocInsert", "NotesDoc.docInsert");

		newString = Replacer.simpleReplace(newString, "NOTES_DocUpdate", "NotesDoc.docUpdate");

		newString = Replacer.simpleReplace(newString, "NOTES_GetBuySell", "NotesDoc.getBuySell");

		newString = Replacer.simpleReplace(newString, "NOTES_GetCurrentTran", "NotesDoc.getCurrentTran");

		newString = Replacer.simpleReplace(newString, "NOTES_GetDailyVolume", "NotesDoc.getDailyVolume");

		newString = Replacer.simpleReplace(newString, "NOTES_GetEventDate", "NotesDoc.getEventDate");

		newString = Replacer.simpleReplace(newString, "NOTES_GetIdxComponent", "NotesDoc.getIdxComponent");

		newString = Replacer.simpleReplace(newString, "NOTES_GetInsSubType", "NotesDoc.getInsSubType");

		newString = Replacer.simpleReplace(newString, "NOTES_GetInsType", "NotesDoc.getInsType");

		newString = Replacer.simpleReplace(newString, "NOTES_GetNumTrans", "NotesDoc.getNumTrans");

		newString = Replacer.simpleReplace(newString, "NOTES_GetOptionPremium", "NotesDoc.getOptionPremium");

		newString = Replacer.simpleReplace(newString, "NOTES_GetOptionPremiumDate", "NotesDoc.getOptionPremiumDate");

		newString = Replacer.simpleReplace(newString, "NOTES_GetPutCall", "NotesDoc.getPutCall");

		newString = Replacer.simpleReplace(newString, "NOTES_GetSwapType", "NotesDoc.getSwapType");

		newString = Replacer.simpleReplace(newString, "NOTES_GetToolset", "NotesDoc.getToolset");

		newString = Replacer.simpleReplace(newString, "NOTES_GetTranDataTable", "NotesDoc.getTranDataTable");

		newString = Replacer.simpleReplace(newString, "NOTES_SetCurrentTran", "NotesDoc.setCurrentTran");

		newString = Replacer.simpleReplace(newString, "NOTES_SetField", "NotesDoc.setField");

		newString = Replacer.simpleReplace(newString, "NOTES_SetFixedSide", "NotesDoc.setFixedSide");

		newString = Replacer.simpleReplace(newString, "NOTES_SetFloatSide", "NotesDoc.setFloatSide");

		newString = Replacer.simpleReplace(newString, "NOTES_SetPaySide", "NotesDoc.setPaySide");

		newString = Replacer.simpleReplace(newString, "NOTES_SetReceiveSide", "NotesDoc.setReceiveSide");

		newString = Replacer.simpleReplace(newString, "NOTES_SetRichTextField", "NotesDoc.setRichTextField");

		newString = Replacer.simpleReplace(newString, "NOTES_SetSettleInstToExternal",
				"NotesDoc.setSettleInstToExternal");

		newString = Replacer.simpleReplace(newString, "NOTES_SetSettleInstToInternal",
				"NotesDoc.setSettleInstToInternal");

		newString = Replacer.simpleReplace(newString, "NOTES_SetSide", "NotesDoc.setSide");

		newString = Replacer.simpleReplace(newString, "NOVATION_Accept", "Util.novationAccept");

		newString = Replacer.simpleReplace(newString, "NOVATION_Reject", "Util.novationReject");

		newString = Replacer.simpleReplace(newString, "OC_AbortPushMethod", "ConnexUtility.abortPushMethod");

		newString = Replacer.simpleReplace(newString, "oc_add_hospital_record_DefaultArgs_Wrap",
				"ConnexUtility.addHospitalRecord");

		newString = Replacer.simpleReplace(newString, "OC_AddTokenVal", "ConnexRefMapManager.addTokenVal");

		newString = Replacer.simpleReplace(newString, "OC_ApplyReferenceMapDefinition",
				"ConnexRefMapManager.applyReferenceMapDefinition");

		newString = Replacer.simpleReplace(newString, "OC_ApplyReferenceMapInLine",
				"ConnexRefMapManager.applyReferenceMapInLine");

		newString = Replacer.simpleReplace(newString, "OC_BuildExpDefnExportTable",
				"ConnexGlobalCredit.buildExpDefnExportTable");

		newString = Replacer.simpleReplace(newString, "OC_CreatePropertyImportTable",
				"ConnexUtility.createPropertyImportTable");

		newString = Replacer.simpleReplace(newString, "OC_CreateResponseXML", "ConnexUtility.createResponseXML");

		newString = Replacer.simpleReplace(newString, "OC_CreateTokenValueTbl",
				"ConnexRefMapManager.createTokenValueTbl");

		newString = Replacer.simpleReplace(newString, "OC_CreateTradeBuilder", "ConnexUtility.createTradeBuilder");

		newString = Replacer.simpleReplace(newString, "OC_CreditApplyExternalUpdates",
				"ConnexGlobalCredit.creditApplyExternalUpdates");

		newString = Replacer.simpleReplace(newString, "OC_CreditLineDrillDown",
				"ConnexGlobalCredit.creditLineDrillDown");

		newString = Replacer.simpleReplace(newString, "OC_CreditRiskCheck", "ConnexUtility.creditRiskCheck");

		newString = Replacer.simpleReplace(newString, "OC_CurveInputDataRetrieve",
				"ConnexCurve.curveInputDataRetrieve");

		newString = Replacer.simpleReplace(newString, "OC_CurveOutputDataRetrieve",
				"ConnexCurve.curveOutputDataRetrieve");

		newString = Replacer.simpleReplace(newString, "OC_DefaultAnalysisToTable", "ConnexBiz.defaultAnalysisToTable");

		newString = Replacer.simpleReplace(newString, "OC_DefaultCurveToTable", "ConnexCurve.defaultCurveToTable");

		newString = Replacer.simpleReplace(newString, "OC_DefaultTradeBuilderToTable",
				"ConnexUtility.defaultTradeBuilderToTable");

		newString = Replacer.simpleReplace(newString, "oc_delete_hospital_record_DefaultArgs_Wrap",
				"ConnexUtility.deleteHospitalRecord");

		newString = Replacer.simpleReplace(newString, "OC_DeleteExternalReferenceData",
				"ConnexRefMapManager.deleteExternalReferenceData");

		newString = Replacer.simpleReplace(newString, "OC_DeleteInternalReferenceData",
				"ConnexRefMapManager.deleteInternalReferenceData");

		newString = Replacer.simpleReplace(newString, "OC_DeleteReferenceMapDefinition",
				"ConnexRefMapManager.deleteReferenceMapDefinition");

		newString = Replacer.simpleReplace(newString, "OC_DisableHTMLCharConversion",
				"ConnexUtility.disableHTMLCharConversion");

		newString = Replacer.simpleReplace(newString, "OC_DisableHTMLSpecialCharConversion",
				"ConnexUtility.disableHTMLSpecialCharConversion");

		newString = Replacer.simpleReplace(newString, "OC_ExportExternalReferenceData_DefaultArgs_Wrap",
				"ConnexRefMapManager.exportExternalReferenceData");

		newString = Replacer.simpleReplace(newString, "OC_ExportGateway_DefaultArgs_Wrap",
				"ConnexUtility.exportGateway");

		newString = Replacer.simpleReplace(newString, "OC_ExportGatewayToFile_DefaultArgs_Wrap",
				"ConnexUtility.exportGatewayToFile");

		newString = Replacer.simpleReplace(newString, "OC_ExportInternalReferenceData_DefaultArgs_Wrap",
				"ConnexRefMapManager.exportInternalReferenceData");

		newString = Replacer.simpleReplace(newString, "OC_GetArgumentColName", "ConnexUtility.getArgumentColName");

		newString = Replacer.simpleReplace(newString, "OC_GetComponentIdForName",
				"ConnexUtility.getComponentIdForName");

		newString = Replacer.simpleReplace(newString, "OC_GetComponentListAsTable",
				"ConnexUtility.getComponentListAsTable");

		newString = Replacer.simpleReplace(newString, "OC_GetCurveId", "ConnexCurve.getCurveId");

		newString = Replacer.simpleReplace(newString, "OC_GetCurveInputDataFieldName",
				"ConnexCurve.getCurveInputDataFieldName");

		newString = Replacer.simpleReplace(newString, "OC_GetCurveInputDataFieldNames",
				"ConnexCurve.getCurveInputDataFieldNames");

		newString = Replacer.simpleReplace(newString, "OC_GetExecutionData", "ConnexUtility.getExecutionData");

		newString = Replacer.simpleReplace(newString, "OC_GetExecutionLog", "ConnexUtility.getExecutionLog");

		newString = Replacer.simpleReplace(newString, "OC_GetJobXml", "ConnexUtility.getJobXml");

		newString = Replacer.simpleReplace(newString, "OC_GetJobXmlAsTable", "ConnexUtility.getJobXmlAsTable");

		newString = Replacer.simpleReplace(newString, "OC_GetObjectAuxData", "ConnexUtility.getObjectAuxData");

		newString = Replacer.simpleReplace(newString, "OC_GetRequestStyleSheet", "ConnexUtility.getRequestStyleSheet");

		newString = Replacer.simpleReplace(newString, "OC_GetReturnStatusTable", "ConnexUtility.getReturnStatusTable");

		newString = Replacer.simpleReplace(newString, "OC_GetStatus", "ConnexUtility.getStatus");

		newString = Replacer.simpleReplace(newString, "OC_GetStatusAll", "ConnexUtility.getStatusAll");

		newString = Replacer.simpleReplace(newString, "OC_GetSystemVirtualReportPath",
				"ConnexUtility.getSystemVirtualReportPath");

		newString = Replacer.simpleReplace(newString, "OC_GetTradeBuilderFieldName",
				"ConnexUtility.getTradeBuilderFieldName");

		newString = Replacer.simpleReplace(newString, "OC_GetTradeBuilderFieldRow",
				"ConnexUtility.getTradeBuilderFieldRow");

		newString = Replacer.simpleReplace(newString, "OC_GetTradeQueryTranNums",
				"ConnexUtility.getTradeQueryTranNums");

		newString = Replacer.simpleReplace(newString, "OC_GetUserData", "ConnexUtility.getUserData");

		newString = Replacer.simpleReplace(newString, "OC_GetUserDataTblOnTran", "ConnexUtility.getUserDataTblOnTran");

		newString = Replacer.simpleReplace(newString, "OC_ImportConfiguration", "ConnexUtility.importConfiguration");

		newString = Replacer.simpleReplace(newString, "OC_ImportExpDefn", "ConnexGlobalCredit.importExpDefn");

		newString = Replacer.simpleReplace(newString, "OC_ImportExternalReferenceData_DefaultArgs_Wrap",
				"ConnexRefMapManager.importExternalReferenceData");

		newString = Replacer.simpleReplace(newString, "OC_ImportGateway", "ConnexUtility.importGateway");

		newString = Replacer.simpleReplace(newString, "OC_ImportGatewayFromFile",
				"ConnexUtility.importGatewayFromFile");

		newString = Replacer.simpleReplace(newString, "OC_ImportInternalReferenceData_DefaultArgs_Wrap",
				"ConnexRefMapManager.importInternalReferenceData");

		newString = Replacer.simpleReplace(newString, "OC_InsertRefMapEntry", "ConnexRefMapManager.insertRefMapEntry");

		newString = Replacer.simpleReplace(newString, "OC_IsCurveInputFieldReadOnly",
				"ConnexCurve.isCurveInputFieldReadOnly");

		newString = Replacer.simpleReplace(newString, "OC_IsCurveOutputFieldReadOnly",
				"ConnexCurve.isCurveOutputFieldReadOnly");

		newString = Replacer.simpleReplace(newString, "OC_IsFieldCurveInputDataPointField",
				"ConnexCurve.isFieldCurveInputDataPointField");

		newString = Replacer.simpleReplace(newString, "OC_IsFieldCurveInputField",
				"ConnexCurve.isFieldCurveInputField");

		newString = Replacer.simpleReplace(newString, "OC_IsFieldCurveOutputField",
				"ConnexCurve.isFieldCurveOutputField");

		newString = Replacer.simpleReplace(newString, "OC_IsMessageHospitalEnabled",
				"ConnexUtility.isMessageHospitalEnabled");

		newString = Replacer.simpleReplace(newString, "OC_IsMethodLicensed", "ConnexUtility.isMethodLicensed");

		newString = Replacer.simpleReplace(newString, "OC_ListRetrieve", "ConnexBiz.listRetrieve");

		newString = Replacer.simpleReplace(newString, "OC_LoadCurveDataLocally", "ConnexCurve.loadCurveDataLocally");

		newString = Replacer.simpleReplace(newString, "OC_MessageHospital", "ConnexUtility.messageHospital");

		newString = Replacer.simpleReplace(newString, "OC_NumErrorsInErrorLog", "ConnexUtility.numErrorsInErrorLog");

		newString = Replacer.simpleReplace(newString, "OC_PartyQuery", "ConnexBiz.partyQuery");

		newString = Replacer.simpleReplace(newString, "OC_PingRunSite", "ConnexUtility.pingRunSite");

		newString = Replacer.simpleReplace(newString, "OC_ProcessUserData", "ConnexUtility.processUserData");

		newString = Replacer.simpleReplace(newString, "OC_PushXml", "ConnexUtility.pushXml");

		newString = Replacer.simpleReplace(newString, "OC_RefreshRTPEPages", "ConnexBiz.refreshRTPEPages");

		newString = Replacer.simpleReplace(newString, "OC_ReportPathToURL", "ConnexUtility.reportPathToURL");

		newString = Replacer.simpleReplace(newString, "OC_RestartGateway", "ConnexUtility.restartGateway");

		newString = Replacer.simpleReplace(newString, "OC_RestartService", "ConnexUtility.restartService");

		newString = Replacer.simpleReplace(newString, "oc_retrieve_hospital_records_DefaultArgs_Wrap",
				"ConnexUtility.retrieveHospitalRecords");

		newString = Replacer.simpleReplace(newString, "OC_RetrieveEngineProperties",
				"ConnexUtility.retrieveEngineProperties");

		newString = Replacer.simpleReplace(newString, "OC_RetrieveErrorLog", "ConnexUtility.retrieveErrorLog");

		newString = Replacer.simpleReplace(newString, "OC_RetrieveGatewayProperties",
				"ConnexUtility.retrieveGatewayProperties");

		newString = Replacer.simpleReplace(newString, "OC_RetrieveMapDefinition",
				"ConnexRefMapManager.retrieveMapDefinition");

		newString = Replacer.simpleReplace(newString, "OC_RetrieveMapDefinitionsByUser_DefaultArgs_Wrap",
				"ConnexRefMapManager.retrieveMapDefinitionsByUser");

		newString = Replacer.simpleReplace(newString, "OC_RetrieveRefMapTokens",
				"ConnexRefMapManager.retrieveRefMapTokens");

		newString = Replacer.simpleReplace(newString, "OC_ReturnTableAsXHTMLReport",
				"ConnexUtility.returnTableAsXHTMLReport");

		newString = Replacer.simpleReplace(newString, "OC_RtpeDrillDown", "ConnexBiz.rtpeDrillDown");

		newString = Replacer.simpleReplace(newString, "OC_RtpeOnlinePageDetails", "ConnexBiz.rtpeOnlinePageDetails");

		newString = Replacer.simpleReplace(newString, "OC_SaveReferenceMapDefinition",
				"ConnexRefMapManager.saveReferenceMapDefinition");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetClusterID", "ConnexUtility.scriptGetClusterID");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetClusterName", "ConnexUtility.scriptGetClusterName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetDbName", "ConnexUtility.scriptGetDbName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetDbServerName",
				"ConnexUtility.scriptGetDbServerName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionErrorCode",
				"ConnexUtility.scriptGetMethodExceptionErrorCode");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionErrorMessage",
				"ConnexUtility.scriptGetMethodExceptionErrorMessage");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionHospitalStatus",
				"ConnexUtility.scriptGetMethodExceptionHospitalStatus");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionMessageId",
				"ConnexUtility.scriptGetMethodExceptionMessageId");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionMessageSubId",
				"ConnexUtility.scriptGetMethodExceptionMessageSubId");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionMethodName",
				"ConnexUtility.scriptGetMethodExceptionMethodName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionMethodPhase",
				"ConnexUtility.scriptGetMethodExceptionMethodPhase");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionSenderId",
				"ConnexUtility.scriptGetMethodExceptionSenderId");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetMethodExceptionTable",
				"ConnexUtility.scriptGetMethodExceptionTable");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestArgTable",
				"ConnexUtility.scriptGetRequestArgTable");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestClientID",
				"ConnexUtility.scriptGetRequestClientID");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestClientMethodID",
				"ConnexUtility.scriptGetRequestClientMethodID");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestClientMethodTag",
				"ConnexUtility.scriptGetRequestClientMethodTag");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestClientTag",
				"ConnexUtility.scriptGetRequestClientTag");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestDetailsTable",
				"ConnexUtility.scriptGetRequestDetailsTable");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestGatewayGroupName",
				"ConnexUtility.scriptGetRequestGatewayGroupName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestGatewayInstanceName",
				"ConnexUtility.scriptGetRequestGatewayInstanceName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestGatewayName",
				"ConnexUtility.scriptGetRequestGatewayName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestJobID",
				"ConnexUtility.scriptGetRequestJobID");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestMethodClassName",
				"ConnexUtility.scriptGetRequestMethodClassName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestMethodConnections",
				"ConnexUtility.scriptGetRequestMethodConnections");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestMethodDisableDatatypeFlag",
				"ConnexUtility.scriptGetRequestMethodDisableDatatypeFlag");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestMethodID",
				"ConnexUtility.scriptGetRequestMethodID");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestMethodName",
				"ConnexUtility.scriptGetRequestMethodName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestMethodProcessPartyCodesFlag",
				"ConnexUtility.scriptGetRequestMethodProcessPartyCodesFlag");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestSenderID",
				"ConnexUtility.scriptGetRequestSenderID");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestSenderName",
				"ConnexUtility.scriptGetRequestSenderName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestSrcInfoTable",
				"ConnexUtility.scriptGetRequestSrcInfoTable");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestStyleSheet",
				"ConnexUtility.scriptGetRequestStyleSheet");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestUserName",
				"ConnexUtility.scriptGetRequestUserName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetRequestXml", "ConnexUtility.scriptGetRequestXml");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetServerNodeID",
				"ConnexUtility.scriptGetServerNodeID");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetServerNodeName",
				"ConnexUtility.scriptGetServerNodeName");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetTran", "ConnexUtility.scriptGetTran");

		newString = Replacer.simpleReplace(newString, "OC_Script_GetXmlEngineID", "ConnexUtility.scriptGetXmlEngineID");

		newString = Replacer.simpleReplace(newString, "OC_Script_HasMethodPostProcess",
				"ConnexUtility.scriptHasMethodPostProcess");

		newString = Replacer.simpleReplace(newString, "OC_Script_HasMethodPreProcess",
				"ConnexUtility.scriptHasMethodPreProcess");

		newString = Replacer.simpleReplace(newString, "OC_Script_IsThereAMethodException",
				"ConnexUtility.scriptIsThereAMethodException");

		newString = Replacer.simpleReplace(newString, "OC_Script_SetTran", "ConnexUtility.scriptSetTran");

		newString = Replacer.simpleReplace(newString, "OC_SendJobStatus", "ConnexUtility.sendJobStatus");

		newString = Replacer.simpleReplace(newString, "OC_SendMsgHospitalRequest",
				"ConnexUtility.sendMsgHospitalRequest");

		newString = Replacer.simpleReplace(newString, "OC_SetCurrentDateLocally", "ConnexBiz.setCurrentDateLocally");

		newString = Replacer.simpleReplace(newString, "OC_SetObjectAuxData", "ConnexUtility.setObjectAuxData");

		newString = Replacer.simpleReplace(newString, "OC_SetReturnStatus", "ConnexUtility.setReturnStatus");

		newString = Replacer.simpleReplace(newString, "OC_SetReturnTable", "ConnexUtility.setReturnTable");

		newString = Replacer.simpleReplace(newString, "OC_SetReturnXml", "ConnexUtility.setReturnXml");

		newString = Replacer.simpleReplace(newString, "OC_SetUserDataTblOnTran", "ConnexUtility.setUserDataTblOnTran");

		newString = Replacer.simpleReplace(newString, "OC_SetXMLNameSpaceOnTable",
				"ConnexUtility.setXMLNameSpaceOnTable");

		newString = Replacer.simpleReplace(newString, "OC_StartGateway", "ConnexUtility.startGateway");

		newString = Replacer.simpleReplace(newString, "OC_StartService", "ConnexUtility.startService");

		newString = Replacer.simpleReplace(newString, "OC_StopGateway", "ConnexUtility.stopGateway");

		newString = Replacer.simpleReplace(newString, "OC_StopService", "ConnexUtility.stopService");

		newString = Replacer.simpleReplace(newString, "OC_TableToHTML", "ConnexUtility.tableToHTML");

		newString = Replacer.simpleReplace(newString, "OC_TradeBuilderGetField", "ConnexUtility.tradeBuilderGetField");

		newString = Replacer.simpleReplace(newString, "OC_TradeBuilderGetFieldDouble",
				"ConnexUtility.tradeBuilderGetFieldDouble");

		newString = Replacer.simpleReplace(newString, "OC_TradeBuilderGetFieldInt",
				"ConnexUtility.tradeBuilderGetFieldInt");

		newString = Replacer.simpleReplace(newString, "OC_TradeBuilderGetTemplateTickerName",
				"ConnexUtility.tradeBuilderGetTemplateTickerName");

		newString = Replacer.simpleReplace(newString, "OC_TradeBuilderToTran", "ConnexUtility.tradeBuilderToTran");

		newString = Replacer.simpleReplace(newString, "OC_TriggerGateway", "ConnexUtility.triggerGateway");

		newString = Replacer.simpleReplace(newString, "OC_TriggerPush", "ConnexUtility.triggerPush");

		newString = Replacer.simpleReplace(newString, "OC_ValidateClasspathForGateway",
				"ConnexUtility.validateClasspathForGateway");

		newString = Replacer.simpleReplace(newString, "OCRetrieveMappedID", "ConnexRefMapManager.oCRetrieveMappedID");

		newString = Replacer.simpleReplace(newString, "OCRetrieveMappedValue",
				"ConnexRefMapManager.oCRetrieveMappedValue");

		newString = Replacer.simpleReplace(newString, "OPRISK_DeleteAssessment", "OpRisk.deleteAssessment");

		newString = Replacer.simpleReplace(newString, "OPRISK_DeleteModel", "OpRisk.deleteModel");

		newString = Replacer.simpleReplace(newString, "OPRISK_DeleteSimulation", "OpRisk.deleteSimulation");

		newString = Replacer.simpleReplace(newString, "OPRISK_QueryForTrans", "OpRisk.queryForTrans");

		newString = Replacer.simpleReplace(newString, "OPRISK_RetrieveAssessmentData", "OpRisk.retrieveAssessmentData");

		newString = Replacer.simpleReplace(newString, "OPRISK_RetrieveKRISensitivity", "OpRisk.retrieveKRISensitivity");

		newString = Replacer.simpleReplace(newString, "OPRISK_RetrieveLossExposureData",
				"OpRisk.retrieveLossExposureData");

		newString = Replacer.simpleReplace(newString, "OPRISK_RetrieveLossInputData", "OpRisk.retrieveLossInputData");

		newString = Replacer.simpleReplace(newString, "OPRISK_RetrieveModelParameters",
				"OpRisk.retrieveModelParameters");

		newString = Replacer.simpleReplace(newString, "OPRISK_RetrieveSimulationData", "OpRisk.retrieveSimulationData");

		newString = Replacer.simpleReplace(newString, "OPRISK_RetrieveTrainingData", "OpRisk.retrieveTrainingData");

		newString = Replacer.simpleReplace(newString, "OPRISK_RunAndSaveAssessment", "OpRisk.runAndSaveAssessment");

		newString = Replacer.simpleReplace(newString, "OPRISK_RunAndSaveSimulation", "OpRisk.runAndSaveSimulation");

		newString = Replacer.simpleReplace(newString, "OPRISK_RunAssessment", "OpRisk.runAssessment");

		newString = Replacer.simpleReplace(newString, "OPRISK_RunAssessmentList", "OpRisk.runAssessmentList");

		newString = Replacer.simpleReplace(newString, "OPRISK_TrainModel", "OpRisk.trainModel");

		newString = Replacer.simpleReplace(newString, "OPS_Service_Fail", "OpService.serviceFail");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_AddCustomLogEntry", "OpService.addCustomLogEntry");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_CreateAllTranProcessTable",
				"OpService.createAllTranProcessTable");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_GetLogFields", "OpService.getLogFields");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_GetLogId", "OpService.getLogId");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_LoadPostProcessingLog",
				"OpService.loadPostProcessingLog");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_LoadServicesInfo", "OpService.loadServicesInfo");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_PostProcessWait", "OpService.postProcessWait");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_ResumeMonitoring", "OpService.resumeMonitoring");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_RetrieveCustomLogEntryArgTable",
				"OpService.retrieveCustomLogEntryArgTable");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_RunPostProcess", "OpService.runPostProcess");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_SetComplete", "OpService.setComplete");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_SetIncomplete", "OpService.setIncomplete");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_SetUserFieldByLogId", "OpService.setUserFieldByLogId");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_SetUserFieldsByItem", "OpService.setUserFieldsByItem");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_SetUserFieldsByLogId",
				"OpService.setUserFieldsByLogId");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_StartMonitoring", "OpService.startMonitoring");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_StopMonitoring", "OpService.stopMonitoring");

		newString = Replacer.simpleReplace(newString, "OPSERVICE_SuspendMonitoring", "OpService.suspendMonitoring");

		newString = Replacer.simpleReplace(newString, "option_on_ins_type", "Instrument.optionOnInsType");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_DeleteCashEvent", "OutboundDoc.deleteCashEvent");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_DocInit", "OutboundDoc.docInit");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_DocInsert", "OutboundDoc.docInsert");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_DocUpdate", "OutboundDoc.docUpdate");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_GetRelatedDocNum", "OutboundDoc.getRelatedDocNum");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_GetRelatedMessageId",
				"OutboundDoc.getRelatedMessageId");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_GetTranDataTable", "OutboundDoc.getTranDataTable");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_ProcessPending", "OutboundDoc.processPending");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_ProcessSTPExceptions",
				"OutboundDoc.processSTPExceptions");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_ReleaseEvent", "OutboundDoc.releaseEvent");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_Send", "OutboundDoc.send");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_SetField", "OutboundDoc.setField");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_SetRichTextField", "OutboundDoc.setRichTextField");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_UpdateDocStatusConf",
				"OutboundDoc.updateDocStatusConf");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_UpdateDocStatusPymt",
				"OutboundDoc.updateDocStatusPymt");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_UpdateStatus", "OutboundDoc.updateStatus");

		newString = Replacer.simpleReplace(newString, "PAGEVIEW_Start", "Positions.pageViewerStart");

		newString = Replacer.simpleReplace(newString, "party_long_name", "Ref.getPartyLongName");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsOwnerImbalanceImportTable_Create",
				"ProdServ.psOwnerImbalanceImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsOwnerImbalanceImportTable_Import",
				"ProdServ.psOwnerImbalanceImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityDetailImportTable_Create",
				"ProdServ.psQualityDetailImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityDetailImportTable_Import",
				"ProdServ.psQualityDetailImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityHeaderImportTable_Create",
				"ProdServ.psQualityHeaderImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityHeaderImportTable_Import",
				"ProdServ.psQualityHeaderImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Import",
				"ProdServ.psWellheadComponentImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadCtpImportTable_Create",
				"ProdServ.psWellheadCtpImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadCtpImportTable_Import",
				"ProdServ.psWellheadCtpImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadEntitlementImportTable_Create",
				"ProdServ.psWellheadEntitlementImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadEntitlementImportTable_Import",
				"ProdServ.psWellheadEntitlementImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadImportTable_Create",
				"ProdServ.psWellheadImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadImportTable_Import",
				"ProdServ.psWellheadImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadReservesImportTable_Create",
				"ProdServ.psWellheadReservesImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadReservesImportTable_Import",
				"ProdServ.psWellheadReservesImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadStatusImportTable_Create",
				"ProdServ.psWellheadStatusImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadStatusImportTable_Import",
				"ProdServ.psWellheadStatusImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadVolumeAdjImportTable_Create",
				"ProdServ.psWellheadVolumeAdjImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadVolumeAdjImportTable_Import",
				"ProdServ.psWellheadVolumeAdjImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadVolumeImportTable_Create",
				"ProdServ.psWellheadVolumeImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadVolumeImportTable_Import",
				"ProdServ.psWellheadVolumeImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_SetLocationVolumeAdjustment",
				"ProdServ.setLocationVolumeAdjustment");

		newString = Replacer.simpleReplace(newString, "ProdVolumeMgmt_AddRow", "ProdVolumeMgmt.addRow");

		newString = Replacer.simpleReplace(newString, "ProdVolumeMgmt_CreateData", "ProdVolumeMgmt.createData");

		newString = Replacer.simpleReplace(newString, "ProdVolumeMgmt_CreateQueryData",
				"ProdVolumeMgmt.createQueryData");

		newString = Replacer.simpleReplace(newString, "ProdVolumeMgmt_DestroyData", "ProdVolumeMgmt.destroyData");

		newString = Replacer.simpleReplace(newString, "ProdVolumeMgmt_DestroyQueryData",
				"ProdVolumeMgmt.destroyQueryData");

		newString = Replacer.simpleReplace(newString, "ProdVolumeMgmt_Process", "ProdVolumeMgmt.process");

		newString = Replacer.simpleReplace(newString, "ProdVolumeMgmt_QueryData", "ProdVolumeMgmt.queryData");

		newString = Replacer.simpleReplace(newString, "PUBLISH_Global", "Services.publishGlobal");

		newString = Replacer.simpleReplace(newString, "PUBLISH_Local", "Services.publishLocal");

		newString = Replacer.simpleReplace(newString, "PURGE_DatabaseData", "DataMaint.databaseData");

		newString = Replacer.simpleReplace(newString, "PURGE_IsPurgeValid", "DataMaint.isPurgeValid");

		newString = Replacer.simpleReplace(newString, "PURGE_PurgeAmendedIdxDef", "DataMaint.purgeAmendedIdxDef");

		newString = Replacer.simpleReplace(newString, "PURGE_PurgeDeletedIdxDef", "DataMaint.purgeDeletedIdxDef");

		newString = Replacer.simpleReplace(newString, "PURGE_PurgeIdxClosingData", "DataMaint.purgeIdxClosingData");

		newString = Replacer.simpleReplace(newString, "PV_quick_bs", "Reval.pvquickBs");

		newString = Replacer.simpleReplace(newString, "REF_AddNewAccount", "Ref.addNewAccount");

		newString = Replacer.simpleReplace(newString, "REF_AddNewParty", "Ref.addNewParty");

		newString = Replacer.simpleReplace(newString, "REF_AddNewSettleInstruction", "Ref.addNewSettleInstruction");

		newString = Replacer.simpleReplace(newString, "REF_AmIConnex", "Ref.amIConnex");

		newString = Replacer.simpleReplace(newString, "REF_AmIScreng", "Ref.amIScreng");

		newString = Replacer.simpleReplace(newString, "REF_AmITpm", "Ref.amITpm");

		newString = Replacer.simpleReplace(newString, "REF_ChangePartyDefaultAddress", "Ref.changePartyDefaultAddress");

		newString = Replacer.simpleReplace(newString, "REF_CopyPersonnel", "Ref.copyPersonnel");

		newString = Replacer.simpleReplace(newString, "REF_CreateMeasurementDataImportTable",
				"Ref.createMeasurementDataImportTable");

		newString = Replacer.simpleReplace(newString, "REF_CreateParty", "Ref.createParty");

		newString = Replacer.simpleReplace(newString, "REF_CreatePartyAgreementTable", "Ref.createPartyAgreementTable");

		newString = Replacer.simpleReplace(newString, "REF_CreatePortfolio", "Ref.createPortfolio");

		newString = Replacer.simpleReplace(newString, "REF_DeletePartyNote", "Ref.deletePartyNote");

		newString = Replacer.simpleReplace(newString, "REF_ExportEnergyDataToFile", "Ref.exportEnergyDataToFile");

		newString = Replacer.simpleReplace(newString, "REF_ExportEnergyDataToTable", "Ref.exportEnergyDataToTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportIndexLocationDataToFile",
				"Ref.exportIndexLocationDataToFile");

		newString = Replacer.simpleReplace(newString, "REF_ExportIndexLocationDataToTable",
				"Ref.exportIndexLocationDataToTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportParties", "Ref.exportParties");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyAgreementTable", "Ref.exportPartyAgreementTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyAgreementTableAll",
				"Ref.exportPartyAgreementTableAll");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyTable", "Ref.exportPartyTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyTableAll", "Ref.exportPartyTableAll");

		newString = Replacer.simpleReplace(newString, "REF_ExportPricingModelAttributes",
				"Ref.exportPricingModelAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ExportPricingModelConfigurations",
				"Ref.exportPricingModelConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ExportPricingModelDefinitions",
				"Ref.exportPricingModelDefinitions");

		newString = Replacer.simpleReplace(newString, "REF_ExportSimResultConfigurations",
				"Ref.exportSimResultConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ExportSimulationResultAttributes",
				"Ref.exportSimulationResultAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ExportUserDefinedInsTypes", "Ref.exportUserDefinedInsTypes");

		newString = Replacer.simpleReplace(newString, "REF_ExportUserDefinedSimResults",
				"Ref.exportUserDefinedSimResults");

		newString = Replacer.simpleReplace(newString, "REF_GetDeliveryTypeFromEventType",
				"Ref.getDeliveryTypeFromEventType");

		newString = Replacer.simpleReplace(newString, "REF_GetEventTypeFromDeliveryType",
				"Ref.getEventTypeFromDeliveryType");

		newString = Replacer.simpleReplace(newString, "REF_GetInfo", "Ref.getInfo");

		newString = Replacer.simpleReplace(newString, "REF_GetInsClassFromInsType", "Ref.getInsClassFromInsType");

		newString = Replacer.simpleReplace(newString, "REF_GetInsClassFromToolset", "Ref.getInsClassFromToolset");

		newString = Replacer.simpleReplace(newString, "REF_GetLicenseData", "Ref.getLicenseData");

		newString = Replacer.simpleReplace(newString, "REF_GetLocalCurrency", "Ref.getLocalCurrency");

		newString = Replacer.simpleReplace(newString, "REF_GetModuleId", "Ref.getModuleId");

		newString = Replacer.simpleReplace(newString, "REF_GetModuleName", "Ref.getModuleName");

		newString = Replacer.simpleReplace(newString, "REF_GetName", "Ref.getName");

		newString = Replacer.simpleReplace(newString, "REF_GetProcessId", "Ref.getProcessId");

		newString = Replacer.simpleReplace(newString, "REF_GetToolsetFromInsType", "Ref.getToolsetFromInsType");

		newString = Replacer.simpleReplace(newString, "REF_GetUserId", "Ref.getUserId");

		newString = Replacer.simpleReplace(newString, "REF_GetUserName", "Ref.getUserName");

		newString = Replacer.simpleReplace(newString, "REF_GetValue", "Ref.getValue");

		newString = Replacer.simpleReplace(newString, "REF_GetVersion", "Ref.getVersion");

		newString = Replacer.simpleReplace(newString, "REF_ImportEnergyDataFromFile", "Ref.importEnergyDataFromFile");

		newString = Replacer.simpleReplace(newString, "REF_ImportEnergyDataFromTable", "Ref.importEnergyDataFromTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportIndexLocationDataFromFile",
				"Ref.importIndexLocationDataFromFile");

		newString = Replacer.simpleReplace(newString, "REF_ImportIndexLocationDataFromTable",
				"Ref.importIndexLocationDataFromTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportMeasurementDataFromFile",
				"Ref.importMeasurementDataFromFile");

		newString = Replacer.simpleReplace(newString, "REF_ImportMeasurementDataFromTable",
				"Ref.importMeasurementDataFromTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportPartyAgreementTable", "Ref.importPartyAgreementTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportPartyTable", "Ref.importPartyTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportPricingModelAttributes",
				"Ref.importPricingModelAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ImportPricingModelConfigurations",
				"Ref.importPricingModelConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ImportPricingModelDefinitions",
				"Ref.importPricingModelDefinitions");

		newString = Replacer.simpleReplace(newString, "REF_ImportSimResultConfigurations",
				"Ref.importSimResultConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ImportSimulationResultAttributes",
				"Ref.importSimulationResultAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ImportUserDefinedInsTypes", "Ref.importUserDefinedInsTypes");

		newString = Replacer.simpleReplace(newString, "REF_ImportUserDefinedSimResults",
				"Ref.importUserDefinedSimResults");

		newString = Replacer.simpleReplace(newString, "REF_IsOptionInsType", "Ref.isOptionInsType");

		newString = Replacer.simpleReplace(newString, "REF_LinkAccountToParty", "Ref.linkAccountToParty");

		newString = Replacer.simpleReplace(newString, "REF_LinkPortfolioToParty", "Ref.linkPortfolioToParty");

		newString = Replacer.simpleReplace(newString, "REF_LinkPortfolioToPortfolioGroup",
				"Ref.linkPortfolioToPortfolioGroup");

		newString = Replacer.simpleReplace(newString, "REF_LinkSettleInstructionToParty",
				"Ref.linkSettleInstructionToParty");

		newString = Replacer.simpleReplace(newString, "REF_MoveLegalEntityAndLinkedBUs",
				"Ref.moveLegalEntityAndLinkedBUs");

		newString = Replacer.simpleReplace(newString, "REF_MoveParty", "Ref.moveParty");

		newString = Replacer.simpleReplace(newString, "REF_NewPortfolioTable", "Ref.newPortfolioTable");

		newString = Replacer.simpleReplace(newString, "REF_PipelineIdToRegionId", "Ref.pipelineIdToRegionId");

		newString = Replacer.simpleReplace(newString, "REF_RetrieveAccount", "Ref.retrieveAccount");

		newString = Replacer.simpleReplace(newString, "REF_RetrieveParty", "Ref.retrieveParty");

		newString = Replacer.simpleReplace(newString, "REF_RetrievePersonnel", "Ref.retrievePersonnel");

		newString = Replacer.simpleReplace(newString, "REF_RetrievePersonnelTable", "Ref.retrievePersonnelTable");

		newString = Replacer.simpleReplace(newString, "REF_RetrievePortfolio", "Ref.retrievePortfolio");

		newString = Replacer.simpleReplace(newString, "REF_RetrieveSettleInstruction", "Ref.retrieveSettleInstruction");

		newString = Replacer.simpleReplace(newString, "REF_SavePartyAgreementDocument",
				"Ref.savePartyAgreementDocument");

		newString = Replacer.simpleReplace(newString, "REF_SavePartyNote", "Ref.savePartyNote");

		newString = Replacer.simpleReplace(newString, "REF_SavePersonnel", "Ref.savePersonnel");

		newString = Replacer.simpleReplace(newString, "REF_UnLinkAccountFromParty", "Ref.unLinkAccountFromParty");

		newString = Replacer.simpleReplace(newString, "REF_UnlinkPortfolioFromParty", "Ref.unlinkPortfolioFromParty");

		newString = Replacer.simpleReplace(newString, "REF_UnlinkPortfolioFromPortfolioGroup",
				"Ref.unlinkPortfolioFromPortfolioGroup");

		newString = Replacer.simpleReplace(newString, "REF_UnLinkSettleInstructionFromParty",
				"Ref.unLinkSettleInstructionFromParty");

		newString = Replacer.simpleReplace(newString, "REF_UpdateAccount", "Ref.updateAccount");

		newString = Replacer.simpleReplace(newString, "REF_UpdateParty", "Ref.updateParty");

		newString = Replacer.simpleReplace(newString, "REF_UpdatePersonnelStatus", "Ref.updatePersonnelStatus");

		newString = Replacer.simpleReplace(newString, "REF_UpdatePortfolio", "Ref.updatePortfolio");

		newString = Replacer.simpleReplace(newString, "REF_UpdateSettleInstruction", "Ref.updateSettleInstruction");

		newString = Replacer.simpleReplace(newString, "shm_get_index_currency", "Index.shmgetIndexCurrency");

		newString = Replacer.simpleReplace(newString, "SIM_AddAccrueToThroughConfig", "Sim.addAccrueToThroughConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddBaseScenario", "Sim.addBaseScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddBondAccruesBeforeSettlementConfig",
				"Sim.addBondAccruesBeforeSettlementConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorMap", "Sim.addCorMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorMod", "Sim.addCorMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorModByGpt", "Sim.addCorModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorVegaShiftModByGpt", "Sim.addCorVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorVegaShiftMod", "Sim.addCorVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddDeltaShiftModByGpt", "Sim.addDeltaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddDeltaShiftMod", "Sim.addDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddEuroConfig", "Sim.addEuroConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddFXModByCcy", "Sim.addFXModByCcy");

		newString = Replacer.simpleReplace(newString, "SIM_AddFXMod", "Sim.addFXMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddHorizonDateMod", "Sim.addHorizonDateMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexEffectiveModByGpt", "Sim.addIndexEffectiveModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexEffectiveMod", "Sim.addIndexEffectiveMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexInheritanceConfig", "Sim.addIndexInheritanceConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexMap", "Sim.addIndexMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexModByGpt", "Sim.addIndexModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexMod", "Sim.addIndexMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexOutputConfig", "Sim.addIndexOutputConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexOutputModByDate", "Sim.addIndexOutputModByDate");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexOutputMod", "Sim.addIndexOutputMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexParentMap", "Sim.addIndexParentMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddMarketPxIndexConfig", "Sim.addMarketPxIndexConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddMCarloConfig", "Sim.addMCarloConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddOutputDeltaShiftMod", "Sim.addOutputDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddPricingModelConfig", "Sim.addPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddPricingModelMap", "Sim.addPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddPricingModelMap", "Sim.addPricingModelMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddPriorSimResultConfig", "Sim.addPriorSimResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultCol", "Sim.addResultCol");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultConfig", "Sim.addResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultGroupListToScenario",
				"Sim.addResultGroupListToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultGroupToScenario", "Sim.addResultGroupToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultListToScenario", "Sim.addResultListToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultToScenario", "Sim.addResultToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddScenarioMod", "Sim.addScenarioMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddScenario", "Sim.addScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddSimulation", "Sim.addSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_AddUnFixConfig", "Sim.addUnFixConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddVaRConfig", "Sim.addVaRConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddVaRDef", "Sim.addVaRDef");

		newString = Replacer.simpleReplace(newString, "SIM_AddVegaShiftModByGpt", "Sim.addVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddVegaShiftMod", "Sim.addVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolInputModByGpt", "Sim.addVolInputModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolInputMod", "Sim.addVolInputMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolMap", "Sim.addVolMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolModByGpt", "Sim.addVolModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolMod", "Sim.addVolMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolumetricConfig", "Sim.addVolumetricConfig");

		newString = Replacer.simpleReplace(newString, "SIM_ComputeResultsForTranListByParam",
				"Transaction.simComputeResultsForTranListByParam");

		newString = Replacer.simpleReplace(newString, "SIM_ComputeResultsForTranList",
				"Transaction.simComputeResultsForTranList");

		newString = Replacer.simpleReplace(newString, "SIM_ConvertSimDef", "Sim.convertSimDef");

		newString = Replacer.simpleReplace(newString, "SIM_CopySim", "Sim.copySim");

		newString = Replacer.simpleReplace(newString, "SIM_CreateBaseSimulation", "Sim.createBaseSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_CreateConfigSubTableForType",
				"Sim.createConfigSubTableForType");

		newString = Replacer.simpleReplace(newString, "SIM_CreateRevalTable", "Sim.createRevalTable");

		newString = Replacer.simpleReplace(newString, "SIM_CreateScenarioTable", "Sim.createScenarioTable");

		newString = Replacer.simpleReplace(newString, "SIM_CreateSimDefTable", "Sim.createSimDefTable");

		newString = Replacer.simpleReplace(newString, "SIM_CreateSplitQueryTable", "Sim.createSplitQueryTable");

		newString = Replacer.simpleReplace(newString, "SIM_ExportSimDefs", "Sim.exportSimDefs");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateJDForHistPriceDate",
				"Sim.getHorizonDateJDForHistPriceDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateJDForResetDate",
				"Sim.getHorizonDateJDForResetDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateJDForScenarioDate",
				"Sim.getHorizonDateJDForScenarioDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateSymbolicDateForHistPriceDate",
				"Sim.getHorizonDateSymbolicDateForHistPriceDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateSymbolicDateForResetDate",
				"Sim.getHorizonDateSymbolicDateForResetDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateSymbolicDateForScenarioDate",
				"Sim.getHorizonDateSymbolicDateForScenarioDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetIndexOutputConfig", "Sim.getIndexOutputConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetLastResultDate", "Sim.getLastResultDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetListBy", "Sim.simGetListBy");

		newString = Replacer.simpleReplace(newString, "SIM_GetMarketPxIndexConfig", "Sim.getMarketPxIndexConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetMCarloConfig", "Sim.getMCarloConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetNewSimRunId", "Sim.getNewSimRunId");

		newString = Replacer.simpleReplace(newString, "SIM_GetPricingModelConfig", "Sim.getPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetResultConfig", "Sim.getResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetResultListForGroup", "Sim.simGetResultListForGroup");

		newString = Replacer.simpleReplace(newString, "SIM_GetResultName", "Sim.getResultName");

		newString = Replacer.simpleReplace(newString, "SIM_GetScenarioRow", "Sim.getScenarioRow");

		newString = Replacer.simpleReplace(newString, "SIM_GetSimDefId", "Sim.getSimDefId");

		newString = Replacer.simpleReplace(newString, "SIM_GetSimulationRow", "Sim.getSimulationRow");

		newString = Replacer.simpleReplace(newString, "SIM_GetVaRConfig", "Sim.getVaRConfig");

		newString = Replacer.simpleReplace(newString, "SIM_ImportSimDefs", "Sim.importSimDefs");

		newString = Replacer.simpleReplace(newString, "SIM_Init", "Sim.init");

		newString = Replacer.simpleReplace(newString, "SIM_InsertSimResults", "Sim.insertSimResults");

		newString = Replacer.simpleReplace(newString, "SIM_LoadBatchSim", "Sim.loadBatchSim");

		newString = Replacer.simpleReplace(newString, "SIM_LoadSimulation", "Sim.loadSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_NewRevalTable", "Sim.newRevalTable");

		newString = Replacer.simpleReplace(newString, "SIM_PurgeBySimRunId", "Sim.purgeBySimRunId");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveAccrueToThroughConfig",
				"Sim.removeAccrueToThroughConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveBondAccruesBeforeSettlementConfig",
				"Sim.removeBondAccruesBeforeSettlementConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorMap", "Sim.removeCorMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorModByGpt", "Sim.removeCorModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorVegaShiftModByGpt",
				"Sim.removeCorVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorVegaShiftMod", "Sim.removeCorVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveDeltaShiftModByGpt", "Sim.removeDeltaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveDeltaShiftMod", "Sim.removeDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveEuroConfig", "Sim.removeEuroConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveFXModByCcy", "Sim.removeFXModByCcy");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveFXMod", "Sim.removeFXMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveHorizonDateMod", "Sim.removeHorizonDateMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexEffectiveModByGpt",
				"Sim.removeIndexEffectiveModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexEffectiveMod", "Sim.removeIndexEffectiveMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexInheritanceConfig",
				"Sim.removeIndexInheritanceConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexMap", "Sim.removeIndexMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexModByGpt", "Sim.removeIndexModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexMod", "Sim.removeIndexMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexOutputConfig", "Sim.removeIndexOutputConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexOutputModByDate",
				"Sim.removeIndexOutputModByDate");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexOutputMod", "Sim.removeIndexOutputMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexParentMap", "Sim.removeIndexParentMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveMarketPxIndexConfig", "Sim.removeMarketPxIndexConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveMCarloConfig", "Sim.removeMCarloConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveOutputDeltaShiftMod", "Sim.removeOutputDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePricingMap", "Sim.removePricingMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePricingModelConfig", "Sim.removePricingModelConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePricingModelMap", "Sim.removePricingModelMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePriorSimResultConfig",
				"Sim.removePriorSimResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveResultConfig", "Sim.removeResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveResultGroupFromScenario",
				"Sim.removeResultGroupFromScenario");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveScenario", "Sim.removeScenario");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveSimulation", "Sim.removeSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveUnFixConfig", "Sim.removeUnFixConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVaRConfig", "Sim.removeVaRConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVaRDef", "Sim.removeVaRDef");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVegaShiftModByGpt", "Sim.removeVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVegaShiftMod", "Sim.removeVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolInputModByGpt", "Sim.removeVolInputModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolInputMod", "Sim.removeVolInputMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolMap", "Sim.removeVolMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolModByGpt", "Sim.removeVolModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolMod", "Sim.removeVolMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolumetricConfig", "Sim.removeVolumetricConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RunRevalByQidFixed", "Sim.runRevalByQidFixed");

		newString = Replacer.simpleReplace(newString, "SIM_RunRevalByParamFixed", "Sim.runRevalByParamFixed");

		newString = Replacer.simpleReplace(newString, "SIM_RunLocalByParamByDeal", "Sim.runLocalByParamByDeal");

		newString = Replacer.simpleReplace(newString, "SIM_RunLocalByDealFixed", "Sim.runLocalByDealFixed");

		newString = Replacer.simpleReplace(newString, "SIM_RunBatchSim", "Sim.runBatchSim");

		newString = Replacer.simpleReplace(newString, "SIM_Run", "Sim.run");

		newString = Replacer.simpleReplace(newString, "SIM_SaveAllSimulations", "Sim.saveAllSimulations");

		newString = Replacer.simpleReplace(newString, "SIM_SaveSimulation", "Sim.saveSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorModValueByTable", "Sim.setCorModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorModValueByGpt", "Sim.setCorModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorModValue", "Sim.setCorModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorVegaShiftModValueByTable",
				"Sim.setCorVegaShiftModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorVegaShiftModValueByGpt",
				"Sim.setCorVegaShiftModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorVegaShiftModValue", "Sim.setCorVegaShiftModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetDeltaShiftModByTable", "Sim.setDeltaShiftModByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetDeltaShiftModValueByGpt",
				"Sim.setDeltaShiftModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetDeltaShiftModValue", "Sim.setDeltaShiftModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetDistributedBatchSimProperty",
				"Sim.setDistributedBatchSimProperty");

		newString = Replacer.simpleReplace(newString, "SIM_SetDistributedRevalProperty",
				"Sim.setDistributedRevalProperty");

		newString = Replacer.simpleReplace(newString, "SIM_SetFXModByTable", "Sim.setFXModByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetFXModValueByCcy", "Sim.setFXModValueByCcy");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateRollMarketData",
				"Sim.setHorizonDateRollMarketData");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateResetDate", "Sim.setHorizonDateResetDate");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDatePVDateMode", "Sim.setHorizonDatePVDateMode");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDatePricingMethod",
				"Sim.setHorizonDatePricingMethod");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateModValue", "Sim.setHorizonDateModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateHistPriceDateMode",
				"Sim.setHorizonDateHistPriceDateMode");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateHistoricalPriceDate",
				"Sim.setHorizonDateHistoricalPriceDate");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateEODBODFlag", "Sim.setHorizonDateEODBODFlag");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexEffectiveModValueByTable",
				"Sim.setIndexEffectiveModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexEffectiveModValueByGpt",
				"Sim.setIndexEffectiveModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexEffectiveModValue", "Sim.setIndexEffectiveModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexOutputModValueByTable",
				"Sim.setIndexOutputModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexOutputModValue", "Sim.setIndexOutputModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexModValueByTable", "Sim.setIndexModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexModValueByGpt", "Sim.setIndexModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexModValue", "Sim.setIndexModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetModValue", "Sim.setModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolModValueByTable", "Sim.setVolModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolModValueByGpt", "Sim.setVolModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolModValue", "Sim.setVolModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolInputModValueByTable",
				"Sim.setVolInputModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolInputModValueByGpt", "Sim.setVolInputModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolInputModValue", "Sim.setVolInputModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModValueByTable",
				"Sim.setVegaShiftModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModValueByGpt", "Sim.setVegaShiftModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModValue", "Sim.setVegaShiftModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModByTable", "Sim.setVegaShiftModByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetUnFixConfigValue", "Sim.setUnFixConfigValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetScenarioBMO", "Sim.setScenarioBMO");

		newString = Replacer.simpleReplace(newString, "SIM_SetOutputDeltaShiftModValue",
				"Sim.setOutputDeltaShiftModValue");

		newString = Replacer.simpleReplace(newString, "PWR_AdjustSchedule", "PowerSchedule.adjustSchedule");

		newString = Replacer.simpleReplace(newString, "PWR_CompressTranScheduleDetails",
				"Power.compressTranScheduleDetails");

		newString = Replacer.simpleReplace(newString, "PWR_ComputeBestAvailableForTransaction",
				"PowerSchedule.computeBestAvailableForTransaction");

		newString = Replacer.simpleReplace(newString, "PWR_ComputeDeliveryHoursInPeriod",
				"Power.computeDeliveryHoursInPeriod");

		newString = Replacer.simpleReplace(newString, "PWR_ConvertTableToScheduleTable",
				"PowerSchedule.convertTableToScheduleTable");

		newString = Replacer.simpleReplace(newString, "PWR_Create_Position_Page", "Power.createPositionPage");

		newString = Replacer.simpleReplace(newString, "PWR_CreateCustomTransactionSchedule",
				"Power.createCustomTransactionSchedule");

		newString = Replacer.simpleReplace(newString, "PWR_CreateStandardTransactionSchedule",
				"Power.createStandardTransactionSchedule");

		newString = Replacer.simpleReplace(newString, "PWR_DailyVolumeAdjustment", "Power.dailyVolumeAdjustment");

		newString = Replacer.simpleReplace(newString, "PWR_DateEncodingToString", "Power.dateEncodingToString");

		newString = Replacer.simpleReplace(newString, "PWR_ExpandProductTable", "Power.expandProductTable");

		newString = Replacer.simpleReplace(newString, "PWR_ExportPowerTables", "Power.exportPowerTables");

		newString = Replacer.simpleReplace(newString, "PWR_ExportReferenceData", "Power.exportReferenceData");

		newString = Replacer.simpleReplace(newString, "PWR_ExportTimeZones", "Power.exportTimeZones");

		newString = Replacer.simpleReplace(newString, "PWR_GenerateDeliveryID", "PowerSchedule.generateDeliveryID");

		newString = Replacer.simpleReplace(newString, "PWR_GenerateVolumetricPositions",
				"Power.generateVolumetricPositions");

		newString = Replacer.simpleReplace(newString, "PWR_GetAbsoluteStartTime", "Power.getAbsoluteStartTime");

		newString = Replacer.simpleReplace(newString, "PWR_GetAbsoluteStartTimeForRow",
				"Power.getAbsoluteStartTimeForRow");

		newString = Replacer.simpleReplace(newString, "PWR_GetAbsoluteStopTime", "Power.getAbsoluteStopTime");

		newString = Replacer.simpleReplace(newString, "PWR_GetAbsoluteStopTimeForRow",
				"Power.getAbsoluteStopTimeForRow");

		newString = Replacer.simpleReplace(newString, "PWR_GetBillingAmount", "Power.getBillingAmount");

		newString = Replacer.simpleReplace(newString, "PWR_GetInvoiceDeliveryDates", "Power.getInvoiceDeliveryDates");

		newString = Replacer.simpleReplace(newString, "PWR_GetProfileDeliveryDates", "Power.getProfileDeliveryDates");

		newString = Replacer.simpleReplace(newString, "PWR_HourEncodingToString", "Power.hourEncodingToString");

		newString = Replacer.simpleReplace(newString, "PWR_ImportDeliveryInfo", "PowerSchedule.importDeliveryInfo");

		newString = Replacer.simpleReplace(newString, "PWR_ImportPowerTables", "Power.importPowerTables");

		newString = Replacer.simpleReplace(newString, "PWR_ImportReferenceData", "Power.importReferenceData");

		newString = Replacer.simpleReplace(newString, "PWR_ImportSchedule", "PowerSchedule.importSchedule");

		newString = Replacer.simpleReplace(newString, "PWR_MinuteEncodingToString", "Power.minuteEncodingToString");

		newString = Replacer.simpleReplace(newString, "PWR_MatchTransactions", "PowerSchedule.matchTransactions");

		newString = Replacer.simpleReplace(newString, "PWR_ImportTimeZones", "Power.importTimeZones");

		newString = Replacer.simpleReplace(newString, "PWR_PsiInsertExternalInterfaceRecords",
				"PowerSchedule.psiInsertExternalInterfaceRecords");

		newString = Replacer.simpleReplace(newString, "PWR_PsiLockTSDRequest", "PowerSchedule.psiLockTSDRequest");

		newString = Replacer.simpleReplace(newString, "PWR_PsiRetrieveExternalInterfaceRecords",
				"PowerSchedule.psiRetrieveExternalInterfaceRecords");

		newString = Replacer.simpleReplace(newString, "PWR_PsiRetrieveNextSequenceNum",
				"PowerSchedule.psiRetrieveNextSequenceNum");

		newString = Replacer.simpleReplace(newString, "PWR_PsiUnlockTSDRequest", "PowerSchedule.psiUnlockTSDRequest");

		newString = Replacer.simpleReplace(newString, "PWR_PsiUpdateExternalInterfaceExcludeMsg",
				"PowerSchedule.psiUpdateExternalInterfaceExcludeMsg");

		newString = Replacer.simpleReplace(newString, "PWR_PsiUpdateExternalInterfaceIncludeMsg",
				"PowerSchedule.psiUpdateExternalInterfaceIncludeMsg");

		newString = Replacer.simpleReplace(newString, "PWR_ReplaceSchedule", "PowerSchedule.replaceSchedule");

		newString = Replacer.simpleReplace(newString, "PWR_ReplaceScheduleRange", "PowerSchedule.replaceScheduleRange");

		newString = Replacer.simpleReplace(newString, "PWR_ScheduleMultipleTransactions",
				"PowerSchedule.scheduleMultipleTransactions");

		newString = Replacer.simpleReplace(newString, "PWR_ScheduleTransaction", "PowerSchedule.scheduleTransaction");

		newString = Replacer.simpleReplace(newString, "PWR_RegeneratePriceBands", "Power.regeneratePriceBands");

		newString = Replacer.simpleReplace(newString, "PWR_RegenerateProfileAuxGivenTranNum",
				"Power.regenerateProfileAuxGivenTranNum");

		newString = Replacer.simpleReplace(newString, "PWR_RegeneratePwrProfileAux", "Power.regeneratePwrProfileAux");

		newString = Replacer.simpleReplace(newString, "PWR_RegenerateScheduleDetails",
				"Power.regenerateScheduleDetails");

		newString = Replacer.simpleReplace(newString, "PWR_StringToDateEncoding", "Power.stringToDateEncoding");

		newString = Replacer.simpleReplace(newString, "PWR_StringToHourEncoding", "Power.stringToHourEncoding");

		newString = Replacer.simpleReplace(newString, "PWR_StringToMinuteEncoding", "Power.stringToMinuteEncoding");

		newString = Replacer.simpleReplace(newString, "SUBSCRIBE_Add", "Services.subscribeAdd");

		newString = Replacer.simpleReplace(newString, "SUBSCRIBE_CreateTable", "Services.subscribeCreateTable");

		newString = Replacer.simpleReplace(newString, "SYSTEM_Command", "SystemUtil.command");

		newString = Replacer.simpleReplace(newString, "SYSTEM_CreateProcess", "SystemUtil.createProcess");

		newString = Replacer.simpleReplace(newString, "SYSTEM_GetEnvVariable", "SystemUtil.getEnvVariable");

		newString = Replacer.simpleReplace(newString, "SYSTEM_GetEnvVariableNames", "SystemUtil.getEnvVariableNames");

		newString = Replacer.simpleReplace(newString, "SYSTEM_GetInfo", "SystemUtil.getInfo");

		newString = Replacer.simpleReplace(newString, "SYSTEM_GetSessionTable", "SystemUtil.getSessionTable");

		newString = Replacer.simpleReplace(newString, "SYSTEM_SetEnvVariable", "SystemUtil.setEnvVariable");

		newString = Replacer.simpleReplace(newString, "SYSTEM_Shutdown", "SystemUtil.shutdown");

		newString = Replacer.simpleReplace(newString, "SYSTEM_TerminateSession", "SystemUtil.terminateSession");

		newString = Replacer.simpleReplace(newString, "SYSTEM_GetOsServicesList", "Services.systemGetOsServicesList");

		newString = Replacer.simpleReplace(newString, "SYSTEM_StartOsService", "Services.systemStartOsService");

		newString = Replacer.simpleReplace(newString, "SYSTEM_StopOsService", "Services.systemStopOsService");

		newString = Replacer.simpleReplace(newString, "sleep", "Debug.sleep");

		newString = Replacer.simpleReplace(newString, "STLDOC_AddEventToDoc", "StlDoc.addEventToDoc");

		newString = Replacer.simpleReplace(newString, "STLDOC_AddGenDataItem", "StlDoc.addGenDataItem");

		newString = Replacer.simpleReplace(newString, "STLDOC_AppendGenDataTable", "StlDoc.appendGenDataTable");

		newString = Replacer.simpleReplace(newString, "STLDOC_CreateAdjustedCashTransaction",
				"StlDoc.createAdjustedCashTransaction");

		newString = Replacer.simpleReplace(newString, "STLDOC_CreateCashTransaction", "StlDoc.createCashTransaction");

		newString = Replacer.simpleReplace(newString, "STLDOC_DeleteDefinition", "StlDoc.deleteDefinition");

		newString = Replacer.simpleReplace(newString, "STLDOC_DeleteDocType", "StlDoc.deleteDocType");

		newString = Replacer.simpleReplace(newString, "STLDOC_DeleteOutputForm", "StlDoc.deleteOutputForm");

		newString = Replacer.simpleReplace(newString, "STLDOC_DeleteTemplate", "StlDoc.deleteTemplate");

		newString = Replacer.simpleReplace(newString, "STLDOC_DiffGenerationData", "StlDoc.diffGenerationData");

		newString = Replacer.simpleReplace(newString, "STLDOC_DocumentFieldsHaveChanged",
				"StlDoc.documentFieldsHaveChanged");

		newString = Replacer.simpleReplace(newString, "STLDOC_GetAnnotation", "StlDoc.getAnnotation");

		newString = Replacer.simpleReplace(newString, "STLDOC_GetDocumentsByDeal", "StlDoc.getDocumentsByDeal");

		newString = Replacer.simpleReplace(newString, "STLDOC_GetUserDataTable", "StlDoc.getUserDataTable");

		newString = Replacer.simpleReplace(newString, "STLDOC_GroupEvents", "StlDoc.groupEvents");

		newString = Replacer.simpleReplace(newString, "STLDOC_OutputDocs", "StlDoc.outputDocs");

		newString = Replacer.simpleReplace(newString, "STLDOC_PreviewDocs", "StlDoc.previewDocs");

		newString = Replacer.simpleReplace(newString, "STLDOC_ProcessDocs", "StlDoc.processDocs");

		newString = Replacer.simpleReplace(newString, "STLDOC_ProcessDocToStatus", "StlDoc.processDocToStatus");

		newString = Replacer.simpleReplace(newString, "STLDOC_PurgeHistory", "StlDoc.purgeHistory");

		newString = Replacer.simpleReplace(newString, "STLDOC_ReformatGenDataForXML", "StlDoc.reformatGenDataForXML");

		newString = Replacer.simpleReplace(newString, "STLDOC_RemoveEventFromDoc", "StlDoc.removeEventFromDoc");

		newString = Replacer.simpleReplace(newString, "STLDOC_RunEventQueryInternal", "StlDoc.runEventQueryInternal");

		newString = Replacer.simpleReplace(newString, "STLDOC_SaveAnnotation", "StlDoc.saveAnnotation");

		newString = Replacer.simpleReplace(newString, "STLDOC_SaveInfoValue", "StlDoc.saveInfoValue");

		newString = Replacer.simpleReplace(newString, "STLDOC_SaveUpdatedGenData", "StlDoc.saveUpdatedGenData");

		newString = Replacer.simpleReplace(newString, "STLDOC_SaveUserDataTable", "StlDoc.saveUserDataTable");

		newString = Replacer.simpleReplace(newString, "STLDOC_UpdateAmendedDealEvents",
				"StlDoc.updateAmendedDealEvents");

		newString = Replacer.simpleReplace(newString, "STLDOC_UpdateDetailParaPosition",
				"StlDoc.updateDetailParaPosition");

		newString = Replacer.simpleReplace(newString, "STLDOC_UpdateDetailSettleAmount",
				"StlDoc.updateDetailSettleAmount");

		newString = Replacer.simpleReplace(newString, "STLDOC_UpdateDetailTranPosition",
				"StlDoc.updateDetailTranPosition");

		newString = Replacer.simpleReplace(newString, "STLDOC_UpdateHeaderAmounts", "StlDoc.updateHeaderAmounts");

		newString = Replacer.simpleReplace(newString, "STLDOC_UpdateOutputReturnStatus",
				"StlDoc.updateOutputReturnStatus");

		newString = Replacer.simpleReplace(newString, "STLDOC_UpdatePaymentDueDate", "StlDoc.updatePaymentDueDate");

		newString = Replacer.simpleReplace(newString, "Save_Credit_Risk_Eod_Table",
				"CreditRiskUtil.saveCreditRiskEodTable");

		newString = Replacer.simpleReplace(newString, "Save_Excession_Table", "CreditRiskBatch.saveExcessionTable");

		newString = Replacer.simpleReplace(newString, "SCRIPT_CanAccessGui", "Util.canAccessGui");

		newString = Replacer.simpleReplace(newString, "script_debug_function", "Debug.scriptdebugFunction");

		newString = Replacer.simpleReplace(newString, "SCRIPT_Delete", "Util.scriptDelete");

		newString = Replacer.simpleReplace(newString, "SCRIPT_GetExecutionLog", "Util.scriptGetExecutionLog");

		newString = Replacer.simpleReplace(newString, "SCRIPT_Import", "Util.scriptImport");

		newString = Replacer.simpleReplace(newString, "SCRIPT_PostStatus", "Util.scriptPostStatus");

		newString = Replacer.simpleReplace(newString, "SERVICE_AddSplitJobDescriptionField",
				"Services.serviceAddSplitJobDescriptionField");

		newString = Replacer.simpleReplace(newString, "SERVICE_ApmPostProcessScript",
				"Services.serviceApmPostProcessScript");

		newString = Replacer.simpleReplace(newString, "SERVICE_ClearRunServiceMethodLocally",
				"Services.serviceClearRunServiceMethodLocally");

		newString = Replacer.simpleReplace(newString, "SERVICE_CreateMethodParamsTable",
				"Services.serviceCreateMethodParamsTable");

		newString = Replacer.simpleReplace(newString, "SERVICE_CreateSplitTable", "Services.serviceCreateSplitTable");

		newString = Replacer.simpleReplace(newString, "SERVICE_DispatcherScript", "Services.serviceDispatcherScript");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetExecutionLog", "Util.serviceGetExecutionLog");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetNumberSplitEngines",
				"Services.serviceGetNumberSplitEngines");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetServiceGroupType",
				"Services.serviceGetServiceGroupType");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetServiceGroupTypeName",
				"Services.serviceGetServiceGroupTypeName");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetServiceId", "Services.serviceGetServiceId");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetServiceName", "Services.serviceGetServiceName");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetStatus", "Util.serviceGetStatus");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetStatusAll", "Util.serviceGetStatusAll");

		newString = Replacer.simpleReplace(newString, "SERVICE_GetUserDefaultServices",
				"Services.serviceGetUserDefaultServices");

		newString = Replacer.simpleReplace(newString, "SERVICE_IsServiceRunning", "Services.serviceIsServiceRunning");

		newString = Replacer.simpleReplace(newString, "SERVICE_IsServiceRunningByName",
				"Services.isServiceRunningByName");

		newString = Replacer.simpleReplace(newString, "SERVICE_Method", "Services.serviceMethod");

		newString = Replacer.simpleReplace(newString, "SERVICE_MethodScript", "Services.serviceMethodScript");

		newString = Replacer.simpleReplace(newString, "SERVICE_PingRunsite", "Util.servicePingRunSite");

		newString = Replacer.simpleReplace(newString, "SERVICE_RestartService", "Util.serviceRestartService");

		newString = Replacer.simpleReplace(newString, "SERVICE_RunCreditRiskBatch",
				"CreditRiskBatch.serviceRunCreditRiskBatch");

		newString = Replacer.simpleReplace(newString, "SERVICE_RunMethod", "Services.serviceRunMethod");

		newString = Replacer.simpleReplace(newString, "SERVICE_SaveUserDefaultServices",
				"Services.serviceSaveUserDefaultServices");

		newString = Replacer.simpleReplace(newString, "SERVICE_SetRunServiceMethodLocally",
				"Services.serviceSetRunServiceMethodLocally");

		newString = Replacer.simpleReplace(newString, "SERVICE_SetUserServices", "Services.serviceSetUserServices");

		newString = Replacer.simpleReplace(newString, "SERVICEGRP_GetName", "Services.servicegrpGetName");

		newString = Replacer.simpleReplace(newString, "SERVICE_StartService", "Util.serviceStartService");

		newString = Replacer.simpleReplace(newString, "SERVICE_StopService", "Util.serviceStopService");

		newString = Replacer.simpleReplace(newString, "SET_DEBUG", "Debug.setDEBUG");

		newString = Replacer.simpleReplace(newString, "SETTLE_CopyEventDataForward", "Ref.settleCopyEventDataForward");

		newString = Replacer.simpleReplace(newString, "SETTLE_INST_RetrieveAll", "Ref.settleINSTRetrieveAll");

		newString = Replacer.simpleReplace(newString, "SETTLE_INST_RetrievePossibleForDelivery",
				"Ref.settleINSTRetrievePossibleForDelivery");

		newString = Replacer.simpleReplace(newString, "SETTLE_INST_Save", "Ref.settleINSTSave");

		newString = Replacer.simpleReplace(newString, "SETTLE_INST_save_event_settle", "Ref.settleINSTSaveEventSettle");

		newString = Replacer.simpleReplace(newString, "SETTLE_SPLIT", "Ref.settleSPLIT");

		newString = Replacer.simpleReplace(newString, "SETTLE_SPLIT_InitTable", "Ref.settleSPLITInitTable");

		newString = Replacer.simpleReplace(newString, "RNG_Double", "Math.rngDouble");

		newString = Replacer.simpleReplace(newString, "RNG_Int", "Math.rngInt");

		newString = Replacer.simpleReplace(newString, "RNG_SetSeed", "Math.rngSetSeed");

		newString = Replacer.simpleReplace(newString, "RNG_String", "Math.rngString");

		newString = Replacer.simpleReplace(newString, "round", "Math.round");

		newString = Replacer.simpleReplace(newString, "roll_to_dates", "EndOfDay.rollToDates");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateConfigTable", "RptMgr.createConfigTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateGroupTable", "RptMgr.createGroupTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateInpParamSubTable", "RptMgr.createInpParamSubTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateOutParamSubTable", "RptMgr.createOutParamSubTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateParamListTable", "RptMgr.createParamListTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateParamTable", "RptMgr.createParamTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateReportParamTable", "RptMgr.createReportParamTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateReportTable", "RptMgr.createReportTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_CreateReturntTable", "RptMgr.createReturntTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_DeleteReportLogByDate", "RptMgr.deleteReportLogByDate");

		newString = Replacer.simpleReplace(newString, "RPTMGR_DeleteReportLogByName", "RptMgr.deleteReportLogByName");

		newString = Replacer.simpleReplace(newString, "RPTMGR_DeleteReportSettings", "RptMgr.deleteReportSettings");

		newString = Replacer.simpleReplace(newString, "RPTMGR_DeleteUserSettings", "RptMgr.deleteUserSettings");

		newString = Replacer.simpleReplace(newString, "RPTMGR_FindReportParamRow", "RptMgr.findReportParamRow");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetArgList", "RptMgr.getArgList");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetArgListStr", "RptMgr.getArgListStr");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetArgListStrN", "RptMgr.getArgListStr");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetDirForDate", "RptMgr.getDirForDate");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetDirForToday", "RptMgr.getDirForToday");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetOutputFlag", "RptMgr.getOutputFlag");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetReportIdForDate", "RptMgr.getReportIdForDate");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetTextEditDouble", "RptMgr.getTextEditDouble");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetTextEditInt", "RptMgr.getTextEditInt");

		newString = Replacer.simpleReplace(newString, "RPTMGR_GetTextEditStr", "RptMgr.getTextEditStr");

		newString = Replacer.simpleReplace(newString, "RPTMGR_RetrieveReportData", "RptMgr.retrieveReportData");

		newString = Replacer.simpleReplace(newString, "RPTMGR_RetrieveReportSettings", "RptMgr.retrieveReportSettings");

		newString = Replacer.simpleReplace(newString, "RPTMGR_RetrieveReportsFromFileSystem",
				"RptMgr.retrieveReportsFromFileSystem");

		newString = Replacer.simpleReplace(newString, "RPTMGR_RetrieveReturntTable", "RptMgr.retrieveReturntTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_RetrieveUserFavorites", "RptMgr.retrieveUserFavorites");

		newString = Replacer.simpleReplace(newString, "RPTMGR_RetrieveUserPushButtons",
				"RptMgr.retrieveUserPushButtons");

		newString = Replacer.simpleReplace(newString, "RPTMGR_RetrieveUserSettings", "RptMgr.retrieveUserSettings");

		newString = Replacer.simpleReplace(newString, "RPTMGR_SaveReportSettings", "RptMgr.saveReportSettings");

		newString = Replacer.simpleReplace(newString, "RPTMGR_SaveReturntTable", "RptMgr.saveReturntTable");

		newString = Replacer.simpleReplace(newString, "RPTMGR_SaveUserFavorites", "RptMgr.saveUserFavorites");

		newString = Replacer.simpleReplace(newString, "RPTMGR_SaveUserPushButtons", "RptMgr.saveUserPushButtons");

		newString = Replacer.simpleReplace(newString, "RPTMGR_SaveUserSettings", "RptMgr.saveUserSettings");

		newString = Replacer.simpleReplace(newString, "RPTMGR_StoreReportData", "RptMgr.storeReportData");

		newString = Replacer.simpleReplace(newString, "RPTMGR_UpdateArgTable", "RptMgr.updateArgTable");

		newString = Replacer.simpleReplace(newString, "RUNSITE_GetAvailableEngines",
				"Services.runsiteGetAvailableEngines");

		newString = Replacer.simpleReplace(newString, "RUNSITE_GetProfile", "Services.runsiteGetProfile");

		newString = Replacer.simpleReplace(newString, "RUNSITE_GetRunsiteId", "Services.runsiteGetRunsiteId");

		newString = Replacer.simpleReplace(newString, "RUNSITE_GetStatusAll", "Services.runsiteGetStatusAll");

		newString = Replacer.simpleReplace(newString, "RUNSITE_GetUtilization", "Services.runsiteGetUtilization");

		newString = Replacer.simpleReplace(newString, "RUNSITE_IsRunning", "Services.runsiteIsRunning");

		newString = Replacer.simpleReplace(newString, "RUNSITE_RetrieveRunsiteTable",
				"Services.runsiteRetrieveRunsiteTable");

		newString = Replacer.simpleReplace(newString, "RTP_Append_Page", "Positions.rtpAppendPage");

		newString = Replacer.simpleReplace(newString, "RTP_Batch_Complete", "Positions.rtpBatchComplete");

		newString = Replacer.simpleReplace(newString, "RTP_Batch_Init", "Positions.rtpBatchInit");

		newString = Replacer.simpleReplace(newString, "RTP_CreateCustomPivotConfig",
				"Positions.rtpCreateCustomPivotConfig");

		newString = Replacer.simpleReplace(newString, "RTP_Criteria_Selected", "Positions.rtpCriteriaSelected");

		newString = Replacer.simpleReplace(newString, "RTP_DataServer_Batch_Init", "Rtpe.dataServerBatchInit");

		newString = Replacer.simpleReplace(newString, "RTP_DataServer_CreateArgTable", "Rtpe.dataServerCreateArgTable");

		newString = Replacer.simpleReplace(newString, "RTP_GeneratePositionPage", "Positions.rtpGeneratePositionPage");

		newString = Replacer.simpleReplace(newString, "RTP_GetBatchInvocationNum",
				"Positions.rtpGetBatchInvocationNum");

		newString = Replacer.simpleReplace(newString, "RTP_GetConfigTable", "Positions.rtpGetConfigTable");

		newString = Replacer.simpleReplace(newString, "RTP_GetDefId", "Positions.rtpGetDefId");

		newString = Replacer.simpleReplace(newString, "RTP_GetFullPageTitle", "Positions.rtpGetFullPageTitle");

		newString = Replacer.simpleReplace(newString, "RTP_GetIncrClientDataTable",
				"Positions.rtpGetIncrClientDataTable");

		newString = Replacer.simpleReplace(newString, "RTP_GetPageTitle", "Positions.rtpGetPageTitle");

		newString = Replacer.simpleReplace(newString, "RTP_HasIncrClientDataTable",
				"Positions.rtpHasIncrClientDataTable");

		newString = Replacer.simpleReplace(newString, "RTP_Init", "Positions.rtpInit");

		newString = Replacer.simpleReplace(newString, "RTP_RevisePageFilterUsingCriteriaTable",
				"Positions.rtpRevisePageFilterUsingCriteriaTable");

		newString = Replacer.simpleReplace(newString, "RTP_SetBatchClientDataTable",
				"Positions.rtpSetBatchClientDataTable");

		newString = Replacer.simpleReplace(newString, "RTP_SyncResultSets", "Positions.rtpSyncResultSets");

		newString = Replacer.simpleReplace(newString, "RTP_Trade_Criteria", "Positions.rtpTradeCriteria");

		newString = Replacer.simpleReplace(newString, "RTPE_CreateIncrementalScriptInfoTable",
				"Positions.rtpeCreateIncrementalScriptInfoTable");

		newString = Replacer.simpleReplace(newString, "RTPE_IsRunning", "Rtpe.isRunning");

		newString = Replacer.simpleReplace(newString, "RTPE_RequiresUpdate", "Rtpe.requiresConfigUpdate");

		newString = Replacer.simpleReplace(newString, "RTPE_RestartBatch", "Rtpe.restartBatch");

		newString = Replacer.simpleReplace(newString, "RTPE_ResumeMonitoring", "Rtpe.resumeMonitoring");

		newString = Replacer.simpleReplace(newString, "RTPE_RetrieveMsglogByDateRange",
				"Rtpe.retrieveMsglogByDateRange");

		newString = Replacer.simpleReplace(newString, "RTPE_RetrieveMsglogById", "Rtpe.retrieveMsglogById");

		newString = Replacer.simpleReplace(newString, "RTPE_RunBatchTask", "Rtpe.runBatchTask");

		newString = Replacer.simpleReplace(newString, "RTPE_Script", "Rtpe.script");

		newString = Replacer.simpleReplace(newString, "RTPE_SendIncrementalDeals", "Rtpe.sendIncrementalDeals");

		newString = Replacer.simpleReplace(newString, "RTPE_StartMonitoring", "Rtpe.startMonitoring");

		newString = Replacer.simpleReplace(newString, "RTPE_StopMonitoring", "Rtpe.stopMonitoring");

		newString = Replacer.simpleReplace(newString, "RTPE_SuspendMonitoring", "Rtpe.suspendMonitoring");

		newString = Replacer.simpleReplace(newString, "RTPE_Update", "Rtpe.configUpdate");

		newString = Replacer.simpleReplace(newString, "RTPQUERY_GetPosConfig", "Positions.rtpqueryGetPosConfig");

		newString = Replacer.simpleReplace(newString, "RTPQUERY_GetPosMasterDetails",
				"Positions.rtpqueryGetPosMasterDetails");

		newString = Replacer.simpleReplace(newString, "RTPQUERY_GetPosOnlinePages",
				"Positions.rtpqueryGetPosOnlinePages");

		newString = Replacer.simpleReplace(newString, "RTPQUERY_GetPosPageImage", "Positions.rtpqueryGetPosPageImage");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_CreateMinorSubjectName",
				"Positions.rtptableCreateMinorSubjectName");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_CreateSubjectMatchCriteria",
				"Positions.rtptableCreateSubjectMatchCriteria");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_FindSubjectMapEntry",
				"Positions.rtptableFindSubjectMapEntry");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_GetIntN", "Positions.rtptableGetIntN");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_GetNumSubjectMapEntries",
				"Positions.rtptableGetNumSubjectMapEntries");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_GetNumSubjectSections",
				"Positions.rtptableGetNumSubjectSections");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_GetStringN", "Positions.rtptableGetStringN");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_GetTableN", "Positions.rtptableGetTableN");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_InsertSubjectMapEntry",
				"Positions.rtptableInsertSubjectMapEntry");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_SetIntN", "Positions.rtptableSetIntN");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_SetStringN", "Positions.rtptableSetStringN");

		newString = Replacer.simpleReplace(newString, "RTPTABLE_SetTableN", "Positions.rtptableSetTableN");

		newString = Replacer.simpleReplace(newString, "RISK_CreateInquiryTable", "Risk.createInquiryTable");

		newString = Replacer.simpleReplace(newString, "RISK_CreateLimitTable", "Risk.createLimitTable");

		newString = Replacer.simpleReplace(newString, "RISK_PopulateLimitTable", "Risk.populateLimitTable");

		newString = Replacer.simpleReplace(newString, "RISK_ResumeMonitoring", "Risk.resumeMonitoring");

		newString = Replacer.simpleReplace(newString, "RISK_RetrieveCurrentUsages", "Risk.retrieveCurrentUsages");

		newString = Replacer.simpleReplace(newString, "RISK_RetrieveOnlineStatus", "Risk.retrieveOnlineStatus");

		newString = Replacer.simpleReplace(newString, "RISK_RunBatchTask", "Risk.runBatchTask");

		newString = Replacer.simpleReplace(newString, "RISK_SetLimits", "Risk.setLimits");

		newString = Replacer.simpleReplace(newString, "RISK_StartMonitoring", "Risk.startMonitoring");

		newString = Replacer.simpleReplace(newString, "RISK_StopMonitoring", "Risk.stopMonitoring");

		newString = Replacer.simpleReplace(newString, "RISK_SuspendMonitoring", "Risk.suspendMonitoring");

		newString = Replacer.simpleReplace(newString, "REFIXING_GetListOfModifiedHistPrices",
				"Index.refixingGetListOfModifiedHistPrices");

		newString = Replacer.simpleReplace(newString, "REFIXING_InsertTransAffectedByPriceChanges",
				"Index.refixingInsertTransAffectedByPriceChanges");

		newString = Replacer.simpleReplace(newString, "REFIXING_RefixTransAffectedByPriceChanges",
				"Index.refixingRefixTransAffectedByPriceChanges");

		newString = Replacer.simpleReplace(newString, "REPO_LoadTran", "Transaction.repoLoadTran");

		newString = Replacer.simpleReplace(newString, "REPO_LoadTranCopy", "Transaction.repoLoadTranCopy");

		newString = Replacer.simpleReplace(newString, "REPORT_GetDirForDate", "Util.reportGetDirForDate");

		newString = Replacer.simpleReplace(newString, "REPORT_GetDirForToday", "Util.reportGetDirForToday");

		newString = Replacer.simpleReplace(newString, "Reset_Position_Date", "Util.resetPositionDate");

		newString = Replacer.simpleReplace(newString, "RESULT_AddResultForSim", "Sim.addResultForSim");

		newString = Replacer.simpleReplace(newString, "RESULT_CreateResultListForSim", "Sim.createResultListForSim");

		newString = Replacer.simpleReplace(newString, "RESULT_DestroyResultList", "Sim.destroyResultList");

		newString = Replacer.simpleReplace(newString, "Retrieve_Checking_Criteria",
				"CreditRiskUtil.retrieveCheckingCriteria");

		newString = Replacer.simpleReplace(newString, "Retrieve_Credit_Risk_Eod_Table",
				"CreditRiskUtil.retrieveCheckingCriteria");

		newString = Replacer.simpleReplace(newString, "Retrieve_Excession_Table",
				"CreditRiskBatch.retrieveExcessionTable");

		newString = Replacer.simpleReplace(newString, "Retrieve_Num_Trans", "OpService.retrieveNumTrans");

		newString = Replacer.simpleReplace(newString, "Retrieve_Original_Tran", "OpService.retrieveOriginalTran");

		newString = Replacer.simpleReplace(newString, "Retrieve_Tran", "OpService.retrieveTran");

		newString = Replacer.simpleReplace(newString, "RESULT_FindGenResultRow", "SimResult.findGenResultRow");

		newString = Replacer.simpleReplace(newString, "RESULT_FindGenResultTable", "SimResult.findGenResultTable");

		newString = Replacer.simpleReplace(newString, "RESULT_GetAttrGroupsForResultType",
				"SimResult.getAttrGroupsForResultType");

		newString = Replacer.simpleReplace(newString, "RESULT_GetGenResults", "SimResult.getGenResults");

		newString = Replacer.simpleReplace(newString, "RESULT_GetGenResultTables", "SimResult.getGenResultTables");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultClass", "SimResult.getResultClass");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultConfig", "SimResult.getResultConfig");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultEnumFromId", "SimResult.getResultEnumFromId");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultIdFromEnum", "SimResult.getResultIdFromEnum");

		newString = Replacer.simpleReplace(newString, "RESULT_GetTranCumResults", "SimResult.getTranCumResults");

		newString = Replacer.simpleReplace(newString, "RESULT_GetTranLegResults", "SimResult.getTranLegResults");

		newString = Replacer.simpleReplace(newString, "RESULT_GetTranResults", "SimResult.getTranResults");

		newString = Replacer.simpleReplace(newString, "RESULT_IsResultAllowedForTran",
				"SimResult.isResultAllowedForTran");

		newString = Replacer.simpleReplace(newString, "RESULT_ResultColName", "SimResult.resultColName");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_AllocateDeliveryQty", "QtyMgmt.allocateDeliveryQty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_AllocateReceiptQty", "QtyMgmt.allocateReceiptQty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_ClearSummaryGroups", "QtyMgmt.clearSummaryGroups");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_CreateAccessData", "QtyMgmt.createAccessData");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_DestroyAccessData", "QtyMgmt.destroyAccessData");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_ExecuteQuery", "QtyMgmt.executeQuery");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_Save", "QtyMgmt.save");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetDeliveryQty", "QtyMgmt.setDeliveryQty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetFuelQty", "QtyMgmt.setFuelQty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryCounterParty", "QtyMgmt.setQueryCounterparty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryDealNum", "QtyMgmt.setQueryDealNum");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryDeliveries", "QtyMgmt.setQueryDeliveries");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryGasDayEnd", "QtyMgmt.setQueryGasDayEnd");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryGasDayStart", "QtyMgmt.setQueryGasDayStart");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryLocation", "QtyMgmt.setQueryLocation");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryProdMonth", "QtyMgmt.setQueryProdMonth");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryServiceProvider",
				"QtyMgmt.setQueryServiceProviderDeal");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryServiceProviderDeal",
				"QtyMgmt.setQueryServiceProviderDealNum");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetQueryVolumeType", "QtyMgmt.setQueryVolumeType");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetReceiptQty", "QtyMgmt.setReceiptQty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryDeliveryQty", "QtyMgmt.setSummaryDeliveryQty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryFilterPoolDel",
				"QtyMgmt.setSummaryFilterPoolDel");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryFilterPoolRec",
				"QtyMgmt.setSummaryFilterPoolRec");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupDeliveryContractN",
				"QtyMgmt.setSummaryGroupDeliveryContractN");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupDeliveryExternalLentityN",
				"QtyMgmt.setSummaryGroupDeliveryExternalLentityN");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupDeliveryLocationId",
				"QtyMgmt.setSummaryGroupDeliveryLocation");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupExternalLentityN",
				"QtyMgmt.setSummaryGroupExternalLentityN");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupLocationId",
				"QtyMgmt.setSummaryGroupLocation");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupNomTransactionType",
				"QtyMgmt.setSummaryGroupNomTransactionType");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupPackageIdN",
				"QtyMgmt.setSummaryGroupPackageIdN");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupReceiptContractN",
				"QtyMgmt.setSummaryGroupReceiptContractN");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupReceiptExternalLentityN",
				"QtyMgmt.setSummaryGroupReceiptExternalLentityN");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupReceiptLocationId",
				"QtyMgmt.setSummaryGroupReceiptLocation");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupServiceProviderDealNum",
				"QtyMgmt.setSummaryGroupServiceProviderDealNum");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupServiceProviderId",
				"QtyMgmt.setSummaryGroupServiceProvider");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryGroupUpDnContractN",
				"QtyMgmt.setSummaryGroupUpDnContractN");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryOff", "QtyMgmt.setSummaryOff");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryOn", "QtyMgmt.setSummaryOn");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryPathed", "QtyMgmt.setSummaryPathed");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummaryReceiptQty", "QtyMgmt.setSummaryReceiptQty");

		newString = Replacer.simpleReplace(newString, "QTYMGMT_SetSummarySingleLocation",
				"QtyMgmt.setSummarySingleLocation");

		newString = Replacer.simpleReplace(newString, "QUERY_Append", "Query.append");

		newString = Replacer.simpleReplace(newString, "QUERY_CleanQueryTables", "Query.cleanQueryTables");

		newString = Replacer.simpleReplace(newString, "QUERY_Clear", "Query.clear");

		newString = Replacer.simpleReplace(newString, "QUERY_Delete", "Query.delete");

		newString = Replacer.simpleReplace(newString, "QUERY_ExecuteDirect", "Query.executeDirect");

		newString = Replacer.simpleReplace(newString, "QUERY_GetListBy", "Util.queryGetListBy");

		newString = Replacer.simpleReplace(newString, "QUERY_GetQueryIdFromBrowser", "Query.getQueryIdFromBrowser");

		newString = Replacer.simpleReplace(newString, "QUERY_GetQueryIdFromCaller", "Query.getQueryIdFromCaller");

		newString = Replacer.simpleReplace(newString, "QUERY_GetQueryNameFromBrowser", "Query.getQueryNameFromBrowser");

		newString = Replacer.simpleReplace(newString, "QUERY_Insert", "Query.insert");

		newString = Replacer.simpleReplace(newString, "QUERY_Run", "Query.run");

		newString = Replacer.simpleReplace(newString, "RATE_ExportRateData", "Rate.exportRateData");

		newString = Replacer.simpleReplace(newString, "RATE_ExportRateScheduleDataToTable",
				"Rate.exportRateScheduleDataToTable");

		newString = Replacer.simpleReplace(newString, "RATE_ExportStaticData", "Rate.exportStaticData");

		newString = Replacer.simpleReplace(newString, "RATE_ImportRateData", "Rate.importRateData");

		newString = Replacer.simpleReplace(newString, "RATE_ImportRateSchDataFromTable",
				"Rate.importRateScheduleDataFromTable");

		newString = Replacer.simpleReplace(newString, "RATE_ImportStaticData", "Rate.importStaticData");

		newString = Replacer.simpleReplace(newString, "RATE_RepriceScheduledDeals", "Rate.repriceScheduledDeals");

		newString = Replacer.simpleReplace(newString, "RATE_ScheduleRepricing", "Rate.scheduleRepricing");

		newString = Replacer.simpleReplace(newString, "RECON_DeleteDefinition", "Recon.deleteDefinition");

		newString = Replacer.simpleReplace(newString, "RECON_DeleteImportFile", "Recon.deleteImportFile");

		newString = Replacer.simpleReplace(newString, "RECON_DeleteImportRow", "Recon.deleteImportRow");

		newString = Replacer.simpleReplace(newString, "RECON_ParseSwiftMessage", "Recon.parseSwiftMessage");

		newString = Replacer.simpleReplace(newString, "RECON_RunDefinition", "Recon.runDefinition");

		newString = Replacer.simpleReplace(newString, "RECON_RunDefinitionQueries", "Recon.runDefinitionQueries");

		newString = Replacer.simpleReplace(newString, "RECON_SaveImportData", "Recon.saveImportData");

		newString = Replacer.simpleReplace(newString, "RECON_SaveImportField", "Recon.saveImportField");

		newString = Replacer.simpleReplace(newString, "RECON_StartNewFile", "Recon.startNewFile");

		newString = Replacer.simpleReplace(newString, "RECON_UpdateFileStatus", "Recon.updateFileStatus");

		newString = Replacer.simpleReplace(newString, "RECON_UpdateInputMessageFileID",
				"Recon.updateInputMessageFileID");

		newString = Replacer.simpleReplace(newString, "RECON_UpdateOutputMessageFileID",
				"Recon.updateOutputMessageFileID");

		if (newString.contains("REPO_GetAuxTable")) {
			tableObjectName = newString.substring(newString.indexOf("REPO_GetAuxTable"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REPO_GetAuxTable"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".repoGetAuxTable()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REPO_GetSpotPrice")) {
			tableObjectName = newString.substring(newString.indexOf("REPO_GetSpotPrice"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REPO_GetSpotPrice"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".repoGetSpotPrice()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REPO_GetTranFromCollateral")) {
			tableObjectName = newString.substring(newString.indexOf("REPO_GetTranFromCollateral"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REPO_GetTranFromCollateral"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".repoGetTranFromCollateral()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REPO_ProcessTran")) {
			tableObjectName = newString.substring(newString.indexOf("REPO_ProcessTran"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REPO_ProcessTran"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REPO_RecalculateTran")) {
			tableObjectName = newString.substring(newString.indexOf("REPO_RecalculateTran"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REPO_RecalculateTran"),
					tableObjectName.indexOf(")") + 1);
			tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
			tableObjectName = tableObjectName + ".repoRecalculateTran()";
			tableObjectName = newString.replace(temp, tableObjectName);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("compute_total_seconds_in_GMT_date_range")) {
			tableObjectName = newString.substring(0, newString.indexOf("compute_total_seconds_in_GMT_date_range"));
			temp = newString.substring(newString.indexOf("compute_total_seconds_in_GMT_date_range"),
					newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_FormatCell")) {

			tableObjectName = newString.substring(newString.indexOf("TABLE_FormatCell"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_FormatCell"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_FormatCellData")) {

			tableObjectName = newString.substring(newString.indexOf("TABLE_FormatCellData"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_FormatCellData"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_FormatCellDataN")) {

			tableObjectName = newString.substring(newString.indexOf("TABLE_FormatCellDataN"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_FormatCellDataN"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_FormatCellN")) {

			tableObjectName = newString.substring(newString.indexOf("TABLE_FormatCellN"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_FormatCellN"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_RemoveIndexFromVaRDef")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_RemoveIndexFromVaRDef"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_RemoveIndexFromVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_RemoveIndexMapFromVaRDef")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_RemoveIndexMapFromVaRDef"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_RemoveIndexMapFromVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_RemoveVolatilityFromVaRDef")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_RemoveVolatilityFromVaRDef"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_RemoveVolatilityFromVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_RemoveVolatilityMapFromVaRDef")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_RemoveVolatilityMapFromVaRDef"),
					newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_SetVaRDefName")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_SetVaRDefName"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_SetVaRDefName"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("VAR_SaveVaRDef")) {
			tableObjectName = newString.substring(newString.indexOf("VAR_SaveVaRDef"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("VAR_SaveVaRDef"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_FormatString")) {

			tableObjectName = newString.substring(newString.indexOf("TABLE_FormatString"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_FormatString"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		return newString;
	}

}
