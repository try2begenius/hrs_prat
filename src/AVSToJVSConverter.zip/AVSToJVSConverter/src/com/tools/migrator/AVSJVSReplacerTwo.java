package com.tools.migrator;

public class AVSJVSReplacerTwo {

	public static String replacecoreFunctionCall1(String newString) {

		String returnString = null;
		String tableObjectName = null;
		String temp = null;
		returnString = newString;

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_PIPELINE_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_PIPELINE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANS_STATUS_TABLE", "SHM_USR_TABLES_ENUM.TRANS_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_ZONE_TABLE", "SHM_USR_TABLES_ENUM.GAS_PHYS_ZONE_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_LOCATION_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_LOCATION_TABLE");

		newString = Replacer.simpleReplace(newString, "UNIT_DISPLAY_TABLE", "SHM_USR_TABLES_ENUM.UNIT_DISPLAY_TABLE");

		newString = Replacer.simpleReplace(newString, "RESULT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.RESULT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "REVAL_TYPE_TABLE", "SHM_USR_TABLES_ENUM.REVAL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PERSONNEL_TABLE", "SHM_USR_TABLES_ENUM.PERSONNEL_TABLE");

		newString = Replacer.simpleReplace(newString, "PORTFOLIO_TABLE", "SHM_USR_TABLES_ENUM.PORTFOLIO_TABLE");

		newString = Replacer.simpleReplace(newString, "INSTRUMENTS_TABLE", "SHM_USR_TABLES_ENUM.INSTRUMENTS_TABLE");

		newString = Replacer.simpleReplace(newString, "INDEX_TABLE", "SHM_USR_TABLES_ENUM.INDEX_TABLE");

		newString = Replacer.simpleReplace(newString, "PROJECTION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.PROJECTION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "VALUE_STATUS_TABLE", "SHM_USR_TABLES_ENUM.VALUE_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_TABLE", "SHM_USR_TABLES_ENUM.PARTY_TABLE");

		newString = Replacer.simpleReplace(newString, "DEBIT_CREDIT_TABLE", "SHM_USR_TABLES_ENUM.DEBIT_CREDIT_TABLEL");

		newString = Replacer.simpleReplace(newString, "OPTION_TYPE_TABLE", "SHM_USR_TABLES_ENUM.OPTION_TYPE_TABLEL");

		newString = Replacer.simpleReplace(newString, "NO_YES_TABLE", "SHM_USR_TABLES_ENUM.NO_YES_TABLE");

		newString = Replacer.simpleReplace(newString, "YES_NO_TABLE", "SHM_USR_TABLES_ENUM.YES_NO_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_CLASS_TABLE", "SHM_USR_TABLES_ENUM.INS_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_UNIT_TABLE", "SHM_USR_TABLES_ENUM.IDX_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICING_MODEL_TABLE", "SHM_USR_TABLES_ENUM.PRICING_MODEL_TABLE");

		newString = Replacer.simpleReplace(newString, "HOL_TYPE_TABLE", "SHM_USR_TABLES_ENUM.HOL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "HOL_ID_TABLE", "SHM_USR_TABLES_ENUM.HOL_ID_TABLE");

		newString = Replacer.simpleReplace(newString, "REC_PAY_TABLE", "SHM_USR_TABLES_ENUM.REC_PAY_TABLE");

		newString = Replacer.simpleReplace(newString, "FX_FLT_TABLE", "SHM_USR_TABLES_ENUM.FX_FLT_TABLE");

		newString = Replacer.simpleReplace(newString, "CURRENCY_TABLE", "SHM_USR_TABLES_ENUM.CURRENCY_TABLE");

		newString = Replacer.simpleReplace(newString, "PAYMENT_CONV_TABLE", "SHM_USR_TABLES_ENUM.PAYMENT_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "YIELD_BASIS_TABLE", "SHM_USR_TABLES_ENUM.YIELD_BASIS_TABLE");

		newString = Replacer.simpleReplace(newString, "ROLL_CONV_TABLE", "SHM_USR_TABLES_ENUM.ROLL_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "ROLL_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ROLL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PYMT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.PYMT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "AVG_TYPE_TABLE", "SHM_USR_TABLES_ENUM.AVG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ANNUITY_TABLE", "SHM_USR_TABLES_ENUM.ANNUITY_TABLE");

		newString = Replacer.simpleReplace(newString, "RESET_CALC_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RESET_CALC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "STATES_TABLE", "SHM_USR_TABLES_ENUM.STATES_TABLE");

		newString = Replacer.simpleReplace(newString, "BUY_SELL_TABLE", "SHM_USR_TABLES_ENUM.BUY_SELL_TABLE");

		newString = Replacer.simpleReplace(newString, "PUT_CALL_TABLE", "SHM_USR_TABLES_ENUM.PUT_CALL_TABLE");

		newString = Replacer.simpleReplace(newString, "ATM_SPREAD_TABLE", "SHM_USR_TABLES_ENUM.ATM_SPREAD_TABLE");

		newString = Replacer.simpleReplace(newString, "RECEIVER_PAYER_TABLE",
				"SHM_USR_TABLES_ENUM.RECEIVER_PAYER_TABLE");

		newString = Replacer.simpleReplace(newString, "CFLOW_TYPE_TABLE", "SHM_USR_TABLES_ENUM.CFLOW_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FULL_RESET_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.FULL_RESET_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "ASSET_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ASSET_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "REF_SOURCE_TABLE", "SHM_USR_TABLES_ENUM.REF_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANS_TYPE_TABLE", "SHM_USR_TABLES_ENUM.TRANS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PORTFOLIO_TABLE", "SHM_USR_TABLES_ENUM.PORTFOLIO_TABLE");

		newString = Replacer.simpleReplace(newString, "COUNTRY_TABLE", "SHM_USR_TABLES_ENUM.COUNTRY_TABLE");

		newString = Replacer.simpleReplace(newString, "SETTLEMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.SETTLEMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TOOLSETS_TABLE", "SHM_USR_TABLES_ENUM.TOOLSETS_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_CLASS_TABLE", "SHM_USR_TABLES_ENUM.PARTY_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_STATUS_TABLE", "SHM_USR_TABLES_ENUM.PARTY_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_RATING_TABLE", "SHM_USR_TABLES_ENUM.CREDIT_RATING_TABLE");

		newString = Replacer.simpleReplace(newString, "CAPITAL_ADEQUACY_TABLE",
				"SHM_USR_TABLES_ENUM.CAPITAL_ADEQUACY_TABLE");

		newString = Replacer.simpleReplace(newString, "QUARTERLY_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.QUARTERLY_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "INTERNAL_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.INTERNAL_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "SIC_CODE_TABLE", "SHM_USR_TABLES_ENUM.SIC_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "ISC_CODE_TABLE", "SHM_USR_TABLES_ENUM.ISC_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "CIS_CODE_TABLE", "SHM_USR_TABLES_ENUM.CIS_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_PURPOSE_TABLE", "SHM_USR_TABLES_ENUM.IDX_PURPOSE_TABLE");

		newString = Replacer.simpleReplace(newString, "FUNCTION_TYPE_TABLE", "SHM_USR_TABLES_ENUM.FUNCTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "POSITIVE_NEGATIVE_TABLE",
				"SHM_USR_TABLES_ENUM.POSITIVE_NEGATIVE_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_CODE_TABLE", "SHM_USR_TABLES_ENUM.DELIVERY_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_MECHANISM_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_MECHANISM_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_GROUP_TABLE", "SHM_USR_TABLES_ENUM.IDX_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "DOC_TYPE_TABLE", "SHM_USR_TABLES_ENUM.DOC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DOC_STATUS_TABLE", "SHM_USR_TABLES_ENUM.DOC_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "LAW_TYPE_TABLE", "SHM_USR_TABLES_ENUM.LAW_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FUNCTIONAL_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.FUNCTIONAL_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "PERSONNEL_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PERSONNEL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PERSONNEL_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.PERSONNEL_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "PORTFOLIO_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PORTFOLIO_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CASH_TRANSFER_TABLE", "SHM_USR_TABLES_ENUM.CASH_TRANSFER_TABLE");

		newString = Replacer.simpleReplace(newString, "EVENT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.EVENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "INTERNAL_CONFIRMATION_TABLE",
				"SHM_USR_TABLES_ENUM.INTERNAL_CONFIRMATION_TABLE");

		newString = Replacer.simpleReplace(newString, "EXTERNAL_CONFIRMATION_TABLE",
				"SHM_USR_TABLES_ENUM.EXTERNAL_CONFIRMATION_TABLE");

		newString = Replacer.simpleReplace(newString, "MONTHS_TABLE", "SHM_USR_TABLES_ENUM.MONTHS_TABLE");

		newString = Replacer.simpleReplace(newString, "DAYS_TABLE", "SHM_USR_TABLES_ENUM.DAYS_TABLE");

		newString = Replacer.simpleReplace(newString, "NOTES_DB_TABLE", "SHM_USR_TABLES_ENUM.NOTES_DB_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_RISK_TABLE", "SHM_USR_TABLES_ENUM.CREDIT_RISK_TABLE");

		newString = Replacer.simpleReplace(newString, "OFF_ON_TABLE", "SHM_USR_TABLES_ENUM.OFF_ON_TABLE");

		newString = Replacer.simpleReplace(newString, "AMOUNT_PERCENT_TABLE",
				"SHM_USR_TABLES_ENUM.AMOUNT_PERCENT_TABLE");

		newString = Replacer.simpleReplace(newString, "AUTHORIZATION_TABLE", "SHM_USR_TABLES_ENUM.AUTHORIZATION_TABLE");

		newString = Replacer.simpleReplace(newString, "RISK_CHECKING_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RISK_CHECKING_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CLASS_TABLE", "SHM_USR_TABLES_ENUM.CREDIT_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "INTERNAL_EXTERNAL_TABLE",
				"SHM_USR_TABLES_ENUM.INTERNAL_EXTERNAL_TABLE");

		newString = Replacer.simpleReplace(newString, "RSK_VALUE_TYPES", "SHM_USR_TABLES_ENUM.RSK_VALUE_TYPES");

		newString = Replacer.simpleReplace(newString, "MDO_FEED_TYPE_TABLE", "SHM_USR_TABLES_ENUM.MDO_FEED_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RISK_CLASS_TABLE", "SHM_USR_TABLES_ENUM.RISK_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_LISTING_TABLE", "SHM_USR_TABLES_ENUM.IDX_LISTING_TABLE");

		newString = Replacer.simpleReplace(newString, "SCRIPT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.SCRIPT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "MIN_MAX_LIMIT_TABLE", "SHM_USR_TABLES_ENUM.MIN_MAX_LIMIT_TABLE");

		newString = Replacer.simpleReplace(newString, "TIME_UNIT_TABLE", "SHM_USR_TABLES_ENUM.TIME_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "JOB_STATUS_TABLE", "SHM_USR_TABLES_ENUM.JOB_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "JOB_RESPONSE_TABLE", "SHM_USR_TABLES_ENUM.JOB_RESPONSE_TABLE");

		newString = Replacer.simpleReplace(newString, "MESSAGE_SCOPE_TABLE", "SHM_USR_TABLES_ENUM.MESSAGE_SCOPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_TYPE_TABLE", "SHM_USR_TABLES_ENUM.DELIVERY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FTP_INDEX_PURPOSE_TABLE",
				"SHM_USR_TABLES_ENUM.FTP_INDEX_PURPOSE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_SUBLEDGER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_SUBLEDGER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_SUBLEDGER_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_SUBLEDGER_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_DEFINITION_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_DEFINITION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_QUERY_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_QUERY_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_SUB_TYPE_TABLE", "SHM_USR_TABLES_ENUM.INS_SUB_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RESET_HOLIDAY_OPTION_TABLE",
				"SHM_USR_TABLES_ENUM.RESET_HOLIDAY_OPTION_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_COMPONENT_TABLE", "SHM_USR_TABLES_ENUM.IDX_COMPONENT_TABLE");

		newString = Replacer.simpleReplace(newString, "AUTHORIZED_PERSONNEL_TABLE",
				"SHM_USR_TABLES_ENUM.AUTHORIZED_PERSONNEL_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_ENTRY_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_ENTRY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RISK_FILTER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RISK_FILTER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_FEED_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_FEED_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RISK_MATURITY_BUCKET_TABLE",
				"SHM_USR_TABLES_ENUM.RISK_MATURITY_BUCKET_TABLE");

		newString = Replacer.simpleReplace(newString, "INDEX_STATUS_TABLE", "SHM_USR_TABLES_ENUM.INDEX_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "INDEX_MARKET_TABLE", "SHM_USR_TABLES_ENUM.INDEX_MARKET_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_MARKET_TABLE", "SHM_USR_TABLES_ENUM.IDX_MARKET_TABLE");

		newString = Replacer.simpleReplace(newString, "INDEX_CLASS_TABLE", "SHM_USR_TABLES_ENUM.INDEX_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_CLASS_TABLE", "SHM_USR_TABLES_ENUM.IDX_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "INDEX_INTERP_TABLE", "SHM_USR_TABLES_ENUM.INDEX_INTERP_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_RATING_TABLE", "SHM_USR_TABLES_ENUM.PARTY_RATING_TABLE");

		newString = Replacer.simpleReplace(newString, "OFFSET_TRAN_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.OFFSET_TRAN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPTION_STATUS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.OPTION_STATUS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RSK_EXCEPTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RSK_EXCEPTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRAN_INFO_DATA_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TRAN_INFO_DATA_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PROV_STATUS_TABLE", "SHM_USR_TABLES_ENUM.PROV_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "PROV_TYPE_TABLE", "SHM_USR_TABLES_ENUM.PROV_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RTP_UPDATE_METHOD", "SHM_USR_TABLES_ENUM.RTP_UPDATE_METHOD");

		newString = Replacer.simpleReplace(newString, "PROV_UNIT_TABLE", "SHM_USR_TABLES_ENUM.PROV_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "PROV_PAY_FREQ_TABLE", "SHM_USR_TABLES_ENUM.PROV_PAY_FREQ_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_TRAN_TYPE", "SHM_USR_TABLES_ENUM.GAS_PHYS_TRAN_TYPE");

		newString = Replacer.simpleReplace(newString, "TMAINT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.TMAINT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_CALC_METHOD",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_CALC_METHOD");

		newString = Replacer.simpleReplace(newString, "TODAY_COMPARISON_TABLE",
				"SHM_USR_TABLES_ENUM.TODAY_COMPARISON_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_CRITERIA_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_CRITERIA_TABLE");

		newString = Replacer.simpleReplace(newString, "COMPOUNDING_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.COMPOUNDING_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DATE_SEQUENCE_TABLE", "SHM_USR_TABLES_ENUM.DATE_SEQUENCE_TABLE");

		newString = Replacer.simpleReplace(newString, "OBJECTS_TABLE", "SHM_USR_TABLES_ENUM.OBJECTS_TABLE");

		newString = Replacer.simpleReplace(newString, "GROUPS_TABLE", "SHM_USR_TABLES_ENUM.GROUPS_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_TRAN_TYPE_TABLE", "SHM_USR_TABLES_ENUM.PWR_TRAN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TIME_ZONE_TABLE", "SHM_USR_TABLES_ENUM.TIME_ZONE_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICE_BAND_TABLE", "SHM_USR_TABLES_ENUM.PRICE_BAND_TABLE");

		newString = Replacer.simpleReplace(newString, "PORTFOLIO_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.PORTFOLIO_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_CHOICE_TABLE", "SHM_USR_TABLES_ENUM.PWR_CHOICE_TABLE");

		newString = Replacer.simpleReplace(newString, "YIELD_CALC_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.YIELD_CALC_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCINT_CALC_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.ACCINT_CALC_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_REGION_TABLE", "SHM_USR_TABLES_ENUM.PWR_REGION_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_CTL_AREA_TABLE", "SHM_USR_TABLES_ENUM.PWR_CTL_AREA_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_LOCATION_TABLE", "SHM_USR_TABLES_ENUM.PWR_LOCATION_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_PRODUCT_TABLE", "SHM_USR_TABLES_ENUM.PWR_PRODUCT_TABLE");

		newString = Replacer.simpleReplace(newString, "PRODUCT_TABLE", "SHM_USR_TABLES_ENUM.PRODUCT_TABLE");

		newString = Replacer.simpleReplace(newString, "INITIAL_TERM_TABLE", "SHM_USR_TABLES_ENUM.INITIAL_TERM_TABLE");

		newString = Replacer.simpleReplace(newString, "SERVICE_TYPE_TABLE", "SHM_USR_TABLES_ENUM.SERVICE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "SERVICE_DESC_TABLE", "SHM_USR_TABLES_ENUM.SERVICE_DESC_TABLE");

		newString = Replacer.simpleReplace(newString, "DEMAND_METHOD_TABLE", "SHM_USR_TABLES_ENUM.DEMAND_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_HOURLY_ADJUSTMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_HOURLY_ADJUSTMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ROUND_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ROUND_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_OR_TRAN_TABLE", "SHM_USR_TABLES_ENUM.INS_OR_TRAN_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCOUNT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ACCOUNT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "INTERP_STUB_TABLE", "SHM_USR_TABLES_ENUM.INTERP_STUB_TABLE");

		newString = Replacer.simpleReplace(newString, "LTP_DEAL_TYPE_TABLE", "SHM_USR_TABLES_ENUM.LTP_DEAL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_DEAL_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_DEAL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RESET_RATE_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.RESET_RATE_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "SPOTPX_RESET_TYPE", "SHM_USR_TABLES_ENUM.SPOTPX_RESET_TYPE");

		newString = Replacer.simpleReplace(newString, "SCHED_REVERSAL_INTERVAL_TABLE",
				"SHM_USR_TABLES_ENUM.SCHED_REVERSAL_INTERVAL_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_WAS_SCHEDULE_DETAIL_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_WAS_SCHEDULE_DETAIL_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_WAS_PWR_SCHEDULE_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_WAS_PWR_SCHEDULE_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "BARRIER_TYPE_TABLE", "SHM_USR_TABLES_ENUM.BARRIER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "BARRIER_IN_OR_OUT_TABLE",
				"SHM_USR_TABLES_ENUM.BARRIER_IN_OR_OUT_TABLE");

		newString = Replacer.simpleReplace(newString, "CASH_FLOW_OFFSET_TABLE",
				"SHM_USR_TABLES_ENUM.CASH_FLOW_OFFSET_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_SYSTEM_INDICATOR_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_SYSTEM_INDICATOR_TABLE");

		newString = Replacer.simpleReplace(newString, "CURRENCY_ZONE_TABLE", "SHM_USR_TABLES_ENUM.CURRENCY_ZONE_TABLE");

		newString = Replacer.simpleReplace(newString, "GEOGRAPHIC_ZONE_TABLE",
				"SHM_USR_TABLES_ENUM.GEOGRAPHIC_ZONE_TABLE");

		newString = Replacer.simpleReplace(newString, "EXTERNAL_SYSTEMS_TABLE",
				"SHM_USR_TABLES_ENUM.EXTERNAL_SYSTEMS_TABLE");

		newString = Replacer.simpleReplace(newString, "INT_THRESHOLD_PERIOD_TABLE",
				"SHM_USR_TABLES_ENUM.INT_THRESHOLD_PERIOD_TABLE");

		newString = Replacer.simpleReplace(newString, "INT_CALC_FREQUENCY_TABLE",
				"SHM_USR_TABLES_ENUM.INT_CALC_FREQUENCY_TABLE");

		newString = Replacer.simpleReplace(newString, "INT_TRANSFER_TABLE", "SHM_USR_TABLES_ENUM.INT_TRANSFER_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_VALUE_POOL_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_VALUE_POOL_TABLE");

		newString = Replacer.simpleReplace(newString, "CALC_SIGN", "SHM_USR_TABLES_ENUM.CALC_SIGN");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_PATH_TABLE", "SHM_USR_TABLES_ENUM.GAS_PHYS_PATH_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_LOC_DIR_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_LOC_DIR_TABLE");

		newString = Replacer.simpleReplace(newString, "STP_EXCEPTION_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.STP_EXCEPTION_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCOUNT_TABLE", "SHM_USR_TABLES_ENUM.ACCOUNT_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCINT_ROUNDING_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.ACCINT_ROUNDING_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_HOURLY_MATRIX_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_HOURLY_MATRIX_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_SCHEDULE_ADJUSTMENT_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_SCHEDULE_ADJUSTMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "RSK_SPECIAL_NOTE_TABLE",
				"SHM_USR_TABLES_ENUM.RSK_SPECIAL_NOTE_TABLE");

		newString = Replacer.simpleReplace(newString, "HEDGE_TYPE_TABLE", "SHM_USR_TABLES_ENUM.HEDGE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_GROUP_TABLE", "SHM_USR_TABLES_ENUM.INS_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "REPO_CATEGORY_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.REPO_CATEGORY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "LEG_TYPE_TABLE", "SHM_USR_TABLES_ENUM.LEG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "BAR_STATUS_TABLE", "SHM_USR_TABLES_ENUM.BAR_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_DATA_CFG_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_DATA_CFG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FEE_VOLUME_CALC_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.FEE_VOLUME_CALC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOLUME_TYPE_TABLE", "SHM_USR_TABLES_ENUM.VOLUME_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_SCHEDULE_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_SCHEDULE_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "SCHEDULE_DETAIL_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.SCHEDULE_DETAIL_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCOUNTING_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.ACCOUNTING_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "EVENT_SOURCE_TABLE", "SHM_USR_TABLES_ENUM.EVENT_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICING_FUNCTION_TABLE",
				"SHM_USR_TABLES_ENUM.PRICING_FUNCTION_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY1", "SHM_USR_TABLES_ENUM.DUMMY1");

		newString = Replacer.simpleReplace(newString, "PRICING_APPLY_TRANSPORT_TABLE", "SHM_USR_TABLES_ENUM.SHELL");

		newString = Replacer.simpleReplace(newString, "ACCOUNT_CLASS_TABLE", "SHM_USR_TABLES_ENUM.ACCOUNT_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "SWING_STYLE_TABLE", "SHM_USR_TABLES_ENUM.SWING_STYLE_TABLE");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.OUTBOUND_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "VOLUME_CALC_PERIOD_TABLE",
				"SHM_USR_TABLES_ENUM.VOLUME_CALC_PERIOD_TABLE");

		newString = Replacer.simpleReplace(newString, "INDEX_LOCATION_TABLE",
				"SHM_USR_TABLES_ENUM.INDEX_LOCATION_TABLE");

		newString = Replacer.simpleReplace(newString, "PUBLICATION_TABLE", "SHM_USR_TABLES_ENUM.PUBLICATION_TABLE");

		newString = Replacer.simpleReplace(newString, "NOSTRO_FLAG_TABLE", "SHM_USR_TABLES_ENUM.NOSTRO_FLAG_TABLE");

		newString = Replacer.simpleReplace(newString, "TLINK_ALLOC_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.TLINK_ALLOC_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "FEE_TYPE_DEF_TABLE", "SHM_USR_TABLES_ENUM.FEE_TYPE_DEF_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICING_IDX_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PRICING_IDX_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_INCREMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_INCREMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACTIVITY_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ACTIVITY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ALL_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ALL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "G_ENV_ORIGIN_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.G_ENV_ORIGIN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TOLERANCE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TOLERANCE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "EVERGREEN_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.EVERGREEN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RISK_LIMIT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RISK_LIMIT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY2", "SHM_USR_TABLES_ENUM.DUMMY2");

		newString = Replacer.simpleReplace(newString, "TRIGGER_DATA_ACTION", "SHM_USR_TABLES_ENUM.TRIGGER_DATA_ACTION");

		newString = Replacer.simpleReplace(newString, "PRICING_LEVEL_TABLE", "SHM_USR_TABLES_ENUM.PRICING_LEVEL_TABLE");

		newString = Replacer.simpleReplace(newString, "STORAGE_TYPE_TABLE", "SHM_USR_TABLES_ENUM.STORAGE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSPORT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSPORT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "SETTLE_ADJUSTMENT_TYPE",
				"SHM_USR_TABLES_ENUM.SETTLE_ADJUSTMENT_TYPE");

		newString = Replacer.simpleReplace(newString, "CE_PS_COUNTY_TABLE", "SHM_USR_TABLES_ENUM.CE_PS_COUNTY_TABLE");

		newString = Replacer.simpleReplace(newString, "AGREEMENT_TABLE", "SHM_USR_TABLES_ENUM.AGREEMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "KEEP_WHOLE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.KEEP_WHOLE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NOTNL_TYPE_TABLE", "SHM_USR_TABLES_ENUM.NOTNL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_PRODUCT_MATRIX_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_PRODUCT_MATRIX_TABLEL");

		newString = Replacer.simpleReplace(newString, "PRODUCT_MATRIX_TABLE",
				"SHM_USR_TABLES_ENUM.PRODUCT_MATRIX_TABLE");

		newString = Replacer.simpleReplace(newString, "FUEL_CALC_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.FUEL_CALC_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "UNIT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.UNIT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "EX_COUPON_TREATMENT_TABLE",
				"SHM_USR_TABLES_ENUM.EX_COUPON_TREATMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_EXT_QUERY_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_EXT_QUERY_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_EXT_RULE_DEFINITION_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_EXT_RULE_DEFINITION_TABLE");

		newString = Replacer.simpleReplace(newString, "EXPIRY_CUT_TABLE", "SHM_USR_TABLES_ENUM.EXPIRY_CUT_TABLE");

		newString = Replacer.simpleReplace(newString, "PROVIDER_CHARGE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PROVIDER_CHARGE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NON_GBD_ROLL_TABLE", "SHM_USR_TABLES_ENUM.NON_GBD_ROLL_TABLE");

		newString = Replacer.simpleReplace(newString, "PIVOT_NON_GBD_RULE_TABLE",
				"SHM_USR_TABLES_ENUM.PIVOT_NON_GBD_RULE_TABLE");

		newString = Replacer.simpleReplace(newString, "PIVOT_REF_ROLL_TABLE",
				"SHM_USR_TABLES_ENUM.PIVOT_REF_ROLL_TABLE");

		newString = Replacer.simpleReplace(newString, "ANE_UPDATE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ANE_UPDATE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TLINK_FLOW_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.TLINK_FLOW_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_REGIONS_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_REGIONS_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_LOC_TYPE", "SHM_USR_TABLES_ENUM.GAS_PHYS_LOC_TYPE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_CONNECTION_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_CONNECTION_TABLE");

		newString = Replacer.simpleReplace(newString, "HEDGE_BY_TYPE_TABLE", "SHM_USR_TABLES_ENUM.HEDGE_BY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "HEDGE_WITH_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.HEDGE_WITH_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DIR_NODE_TYPE_TABLE", "SHM_USR_TABLES_ENUM.DIR_NODE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PRIMARY_RESELL_TABLE",
				"SHM_USR_TABLES_ENUM.PRIMARY_RESELL_TABLE");

		newString = Replacer.simpleReplace(newString, "VAR_SUMMARY_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.VAR_SUMMARY_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "AUTHORIZED_EXT_PERSONNEL_TABLE",
				"SHM_USR_TABLES_ENUM.AUTHORIZED_EXT_PERSONNEL_TABLE");

		newString = Replacer.simpleReplace(newString, "VOLUME_STATUS_TABLE", "SHM_USR_TABLES_ENUM.VOLUME_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_TRANSMISSION_PATH_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_TRANSMISSION_PATH_TABLE");

		newString = Replacer.simpleReplace(newString, "TLINK_PRICE_CRITERIA_TABLE",
				"SHM_USR_TABLES_ENUM.TLINK_PRICE_CRITERIA_TABLE");

		newString = Replacer.simpleReplace(newString, "PAYMENT_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.PAYMENT_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "VOLUME_CALCULATION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.VOLUME_CALCULATION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "LOSS_METHOD_TABLE", "SHM_USR_TABLES_ENUM.LOSS_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "KEEP_WHOLE_OWNER_TABLE",
				"SHM_USR_TABLES_ENUM.KEEP_WHOLE_OWNER_TABLE");

		newString = Replacer.simpleReplace(newString, "OPTION_STRIKE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.OPTION_STRIKE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPTION_STRIKE_FIELD_TABLE",
				"SHM_USR_TABLES_ENUM.OPTION_STRIKE_FIELD_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_PRODUCT_LOAD_SHAPE_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_PRODUCT_LOAD_SHAPE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_MARKET_DATA_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_MARKET_DATA_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_FORMAT_TABLE", "SHM_USR_TABLES_ENUM.IDX_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_GPT_AIF_TABLE", "SHM_USR_TABLES_ENUM.IDX_GPT_AIF_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_INTERP_TABLE", "SHM_USR_TABLES_ENUM.IDX_INTERP_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICE_FORMAT_TABLE", "SHM_USR_TABLES_ENUM.PRICE_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "GPT_INP_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.GPT_INP_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "GPT_FULL_INS_CAT_TABLE",
				"SHM_USR_TABLES_ENUM.GPT_FULL_INS_CAT_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_INDEX_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_INDEX_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_DB_STATUS_TABLE", "SHM_USR_TABLES_ENUM.IDX_DB_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_GPT_TYPE", "SHM_USR_TABLES_ENUM.IDX_GPT_TYPE");

		newString = Replacer.simpleReplace(newString, "IDX_GPT_INS_TYPE", "SHM_USR_TABLES_ENUM.IDX_GPT_INS_TYPE");

		newString = Replacer.simpleReplace(newString, "TRUE_FALSE_TABLE", "SHM_USR_TABLES_ENUM.TRUE_FALSE_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_PRIOR_VALUE_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_PRIOR_VALUE_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_RETURNS_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_RETURNS_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "DIR_SECURITY_PERMISS_TABLE",
				"SHM_USR_TABLES_ENUM.DIR_SECURITY_PERMISS_TABLE");

		newString = Replacer.simpleReplace(newString, "TRADING_MODE_TABLE", "SHM_USR_TABLES_ENUM.TRADING_MODE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPS_SERVICE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.OPS_SERVICE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PHYSICAL_VALUATION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.PHYSICAL_VALUATION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_RATE_SCHEDULE_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_RATE_SCHEDULE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_GROUP_REV_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_GROUP_REV_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TSVPEER_GROUP_TABLE", "SHM_USR_TABLES_ENUM.TSVPEER_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_WAS_MATERIAL_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_WAS_MATERIAL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "MEASUREMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.MEASUREMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "QRY_GROUPS_TABLE", "SHM_USR_TABLES_ENUM.QRY_GROUPS_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_DATA_RANGE_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_DATA_RANGE_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_VC_CALC_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_VC_CALC_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_MISSING_DATA_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_MISSING_DATA_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_DECAY_FACTOR_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_DECAY_FACTOR_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_DEF_TYPE_TABLE", "SHM_USR_TABLES_ENUM.VOL_DEF_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_TYPE_TABLE", "SHM_USR_TABLES_ENUM.VOL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "COR_DECOMP_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.COR_DECOMP_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "VAR_METHOD_TABLE", "SHM_USR_TABLES_ENUM.VAR_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "MEASURE_GROUP_TABLE", "SHM_USR_TABLES_ENUM.MEASURE_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "UPDATE_FREQUENCY_TABLE",
				"SHM_USR_TABLES_ENUM.UPDATE_FREQUENCY_TABLE");

		newString = Replacer.simpleReplace(newString, "TRAN_STATUS_INTERNAL_TABLE",
				"SHM_USR_TABLES_ENUM.TRAN_STATUS_INTERNAL_TABLE");

		newString = Replacer.simpleReplace(newString, "CONSTRAINT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CONSTRAINT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_NOTE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_NOTE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICING_MODEL_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.PRICING_MODEL_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICING_MODEL_ATTR_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PRICING_MODEL_ATTR_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_RATING_SOURCE_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_RATING_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_SERIES_SEL_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_SERIES_SEL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "GPT_SOURCE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.GPT_SOURCE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "POOL_ASSET_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.POOL_ASSET_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "BARRIER_STATES_TABLE",
				"SHM_USR_TABLES_ENUM.BARRIER_STATES_TABLE");

		newString = Replacer.simpleReplace(newString, "PYMT_FMLA_VAR_DATATYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PYMT_FMLA_VAR_DATATYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PYMT_FMLA_VAR_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PYMT_FMLA_VAR_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORR_LOOKUP_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORR_LOOKUP_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ADJ_GROUP_TABLE", "SHM_USR_TABLES_ENUM.ADJ_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "ADJ_FUNCTION_TABLE", "SHM_USR_TABLES_ENUM.ADJ_FUNCTION_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_PRICE_COMPLEX_TABLE",
				"SHM_USR_TABLES_ENUM.INS_PRICE_COMPLEX_TABLE");

		newString = Replacer.simpleReplace(newString, "PRODUCT_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.PRODUCT_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICE_ADJ_LEVEL_TABLE",
				"SHM_USR_TABLES_ENUM.PRICE_ADJ_LEVEL_TABLE");

		newString = Replacer.simpleReplace(newString, "MEMO_STATUS_TABLE", "SHM_USR_TABLES_ENUM.MEMO_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "MASTER_AGREEMENT_TABLE",
				"SHM_USR_TABLES_ENUM.MASTER_AGREEMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "ALERT_GENERAL_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.ALERT_GENERAL_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ALERT_RECEIPT_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.ALERT_RECEIPT_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ALERT_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.ALERT_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "MARKET_PX_LOOKUP_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.MARKET_PX_LOOKUP_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_ADDRESS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_ADDRESS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_PRIORITY_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_PRIORITY_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "INFO_GROUP_TABLE", "SHM_USR_TABLES_ENUM.INFO_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_AGREEMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_AGREEMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_INPUT_FORMAT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_INPUT_FORMAT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "COMMUNICATION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.COMMUNICATION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CHARGE_BASIS_TABLE", "SHM_USR_TABLES_ENUM.CHARGE_BASIS_TABLE");

		newString = Replacer.simpleReplace(newString, "RATE_CATEGORY_TABLE", "SHM_USR_TABLES_ENUM.RATE_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "RATE_TYPE_TABLE", "SHM_USR_TABLES_ENUM.RATE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_LOCATION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_LOCATION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "LOCATION_GROUP_PURPOSE_TABLE",
				"SHM_USR_TABLES_ENUM.LOCATION_GROUP_PURPOSE_TABLE");

		newString = Replacer.simpleReplace(newString, "UNDERLYING_PX_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.UNDERLYING_PX_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "PREMIUM_CREATION_RULE_TABLE",
				"SHM_USR_TABLES_ENUM.PREMIUM_CREATION_RULE_TABLE");

		newString = Replacer.simpleReplace(newString, "MARGIN_TYPE_TABLE", "SHM_USR_TABLES_ENUM.MARGIN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VEGA_METHOD_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VEGA_METHOD_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "LANGUAGE_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.LANGUAGE_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "RSK_CRITERIA_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.RSK_CRITERIA_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "RESET_STATUS_TABLE", "SHM_USR_TABLES_ENUM.RESET_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "RSK_USER_LIMIT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RSK_USER_LIMIT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DEAL_LOCK_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DEAL_LOCK_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ALERT_FREQUENCY_PERIOD_TABLE",
				"SHM_USR_TABLES_ENUM.ALERT_FREQUENCY_PERIOD_TABLE");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_REBALANCE_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.BENCHMARK_REBALANCE_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "BARRIER_TRIGGER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.BARRIER_TRIGGER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ENTITLEMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ENTITLEMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "QUANTITY_TYPE_TABLE", "SHM_USR_TABLES_ENUM.QUANTITY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RELEASE_TYPE_TABLE", "SHM_USR_TABLES_ENUM.RELEASE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ENTITLE_LOC_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ENTITLE_LOC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "EDI_FILE_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.EDI_FILE_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_LOC_TYPE_TABLE", "SHM_USR_TABLES_ENUM.PWR_LOC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_MODEL_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NOM_MODEL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_CAPACITY_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NOM_CAPACITY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "LINKED_STATUS_TABLE", "SHM_USR_TABLES_ENUM.LINKED_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_CYCLE_TABLE", "SHM_USR_TABLES_ENUM.NOM_CYCLE_TABLE");

		newString = Replacer.simpleReplace(newString, "SYSTEM_TRAN_TABLE", "SHM_USR_TABLES_ENUM.SYSTEM_TRAN_TABLE");

		newString = Replacer.simpleReplace(newString, "SWAPTION_VOL_LOOKUP_TABLE",
				"SHM_USR_TABLES_ENUM.SWAPTION_VOL_LOOKUP_TABLE");

		newString = Replacer.simpleReplace(newString, "AVS_SCRIPT_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.AVS_SCRIPT_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "RISK_EXPOSURE_DEFN_SCOPE_TABLE",
				"SHM_USR_TABLES_ENUM.RISK_EXPOSURE_DEFN_SCOPE_TABLE");

		newString = Replacer.simpleReplace(newString, "SEASON_TABLE", "SHM_USR_TABLES_ENUM.SEASON_TABLE");

		newString = Replacer.simpleReplace(newString, "FEE_BASIS_TABLE", "SHM_USR_TABLES_ENUM.FEE_BASIS_TABLE");

		newString = Replacer.simpleReplace(newString, "INVESTOR_ISSUER_TABLE",
				"SHM_USR_TABLES_ENUM.INVESTOR_ISSUER_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_VALIDATION_RULES_TABLE",
				"SHM_USR_TABLES_ENUM.NOM_VALIDATION_RULES_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_VALIDATION_RULE_ACTION_TABLE",
				"SHM_USR_TABLES_ENUM.NOM_VALIDATION_RULE_ACTION_TABLE");

		newString = Replacer.simpleReplace(newString, "LOCATION_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.LOCATION_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "VOLUME_CALC_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VOLUME_CALC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ASSET_SWAP_ACC_TREATMENT_TABLE",
				"SHM_USR_TABLES_ENUM.ASSET_SWAP_ACC_TREATMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "ASSET_SWAP_PRE_TREATMENT_TABLE",
				"SHM_USR_TABLES_ENUM.ASSET_SWAP_PRE_TREATMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "PSI_EXPORT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PSI_EXPORT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PSI_MSG_TYPE_TABLE", "SHM_USR_TABLES_ENUM.PSI_MSG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PSI_STATUS_TABLE", "SHM_USR_TABLES_ENUM.PSI_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "PSI_REQUEST_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PSI_REQUEST_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PSI_WFLOW_ST_TABLE", "SHM_USR_TABLES_ENUM.PSI_WFLOW_ST_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_ACTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_ACTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "EXERCISE_FEE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.EXERCISE_FEE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DEAL_COMMENTS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DEAL_COMMENTS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_TRAN_TYPE_TABLE", "SHM_USR_TABLES_ENUM.NOM_TRAN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FEE_SOURCE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.FEE_SOURCE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_TRANSMISSION_PROVIDER_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_TRANSMISSION_PROVIDER_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_PSE_TABLE", "SHM_USR_TABLES_ENUM.NERC_PSE_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_CONTROL_AREA_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_CONTROL_AREA_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_PRODUCT_TABLE", "SHM_USR_TABLES_ENUM.NERC_PRODUCT_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_PRODUCT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_PRODUCT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_POR_POD_POINT_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_POR_POD_POINT_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_POR_POD_ROLE_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_POR_POD_ROLE_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_SOURCE_SINK_POINT_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_SOURCE_SINK_POINT_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_SOURCE_SINK_ROLE_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_SOURCE_SINK_ROLE_TABLE");

		newString = Replacer.simpleReplace(newString, "YIELD_COMP_FREQ_TABLE",
				"SHM_USR_TABLES_ENUM.YIELD_COMP_FREQ_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_DEFAULT_TRIGGER_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_DEFAULT_TRIGGER_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CLASSIFICATION_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_CLASSIFICATION_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_LOCATION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NOM_LOCATION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PSM_REASON_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PSM_REASON_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSMISSION_LOSS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSMISSION_LOSS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_DOCUMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_DOCUMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_DOCUMENT_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_DOCUMENT_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_DEFINITIONS_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_DEFINITIONS_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_CRITERIA_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_CRITERIA_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_TEMPLATES_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_TEMPLATES_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_OUTPUT_FORMS_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_OUTPUT_FORMS_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_OUTPUT_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_OUTPUT_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "AVS_SCRIPT_CAT_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.AVS_SCRIPT_CAT_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_AGREEMENT_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_AGREEMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "STL_PPA_TYPE_TABLE", "SHM_USR_TABLES_ENUM.STL_PPA_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "STL_PPA_APPROVAL_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.STL_PPA_APPROVAL_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "STL_PPA_APPROVAL_ACTION_TABLE",
				"SHM_USR_TABLES_ENUM.STL_PPA_APPROVAL_ACTION_TABLE");

		newString = Replacer.simpleReplace(newString, "SHARED_PRICE_ROUNDING_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.SHARED_PRICE_ROUNDING_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "INVENTORY_LOSS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.INVENTORY_LOSS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RATE_FORM_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RATE_FORM_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_OUTPUT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_OUTPUT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_LOOKUP_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_LOOKUP_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_AVG_MTHD_TABLE", "SHM_USR_TABLES_ENUM.VOL_AVG_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_DIMENSION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_DIMENSION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RESULT_CLASS_TABLE", "SHM_USR_TABLES_ENUM.RESULT_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "ALLOCATION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.ALLOCATION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "OC_ACT_ACTIVITIES_TABLE",
				"SHM_USR_TABLES_ENUM.OC_ACT_ACTIVITIES_TABLE");

		newString = Replacer.simpleReplace(newString, "OC_ACT_LEVELS_TABLE", "SHM_USR_TABLES_ENUM.OC_ACT_LEVELS_TABLE");

		newString = Replacer.simpleReplace(newString, "OC_ACT_DATA_STATES_TABLE",
				"SHM_USR_TABLES_ENUM.OC_ACT_DATA_STATES_TABLE");

		newString = Replacer.simpleReplace(newString, "OC_ACT_DATA_FORMATS_TABLE",
				"SHM_USR_TABLES_ENUM.OC_ACT_DATA_FORMATS_TABLE");

		newString = Replacer.simpleReplace(newString, "ALLOCATION_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.ALLOCATION_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "OUTBOUND_ACTION_TABLE",
				"SHM_USR_TABLES_ENUM.OUTBOUND_ACTION_TABLE");

		newString = Replacer.simpleReplace(newString, "PIPE_OWNERSHIP_TABLE",
				"SHM_USR_TABLES_ENUM.PIPE_OWNERSHIP_TABLE");

		newString = Replacer.simpleReplace(newString, "VAR_INPUT_SOURCES_TABLE",
				"SHM_USR_TABLES_ENUM.VAR_INPUT_SOURCES_TABLE");

		newString = Replacer.simpleReplace(newString, "VAR_DEAL_VALUATION_MTHDS_TABLE",
				"SHM_USR_TABLES_ENUM.VAR_DEAL_VALUATION_MTHDS_TABLE");

		newString = Replacer.simpleReplace(newString, "FX_FLT_REC_TABLE", "SHM_USR_TABLES_ENUM.FX_FLT_REC_TABLE");

		newString = Replacer.simpleReplace(newString, "OPRISK_LM_LOSS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.OPRISK_LM_LOSS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ENTITLEMENT_RECEIPT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ENTITLEMENT_RECEIPT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FWD_DISPLAY_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.FWD_DISPLAY_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "SCREEN_CONFIG_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.SCREEN_CONFIG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DEAL_VOLUME_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DEAL_VOLUME_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PERSONNEL_LICENSE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PERSONNEL_LICENSE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_ADJ_CAT_TABLE", "SHM_USR_TABLES_ENUM.VOL_ADJ_CAT_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_ADJ_FORM_TABLE", "SHM_USR_TABLES_ENUM.VOL_ADJ_FORM_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_GPT_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_GPT_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_INTERP_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_INTERP_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_INTERP_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_INTERP_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_KEY_TYPES_TABLE", "SHM_USR_TABLES_ENUM.VOL_KEY_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_WAS_SCREEN_CONFIG_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_WAS_SCREEN_CONFIG_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "SCR_CFG_VIEW_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.SCR_CFG_VIEW_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_DIMDEF_USAGE_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_DIMDEF_USAGE_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_GPT_FORM_TABLE", "SHM_USR_TABLES_ENUM.VOL_GPT_FORM_TABLE");

		newString = Replacer.simpleReplace(newString, "FC_SIMPLE_YIELD_TABLE",
				"SHM_USR_TABLES_ENUM.FC_SIMPLE_YIELD_TABLE");

		newString = Replacer.simpleReplace(newString, "DATE_LOCALE_TABLE", "SHM_USR_TABLES_ENUM.DATE_LOCALE_TABLE");

		newString = Replacer.simpleReplace(newString, "DATE_FORMAT_TABLE", "SHM_USR_TABLES_ENUM.DATE_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "MARKET_PX_INP_EFF_TABLE",
				"SHM_USR_TABLES_ENUM.MARKET_PX_INP_EFF_TABLE");

		newString = Replacer.simpleReplace(newString, "RES_ATTR_GRP_TABLE", "SHM_USR_TABLES_ENUM.RES_ATTR_GRP_TABLE");

		newString = Replacer.simpleReplace(newString, "OPRISK_ANOMALY_SCORE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.OPRISK_ANOMALY_SCORE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICE_FORM_TABLE", "SHM_USR_TABLES_ENUM.PRICE_FORM_TABLE");

		newString = Replacer.simpleReplace(newString, "ENGY_PHYS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ENGY_PHYS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FONT_TABLE", "SHM_USR_TABLES_ENUM.FONT_TABLE");

		newString = Replacer.simpleReplace(newString, "NUMBER_LOCALE_TABLE", "SHM_USR_TABLES_ENUM.NUMBER_LOCALE_TABLE");

		newString = Replacer.simpleReplace(newString, "GPT_INP_FORM_TABLE", "SHM_USR_TABLES_ENUM.GPT_INP_FORM_TABLE");

		newString = Replacer.simpleReplace(newString, "SHARED_PRICE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.SHARED_PRICE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPTION_PRICING_SOURCE_TABLE",
				"SHM_USR_TABLES_ENUM.OPTION_PRICING_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "PORTFOLIO_RESTRICT_TABLE",
				"SHM_USR_TABLES_ENUM.PORTFOLIO_RESTRICT_TABLE");

		newString = Replacer.simpleReplace(newString, "ENTITY_GROUP_TABLE", "SHM_USR_TABLES_ENUM.ENTITY_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "JURISDICTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.JURISDICTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "STP_EXCEPTION_HIT_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.STP_EXCEPTION_HIT_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "STP_EXCEPTION_TABLE", "SHM_USR_TABLES_ENUM.STP_EXCEPTION_TABLE");

		newString = Replacer.simpleReplace(newString, "CHANNELS_TABLE", "SHM_USR_TABLES_ENUM.CHANNELS_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_STP_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_STP_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_SEND_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_SEND_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "HISTORY_DB_ACTION_TABLE",
				"SHM_USR_TABLES_ENUM.HISTORY_DB_ACTION_TABLE");

		newString = Replacer.simpleReplace(newString, "TAX_TRAN_TYPE_TABLE", "SHM_USR_TABLES_ENUM.TAX_TRAN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TAX_TRAN_SUBTYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TAX_TRAN_SUBTYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TAX_TYPE_TABLE", "SHM_USR_TABLES_ENUM.TAX_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_DATA_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_DATA_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_STATUS_TABLE", "SHM_USR_TABLES_ENUM.RECON_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_MATCH_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_MATCH_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DDATA_DATA_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DDATA_DATA_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DDATA_QUERY_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DDATA_QUERY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_ADDON_QRY_CRITERIA_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_ADDON_QRY_CRITERIA_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_DEFINITIONS_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_DEFINITIONS_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_IMPORT_FIELD_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_IMPORT_FIELD_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_TYPE_TABLE", "SHM_USR_TABLES_ENUM.RECON_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_GROUPING_CRITERIA_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_GROUPING_CRITERIA_TABLE");

		newString = Replacer.simpleReplace(newString, "BMO_TABLE", "SHM_USR_TABLES_ENUM.BMO_TABLE");

		newString = Replacer.simpleReplace(newString, "BUMP_TYPE_TABLE", "SHM_USR_TABLES_ENUM.BUMP_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VARIANCE_INPUT_TABLE",
				"SHM_USR_TABLES_ENUM.VARIANCE_INPUT_TABLE");

		newString = Replacer.simpleReplace(newString, "INDEX_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.INDEX_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "ADJ_FUNC_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.ADJ_FUNC_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_TYPE_CONFIG_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_TYPE_CONFIG_TABLE");

		newString = Replacer.simpleReplace(newString, "RECON_FILE_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.RECON_FILE_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "OPTION_PRICER_NOTNL_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.OPTION_PRICER_NOTNL_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "RSK_EXCESSION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RSK_EXCESSION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "REVAL_DISTRIBUTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.REVAL_DISTRIBUTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "SETTLE_INSTRUCTIONS_TABLE",
				"SHM_USR_TABLES_ENUM.SETTLE_INSTRUCTIONS_TABLE");

		newString = Replacer.simpleReplace(newString, "PRICE_TIER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PRICE_TIER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "LIMIT_PERCENT_CONVENTION_TABLE",
				"SHM_USR_TABLES_ENUM.LIMIT_PERCENT_CONVENTION_TABLE");

		newString = Replacer.simpleReplace(newString, "LIMIT_CALCULATION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.LIMIT_CALCULATION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "PREPAYMENT_MODEL_TABLE",
				"SHM_USR_TABLES_ENUM.PREPAYMENT_MODEL_TABLE");

		newString = Replacer.simpleReplace(newString, "DELTA_GAMMA_IMPACT_CHOICE_TABLE",
				"SHM_USR_TABLES_ENUM.DELTA_GAMMA_IMPACT_CHOICE_TABLE");

		newString = Replacer.simpleReplace(newString, "VEGA_IMPACT_CHOICE_TABLE",
				"SHM_USR_TABLES_ENUM.VEGA_IMPACT_CHOICE_TABLE");

		newString = Replacer.simpleReplace(newString, "OUTPUT_DELTA_IMPACT_CHOICE_TABLE",
				"SHM_USR_TABLES_ENUM.OUTPUT_DELTA_IMPACT_CHOICE_TABLE");

		newString = Replacer.simpleReplace(newString, "IMPACT_DELTA_COLUMN_CONFIG_TABLE",
				"SHM_USR_TABLES_ENUM.IMPACT_DELTA_COLUMN_CONFIG_TABLE");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_DELTA_DF_CONFIG_TABLE",
				"SHM_USR_TABLES_ENUM.TRAN_GPT_DELTA_DF_CONFIG_TABLE");

		newString = Replacer.simpleReplace(newString, "FX_SPOT_TYPE_TABLE", "SHM_USR_TABLES_ENUM.FX_SPOT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "IMBALANCE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.IMBALANCE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_INDEX_FORMAT_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_INDEX_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "TASK_EXECUTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TASK_EXECUTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_DELTA_CURRENCY_TABLE",
				"SHM_USR_TABLES_ENUM.TRAN_GPT_DELTA_CURRENCY_TABLE");

		newString = Replacer.simpleReplace(newString, "CROSS_GAMMA_IMPACT_CHOICE_TABLE",
				"SHM_USR_TABLES_ENUM.CROSS_GAMMA_IMPACT_CHOICE_TABLE");

		newString = Replacer.simpleReplace(newString, "CROSS_VEGA_GAMMA_IMPACT_TABLE",
				"SHM_USR_TABLES_ENUM.CROSS_VEGA_GAMMA_IMPACT_TABLE");

		newString = Replacer.simpleReplace(newString, "DIR_USER_FILE_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.DIR_USER_FILE_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "TAX_RATE_TABLE", "SHM_USR_TABLES_ENUM.TAX_RATE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_PREPAY_SPEED_UNIT_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_PREPAY_SPEED_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "PPA_ACTION_TABLE", "SHM_USR_TABLES_ENUM.PPA_ACTION_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_TRANSACTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_TRANSACTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "MKTD_SOURCE_TABLE", "SHM_USR_TABLES_ENUM.MKTD_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_DEFAULT_UNIT_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_DEFAULT_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_SEVERITY_UNIT_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_SEVERITY_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_GROUP_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_GROUP_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ALERT_ERROR_WARNING_TABLE",
				"SHM_USR_TABLES_ENUM.ALERT_ERROR_WARNING_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_ACTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NOM_ACTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPS_SERVICES_LOG_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.OPS_SERVICES_LOG_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "TRADING_LOCATION_TABLE",
				"SHM_USR_TABLES_ENUM.TRADING_LOCATION_TABLE");

		newString = Replacer.simpleReplace(newString, "IMPACT_OPT_EXERCISE_SATAUS_TABLE",
				"SHM_USR_TABLES_ENUM.IMPACT_OPT_EXERCISE_SATAUS_TABLE");

		newString = Replacer.simpleReplace(newString, "USE_MKT_PX_FOR_SENSITIVITES_TBL",
				"SHM_USR_TABLES_ENUM.USE_MKT_PX_FOR_SENSITIVITES_TBL");

		newString = Replacer.simpleReplace(newString, "NOM_CUT_CODE_TABLE", "SHM_USR_TABLES_ENUM.NOM_CUT_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "CONTRACT_CODES_TABLE",
				"SHM_USR_TABLES_ENUM.CONTRACT_CODES_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSPORT_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSPORT_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "INCOTERMS_TABLE", "SHM_USR_TABLES_ENUM.INCOTERMS_TABLE");

		newString = Replacer.simpleReplace(newString, "SERVICER_ADVANCES_TABLE",
				"SHM_USR_TABLES_ENUM.SERVICER_ADVANCES_TABLE");

		newString = Replacer.simpleReplace(newString, "CARGO_TYPE_TABLE", "SHM_USR_TABLES_ENUM.CARGO_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NOMINATION_ACTION_TABLE",
				"SHM_USR_TABLES_ENUM.NOMINATION_ACTION_TABLE");

		newString = Replacer.simpleReplace(newString, "KEEP_WHOLE_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.KEEP_WHOLE_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_RETURN_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_RETURN_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "LAYOUT_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.LAYOUT_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "STD_CHARGE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.STD_CHARGE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ELECTION_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ELECTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PROD_DETAIL_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.PROD_DETAIL_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "VOLUME_PERCENT_REST_TABLE",
				"SHM_USR_TABLES_ENUM.VOLUME_PERCENT_REST_TABLE");

		newString = Replacer.simpleReplace(newString, "EQUITY_INSTRUMENT_TABLE",
				"SHM_USR_TABLES_ENUM.EQUITY_INSTRUMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "YIELD_TO_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.YIELD_TO_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "COMM_PRICING_TIER_INFO1_TABLE",
				"SHM_USR_TABLES_ENUM.COMM_PRICING_TIER_INFO1_TABLE");

		newString = Replacer.simpleReplace(newString, "COMM_PRICING_TIER_INFO2_TABLE",
				"SHM_USR_TABLES_ENUM.COMM_PRICING_TIER_INFO2_TABLE");

		newString = Replacer.simpleReplace(newString, "CDIS_PRICING_GRANULARITY_TABLE",
				"SHM_USR_TABLES_ENUM.CDIS_PRICING_GRANULARITY_TABLE");

		newString = Replacer.simpleReplace(newString, "CDS_ACCRUED_TREATMENT_TABLE",
				"SHM_USR_TABLES_ENUM.CDS_ACCRUED_TREATMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_EXTRAPOLATION_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_EXTRAPOLATION_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "FACILITY_TYPE_TABLE", "SHM_USR_TABLES_ENUM.FACILITY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FACILITY_TABLE", "SHM_USR_TABLES_ENUM.FACILITY_TABLE");

		newString = Replacer.simpleReplace(newString, "FILE_OBJECT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.FILE_OBJECT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CDO_MODEL_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CDO_MODEL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "COPULA_TYPE_TABLE", "SHM_USR_TABLES_ENUM.COPULA_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CDO_CORRELATION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CDO_CORRELATION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PORTFOLIO_ALLOCATION_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.PORTFOLIO_ALLOCATION_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_DEF_DISPLAY_MODE_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_DEF_DISPLAY_MODE_TABLE");

		newString = Replacer.simpleReplace(newString, "PERF_SEC_DEFN_TABLE", "SHM_USR_TABLES_ENUM.PERF_SEC_DEFN_TABLE");

		newString = Replacer.simpleReplace(newString, "BALANCING_ZONE_TABLE",
				"SHM_USR_TABLES_ENUM.BALANCING_ZONE_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_EVENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_EVENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "BPM_STEP_TYPE_TABLE", "SHM_USR_TABLES_ENUM.BPM_STEP_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "BPM_CONDITION_TABLE", "SHM_USR_TABLES_ENUM.BPM_CONDITION_TABLE");

		newString = Replacer.simpleReplace(newString, "BPM_TRIGGER_TABLE", "SHM_USR_TABLES_ENUM.BPM_TRIGGER_TABLE");

		newString = Replacer.simpleReplace(newString, "BPM_STATUS_TABLE", "SHM_USR_TABLES_ENUM.BPM_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_ADJ_VALUE_MTHD_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_ADJ_VALUE_MTHD_TABLE");

		newString = Replacer.simpleReplace(newString, "TPM_RETURN_CODE_TABLE",
				"SHM_USR_TABLES_ENUM.TPM_RETURN_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_INFO_TYPE_ASSOC_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_INFO_TYPE_ASSOC_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_DATA_SOURCE_TABLE",
				"SHM_USR_TABLES_ENUM.PS_DATA_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_ENTITLEMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PS_ENTITLEMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_ONSHORE_OFFSHORE_TABLE",
				"SHM_USR_TABLES_ENUM.PS_ONSHORE_OFFSHORE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_COMMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PS_COMMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_FIELD_TABLE", "SHM_USR_TABLES_ENUM.PS_FIELD_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_DISTRICT_TABLE", "SHM_USR_TABLES_ENUM.PS_DISTRICT_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_COUNTY_TABLE", "SHM_USR_TABLES_ENUM.PS_COUNTY_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_REGION_TABLE", "SHM_USR_TABLES_ENUM.PS_REGION_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_WELLHEAD_TABLE", "SHM_USR_TABLES_ENUM.PS_WELLHEAD_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_EXTERNAL_SYSTEM_TABLE",
				"SHM_USR_TABLES_ENUM.PS_EXTERNAL_SYSTEM_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_WELLHEAD_STATUS_DESC_TABLE",
				"SHM_USR_TABLES_ENUM.PS_WELLHEAD_STATUS_DESC_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_WH_SECTION_TABLE", "SHM_USR_TABLES_ENUM.PS_WH_SECTION_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_TOWNSHIP_TABLE", "SHM_USR_TABLES_ENUM.PS_TOWNSHIP_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_RANGE_TABLE", "SHM_USR_TABLES_ENUM.PS_RANGE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_PROPERTY_TABLE", "SHM_USR_TABLES_ENUM.PS_PROPERTY_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_VENTURE_TABLE", "SHM_USR_TABLES_ENUM.PS_VENTURE_TABLE");

		newString = Replacer.simpleReplace(newString, "APPL_NOT_APPL_TABLE", "SHM_USR_TABLES_ENUM.APPL_NOT_APPL_TABLE");

		newString = Replacer.simpleReplace(newString, "SING_MULT_TABLE", "SHM_USR_TABLES_ENUM.SING_MULT_TABLE");

		newString = Replacer.simpleReplace(newString, "BUYER_SELLER_TABLE", "SHM_USR_TABLES_ENUM.BUYER_SELLER_TABLE");

		newString = Replacer.simpleReplace(newString, "CDS_VALUATION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.CDS_VALUATION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "OBLIGATION_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.OBLIGATION_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "SCREEN_CONFIG_POSITION_TABLE",
				"SHM_USR_TABLES_ENUM.SCREEN_CONFIG_POSITION_TABLE");

		newString = Replacer.simpleReplace(newString, "ENDUR_NOM_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ENDUR_NOM_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_UNIT_TABLE", "SHM_USR_TABLES_ENUM.PS_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "PERF_RESULT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PERF_RESULT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPTION_EXERCISE_CONVENTION_TABLE",
				"SHM_USR_TABLES_ENUM.OPTION_EXERCISE_CONVENTION_TABLE");

		newString = Replacer.simpleReplace(newString, "DAY_START_TIME_TABLE",
				"SHM_USR_TABLES_ENUM.DAY_START_TIME_TABLE");

		newString = Replacer.simpleReplace(newString, "CAPACITY_TYPE_TABLE", "SHM_USR_TABLES_ENUM.CAPACITY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "SHARED_PRICE_TYPE_IDX_TABLE",
				"SHM_USR_TABLES_ENUM.SHARED_PRICE_TYPE_IDX_TABLE");

		newString = Replacer.simpleReplace(newString, "BPM_CATEGORY_TABLE", "SHM_USR_TABLES_ENUM.BPM_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "NOM_GROUP_TABLE", "SHM_USR_TABLES_ENUM.NOM_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_ACCOUNTING_RESULTS_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_ACCOUNTING_RESULTS_TABLE");

		newString = Replacer.simpleReplace(newString, "BPM_TASK_PRIORITIES_TABLE",
				"SHM_USR_TABLES_ENUM.BPM_TASK_PRIORITIES_TABLE");

		newString = Replacer.simpleReplace(newString, "GCV_TYPE_TABLE", "SHM_USR_TABLES_ENUM.GCV_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "IMBALANCE_PERIOD_TABLE",
				"SHM_USR_TABLES_ENUM.IMBALANCE_PERIOD_TABLE");

		newString = Replacer.simpleReplace(newString, "IMBALANCE_LIMIT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.IMBALANCE_LIMIT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "BASE_HIST_CASH_FLOW_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.BASE_HIST_CASH_FLOW_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "EXERCISABLE_TOOLSETS_TABLE",
				"SHM_USR_TABLES_ENUM.EXERCISABLE_TOOLSETS_TABLE");

		newString = Replacer.simpleReplace(newString, "BARRIER_INSTRUMENTS_TABLE",
				"SHM_USR_TABLES_ENUM.BARRIER_INSTRUMENTS_TABLE");

		newString = Replacer.simpleReplace(newString, "SERVICE_DEFN_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.SERVICE_DEFN_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_STDEV_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_STDEV_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_DISTRIBUTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_DISTRIBUTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RAILCAR_TYPE_TABLE", "SHM_USR_TABLES_ENUM.RAILCAR_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_PROCESSING_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_PROCESSING_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_PROCESSING_STATE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_PROCESSING_STATE_TABLE");

		newString = Replacer.simpleReplace(newString, "COLLATERAL_GRANULARITY_TABLE",
				"SHM_USR_TABLES_ENUM.COLLATERAL_GRANULARITY_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_PROCESS_MODE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_PROCESS_MODE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPS_CRITERIA_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.OPS_CRITERIA_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "GEO_FORMAT_TABLE", "SHM_USR_TABLES_ENUM.GEO_FORMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "GEO_STYLE_TABLE", "SHM_USR_TABLES_ENUM.GEO_STYLE_TABLE");

		newString = Replacer.simpleReplace(newString, "BILL_OF_LADING_TABLE",
				"SHM_USR_TABLES_ENUM.BILL_OF_LADING_TABLE");

		newString = Replacer.simpleReplace(newString, "MEASUREMENT_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.MEASUREMENT_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_INSPECTOR_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_INSPECTOR_TABLE");

		newString = Replacer.simpleReplace(newString, "TANKAGE_TABLE", "SHM_USR_TABLES_ENUM.TANKAGE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_VOL_AVG_PERIOD_TABLE",
				"SHM_USR_TABLES_ENUM.PS_VOL_AVG_PERIOD_TABLE");

		newString = Replacer.simpleReplace(newString, "PROJECTOR_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PROJECTOR_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CFLOW_SOURCE_TABLE", "SHM_USR_TABLES_ENUM.CFLOW_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "RAND_DISTRIBUTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.RAND_DISTRIBUTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPTION_MONEY_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.OPTION_MONEY_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_SUB_CTL_AREA_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_SUB_CTL_AREA_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_SPOT_VIEW_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PS_SPOT_VIEW_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PIPE_PROCESSING_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PIPE_PROCESSING_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NGL_PLANT_SETUP_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_PLANT_SETUP_TABLE");

		newString = Replacer.simpleReplace(newString, "NGL_PLANT_METER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_PLANT_METER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NGL_CONTRACT_OPTION_SETUP_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_CONTRACT_OPTION_SETUP_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_STATUS_TRANSITION_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_STATUS_TRANSITION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCOUNT_STATUS_TRANSITION_TABLE",
				"SHM_USR_TABLES_ENUM.ACCOUNT_STATUS_TRANSITION_TABLE");

		newString = Replacer.simpleReplace(newString, "STLMNT_INS_STS_TRANSITION_TABLE",
				"SHM_USR_TABLES_ENUM.STLMNT_INS_STS_TRANSITION_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_DOMAIN_DIMENSION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_DOMAIN_DIMENSION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_DOMAIN_DEFINITION_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_DOMAIN_DEFINITION_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_DOMAIN_TABLE", "SHM_USR_TABLES_ENUM.VOL_DOMAIN_TABLE");

		newString = Replacer.simpleReplace(newString, "DOMAIN_TYPE_TABLE", "SHM_USR_TABLES_ENUM.DOMAIN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "SIM_RESULT_GROUPS_TABLE",
				"SHM_USR_TABLES_ENUM.SIM_RESULT_GROUPS_TABLE");

		newString = Replacer.simpleReplace(newString, "BUYOUT_METHOD_TABLE", "SHM_USR_TABLES_ENUM.BUYOUT_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "BUYOUT_AMORTIZATION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.BUYOUT_AMORTIZATION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "BUYOUT_PROCEEDS_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.BUYOUT_PROCEEDS_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "BENCHMARK_DEFINITION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.BENCHMARK_DEFINITION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "USER_DEFINED_EXTS_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.USER_DEFINED_EXTS_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "USER_DEFINED_EXTS_ATTR_TABLE",
				"SHM_USR_TABLES_ENUM.USER_DEFINED_EXTS_ATTR_TABLE");

		newString = Replacer.simpleReplace(newString, "USER_DEFINED_EXTS_DEF_TABLE",
				"SHM_USR_TABLES_ENUM.USER_DEFINED_EXTS_DEF_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_RISK_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_RISK_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "QUICK_CREDIT_RISK_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.QUICK_CREDIT_RISK_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "CMOTION_DELIVERY_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.CMOTION_DELIVERY_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "MANUAL_ENTRY_POSTED_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.MANUAL_ENTRY_POSTED_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_SECURITY_COORDINATOR_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_SECURITY_COORDINATOR_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_ENTITY_TABLE", "SHM_USR_TABLES_ENUM.NERC_ENTITY_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_MRD_RESOURCE_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_MRD_RESOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_MRD_FLOWGATES_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_MRD_FLOWGATES_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_WELLHEAD_NETWORK_PATH_TABLE",
				"SHM_USR_TABLES_ENUM.PS_WELLHEAD_NETWORK_PATH_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_DELIVERY_NETWORK_TABLE",
				"SHM_USR_TABLES_ENUM.PS_DELIVERY_NETWORK_TABLE");

		newString = Replacer.simpleReplace(newString, "RATE_MATRIX_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.RATE_MATRIX_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "RATE_MATRIX_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.RATE_MATRIX_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_RISK_LIMIT_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_RISK_LIMIT_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_GPT_STKE_RATIO_FMAT_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_GPT_STKE_RATIO_FMAT_TABLE");

		newString = Replacer.simpleReplace(newString, "INTEREST_CAPITALIZATION_TABLE",
				"SHM_USR_TABLES_ENUM.INTEREST_CAPITALIZATION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_STATUS_TABLE", "SHM_USR_TABLES_ENUM.ACCT_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_QUERY_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_QUERY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_SIGN_DIRECTION_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_SIGN_DIRECTION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_EXT_RESULT_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_EXT_RESULT_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_AMORTIZATION_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_AMORTIZATION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_POSTING_METHOD", "SHM_USR_TABLES_ENUM.ACCT_POSTING_METHOD");

		newString = Replacer.simpleReplace(newString, "PIPE_ALLOW_PATHING_TABLE",
				"SHM_USR_TABLES_ENUM.PIPE_ALLOW_PATHING_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_CONSTRUCTION_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_CONSTRUCTION_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_REMAIN_PARTY_CONSNT_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_REMAIN_PARTY_CONSNT_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RESULT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RESULT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_BALANCE_SHEET_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_BALANCE_SHEET_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_SUBLEDGER_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_SUBLEDGER_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "DOC_STATUS_TRANSITION_TABLE",
				"SHM_USR_TABLES_ENUM.DOC_STATUS_TRANSITION_TABLE");

		newString = Replacer.simpleReplace(newString, "AMOUNT_ADJUSTMENT_TABLE",
				"SHM_USR_TABLES_ENUM.AMOUNT_ADJUSTMENT_TABLE");

		newString = Replacer.simpleReplace(newString, "EXERCISE_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.EXERCISE_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "PAUG_TRIGGER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PAUG_TRIGGER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "INTEREST_SHORTFALL_TABLE",
				"SHM_USR_TABLES_ENUM.INTEREST_SHORTFALL_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_DEFAULT_RATE_UNIT_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_DEFAULT_RATE_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSPORT_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSPORT_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSPORT_CARRIAGE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSPORT_CARRIAGE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSPORT_HULL_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSPORT_HULL_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSPORT_CARRIAGE_VESSEL_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSPORT_CARRIAGE_VESSEL_TABLE");

		newString = Replacer.simpleReplace(newString, "ADJ_FUNC_TOLERANCE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ADJ_FUNC_TOLERANCE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ADJ_FUNC_ADJ_CALC_TABLE",
				"SHM_USR_TABLES_ENUM.ADJ_FUNC_ADJ_CALC_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_EVDATA_ADDON_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_EVDATA_ADDON_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_EVENT_SOURCE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_EVENT_SOURCE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACQUISITION_TABLE", "SHM_USR_TABLES_ENUM.ACQUISITION_TABLE");

		newString = Replacer.simpleReplace(newString, "RATE_SCHEDULE_MODIFICATION_TABLE",
				"SHM_USR_TABLES_ENUM.RATE_SCHEDULE_MODIFICATION_TABLE");

		newString = Replacer.simpleReplace(newString, "STLDOC_GEN_FIELD_PRIORITY_TABLE",
				"SHM_USR_TABLES_ENUM.STLDOC_GEN_FIELD_PRIORITY_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_FXRATE_SET_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_FXRATE_SET_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_FXRATE_CONVENTION_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_FXRATE_CONVENTION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_FXRATE_SET_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_FXRATE_SET_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_FXRATE_SET_OPTION_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_FXRATE_SET_OPTION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_FXRATE_MSG_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_FXRATE_MSG_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCRUED_HANDLING_TABLE",
				"SHM_USR_TABLES_ENUM.ACCRUED_HANDLING_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTIAL_SHARE_HANDLING_TABLE",
				"SHM_USR_TABLES_ENUM.PARTIAL_SHARE_HANDLING_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTIAL_SHARE_AGGREGATION_TABLE",
				"SHM_USR_TABLES_ENUM.PARTIAL_SHARE_AGGREGATION_TABLE");

		newString = Replacer.simpleReplace(newString, "TPM_POST_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.TPM_POST_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "TPM_RUNNING_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.TPM_RUNNING_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANF_OVERRIDE_ATTRIBUTE_VALUE",
				"SHM_USR_TABLES_ENUM.TRANF_OVERRIDE_ATTRIBUTE_VALUE");

		newString = Replacer.simpleReplace(newString, "XF_NAMESPACE_TABLE", "SHM_USR_TABLES_ENUM.XF_NAMESPACE_TABLE");

		newString = Replacer.simpleReplace(newString, "TPM_DEFINITION_TABLE",
				"SHM_USR_TABLES_ENUM.TPM_DEFINITION_TABLE");

		newString = Replacer.simpleReplace(newString, "APM_GRID_SPLIT_TYPES",
				"SHM_USR_TABLES_ENUM.APM_GRID_SPLIT_TYPES");

		newString = Replacer.simpleReplace(newString, "TRIGGER_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.TRIGGER_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "QUANTO_COMPO_TABLE", "SHM_USR_TABLES_ENUM.QUANTO_COMPO_TABLE");

		newString = Replacer.simpleReplace(newString, "DIGITAL_RANGE_ACCRUAL_TABLE",
				"SHM_USR_TABLES_ENUM.DIGITAL_RANGE_ACCRUAL_TABLE");

		newString = Replacer.simpleReplace(newString, "PAYMENT_RATE_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.PAYMENT_RATE_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "LOCK_ITEM_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.LOCK_ITEM_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DENOMINATION_UNIT_TABLE",
				"SHM_USR_TABLES_ENUM.DENOMINATION_UNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "USER_PATH_TABLE", "SHM_USR_TABLES_ENUM.USER_PATH_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_METHOD_TABLE", "SHM_USR_TABLES_ENUM.ACCT_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RESULT_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RESULT_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_METHOD_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_METHOD_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RESULT_CATEGORY_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RESULT_CATEGORY_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_ARG_TYPE_TABLE", "SHM_USR_TABLES_ENUM.ACCT_ARG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TOLERANCE_PARTY_TABLE",
				"SHM_USR_TABLES_ENUM.TOLERANCE_PARTY_TABLE");

		newString = Replacer.simpleReplace(newString, "DIVIDEND_PYMT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DIVIDEND_PYMT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRIGGER_SCRIPT_MODE_TABLE",
				"SHM_USR_TABLES_ENUM.TRIGGER_SCRIPT_MODE_TABLE");

		newString = Replacer.simpleReplace(newString, "BUYOUT_COLUMN_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.BUYOUT_COLUMN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_CLASS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_CLASS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_PROCESS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_PROCESS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "FRACTIONAL_SECURITY_RULE_TABLE",
				"SHM_USR_TABLES_ENUM.FRACTIONAL_SECURITY_RULE_TABLE");

		newString = Replacer.simpleReplace(newString, "DIVIDEND_TYPE_TABLE", "SHM_USR_TABLES_ENUM.DIVIDEND_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_ENTRY_SOURCE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_ENTRY_SOURCE_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_CURRENCY_CONVENTION_TABLE",
				"SHM_USR_TABLES_ENUM.IDX_CURRENCY_CONVENTION_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_METHOD_CORE_CODE_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_METHOD_CORE_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RESULT_TABLE", "SHM_USR_TABLES_ENUM.ACCT_RESULT_TABLE");

		newString = Replacer.simpleReplace(newString, "FILE_OBJECT_LINK_TYPE_TABLE_2",
				"SHM_USR_TABLES_ENUM.FILE_OBJECT_LINK_TYPE_TABLE_2");

		newString = Replacer.simpleReplace(newString, "FILE_OBJECT_LINK_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.FILE_OBJECT_LINK_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_INTERFACE_TABLE", "SHM_USR_TABLES_ENUM.PS_INTERFACE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_VENTURE_STRING_TABLE",
				"SHM_USR_TABLES_ENUM.PS_VENTURE_STRING_TABLE");

		newString = Replacer.simpleReplace(newString, "NOVATION_FEE_CALC_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.NOVATION_FEE_CALC_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "RESET_CALC_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.RESET_CALC_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "VOL_DIVIDEND_HANDLING_TABLE",
				"SHM_USR_TABLES_ENUM.VOL_DIVIDEND_HANDLING_TABLE");

		newString = Replacer.simpleReplace(newString, "TERMS_TABLE", "SHM_USR_TABLES_ENUM.TERMS_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_STD_PRESSURE_TABLE",
				"SHM_USR_TABLES_ENUM.PS_STD_PRESSURE_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_SATURATION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PS_SATURATION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NGL_PLANT_METER_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_PLANT_METER_TABLE");

		newString = Replacer.simpleReplace(newString, "NGL_PLANT_METER_NUM_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_PLANT_METER_NUM_TABLE");

		newString = Replacer.simpleReplace(newString, "PS_GAS_COMPONENTS_TABLE",
				"SHM_USR_TABLES_ENUM.PS_GAS_COMPONENTS_TABLE");

		newString = Replacer.simpleReplace(newString, "NGBD_ROLL_RULE_TRUE_FALSE_TABLE",
				"SHM_USR_TABLES_ENUM.NGBD_ROLL_RULE_TRUE_FALSE_TABLE");

		newString = Replacer.simpleReplace(newString, "EVENT_SOURCE_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.EVENT_SOURCE_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TIME_CLASSIFICATION_TABLE",
				"SHM_USR_TABLES_ENUM.TIME_CLASSIFICATION_TABLE");

		newString = Replacer.simpleReplace(newString, "COMPOSITE_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.COMPOSITE_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "USER_PATH_DELIV_LOC_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.USER_PATH_DELIV_LOC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NOVATION_COLUMN_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NOVATION_COLUMN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_ACTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.INS_ACTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TSERIES_DATA_CFG_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.TSERIES_DATA_CFG_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "DEDICATION_COMMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DEDICATION_COMMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DEDICATION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DEDICATION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_AGREEMENT_CLASS_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_AGREEMENT_CLASS_TABLE");

		newString = Replacer.simpleReplace(newString, "NUM_DB_TABLES", "SHM_USR_TABLES_ENUM.NUM_DB_TABLES");

		newString = Replacer.simpleReplace(newString, "BEGIN_OLF_DB_TABLES", "SHM_USR_TABLES_ENUM.BEGIN_OLF_DB_TABLES");

		newString = Replacer.simpleReplace(newString, "NGL_PROCESS_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_PROCESS_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "NGL_VALUATION_STATUS_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_VALUATION_STATUS_TABLE");

		newString = Replacer.simpleReplace(newString, "NGL_CONTRACT_OPTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NGL_CONTRACT_OPTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_AGREEMENT_NGL_KOPT_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_AGREEMENT_NGL_KOPT_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_STATUS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_STATUS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "STRATEGY_LISTING_TABLE",
				"SHM_USR_TABLES_ENUM.STRATEGY_LISTING_TABLE");

		newString = Replacer.simpleReplace(newString, "DELIVERY_TICKET_LINK_TABLE",
				"SHM_USR_TABLES_ENUM.DELIVERY_TICKET_LINK_TABLE");

		newString = Replacer.simpleReplace(newString, "GPT_SHIFT_CHOICE_TABLE",
				"SHM_USR_TABLES_ENUM.GPT_SHIFT_CHOICE_TABLE");

		newString = Replacer.simpleReplace(newString, "NOMINATION_USER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NOMINATION_USER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NETBACK_DEFINITION_TABLE",
				"SHM_USR_TABLES_ENUM.NETBACK_DEFINITION_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_METER_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_METER_TABLE");

		newString = Replacer.simpleReplace(newString, "CARGO_IDENTIFIER_TABLE",
				"SHM_USR_TABLES_ENUM.CARGO_IDENTIFIER_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_AGREEMENT_NGL_ELECTED_PARTY_TABLE",
				"SHM_USR_TABLES_ENUM.PARTY_AGREEMENT_NGL_ELECTED_PARTY_TABLE");

		newString = Replacer.simpleReplace(newString, "TRAN_GPT_DELTA_CALC_TYPE",
				"SHM_USR_TABLES_ENUM.TRAN_GPT_DELTA_CALC_TYPE");

		newString = Replacer.simpleReplace(newString, "SECURITY_ID_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.SECURITY_ID_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_BASIS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_BASIS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_FUNDING_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_FUNDING_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "HMPD_SAVE_FREQUENCY_TABLE",
				"SHM_USR_TABLES_ENUM.HMPD_SAVE_FREQUENCY_TABLE");

		newString = Replacer.simpleReplace(newString, "HMP_DEFN_NAME_TABLE", "SHM_USR_TABLES_ENUM.HMP_DEFN_NAME_TABLE");

		newString = Replacer.simpleReplace(newString, "SWING_CONSTRAINT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.SWING_CONSTRAINT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_DISRUPTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_DISRUPTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CONSTITUENT_ANNEX_TABLE",
				"SHM_USR_TABLES_ENUM.CONSTITUENT_ANNEX_TABLE");

		newString = Replacer.simpleReplace(newString, "BERMUDAN_DATES_CALC_METHOD_TABLE",
				"SHM_USR_TABLES_ENUM.BERMUDAN_DATES_CALC_METHOD_TABLE");

		newString = Replacer.simpleReplace(newString, "DMM_DIRECTION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.DMM_DIRECTION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VIF_CONFIGURATION_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VIF_CONFIGURATION_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VIF_PLUGIN_PROCESS_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.VIF_PLUGIN_PROCESS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "VIF_CONFIGURATION_TABLE",
				"SHM_USR_TABLES_ENUM.VIF_CONFIGURATION_TABLE");

		newString = Replacer.simpleReplace(newString, "NUM_OLF_DB_TABLES", "SHM_USR_TABLES_ENUM.NUM_OLF_DB_TABLES");

		newString = Replacer.simpleReplace(newString, "BEGIN_MISC_TABLES", "SHM_USR_TABLES_ENUM.BEGIN_MISC_TABLES");

		newString = Replacer.simpleReplace(newString, "BUNIT_TABLE", "SHM_USR_TABLES_ENUM.BUNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "LENTITY_TABLE", "SHM_USR_TABLES_ENUM.LENTITY_TABLE");

		newString = Replacer.simpleReplace(newString, "TRAN_QUERY_TABLE", "SHM_USR_TABLES_ENUM.TRAN_QUERY_TABLE");

		newString = Replacer.simpleReplace(newString, "RESET_ROLL_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.RESET_ROLL_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "VOLATILITY_TABLE", "SHM_USR_TABLES_ENUM.VOLATILITY_TABLE");

		newString = Replacer.simpleReplace(newString, "IDX_SUBGROUP_TABLE", "SHM_USR_TABLES_ENUM.IDX_SUBGROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "GEO_LOCATION_TABLE", "SHM_USR_TABLES_ENUM.GEO_LOCATION_TABLE");

		newString = Replacer.simpleReplace(newString, "FEE_STRUCTURED_CALC_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.FEE_STRUCTURED_CALC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FEE_ENERGY_CALC_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.FEE_ENERGY_CALC_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "RESET_CONV_TOOLSET_TABLE",
				"SHM_USR_TABLES_ENUM.RESET_CONV_TOOLSET_TABLE");

		newString = Replacer.simpleReplace(newString, "CASH_TRANSFER_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CASH_TRANSFER_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_COMMODITY_RESET_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_COMMODITY_RESET_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "DATE_SEQ_ROLL_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.DATE_SEQ_ROLL_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_ENERGY_RESET_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_ENERGY_RESET_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "GPT_PRIORITY_TABLE", "SHM_USR_TABLES_ENUM.GPT_PRIORITY_TABLE");

		newString = Replacer.simpleReplace(newString, "HOL_TABLE", "SHM_USR_TABLES_ENUM.HOL_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_TYPE_TABLE", "SHM_USR_TABLES_ENUM.INS_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_METAL_OPT_RESET_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_METAL_OPT_RESET_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_METAL_SWAP_RESET_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_METAL_SWAP_RESET_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "NON_DISCOUNT_YLD_BASIS_TABLE",
				"SHM_USR_TABLES_ENUM.NON_DISCOUNT_YLD_BASIS_TABLE");

		newString = Replacer.simpleReplace(newString, "PERS_PFOLIO_TABLE", "SHM_USR_TABLES_ENUM.PERS_PFOLIO_TABLE");

		newString = Replacer.simpleReplace(newString, "PURPOSE_TRAN_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PURPOSE_TRAN_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TOOLSET_ID_TABLE", "SHM_USR_TABLES_ENUM.TOOLSET_ID_TABLE");

		newString = Replacer.simpleReplace(newString, "YLD_BASIS_TABLE", "SHM_USR_TABLES_ENUM.YLD_BASIS_TABLE");

		newString = Replacer.simpleReplace(newString, "USER_TO_GROUPS_TABLE",
				"SHM_USR_TABLES_ENUM.USER_TO_GROUPS_TABLE");

		newString = Replacer.simpleReplace(newString, "NON_RESERVED_CFLOW_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NON_RESERVED_CFLOW_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CASH_ASSET_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CASH_ASSET_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "NUMBER_LOCALE_STRING_TABLE",
				"SHM_USR_TABLES_ENUM.NUMBER_LOCALE_STRING_TABLE");

		newString = Replacer.simpleReplace(newString, "DUMMY_ENERGY_POWER_RESET_CONV_TABLE",
				"SHM_USR_TABLES_ENUM.DUMMY_ENERGY_POWER_RESET_CONV_TABLE");

		newString = Replacer.simpleReplace(newString, "NON_LOGICAL_LEG_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.NON_LOGICAL_LEG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "STRUCTURED_LEG_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.STRUCTURED_LEG_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PORTFOLIO_GROUP_USE_NONE_FOR_ZERO_TABLE",
				"SHM_USR_TABLES_ENUM.PORTFOLIO_GROUP_USE_NONE_FOR_ZERO_TABLE");

		newString = Replacer.simpleReplace(newString, "INS_GROUP_USE_NONE_FOR_ZERO_TABLE",
				"SHM_USR_TABLES_ENUM.INS_GROUP_USE_NONE_FOR_ZERO_TABLE");

		newString = Replacer.simpleReplace(newString, "STRUCTURED_PROV_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.STRUCTURED_PROV_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANF_FIELD_TABLE", "SHM_USR_TABLES_ENUM.TRANF_FIELD_TABLE");

		newString = Replacer.simpleReplace(newString, "MODEL_FORMULA_TABLE", "SHM_USR_TABLES_ENUM.MODEL_FORMULA_TABLE");

		newString = Replacer.simpleReplace(newString, "SCRIPT_TABLE", "SHM_USR_TABLES_ENUM.SCRIPT_TABLE");

		newString = Replacer.simpleReplace(newString, "TASK_TABLE", "SHM_USR_TABLES_ENUM.TASK_TABLE");

		newString = Replacer.simpleReplace(newString, "STORED_QUERY_TABLE", "SHM_USR_TABLES_ENUM.STORED_QUERY_TABLE");

		newString = Replacer.simpleReplace(newString, "DIRECTORY_TABLE", "SHM_USR_TABLES_ENUM.DIRECTORY_TABLE");

		newString = Replacer.simpleReplace(newString, "DATE_ENCODING_TABLE", "SHM_USR_TABLES_ENUM.DATE_ENCODING_TABLE");

		newString = Replacer.simpleReplace(newString, "SHARED_YIELD_TO_PRICE_ROUNDING_TABLE",
				"SHM_USR_TABLES_ENUM.SHARED_YIELD_TO_PRICE_ROUNDING_TABLE");

		newString = Replacer.simpleReplace(newString, "YIELD_TO_PRICE_DECPLCS_PRESELECTS_TABLE",
				"SHM_USR_TABLES_ENUM.YIELD_TO_PRICE_DECPLCS_PRESELECTS_TABLE");

		newString = Replacer.simpleReplace(newString, "TRANSMISSION_PROVIDER_TABLE",
				"SHM_USR_TABLES_ENUM.TRANSMISSION_PROVIDER_TABLE");

		newString = Replacer.simpleReplace(newString, "IBUNIT_TABLE", "SHM_USR_TABLES_ENUM.IBUNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "XBUNIT_TABLE", "SHM_USR_TABLES_ENUM.XBUNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "ILENTITY_TABLE", "SHM_USR_TABLES_ENUM.ILENTITY_TABLE");

		newString = Replacer.simpleReplace(newString, "XLENTITY_TABLE", "SHM_USR_TABLES_ENUM.XLENTITY_TABLE");

		newString = Replacer.simpleReplace(newString, "PBUNIT_TABLE", "SHM_USR_TABLES_ENUM.PBUNIT_TABLE");

		newString = Replacer.simpleReplace(newString, "REF_PARTY_CREDIT_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.REF_PARTY_CREDIT_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_POOLING_POINTS_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_POOLING_POINTS_TABLE");

		newString = Replacer.simpleReplace(newString, "OPEN_CONNECT_SERVICE_TABLE",
				"SHM_USR_TABLES_ENUM.OPEN_CONNECT_SERVICE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPEN_CONNECT_LOG_STATE_TABLE",
				"SHM_USR_TABLES_ENUM.OPEN_CONNECT_LOG_STATE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPEN_CONNECT_DEBUG_STATE_TABLE",
				"SHM_USR_TABLES_ENUM.OPEN_CONNECT_DEBUG_STATE_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_OPERATOR_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_OPERATOR_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_OPERATOR_TABLE", "SHM_USR_TABLES_ENUM.PWR_OPERATOR_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_OPERATOR_CODE_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_OPERATOR_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "MESSAGE_TYPES_TABLE", "SHM_USR_TABLES_ENUM.MESSAGE_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "MESSAGE_FORMATS_TABLE",
				"SHM_USR_TABLES_ENUM.MESSAGE_FORMATS_TABLE");

		newString = Replacer.simpleReplace(newString, "NO_FEE_YLD_BASIS_TABLE",
				"SHM_USR_TABLES_ENUM.NO_FEE_YLD_BASIS_TABLE");

		newString = Replacer.simpleReplace(newString, "NON_DISCOUNT_YLD_BASIS_W_FEE_TABLE",
				"SHM_USR_TABLES_ENUM.NON_DISCOUNT_YLD_BASIS_W_FEE_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_TSD_VOLUME_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_TSD_VOLUME_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_TSD_VOLUME_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_TSD_VOLUME_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "CRUDE_TSD_VOLUME_TYPES_TABLE",
				"SHM_USR_TABLES_ENUM.CRUDE_TSD_VOLUME_TYPES_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_OPERATOR_CODE_ROLE_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_OPERATOR_CODE_ROLE_TABLE");

		newString = Replacer.simpleReplace(newString, "PERF_ENTRY_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.PERF_ENTRY_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CONFIGURED_SERVICES_TABLE",
				"SHM_USR_TABLES_ENUM.CONFIGURED_SERVICES_TABLE");

		newString = Replacer.simpleReplace(newString, "FX_ASSET_TYPE_TABLE", "SHM_USR_TABLES_ENUM.FX_ASSET_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_DEFAULT_INDEX_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_DEFAULT_INDEX_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_SUB_INDEX_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_SUB_INDEX_TABLE");

		newString = Replacer.simpleReplace(newString, "REF_PARTY_ALL_CREDIT_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.REF_PARTY_ALL_CREDIT_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "PARTY_GROUP_TABLE", "SHM_USR_TABLES_ENUM.PARTY_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "IPARTY_GROUP_TABLE", "SHM_USR_TABLES_ENUM.IPARTY_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "XPARTY_GROUP_TABLE", "SHM_USR_TABLES_ENUM.XPARTY_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "REFERENCE_ENTITY_TABLE",
				"SHM_USR_TABLES_ENUM.REFERENCE_ENTITY_TABLE");

		newString = Replacer.simpleReplace(newString, "RED_CODE_TABLE", "SHM_USR_TABLES_ENUM.RED_CODE_TABLE");

		newString = Replacer.simpleReplace(newString, "CYCLE_ID_TABLE", "SHM_USR_TABLES_ENUM.CYCLE_ID_TABLE");

		newString = Replacer.simpleReplace(newString, "PERF_ATTRIB_MODEL_TABLE",
				"SHM_USR_TABLES_ENUM.PERF_ATTRIB_MODEL_TABLE");

		newString = Replacer.simpleReplace(newString, "PERF_ATTRIB_MODEL_DIM_TABLE",
				"SHM_USR_TABLES_ENUM.PERF_ATTRIB_MODEL_DIM_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_DEFAULT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_DEFAULT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "OPEN_CONNECT_CUSTOM_USER_TABLE",
				"SHM_USR_TABLES_ENUM.OPEN_CONNECT_CUSTOM_USER_TABLE");

		newString = Replacer.simpleReplace(newString, "OPS_TRAN_STATUS_TRANSITION_TABLE",
				"SHM_USR_TABLES_ENUM.OPS_TRAN_STATUS_TRANSITION_TABLE");

		newString = Replacer.simpleReplace(newString, "RISK_MATURITY_BUCKET_FULL_TABLE",
				"SHM_USR_TABLES_ENUM.RISK_MATURITY_BUCKET_FULL_TABLE");

		newString = Replacer.simpleReplace(newString, "GAS_PHYS_LOCATION_NAME_TABLE",
				"SHM_USR_TABLES_ENUM.GAS_PHYS_LOCATION_NAME_TABLE");

		newString = Replacer.simpleReplace(newString, "PROJECTOR_DEF_TABLE", "SHM_USR_TABLES_ENUM.PROJECTOR_DEF_TABLE");

		newString = Replacer.simpleReplace(newString, "VAL_PRODUCT_TABLE", "SHM_USR_TABLES_ENUM.VAL_PRODUCT_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_POR_POINT_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_POR_POINT_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_POD_POINT_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_POD_POINT_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_SOURCE_POINT_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_SOURCE_POINT_TABLE");

		newString = Replacer.simpleReplace(newString, "NERC_SINK_POINT_TABLE",
				"SHM_USR_TABLES_ENUM.NERC_SINK_POINT_TABLE");

		newString = Replacer.simpleReplace(newString, "GLOBAL_RATE_MATRIX_TABLE",
				"SHM_USR_TABLES_ENUM.GLOBAL_RATE_MATRIX_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_TRANCHE_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_TRANCHE_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CDS_OBLIGATION_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_CDS_OBLIGATION_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CDS_OBLIGATION_TICKER_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_CDS_OBLIGATION_TICKER_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_SECTOR_TABLE", "SHM_USR_TABLES_ENUM.CREDIT_SECTOR_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_SUBLEDGER_HPA", "SHM_USR_TABLES_ENUM.ACCT_SUBLEDGER_HPA");

		newString = Replacer.simpleReplace(newString, "ACCT_SUBLEDGER_NAME_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_SUBLEDGER_NAME_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_PROCESS_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_PROCESS_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_TO_PROCESS_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_TO_PROCESS_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_TO_REVERSAL_GROUP_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_TO_REVERSAL_GROUP_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_PERIOD_LIST_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_PERIOD_LIST_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_PROD_PERIOD_LIST_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_PROD_PERIOD_LIST_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_SCRIPT_RESULTS_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_SCRIPT_RESULTS_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_DEFN_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_DEFN_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_ALL_RULE_DEFN_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_ALL_RULE_DEFN_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_RULE_DEFN_NAME_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_RULE_DEFN_NAME_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_ALL_RULE_DEFN_NAME_TABLE",
				"SHM_USR_TABLES_ENUM.ACCT_ALL_RULE_DEFN_NAME_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_EVENT_ACTION_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_EVENT_ACTION_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_REFERENCE_CFLOW_PAYMENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_REFERENCE_CFLOW_PAYMENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CDS_OBLIGATION_CUSIP_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_CDS_OBLIGATION_CUSIP_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CDS_OBLIGATION_REFERENCE_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_CDS_OBLIGATION_REFERENCE_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CDS_OBLIGATION_CLIP_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_CDS_OBLIGATION_CLIP_TABLE");

		newString = Replacer.simpleReplace(newString, "BALANCE_CIRCLE_TABLE",
				"SHM_USR_TABLES_ENUM.BALANCE_CIRCLE_TABLE");

		newString = Replacer.simpleReplace(newString, "BALANCE_CIRCLE_ASSIGN_TABLE",
				"SHM_USR_TABLES_ENUM.BALANCE_CIRCLE_ASSIGN_TABLE");

		newString = Replacer.simpleReplace(newString, "ACCT_SUBLEDGER_GROUP_HPA",
				"SHM_USR_TABLES_ENUM.ACCT_SUBLEDGER_GROUP_HPA");

		newString = Replacer.simpleReplace(newString, "ACCT_BALANCE_SHEET_HPA",
				"SHM_USR_TABLES_ENUM.ACCT_BALANCE_SHEET_HPA");

		newString = Replacer.simpleReplace(newString, "TRANF_OVERRIDE_ATTRIBUTE_TABLE",
				"SHM_USR_TABLES_ENUM.TRANF_OVERRIDE_ATTRIBUTE_TABLE");

		newString = Replacer.simpleReplace(newString, "PWR_OPERATOR_COMMODITY_TABLE",
				"SHM_USR_TABLES_ENUM.PWR_OPERATOR_COMMODITY_TABLE");

		newString = Replacer.simpleReplace(newString, "SIMULATION_NAME_TABLE",
				"SHM_USR_TABLES_ENUM.SIMULATION_NAME_TABLE");

		newString = Replacer.simpleReplace(newString, "APM_DATASET_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.APM_DATASET_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_EVENT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_EVENT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CORP_ACTION_FIELD_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.CORP_ACTION_FIELD_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "FIELD_FORMAT_TYPE_TABLE",
				"SHM_USR_TABLES_ENUM.FIELD_FORMAT_TYPE_TABLE");

		newString = Replacer.simpleReplace(newString, "CYCLE_PIPELINE_TABLE",
				"SHM_USR_TABLES_ENUM.CYCLE_PIPELINE_TABLE");

		newString = Replacer.simpleReplace(newString, "ETAG_TAG_ID_STRING_HPA",
				"SHM_USR_TABLES_ENUM.ETAG_TAG_ID_STRING_HPA");

		newString = Replacer.simpleReplace(newString, "TERMS_WITH_DESC_TABLE",
				"SHM_USR_TABLES_ENUM.TERMS_WITH_DESC_TABLE");

		newString = Replacer.simpleReplace(newString, "CREDIT_CLASSIFICATION_WITH_DESC_TABLE",
				"SHM_USR_TABLES_ENUM.CREDIT_CLASSIFICATION_WITH_DESC_TABLE");

		newString = Replacer.simpleReplace(newString, "NUM_MISC_TABLES", "SHM_USR_TABLES_ENUM.NUM_MISC_TABLES");

		newString = Replacer.simpleReplace(newString, "LAST_RESERVED_OLF_DB_TABLE",
				"SHM_USR_TABLES_ENUM.LAST_RESERVED_OLF_DB_TABLE");

		newString = Replacer.simpleReplace(newString, "BEGIN_OLF_MISC_TABLES",
				"SHM_USR_TABLES_ENUM.BEGIN_OLF_MISC_TABLES");

		newString = Replacer.simpleReplace(newString, "NUM_OLF_MISC_TABLES", "SHM_USR_TABLES_ENUM.NUM_OLF_MISC_TABLES");

		newString = Replacer.simpleReplace(newString, "LAST_RESERVED_OLF_MISC_TABLE",
				"SHM_USR_TABLES_ENUM.LAST_RESERVED_OLF_MISC_TABLE");

		newString = Replacer.simpleReplace(newString, "SIM_RunRevalByQidFixed", "Sim.runRevalByQidFixed");

		newString = Replacer.simpleReplace(newString, "SIM_AddAccrueToThroughConfig", "Sim.addAccrueToThroughConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddBaseScenario", "Sim.addBaseScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddBondAccruesBeforeSettlementConfig",
				"Sim.addBondAccruesBeforeSettlementConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorMap", "Sim.addCorMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorModByGpt", "Sim.addCorModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorMod", "Sim.addCorMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorVegaShiftModByGpt", "Sim.addCorVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddCorVegaShiftMod", "Sim.addCorVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddDeltaShiftModByGpt", "Sim.addDeltaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddDeltaShiftMod", "Sim.addDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddEuroConfig", "Sim.addEuroConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddFXModByCcy", "Sim.addFXModByCcy");

		newString = Replacer.simpleReplace(newString, "SIM_AddFXMod", "Sim.addFXMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddHorizonDateMod", "Sim.addHorizonDateMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexEffectiveModByGpt", "Sim.addIndexEffectiveModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexEffectiveMod", "Sim.addIndexEffectiveMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexInheritanceConfig", "Sim.addIndexInheritanceConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexMap", "Sim.addIndexMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexModByGpt", "Sim.addIndexModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexMod", "Sim.addIndexMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexOutputConfig", "Sim.addIndexOutputConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexOutputModByDate", "Sim.addIndexOutputModByDate");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexOutputMod", "Sim.addIndexOutputMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddIndexParentMap", "Sim.addIndexParentMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddMarketPxIndexConfig", "Sim.addMarketPxIndexConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddMCarloConfig", "Sim.addMCarloConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddOutputDeltaShiftMod", "Sim.addOutputDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddPricingModelConfig", "Sim.addPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddPricingModelMap", "Sim.addPricingModelMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddPriorSimResultConfig", "Sim.addPriorSimResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultCol", "Sim.addResultCol");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultConfig", "Sim.addResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultGroupListToScenario",
				"Sim.addResultGroupListToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultGroupToScenario", "Sim.addResultGroupToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultListToScenario", "Sim.addResultListToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddResultToScenario", "Sim.addResultToScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddScenarioMod", "Sim.addScenarioMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddScenario", "Sim.addScenario");

		newString = Replacer.simpleReplace(newString, "SIM_AddSimulation", "Sim.addSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_AddUnFixConfig", "Sim.addUnFixConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddVaRConfig", "Sim.addVaRConfig");

		newString = Replacer.simpleReplace(newString, "SIM_AddVaRDef", "Sim.addVaRDef");

		newString = Replacer.simpleReplace(newString, "SIM_AddVegaShiftModByGpt", "Sim.addVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddVegaShiftMod", "Sim.addVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolInputModByGpt", "Sim.addVolInputModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolInputMod", "Sim.addVolInputMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolMap", "Sim.addVolMap");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolModByGpt", "Sim.addVolModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolMod", "Sim.addVolMod");

		newString = Replacer.simpleReplace(newString, "SIM_AddVolumetricConfig", "Sim.addVolumetricConfig");

		newString = Replacer.simpleReplace(newString, "SIM_ComputeResultsForTranList",
				"Transaction.simComputeResultsForTranList");

		newString = Replacer.simpleReplace(newString, "SIM_ComputeResultsForTranListByParam",
				"Transaction.simComputeResultsForTranListByParam");

		newString = Replacer.simpleReplace(newString, "SIM_ConvertSimDef", "Sim.convertSimDef");

		newString = Replacer.simpleReplace(newString, "SIM_CopySim", "Sim.copySim");

		newString = Replacer.simpleReplace(newString, "SIM_CreateBaseSimulation", "Sim.createBaseSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_CreateConfigSubTableForType",
				"Sim.createConfigSubTableForType");

		newString = Replacer.simpleReplace(newString, "SIM_CreateRevalTable", "Sim.createRevalTable");

		newString = Replacer.simpleReplace(newString, "SIM_CreateScenarioTable", "Sim.createScenarioTable");

		newString = Replacer.simpleReplace(newString, "SIM_CreateSimDefTable", "Sim.createSimDefTable");

		newString = Replacer.simpleReplace(newString, "SIM_CreateSplitQueryTable", "Sim.createSplitQueryTable");

		newString = Replacer.simpleReplace(newString, "SIM_ExportSimDefs", "Sim.exportSimDefs");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateJDForHistPriceDate",
				"Sim.getHorizonDateJDForHistPriceDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateJDForResetDate",
				"Sim.getHorizonDateJDForResetDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateJDForScenarioDate",
				"Sim.getHorizonDateJDForScenarioDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateSymbolicDateForHistPriceDate",
				"Sim.getHorizonDateSymbolicDateForHistPriceDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateSymbolicDateForResetDate",
				"Sim.getHorizonDateSymbolicDateForResetDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetHorizonDateSymbolicDateForScenarioDate",
				"Sim.getHorizonDateSymbolicDateForScenarioDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetIndexOutputConfig", "Sim.getIndexOutputConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetLastResultDate", "Sim.getLastResultDate");

		newString = Replacer.simpleReplace(newString, "SIM_GetListBy", "Util.simGetListBy");

		newString = Replacer.simpleReplace(newString, "SIM_GetMarketPxIndexConfig", "Sim.getMarketPxIndexConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetMCarloConfig", "Sim.getMCarloConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetNewSimRunId", "Sim.getNewSimRunId");

		newString = Replacer.simpleReplace(newString, "SIM_GetPricingModelConfig", "Sim.getPricingModelConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetResultConfig", "Sim.getResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_GetResultListForGroup", "Util.simGetResultListForGroup");

		newString = Replacer.simpleReplace(newString, "SIM_GetResultName", "Sim.getResultName");

		newString = Replacer.simpleReplace(newString, "SIM_GetScenarioRow", "Sim.getScenarioRow");

		newString = Replacer.simpleReplace(newString, "SIM_GetSimDefId", "Sim.getSimDefId");

		newString = Replacer.simpleReplace(newString, "SIM_GetSimulationRow", "Sim.getSimulationRow");

		newString = Replacer.simpleReplace(newString, "SIM_GetVaRConfig", "Sim.getVaRConfig");

		newString = Replacer.simpleReplace(newString, "SIM_ImportSimDefs", "Sim.importSimDefs");

		newString = Replacer.simpleReplace(newString, "SIM_Init", "Sim.init");

		newString = Replacer.simpleReplace(newString, "SIM_InsertSimResults", "Sim.insertSimResults");

		newString = Replacer.simpleReplace(newString, "SIM_LoadBatchSim", "Sim.loadBatchSim");

		newString = Replacer.simpleReplace(newString, "SIM_LoadSimulation", "Sim.loadSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_NewRevalTable", "Sim.newRevalTable");

		newString = Replacer.simpleReplace(newString, "SIM_PurgeBySimRunId", "Sim.purgeBySimRunId");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveAccrueToThroughConfig",
				"Sim.removeAccrueToThroughConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveBondAccruesBeforeSettlementConfig",
				"Sim.removeBondAccruesBeforeSettlementConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorMap", "Sim.removeCorMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorModByGpt", "Sim.removeCorModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorVegaShiftModByGpt",
				"Sim.removeCorVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveCorVegaShiftMod", "Sim.removeCorVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveDeltaShiftModByGpt", "Sim.removeDeltaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveDeltaShiftMod", "Sim.removeDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveEuroConfig", "Sim.removeEuroConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveFXModByCcy", "Sim.removeFXModByCcy");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveFXMod", "Sim.removeFXMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveHorizonDateMod", "Sim.removeHorizonDateMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexEffectiveModByGpt",
				"Sim.removeIndexEffectiveModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexEffectiveMod", "Sim.removeIndexEffectiveMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexInheritanceConfig",
				"Sim.removeIndexInheritanceConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexMap", "Sim.removeIndexMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexModByGpt", "Sim.removeIndexModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexMod", "Sim.removeIndexMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexOutputConfig", "Sim.removeIndexOutputConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexOutputModByDate",
				"Sim.removeIndexOutputModByDate");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexOutputMod", "Sim.removeIndexOutputMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveIndexParentMap", "Sim.removeIndexParentMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveMarketPxIndexConfig", "Sim.removeMarketPxIndexConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveMCarloConfig", "Sim.removeMCarloConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveOutputDeltaShiftMod", "Sim.removeOutputDeltaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePricingMap", "Sim.removePricingMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePricingModelConfig", "Sim.removePricingModelConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePricingModelMap", "Sim.removePricingModelMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemovePriorSimResultConfig",
				"Sim.removePriorSimResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveResultConfig", "Sim.removeResultConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveResultGroupFromScenario",
				"Sim.removeResultGroupFromScenario");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveScenario", "Sim.removeScenario");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveSimulation", "Sim.removeSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveUnFixConfig", "Sim.removeUnFixConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVaRConfig", "Sim.removeVaRConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVaRDef", "Sim.removeVaRDef");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVegaShiftModByGpt", "Sim.removeVegaShiftModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVegaShiftMod", "Sim.removeVegaShiftMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolInputModByGpt", "Sim.removeVolInputModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolInputMod", "Sim.removeVolInputMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolMap", "Sim.removeVolMap");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolModByGpt", "Sim.removeVolModByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolMod", "Sim.removeVolMod");

		newString = Replacer.simpleReplace(newString, "SIM_RemoveVolumetricConfig", "Sim.removeVolumetricConfig");

		newString = Replacer.simpleReplace(newString, "SIM_RunLocalByDealFixed", "Sim.runLocalByDealFixed");

		newString = Replacer.simpleReplace(newString, "SIM_RunLocalByParamByDeal", "Sim.runLocalByParamByDeal");

		newString = Replacer.simpleReplace(newString, "SIM_RunRevalByParamFixed", "Sim.runRevalByParamFixed");

		newString = Replacer.simpleReplace(newString, "SIM_RunBatchSim", "Sim.runBatchSim");

		newString = Replacer.simpleReplace(newString, "SIM_Run", "Sim.run");

		newString = Replacer.simpleReplace(newString, "SIM_SaveAllSimulations", "Sim.saveAllSimulations");

		newString = Replacer.simpleReplace(newString, "SIM_SaveSimulation", "Sim.saveSimulation");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorModValueByGpt", "Sim.setCorModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorModValue", "Sim.setCorModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorModValueByTable", "Sim.setCorModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorVegaShiftModValueByGpt",
				"Sim.setCorVegaShiftModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorVegaShiftModValueByTable",
				"Sim.setCorVegaShiftModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetCorVegaShiftModValue", "Sim.setCorVegaShiftModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetDeltaShiftModValueByGpt",
				"Sim.setDeltaShiftModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetDeltaShiftModValueByTable",
				"Sim.setDeltaShiftModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetDeltaShiftModByTable", "Sim.setDeltaShiftModByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetDeltaShiftModValue", "Sim.setDeltaShiftModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetDistributedBatchSimProperty",
				"Sim.setDistributedBatchSimProperty");

		newString = Replacer.simpleReplace(newString, "SIM_SetDistributedRevalProperty",
				"Sim.setDistributedRevalProperty");

		newString = Replacer.simpleReplace(newString, "SIM_SetFXModByTable", "Sim.setFXModByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetFXModValueByCcy", "Sim.setFXModValueByCcy");

		newString = Replacer.simpleReplace(newString, "SIM_SetFXModValue", "Sim.setFXModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateEODBODFlag", "Sim.setHorizonDateEODBODFlag");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateHistoricalPriceDate",
				"Sim.setHorizonDateHistoricalPriceDate");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateHistPriceDateMode",
				"Sim.setHorizonDateHistPriceDateMode");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateModValue", "Sim.setHorizonDateModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDatePricingMethod",
				"Sim.setHorizonDatePricingMethod");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDatePVDateMode", "Sim.setHorizonDatePVDateMode");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateResetDate", "Sim.setHorizonDateResetDate");

		newString = Replacer.simpleReplace(newString, "SIM_SetHorizonDateRollMarketData",
				"Sim.setHorizonDateRollMarketData");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexEffectiveModValueByGpt",
				"Sim.setIndexEffectiveModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexEffectiveModValueByTable",
				"Sim.setIndexEffectiveModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexEffectiveModValue", "Sim.setIndexEffectiveModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexModValueByGpt", "Sim.setIndexModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexModValueByTable", "Sim.setIndexModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexModValue", "Sim.setIndexModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexOutputModValueByTable",
				"Sim.setIndexOutputModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetIndexOutputModValue", "Sim.setIndexOutputModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetModValue", "Sim.setModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetOutputDeltaShiftModValue",
				"Sim.setOutputDeltaShiftModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetScenarioBMO", "Sim.setScenarioBMO");

		newString = Replacer.simpleReplace(newString, "SIM_SetUnFixConfigValue", "Sim.setUnFixConfigValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModValueByGpt", "Sim.setVegaShiftModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModValueByTable",
				"Sim.setVegaShiftModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModByTable", "Sim.setVegaShiftModByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetVegaShiftModValue", "Sim.setVegaShiftModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolInputModValueByGpt", "Sim.setVolInputModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolInputModValueByTable",
				"Sim.setVolInputModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolInputModValue", "Sim.setVolInputModValue");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolModValueByGpt", "Sim.setVolModValueByGpt");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolModValueByTable", "Sim.setVolModValueByTable");

		newString = Replacer.simpleReplace(newString, "SIM_SetVolModValue", "Sim.setVolModValue");

		newString = Replacer.simpleReplace(newString, "RESULT_CreateResultListForSim", "Sim.createResultListForSim");

		newString = Replacer.simpleReplace(newString, "RESULT_GetGenResults", "SimResult.getGenResults");

		newString = Replacer.simpleReplace(newString, "RESULT_FindGenResultTable", "SimResult.findGenResultTable");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultClass", "SimResult.getResultClass");

		newString = Replacer.simpleReplace(newString, "RESULT_GetTranResults", "SimResult.getTranResults");

		newString = Replacer.simpleReplace(newString, "RESULT_GetTranCumResults", "SimResult.getTranCumResults");

		newString = Replacer.simpleReplace(newString, "RESULT_GetTranLegResults", "SimResult.getTranLegResults");

		if (newString.contains("RESULT_AddResultForSim")) {
			tableObjectName = newString.replace("RESULT_AddResultForSim", "SimResult.addResultForSim");
			temp = tableObjectName.substring(tableObjectName.indexOf(",") + 1, tableObjectName.indexOf(")")).trim();
			tableObjectName = tableObjectName.replace(temp, "SimResultType.create(" + "\"" + temp + "\"");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		newString = Replacer.simpleReplace(newString, "RESULT_DestroyResultList", "Sim.destroyResultList");

		newString = Replacer.simpleReplace(newString, "RESULT_FindGenResultRow", "SimResult.findGenResultRow");

		newString = Replacer.simpleReplace(newString, "RESULT_GetAttrGroupsForResultType",
				"SimResult.getAttrGroupsForResultType");

		newString = Replacer.simpleReplace(newString, "RESULT_GetGenResultTables", "SimResult.getGenResultTables");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultConfig", "SimResult.getResultConfig");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultEnumFromId", "SimResult.getResultEnumFromId");

		newString = Replacer.simpleReplace(newString, "RESULT_GetResultIdFromEnum", "SimResult.getResultIdFromEnum");

		newString = Replacer.simpleReplace(newString, "RESULT_IsResultAllowedForTran",
				"SimResult.isResultAllowedForTran");

		newString = Replacer.simpleReplace(newString, "RESULT_ResultColName", "SimResult.resultColName");

		newString = Replacer.simpleReplace(newString, "COL_TABLE", "COL_TYPE_ENUM.COL_TABLE");

		newString = Replacer.simpleReplace(newString, "COL_STRING", "COL_TYPE_ENUM.COL_STRING");

		newString = Replacer.simpleReplace(newString, "COL_INT", "COL_TYPE_ENUM.COL_INT");

		newString = Replacer.simpleReplace(newString, "COL_DOUBLE", "COL_TYPE_ENUM.COL_DOUBLE");

		newString = Replacer.simpleReplace(newString, "ERROR_LogMessage", "Util.errorLogMessage");

		newString = Replacer.simpleReplace(newString, "OLF_RETURN_SUCCEED",
				"OLF_RETURN_CODE.OLF_RETURN_SUCCEED.toInt()");

		newString = Replacer.simpleReplace(newString, "QUERY_Clear", "Query.clear");

		newString = Replacer.simpleReplace(newString, "REF_GetValue", "Ref.getValue");

		newString = Replacer.simpleReplace(newString, "REF_GetInfo", "Ref.getInfo");

		newString = Replacer.simpleReplace(newString, "REF_GetName", "Ref.getName");

		newString = Replacer.simpleReplace(newString, "REF_AddNewSettleInstruction", "Ref.addNewSettleInstruction");

		newString = Replacer.simpleReplace(newString, "REF_AddNewAccount", "Ref.addNewAccount");

		newString = Replacer.simpleReplace(newString, "REF_AddNewParty", "Ref.addNewPartyn");

		newString = Replacer.simpleReplace(newString, "REF_AmIConnex", "Ref.amIConnex");

		newString = Replacer.simpleReplace(newString, "REF_AmIScreng", "Ref.amIScreng");

		newString = Replacer.simpleReplace(newString, "REF_AmITpm", "Ref.amITpm");

		newString = Replacer.simpleReplace(newString, "REF_ChangePartyDefaultAddress", "Ref.changePartyDefaultAddress");

		newString = Replacer.simpleReplace(newString, "REF_CopyPersonnel", "Ref.copyPersonnel");

		newString = Replacer.simpleReplace(newString, "REF_CreateMeasurementDataImportTable",
				"Ref.createMeasurementDataImportTable");

		newString = Replacer.simpleReplace(newString, "REF_CreatePartyAgreementTable", "Ref.createPartyAgreementTable");

		newString = Replacer.simpleReplace(newString, "REF_CreateParty", "Ref.createParty");

		newString = Replacer.simpleReplace(newString, "REF_ExportEnergyDataToFile", "Ref.REF_ExportEnergyDataToFile");

		newString = Replacer.simpleReplace(newString, "REF_CreatePortfolio", "Ref.createPortfolio");

		newString = Replacer.simpleReplace(newString, "REF_DeletePartyNote", "Ref.deletePartyNote");

		newString = Replacer.simpleReplace(newString, "REF_ExportEnergyDataToTable", "Ref.exportEnergyDataToTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportIndexLocationDataToTable",
				"Ref.exportIndexLocationDataToTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportIndexLocationDataToFile",
				"Ref.exportIndexLocationDataToFile");

		newString = Replacer.simpleReplace(newString, "REF_ExportParties", "Ref.exportParties");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyAgreementTableAll",
				"Ref.exportPartyAgreementTableAll");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyAgreementTable", "Ref.exportPartyAgreementTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyTableAll", "Ref.exportPartyTableAll");

		newString = Replacer.simpleReplace(newString, "REF_ExportPartyTable", "Ref.exportPartyTable");

		newString = Replacer.simpleReplace(newString, "REF_ExportPricingModelAttributes",
				"Ref.exportPricingModelAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ExportPricingModelConfigurations",
				"Ref.exportPricingModelConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ExportPricingModelDefinitions",
				"Ref.exportPricingModelDefinitions");

		newString = Replacer.simpleReplace(newString, "REF_ExportSimResultConfigurations",
				"Ref.exportSimResultConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ExportSimulationResultAttributes",
				"Ref.exportSimulationResultAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ExportUserDefinedInsTypes", "Ref.exportUserDefinedInsTypes");

		newString = Replacer.simpleReplace(newString, "REF_ExportUserDefinedSimResults",
				"Ref.exportUserDefinedSimResults");

		newString = Replacer.simpleReplace(newString, "REF_GetDeliveryTypeFromEventType",
				"Ref.getDeliveryTypeFromEventType");

		newString = Replacer.simpleReplace(newString, "REF_GetEventTypeFromDeliveryType",
				"Ref.getEventTypeFromDeliveryType");

		newString = Replacer.simpleReplace(newString, "REF_GetInsClassFromInsType", "Ref.getInsClassFromInsType");

		newString = Replacer.simpleReplace(newString, "REF_GetInsClassFromToolset", "Ref.getInsClassFromToolset");

		newString = Replacer.simpleReplace(newString, "REF_GetLicenseData", "Ref.getLicenseData");

		newString = Replacer.simpleReplace(newString, "REF_GetLocalCurrency", "Ref.getLocalCurrency");

		newString = Replacer.simpleReplace(newString, "REF_GetModuleId", "Ref.getModuleId");

		newString = Replacer.simpleReplace(newString, "REF_GetModuleName", "Ref.getModuleName");

		newString = Replacer.simpleReplace(newString, "REF_GetProcessId", "Ref.getProcessId");

		newString = Replacer.simpleReplace(newString, "REF_GetToolsetFromInsType", "Ref.getToolsetFromInsType");

		newString = Replacer.simpleReplace(newString, "REF_GetUserId", "Ref.getUserId");

		newString = Replacer.simpleReplace(newString, "REF_GetUserName", "Ref.getUserName");

		newString = Replacer.simpleReplace(newString, "REF_GetVersion", "Ref.getVersion");

		newString = Replacer.simpleReplace(newString, "REF_ImportEnergyDataFromFile", "Ref.importEnergyDataFromFile");

		newString = Replacer.simpleReplace(newString, "REF_ImportEnergyDataFromTable", "Ref.importEnergyDataFromTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportIndexLocationDataFromFile",
				"Ref.importIndexLocationDataFromFile");

		newString = Replacer.simpleReplace(newString, "REF_ImportIndexLocationDataFromTable",
				"Ref.importIndexLocationDataFromTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportMeasurementDataFromFile",
				"Ref.importMeasurementDataFromFile");

		newString = Replacer.simpleReplace(newString, "REF_ImportMeasurementDataFromTable",
				"Ref.importMeasurementDataFromTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportPartyAgreementTable", "Ref.importPartyAgreementTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportPartyTable", "Ref.importPartyTable");

		newString = Replacer.simpleReplace(newString, "REF_ImportPricingModelAttributes",
				"Ref.importPricingModelAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ImportPricingModelConfigurations",
				"Ref.importPricingModelConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ImportPricingModelDefinitions",
				"Ref.importPricingModelDefinitions");

		newString = Replacer.simpleReplace(newString, "REF_ImportSimResultConfigurations",
				"Ref.importSimResultConfigurations");

		newString = Replacer.simpleReplace(newString, "REF_ImportSimulationResultAttributes",
				"Ref.importSimulationResultAttributes");

		newString = Replacer.simpleReplace(newString, "REF_ImportUserDefinedInsTypes", "Ref.importUserDefinedInsTypes");

		newString = Replacer.simpleReplace(newString, "REF_ImportUserDefinedSimResults",
				"Ref.importUserDefinedSimResults");

		newString = Replacer.simpleReplace(newString, "REF_IsOptionInsType", "Ref.isOptionInsType");

		newString = Replacer.simpleReplace(newString, "REF_LinkAccountToParty", "Ref.linkAccountToParty");

		newString = Replacer.simpleReplace(newString, "REF_LinkPortfolioToParty", "Ref.linkPortfolioToParty");

		newString = Replacer.simpleReplace(newString, "REF_LinkPortfolioToPortfolioGroup",
				"Ref.linkPortfolioToPortfolioGroup");

		newString = Replacer.simpleReplace(newString, "REF_LinkSettleInstructionToParty",
				"Ref.linkSettleInstructionToParty");

		newString = Replacer.simpleReplace(newString, "REF_MoveLegalEntityAndLinkedBUs",
				"Ref.moveLegalEntityAndLinkedBUs");

		newString = Replacer.simpleReplace(newString, "REF_MoveParty", "Ref.moveParty");

		newString = Replacer.simpleReplace(newString, "REF_NewPortfolioTable", "Ref.newPortfolioTable");

		newString = Replacer.simpleReplace(newString, "REF_PipelineIdToRegionId", "Ref.pipelineIdToRegionId");

		newString = Replacer.simpleReplace(newString, "REF_RetrieveAccount", "Ref.retrieveAccount");

		newString = Replacer.simpleReplace(newString, "REF_RetrieveParty", "Ref.retrieveParty");

		newString = Replacer.simpleReplace(newString, "REF_RetrievePersonnelTable", "Ref.retrievePersonnelTable");

		newString = Replacer.simpleReplace(newString, "REF_RetrievePersonnel", "Ref.retrievePersonnel");

		newString = Replacer.simpleReplace(newString, "REF_RetrievePortfolio", "Ref.retrievePortfolio");

		newString = Replacer.simpleReplace(newString, "REF_RetrieveSettleInstruction", "Ref.retrieveSettleInstruction");

		newString = Replacer.simpleReplace(newString, "REF_SavePartyAgreementDocument",
				"Ref.savePartyAgreementDocument");

		newString = Replacer.simpleReplace(newString, "REF_SavePartyNote", "Ref.savePartyNote");

		newString = Replacer.simpleReplace(newString, "REF_SavePersonnel", "Ref.savePersonnel");

		newString = Replacer.simpleReplace(newString, "REF_UnLinkAccountFromParty", "Ref.unLinkAccountFromParty");

		newString = Replacer.simpleReplace(newString, "REF_UnlinkPortfolioFromParty", "Ref.unlinkPortfolioFromParty");

		newString = Replacer.simpleReplace(newString, "REF_UnlinkPortfolioFromPortfolioGroup",
				"Ref.unlinkPortfolioFromPortfolioGroup");

		newString = Replacer.simpleReplace(newString, "REF_UnLinkSettleInstructionFromParty",
				"Ref.unLinkSettleInstructionFromParty");

		newString = Replacer.simpleReplace(newString, "REF_UpdateAccount", "Ref.updateAccount");

		newString = Replacer.simpleReplace(newString, "REF_UpdateParty", "Ref.updateParty");

		newString = Replacer.simpleReplace(newString, "REF_UpdatePersonnelStatus", "Ref.updatePersonnelStatus");

		newString = Replacer.simpleReplace(newString, "REF_UpdatePortfolio", "Ref.updatePortfolio");

		newString = Replacer.simpleReplace(newString, "REF_UpdateSettleInstruction", "Ref.updateSettleInstruction");

		newString = Replacer.simpleReplace(newString, "MATCH_EQ", "MATCH_CMP_ENUM.MATCH_EQ");

		newString = Replacer.simpleReplace(newString, "NULL_TABLE", "Util.NULL_TABLE");

		newString = Replacer.simpleReplace(newString, "TRUE", "1");

		newString = Replacer.simpleReplace(newString, "FALSE", "0");

		newString = Replacer.simpleReplace(newString, "NOTNL_WIDTH", "Util.NOTNL_WIDTH");

		newString = Replacer.simpleReplace(newString, "BASE_NONE", "COL_FORMAT_BASE_ENUM.BASE_NONE.toInt()");

		newString = Replacer.simpleReplace(newString, "DoubleToInt", "Math.doubleToInt");

		newString = Replacer.simpleReplace(newString, "IntToDouble", "");

		newString = Replacer.simpleReplace(newString, "UTIL_GetEnergyConversionFactors",
				"Transaction.utilGetEnergyConversionFactors");

		newString = Replacer.simpleReplace(newString, "TRAN_Retrieve", "Transaction.retrieve");

		newString = Replacer.simpleReplace(newString, "INS_DATA*", "Instrument");

		newString = Replacer.simpleReplace(newString, "TRANSACTION*", "Transaction");

		newString = Replacer.simpleReplace(newString, "DB_RetrieveErrorInfo", "DBUserTable.dbRetrieveErrorInfo");

		newString = Replacer.simpleReplace(newString, "DBASE_CreateTableOfQueryResults",
				"DBase.createTableOfQueryResults");

		newString = Replacer.simpleReplace(newString, "DBASE_GetBCPFlagFromEnv", "DBase.getBCPFlagFromEnv");

		newString = Replacer.simpleReplace(newString, "DBASE_RunProcFillTable", "DBase.runProcFillTable");

		newString = Replacer.simpleReplace(newString, "DBASE_RunSqlFillTable", "DBase.runSqlFillTable");

		newString = Replacer.simpleReplace(newString, "DBASE_RunSql", "DBase.runSql");

		newString = Replacer.simpleReplace(newString, "DBASE_RunQueryWithIdList", "DBase.runQueryWithIdList");

		newString = Replacer.simpleReplace(newString, "DBASE_SetBCPFlag", "DBase.setBCPFlag");

		newString = Replacer.simpleReplace(newString, "DBMAINT_FindMissingInternalIdentifiers",
				"DBMaint.findMissingInternalIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBMAINT_GenerateNewInternalIdentifiers",
				"DBMaint.generateNewInternalIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBMAINT_LoadGroupIdentifiers", "DBMaint.loadGroupIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBMAINT_LoadTable", "DBMaint.loadTable");

		newString = Replacer.simpleReplace(newString, "DBMAINT_ReadData", "DBMaint.readData");

		newString = Replacer.simpleReplace(newString, "DBMAINT_RetrieveErrorInfo", "DBMaint.retrieveErrorInfo");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SaveData", "DBMaint.saveData");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SetDebug", "DBMaint.setDebug");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SSQL_Is_Valid", "DBMaint.ssqlIsValid");

		newString = Replacer.simpleReplace(newString, "DBMAINT_SSQL_New", "DBMaint.ssqlNew");

		newString = Replacer.simpleReplace(newString, "DBMAINT_UpdateNewInternalIdentifiers",
				"DBMaint.updateNewInternalIdentifiers");

		newString = Replacer.simpleReplace(newString, "DBASE_GetDbType", "DBase.getDbType");

		newString = Replacer.simpleReplace(newString, "DBMAINT_BCPIn", "DBMaint.bcpIn");

		newString = Replacer.simpleReplace(newString, "DBMAINT_CreateTable", "DBMaint.createTable");

		newString = Replacer.simpleReplace(newString, "DBMAINT_DeleteData", "DBMaint.deleteData");

		newString = Replacer.simpleReplace(newString, "DBMAINT_DisplayErrorInfo", "DBMaint.displayErrorInfo");

		newString = Replacer.simpleReplace(newString, "DBMAINT_Disconnect", "DBMaint.disconnect");

		newString = Replacer.simpleReplace(newString, "DBMAINT_ExecProc", "DBMaint.execProc");

		newString = Replacer.simpleReplace(newString, "DBMAINT_ExecSql", "DBMaint.execSql");

		newString = Replacer.simpleReplace(newString, "DBMAINT_Connect", "DBMaint.connect");

		newString = Replacer.simpleReplace(newString, "DBASE_RunProc", "DBase.runProc");

		newString = Replacer.simpleReplace(newString, "DBASE_GetBCPFlag", "DBase.getBCPFlag");

		newString = Replacer.simpleReplace(newString, "DBTABLE_BcpInTempDb", "DBUserTable.bcpInTempDb");

		newString = Replacer.simpleReplace(newString, "DBTABLE_BcpInWithFill", "DBUserTable.bcpInWithFill");

		newString = Replacer.simpleReplace(newString, "DBTABLE_BcpIn", "DBUserTable.bcpIn");

		newString = Replacer.simpleReplace(newString, "DBTABLE_ClearAllAccess", "DBUserTable.clearAllAccess");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Clear", "DBUserTable.clear");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Create", "DBUserTable.create");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Delete", "DBUserTable.delete");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Drop", "DBUserTable.drop");

		newString = Replacer.simpleReplace(newString, "DBTABLE_GetAccessSecurityGroups",
				"DBUserTable.getAccessSecurityGroups");

		newString = Replacer.simpleReplace(newString, "DBTABLE_GetAccess", "DBUserTable.getAccess");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Insert", "DBUserTable.insert");

		newString = Replacer.simpleReplace(newString, "DBTABLE_List", "DBUserTable.list");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Load", "DBUserTable.load");

		newString = Replacer.simpleReplace(newString, "DBTABLE_SaveUserTable", "DBUserTable.saveUserTable");

		newString = Replacer.simpleReplace(newString, "DBTABLE_SetAccessSecurityGroups",
				"DBUserTable.setAccessSecurityGroups");

		newString = Replacer.simpleReplace(newString, "DBTABLE_SetAccess", "DBUserTable.setAccess");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Structure", "DBUserTable.structure");

		newString = Replacer.simpleReplace(newString, "DBTABLE_Update", "DBUserTable.update");

		newString = Replacer.simpleReplace(newString, "DBTABLE_UserTableIsValid", "DBUserTable.userTableIsValid");

		newString = Replacer.simpleReplace(newString, "DBTYPE_SYBASE", "DBTYPE_ENUM.DBTYPE_SYBASE");

		newString = Replacer.simpleReplace(newString, "DBTYPE_TYPE_NOT_SET", "DBTYPE_ENUM.DBTYPE_TYPE_NOT_SET");

		newString = Replacer.simpleReplace(newString, "DBTYPE_MSSQL", "DBTYPE_ENUM.DBTYPE_MSSQL");

		newString = Replacer.simpleReplace(newString, "DBTYPE_ORACLE", "DBTYPE_ENUM.DBTYPE_ORACLE");

		newString = Replacer.simpleReplace(newString, "DEBUG_SetLevel", "Debug.setLevel");

		newString = Replacer.simpleReplace(newString, "DEBUG_SetTypeStatus", "Debug.setTypeStatus");

		newString = Replacer.simpleReplace(newString, "TABLE_CacheTable", "Table.cacheTable");

		newString = Replacer.simpleReplace(newString, "TABLE_CflowsToDiscCflows", "Index.tableCflowsToDiscCflows");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutAllTransFIFO",
				"TradeMaint.tableCloseOutAllTransFIFO");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutAllTransLIFO",
				"TradeMaint.tableCloseOutAllTransLIFO");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTradeN", "TradeMaint.tableCloseOutTrade");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTrade", "TradeMaint.tableCloseOutTrade");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransFIFOByPfolioIns",
				"TradeMaint.tableCloseOutTransFIFOByPfolioIns");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransFIFOByPfolios",
				"TradeMaint.tableCloseOutTransFIFOByPfolios");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransFIFOByQidDateRange",
				"TradeMaint.tableCloseOutTransFIFOByQidDateRange");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransFIFOByQid",
				"TradeMaint.tableCloseOutTransFIFOByQid");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransLIFOByPfolioIns",
				"TradeMaint.tableCloseOutTransLIFOByPfolioIns");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransLIFOByPfolios",
				"TradeMaint.tableCloseOutTransLIFOByPfolios");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransLIFOByQidDateRange",
				"TradeMaint.tableCloseOutTransLIFOByQidDateRange");

		newString = Replacer.simpleReplace(newString, "TABLE_CloseOutTransLIFOByQid",
				"TradeMaint.tableCloseOutTransLIFOByQid");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertDateToContractN",
				"Index.colConvertDateToContract");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertDateToContract",
				"Index.colConvertDateToContract");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertFXRates", "Index.colConvertFXRates");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertGptNameToContractN",
				"Index.colConvertGptNameToContract");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertGptNameToContract",
				"Index.colConvertGptNameToContract");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertGptNameToJdN",
				"Index.tableColConvertGptNameToJd");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertGptNameToJd",
				"Index.tableColConvertGptNameToJd");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertIndexToCurrencyN",
				"Index.tableColConvertIndexToCurrency");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertIndexToCurrency",
				"Index.tableColConvertIndexToCurrency");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertInsTypeToToolsetN",
				"Util.colConvertInsTypeToToolset");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertInsTypeToToolset",
				"Util.colConvertInsTypeToToolset");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToEOMN", "OCalendar.colConvertJdToEOM");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToEOM", "OCalendar.colConvertJdToEOM");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToEOYN", "OCalendar.colConvertJdToEOY");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToEOY", "OCalendar.colConvertJdToEOY");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToSOMN", "OCalendar.colConvertJdToSOM");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToSOM", "OCalendar.colConvertJdToSOM");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToSOYN", "OCalendar.colConvertJdToSOY");

		newString = Replacer.simpleReplace(newString, "TABLE_ColConvertJdToSOY", "OCalendar.colConvertJdToSOY");

		newString = Replacer.simpleReplace(newString, "TABLE_ColIndexDateToAnnZrN", "Index.tableColIndexDateToAnnZr");

		newString = Replacer.simpleReplace(newString, "TABLE_ColIndexDateToAnnZr", "Index.tableColIndexDateToAnnZr");

		newString = Replacer.simpleReplace(newString, "TABLE_ColIndexDateToDFN", "Index.tableColIndexDateToDF");

		newString = Replacer.simpleReplace(newString, "TABLE_ColIndexDateToDF", "Index.tableColIndexDateToDF");

		newString = Replacer.simpleReplace(newString, "TABLE_ColIndexDateToEffN", "Index.tableColIndexDateToEff");

		newString = Replacer.simpleReplace(newString, "TABLE_ColIndexDateToEff", "Index.tableColIndexDateToEff");

		newString = Replacer.simpleReplace(newString, "TABLE_ColNotnlToNumContractsN",
				"Index.tableColNotnlToNumContracts");

		newString = Replacer.simpleReplace(newString, "TABLE_ColNotnlToNumContracts",
				"Index.tableColNotnlToNumContracts");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetContractSizeN", "Index.tableColSetContractSize");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetContractSize", "Index.tableColSetContractSize");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetDeliveryTypeN", "Index.tableColSetDeliveryType");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetDeliveryType", "Index.tableColSetDeliveryType");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetDeltaShiftN", "Index.tableColSetDeltaShift");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetDeltaShift", "Index.tableColSetDeltaShift");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetIndexLabelN", "Index.tableColSetIndexLabel");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetIndexLabel", "Index.tableColSetIndexLabel");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetIndexRefSourceN", "Index.tableColSetIndexRefSource");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSetIndexRefSource", "Index.tableColSetIndexRefSource");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSpotFXForCurrencyN", "Index.colSpotFXForCurrency");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSpotFXForCurrency", "Index.colSpotFXForCurrency");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSpotFXN", "Index.colSpotFX");

		newString = Replacer.simpleReplace(newString, "TABLE_ColSpotFX", "Index.colSpotFX");

		newString = Replacer.simpleReplace(newString, "TABLE_CompareBinaryFile", "Util.tableCompareBinaryFile");

		newString = Replacer.simpleReplace(newString, "TABLE_CreateImageDiff", "Positions.createImageDiff");

		newString = Replacer.simpleReplace(newString, "TABLE_CreatePaymentReconcileTable",
				"Acct.tableCreatePaymentReconcileTable");

		newString = Replacer.simpleReplace(newString, "TABLE_CreatePaymentTable", "Acct.tableCreatePaymentTable");

		newString = Replacer.simpleReplace(newString, "TABLE_DestroyCachedTable", "Table.destroyCachedTable");

		newString = Replacer.simpleReplace(newString, "TABLE_DiffContainsNewImage", "Positions.diffContainsNewImage");

		newString = Replacer.simpleReplace(newString, "TABLE_DiffForceOpcodeNewImage",
				"Positions.diffForceOpcodeNewImage");

		newString = Replacer.simpleReplace(newString, "TABLE_DiffGetNewImage", "Positions.diffGetNewImage");

		newString = Replacer.simpleReplace(newString, "TABLE_DiffInsertCellUpdateDouble",
				"Positions.diffInsertCellUpdateDouble");

		newString = Replacer.simpleReplace(newString, "TABLE_DiffInsertCellUpdateInt",
				"Positions.diffInsertCellUpdateInt");

		newString = Replacer.simpleReplace(newString, "TABLE_DiffInsertCellUpdateString",
				"Positions.diffInsertCellUpdateString");

		newString = Replacer.simpleReplace(newString, "TABLE_DrillGetCellEntryN", "Positions.drillGetCellEntry");

		newString = Replacer.simpleReplace(newString, "TABLE_DrillGetCellEntry", "Positions.drillGetCellEntry");

		newString = Replacer.simpleReplace(newString, "TABLE_DrillGetNumCellEntriesN",
				"Positions.drillGetNumCellEntries");

		newString = Replacer.simpleReplace(newString, "TABLE_DrillTableCreate", "Positions.drillTableCreate");

		newString = Replacer.simpleReplace(newString, "TABLE_DrillInsertEntryN", "Positions.drillInsertEntry");

		newString = Replacer.simpleReplace(newString, "TABLE_DrillInsertEntry", "Positions.drillInsertEntry");

		newString = Replacer.simpleReplace(newString, "TABLE_ExecISql", "DBaseTable.execISql");

		newString = Replacer.simpleReplace(newString, "TABLE_ExportCrystalReport", "Crystal.tableExportCrystalReport");

		newString = Replacer.simpleReplace(newString, "TABLE_ExportCrystalReportWithSubreports",
				"Crystal.tableExportCrystalReportWithSubreports");

		newString = Replacer.simpleReplace(newString, "TABLE_ExtendImageDiff", "Positions.extendImageDiff");

		newString = Replacer.simpleReplace(newString, "TABLE_InsertPaymentTable", "Acct.tableInsertPaymentTable");

		newString = Replacer.simpleReplace(newString, "TABLE_PublishGlobalRV", "Broadcast.tablePublishGlobalRV");

		newString = Replacer.simpleReplace(newString, "TABLE_PublishLocalRV", "Broadcast.tablePublishLocalRV");

		newString = Replacer.simpleReplace(newString, "TABLE_PublishRV", "Broadcast.tablePublishRV");

		newString = Replacer.simpleReplace(newString, "TABLE_FormatDateInt", "OCalendar.formatDateInt");

		newString = Replacer.simpleReplace(newString, "TABLE_FormatRefInt", "Table.formatRefInt");

		newString = Replacer.simpleReplace(newString, "TABLE_FromXHTML", "Table.fromXhtml");

		newString = Replacer.simpleReplace(newString, "TABLE_GetAccountBalanceDetails",
				"Transaction.getAccountBalanceDetails");

		newString = Replacer.simpleReplace(newString, "TABLE_GetAliasTable", "Util.getAliasTable");

		newString = Replacer.simpleReplace(newString, "TABLE_GetAllTableDefInTable", "Util.getAllTableDefInTable");

		newString = Replacer.simpleReplace(newString, "TABLE_GetApplicableFieldListForToolset",
				"Transaction.tableGetApplicableFieldListForToolset");

		newString = Replacer.simpleReplace(newString, "TABLE_GetCachedTable", "Table.getCachedTable");

		newString = Replacer.simpleReplace(newString, "TABLE_GetCachedTablesInfo", "Table.getCachedTablesInfo");

		newString = Replacer.simpleReplace(newString, "TABLE_GetCurrencyInfo", "Ref.getCurrencyInfo");

		newString = Replacer.simpleReplace(newString, "TABLE_GetETagN", "ETag.tableGetETag");

		newString = Replacer.simpleReplace(newString, "TABLE_GetETag", "ETag.tableGetETag");

		newString = Replacer.simpleReplace(newString, "TABLE_GetFileAttributes", "Util.tableGetFileAttributes");

		newString = Replacer.simpleReplace(newString, "TABLE_GetHighestLevelParentN", "Index.getHighestLevelParent");

		newString = Replacer.simpleReplace(newString, "TABLE_GetHighestLevelParent", "Index.getHighestLevelParent");

		newString = Replacer.simpleReplace(newString, "TABLE_GetLocationAdjustmentInfo",
				"Transaction.tableGetLocationAdjustmentInfo");

		newString = Replacer.simpleReplace(newString, "TABLE_GetPhysicalBalanceDetails",
				"Transaction.getPhysicalBalanceDetails");

		newString = Replacer.simpleReplace(newString, "TABLE_GetSecurityInventoryDetails",
				"Transaction.getSecurityInventoryDetails");

		newString = Replacer.simpleReplace(newString, "TABLE_GetSharedInsFromGpts", "Index.tableGetSharedInsFromGpts");

		newString = Replacer.simpleReplace(newString, "TABLE_GetSharedInsFromGptsN", "Index.tableGetSharedInsFromGpts");

		newString = Replacer.simpleReplace(newString, "TABLE_ImportHistoricalPricesAndFixDeals",
				"Index.tableImportHistoricalPricesAndFixDeals");

		newString = Replacer.simpleReplace(newString, "TABLE_ImportHistoricalPrices",
				"Index.tableImportHistoricalPrices");

		newString = Replacer.simpleReplace(newString, "TABLE_ImportHourlyHistoricalPrices",
				"Index.tableImportHourlyHistoricalPrices");

		newString = Replacer.simpleReplace(newString, "TABLE_InitSp", "DBaseTable.initSp");

		newString = Replacer.simpleReplace(newString, "TABLE_InsertColIntoQuery", "Query.tableInsertColIntoQuery");

		newString = Replacer.simpleReplace(newString, "TABLE_InsertColIntoQueryN", "Query.tableInsertColIntoQuery");

		newString = Replacer.simpleReplace(newString, "TABLE_InsertTranByStatus",
				"Transaction.tableInsertTranByStatus");

		newString = Replacer.simpleReplace(newString, "TABLE_InsertTranInfo", "Transaction.insertTranInfo");

		newString = Replacer.simpleReplace(newString, "TABLE_InsertTransferPricesN",
				"Transaction.insertTransferPrices");

		newString = Replacer.simpleReplace(newString, "TABLE_InsertTransferPrices", "Transaction.insertTransferPrices");

		newString = Replacer.simpleReplace(newString, "TABLE_IsColTypeValid", "Table.isColTypeValid");

		newString = Replacer.simpleReplace(newString, "TABLE_IsRowTypeValid", "Table.isRowTypeValid");

		newString = Replacer.simpleReplace(newString, "TABLE_ListFilesInDirectory", "Util.tableListFilesInDirectory");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadAllRefLists", "Ref.loadAllRefLists");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadBunitListForUser", "Util.tableLoadBunitListForUser");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadCashFromDbByType", "Instrument.loadCashFromDbByType");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadChildIndexes", "Index.tableLoadChildIndexes");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadEventFromDbByType",
				"Instrument.loadEventFromDbByType");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadFromDbWithSQL", "DBaseTable.loadFromDbWithSQL");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadFromDbWithWhatWhere",
				"DBaseTable.loadFromDbWithWhatWhere");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadFromDbWithWhere", "DBaseTable.loadFromDbWithWhere");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadFromDb", "DBaseTable.loadFromDb");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadFromRef", "Ref.loadFromRef");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadGptNameFromId", "Index.tableLoadGptNameFromId");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadIIMFromDbByCurveTerm",
				"Instrument.loadIIMFromDbByCurveTerm");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadIIMFromDb", "Instrument.loadIIMFromDb");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadIndexGptsByIndexName",
				"Index.tableLoadIndexGptsByIndexName");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadIndexGpts", "Index.tableLoadIndexGpts");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadLegalEntityListForUser",
				"Util.tableLoadLegalEntityListForUser");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadParentIndexes", "Index.tableLoadParentIndexes");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadPartyNameFromDb", "Ref.loadPartyNameFromDb");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadPartyNameFromDbN", "Ref.loadPartyNameFromDb");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadPfolioListForBunit",
				"Util.tableLoadPfolioListForBunit");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadProfileFromDbByDate",
				"Instrument.loadProfileFromDbByDate");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadQueryList", "Util.tableLoadQueryList");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadQueryResult", "Query.tableLoadQueryResult");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadQueryResultN", "Query.tableLoadQueryResult");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadRefList", "Ref.loadRefList");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadResetFromDbByDate",
				"Instrument.loadResetFromDbByDate");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadSimByPfolios", "SimResult.tableLoadSimByPfolios");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadSimDefList", "Util.tableLoadSimDefList");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTableFromFile", "Table.loadTableFromFile");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTableFromSPWithParamsWithNumRows",
				"DBaseTable.loadTableFromSPWithParamsWithNumRows");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTemplateListForToolset",
				"Util.tableLoadTemplateListForToolset");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTableFromSPWithParams",
				"DBaseTable.loadTableFromSPWithParams");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTaskList_by", "Util.tableLoadTaskListBy");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTaskList", "Util.tableLoadTaskList");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTraderNameFromDbN", "Ref.loadTraderNameFromDb");

		newString = Replacer.simpleReplace(newString, "TABLE_LoadTraderNameFromDb", "Ref.loadTraderNameFromDb");

		newString = Replacer.simpleReplace(newString, "TABLE_MoveOpenPositions", "TradeMaint.tableMoveOpenPositions");

		newString = Replacer.simpleReplace(newString, "TABLE_ParseSymbolicDates", "OCalendar.parseSymbolicDates");

		newString = Replacer.simpleReplace(newString, "TABLE_ParseSymbolicDatesN", "OCalendar.parseSymbolicDates");

		newString = Replacer.simpleReplace(newString, "TABLE_PrintCrystalReportWithSubreports",
				"Crystal.tablePrintCrystalReportWithSubreports");

		newString = Replacer.simpleReplace(newString, "TABLE_PrintCrystalReport", "Crystal.tablePrintCrystalReport");

		newString = Replacer.simpleReplace(newString, "TABLE_PrintTableToReport", "Report.printTableToReport");

		newString = Replacer.simpleReplace(newString, "TABLE_QueryInsertN", "Query.tableQueryInsert");

		newString = Replacer.simpleReplace(newString, "TABLE_ReadBinaryFile", "Util.tableReadBinaryFile");

		newString = Replacer.simpleReplace(newString, "TABLE_ReportEnd", "Report.reportEnd");

		newString = Replacer.simpleReplace(newString, "TABLE_ReportPrint", "Report.reportPrint");

		newString = Replacer.simpleReplace(newString, "TABLE_ReportPrintToPrinter", "Report.reportPrintToPrinter");

		newString = Replacer.simpleReplace(newString, "TABLE_ReportStart", "Report.reportStart");

		newString = Replacer.simpleReplace(newString, "TABLE_RetrieveTranInfo", "Transaction.retrieveTranInfo");

		newString = Replacer.simpleReplace(newString, "TABLE_RetrieveUserInfo", "Util.retrieveUserInfo");

		newString = Replacer.simpleReplace(newString, "TABLE_SetDefaultHeaderFields", "Util.setDefaultHeaderFields");

		newString = Replacer.simpleReplace(newString, "TABLE_StartMemoryWatch", "SystemUtil.startMemoryWatch");

		newString = Replacer.simpleReplace(newString, "TABLE_StopMemoryWatch", "SystemUtil.stopMemoryWatch");

		newString = Replacer.simpleReplace(newString, "TABLE_TranfDestroy", "Transaction.tableTranfDestroy");

		newString = Replacer.simpleReplace(newString, "TABLE_TranfInval", "Transaction.tableTranfInval");

		newString = Replacer.simpleReplace(newString, "TABLE_TranfInvalCell", "Transaction.tableTranfInvalCell");

		newString = Replacer.simpleReplace(newString, "TABLE_TranfNew", "Transaction.tableTranfNew");

		newString = Replacer.simpleReplace(newString, "TABLE_TranfSubscribe", "Transaction.tableTranfSubscribe");

		newString = Replacer.simpleReplace(newString, "TABLE_TranfTableIsValid", "Transaction.tableTranfTableIsValid");

		newString = Replacer.simpleReplace(newString, "TABLE_TranfUnsubscribe", "Transaction.tableTranfUnsubscribe");

		newString = Replacer.simpleReplace(newString, "TABLE_UnwindCloseOutByDateId",
				"TradeMaint.tableUnwindCloseOutByDateId");

		newString = Replacer.simpleReplace(newString, "TABLE_UnwindCloseOutByDateRange",
				"TradeMaint.tableUnwindCloseOutByDateRange");

		newString = Replacer.simpleReplace(newString, "TABLE_UnwindCloseOutByDate",
				"TradeMaint.tableUnwindCloseOutByDate");

		newString = Replacer.simpleReplace(newString, "TABLE_UpdatePortfolio", "TradeMaint.tableUpdatePortfolio");

		newString = Replacer.simpleReplace(newString, "TABLE_UpdatePortfolioN", "TradeMaint.tableUpdatePortfolio");

		newString = Replacer.simpleReplace(newString, "TABLE_UpdateTransferPrices", "Transaction.updateTransferPrices");

		newString = Replacer.simpleReplace(newString, "TABLE_UpdateTransferPricesN",
				"Transaction.updateTransferPrices");

		newString = Replacer.simpleReplace(newString, "TABLE_UpdateFTPCurve", "Transaction.updateFTPCurve");

		newString = Replacer.simpleReplace(newString, "TABLE_ViewCrystalReportWithSubreports",
				"Crystal.tableViewCrystalReportWithSubreports");

		newString = Replacer.simpleReplace(newString, "TABLE_ViewCrystalReport", "Crystal.tableViewCrystalReport");

		newString = Replacer.simpleReplace(newString, "TABLE_ViewPrintOk", "Report.viewPrintOk");

		newString = Replacer.simpleReplace(newString, "TABLE_WriteBinaryFile", "Util.tableWriteBinaryFile");

		newString = Replacer.simpleReplace(newString, "TABLE_XMLStringToTable", "Table.xmlStringToTable");

		newString = Replacer.simpleReplace(newString, "TASK_Create", "Util.taskCreate");

		newString = Replacer.simpleReplace(newString, "TASK_GetExecutionLog", "Util.taskGetExecutionLog");

		newString = Replacer.simpleReplace(newString, "TASK_GetListBy", "Util.taskGetListBy");

		newString = Replacer.simpleReplace(newString, "TESTWORKBENCH_AutoRun", "Util.testworkbenchAutoRun");

		newString = Replacer.simpleReplace(newString, "TIME_GetServerTimeHMS", "Util.timeGetServerTimeHMS");

		newString = Replacer.simpleReplace(newString, "TIME_GetServerTime", "Util.timeGetServerTime");

		newString = Replacer.simpleReplace(newString, "TMAINT_AddEFPPostingEvent",
				"TradeMaint.tmaintAddEFPPostingEvent");

		newString = Replacer.simpleReplace(newString, "TMAINT_AddTran", "TradeMaint.tmaintAddTran");

		newString = Replacer.simpleReplace(newString, "TMAINT_AddTriggerEvent", "TradeMaint.tmaintAddTriggerEvent");

		newString = Replacer.simpleReplace(newString, "TMAINT_BondTranRefreshGivenQuery",
				"TradeMaint.tmaintBondTranRefreshGivenQuery");

		newString = Replacer.simpleReplace(newString, "TMAINT_CreateEvergreenTable",
				"TradeMaint.tmaintCreateEvergreenTable");

		newString = Replacer.simpleReplace(newString, "TMAINT_DeleteTriggerEvents",
				"TradeMaint.tmaintDeleteTriggerEvents");

		newString = Replacer.simpleReplace(newString, "TMAINT_EFPUpdateAssoc", "TradeMaint.tmaintEFPUpdateAssoc");

		newString = Replacer.simpleReplace(newString, "TMAINT_FixPriorUnknownResets",
				"TradeMaint.tmaintFixPriorUnknownResets");

		newString = Replacer.simpleReplace(newString, "TMAINT_FixupFixings", "TradeMaint.tmaintFixupFixings");

		newString = Replacer.simpleReplace(newString, "TMAINT_FlogError", "TradeMaint.tmaintFlogError");

		newString = Replacer.simpleReplace(newString, "TMAINT_get_location_id_from_tran_info",
				"TradeMaint.tmaintgetLocationIdFromTranInfo");

		newString = Replacer.simpleReplace(newString, "TMAINT_GetOrigTran", "TradeMaint.tmaintGetOrigTran");

		newString = Replacer.simpleReplace(newString, "TMAINT_GetTranNeedingRegen",
				"TradeMaint.tmaintGetTranNeedingRegen");

		newString = Replacer.simpleReplace(newString, "TMAINT_ImportDailyDeliveryFromTable",
				"TradeMaint.tmaintImportDailyDeliveryFromTable");

		newString = Replacer.simpleReplace(newString, "TMAINT_ImportDailyDelivery",
				"TradeMaint.tmaintImportDailyDelivery");

		newString = Replacer.simpleReplace(newString, "TMAINT_InsertInsFromBlob", "TradeMaint.tmaintInsertInsFromBlob");

		newString = Replacer.simpleReplace(newString, "TK_RetrieveArgTable", "RptMgr.tkRetrieveArgTable");

		newString = Replacer.simpleReplace(newString, "TK_SaveArgTable", "RptMgr.tkSaveArgTable");

		newString = Replacer.simpleReplace(newString, "TMAINT_LoadEvergreens", "TradeMaint.tmaintLoadEvergreens");

		newString = Replacer.simpleReplace(newString, "TMAINT_post_efp_trigger", "TradeMaint.tmaintpostEfpTrigger");

		newString = Replacer.simpleReplace(newString, "TMAINT_ProcessEvergreens", "TradeMaint.tmaintProcessEvergreens");

		newString = Replacer.simpleReplace(newString, "TMAINT_RebookTradeGivenQuery",
				"TradeMaint.tmaintRebookTradeGivenQuery");

		newString = Replacer.simpleReplace(newString, "TMAINT_RefixCashMonthReset",
				"TradeMaint.tmaintRefixCashMonthReset");

		newString = Replacer.simpleReplace(newString, "TMAINT_RefreshStructGivenQuery",
				"TradeMaint.tmaintRefreshStructGivenQuery");

		newString = Replacer.simpleReplace(newString, "TMAINT_update_engy_delivery_inventory",
				"TradeMaint.tmaintupdateEngyDeliveryInventory");

		newString = Replacer.simpleReplace(newString, "TMAINT_UpdateCreditDerivIndexes",
				"TradeMaint.tmaintUpdateCreditDerivIndexes");

		newString = Replacer.simpleReplace(newString, "TOF_InsertError", "ExtInterfaces.insertError");

		newString = Replacer.simpleReplace(newString, "TOF_SetHeaderStatus", "ExtInterfaces.setHeaderStatus");

		newString = Replacer.simpleReplace(newString, "TPM_AbortInstance", "Tpm.abortInstance");

		newString = Replacer.simpleReplace(newString, "TPM_AcceptTask", "Tpm.acceptTask");

		newString = Replacer.simpleReplace(newString, "TPM_AddBooleanToVariableTable", "Tpm.addBooleanToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddCustomListToVariableTable",
				"Tpm.addCustomListToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddDateToVariableTable", "Tpm.addDateToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddDoubleToVariableTable", "Tpm.addDoubleToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddErrorEntry", "Tpm.addErrorEntry");

		newString = Replacer.simpleReplace(newString, "TPM_AddIntToVariableTable", "Tpm.addIntToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddJdToVariableTable", "Tpm.addJdToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddLongIntToVariableTable", "Tpm.addLongIntToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddMultiSelectPickListToVariableTable",
				"Tpm.addMultiSelectPickListToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddMultiSelectUserListToVariableTable",
				"Tpm.addMultiSelectUserListToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddPickListToVariableTable",
				"Tpm.addPickListToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddStringToVariableTable", "Tpm.addStringToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddSymbolicDateToVariableTable",
				"Tpm.addSymbolicDateToVariableTable");

		newString = Replacer.simpleReplace(newString, "addSymbolicDateToVariableTable",
				"Tpm.addSymbolicDateToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddToStartInstanceTable", "Tpm.addToStartInstanceTable");

		newString = Replacer.simpleReplace(newString, "TPM_AddUserListToVariableTable",
				"Tpm.addUserListToVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_AssignTask", "Tpm.assignTask");

		newString = Replacer.simpleReplace(newString, "TPM_CommentTask", "Tpm.commentTask");

		newString = Replacer.simpleReplace(newString, "TPM_CompleteTask", "Tpm.completeTask");

		newString = Replacer.simpleReplace(newString, "TPM_CreateStartInstanceTable", "Tpm.createStartInstanceTable");

		newString = Replacer.simpleReplace(newString, "TPM_CreateVariableTable", "Tpm.createVariableTable");

		newString = Replacer.simpleReplace(newString, "TPM_DeleteDefinition", "Util.tpmDeleteDefinition");

		newString = Replacer.simpleReplace(newString, "TPM_GetArgTable", "Tpm.getArgTable");

		newString = Replacer.simpleReplace(newString, "TPM_GetInstanceId", "Tpm.getInstanceId");

		newString = Replacer.simpleReplace(newString, "TPM_GetInstanceLogByDate", "Tpm.getInstanceLogByDate");

		newString = Replacer.simpleReplace(newString, "TPM_GetInstanceLogByJd", "Tpm.getInstanceLogByJd");

		newString = Replacer.simpleReplace(newString, "TPM_GetInstanceLog", "Tpm.getInstanceLog");

		newString = Replacer.simpleReplace(newString, "TPM_GetInstancesByDefinition", "Tpm.getInstancesByDefinition");

		newString = Replacer.simpleReplace(newString, "TPM_GetInstanceStatusAll", "Tpm.getInstanceStatusAll");

		newString = Replacer.simpleReplace(newString, "TPM_GetInstanceStatus", "Tpm.getInstanceStatus");

		newString = Replacer.simpleReplace(newString, "TPM_GetTaskList", "Tpm.getTaskList");

		newString = Replacer.simpleReplace(newString, "TPM_GetTokenId", "Tpm.getTokenId");

		newString = Replacer.simpleReplace(newString, "TPM_GetVariables", "Tpm.getVariables");

		newString = Replacer.simpleReplace(newString, "TPM_MoveToStep", "Tpm.moveToStep");

		newString = Replacer.simpleReplace(newString, "TPM_PostStatus", "Tpm.postStatus");

		newString = Replacer.simpleReplace(newString, "TPM_PresetArgTable", "Tpm.presetArgTable");

		newString = Replacer.simpleReplace(newString, "TPM_PresetVariables", "Tpm.presetVariables");

		newString = Replacer.simpleReplace(newString, "TPM_PresetVariable", "Tpm.presetVariable");

		newString = Replacer.simpleReplace(newString, "TPM_ProcessActionUsingScreng", "Tpm.processActionUsingScreng");

		newString = Replacer.simpleReplace(newString, "TPM_QueryTasks", "Util.tpmQueryTasks");

		newString = Replacer.simpleReplace(newString, "TPM_SetArgTable", "Tpm.setArgTable");

		newString = Replacer.simpleReplace(newString, "TPM_SetTaskPriority", "Tpm.setTaskPriority");

		newString = Replacer.simpleReplace(newString, "TPM_SetVariables", "Tpm.setVariables");

		newString = Replacer.simpleReplace(newString, "TPM_SetVariable", "Tpm.setVariable");

		newString = Replacer.simpleReplace(newString, "TPM_SignalInstance", "Tpm.signalInstance");

		newString = Replacer.simpleReplace(newString, "TPM_StartInstances", "Tpm.startInstances");

		newString = Replacer.simpleReplace(newString, "TPM_StartInstance", "Tpm.startInstance");

		newString = Replacer.simpleReplace(newString, "PERF_CalcReturns", "Performance.calcReturns");

		newString = Replacer.simpleReplace(newString, "PERF_ComputeSecurityResults",
				"Performance.computeSecurityResults");

		newString = Replacer.simpleReplace(newString, "PERF_ComputeSecurityValues",
				"Performance.computeSecurityValues");

		newString = Replacer.simpleReplace(newString, "PERF_CreateDefaultConfigTable",
				"Performance.createDefaultConfigTable");

		newString = Replacer.simpleReplace(newString, "PERF_CreateSecurityDefnAttribTable",
				"Performance.createSecurityDefnAttribTable");

		newString = Replacer.simpleReplace(newString, "PERF_CreateSecurityDefnTable",
				"Performance.createSecurityDefnTable");

		newString = Replacer.simpleReplace(newString, "PERF_CreateSecurityPricesTable",
				"Performance.createSecurityPricesTable");

		newString = Replacer.simpleReplace(newString, "PERF_CreateSecurityResultsTable",
				"Performance.createSecurityResultsTable");

		newString = Replacer.simpleReplace(newString, "PERF_CreateSecurityValuesTable",
				"Performance.createSecurityValuesTable");

		newString = Replacer.simpleReplace(newString, "PERF_DeleteSecurityPrices", "Performance.deleteSecurityPrices");

		newString = Replacer.simpleReplace(newString, "PERF_DeleteSecurityTranLog",
				"Performance.deleteSecurityTranLog");

		newString = Replacer.simpleReplace(newString, "PERF_DeleteSecurityTranLogForTran",
				"Performance.deleteSecurityTranLogForTran");

		newString = Replacer.simpleReplace(newString, "PERF_DeleteSecurityValues", "Performance.deleteSecurityValues");

		newString = Replacer.simpleReplace(newString, "PERF_DeleteSecurityValuesForSecurity",
				"Performance.deleteSecurityValuesForSecurity");

		newString = Replacer.simpleReplace(newString, "PERF_FindAmendedDeals", "Performance.findAmendedDeals");

		newString = Replacer.simpleReplace(newString, "PERF_FindNewSecurityDefn", "Performance.findNewSecurityDefn");

		newString = Replacer.simpleReplace(newString, "PERF_FindNewSecurityPrices",
				"Performance.findNewSecurityPrices");

		newString = Replacer.simpleReplace(newString, "PERF_FindNewSecurityTranCflows",
				"Performance.findNewSecurityTranCflows");

		newString = Replacer.simpleReplace(newString, "PERF_FindNewSecurityTran", "Performance.findNewSecurityTran");

		newString = Replacer.simpleReplace(newString, "PERF_InsertProcessLogEntry",
				"Performance.insertProcessLogEntry");

		newString = Replacer.simpleReplace(newString, "PERF_InsertSecurityDefnAttrib",
				"Performance.insertSecurityDefnAttrib");

		newString = Replacer.simpleReplace(newString, "PERF_InsertSecurityDefn", "Performance.insertSecurityDefn");

		newString = Replacer.simpleReplace(newString, "PERF_InsertSecurityPrices", "Performance.insertSecurityPrices");

		newString = Replacer.simpleReplace(newString, "PERF_InsertSecurityResults",
				"Performance.insertSecurityResults");

		newString = Replacer.simpleReplace(newString, "PERF_InsertSecurityTranLog",
				"Performance.insertSecurityTranLog");

		newString = Replacer.simpleReplace(newString, "PERF_InsertSecurityValues", "Performance.insertSecurityValues");

		newString = Replacer.simpleReplace(newString, "PERF_RegenSecurityValuesForTran",
				"Performance.regenSecurityValuesForTran");

		newString = Replacer.simpleReplace(newString, "PERF_RegenTranLogForTran", "Performance.regenTranLogForTran");

		newString = Replacer.simpleReplace(newString, "PERF_UpdateSecurityPrices", "Performance.updateSecurityPrices");

		newString = Replacer.simpleReplace(newString, "POS_ApplyPageFilter", "Positions.posApplyPageFilter");

		newString = Replacer.simpleReplace(newString, "POS_ApplySinglePageFilter",
				"Positions.posApplySinglePageFilter");

		newString = Replacer.simpleReplace(newString, "POS_BatchReturnRTPage", "Positions.posBatchReturnRTPage");

		newString = Replacer.simpleReplace(newString, "POS_ComputeEndDateFromSymbolic",
				"Positions.posComputeEndDateFromSymbolic");

		newString = Replacer.simpleReplace(newString, "POS_CreateLockHideInfoTableByConfig",
				"Positions.posCreateLockHideInfoTableByConfig");

		newString = Replacer.simpleReplace(newString, "POS_CreatePagePivotTable", "Positions.posCreatePagePivotTable");

		newString = Replacer.simpleReplace(newString, "POS_CreatePivotDiff", "Positions.posCreatePivotDiff");

		newString = Replacer.simpleReplace(newString, "POS_CreateScriptPivotInfoTable",
				"Positions.posCreateScriptPivotInfoTable");

		newString = Replacer.simpleReplace(newString, "POS_GetConfigTable", "Positions.posGetConfigTable");

		newString = Replacer.simpleReplace(newString, "POS_GetDatesConfigTable", "Positions.posGetDatesConfigTable");

		newString = Replacer.simpleReplace(newString, "POS_GetFullPageTitle", "Positions.posGetFullPageTitle");

		newString = Replacer.simpleReplace(newString, "POS_GetMacroContent", "Positions.posGetMacroContent");

		newString = Replacer.simpleReplace(newString, "POS_GetMasterConfigFilterContent",
				"Positions.getMasterConfigFilterContent");

		newString = Replacer.simpleReplace(newString, "POS_GetNumPageFiltersByType",
				"Positions.posGetNumPageFiltersByType");

		newString = Replacer.simpleReplace(newString, "POS_GetNumRTPages", "Positions.posGetNumRTPages");

		newString = Replacer.simpleReplace(newString, "POS_GetPageFilterContent", "Positions.posGetPageFilterContent");

		newString = Replacer.simpleReplace(newString, "POS_GetPageFilterItemContent",
				"Positions.posGetPageFilterItemContent");

		newString = Replacer.simpleReplace(newString, "POS_GetPageFilterItemScalarID",
				"Positions.posGetPageFilterItemScalarID");

		newString = Replacer.simpleReplace(newString, "POS_GetPageFilterItemScalarValue",
				"Positions.posGetPageFilterItemScalarValue");

		newString = Replacer.simpleReplace(newString, "POS_GetPageTitle", "Positions.posGetPageTitle");

		newString = Replacer.simpleReplace(newString, "POS_GetRTPageDefinitionID",
				"Positions.posGetRTPageDefinitionID");

		newString = Replacer.simpleReplace(newString, "POS_GetRTPageName", "Positions.posGetRTPageName");

		newString = Replacer.simpleReplace(newString, "POS_GetRTPagePosConfig", "Positions.posGetRTPagePosConfig");

		newString = Replacer.simpleReplace(newString, "POS_GetUniqueSequence", "Positions.posGetUniqueSequence");

		newString = Replacer.simpleReplace(newString, "POS_ImportPositionPageConfig",
				"Positions.posImportPositionPageConfig");

		newString = Replacer.simpleReplace(newString, "POS_IncrPivot", "Positions.posIncrPivot");

		newString = Replacer.simpleReplace(newString, "POS_IncrReturnRTPage", "Positions.posIncrReturnRTPage");

		newString = Replacer.simpleReplace(newString, "POS_InitBatchReturnT", "Positions.posInitBatchReturnT");

		newString = Replacer.simpleReplace(newString, "POS_InitIncrReturnT", "Positions.posInitIncrReturnT");

		newString = Replacer.simpleReplace(newString, "POS_InstallNewPageFilterContent",
				"Positions.posInstallNewPageFilterContent");

		newString = Replacer.simpleReplace(newString, "POS_LoadPivotFile", "Positions.posLoadPivotFile");

		newString = Replacer.simpleReplace(newString, "POS_PageSetReturnT", "Positions.posPageSetReturnT");

		newString = Replacer.simpleReplace(newString, "POS_Pivot", "Positions.posPivot");

		newString = Replacer.simpleReplace(newString, "POS_QueryDetails", "Positions.posQueryDetails");

		newString = Replacer.simpleReplace(newString, "POS_QueryMasterDetails", "Positions.posQueryMasterDetails");

		newString = Replacer.simpleReplace(newString, "POS_RemoveRTPESubject", "Positions.posRemoveRTPESubject");

		newString = Replacer.simpleReplace(newString, "POS_RetrieveDrillTable", "Positions.posRetrieveDrillTable");

		newString = Replacer.simpleReplace(newString, "POS_SequenceOutput", "Positions.sequenceOutput");

		newString = Replacer.simpleReplace(newString, "POS_SetLockHideInfoTable", "Positions.posSetLockHideInfoTable");

		newString = Replacer.simpleReplace(newString, "POS_SetMacroContentPivotName",
				"Positions.posSetMacroContentPivotName");

		newString = Replacer.simpleReplace(newString, "POS_SetPageFilterItemContent",
				"Positions.posSetPageFilterItemContent");

		newString = Replacer.simpleReplace(newString, "POS_SetReturnT", "Positions.posSetReturnT");

		newString = Replacer.simpleReplace(newString, "PROCESS_MemorySizeDouble", "SystemUtil.memorySizeDouble");

		newString = Replacer.simpleReplace(newString, "PROCESS_MemorySize", "SystemUtil.memorySize");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_ProdMatrixTable_LoadMatrixAndSetup",
				"ProdServ.productionMatrixProdMatrixTableLoadMatrixAndSetup");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_ProdMatrixTable_Save",
				"ProdServ.productionMatrixProdMatrixTableSave");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_ProdSetupTable_AutoLink",
				"ProdServ.productionMatrixProdSetupTableAutoLink");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_ProdSetupTable_Save",
				"ProdServ.productionMatrixProdSetupTableSave");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_QueryTable_AddFieldId",
				"ProdServ.productionMatrixQueryTableAddFieldId");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_QueryTable_AddOwnerId",
				"ProdServ.productionMatrixQueryTableAddOwnerId");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_QueryTable_AddSellerId",
				"ProdServ.productionMatrixQueryTableAddSellerId");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_QueryTable_AddWellheadId",
				"ProdServ.productionMatrixQueryTableAddWellheadId");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_QueryTable_Create",
				"ProdServ.productionMatrixQueryTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_QueryTable_SetExtSystemId",
				"ProdServ.productionMatrixQueryTableSetExtSystemId");

		newString = Replacer.simpleReplace(newString, "PRODSERV_ProductionMatrix_QueryTable_SetProdMonth",
				"ProdServ.productionMatrixQueryTableSetProdMonth");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsOwnerImbalanceImportTable_Import",
				"ProdServ.psOwnerImbalanceImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsOwnerImbalanceImportTable_Create",
				"ProdServ.psOwnerImbalanceImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityDetailImportTable_Create",
				"ProdServ.psQualityDetailImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityDetailImportTable_Import",
				"ProdServ.psQualityDetailImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityHeaderImportTable_Create",
				"ProdServ.psQualityHeaderImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsQualityHeaderImportTable_Import",
				"ProdServ.psQualityHeaderImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Import",
				"ProdServ.psWellheadComponentImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadCtpImportTable_Create",
				"ProdServ.psWellheadCtpImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadCtpImportTable_Import",
				"ProdServ.psWellheadCtpImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadEntitlementImportTable_Create",
				"ProdServ.psWellheadEntitlementImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadEntitlementImportTable_Import",
				"ProdServ.psWellheadEntitlementImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadImportTable_Create",
				"ProdServ.psWellheadImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadImportTable_Import",
				"ProdServ.psWellheadImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadReservesImportTable_Create",
				"ProdServ.psWellheadReservesImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadReservesImportTable_Import",
				"ProdServ.psWellheadReservesImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadStatusImportTable_Create",
				"ProdServ.psWellheadStatusImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadStatusImportTable_Import",
				"ProdServ.psWellheadStatusImportTableImport");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadVolumeAdjImportTable_Create",
				"ProdServ.psWellheadVolumeAdjImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadVolumeAdjImportTable_Import",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "PRODSERV_PsWellheadComponentImportTable_Create",
				"ProdServ.psWellheadComponentImportTableCreate");

		newString = Replacer.simpleReplace(newString, "TRAN_AddSensitivityTableRow",
				"Transaction.addSensitivityTableRow");

		newString = Replacer.simpleReplace(newString, "TRAN_BookHedgesFromComponentData",
				"Transaction.bookHedgesFromComponentData");

		newString = Replacer.simpleReplace(newString, "TRAN_BookHedgesFromComponentDataByQid",
				"Transaction.bookHedgesFromComponentDataByQid");

		newString = Replacer.simpleReplace(newString, "TRAN_Buyout", "Transaction.buyout");

		newString = Replacer.simpleReplace(newString, "TRAN_Cancel", "Transaction.cancel");

		newString = Replacer.simpleReplace(newString, "TRAN_CancelAlmTranPerpetualTable",
				"Transaction.cancelAlmTranPerpetualTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CancelRollover", "Transaction.cancelRollover");

		newString = Replacer.simpleReplace(newString, "TRAN_ChangeUserInsType", "Services.tranChangeUserInsType");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateActualTable", "Transaction.createActualTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateAlmInsertTable", "Transaction.createAlmInsertTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateCashInsertTable",
				"Transaction.createCashInsertTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateEngyPhysInsertTable",
				"Transaction.createEngyPhysInsertTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateEventInfoTable", "Transaction.createEventInfoTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateFTPInfoTable", "Transaction.createFTPInfoTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateFxInsertTable", "Transaction.createFxInsertTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateMetalForwardInsertTable",
				"Transaction.createMetalForwardInsertTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreatePhysTable", "Transaction.createPhysTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateSensitivityTable",
				"Transaction.createSensitivityTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateSharedTranInsertTable",
				"Transaction.createSharedTranInsertTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateTranfInsStructuredExportTable",
				"Transaction.createTranfInsStructuredExportTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateTranFromTranfTable",
				"Transaction.createTranFromTranfTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateTranfStructuredExportTable",
				"Transaction.createTranfStructuredExportTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateTranInfoTable", "Transaction.createTranInfoTable");

		newString = Replacer.simpleReplace(newString, "TRAN_CreateUserDefinedEventsTable",
				"Transaction.createUserDefinedEventsTable");

		newString = Replacer.simpleReplace(newString, "TRAN_DefaultTranForToolset",
				"Transaction.defaultTranForToolset");

		newString = Replacer.simpleReplace(newString, "TRAN_DefaultTranForUniqueToolset",
				"Transaction.defaultTranForUniqueToolset");

		newString = Replacer.simpleReplace(newString, "TRAN_Delete", "Transaction.delete");

		newString = Replacer.simpleReplace(newString, "TRAN_EventCreate", "Transaction.eventCreate");

		newString = Replacer.simpleReplace(newString, "TRAN_EventDelete", "Transaction.eventDelete");

		newString = Replacer.simpleReplace(newString, "TRAN_EventRetrieveEvents", "Transaction.eventRetrieveEvents");

		newString = Replacer.simpleReplace(newString, "TRAN_EventRetrieveValues", "Transaction.eventRetrieveValues");

		newString = Replacer.simpleReplace(newString, "TRAN_EventUpdate", "Transaction.eventUpdate");

		newString = Replacer.simpleReplace(newString, "TRAN_FixUnfixDerivativeCFlowProjector",
				"Transaction.fixUnfixDerivativeCFlowProjector");

		newString = Replacer.simpleReplace(newString, "TRAN_ForceRepriceQueryID", "Transaction.forceRepriceQueryID");

		newString = Replacer.simpleReplace(newString, "TRAN_FxCancel", "Transaction.fxCancel");

		newString = Replacer.simpleReplace(newString, "TRAN_GenerateInventory", "Transaction.generateInventory");

		newString = Replacer.simpleReplace(newString, "TRAN_GenerateInventoryByQid",
				"Transaction.generateInventoryByQid");

		newString = Replacer.simpleReplace(newString, "TRAN_GenerateInventoryByQuery",
				"Transaction.generateInventoryByQuery");

		newString = Replacer.simpleReplace(newString, "TRAN_GetAllDerivativeInstrumentsFromUnderlyingTranNum",
				"Transaction.getAllDerivativeInstrumentsFromUnderlyingTranNum");

		newString = Replacer.simpleReplace(newString, "TRAN_GetContractUtilization",
				"Transaction.getContractUtilization");

		newString = Replacer.simpleReplace(newString, "TRAN_GetEventAccountSettle",
				"Transaction.getEventAccountSettle");

		newString = Replacer.simpleReplace(newString, "TRAN_GetNewTriggers", "Transaction.getNewTriggers");

		newString = Replacer.simpleReplace(newString, "TRAN_GetQuantityDetails", "Transaction.getQuantityDetails");

		newString = Replacer.simpleReplace(newString, "TRAN_GetQuantityDetailsBySide",
				"Transaction.getQuantityDetailsBySide");

		newString = Replacer.simpleReplace(newString, "TRAN_GetStorageBalanceTableRange",
				"Transaction.getStorageBalanceTableRange");

		newString = Replacer.simpleReplace(newString, "TRAN_GetSwapStubPeriodInfo",
				"Transaction.getSwapStubPeriodInfo");

		newString = Replacer.simpleReplace(newString, "TRAN_GetTranFromIns", "Transaction.getTranFromIns");

		newString = Replacer.simpleReplace(newString, "TRAN_GetTranFromTranArrayN",
				"Transaction.getTranFromTranArrayN");

		newString = Replacer.simpleReplace(newString, "TRAN_ImportTradeFromXML", "Transaction.importTradeFromXML");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertAlmTranPerpetualTable",
				"Transaction.insertAlmTranPerpetualTable");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertCashTranTable", "Transaction.insertCashTranTable");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertEnergyPhysTable",
				"Transaction.insertEnergyPhysTable");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertFxSpotOrForwardTranTable",
				"Transaction.insertFxSpotOrForwardTranTable");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertFxTranTable", "Transaction.insertFxTranTable");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertMetalForwardTranTable",
				"Transaction.insertMetalForwardTranTable");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertSharedTranTable",
				"Transaction.insertSharedTranTable");

		newString = Replacer.simpleReplace(newString, "TRAN_InsertSharedTranTableByStatus",
				"Transaction.insertSharedTranTableByStatus");

		newString = Replacer.simpleReplace(newString, "TRAN_IntegrityCheck", "Transaction.integrityCheck");

		newString = Replacer.simpleReplace(newString, "TRAN_IntegrityCheckTwoTrans",
				"Transaction.integrityCheckTwoTrans");

		newString = Replacer.simpleReplace(newString, "TRAN_IsNull", "Transaction.isNull");

		newString = Replacer.simpleReplace(newString, "TRAN_LoadEventInfo", "Transaction.loadEventInfo");

		newString = Replacer.simpleReplace(newString, "TRAN_Mature", "Transaction.mature");

		newString = Replacer.simpleReplace(newString, "TRAN_OptionExerciseByEvent",
				"Transaction.optionExerciseByEvent");

		newString = Replacer.simpleReplace(newString, "TRAN_OptionExpireByEvent", "Transaction.optionExpireByEvent");

		newString = Replacer.simpleReplace(newString, "TRAN_Post", "Transaction.post");

		newString = Replacer.simpleReplace(newString, "TRAN_ProcessCreditDefault", "Transaction.processCreditDefault");

		newString = Replacer.simpleReplace(newString, "TRAN_ProcessCreditDefault_GetTable",
				"Transaction.processCreditDefaultGetTable");

		newString = Replacer.simpleReplace(newString, "TRAN_ProcessOptionExercise",
				"Transaction.processOptionExercise");

		newString = Replacer.simpleReplace(newString, "TRAN_ProcessOptionExercise_GetTable",
				"Transaction.processOptionExerciseGetTable");

		newString = Replacer.simpleReplace(newString, "TRAN_ProcessPhysDelivery", "Transaction.processPhysDelivery");

		newString = Replacer.simpleReplace(newString, "TRAN_RegeneratePipelineTable",
				"Transaction.regeneratePipelineTable");

		newString = Replacer.simpleReplace(newString, "TRAN_RepoRoll", "Transaction.repoRoll");

		newString = Replacer.simpleReplace(newString, "TRAN_RepoUndoRoll", "Transaction.repoUndoRoll");

		newString = Replacer.simpleReplace(newString, "TRAN_Retrieve", "Transaction.retrieve");

		newString = Replacer.simpleReplace(newString, "TRAN_RetrieveActualInfo", "Transaction.retrieveActualInfo");

		newString = Replacer.simpleReplace(newString, "TRAN_RetrieveBeforeAmended",
				"Transaction.retrieveBeforeAmended");

		newString = Replacer.simpleReplace(newString, "TRAN_RetrieveCopy", "Transaction.retrieveCopy");

		newString = Replacer.simpleReplace(newString, "TRAN_RetrieveTranfInsStructuredFieldInfo",
				"Transaction.retrieveTranfInsStructuredFieldInfo");

		newString = Replacer.simpleReplace(newString, "TRAN_RetrieveTranfStructuredFieldInfo",
				"Transaction.retrieveTranfStructuredFieldInfo");

		newString = Replacer.simpleReplace(newString, "TRAN_RunSecurityPymt", "Transaction.runSecurityPymt");

		newString = Replacer.simpleReplace(newString, "TRAN_SaveEventInfo", "Transaction.saveEventInfo");

		newString = Replacer.simpleReplace(newString, "TRAN_SetStatus", "Transaction.setStatus");

		newString = Replacer.simpleReplace(newString, "TRAN_SettleEventCreate", "Transaction.settleEventCreate");

		newString = Replacer.simpleReplace(newString, "TRAN_SetTranEventSettleAmt",
				"Transaction.setTranEventSettleAmt");

		newString = Replacer.simpleReplace(newString, "TRAN_Split", "Transaction.split");

		newString = Replacer.simpleReplace(newString, "TRAN_UnmatureDeal", "Transaction.unmatureDeal");

		newString = Replacer.simpleReplace(newString, "TRAN_UpdateActualCrSubledger",
				"Transaction.updateActualCrSubledger");

		newString = Replacer.simpleReplace(newString, "TRAN_UpdateActualDrSubledger",
				"Transaction.updateActualDrSubledger");

		newString = Replacer.simpleReplace(newString, "TRAN_UpdateActualInfo", "Transaction.updateActualInfo");

		newString = Replacer.simpleReplace(newString, "TRAN_UpdateActualStatus", "Transaction.updateActualStatus");

		newString = Replacer.simpleReplace(newString, "TRAN_UpdateCommoditySchedulingForDaylightSavings",
				"Transaction.updateCommoditySchedulingForDaylightSavings");

		newString = Replacer.simpleReplace(newString, "TRAN_UpdateTranForFuturesDelivery",
				"Transaction.updateTranForFuturesDelivery");

		newString = Replacer.simpleReplace(newString, "TRAN_VerifySettlementInstructionsForTranNum",
				"Transaction.verifySettlementInstructionsForTranNum");

		newString = Replacer.simpleReplace(newString, "TRANF_DUMP_OutputCSVFile", "Transaction.tranfDUMPOutputCSVFile");

		newString = Replacer.simpleReplace(newString, "TRANF_DUMP_OutputCSVTable",
				"Transaction.tranfDUMPOutputCSVTable");

		newString = Replacer.simpleReplace(newString, "TRANF_DUMP_Query", "Transaction.tranfDUMPQuery");

		newString = Replacer.simpleReplace(newString, "TRANF_ExportDeals", "Transaction.exportDeals");

		newString = Replacer.simpleReplace(newString, "TRANF_ImportDeals", "Transaction.importDeals");

		newString = Replacer.simpleReplace(newString, "TRANF_ImportDeals_given_tablenames",
				"Transaction.importDealsGivenTablenames");

		newString = Replacer.simpleReplace(newString, "TRANF_ImportPowerDeal", "Transaction.importPowerDeal");

		newString = Replacer.simpleReplace(newString, "TRANF_SetFieldBatch", "Transaction.tranfSetFieldBatch");

		newString = Replacer.simpleReplace(newString, "TRAN_GetAllUserData", "TradeMaint.tranGetAllUserData");

		newString = Replacer.simpleReplace(newString, "TRAN_GetDealRanks", "GasScheduling.getDealRanks");

		newString = Replacer.simpleReplace(newString, "TRAN_GetTranListFromIndexEx",
				"Index.tranGetTranListFromIndexEx");

		newString = Replacer.simpleReplace(newString, "TRAN_GetUserDataDouble", "TradeMaint.tranGetUserDataDouble");

		newString = Replacer.simpleReplace(newString, "TRAN_GetUserDataInt", "TradeMaint.tranGetUserDataInt");

		newString = Replacer.simpleReplace(newString, "TRAN_GetUserDataString", "TradeMaint.tranGetUserDataString");

		newString = Replacer.simpleReplace(newString, "TRAN_GetUserDataTable", "TradeMaint.tranGetUserDataTable");

		newString = Replacer.simpleReplace(newString, "TRAN_SetUserDataDouble", "TradeMaint.tranSetUserDataDouble");

		newString = Replacer.simpleReplace(newString, "TRAN_SetUserDataInt", "TradeMaint.tranSetUserDataInt");

		newString = Replacer.simpleReplace(newString, "TRAN_SetUserDataString", "TradeMaint.tranSetUserDataString");

		newString = Replacer.simpleReplace(newString, "TRAN_SetUserDataTable", "TradeMaint.tranSetUserDataTable");

		newString = Replacer.simpleReplace(newString, "TRAN_ViewTransaction", "TradeMaint.tranViewTransaction");

		newString = Replacer.simpleReplace(newString, "TRANF_FuncDataNew", "TranFieldData.tranfFuncDataNew");

		newString = Replacer.simpleReplace(newString, "TRAN_SetDealRanks", "GasScheduling.setDealRanks");

		newString = Replacer.simpleReplace(newString, "TRAN_INFO_UserTable_RetrieveByTranNum",
				"TranInfoUserTable.retrieveByTranNum");

		newString = Replacer.simpleReplace(newString, "TRAN_INFO_UserTable_SaveForTranNum",
				"TranInfoUserTable.saveForTranNum");

		newString = Replacer.simpleReplace(newString, "TRAN_Purge", "DataMaint.tranPurge");

		newString = Replacer.simpleReplace(newString, "TRAN_QuickCreditCheck", "Credit.tranQuickCreditCheck");

		if (newString.contains("TRAN_IsNull")) {
			do {
				tableObjectName = newString.replace("TRAN_IsNull", "Transaction.isNull");
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("TRAN_IsNull"));
		}
		if (newString.contains("TRAN_GetInsFromTran")) {
			do {
				temp = newString.substring(newString.indexOf("TRAN_GetInsFromTran"), newString.length());
				temp = temp.substring(temp.indexOf("TRAN_GetInsFromTran"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
				tableObjectName = tableObjectName + ".getInsFromTran()";
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("TRAN_GetInsFromTran"));
		}
		if (newString.contains("INS_IsNull")) {
			do {
				tableObjectName = newString.replace("INS_IsNull", "Instrument.isNull");
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("INS_IsNull"));
		}
		if (newString.contains("TRAN_Destroy")) {
			do {
				temp = newString.substring(newString.indexOf("TRAN_Destroy"), newString.length());
				temp = temp.substring(temp.indexOf("TRAN_Destroy"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
				tableObjectName = tableObjectName + ".destroy()";
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("TRAN_Destroy"));
		}
		if (newString.contains("INS_PrepareForPricing")) {
			do {
				temp = newString.substring(newString.indexOf("INS_PrepareForPricing"), newString.length());
				temp = temp.substring(temp.indexOf("INS_PrepareForPricing"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
				tableObjectName = tableObjectName + ".prepareForPricing()";
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("INS_PrepareForPricing"));
		}
		if (newString.contains("INS_ResetToTable")) {
			do {
				temp = newString.substring(newString.indexOf("INS_ResetToTable"), newString.length());
				temp = temp.substring(temp.indexOf("INS_ResetToTable"), temp.indexOf(")") + 1);
				tableObjectName = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
				tableObjectName = tableObjectName + ".resetToTable()";
				tableObjectName = newString.replace(temp, tableObjectName);
				returnString = tableObjectName;
				newString = tableObjectName;
			} while (newString.contains("INS_ResetToTable"));
		}

		if (newString.contains("TRAN_AddDealDocument")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_AddDealDocument"));
			temp = newString.substring(newString.indexOf("TRAN_AddDealDocument"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_AddSide")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_AddSide"));
			temp = newString.substring(newString.indexOf("TRAN_AddSide"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_AddTrigger")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_AddTrigger"));
			temp = newString.substring(newString.indexOf("TRAN_AddTrigger"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_AddUserDefinedEvents")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_AddUserDefinedEvents"));
			temp = newString.substring(newString.indexOf("TRAN_AddUserDefinedEvents"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_AuthorizeSharedIns")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_AuthorizeSharedIns"));
			temp = newString.substring(newString.indexOf("TRAN_AuthorizeSharedIns"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_BondYieldToMaturity")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_BondYieldToMaturity"));
			temp = newString.substring(newString.indexOf("TRAN_BondYieldToMaturity"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_CalculateSensitivities")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_CalculateSensitivities"));
			temp = newString.substring(newString.indexOf("TRAN_CalculateSensitivities"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_ConvertDealToLocationPricing")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_ConvertDealToLocationPricing"));
			temp = newString.substring(newString.indexOf("TRAN_ConvertDealToLocationPricing"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_ConvertLTPToCommodity")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_ConvertLTPToCommodity"));
			temp = newString.substring(newString.indexOf("TRAN_ConvertLTPToCommodity"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_CreateExportTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_CreateExportTable"));
			temp = newString.substring(newString.indexOf("TRAN_CreateExportTable"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_DeleteDealComment")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_DeleteDealComment"));
			temp = newString.substring(newString.indexOf("TRAN_DeleteDealComment"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_DeleteDealDocument")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_DeleteDealDocument"));
			temp = newString.substring(newString.indexOf("TRAN_DeleteDealDocument"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_DeletePricingVolumeAdjustment")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_DeletePricingVolumeAdjustment"));
			temp = newString.substring(newString.indexOf("TRAN_DeletePricingVolumeAdjustment"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_DeleteSide")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_DeleteSide"));
			temp = newString.substring(newString.indexOf("TRAN_DeleteSide"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_DeleteTranScheduleDetail")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_DeleteTranScheduleDetail"));
			temp = newString.substring(newString.indexOf("TRAN_DeleteTranScheduleDetail"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_DeleteTrigger")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_DeleteTrigger"));
			temp = newString.substring(newString.indexOf("TRAN_DeleteTrigger"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_FeeDeleteFee")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_FeeDeleteFee"));
			temp = newString.substring(newString.indexOf("TRAN_FeeDeleteFee"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_FeeInsertFee")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_FeeInsertFee"));
			temp = newString.substring(newString.indexOf("TRAN_FeeInsertFee"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_FillHourlyTSDTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_FillHourlyTSDTable"));
			temp = newString.substring(newString.indexOf("TRAN_FillHourlyTSDTable"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GenerateComponentHedge")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GenerateComponentHedge"));
			temp = newString.substring(newString.indexOf("TRAN_GenerateComponentHedge"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetCommodityTotalDailyVolume")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetCommodityTotalDailyVolume"));
			temp = newString.substring(newString.indexOf("TRAN_GetCommodityTotalDailyVolume"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_GetCommodityTotalTriggeredVolume")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetCommodityTotalTriggeredVolume"));
			temp = newString.substring(newString.indexOf("TRAN_GetCommodityTotalTriggeredVolume"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetCTLDealConnection")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetCTLDealConnection"));
			temp = newString.substring(newString.indexOf("TRAN_GetCTLDealConnection"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_GetDailyVolumePricingDetails")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetDailyVolumePricingDetails"));
			temp = newString.substring(newString.indexOf("TRAN_GetDailyVolumePricingDetails"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetFirstSeqNum")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetFirstSeqNum"));
			temp = newString.substring(newString.indexOf("TRAN_GetFirstSeqNum"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_GetGasScheduledFlag")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetGasScheduledFlag"));
			temp = newString.substring(newString.indexOf("TRAN_GetGasScheduledFlag"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetNewTriggersByTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetNewTriggersByTran"));
			temp = newString.substring(newString.indexOf("TRAN_GetNewTriggersByTran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetNumRows")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetNumRows"));
			temp = newString.substring(newString.indexOf("TRAN_GetNumRows"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetPricingDetails")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetPricingDetails"));
			temp = newString.substring(newString.indexOf("TRAN_GetPricingDetails"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetPricingDetailsForEvents")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetPricingDetailsForEvents"));
			temp = newString.substring(newString.indexOf("TRAN_GetPricingDetailsForEvents"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetPricingVolumeAdjSeqNum")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetPricingVolumeAdjSeqNum"));
			temp = newString.substring(newString.indexOf("TRAN_GetPricingVolumeAdjSeqNum"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetProvisional")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetProvisional"));
			temp = newString.substring(newString.indexOf("TRAN_GetProvisional"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetQuantityDetailsBySideForTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetQuantityDetailsBySideForTran"));
			temp = newString.substring(newString.indexOf("TRAN_GetQuantityDetailsBySideForTran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetStorageBalanceToDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetStorageBalanceToDate"));
			temp = newString.substring(newString.indexOf("TRAN_GetStorageBalanceToDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_GetTableOfKeepWholeResults")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetTableOfKeepWholeResults"));
			temp = newString.substring(newString.indexOf("TRAN_GetTableOfKeepWholeResults"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_GetTableOfKeepWholeResultsRange")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetTableOfKeepWholeResultsRange"));
			temp = newString.substring(newString.indexOf("TRAN_GetTableOfKeepWholeResultsRange"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_GetTranfTableFromTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetTranfTableFromTran"));
			temp = newString.substring(newString.indexOf("TRAN_GetTranfTableFromTran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_GetTriggerContractDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetTriggerContractDate"));
			temp = newString.substring(newString.indexOf("TRAN_GetTriggerContractDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_GetUnderlyingTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_GetUnderlyingTran"));
			temp = newString.substring(newString.indexOf("TRAN_GetUnderlyingTran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_HedgeAddTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_HedgeAddTran"));
			temp = newString.substring(newString.indexOf("TRAN_HedgeAddTran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_InsertDealComment")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_InsertDealComment"));
			temp = newString.substring(newString.indexOf("TRAN_InsertDealComment"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_InsertPricingVolumeAdjustment")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_InsertPricingVolumeAdjustment"));
			temp = newString.substring(newString.indexOf("TRAN_InsertPricingVolumeAdjustment"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_NeutralizeInsPrice")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_NeutralizeInsPrice"));
			temp = newString.substring(newString.indexOf("TRAN_NeutralizeInsPrice"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_PPAGetPaymentDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_PPAGetPaymentDate"));
			temp = newString.substring(newString.indexOf("TRAN_PPAGetPaymentDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_PPASetPaymentDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_PPASetPaymentDate"));
			temp = newString.substring(newString.indexOf("TRAN_PPASetPaymentDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_ProcessBuyout")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_ProcessBuyout"));
			temp = newString.substring(newString.indexOf("TRAN_ProcessBuyout"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_RefreshModelInputs")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_RefreshModelInputs"));
			temp = newString.substring(newString.indexOf("TRAN_RefreshModelInputs"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_SaveDeliveryTickets")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SaveDeliveryTickets"));
			temp = newString.substring(newString.indexOf("TRAN_SaveDeliveryTickets"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SaveProvisional")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SaveProvisional"));
			temp = newString.substring(newString.indexOf("TRAN_SaveProvisional"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SaveTranInfo")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SaveTranInfo"));
			temp = newString.substring(newString.indexOf("TRAN_SaveTranInfo"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SaveTranScheduleDetails")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SaveTranScheduleDetails"));
			temp = newString.substring(newString.indexOf("TRAN_SaveTranScheduleDetails"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetComponentTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetComponentTable"));
			temp = newString.substring(newString.indexOf("TRAN_SetComponentTable"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetCTLDealConnection")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetCTLDealConnection"));
			temp = newString.substring(newString.indexOf("TRAN_SetCTLDealConnection"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetExternalBunit")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetExternalBunit"));
			temp = newString.substring(newString.indexOf("TRAN_SetExternalBunit"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetExternalLentity")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetExternalLentity"));
			temp = newString.substring(newString.indexOf("TRAN_SetExternalLentity"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetExternalPortfolio")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetExternalPortfolio"));
			temp = newString.substring(newString.indexOf("TRAN_SetExternalPortfolio"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetGasScheduledFlag")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetGasScheduledFlag"));
			temp = newString.substring(newString.indexOf("TRAN_SetGasScheduledFlag"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetInternalBunit")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetInternalBunit"));
			temp = newString.substring(newString.indexOf("TRAN_SetInternalBunit"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetInternalLentity")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetInternalLentity"));
			temp = newString.substring(newString.indexOf("TRAN_SetInternalLentity"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetInternalPortfolio")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetInternalPortfolio"));
			temp = newString.substring(newString.indexOf("TRAN_SetInternalPortfolio"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetMaturityDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetMaturityDate"));
			temp = newString.substring(newString.indexOf("TRAN_SetMaturityDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetPosition")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetPosition"));
			temp = newString.substring(newString.indexOf("TRAN_SetPosition"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetPrice")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetPrice"));
			temp = newString.substring(newString.indexOf("TRAN_SetPrice"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetPricingVolumeAdjustmentDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetPricingVolumeAdjustmentDate"));
			temp = newString.substring(newString.indexOf("TRAN_SetPricingVolumeAdjustmentDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetPricingVolumeAdjustmentVolume")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetPricingVolumeAdjustmentVolume"));
			temp = newString.substring(newString.indexOf("TRAN_SetPricingVolumeAdjustmentVolume"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetProvisional")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetProvisional"));
			temp = newString.substring(newString.indexOf("TRAN_SetProvisional"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetSettleDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetSettleDate"));
			temp = newString.substring(newString.indexOf("TRAN_SetSettleDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetStartDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetStartDate"));
			temp = newString.substring(newString.indexOf("TRAN_SetStartDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetTranInfoUserTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetTranInfoUserTable"));
			temp = newString.substring(newString.indexOf("TRAN_SetTranInfoUserTable"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetTranModifiedStatus")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetTranModifiedStatus"));
			temp = newString.substring(newString.indexOf("TRAN_SetTranModifiedStatus"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetTranType")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetTranType"));
			temp = newString.substring(newString.indexOf("TRAN_SetTranType"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetTranInfoUserTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetTranInfoUserTable"));
			temp = newString.substring(newString.indexOf("TRAN_SetTranInfoUserTable"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetTranModifiedStatus")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetTranModifiedStatus"));
			temp = newString.substring(newString.indexOf("TRAN_SetTranModifiedStatus"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetUnderlyingTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetUnderlyingTran"));
			temp = newString.substring(newString.indexOf("TRAN_SetUnderlyingTran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SetUnderlyingTranOnComOptFut")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SetUnderlyingTranOnComOptFut"));
			temp = newString.substring(newString.indexOf("TRAN_SetUnderlyingTranOnComOptFut"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SimpleBuyout")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SimpleBuyout"));
			temp = newString.substring(newString.indexOf("TRAN_SimpleBuyout"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_SplitKeepWhole")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_SplitKeepWhole"));
			temp = newString.substring(newString.indexOf("TRAN_SplitKeepWhole"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_StructSecSetInsInfo")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_StructSecSetInsInfo"));
			temp = newString.substring(newString.indexOf("TRAN_StructSecSetInsInfo"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRAN_UnsetGasScheduledFlag")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_UnsetGasScheduledFlag"));
			temp = newString.substring(newString.indexOf("TRAN_UnsetGasScheduledFlag"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRAN_UpdateTlinkDealNums")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_UpdateTlinkDealNums"));
			temp = newString.substring(newString.indexOf("TRAN_UpdateTlinkDealNums"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRANF_DUMP_Tran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_DUMP_Tran"));
			temp = newString.substring(newString.indexOf("TRANF_DUMP_Tran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataCopy")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataCopy"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataCopy"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRANF_FuncDataInit")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataInit"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataInit"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataSetETag")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataSetETag"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataSetETag"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataSetField")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataSetField"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataSetField"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataSetGroup")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataSetGroup"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataSetGroup"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataSetLevel")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataSetLevel"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataSetLevel"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataSetName")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataSetName"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataSetName"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataSetTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataSetTran"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataSetTran"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_FuncDataUnsetField")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataUnsetField"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataUnsetField"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRANF_FuncDataUnsetLevel")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_FuncDataUnsetLevel"));
			temp = newString.substring(newString.indexOf("TRANF_FuncDataUnsetLevel"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TRANF_GetField")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetField"));
			temp = newString.substring(newString.indexOf("TRANF_GetField"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GetFieldComponent")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetFieldComponent"));
			temp = newString.substring(newString.indexOf("TRANF_GetFieldComponent"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GetFieldDouble")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetFieldDouble"));
			temp = newString.substring(newString.indexOf("TRANF_GetFieldDouble"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GetFieldDoubleComponent")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetFieldDoubleComponent"));
			temp = newString.substring(newString.indexOf("TRANF_GetFieldDoubleComponent"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GetFieldInt")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetFieldInt"));
			temp = newString.substring(newString.indexOf("TRANF_GetFieldInt"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GetFieldIntComponent")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetFieldIntComponent"));
			temp = newString.substring(newString.indexOf("TRANF_GetFieldIntComponent"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GetFieldTable")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetFieldTable"));
			temp = newString.substring(newString.indexOf("TRANF_GetFieldTable"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GetFieldTableComponent")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GetFieldTableComponent"));
			temp = newString.substring(newString.indexOf("TRANF_GetFieldTableComponent"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_GroupAdd")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_GroupAdd"));
			temp = newString.substring(newString.indexOf("TRANF_GroupAdd"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_SetField")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_SetField"));
			temp = newString.substring(newString.indexOf("TRANF_SetField"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("TRANF_SetFieldComponent")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRANF_SetFieldComponent"));
			temp = newString.substring(newString.indexOf("TRANF_SetFieldComponent"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_AddConfiguration")) {

			tableObjectName = newString.substring(newString.indexOf("REVAL_AddConfiguration"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_AddConfiguration"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;

		}
		if (newString.contains("REVAL_AddMapping")) {

			tableObjectName = newString.substring(newString.indexOf("REVAL_AddMapping"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_AddMapping"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_AddTransaction")) {
			tableObjectName = newString.substring(0, newString.indexOf("REVAL_AddTransaction"));
			temp = newString.substring(newString.indexOf("REVAL_AddTransaction"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_ComputeResults")) {
			tableObjectName = newString.substring(0, newString.indexOf("REVAL_ComputeResults"));
			temp = newString.substring(newString.indexOf("REVAL_ComputeResults"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_EnableVolumetricSens")) {
			tableObjectName = newString.substring(0, newString.indexOf("REVAL_EnableVolumetricSens"));
			temp = newString.substring(newString.indexOf("REVAL_EnableVolumetricSens"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_GenerateVaRGptShockVector")) {
			tableObjectName = newString.substring(0, newString.indexOf("REVAL_GenerateVaRGptShockVector"));
			temp = newString.substring(newString.indexOf("REVAL_GenerateVaRGptShockVector"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_RemoveConfigurations")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_RemoveConfigurations"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_RemoveConfigurations"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_RemoveMappings")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_RemoveMappings"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_RemoveMappings"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_RemoveTransaction")) {
			tableObjectName = newString.substring(0, newString.indexOf("REVAL_RemoveTransaction"));
			temp = newString.substring(newString.indexOf("REVAL_RemoveTransaction"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetBMO")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetBMO"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetBMO"), tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetCurrency")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetCurrency"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetCurrency"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonDate")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetHorizonDate"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetHorizonDate"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonEODBODFlag")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetHorizonEODBODFlag"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetHorizonEODBODFlag"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonHistoricalDate")) {
			tableObjectName = newString.substring(0, newString.indexOf("REVAL_SetHorizonHistoricalDate"));
			temp = newString.substring(newString.indexOf("REVAL_SetHorizonHistoricalDate"), newString.length());

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonHistPriceDateMode")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetHorizonHistPriceDateMode"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetHorizonHistPriceDateMode"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonPricingMethodMode")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetHorizonPricingMethodMode"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetHorizonPricingMethodMode"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonPVDateMode")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetHorizonPVDateMode"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetHorizonPVDateMode"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonResetDate")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetHorizonResetDate"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetHorizonResetDate"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetHorizonRollMarketData")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetHorizonRollMarketData"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetHorizonRollMarketData"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetMarketPrices")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetMarketPrices"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetMarketPrices"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetTransactions")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetTransactions"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetTransactions"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetTransactionsFromQuery")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetTransactionsFromQuery"),
					newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetTransactionsFromQuery"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_SetVaRDefinition")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_SetVaRDefinition"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_SetVaRDefinition"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_ShockVaRGridPoints")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_ShockVaRGridPoints"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_ShockVaRGridPoints"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_UseMarketPriceIndexes")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_UseMarketPriceIndexes"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_UseMarketPriceIndexes"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("REVAL_UseMarketPrices")) {
			tableObjectName = newString.substring(newString.indexOf("REVAL_UseMarketPrices"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("REVAL_UseMarketPrices"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}
		if (newString.contains("TABLE_PivotByConfig")) {
			tableObjectName = newString.substring(newString.indexOf("TABLE_PivotByConfig"), newString.length());
			temp = tableObjectName.substring(tableObjectName.indexOf("TABLE_PivotByConfig"),
					tableObjectName.indexOf(")") + 1);

			returnString = newString.replace(temp, Replacer.convertindexCall(temp));
			newString = returnString;
		}

		if (newString.contains("print")) {
			tableObjectName = "OConsole.oprint( "
					+ newString.substring(newString.indexOf("(") + 1, newString.indexOf(";") + 1);
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_DrillGetNumCellEntrieN")) {
			tableObjectName = newString.replace("TABLE_DrillGetNumCellEntries", "Positions.drillGetNumCellEntries");
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_AddDealComment")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".addDealComment();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_Copy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".copy();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_CreatePhysDeliveryUnscheduledRecord")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".createPhysDeliveryUnscheduledRecord();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_Destroy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".destroy();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TRAN_DestroyComponentTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".destroyComponentTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_FixComponentData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fixComponentData();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_FlipBuySell")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".flipBuySell();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_ForceReprice")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".forceReprice();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetAuxiliaryTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getAuxiliaryTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetBrokerFeeTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getBrokerFeeTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetComponentTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getComponentTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetDealDocumentTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getDealDocumentTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetDefaultBuyoutTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getDefaultBuyoutTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetExternalBunit")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getExternalBunit();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetExternalLentity")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getExternalLentity();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetExternalPortfolio")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getExternalPortfolio();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetHedgeTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getHedgeTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetHoldingTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getHoldingTran();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetInsFromTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getInsFromTran();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetInsSubType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getInsSubType();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetInsType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getInsType();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetInternalBunit")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getInternalBunit();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetInternalLentity")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getInternalLentity();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetInternalPortfolio")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getInternalPortfolio();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetMaturityDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getMaturityDate();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetModelInputs")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getModelInputs();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetNumParams")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getNumParams();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetPhysTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getPhysTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetPosition")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getPosition();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetPrice")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getPrice();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetSettleDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getSettleDate();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetSettlementInstructionsTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getSettlementInstructionsTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetSettlementTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getSettlementTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetStartDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getStartDate();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetStoragePricingDetails")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getStoragePricingDetails();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetTranInfo")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTranInfo();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetTranModifiedStatus")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTranModifiedStatus();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetTranNum")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTranNum();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetTranType")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTranType();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_GetTriggerDataDiffTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getTriggerDataDiffTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_LoadDealComments")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".loadDealComments();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_LoadDefaultSettlementInstructions")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".loadDefaultSettlementInstructions();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_PPAResetPaymentDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".pPAResetPaymentDate();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_PPASetPaymentDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".getMaturityDate();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_PricingFormulaVarTableClear")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".pricingFormulaVarTableClear();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_PricingFormulaVarTableDisable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".pricingFormulaVarTableDisable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_PricingFormulaVarTableEnable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".pricingFormulaVarTableEnable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_PricingFormulaVarTableGet")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".pricingFormulaVarTableGet();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_ReinsertWithVolumeAndPricing")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".reinsertWithVolumeAndPricing();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_RestorePrevTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".restorePrevTran();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_RetrieveBeforeModified")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".retrieveBeforeModified();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_SaveDealComments")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".saveDealComments();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_SuppressPrintTicket")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".suppressPrintTicket();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_SuppressViewTicket")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".suppressViewTicket();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_TaxApplicableRates")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".taxApplicableRates();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRAN_VerifySettlementInstructions")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".verifySettlementInstructions();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRANF_FuncDataDestroy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".destroy();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRANF_FuncDataUnsetGroup")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".unsetGroup();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRANF_FuncDataUnsetName")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".unsetName();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TRANF_FuncDataUnsetTran")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".unsetTran();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("REVAL_CalcCorrelations")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".calcCorrelations();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REVAL_CalcIndexes")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".calcIndexes();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REVAL_CalcVolatilities")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".calcVolatilities();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REVAL_ClearHorizonDate")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".clearHorizonDate();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("REVAL_Destroy")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".destroy();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("REVAL_DetachResultTable")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".detachResultTable();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("REVAL_FillTransactionData")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
					+ ".fillTransactionData();";
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("TABLE_InsertColN")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".insertCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;

		}

		if (newString.contains("TABLE_InsertCol")) {
			tableObjectName = newString.substring(newString.indexOf("(") + 1, newString.indexOf(",")).trim();
			tableObjectName = tableObjectName + ".insertCol("
					+ newString.substring(newString.indexOf(",") + 1, newString.indexOf(";") + 1).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}
		if (newString.contains("TRAN_RestoreTran")) {
			tableObjectName = newString.substring(0, newString.indexOf("TRAN_RestoreTran"));
			temp = newString.substring(newString.indexOf("TRAN_RestoreTran"), newString.length());
			tableObjectName += temp.substring(temp.indexOf("(") + 1, temp.indexOf(",")).trim() + ".restoreTran("
					+ temp.substring(temp.indexOf(",") + 1, temp.length()).trim();
			returnString = tableObjectName;
			newString = tableObjectName;
		}

		if (newString.contains("REVAL_GetBMO")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetBMO\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetBMO", ".getBMO"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim() + ".getBMO();";

		}

		if (newString.contains("REVAL_GetConfigurations")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetConfigurations\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetConfigurations", ".getConfigurations"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getConfigurations();";

		}

		if (newString.contains("REVAL_GetCorrelations")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetCorrelations\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetCorrelations", ".getCorrelations"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getCorrelations();";

		}

		if (newString.contains("REVAL_GetCurrency")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetCurrency\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetCurrency", ".getCurrency"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getCurrency();";

		}

		if (newString.contains("REVAL_GetHorizonDate")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonDate\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonDate", ".getHorizonDate"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getHorizonDate();";

		}

		if (newString.contains("REVAL_GetHorizonEODBODFlag")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonEODBODFlag\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonEODBODFlag",
									".getHorizonEODBODFlag"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getHorizonEODBODFlag();";

		}

		if (newString.contains("REVAL_GetHorizonHistoricalDate")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonHistoricalDate\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonHistoricalDate",
									".getHorizonHistoricalDate"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getHorizonHistoricalDate();";

		}

		if (newString.contains("REVAL_GetHorizonHistPriceDateMode")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonHistPriceDateMode\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonHistPriceDateMode",
									".getHorizonHistPriceDateMode"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getHorizonHistPriceDateMode();";

		}

		if (newString.contains("REVAL_GetHorizonPricingMethodMode")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonPricingMethodMode\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonPricingMethodMode",
									".getHorizonPricingMethodMode"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getHorizonPricingMethodMode();";

		}

		if (newString.contains("REVAL_GetHorizonPVDateMode")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonPVDateMode\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonPVDateMode",
									".REVAL_GetHorizonPVDateMode"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".REVAL_GetHorizonPVDateMode();";

		}

		if (newString.contains("REVAL_GetHorizonResetDate")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonResetDate\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonResetDate",
									".getHorizonResetDate"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getHorizonResetDate();";

		}

		if (newString.contains("REVAL_GetHorizonRollMarketData")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetHorizonRollMarketData\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetHorizonRollMarketData",
									".getHorizonRollMarketData"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getHorizonRollMarketData();";

		}

		if (newString.contains("REVAL_GetIndexes")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetIndexes\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetIndexes", ".getIndexes"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim() + ".getIndexes();";

		}

		if (newString.contains("REVAL_GetMappings")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetMappings\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetMappings", ".getMappings"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getMappings();";

		}

		if (newString.contains("REVAL_GetMarketPrices")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetMarketPrices\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetMarketPrices", ".getMarketPrices"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getMarketPrices();";

		}

		if (newString.contains("REVAL_GetTransactions")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetTransactions\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetTransactions", ".GetTransactions"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".GetTransactions();";

		}

		if (newString.contains("REVAL_GetVaRDefinition")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetVaRDefinition\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetVaRDefinition", ".getVaRDefinition"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getVaRDefinition();";

		}

		if (newString.contains("REVAL_GetVolatilities")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_GetVolatilities\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_GetVolatilities", ".getVolatilities"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".getVolatilities();";

		}

		if (newString.contains("REVAL_IsUsingMarketPriceIndexes")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_IsUsingMarketPriceIndexes\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_IsUsingMarketPriceIndexes",
									".isUsingMarketPriceIndexes"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".isUsingMarketPriceIndexes();";

		}

		if (newString.contains("REVAL_IsUsingMarketPrices")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_IsUsingMarketPrices\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_IsUsingMarketPrices",
									".isUsingMarketPrices"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".isUsingMarketPrices();";

		}

		if (newString.contains("REVAL_IsVolumetricSensEnabled")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_IsVolumetricSensEnabled\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_IsVolumetricSensEnabled",
									".isVolumetricSensEnabled"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".isVolumetricSensEnabled();";

		}

		if (newString.contains("REVAL_PrepareForRun")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_PrepareForRun\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_PrepareForRun", ".prepareForRun"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".prepareForRun();";

		}

		if (newString.contains("REVAL_RefreshVaRGptData")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_RefreshVaRGptData\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_RefreshVaRGptData", ".refreshVaRGptData"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".refreshVaRGptData();";

		}

		if (newString.contains("REVAL_ResetVaRRandomSeed")) {
			boolean hasConditionBlock = newString.contains("if") || newString.contains("while");

			newString = hasConditionBlock
					? newString.replaceFirst("REVAL_ResetVaRRandomSeed\\([^)]*\\)",
							Replacer.convertFunctionCall(newString, "REVAL_ResetVaRRandomSeed", ".resetVaRRandomSeed"))
					: newString.substring(newString.indexOf("(") + 1, newString.indexOf(")")).trim()
							+ ".resetVaRRandomSeed();";

		}
		return newString;
	}

}
