/**************************************************************************************************
VERSION : 1.0

CLASS NAME : AVS_Code_Pattern

PURPOSE : THIS CLASS WILL SERVE AS A BASE FOR PARSING CODE AND FINDING WHETHER A GIVEN LINE OF CODE IS
VARIABLE DECLARATION,FUNCTION DECLARATION/DEFENATION,VOID MAIN

AUTHOR : RAHUL SHAH

DATE : 4-APR-2012
 ***************************************************************************************************/
package com.tools.migrator;
import java.util.regex.Pattern;

public class AVS_Code_Pattern {

	private final String VARIABLE_PATTERN = "^[A-Za-z]{3,8}+([' ']+)*+([A-Za-z0-9_,' '-]+)+(\\,+)*+([' ']+)*+(\\=)*+([' ']+)*+(\\()*+(\")*+([A-Za-z0-9_''' '.-/]+)*+(\\,+)*+(\")*+(\\))*+(\\;)$";
	private final String VOID_MAIN_PATTERN = "^([' ']+)*+[voidmant' ']+(\\()+(\\))+([' ']+)*+(\\{)*$";
	private final String FUNCTION_PATTERN = "^[A-Za-z]{3,8}+([' ']+)*+([A-Za-z0-9_]+)+(\\()+([' ']+)*+([A-Za-z0-9_' ',]+)*+(\\,)*+(\\))+([' ']+)*+(\\{)*$";
	private final String FUNCTION_DECLARATION_PATTERN = "^[A-Za-z]{3,8}+([' ']+)*+([A-Za-z0-9_]+)+(\\()+([' ']+)*+([A-Za-z0-9_' ',]+)*+(\\,)*+(\\))+([' ']+)*+(\\;)$";

	public Pattern patternFunction = null;
	public Pattern patternVariable = null;
	public Pattern patternVoidMain = null;
	public Pattern patternFunctionDeclaration = null;

	/**
	 * @param DEFAULT CONSTRUCTOR
	 */
	public AVS_Code_Pattern() {
		patternFunction = Pattern.compile(FUNCTION_PATTERN);
		patternVariable = Pattern.compile(VARIABLE_PATTERN);
		patternVoidMain = Pattern.compile(VOID_MAIN_PATTERN);
		patternFunctionDeclaration = Pattern.compile(FUNCTION_DECLARATION_PATTERN);

	}

	/**
	 * @param String CHECKS WHETHER GIVEN STRING IS VOID MAIN()
	 * @return boolean
	 */

	public boolean isMethodVoidMain(String codeLine) {

		return patternVoidMain.matcher(codeLine).matches();
	}

	/**
	 * @param String CHECKS WHETHER GIVEN STRING IS VARIABLE DECLARATION
	 * @return boolean
	 */
	public boolean isVariableDeclaration(String codeLine) {
		boolean result = false;
		String s = codeLine.trim();
		if (s.contains(" ")) {
			String dataType = s.substring(0, s.indexOf(' '));

			if (!checkValidDataType(dataType)) {
				return false;
			}
		}
		if (!s.contains(";")) {
			return false;
		}
		if (s.contains("[") && s.contains("]")) {
			if (s.contains("()")) {
				return false;
			}
		}
		if (!s.contains("[") && !s.contains("]")) {
			if (s.contains("(") || s.contains(")")) {
				if (!s.contains("=")) {
					return false;
				}

			}
		}
		if (!s.contains("[") && !s.contains("]")) {
			if (s.contains("(") && s.contains(")")) {
				if (s.contains("=") && s.contains(";")) {
					return true;
				}

			}
		}
		if (s.contains("=") && s.contains(";")) {
			return true;
		}
		s = s.substring(0, s.indexOf(";") + 1);

		result = patternVariable.matcher(s).matches();

		return result;
	}

	/**
	 * @param String CHECKS WHETHER GIVEN STRING IS METHOD DEFINITION
	 * @return boolean
	 */
	public boolean isMethodDefinition(String codeLine) {
		boolean result = false;
		String s = codeLine.trim(), returnType, newLine;
		;

		if (s.contains(" ")) {
			returnType = s.substring(0, s.indexOf(' '));

			if (!checkValidDataTypeForFunction(returnType)) {
				return false;
			}
		} else {
			return false;
		}

		if (!(s.contains("(")) & !(s.contains(")"))) {
			return false;
		}
		if (s.contains("=")) {
			return false;
		}
		if (s.contains(";")) {
			return false;
		}
		newLine = returnType + " " + s.substring(returnType.length() + 1, s.indexOf("(")).trim();
		s = newLine + s.substring(s.indexOf("("), s.indexOf(")") + 1);
		result = patternFunction.matcher(s).matches();

		return result;
	}

	/**
	 * @param String CHECKS WHETHER GIVEN STRING IS METHOD DECLARATION
	 * @return boolean
	 */

	public boolean isMethodDeclaration(String codeLine) {

		boolean result = false;
		String s = codeLine.trim(), returnType, newLine;

		if (s.contains(" ")) {
			returnType = s.substring(0, s.indexOf(' '));

			if (!checkValidDataTypeForFunction(returnType)) {
				return false;
			}
		} else {
			return false;
		}

		if (!(s.contains("(")) || !(s.contains(")"))) {
			return false;
		}
		if (s.contains("=")) {
			return false;
		}
		if (!s.contains(";")) {
			return false;
		}

		newLine = returnType + " " + s.substring(returnType.length() + 1, s.indexOf("(")).trim();
		s = newLine + s.substring(s.indexOf("("), s.indexOf(";") + 1);

		s = s.substring(0, s.indexOf(";") + 1);

		result = patternFunctionDeclaration.matcher(s).matches();

		return result;
	}

	/**
	 * @param String CHECKS WHETHER GIVEN STRING IS A VALID DATA TYPE FOR VARIABLE
	 *               DECLARATION
	 * @return boolean
	 */
	public boolean checkValidDataType(String s) {
		if (s.equals("int") || s.equals("string") || s.equals("double") || s.equals("TablePtr")) {
			return true;
		}
		return false;
	}

	/**
	 * @param String CHECKS WHETHER GIVEN STRING IS A VALID DATA TYPE FOR FUNCTION
	 *               DECLARATION/DEFINITION
	 * @return boolean
	 */
	public boolean checkValidDataTypeForFunction(String s) {
		if (s.equals("int") || s.equals("string") || s.equals("double") || s.equals("TablePtr") || s.equals("void")) {
			return true;
		}
		return false;
	}
}
