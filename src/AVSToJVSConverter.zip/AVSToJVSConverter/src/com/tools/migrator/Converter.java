package com.tools.migrator;
import java.io.BufferedWriter;
import java.io.File;
//import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Properties;
import java.util.Scanner;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

public class Converter {

	String actualCodeLine = "";
	String codeLine = null;
	boolean voidMainFound = false;
	boolean commentedcodeflag = true;
	// boolean startClassBody = true;
	boolean startClassBody;
	StringBuffer convertedCode = null;
	Properties props = null;
	AVS_Code_Pattern acPattern = null;

	public Converter() {
		acPattern = new AVS_Code_Pattern();
	}

	public String convert(File file) throws Exception {

		String avsFileName = file.getAbsolutePath();
		// StrTokenizer javaFileNameTokens = new StrTokenizer(avsFileName, '\\');
		// String classNameArr[] = javaFileNameTokens.getTokenArray();
		// String className = StringUtils.replace(classNameArr[classNameArr.length - 1],
		// ".mls", "").trim();
		String splitter = File.separator.replace("\\", "\\\\");
		String classNameArr[] = avsFileName.split(splitter);
		String className = classNameArr[classNameArr.length - 1];
		className = className.replace(".mls", "");

		File fFile = file;
		Scanner scanner = new Scanner(new FileReader(fFile));
		startClassBody = true;
		convertedCode = new StringBuffer();
		convertedCode.append("\n/*Disclaimer:");
		convertedCode.append("\n  This Code is Converted using AVS - JVS Accenture Proprietary tool*/");
		convertedCode.append("\n");
		while (scanner.hasNextLine()) {
			// convertedCode.append("\n");
			codeLine = scanner.nextLine().trim();
			System.out.println("code Line is ---->" + codeLine + "\n");
			if (codeLine.equals("")) {
				continue;
			}
			if (codeLine.startsWith("//")) {
				convertedCode.append("\n");
				convertedCode.append(codeLine);
				continue;
			}
			// Start - This peace of code will check whether given line is comment or not
			// if it is a multiple line comment it will not be send for further processing
			if (codeLine.startsWith("/*")) {
				commentedcodeflag = true;
				if (codeLine.endsWith("*/")) {
					commentedcodeflag = false;
					convertedCode.append("\n");
					convertedCode.append(codeLine);
					continue;
				} else {
					convertedCode.append("\n");
					convertedCode.append(codeLine);
					while (commentedcodeflag) {
						while (scanner.hasNextLine()) {
							codeLine = scanner.nextLine().trim();
							if (codeLine.endsWith("*/")) {
								commentedcodeflag = false;
								convertedCode.append("\n");
								convertedCode.append(codeLine);
								break;
							} else {
								convertedCode.append("\n");
								convertedCode.append(codeLine);
							}
						}
					}
				}
				continue;
			} // End of checking commented code

			// Start - This peace of code will check if a single logical code is on multiple
			// line
			// it will be appended in a single line before sending for further processing
			if (codeLine.endsWith(")") || codeLine.endsWith("{") || codeLine.endsWith(";")
					|| codeLine.startsWith("#include") || codeLine.contains(";") || codeLine.contains("}")
					|| codeLine.contains("//") || codeLine.equals("end:") || codeLine.equals("goto end;")
					|| codeLine.equals("EXIT_SCRIPT:")) {
				// Do Nothing
			} else {
				while (scanner.hasNextLine()) {
					codeLine += " " + scanner.nextLine().trim();
					if (codeLine.endsWith(")") || codeLine.endsWith("{") || codeLine.endsWith(";")
							|| codeLine.contains(";") || codeLine.contains("}") || codeLine.contains("//")) {
						break;
					}
				}
			} // End

			// System.out.println(codeLine);//for testing purpose if it is getting hung for
			// any specific line
			if (codeLine.startsWith("#include")) {
				convertedCode.append("\n");
				convertedCode.append(codeLine);
				continue;
			}
			if ((startClassBody && codeLine.length() > 0)) {
				convertedCode.append("\n");
				convertedCode.append("public class ");
				convertedCode.append(className);
				convertedCode.append(" implements IScript { ");
				convertedCode.append("\n");
				startClassBody = false;
			}
			if (acPattern.isVariableDeclaration(codeLine)) {
				// System.out.println("VARIABLE DEFINITION");
				codeLine = Replacer.replaceDataType(codeLine);// will
//				codeLine=Replacer.replacecoreFunctionCall(codeLine);//will replace all key //Ankit uncommented line
				codeLine = AVSJVSReplacerOne.replacecoreFunctionCall(codeLine);
				// words in function body
				// replace only data type
				convertedCode.append("\n");
				convertedCode.append(codeLine);
			} else if (acPattern.isMethodDeclaration(codeLine)) {
				// System.out.println("METHOD DECLARATION FOUND");
				continue;// will exclude as in object oriented language we don't have function
							// declaration
			} else if (acPattern.isMethodVoidMain(codeLine)) {
				// System.out.println("VOID MAIN FOUND");
				codeLine = Replacer.replaceVoidmain(codeLine);
				convertedCode.append("\n");
				convertedCode.append(codeLine);
			} else if (acPattern.isMethodDefinition(codeLine)) {
				// System.out.println("METHOD DEFINITION FOUND");
				codeLine = Replacer.replaceDataType(codeLine);// will replace only data type
				codeLine = codeLine + " throws OException";
				convertedCode.append("\n");
				convertedCode.append(codeLine);
			} else {
//				codeLine = Replacer.replacecoreFunctionCall(codeLine);// will replace all key words in function body
				codeLine = AVSJVSReplacerOne.replacecoreFunctionCall(codeLine);
				convertedCode.append("\n");
				convertedCode.append(codeLine);
			}

		}
		convertedCode.append("\n");
		convertedCode.append("}");
		String finalCode = convertedCode.toString().trim();
		System.out.println(finalCode);

		String selectedFilePath = fFile.getParent();

		String savedFilePath = selectedFilePath + "\\jvsOutput\\";// + className +".java";
		BufferedWriter out;
		boolean exists = (new File("savedFilePath")).exists();
		if (exists) {
			// File or directory exists
			out = new BufferedWriter(new FileWriter(savedFilePath + className + ".java"));
		} else {
			// File or directory does not exist
			new File(savedFilePath).mkdirs();
			out = new BufferedWriter(new FileWriter(savedFilePath + className + ".java"));
		}

		out.write(finalCode);
		out.close();
		scanner.close();
		convertedCode = null;
		actualCodeLine = null;
		fFile = null;
		file = null;
		return finalCode;
	}

	public String getAVSCodeAsString(File file) throws Exception {

		StringBuffer buffer = new StringBuffer();
		Scanner scanner = new Scanner(new FileReader(file));
		while (scanner.hasNextLine()) {
			String codeLine = scanner.nextLine();
			buffer.append(codeLine + "\n");
		}
		scanner.close();
		return buffer.toString();
	}
	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		String path = "K:/Development/WorkDir/chetan.srivastava-b/V11Jars/mUTIL_Adhoc_MatureDeals.mls";
//		File file = new File(path);
//		Converter converter = new Converter();
//		try {
//			converter.convert(file);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

}
