package com.tools.migrator;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FilenameFilter;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

//import org.dyno.visual.swing.layouts.Constraints;
//import org.dyno.visual.swing.layouts.GroupLayout;
//import org.dyno.visual.swing.layouts.Leading;

//VS4E -- DO NOT REMOVE THIS LINE!
public class MainWindow extends JFrame implements ActionListener {

	Converter converter = null;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel1;
	private JLabel jLabel0;
	private JButton jConvertBtn;
	private JTextArea jTextArea0;
	private JScrollPane jScrollPane1;
	private JTextArea jTextArea1;
	private JScrollPane jScrollPane2;
	private JButton jBrowseBtn;
	private File file = null;
	private JButton jBrowseFolderBtn;
	private static final String PREFERRED_LOOK_AND_FEEL = "javax.swing.plaf.metal.MetalLookAndFeel";
	private boolean convertMultipleFile = false;
	File[] selectedAVSFile = null;

	public MainWindow() {
		initComponents();
		converter = new Converter();
	}

	private void initComponents() {
		setTitle("AVS TO JVS CONVERTER");
		setResizable(false);
//		setLayout(new GroupLayout());
//		add(getJLabel1(), new Constraints(new Leading(695, 10, 10), new Leading(35, 12, 12)));
//		add(getJButton0(), new Constraints(new Leading(413, 12, 12), new Leading(88, 10, 10)));
//		add(getJLabel0(), new Constraints(new Leading(141, 76, 10, 10), new Leading(35, 12, 12)));
//		add(getJScrollPane2(), new Constraints(new Leading(510, 413, 10, 10), new Leading(57, 488, 12, 12)));
////		add(getJButton2(), new Constraints(new Leading(684, 10, 10), new Leading(550, 12, 12)));
//		add(getJScrollPane1(), new Constraints(new Leading(15, 392, 12, 12), new Leading(58, 486, 10, 10)));
//		add(getJButton3(), new Constraints(new Leading(225, 10, 10), new Leading(551, 12, 12)));
//		add(getJButton1(), new Constraints(new Leading(59, 128, 10, 10), new Leading(550, 12, 12)));
		// Test
		setLayout(new FlowLayout());
		add(getJLabel0());
		add(getJScrollPane1());
		add(getJLabel1());
		add(getJScrollPane2());
//		add(getJButton2(), new Constraints(new Leading(684, 10, 10), new Leading(550, 12, 12)));
		add(getJButton3());
		add(getJButton1());
		add(getJButton0());
		// Test
		setSize(946, 590);
		jBrowseBtn.setActionCommand("BrowseAction");
		jConvertBtn.setActionCommand("ConvertAction");
//		jButton2.setActionCommand("JB2");
		jBrowseFolderBtn.setActionCommand("BrowseFolderAction");
		jConvertBtn.addActionListener(this);
		jBrowseBtn.addActionListener(this);
//		jButton2.addActionListener(this);
		jBrowseFolderBtn.addActionListener(this);
	}

	private JButton getJButton3() {
		if (jBrowseFolderBtn == null) {
			jBrowseFolderBtn = new JButton();
			jBrowseFolderBtn.setText("BROWSE FOLDER");
		}
		return jBrowseFolderBtn;
	}

	/*
	 * private JButton getJButton2() { if (jButton2 == null) { jButton2 = new
	 * JButton(); jButton2.setText("SAVE AS"); } return jButton2; }
	 */

	private JButton getJButton1() {
		if (jBrowseBtn == null) {
			jBrowseBtn = new JButton();
			jBrowseBtn.setText("BROWSE FILE");
		}
		return jBrowseBtn;
	}

	private JScrollPane getJScrollPane2() {
		if (jScrollPane2 == null) {
			jScrollPane2 = new JScrollPane();
			jScrollPane2.setViewportView(getJTextArea1());
		}
		return jScrollPane2;
	}

	private JTextArea getJTextArea1() {
		if (jTextArea1 == null) {
			jTextArea1 = new JTextArea(30, 40);
		}
		return jTextArea1;
	}

	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setViewportView(getJTextArea0());
		}
		return jScrollPane1;
	}

	private JTextArea getJTextArea0() {
		if (jTextArea0 == null) {
			jTextArea0 = new JTextArea(30, 40);
		}
		return jTextArea0;
	}

	private JButton getJButton0() {
		if (jConvertBtn == null) {
			jConvertBtn = new JButton();
			jConvertBtn.setText("CONVERT");
		}
		return jConvertBtn;
	}

	private JLabel getJLabel0() {
		if (jLabel0 == null) {
			jLabel0 = new JLabel();
			jLabel0.setText("AVS FILES / CODE");
		}
		return jLabel0;
	}

	private JLabel getJLabel1() {
		if (jLabel1 == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("OUTPUT");
		}
		return jLabel1;
	}

	private static void installLnF() {
		try {
			String lnfClassname = PREFERRED_LOOK_AND_FEEL;
			// if (lnfClassname == null)
			// lnfClassname = UIManager.getCrossPlatformLookAndFeelClassName();
			UIManager.setLookAndFeel(lnfClassname);
		} catch (Exception e) {
			System.err.println("Cannot install " + PREFERRED_LOOK_AND_FEEL + " on this platform:" + e.getMessage());
		}
	}

	/**
	 * Main entry of the class. Note: This class is only created so that you can
	 * easily preview the result at runtime. It is not expected to be managed by the
	 * designer. You can modify it as you like.
	 */
	public static void main(String[] args) {
		installLnF();

		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				MainWindow frame = new MainWindow();
				frame.setDefaultCloseOperation(MainWindow.EXIT_ON_CLOSE);
				frame.setTitle("MainWindow");
				frame.getContentPane().setPreferredSize(frame.getSize());
				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
		});
	}

	public void actionPerformed(ActionEvent arg0) {

		String actionCommand = arg0.getActionCommand();

		if (actionCommand.equals("BrowseAction")) {
			try {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.showOpenDialog(this);
				file = fileChooser.getSelectedFile();
				System.out.println(file.getAbsolutePath() + file.isDirectory());
				String code = converter.getAVSCodeAsString(file);
				jTextArea0.setText(code);
				jTextArea1.setText("");
				convertMultipleFile = false;
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (actionCommand.equals("ConvertAction")) {
			try {
				StringBuffer fileListStr = new StringBuffer();
				if (convertMultipleFile && selectedAVSFile != null) {// Handle multiple files
					for (File selectedFile : selectedAVSFile) {
						converter.convert(selectedFile);
						fileListStr.append(getJavaFileName(selectedFile.getPath())).append("\n");
					}
					jTextArea1.setText(fileListStr.toString());
					selectedAVSFile = null;
				} else {// Handle single file
					String convertedCode = converter.convert(file);
					jTextArea1.setText(convertedCode);
					file = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (actionCommand.equals("BrowseFolderAction")) {
			try {
				convertMultipleFile = true;
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				fileChooser.showOpenDialog(this);
				File selectedDirectory = fileChooser.getSelectedFile();
				String selectedDirectoryPath = selectedDirectory.getPath();
				FilenameFilter fileFilter = new FilenameFilter() {
					public boolean accept(File dir, String fileName) {
						boolean fileAccepted = false;
						if (fileName.lastIndexOf(".") > -1) {
							String extension = fileName.substring(fileName.lastIndexOf("."), fileName.length());
							if (".mls".equalsIgnoreCase(extension)) {
								fileAccepted = true;
							}
						}
						return fileAccepted;
					}
				};
				String[] mlsFileList = selectedDirectory.list(fileFilter);
				StringBuffer fileList = new StringBuffer();
				for (String mlsFile : mlsFileList) {
					fileList.append(selectedDirectoryPath).append("\\").append(mlsFile + "\n");
				}
				selectedAVSFile = selectedDirectory.listFiles(fileFilter);
				jTextArea0.setText(fileList.toString());
				jTextArea1.setText("");
			} catch (Exception ex) {
				System.out.println("Exception in actionPerformed " + ex.getMessage());
			}
		}
	}

	private String getJavaFileName(String fileName) {
		String javaFileName = "";
		if (fileName != null) {
			javaFileName = fileName.substring(0, fileName.lastIndexOf("."));
			javaFileName = javaFileName + ".java";
		}
		return javaFileName;
	}

}
