package com.tools.migrator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Arrays;

public class ReplaceCoreFunctionEnumCall {


	public static String ReplaceCoreFunction_EnumCall(String newString) {

	String tableObjectName = "";
	String returnString ="";
	if (newString.contains("COL_TABLE")) {
		tableObjectName = newString.replace("COL_TABLE", "COL_TYPE_ENUM.COL_TABLE");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_STRING")) {
		tableObjectName = newString.replace("COL_STRING", "COL_TYPE_ENUM.COL_STRING");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_INT")) {
		tableObjectName = newString.replace("COL_INT", "COL_TYPE_ENUM.COL_INT");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_DOUBLE")) {
		tableObjectName = newString.replace("COL_DOUBLE", "COL_TYPE_ENUM.COL_DOUBLE");
		returnString = tableObjectName;
		newString = tableObjectName;
	}

	if (newString.contains("COL_INVALID")) {
		tableObjectName = newString.replace("COL_INVALID", "COL_TYPE_ENUM.COL_INVALID");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_PTR")) {
		tableObjectName = newString.replace("COL_PTR", "COL_TYPE_ENUM.COL_PTR");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_INT_ARRAY")) {
		tableObjectName = newString.replace("COL_INT_ARRAY", "COL_TYPE_ENUM.COL_INT_ARRAY");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_DOUBLE_ARRAY")) {
		tableObjectName = newString.replace("COL_DOUBLE_ARRAY", "COL_TYPE_ENUM.COL_DOUBLE_ARRAY");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_STRING_ARRAY")) {
		tableObjectName = newString.replace("COL_STRING_ARRAY", "COL_TYPE_ENUM.COL_STRING_ARRAY");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("ROW_HEADER")) {
		tableObjectName = newString.replace("ROW_HEADER", "COL_TYPE_ENUM.ROW_HEADER");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_HEADER")) {
		tableObjectName = newString.replace("COL_HEADER", "COL_TYPE_ENUM.COL_HEADER");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_ERROR")) {
		tableObjectName = newString.replace("COL_ERROR", "COL_TYPE_ENUM.COL_ERROR");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_DATE_TIME")) {
		tableObjectName = newString.replace("COL_DATE_TIME", "COL_TYPE_ENUM.COL_DATE_TIME");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_BYTE_ARRAY")) {
		tableObjectName = newString.replace("COL_BYTE_ARRAY", "COL_TYPE_ENUM.COL_BYTE_ARRAY");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_TRAN")) {
		tableObjectName = newString.replace("COL_TRAN", "COL_TYPE_ENUM.COL_TRAN");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_IVL_LIST")) {
		tableObjectName = newString.replace("COL_IVL_LIST", "COL_TYPE_ENUM.COL_IVL_LIST");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_SSEL_IVL_LIST")) {
		tableObjectName = newString.replace("COL_SSEL_IVL_LIST", "COL_TYPE_ENUM.COL_SSEL_IVL_LIST");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_MSEL_IVL_LIST")) {
		tableObjectName = newString.replace("COL_MSEL_IVL_LIST", "COL_TYPE_ENUM.COL_MSEL_IVL_LIST");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_DATE_TIME_ARRAY")) {
		tableObjectName = newString.replace("COL_DATE_TIME_ARRAY", "COL_TYPE_ENUM.COL_DATE_TIME_ARRAY");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_CLOB")) {
		tableObjectName = newString.replace("COL_CLOB", "COL_TYPE_ENUM.COL_CLOB");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_DATE")) {
		tableObjectName = newString.replace("COL_DATE", "COL_TYPE_ENUM.COL_DATE");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_XML")) {
		tableObjectName = newString.replace("COL_XML", "COL_TYPE_ENUM.COL_XML");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_HPA")) {
		tableObjectName = newString.replace("COL_HPA", "COL_TYPE_ENUM.COL_HPA");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_UINT")) {
		tableObjectName = newString.replace("COL_UINT", "COL_TYPE_ENUM.COL_UINT");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_CELL")) {
		tableObjectName = newString.replace("COL_CELL", "COL_TYPE_ENUM.COL_CELL");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_INT64")) {
		tableObjectName = newString.replace("COL_INT64", "COL_TYPE_ENUM.COL_INT64");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("COL_UINT64")) {
		tableObjectName = newString.replace("COL_UINT64", "COL_TYPE_ENUM.COL_UINT64");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("NUM_COL_TYPE_ENUM")) {
		tableObjectName = newString.replace("NUM_COL_TYPE_ENUM", "COL_TYPE_ENUM.NUM_COL_TYPE_ENUM");
		returnString = tableObjectName;
		newString = tableObjectName;
	}

	if (newString.contains("ROW_DATA")) {
		tableObjectName = newString.replace("ROW_DATA", "ROW_TYPE_ENUM.ROW_DATA");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("ROW_GROUP_SUM")) {
		tableObjectName = newString.replace("ROW_GROUP_SUM", "ROW_TYPE_ENUM.ROW_GROUP_SUM");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("ROW_TITLE")) {
		tableObjectName = newString.replace("ROW_TITLE", "ROW_TYPE_ENUM.ROW_TITLE");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("ROW_HDR")) {
		tableObjectName = newString.replace("ROW_HDR", "ROW_TYPE_ENUM.ROW_HDR");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("ROW_GROUP_HDR")) {
		tableObjectName = newString.replace("ROW_GROUP_HDR", "ROW_TYPE_ENUM.ROW_GROUP_HDR");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("NUM_ROW_TYPE_ENUM")) {
		tableObjectName = newString.replace("NUM_ROW_TYPE_ENUM", "ROW_TYPE_ENUM.NUM_ROW_TYPE_ENUM");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	//---


	if (newString.contains("BMO_MID")) {
		tableObjectName = newString.replace("BMO_MID", "BMO_ENUMERATION.BMO_MID");
		returnString = tableObjectName;
		newString = tableObjectName;
	}

	if (newString.contains("SCENARIO_TARGET_TYPE")) {
		tableObjectName = newString.replace("SCENARIO_TARGET_TYPE", "SCENARIO_TARGET_TYPE.SCEN_RESULT");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("REVAL_Create")) {
		tableObjectName = newString.replace("REVAL_Create", "Reval.create");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("TRAN_InsertAlmTranPerpetualTable")) {
		tableObjectName = newString.replace("TRAN_InsertAlmTranPerpetualTable", "TRAN_STATUS_ENUM.TRAN_STATUS_TEMPLATE");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("TRAN_STATUS_TEMPLATE")) {
		tableObjectName = newString.replace("TRAN_STATUS_TEMPLATE", "TRAN_STATUS_ENUM.TRAN_STATUS_TEMPLATE");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("STLDOC_ProcessDocs")) {
		tableObjectName = newString.replace("STLDOC_ProcessDocs", "StlDoc.processDocs");
		returnString = tableObjectName;
		newString = tableObjectName;
	}

	if (newString.contains("VaRDefPtr")) {
		tableObjectName = newString.replace("VaRDefPtr", "ValueAtRisk");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("RevalDataPtr")) {
		tableObjectName = newString.replace("RevalDataPtr", "Reval");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("Xstringptr")) {
		tableObjectName = newString.replace("Xstringptr", "Xstring");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	if (newString.contains("HGS_PTR")) {
		tableObjectName = newString.replace("HGS_PTR", "HGasScheduling");
		returnString = tableObjectName;
		newString = tableObjectName;
	}
	//--

//	if (newString.contains("REVAL_")) {
//	 Pattern pattern = Pattern.compile("REVAL_(\\w+)\\(rdata\\)");
//        Matcher matcher = pattern.matcher(newString);
//        StringBuffer result = new StringBuffer();
//
//        while (matcher.find()) {
//            String methodName = matcher.group(1); // Extract the method name
//            String replacement = "rdata." + methodName + "()"; // Build new method call
//            matcher.appendReplacement(result, replacement);
//        }
//
//        matcher.appendTail(result); // Append the rest of the line
//        newString= result.toString();
//	}

return newString;
	}


public static String ReplaceApiCallInsideArguments(String input) {
	// Regex to detect nested API call: word starting with uppercase (API style), inside another call
    String nestedApiRegex = "[,(]\\s*([A-Z0-9]+_[A-Za-z0-9_]+)\\s*\\(";
    Pattern nestedPattern = Pattern.compile(nestedApiRegex);
    Matcher nestedMatcher = nestedPattern.matcher(input);

    // If no nested API call, exit early
    if (!nestedMatcher.find()) {
        return input;
    }
	String regex = "\\b([A-Za-z_][A-Za-z0-9_]*)\\s*\\(([^()]*)\\)";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(input);
    StringBuffer sb = new StringBuffer();

    while (matcher.find()) {
        String funcName = matcher.group(1);
        String args = matcher.group(2).trim();

        // Skip methods that look like normal Java (lowercase start)
        if (Character.isLowerCase(funcName.charAt(0))) {
            matcher.appendReplacement(sb, matcher.group(0));
            continue;
        }

        // Remove common prefixes like REVAL_, API_, FUNC_ etc.
        String cleanFunc = funcName.replaceFirst("^[A-Z0-9]+_", "");

        String replacement;
        if (args.isEmpty()) {
            replacement = cleanFunc + "()";
        } else {
            String[] parts = args.split("\\s*,\\s*");
            String object = parts[0];
            if (parts.length > 1) {
                String rest = String.join(", ", Arrays.copyOfRange(parts, 1, parts.length));
                replacement = object + "." + cleanFunc + "(" + rest + ")";
            } else {
                replacement = object + "." + cleanFunc + "()";
            }
        }

        matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
    }
    matcher.appendTail(sb);

    return sb.toString();
}

//End


}
