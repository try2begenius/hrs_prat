/**************************************************************************************************
VERSION : 1.0

CLASS NAME : Replacer

PURPOSE : THIS CLASS WILL SERVE AS REPLACER FOR ALL KEY WORDS , DATA TYPES

AUTHOR : RAHUL SHAH

DATE : 4-APR-2012
 ***************************************************************************************************/
package com.tools.migrator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Replacer {

	/**
	 * @param String REPLACE VOID MAIN() WITH EXECUTE
	 * @return String
	 */

	public static String replaceVoidmain(String s) {
		String key_value[][] = {
				{ "^([' ']+)*+[voidman' ']+(\\()+(\\))+([' ']+)*+(\\{)*$",
						"public void execute(IContainerContext context) throws OException " },
				{ "^([' ']+)*+[voidmant' ']+(\\()+(\\))+([' ']+)*+(\\{)*$",
						"public int execute(IContainerContext context) throws OException " } };
		String toBeChanged = null;
		toBeChanged = s;
		for (int i = 0; i < key_value.length; i++) {

			Pattern p = Pattern.compile(key_value[i][0]);
			Matcher m = p.matcher(toBeChanged);
			toBeChanged = m.replaceAll(key_value[i][1]);
		}
		return toBeChanged;
	}

	/**
	 * @param String REPLACE AVS DATA TYPE WITH JVS DATA TYPE
	 * @return String
	 */

	public static String replaceDataType(String s) {
		String key_value[][] = { { "int", "int" }, { "string", "String" }, { "double", "double" },
				{ "TablePtr", "Table" }, { "TRUE", "1" }, { "FALSE", "0" }, { "NULL_double", "Util.NULL_double" },
				{ "NULL_String", "Util.NULL_string" }, { "NULL_int", "Util.NULL_int" } };
				//,{ "NULL_TABLE", "Util.NULL_TABLE" }, { "ERROR_InitScriptErrorLog", "Util.errorInitScriptErrorLog" } };
		String toBeChanged = null;
		toBeChanged = s;
		for (int i = 0; i < key_value.length; i++) {

			Pattern p = Pattern.compile(key_value[i][0]);
			Matcher m = p.matcher(toBeChanged);
			toBeChanged = m.replaceAll(key_value[i][1]);
		}
		return toBeChanged;
	}

	public static String simpleReplace(String newString, String target, String replacement) {
	    if (newString.contains(target)) {
	        return newString.replace(target, replacement);
	    }
	    return newString;
	}

	public static String convertindexCall(String temp) {

		String inside = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")")).trim();
		String methodName = temp.substring(temp.indexOf('_') + 1, temp.indexOf('(')).toLowerCase();
	    if (inside.contains(",")) {
	        // Case: two arguments (obj, param)
	        String objectName = inside.substring(0, inside.indexOf(",")).trim();
	        String param = inside.substring(inside.indexOf(",") + 1).trim();
	       // tableObjectName = objectName + ".removeConfigurations(" + param + ")";
	        return objectName + "." + methodName + "(" + param + ")";
	    } else {
	        // Case: one argument (obj)
	        return inside + "." + methodName + "()";
	    }
	}

	public static String convertFunctionCall(String newString, String apiName,String jvsAPIName) {

		int firstParen = newString.indexOf("(");
	    int secondParen = newString.indexOf("(", firstParen + 1);

	    // find the comma after the 2nd '('
	    int commaPos = newString.indexOf(",", secondParen);
		if(commaPos == -1) {
			int closeParen = newString.indexOf(")");
			var tableObjectName = newString.substring(secondParen + 1, closeParen).trim();
		    return tableObjectName + jvsAPIName + "()";
		}
		else {
			// take substring from 2nd '(' up to comma
		    var tableObjectName = newString.substring(secondParen + 1, commaPos).trim();
		 // extract second argument (between comma and ')')
		    String secondArg = newString.substring(newString.indexOf(",") + 1, newString.indexOf(")")).trim();

		    // build replacement call
		    return tableObjectName + jvsAPIName + "(" + secondArg + ")";
		}
	}


}
