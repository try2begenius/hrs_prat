package com.tools.migrator;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class SimpleReplacementRules {

	public static final Map<String, String> RULES;

	static {

		Map<String, String> ruleMap = new LinkedHashMap<>();

		// this replacement are for ReplacementStepTwo2.java file
		ruleMap.put("abs", "Math.abs");
		ruleMap.put("ACCT_AuthorizeFxRateSetById", "Acct.authorizeFxRateSetById");
		ruleMap.put("ACCT_CalculateFxRates", "Acct.calculateFxRates");
		ruleMap.put("ACCT_CreatePostingParametersUploadTable", "Acct.createPostingParametersUploadTable");
		ruleMap.put("ACCT_DefaultCurrencyPairsTable", "Acct.defaultCurrencyPairsTable");
		ruleMap.put("ACCT_DefineManualEntry", "Acct.defineManualEntry");
		ruleMap.put("ACCT_DefineManualEntryR", "Acct.defineManualEntryR");
		ruleMap.put("ACCT_DefinePostingParameter", "Acct.definePostingParameter");
		ruleMap.put("ACCT_DeleteFasHistoryEntry", "Acct.deleteFasHistoryEntry");
		ruleMap.put("ACCT_DelProcessGroup", "Acct.delProcessGroup");
		ruleMap.put("ACCT_DisauthorizeFxRateSetById", "Acct.disauthorizeFxRateSetById");
		ruleMap.put("ACCT_DisplayFxRateMatrixTable", "Acct.displayFxRateMatrixTable");
		ruleMap.put("ACCT_ExportFxRateMemapTable", "Acct.exportFxRateMemapTable");
		ruleMap.put("ACCT_ExportFxRatePairTable", "Acct.exportFxRatePairTable");
		ruleMap.put("ACCT_ExportFxRateSetTable", "Acct.exportFxRateSetTable");
		ruleMap.put("ACCT_ExportHistoricFxRateTable", "Acct.exportHistoricFxRateTable");
		ruleMap.put("ACCT_ForceReverseIncrementalEntry", "Acct.forceReverseIncrementalEntry");
		ruleMap.put("ACCT_GetFxRateSetIdByName", "Acct.getFxRateSetIdByName");
		ruleMap.put("ACCT_GetFxRateSetNameById", "Acct.getFxRateSetNameById");
		ruleMap.put("ACCT_GetSimForDate", "Acct.getSimForDate");
		ruleMap.put("ACCT_GetSystemBaseCurrency", "Acct.getSystemBaseCurrencyId");
		ruleMap.put("ACCT_GetSystemBaseCurrencyN", "Acct.getSystemBaseCurrencyName");
		ruleMap.put("ACCT_ImportFxRateMemap", "Acct.importFxRateMemap");
		ruleMap.put("ACCT_ImportFxRatePairTable", "Acct.importFxRatePairTable");
		ruleMap.put("ACCT_ImportFxRateSetTable", "Acct.importFxRateSetTable");
		ruleMap.put("ACCT_InsertAcctBalanceHistory", "Acct.insertAcctBalanceHistory");
		ruleMap.put("ACCT_InsertFasHistory", "Acct.insertFasHistory");
		ruleMap.put("ACCT_InsertPostingParamInfo", "Acct.insertPostingParamInfo");
		ruleMap.put("ACCT_InsertPostingParamInfoTypes", "Acct.insertPostingParamInfoTypes");
		ruleMap.put("ACCT_InsertPPSEntriesTable", "Acct.insertPPSEntriesTable");
		ruleMap.put("ACCT_InsertPPSEntry", "Acct.insertPPSEntry");
		ruleMap.put("ACCT_InsertProcessGroup", "Acct.insertProcessGroup");
		ruleMap.put("ACCT_InsertSubledgerInfo", "Acct.insertSubledgerInfo");
		ruleMap.put("ACCT_InsertSubledgerInfo", "Acct.insertSubledgerInfoTypes");
		ruleMap.put("ACCT_LockFxRates", "Acct.lockFxRates");
		ruleMap.put("ACCT_ModifyFasHistoryEntry", "Acct.modifyFasHistoryEntry");
		ruleMap.put("ACCT_MoveManEntryStatus", "Acct.moveManEntryStatus");
		ruleMap.put("ACCT_MoveManEntryStatus", "Acct.moveManEntryStatus");
		ruleMap.put("ACCT_NewFxRatePairTable", "Acct.newFxRatePairTable");
		ruleMap.put("ACCT_NewFxRateSetCcyTable", "Acct.newFxRateSetCcyTable");
		ruleMap.put("ACCT_NewFxRateSetTable", "Acct.newFxRateSetTable");
		ruleMap.put("ACCT_PostManualEntries", "Acct.postManualEntries");
		ruleMap.put("ACCT_PostManualEntriesForDate", "Acct.postManualEntriesForDate");
		ruleMap.put("ACCT_PostManualEntriesForDate", "Acct.postManualEntriesForDate");
		ruleMap.put("ACCT_RecastBalanceHistory", "Acct.recastBalanceHistory");
		ruleMap.put("ACCT_RecastBalanceHistory", "Acct.recastBalanceHistory");
		ruleMap.put("ACCT_RemoveOrphanedPPSEntries", "Acct.removeOrphanedPPSEntries");
		ruleMap.put("ACCT_ReverseFasHistory", "Acct.reverseFasHistory");
		ruleMap.put("ACCT_SwitchEvent_Criteria", "Acct.switchEventCriteria");
		ruleMap.put("ACCT_SwitchEvent_Criteria", "Acct.switchEventCriteria");
		ruleMap.put("ACCT_UnlockFxRates", "Acct.unlockFxRates");
		ruleMap.put("ACCT_UpdateFasHistoryProcessFlag", "Acct.updateFasHistoryProcessFlag");
		ruleMap.put("ACCT_UpdatePPSEntryTable", "Acct.updatePPSEntryTable");
		ruleMap.put("ACCT_UpdatePPSSentToGL", "Acct.updatePPSSentToGL");
		ruleMap.put("ACCT_UploadFxRates", "Acct.uploadFxRates");
		ruleMap.put("ACCT_UploadPostingParameters", "Acct.uploadPostingParameters");
		ruleMap.put("AFE_CreateServiceRequestArgTable", "Afe.createServiceRequestArgTable");
		ruleMap.put("AFE_IssueServiceRequestByID", "Afe.issueServiceRequestByID");
		ruleMap.put("AFE_IssueServiceRequestByName", "Afe.issueServiceRequestByName");
		ruleMap.put("AFE_IssueServiceRequestWithTableArg", "Afe.issueServiceRequestWithTableArg");
		ruleMap.put("AFS_CopyAllUserFiles", "Afe.copyAllUserFiles");
		ruleMap.put("AFS_CopyUserFile", "Afe.copyUserFile");
		ruleMap.put("AFS_CreateLink", "Afe.createLink");
		ruleMap.put("AFS_DeleteAllUserFiles", "Afe.deleteAllUserFiles");
		ruleMap.put("AFS_DeleteFileNames", "Afe.deleteFileNames");
		ruleMap.put("AFS_DeleteTable", "Afe.deleteTable");
		ruleMap.put("AFS_DeleteUserFile", "Afe.deleteUserFile");
		ruleMap.put("AFS_RetrieveTable", "Afe.retrieveTable");
		ruleMap.put("AFS_SaveTable", "Afe.saveTable");
		ruleMap.put("ALERT_ChangeStatusAlert", "Broadcast.alertChangeStatusAlert");
		ruleMap.put("ALERT_CloseForAllAlert", "Broadcast.alertCloseForAllAlert");
		ruleMap.put("ALERT_CreateNewAlert", "Broadcast.alertCreateNewAlert");
		ruleMap.put("ALERT_GetReceiverGroups", "Broadcast.alertGetReceiverGroups");
		ruleMap.put("ALERT_GetReceivers", "Broadcast.alertGetReceivers");
		ruleMap.put("ALERT_GetReceivers", "Broadcast.alertGetReceivers");
		ruleMap.put("ALERT_ProcessPendingAlerts", "Broadcast.alertProcessPendingAlerts");
		ruleMap.put("ANE_GetNextMessage", "Ane.getNextMessage");
		ruleMap.put("ANE_ProcessNextMessage", "Ane.processNextMessage");
		ruleMap.put("ANE_PruneMessageQueue", "Ane.pruneMessageQueue");
		ruleMap.put("ARCHIVE_ArchiveDB", "DataMaint.archiveDB");
		ruleMap.put("ARCHIVE_IsOperationValid", "DataMaint.isOperationValid");



		// Sting keyword replacements
		ruleMap.put("STR_Concat", "Str.concat");
		ruleMap.put("STR_Copy", "Str.copy");
		ruleMap.put("STR_Count", "Str.count");
		ruleMap.put("STR_DoubleToStr", "Str.doubleToStr");
		ruleMap.put("STR_Field", "Str.field");
	    ruleMap.put("STR_IsNull", "Str.isNull");
	    ruleMap.put("STR_FormatAs128th", "Str.formatAs128th");
	    ruleMap.put("STR_FormatAs64th", "Str.formatAs64th");
	    ruleMap.put("STR_FormatAs32nd", "Str.formatAs32nd");
	    ruleMap.put("STR_FindLastSubString", "Str.findLastSubString");
	    ruleMap.put("STR_FixSqlStr", "DBase.fixSqlStr");
	    ruleMap.put("STR_FormatAsBps", "Str.formatAsBps");
	    ruleMap.put("STR_FormatAsDouble", "Str.formatAsDouble");
	    ruleMap.put("STR_FormatAsNotnl", "Str.formatAsNotnl");
	    ruleMap.put("STR_FormatAsNotnlAcct", "Str.formatAsNotnlAcct");
	    ruleMap.put("STR_FormatAsNotnlCcy", "Str.formatAsNotnlCcy");
	    ruleMap.put("STR_FormatAsPercent", "Str.formatAsPercent");
	    ruleMap.put("STR_FormatAsPymtPeriod", "Str.formatAsPymtPeriod");
	    ruleMap.put("STR_FormatAsRate", "Str.formatAsRate");
	    ruleMap.put("STR_InputAs128th", "Str.inputAs128th");
	    ruleMap.put("STR_InputAs64th", "Str.inputAs64th");
	    ruleMap.put("STR_InputAs32nd", "Str.inputAs32nd");
	    ruleMap.put("STR_InputAsBps", "Str.inputAsBps");
	    ruleMap.put("STR_InputAsDouble", "Str.inputAsDouble");
	    ruleMap.put("STR_InputAsNotnl", "Str.inputAsNotnl");
	    ruleMap.put("STR_InputAsPymtPeriod", "Str.inputAsPymtPeriod");
	    ruleMap.put("STR_InputAsRate", "Str.inputAsRate");
	    ruleMap.put("STR_IsDouble", "Str.isDouble");
	    ruleMap.put("STR_New", "Str.strNew");
	    ruleMap.put("STR_PureString", "Str.pureString");
	    ruleMap.put("STR_ReadFromFile", "Str.readFromFile");
	    ruleMap.put("STR_StrDateTimeToDate", "ODateTime.strDateTimeToDate");
	    ruleMap.put("STR_StrDateTimeToTime", "ODateTime.strDateTimeToTime");
	    ruleMap.put("STR_StrToDouble", "Str.strToDouble");

	    //Nom Keywords
	    ruleMap.put("NOM_AllocateMeasurementVolumes", "GasScheduling.allocateMeasurementVolumes");
	    ruleMap.put("NOM_BookingAddICDeliveryRow", "NomCreate.addICDeliveryRow");
	    ruleMap.put("NOM_BookingAddICReceiptRow", "NomCreate.addICReceiptRow");
	    ruleMap.put("NOM_BookingAddInventoryDeliveryRow", "NomCreate.addInventoryDeliveryRow");
	    ruleMap.put("NOM_BookingAddInventoryReceiptRow", "NomCreate.addInventoryReceiptRow");
	    ruleMap.put("NOM_BookingAddPSIDeliveryRow", "NomCreate.addPSIDeliveryRow");
	    ruleMap.put("NOM_BookingAddPSIReceiptRow", "NomCreate.addPSIReceiptRow");
	    ruleMap.put("NOM_BookingAddPurchaseRow", "NomCreate.addPurchaseRow");
	    ruleMap.put("NOM_BookingAddSaleRow", "NomCreate.addSaleRow");
	    ruleMap.put("NOM_BookingAddTransitDeliveryRow", "NomCreate.addTransitDeliveryRow");
	    ruleMap.put("NOM_BookingAddTransitReceiptRow", "NomCreate.addTransitReceiptRow");
	    ruleMap.put("NOM_BookingAttachPathingTable", "NomCreate.attachPathingTable");
	    ruleMap.put("NOM_BookingCreateCommSchedData", "NomCreate.createCommSchedData");
	    ruleMap.put("NOM_BookingCreateData", "NomCreate.createData");
	    ruleMap.put("NOM_BookingDestroyData", "NomCreate.Destroy");
	    ruleMap.put("NOM_BookingSetDealGrouping", "NomCreate.setDealGrouping");
	    ruleMap.put("NOM_Create", "Nomination.create");


	 // VOL replacements
	    ruleMap.put("VOL_AddOptimizationIns", "Volatility.addOptimizationIns");
	    ruleMap.put("VOL_CalcCor", "Volatility.calcCor");
	    ruleMap.put("VOL_CalcVol", "Volatility.calcVol");
	    ruleMap.put("VOL_CalibrateBlackScholesVolatilities", "Volatility.calibrateBlackScholesVolatilities");
	    ruleMap.put("VOL_CalibrateBlackScholesVolatilitiesFromTable", "Volatility.calibrateBlackScholesVolatilitiesFromTable");
	    ruleMap.put("VOL_CreateOptimizationTable", "Volatility.createOptimizationTable");
	    ruleMap.put("VOL_DefaultKeysTableForVol", "Volatility.defaultKeysTableForVol");
	    ruleMap.put("VOL_ExportVolCorData", "Volatility.exportVolCorData");
	    ruleMap.put("VOL_ExportVolCorDefs", "Volatility.exportVolCorDefs");
	    ruleMap.put("VOL_GetCorData", "Volatility.getCorData");
	    ruleMap.put("VOL_GetVolData", "Volatility.getVolData");
	    ruleMap.put("VOL_ImportVolCorData", "Volatility.importVolCorData");
	    ruleMap.put("VOL_ImportVolCorDefs", "Volatility.importVolCorDefs");
	    ruleMap.put("VOL_ListAllCorrelations", "Volatility.listAllCorrelations");
	    ruleMap.put("VOL_ListAllVolShadows", "Volatility.listAllVolShadows");
	    ruleMap.put("VOL_LoadClose", "Volatility.loadClose");
	    ruleMap.put("VOL_LoadCloseCorsForIndexes", "Volatility.loadCloseCorsForIndexes");
	    ruleMap.put("VOL_LoadCloseVolsForIndexes", "Volatility.loadCloseVolsForIndexes");
	    ruleMap.put("VOL_LoadCorClose", "Volatility.loadCorClose");
	    ruleMap.put("VOL_LoadCorUniversal", "Volatility.loadCorUniversal");
	    ruleMap.put("VOL_LoadUniversal", "Volatility.loadUniversal");
	    ruleMap.put("VOL_LoadUniversalCorsForIndexes", "Volatility.loadUniversalCorsForIndexes");
	    ruleMap.put("VOL_LoadUniversalVolsForIndexes", "Volatility.loadUniversalVolsForIndexes");
	    ruleMap.put("VOL_OptimizeParam", "Volatility.optimizeParam");
	    ruleMap.put("VOL_OptimizeParamFixedAlpha", "Volatility.optimizeParamFixedAlpha");
	    ruleMap.put("VOL_OutputTableForVol", "Volatility.outputTableForVol");
	    ruleMap.put("VOL_RemoveBidOfferData", "Volatility.removeBidOfferData");
	    ruleMap.put("VOL_Rename", "Volatility.rename");
	    ruleMap.put("VOL_SaveClose", "Volatility.saveClose");
	    ruleMap.put("VOL_SaveCorClose", "Volatility.saveCorClose");
	    ruleMap.put("VOL_SaveCorUniversal", "Volatility.saveCorUniversal");
	    ruleMap.put("VOL_SaveUniversal", "Volatility.saveUniversal");
	    ruleMap.put("VOL_UpdateCorData", "Volatility.updateCorData");
	    ruleMap.put("VOL_UpdateVolData", "Volatility.updateVolData");

	 // WFLOW replacements
	    ruleMap.put("WFLOW_GetExecutionLog", "Workflow.getExecutionLog");
	    ruleMap.put("WFLOW_GetStatus", "Workflow.getStatus");
	    ruleMap.put("WFLOW_GetStatusAll", "Workflow.getStatusAll");
	    ruleMap.put("WFLOW_PingRunSite", "Workflow.pingRunSite");
	    ruleMap.put("WFLOW_StartWorkflow", "Workflow.startWorkflow");
	    ruleMap.put("WFLOW_StopWorkflow", "Workflow.stopWorkflow");

	    // Misc / Ankit
	    ruleMap.put("verify_error_log_table", "Transaction.verifyerrorLogTable");
	    ruleMap.put("VERSION_Compare", "Util.versionCompare");

	    // UTIL replacements
	    ruleMap.put("UTIL_GetEnergyConversionFactors", "Transaction.utilGetEnergyConversionFactors");
	    ruleMap.put("UTIL_GetHourlyEnergyConversionFactors", "Transaction.utilGetHourlyEnergyConversionFactors");
	    ruleMap.put("UTIL_GetHeatRateConversionFactors", "Util.utilGetHeatRateConversionFactors");
	    ruleMap.put("UTIL_GetHourlyHeatRateConversionFactors", "Util.utilGetHourlyHeatRateConversionFactors");
	    ruleMap.put("UTIL_GetUnitTypeFromUnit", "Util.utilGetUnitTypeFromUnit");
	    ruleMap.put("UTIL_LicenseReview", "Util.utilLicenseReview");
	    ruleMap.put("UTIL_RefreshCache", "Util.utilRefreshCache");
	    ruleMap.put("UTIL_RefreshClientPickListCache", "Util.utilRefreshClientPickListCache");
	    ruleMap.put("UTIL_RefreshIndexCache", "Util.utilRefreshIndexCache");
	    ruleMap.put("UTIL_RefreshIndexDataCache", "Util.utilRefreshIndexDataCache");
	    ruleMap.put("UTIL_RefreshSharedMemoryGlobally", "Util.utilRefreshSharedMemoryGlobally");
	    ruleMap.put("UTIL_RefreshSharedMemoryLocally", "Util.utilRefreshSharedMemoryLocally");
	    ruleMap.put("UTIL_RefreshSharedMemorySynchronously", "Util.utilRefreshSharedMemorySynchronously");
	    ruleMap.put("UTIL_RefreshVolatilityCache", "Util.utilRefreshVolatilityCache");
	    ruleMap.put("UTIL_SaveEnergyConversionFactors", "Transaction.utilSaveEnergyConversionFactors");

	 // USER Keywords
	    ruleMap.put("USER_CACHE_Clear", "UserCache.clear");
	    ruleMap.put("USER_CACHE_Get", "UserCache.get");
	    ruleMap.put("USER_CACHE_SetError", "UserCache.setError");
	    ruleMap.put("USER_DATA_WORKSHEET_FillProperties", "Ref.userDATAWORKSHEETFillProperties");
	    ruleMap.put("USER_DATA_WORKSHEET_GetAuxiliaryData", "Ref.userDATAWORKSHEETGetAuxiliaryData");
	    ruleMap.put("USER_DATA_WORKSHEET_GetCallbackAction", "Ref.userDATAWORKSHEETGetCallbackAction");
	    ruleMap.put("USER_DATA_WORKSHEET_GetCallbackCol", "Ref.userDATAWORKSHEETGetCallbackCol");
	    ruleMap.put("USER_DATA_WORKSHEET_GetCallbackEvent", "Ref.userDATAWORKSHEETGetCallbackEvent");
	    ruleMap.put("USER_DATA_WORKSHEET_GetCallbackRow", "Ref.userDATAWORKSHEETGetCallbackRow");
	    ruleMap.put("USER_DATA_WORKSHEET_GetColKey", "Ref.userDATAWORKSHEETGetColKey");
	    ruleMap.put("USER_DATA_WORKSHEET_GetColReadOnly", "Ref.userDATAWORKSHEETGetColReadOnly");
	    ruleMap.put("USER_DATA_WORKSHEET_GetData", "Ref.userDATAWORKSHEETGetData");
	    ruleMap.put("USER_DATA_WORKSHEET_GetDefinitionName", "Ref.userDATAWORKSHEETGetDefinitionName");
	    // ... continue for all USER_DATA_WORKSHEET_* ruleMappings

	    ruleMap.put("UserCanAccess", "Util.userCanAccess");
	    ruleMap.put("unit_conversion_factor", "Util.unitconversionFactor");
	    ruleMap.put("UnlinkDealFromComposer", "Transaction.unlinkDealFromComposer");

	    // UPGRADE Keywords
	    ruleMap.put("UPDATE_Browser", "Query.updateBrowser");
	    ruleMap.put("UPDATE_CreateTableFromBrowser", "Query.updateCreateTableFromBrowser");
	    ruleMap.put("UPDATE_CreateTableFromQuery", "Query.updateCreateTableFromQuery");

	    ruleMap.put("UPGRADE_Abs", "Upgrades.abs");
	    ruleMap.put("UPGRADE_AcctEntriesHeaderUniqIndexString", "Upgrades.acctEntriesHeaderUniqIndexString");
	    ruleMap.put("UPGRADE_AddBAVFlagsToTranScheduleDetailsForOldDeals", "Upgrades.addBAVFlagsToTranScheduleDetailsForOldDeals");
	    ruleMap.put("UPGRADE_AddFuelToCommScheduleDeliveryAndCommScheduleHeader", "Upgrades.addFuelToCommScheduleDeliveryAndCommScheduleHeader");


	    ruleMap.put("UPGRADE_AddScheduleDeliveryDetailForScheduleDelivery", "Upgrades.addScheduleDeliveryDetailForScheduleDelivery");
	    ruleMap.put("UPGRADE_AvsScriptDetailToClob", "Upgrades.avsScriptDetailToClob");
	    ruleMap.put("UPGRADE_BlobTranScheduleDetails", "Upgrades.blobTranScheduleDetails");
	    ruleMap.put("UPGRADE_ConvertABSInstruments", "Upgrades.convertABSInstruments");
	    ruleMap.put("UPGRADE_ConvertFXPairs", "Upgrades.convertFXPairs");
	    ruleMap.put("UPGRADE_ConvertGasPhysTlinkDetail", "Upgrades.convertGasPhysTlinkDetail");
	    ruleMap.put("UPGRADE_ConvertRemainingInstruments", "Upgrades.convertRemainingInstruments");
	    ruleMap.put("UPGRADE_ConvertToParentChildStructure", "Upgrades.convertToParentChildStructure");
	    ruleMap.put("UPGRADE_ConvertTSeriesAnalysisCfgIECfgsToStdIEDefs", "Upgrades.convertTSeriesAnalysisCfgIECfgsToStdIEDefs");
	    ruleMap.put("UPGRADE_ConvertTSeriesDataCfgIECfgsToStdIEDefs", "Upgrades.convertTSeriesDataCfgIECfgsToStdIEDefs");
	    ruleMap.put("UPGRADE_ConvertTSeriesDataIECfgsToStdIEDefs", "Upgrades.convertTSeriesDataIECfgsToStdIEDefs");
	    ruleMap.put("UPGRADE_Correct_StepUp_Bond_ABS_Spreads", "Upgrades.correctStepUpBondABSSpreads");
	    ruleMap.put("UPGRADE_CreateConfigurableVolDomainsFromLegacyVolDomains", "Upgrades.createConfigurableVolDomainsFromLegacyVolDomains");
	    ruleMap.put("UPGRADE_CreateGridProperties", "Upgrades.createGridProperties");
	    ruleMap.put("UPGRADE_DateConfigsForDayStartTime", "Upgrades.dateConfigsForDayStartTime");


	    ruleMap.put("UPGRADE_DateConfigsForDayStartTime", "Upgrades.dateConfigsForDayStartTime");
	    ruleMap.put("UPGRADE_FixDealSideVolumePrecision", "Upgrades.fixDealSideVolumePrecision");
	    ruleMap.put("UPGRADE_FixupTranScheduleDetailsForOldDeals", "Upgrades.fixupTranScheduleDetailsForOldDeals");
	    ruleMap.put("UPGRADE_FixVolumeTypesForCMotion", "Upgrades.fixVolumeTypesForCMotion");
	    ruleMap.put("UPGRADE_Fx", "Upgrades.fx");
	    ruleMap.put("UPGRADE_GenericUpgradeScriptProcess", "Upgrades.genericUpgradeScriptProcess");
	    ruleMap.put("UPGRADE_GlobalEnvSettings", "Upgrades.globalEnvSettings");
	    ruleMap.put("UPGRADE_InsPymtFmlaVariableDefn", "Upgrades.insPymtFmlaVariableDefn");
	    ruleMap.put("UPGRADE_LoadConnexScripts", "Upgrades.loadConnexScripts");
	    ruleMap.put("UPGRADE_LoadCustomerJBOClasses", "Upgrades.loadCustomerJBOClasses");
	    ruleMap.put("UPGRADE_LoadCustomerScripts", "Upgrades.loadCustomerScripts");
	    ruleMap.put("UPGRADE_LoadCustomScripts", "Upgrades.loadCustomScripts");
	    ruleMap.put("UPGRADE_LoadDealEntryScreenDefinitions", "Upgrades.loadDealEntryScreenDefinitions");
	    ruleMap.put("UPGRADE_LoadGuiDefinitions", "Upgrades.loadGuiDefinitions");
	    ruleMap.put("UPGRADE_LoadStandardJBOClasses", "Upgrades.loadStandardJBOClasses");
	    ruleMap.put("UPGRADE_LoadStandardScripts", "Upgrades.loadStandardScripts");
	    ruleMap.put("UPGRADE_PWRFixupBestAvailableForOldDeals", "Upgrades.pWRFixupBestAvailableForOldDeals");
	    ruleMap.put("UPGRADE_Remap_SPT_To_FP_CF_FOR_ABS", "Upgrades.remapSPTToFPCFFORABS");
	    ruleMap.put("UPGRADE_RemoveCorrelationBidOfferData", "Upgrades.removeCorrelationBidOfferData");
	    ruleMap.put("UPGRADE_ResetAvgCompoundPeriodForLogicalLeg", "Upgrades.resetAvgCompoundPeriodForLogicalLeg");
	    ruleMap.put("UPGRADE_SetFXDefaultCurrency", "Upgrades.setFXDefaultCurrency");
	    ruleMap.put("UPGRADE_SetFXDefaults", "Upgrades.setFXDefaults");
	    ruleMap.put("UPGRADE_SetPPAConfigurationDefaults", "Upgrades.setPPAConfigurationDefaults");
	    ruleMap.put("UPGRADE_SetSystemBaseCurrency", "Upgrades.setSystemBaseCurrency");
	    ruleMap.put("UPGRADE_UpdateABSInstruments", "Upgrades.updateABSInstruments");
	    ruleMap.put("UPGRADE_UpdateBarAndBarHistoryTables", "Upgrades.updateBarAndBarHistoryTables");
	    ruleMap.put("UPGRADE_UpdateBarrierOptionsV52toV53", "Upgrades.updateBarrierOptionsV52toV53");
	    ruleMap.put("UPGRADE_UpdateBarrierOptionsV53toV60", "Upgrades.updateBarrierOptionsV53toV60");
	    ruleMap.put("UPGRADE_UpdateBlackSwaptionScenarioPricingModelConfig", "Upgrades.updateBlackSwaptionScenarioPricingModelConfig");
	    ruleMap.put("UPGRADE_UpdateCommoditySchedulingForDaylightSavings", "Upgrades.updateCommoditySchedulingForDaylightSavings");
	    ruleMap.put("UPGRADE_UpdateContractDetailEntitlementsEffectiveDates", "Upgrades.updateContractDetailEntitlementsEffectiveDates");
	    ruleMap.put("UPGRADE_UpdateCTLSetupConfig", "Upgrades.updateCTLSetupConfig");
	    ruleMap.put("UPGRADE_UpdateDailyStorageBalances", "Upgrades.updateDailyStorageBalances");
	    ruleMap.put("UPGRADE_UpdateEnergyConversionEffectiveDates", "Upgrades.updateEnergyConversionEffectiveDates");
	    ruleMap.put("UPGRADE_UpdateIndexLinkedBondDailyRefIndexDay", "Upgrades.updateIndexLinkedBondDailyRefIndexDay");
	    ruleMap.put("UPGRADE_UpdateMCarloScenarioPricingModelConfig", "Upgrades.updateMCarloScenarioPricingModelConfig");
	    ruleMap.put("UPGRADE_UpdatePwrLocations", "Upgrades.updatePwrLocations");
	    ruleMap.put("UPGRADE_UpdatePwrPhysTables", "Upgrades.updatePwrPhysTables");
	    ruleMap.put("UPGRADE_UpdateRateDefsForHourly", "Upgrades.updateRateDefsForHourly");
	    ruleMap.put("UPGRADE_UpdateRepoDealsForDVPProcessing", "Upgrades.updateRepoDealsForDVPProcessing");
	    ruleMap.put("UPGRADE_UpdateScenarioLocaleSpecificStrings", "Upgrades.updateScenarioLocaleSpecificStrings");
	    ruleMap.put("UPGRADE_UpdateScenarioPricingModelMappings", "Upgrades.updateScenarioPricingModelMappings");
	    ruleMap.put("UPGRADE_UpdateScenarioVaRConfigs", "Upgrades.updateScenarioVaRConfigs");
	    ruleMap.put("UPGRADE_UpdateScenarioVegaConfigs", "Upgrades.updateScenarioVegaConfigs");
	    ruleMap.put("UPGRADE_UpdateStructSecDealsForPoolFactorAndAllinRate", "Upgrades.updateStructSecDealsForPoolFactorAndAllinRate");
	    ruleMap.put("UPGRADE_UpdateStructuredSecuritiesDealsForOriginalFaceAmount", "Upgrades.updateStructuredSecuritiesDealsForOriginalFaceAmount");
	    ruleMap.put("UPGRADE_UpdateSwingConstraintsForHourly", "Upgrades.updateSwingConstraintsForHourly");
	    ruleMap.put("UPGRADE_UpdateSwingRightsForHourly", "Upgrades.updateSwingRightsForHourly");
	    ruleMap.put("UPGRADE_UpdateTaxEvents", "Upgrades.updateTaxEvents");
	    ruleMap.put("UPGRADE_UpdateTaxJurisdictionEntity", "Upgrades.updateTaxJurisdictionEntity");
	    ruleMap.put("UPGRADE_UpdateWellheadProduct", "Upgrades.updateWellheadProduct");
	    ruleMap.put("UPGRADE_UpdateTaxTranTypeLicensing", "Upgrades.updateTaxTranTypeLicensing");
	    ruleMap.put("UPGRADE_UpdateTrinomialScenarioPricingModelConfig", "Upgrades.updateTrinomialScenarioPricingModelConfig");







	    RULES = Collections.unmodifiableMap(ruleMap);
	}

	// Apply all simple replacements
	 public static String replaceSimple(String input) {
	        String result = input;
	        for (Map.Entry<String, String> entry : RULES.entrySet()) {
	            if (result.contains(entry.getKey())) {
	                result = result.replace(entry.getKey(), entry.getValue());
	            }
	        }
	        return result;
	    }
}
