# Data Validation Queries Documentation

## Overview

This document describes all data validation queries available in the Case Management System. These queries help ensure data integrity, completeness, and quality across all components.

---

## Table of Contents

1. [Case Data Validation](#case-data-validation)
2. [Client Data Validation](#client-data-validation)
3. [Monitoring Data Validation](#monitoring-data-validation)
4. [312 Case Data Validation](#312-case-data-validation)
5. [CAM Case Data Validation](#cam-case-data-validation)
6. [User Data Validation](#user-data-validation)
7. [System Integration Validation](#system-integration-validation)
8. [Data Quality Reporting](#data-quality-reporting)
9. [Usage Examples](#usage-examples)

---

## Case Data Validation

### `validateCase(caseData: Case): ValidationResult`

Validates core case data structure and business rules.

**Checks:**
- ✅ Required Fields: `id`, `clientId`, `clientName`, `gci`, `caseType`, `status`, `riskLevel`, `priority`, `assignedTo`
- ✅ Date Fields: `createdDate`, `dueDate` (format and logic validation)
- ✅ Numeric Fields: `alertCount`, `transactionCount`, `totalAmount` (non-negative)
- ✅ Business Rules:
  - Due date must be after created date
  - Complete cases should have completion date
  - 312 cases should have `case312Data`
  - CAM cases should have `camCaseData`

**Query Functions:**

#### `queryCasesMissingCriticalData(cases: Case[]): Case[]`
Returns cases missing essential integration data.

**Finds:**
- Cases without `clientData`
- Cases without `monitoringData`
- 312 cases without `case312Data`
- CAM cases without `camCaseData`
- Cases missing `gci` or `clientId`

**Use Case:** Identify cases that need data enrichment from source systems.

---

#### `queryCasesWithIntegrityIssues(cases: Case[]): ValidationResult[]`
Returns validation results for cases with any data integrity problems.

**Finds:**
- Invalid required fields
- Date logic errors
- Business rule violations

**Use Case:** Generate a list of cases requiring data remediation.

---

#### `queryPastDueCases(cases: Case[]): Case[]`
Returns cases that are overdue.

**Criteria:**
- Due date is before today
- Status is not "Complete" or "Closed"

**Use Case:** Priority worklist for analysts and managers.

---

#### `queryCasesByStatus(cases: Case[], status: string): Case[]`
Returns cases matching a specific status.

**Parameters:**
- `status`: 'Unassigned', 'In Progress', 'Pending Sales Review', etc.

**Use Case:** Filter cases by workflow stage.

---

#### `queryHighRiskCases(cases: Case[]): Case[]`
Returns cases flagged as high or critical risk.

**Criteria:**
- Risk level is "High" or "Critical", OR
- Dynamic risk rating ≥ 8.0

**Use Case:** Focus on highest priority cases requiring immediate attention.

---

## Client Data Validation

### `validateClientData(clientData: ClientData, parentCaseId?: string): ValidationResult`

Validates client data from source systems.

**Checks:**
- ✅ Required Fields: `clientId`, `gciNumber`, `legalName`, `salesOwner`, `lineOfBusiness`, `accountOpenDate`, `clientType`, `jurisdiction`, `dataSource`, `lastUpdated`
- ✅ GWIM Hub records should have `mpId`
- ✅ Account open date cannot be in the future

**Query Functions:**

#### `queryClientsWithoutMPID(cases: Case[]): Case[]`
Returns cases with GWIM Hub data source but missing MP ID.

**Criteria:**
- `clientData.dataSource === 'GWIM Hub'`
- `clientData.mpId` is null or undefined

**Use Case:** Identify GWIM Hub records needing MP ID enrichment.

---

#### `queryClientsByDataSource(cases: Case[], dataSource: string): Case[]`
Returns cases sourced from a specific system.

**Parameters:**
- `dataSource`: 'Cesium', 'WCC', 'CMT', 'GWIM Hub', 'PRDS', 'CP'

**Use Case:** Audit data by source system or troubleshoot integration issues.

---

#### `queryEmployeeAccounts(cases: Case[]): Case[]`
Returns all employee and affiliate accounts.

**Criteria:**
- `isBACEmployee === true`, OR
- `clientData.isEmployee === true`

**Use Case:** Apply enhanced monitoring for employee accounts per policy.

---

## Monitoring Data Validation

### `validateMonitoringData(monitoringData: MonitoringData, parentCaseId?: string): ValidationResult`

Validates monitoring and risk data from ORRCA and other systems.

**Checks:**
- ✅ Required Fields: `dynamicRiskRating`, `riskRatingDate`, `lastMonitoringDate`
- ✅ Risk rating must be between 0 and 10
- ✅ 312 model score validation when flag is true
- ✅ Data freshness warnings (>90 days old)

**Query Functions:**

#### `queryCasesWithStaleMonitoring(cases: Case[], daysThreshold: number = 90): Case[]`
Returns cases with outdated monitoring data.

**Parameters:**
- `daysThreshold`: Number of days (default: 90)

**Criteria:**
- Risk rating date is older than threshold

**Use Case:** Identify cases needing monitoring data refresh.

---

#### `queryCasesWith312ModelFlag(cases: Case[]): Case[]`
Returns cases flagged by 312 model.

**Criteria:**
- `monitoringData.model312Flag === true`

**Use Case:** Review all model-triggered 312 cases.

---

#### `queryCasesByRiskRating(cases: Case[], minRating: number, maxRating: number = 10): Case[]`
Returns cases within a risk rating range.

**Parameters:**
- `minRating`: Minimum risk score
- `maxRating`: Maximum risk score (default: 10)

**Use Case:** Segment cases by risk level for resource allocation.

---

## 312 Case Data Validation

### `validate312CaseData(case312Data: Case312Data, parentCaseId?: string): ValidationResult`

Validates 312 review specific data.

**Checks:**
- ✅ Required Fields: `dueDate`, `aging`, `status`, `modelResult`, `modelResultDescription`
- ✅ Aging cannot be negative
- ✅ Expected activity volume and value should be populated
- ⚠️ Warnings for overdue cases (>14 days)

**Query Functions:**

#### `queryOverdue312Cases(cases: Case[]): Case[]`
Returns 312 cases past their due date.

**Criteria:**
- `is312Case === true`
- `case312Data.aging > 0`

**Use Case:** Priority list for 312 review analysts.

---

#### `query312CasesMissingActivityData(cases: Case[]): Case[]`
Returns 312 cases without expected activity data.

**Criteria:**
- `is312Case === true`
- Missing `expectedActivityVolume` or `expectedActivityValue`

**Use Case:** Identify cases needing DDQ or client profile data.

---

## CAM Case Data Validation

### `validateCAMCaseData(camCaseData: CAMCaseData, parentCaseId?: string): ValidationResult`

Validates CAM review specific data.

**Checks:**
- ✅ Required Fields: `dueDate`, `aging`, `status`, `triggers`
- ✅ Triggers array should not be empty
- ⚠️ Warnings for overdue cases (>14 days)

**Query Functions:**

#### `queryOverdueCAMCases(cases: Case[]): Case[]`
Returns CAM cases past their due date.

**Criteria:**
- `is312Case === false`
- `camCaseData.aging > 0`

**Use Case:** Priority list for CAM review analysts.

---

## User Data Validation

### `validateUser(user: User): ValidationResult`

Validates user account data.

**Checks:**
- ✅ Required Fields: `id`, `name`, `email`, `role`
- ✅ Email format validation

**Query Functions:**

#### `queryUsersWithMIEntitlement(users: User[]): User[]`
Returns users with M&I (Monitoring & Investigations) entitlement.

**Criteria:**
- `hasM_I_Entitlement === true`

**Use Case:** Identify users who can handle defect remediation cases.

---

#### `queryUsersByRole(users: User[], role: string): User[]`
Returns users with a specific role.

**Parameters:**
- `role`: 'Analyst', 'Manager', 'Administrator', 'Sales Owner'

**Use Case:** Build assignment lists or role-based reports.

---

## System Integration Validation

### `validateSystemIntegration(integration: SystemIntegration): ValidationResult`

Validates system integration health and status.

**Checks:**
- ✅ Required Fields: `id`, `name`, `type`, `status`
- ⚠️ Warnings for error status
- ⚠️ Warnings for sync delays (>24 hours)

**Query Functions:**

#### `queryIntegrationsWithErrors(integrations: SystemIntegration[]): SystemIntegration[]`
Returns integrations in error state.

**Criteria:**
- `status === 'Error'`, OR
- `errorCount > 0`

**Use Case:** System health monitoring and alerting.

---

#### `queryIntegrationsNeedingSync(integrations: SystemIntegration[], hoursThreshold: number = 24): SystemIntegration[]`
Returns integrations that haven't synced recently.

**Parameters:**
- `hoursThreshold`: Hours since last sync (default: 24)

**Use Case:** Identify stale data sources requiring attention.

---

## Data Quality Reporting

### `generateDataQualityReport(cases: Case[]): DataQualityReport`

Generates comprehensive data quality metrics.

**Returns:**
```typescript
{
  totalRecords: number;
  validRecords: number;
  invalidRecords: number;
  validationResults: ValidationResult[];
  summary: {
    criticalErrors: number;
    warnings: number;
    missingFields: string[];
    dataQualityScore: number; // 0-100
  };
}
```

**Data Quality Score Calculation:**
- 100 = Perfect data quality
- 90-99 = Excellent
- 70-89 = Good
- <70 = Needs Attention

**Formula:**
```
Score = 100 - (errorRate × 70) - (warningRate × 30)
```

**Use Case:** Executive dashboard and data governance reporting.

---

## Usage Examples

### Example 1: Validate a Single Case

```typescript
import { validateCase } from '@/app/utils/dataValidation';

const caseData: Case = {
  id: '312-2025-001',
  clientId: 'GCI-123456',
  // ... other fields
};

const result = validateCase(caseData);

if (!result.isValid) {
  console.error('Validation Errors:', result.errors);
}

if (result.warnings.length > 0) {
  console.warn('Validation Warnings:', result.warnings);
}
```

---

### Example 2: Find All Past Due Cases

```typescript
import { queryPastDueCases } from '@/app/utils/dataValidation';
import { mockCases } from '@/app/data/enhancedMockData';

const pastDue = queryPastDueCases(mockCases);

console.log(`Found ${pastDue.length} past due cases:`);
pastDue.forEach(c => {
  console.log(`- ${c.id}: ${c.clientName} (Due: ${c.dueDate})`);
});
```

---

### Example 3: Generate Data Quality Report

```typescript
import { 
  generateDataQualityReport, 
  logDataQualityReport 
} from '@/app/utils/dataValidation';
import { mockCases } from '@/app/data/enhancedMockData';

const report = generateDataQualityReport(mockCases);

// Log to console
logDataQualityReport(report);

// Use in UI
console.log(`Data Quality Score: ${report.summary.dataQualityScore}/100`);
console.log(`Valid Records: ${report.validRecords}/${report.totalRecords}`);
```

---

### Example 4: Find Cases Missing MP ID

```typescript
import { queryClientsWithoutMPID } from '@/app/utils/dataValidation';
import { mockCases } from '@/app/data/enhancedMockData';

const missingMPID = queryClientsWithoutMPID(mockCases);

console.log(`GWIM Hub records missing MP ID: ${missingMPID.length}`);
missingMPID.forEach(c => {
  console.log(`- ${c.id}: ${c.clientName}`);
  console.log(`  GCI: ${c.gci}`);
  console.log(`  Data Source: ${c.clientData?.dataSource}`);
});
```

---

### Example 5: Chain Multiple Queries

```typescript
import { 
  queryHighRiskCases,
  queryPastDueCases,
  queryCasesByStatus 
} from '@/app/utils/dataValidation';
import { mockCases } from '@/app/data/enhancedMockData';

// Find high-risk, past-due cases that are still in progress
const highRisk = queryHighRiskCases(mockCases);
const pastDue = queryPastDueCases(highRisk);
const inProgress = queryCasesByStatus(pastDue, 'In Progress');

console.log(`Critical attention required: ${inProgress.length} cases`);
inProgress.forEach(c => {
  console.log(`- ${c.id}: ${c.clientName}`);
  console.log(`  Risk: ${c.riskLevel} | Due: ${c.dueDate}`);
  console.log(`  Assigned: ${c.assignedTo}`);
});
```

---

### Example 6: Integration Health Check

```typescript
import { 
  validateSystemIntegration,
  queryIntegrationsWithErrors,
  queryIntegrationsNeedingSync
} from '@/app/utils/dataValidation';
import { systemIntegrations } from '@/app/data/systemIntegrations';

// Check for errors
const withErrors = queryIntegrationsWithErrors(systemIntegrations);
if (withErrors.length > 0) {
  console.error(`⚠️  ${withErrors.length} integrations have errors`);
  withErrors.forEach(i => {
    console.error(`- ${i.name}: ${i.errorCount} errors`);
  });
}

// Check for stale syncs
const needsSync = queryIntegrationsNeedingSync(systemIntegrations, 24);
if (needsSync.length > 0) {
  console.warn(`⚠️  ${needsSync.length} integrations need sync`);
  needsSync.forEach(i => {
    console.warn(`- ${i.name}: Last sync ${i.lastSync}`);
  });
}
```

---

### Example 7: Employee Account Audit

```typescript
import { queryEmployeeAccounts } from '@/app/utils/dataValidation';
import { mockCases } from '@/app/data/enhancedMockData';

const employeeAccounts = queryEmployeeAccounts(mockCases);

console.log(`Employee/Affiliate accounts requiring enhanced monitoring: ${employeeAccounts.length}`);

// Group by type
const employees = employeeAccounts.filter(c => c.isBACEmployee);
const affiliates = employeeAccounts.filter(c => c.isBACAffiliate);
const regO = employeeAccounts.filter(c => c.isRegO);

console.log(`- BAC Employees: ${employees.length}`);
console.log(`- BAC Affiliates: ${affiliates.length}`);
console.log(`- Reg O: ${regO.length}`);
```

---

## Query Performance Tips

1. **Filter Before Validate**: Use query functions to filter data before running expensive validations
2. **Batch Validation**: Use `generateDataQualityReport()` for comprehensive analysis instead of individual validations
3. **Cache Results**: Store query results if running the same query multiple times
4. **Incremental Validation**: Only validate changed records in real-time scenarios

---

## Integration with Components

### Using in React Components

```typescript
import { useState, useEffect } from 'react';
import { generateDataQualityReport } from '@/app/utils/dataValidation';

function MyComponent({ cases }) {
  const [report, setReport] = useState(null);
  
  useEffect(() => {
    const dataReport = generateDataQualityReport(cases);
    setReport(dataReport);
  }, [cases]);
  
  return (
    <div>
      {report && (
        <div>
          <h2>Data Quality: {report.summary.dataQualityScore}/100</h2>
          <p>Valid: {report.validRecords}/{report.totalRecords}</p>
        </div>
      )}
    </div>
  );
}
```

---

## Validation Dashboard Component

Use the `DataValidationDashboard` component for a complete UI:

```typescript
import { DataValidationDashboard } from '@/app/components/DataValidationDashboard';
import { mockCases } from '@/app/data/enhancedMockData';
import { systemIntegrations } from '@/app/data/systemIntegrations';

function App() {
  return (
    <DataValidationDashboard 
      cases={mockCases}
      systemIntegrations={systemIntegrations}
    />
  );
}
```

---

## Testing and Validation

### Running Validation on Startup

Add to your application initialization:

```typescript
import { 
  generateDataQualityReport, 
  logDataQualityReport 
} from '@/app/utils/dataValidation';
import { mockCases } from '@/app/data/enhancedMockData';

// Run validation on app load
if (process.env.NODE_ENV === 'development') {
  const report = generateDataQualityReport(mockCases);
  logDataQualityReport(report);
  
  if (report.summary.dataQualityScore < 90) {
    console.warn('⚠️  Data quality below 90%. Review validation errors.');
  }
}
```

---

## API Integration

These validation queries can be used server-side for:

1. **Pre-save Validation**: Validate data before committing to database
2. **Batch Import Validation**: Validate imported data files
3. **Scheduled Quality Checks**: Run nightly data quality reports
4. **API Response Validation**: Ensure integration data meets requirements

---

## Extending Validation Queries

To add custom validation queries:

```typescript
// Add to dataValidation.ts

export function queryCustomCriteria(cases: Case[]): Case[] {
  return cases.filter(c => {
    // Your custom criteria
    return /* boolean condition */;
  });
}

export function validateCustomComponent(data: CustomType): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  
  // Your validation logic
  
  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: 'CustomComponent'
  };
}
```

---

## Support and Questions

For questions about data validation queries or to request new validation rules, contact the development team.

**Last Updated:** January 2026  
**Version:** 1.0.0
