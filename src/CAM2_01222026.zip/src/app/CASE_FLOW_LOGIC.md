# CAM 312 Case Flow Logic

## Overview
This document describes the complete case lifecycle for CAM 312 cases, including all statuses, transitions, actors, and business rules.

## Case Statuses

### 1. **Unassigned**
- **Description**: Case created and placed in workbasket pending assignment
- **Next Status**: In Progress or Complete (auto-closed)
- **Actors**: System (auto-creation), Central Team Manager (assignment), Central Team Analyst (self-select)

### 2. **In Progress**
- **Description**: Case actively being worked by analyst
- **Next Status**: Complete or Pending Sales Review
- **Actors**: Central Team Analyst, Central Team Manager
- **Actions**: 
  - Review case details and data
  - Add comments and documentation
  - Upload supporting files
  - Self-disposition (mark complete)
  - Route to sales owner for input

### 3. **Pending Sales Review**
- **Description**: Case routed to sales owner, awaiting sales to open
- **Next Status**: In Sales Review
- **Actors**: Sales Owner
- **Actions**: Open case for review

### 4. **In Sales Review**
- **Description**: Sales owner actively reviewing case
- **Next Status**: Sales Review Complete
- **Actors**: Sales Owner
- **Actions**:
  - Review client relationship context
  - Provide feedback on transactions
  - Add comments
  - Return to analyst

### 5. **Sales Review Complete**
- **Description**: Sales feedback provided, case returned to analyst
- **Next Status**: Complete
- **Actors**: Central Team Analyst, Central Team Manager
- **Actions**:
  - Review sales feedback
  - Final disposition
  - Submit case

### 6. **Complete**
- **Description**: Case finalized with disposition
- **Next Status**: Defect Remediation (if needed)
- **Actors**: All (view), Central Team Manager/Administrator (reopen)
- **Actions**:
  - View case details
  - Reopen for remediation (credentialed users only)
- **Required Fields**:
  - `derivedDisposition`
  - `modelOutcome`
  - `completionDate`

### 7. **Defect Remediation**
- **Description**: Case reopened for M&I or quality review remediation
- **Next Status**: Complete
- **Actors**: Central Team Analyst, Central Team Manager
- **Actions**:
  - Update case documentation
  - Correct deficiencies
  - Re-disposition
  - Re-submit
- **Special Rules**:
  - `originalCompletionDate` must be preserved
  - `defectRemediationFlag` must be set to true

## Case Creation Scenarios

### Scenario A: Auto-Closed Cases

**Trigger**: System determines activity is in line with expected patterns

**Flow**:
```
System Creates Case → Complete (Auto-Closed)
```

**Required Fields**:
- `autoClosed`: true
- `modelOutcome`: "312 Activity in line with expected activity"
- `derivedDisposition`: "No Action Required"
- `completionDate`: Auto-populated
- `assignedTo`: "System"

**Example**:
- Client: Standard Manufacturing Inc
- Risk: Low
- Alerts: 0-2
- Outcome: No action required, auto-closed

---

### Scenario B: Manual Review - Self-Disposition

**Trigger**: Case requires manual review but analyst can disposition without sales input

**Flow**:
```
Unassigned → In Progress → Complete
```

**Steps**:
1. **Unassigned**: Case appears in workbasket
2. **Assignment**: Manager assigns OR analyst self-selects
3. **In Progress**: Analyst reviews case data, client profile, transactions
4. **Disposition**: Analyst determines outcome
5. **Complete**: Case marked complete with disposition

**Required Fields at Completion**:
- `derivedDisposition`: "No Action Required" | "Escalated to Compliance"
- `modelOutcome`: Based on disposition
- `completionDate`: Date submitted
- `autoClosed`: false

**Example**:
- Client: United Manufacturing Corp
- Risk: Medium
- Analyst Review: Activity consistent with business patterns
- Outcome: No Action Required

---

### Scenario C: Sales Review Flow

**Trigger**: Analyst needs sales owner input on client context/transactions

**Flow**:
```
Unassigned → In Progress → Pending Sales Review → In Sales Review → Sales Review Complete → Complete
```

**Steps**:
1. **Unassigned → In Progress**: Case assigned/selected
2. **Analyst Initial Review**: Identifies need for sales input
3. **Route to Sales**: Case moves to "Pending Sales Review"
4. **Sales Opens**: Status changes to "In Sales Review"
5. **Sales Provides Feedback**: Comments on client relationship, transaction context
6. **Return to Analyst**: Status changes to "Sales Review Complete"
7. **Analyst Final Disposition**: Reviews sales feedback and completes case
8. **Complete**: Case marked complete with disposition

**Required Fields**:
- `salesReviewComments`: Sales owner feedback (required for Sales Review Complete)
- `derivedDisposition`: Final disposition after sales input
- `modelOutcome`: Based on final disposition
- `completionDate`: Date submitted
- `autoClosed`: false

**Example**:
- Client: Apex Strategic Partners
- Risk: High
- Issue: Unusual transaction patterns
- Sales Input: "Transactions align with business strategy discussed in quarterly reviews"
- Outcome: No Action Required (after sales confirmation)

---

### Scenario D: Escalated Cases - TRMS Filed

**Trigger**: Suspicious activity identified requiring TRMS case filing

**Flow**:
```
Unassigned → In Progress → Complete (Escalated)
```

**Steps**:
1. **Investigation**: Analyst identifies suspicious patterns
2. **TRMS Filing**: Case escalated with TRMS case creation
3. **Complete**: Case marked complete with escalation disposition

**Required Fields**:
- `derivedDisposition`: "TRMS Filed"
- `modelOutcome`: "312 Activity Escalated"
- `completionDate`: Date submitted
- `autoClosed`: false
- `trmsCase`: TRMS case details

**Example**:
- Client: Offshore Holdings Ltd
- Risk: Critical
- Issue: Suspicious structuring patterns
- Action: TRMS-2025-1234 filed
- Outcome: Escalated

---

### Scenario E: Escalated Cases - Client Closed

**Trigger**: Unacceptable risk leads to client relationship termination

**Flow**:
```
Unassigned → In Progress → Complete (Client Closed)
```

**Steps**:
1. **Investigation**: Analyst identifies unacceptable risk
2. **Decision**: Client relationship terminated
3. **Complete**: Case marked complete with closure disposition

**Required Fields**:
- `derivedDisposition`: "Client Closed"
- `modelOutcome`: "312 Activity Escalated"
- `completionDate`: Date submitted
- `autoClosed`: false

**Example**:
- Client: Questionable Trading Corp
- Risk: Critical
- Issue: Pattern of high-risk transactions, jurisdiction concerns
- Action: Client relationship terminated
- Outcome: Escalated

---

### Scenario F: Defect Remediation

**Trigger**: M&I or quality review identifies deficiency in completed case

**Flow**:
```
Complete → Defect Remediation → Complete
```

**Steps**:
1. **Quality Review**: M&I or QA identifies issue
2. **Reopen**: Credentialed user reopens case
3. **Defect Remediation**: Analyst corrects deficiency
4. **Re-Complete**: Case re-submitted with corrections

**Special Rules**:
- **Original Completion Date Preserved**: `originalCompletionDate` maintained for reporting
- **New Completion Date**: `completionDate` updated to remediation completion
- **Flag Set**: `defectRemediationFlag` = true

**Required Fields**:
- `originalCompletionDate`: Date of first completion (preserved)
- `completionDate`: Date of remediation completion (updated)
- `defectRemediationFlag`: true
- All other completion fields maintained/updated

**Example**:
- Client: Global Enterprise Solutions
- Original Completion: 2025-09-28
- Issue: Additional documentation required
- Remediation: 2025-10-26
- Reporting: Uses 2025-09-28 for SLA metrics

---

## Model Outcome Determination

### "312 Activity in line with expected activity"
**When**:
- Auto-closed cases
- Manual cases with "No Action Required" disposition
- Cases where activity explained by business context

### "312 Activity Escalated"
**When**:
- TRMS filed
- Client closed
- Escalated to compliance
- Unacceptable risk identified

### "Pending Review"
**When**:
- Case not yet complete
- Awaiting disposition

---

## Derived Disposition Types

| Disposition | Description | Model Outcome |
|------------|-------------|---------------|
| **No Action Required** | Activity consistent with expected patterns | In line with expected activity |
| **TRMS Filed** | Suspicious activity escalated to investigations | Escalated |
| **Client Closed** | Relationship terminated due to unacceptable risk | Escalated |
| **Escalated to Compliance** | Case escalated for compliance review | Escalated |
| **Pending** | Awaiting final disposition | Pending Review |

---

## Actor Permissions

### System
- **Actions**: Auto-create and auto-close cases
- **Statuses**: Can set Unassigned → Complete (auto-closed only)

### Central Team Manager
- **Actions**: 
  - Assign cases to analysts
  - Work cases (same as analyst)
  - Reopen completed cases for remediation
- **Statuses**: All statuses except sales-specific

### Central Team Analyst
- **Actions**:
  - Select cases from workbasket
  - Work cases
  - Route to sales
  - Disposition cases
  - Remediate defects
- **Statuses**: In Progress, Sales Review Complete, Defect Remediation, Complete

### Sales Owner
- **Actions**:
  - Review cases routed to them
  - Provide feedback
  - Return to analyst
- **Statuses**: Pending Sales Review, In Sales Review, Sales Review Complete

### Administrator
- **Actions**:
  - Reopen completed cases
  - Override restrictions (emergency access)
- **Statuses**: Can access all statuses

### View Only
- **Actions**: View completed cases only
- **Statuses**: Complete, Closed (read-only)

---

## Status Transition Matrix

| From Status | To Status | Actor | Required Fields |
|------------|-----------|-------|-----------------|
| Unassigned | In Progress | Manager, Analyst | assignedTo |
| Unassigned | Complete | System | autoClosed, modelOutcome |
| In Progress | Complete | Analyst, Manager | derivedDisposition, modelOutcome |
| In Progress | Pending Sales Review | Analyst, Manager | - |
| Pending Sales Review | In Sales Review | Sales Owner | - |
| In Sales Review | Sales Review Complete | Sales Owner | salesReviewComments |
| Sales Review Complete | Complete | Analyst, Manager | derivedDisposition, modelOutcome |
| Complete | Defect Remediation | Manager, Admin | defectRemediationFlag |
| Defect Remediation | Complete | Analyst, Manager | all completion fields |

---

## Validation Rules

### Case Completion Validation
1. **Auto-Closed Cases**:
   - Must have `autoClosed` = true
   - Must have `modelOutcome` = "312 Activity in line with expected activity"
   - Must have `derivedDisposition` = "No Action Required"
   - Must have `completionDate`

2. **Manual Cases**:
   - Must have `autoClosed` = false
   - Must have `derivedDisposition` (not "Pending")
   - Must have `modelOutcome` (not "Pending Review")
   - Must have `completionDate`
   - Must have reviewed all required data sources

3. **Sales Review Cases**:
   - Must have `salesReviewComments` before marking Sales Review Complete
   - Cannot skip sales review once routed

4. **Remediation Cases**:
   - Must preserve `originalCompletionDate`
   - Must set `defectRemediationFlag` = true
   - New `completionDate` must be after `originalCompletionDate`

### Assignment Validation
1. Only managers can assign to specific analysts
2. Analysts can self-select from workbasket
3. Sales Owner cases must be assigned to the client's sales owner
4. Cannot reassign completed cases

### Status Transition Validation
1. Must follow defined transition paths
2. Actor must have permission for transition
3. Required fields must be populated
4. Cannot skip required statuses in flow

---

## Reporting Considerations

### SLA Metrics
- **For Normal Cases**: Use `completionDate`
- **For Remediation Cases**: Use `originalCompletionDate` (not remediation date)
- **For Auto-Closed**: Use `completionDate` (same as creation date)

### Case Aging
- **Start Date**: `createdDate`
- **End Date**: `completionDate` (or current date if incomplete)
- **Exclude**: Time spent in "Pending Sales Review" and "In Sales Review" (optional)

### Quality Metrics
- **Remediation Rate**: Count of cases with `defectRemediationFlag` = true
- **Auto-Close Rate**: Count of cases with `autoClosed` = true
- **Escalation Rate**: Count of cases with `modelOutcome` = "312 Activity Escalated"

---

## Example Case Scenarios in System

### Case 1: Auto-Closed
- **ID**: 312-2025-AUTO-001
- **Client**: Standard Manufacturing Inc
- **Status**: Complete
- **Auto-Closed**: Yes
- **Outcome**: Activity in line with expected activity

### Case 2: Unassigned Workbasket
- **ID**: 312-2025-UNASSIGN-001
- **Client**: Pacific Trade Ventures Ltd
- **Status**: Unassigned
- **Action Needed**: Assignment or self-selection

### Case 3: In Progress
- **ID**: 312-2025-001
- **Client**: GlobalTech Industries Corp
- **Status**: In Progress
- **Assigned To**: Sarah Mitchell
- **Action Needed**: Analyst review and disposition

### Case 4: Pending Sales Review
- **ID**: 312-2025-SALES-001
- **Client**: Meridian Capital Holdings
- **Status**: Pending Sales Review
- **Assigned To**: David Park (Sales Owner)
- **Action Needed**: Sales owner to open and review

### Case 5: Sales Review Complete
- **ID**: 312-2025-SALES-003
- **Client**: Apex Strategic Partners
- **Status**: Sales Review Complete
- **Assigned To**: Michael Chen
- **Sales Comments**: Provided
- **Action Needed**: Analyst final disposition

### Case 6: Complete - No Action
- **ID**: 312-2025-COMP-001
- **Client**: United Manufacturing Corp
- **Status**: Complete
- **Disposition**: No Action Required
- **Completed**: 2025-10-24

### Case 7: Complete - Escalated (TRMS)
- **ID**: 312-2025-ESC-001
- **Client**: Offshore Holdings Ltd
- **Status**: Complete
- **Disposition**: TRMS Filed
- **TRMS**: TRMS-2025-1234
- **Completed**: 2025-10-19

### Case 8: Complete - Client Closed
- **ID**: 312-2025-ESC-002
- **Client**: Questionable Trading Corp
- **Status**: Complete
- **Disposition**: Client Closed
- **Completed**: 2025-10-21

### Case 9: Defect Remediation
- **ID**: 312-2025-REM-001
- **Client**: Global Enterprise Solutions
- **Status**: Defect Remediation
- **Original Completion**: 2025-09-28
- **Action Needed**: Remediation by analyst

---

## Implementation Notes

### Data Model
All case flow fields are optional in the Case interface to support backward compatibility, but are required based on status:
- `autoClosed?: boolean`
- `modelOutcome?: ModelOutcome`
- `derivedDisposition?: CaseDisposition`
- `completionDate?: string`
- `originalCompletionDate?: string`
- `defectRemediationFlag?: boolean`
- `salesReviewComments?: string`

### Validation Function
Use `validateCaseCompletion()` from `caseFlowValidation.ts` to ensure all required fields are present before status transitions.

### Status Transitions
Use `canTransitionStatus()` from `caseFlowValidation.ts` to validate user permissions and transition validity.

### Available Actions
Use `getAvailableActions()` from `caseFlowValidation.ts` to determine what actions a user can perform on a case.

---

## Related Documentation
- [CASE_CREATION_LOGIC.md](./CASE_CREATION_LOGIC.md) - Population identification and case triggers
- [ROLES_IMPLEMENTATION.md](./ROLES_IMPLEMENTATION.md) - Role-based access control
- [DATA_VISIBILITY_MATRIX.md](./DATA_VISIBILITY_MATRIX.md) - User data access patterns
