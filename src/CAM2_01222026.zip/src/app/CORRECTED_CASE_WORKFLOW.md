# Corrected CAM 312 Case Workflow

## Official Requirements (As Provided)

This document reflects the **corrected** case workflow based on the official requirements provided.

---

## Key Updates

### 1. **Disposition Terminology**
- **OLD**: "312 Activity in line with expected activity" / "312 Activity Escalated"
- **NEW**: "No additional CAM escalation required" / "CAM Case Escalated"

### 2. **Sales Owner Opens Case**
- **Pending Sales Review → In Sales Review**: Sales Owner opens the case (not analyst)
- Analyst routes the case to sales (In Progress → Pending Sales Review)
- Sales Owner opens it when ready (Pending Sales Review → In Sales Review)
- Sales Owner completes review (In Sales Review → Sales Review Complete)

### 3. **LOB Restrictions**
- **Sales review is NOT available** for CI (Corporate & Institutional) and Consumer LOBs
- Only available for: GB/GM, PB, ML

---

## Case Flow Logic

### 1. Auto-Closed Cases

**Flow**: System → Complete (Direct)

**Characteristics**:
- Status: Complete
- Flag: `autoClosed = true`
- Model Outcome: "No additional CAM escalation required"
- **NO** derived disposition (not manually reviewed)

**Example**:
```typescript
{
  id: '312-2025-AUTO-001',
  status: 'Complete',
  autoClosed: true,
  modelOutcome: 'No additional CAM escalation required',
  completionDate: '2025-10-26'
}
```

---

### 2. Manual Review Cases (Not Auto-Closed)

#### **Step 1: Unassigned (Pending)**

**Status**: Unassigned

**How Cases Enter**:
- System creates case (not auto-closed)
- Case sits in workbasket

**Actions**:
- **Central Team Manager**: Assign to specific analyst
- **Central Team Analyst**: Self-select from workbasket

**Next Status**: In Progress

---

#### **Step 2: In Progress**

**Status**: In Progress

**Actor**: Central Team Analyst

**Actions**:
1. **Self-Solve (No Sales Review Needed)**:
   - Analyst reviews case
   - Analyst can determine outcome independently
   - Analyst dispositions case
   - Next Status: **Complete**

2. **Route to Sales (Need Sales Context)**:
   - Analyst needs additional context from sales owner
   - Analyst routes case to sales
   - Next Status: **Pending Sales Review**
   - **RESTRICTION**: NOT available for CI and Consumer LOBs

---

#### **Step 3: Pending Sales Review**

**Status**: Pending Sales Review

**Actor**: Sales Owner (to open case)

**Description**: Case has been routed to sales owner. Waiting for sales owner to open the case.

**Actions**:
- **Sales Owner Opens Case**:
  - Sales owner is ready to review
  - Opens case to start review process
  - Next Status: **In Sales Review**

**LOB Restriction**: This status only applies to GB/GM, PB, and ML cases

---

#### **Step 4: In Sales Review**

**Status**: In Sales Review

**Actor**: Sales Owner

**Description**: Sales owner is actively reviewing the case and will provide context/feedback.

**Actions**:
- **Sales Owner Reviews and Provides Feedback**:
  - Reviews client relationship
  - Provides context on transactions
  - Adds comments
  - Completes review
  - Next Status: **Sales Review Complete**

**Required**: Sales owner must provide comments

---

#### **Step 5: Sales Review Complete**

**Status**: Sales Review Complete

**Actor**: Central Team Analyst (original analyst)

**Description**: Sales owner has completed review. Case returned to analyst's worklist with feedback.

**Actions**:
- **Analyst Reviews Feedback and Dispositions**:
  - Analyst reviews sales owner's comments
  - Makes final disposition decision
  - Submits case
  - Next Status: **Complete**

---

#### **Step 6: Complete**

**Status**: Complete (Terminal)

**Actors**:
- **Central Team Analyst**: Completes case
- **M&I Credentialed Analyst**: Can reopen for remediation

**Characteristics**:
- **Auto-Closed Cases**:
  - `autoClosed = true`
  - `modelOutcome = 'No additional CAM escalation required'`
  - No derived disposition

- **Manual Cases**:
  - `autoClosed = false`
  - Derived disposition indicates escalation:
    - "CAM Case Escalated" (if TRMS filed or client closed)
    - "No additional CAM escalation required" (if no issues)
  - `modelOutcome` matches disposition

**Actions**:
- **Reopen for Remediation** (M&I credentialed only):
  - M&I quality review identifies defect
  - M&I analyst reopens case
  - Next Status: **Defect Remediation**

---

#### **Step 7: Defect Remediation**

**Status**: Defect Remediation

**Actor**: Central Team Analyst w/M&I Entitlement

**Description**: Case reopened due to M&I quality review finding. Being corrected.

**Actions**:
- **Complete Remediation**:
  - M&I analyst corrects defects
  - Re-submits case
  - Next Status: **Complete**

**Important**: Original completion date is **preserved** for SLA reporting

---

## Complete Workflow Diagrams

### Workflow A: Auto-Closed
```
┌──────────────┐
│ CASE CREATED │
└──────┬───────┘
       │
       │ Auto-Close Logic
       ▼
┌──────────────┐
│  COMPLETE    │
│              │
│ autoClosed:  │
│ true         │
└──────────────┘
```

---

### Workflow B: Self-Solved (No Sales Review)
```
┌──────────────┐
│  UNASSIGNED  │
└──────┬───────┘
       │
       │ Manager Assigns OR
       │ Analyst Self-Selects
       ▼
┌──────────────┐
│ IN PROGRESS  │
│              │
│ Analyst      │
└──────┬───────┘
       │
       │ Analyst Reviews &
       │ Can Disposition
       ▼
┌──────────────┐
│  COMPLETE    │
│              │
│ autoClosed:  │
│ false        │
└──────────────┘
```

---

### Workflow C: Sales Review Flow
```
┌──────────────┐
│  UNASSIGNED  │
└──────┬───────┘
       │
       │ Analyst Self-Selects
       ▼
┌──────────────────┐
│  IN PROGRESS     │
│                  │
│  Analyst         │
└──────┬───────────┘
       │
       │ Analyst Routes
       │ to Sales
       ▼
┌──────────────────┐
│ PENDING SALES    │
│ REVIEW           │
│                  │
│ (Sales Owner to  │
│  open)           │
└──────┬───────────┘
       │
       │ Sales Owner
       │ Opens Case
       ▼
┌──────────────────┐
│ IN SALES REVIEW  │
│                  │
│ Sales Owner      │
└──────┬───────────┘
       │
       │ Sales Owner
       │ Completes Review
       ▼
┌──────────────────┐
│ SALES REVIEW     │
│ COMPLETE         │
│                  │
│ Analyst          │
│ (to disposition) │
└──────┬───────────┘
       │
       │ Analyst
       │ Dispositions
       ▼
┌──────────────────┐
│  COMPLETE        │
│                  │
│  autoClosed:     │
│  false           │
└──────────────────┘
```

---

### Workflow D: Defect Remediation
```
┌──────────────────┐
│   COMPLETE       │
│                  │
│ Completion Date: │
│ 2025-09-28       │
└──────┬───────────┘
       │
       │ M&I Quality Review
       │ Identifies Defect
       ▼
┌���─────────────────┐
│ DEFECT           │
│ REMEDIATION      │
│                  │
│ M&I Analyst      │
│ Original Date:   │
│ 2025-09-28       │
│ (PRESERVED)      │
└──────┬───────────┘
       │
       │ M&I Analyst
       │ Completes Remediation
       ▼
┌──────────────────┐
│   COMPLETE       │
│                  │
│ Original Date:   │
│ 2025-09-28       │
│ Remediation Date:│
│ 2025-10-26       │
└──────────────────┘
```

---

## Status Transition Matrix

| From Status | To Status | Actor | Description |
|------------|-----------|-------|-------------|
| System | Unassigned | System | Case creation (not auto-closed) |
| System | Complete | System | Auto-close logic met |
| Unassigned | In Progress | Central Team Manager | Manager assigns to analyst |
| Unassigned | In Progress | Central Team Analyst | Analyst self-selects |
| In Progress | Complete | Central Team Analyst | Self-solve disposition |
| In Progress | Pending Sales Review | Central Team Analyst | Route to sales owner *(Not for CI/Consumer)* |
| **Pending Sales Review** | **In Sales Review** | **Sales Owner** | **Sales owner opens case** |
| In Sales Review | Sales Review Complete | Sales Owner | Sales owner completes review |
| Sales Review Complete | Complete | Central Team Analyst | Final disposition |
| Complete | Defect Remediation | M&I Credentialed User | Reopen for remediation |
| Defect Remediation | Complete | M&I Credentialed User | Remediation complete |

---

## LOB (Line of Business) Restrictions

### Sales Review Availability

| LOB | Sales Review Available? | Notes |
|-----|------------------------|-------|
| **GB/GM** | ✅ Yes | Global Banking / Global Markets |
| **PB** | ✅ Yes | Private Bank |
| **ML** | ✅ Yes | Merrill Lynch |
| **Consumer** | ❌ No | Consumer Banking - No sales owner relationship |
| **CI** | ❌ No | Corporate & Institutional - No sales owner relationship |

**Implementation**:
```typescript
const canRouteTo Sales = (caseData: Case) => {
  // Check status
  if (caseData.status !== 'In Progress') return false;
  
  // Check LOB restriction
  const restrictedLOBs = ['CI', 'Consumer'];
  return !restrictedLOBs.includes(caseData.lineOfBusiness);
};
```

---

## Disposition and Model Outcome Values

### Auto-Closed Cases
```typescript
{
  autoClosed: true,
  modelOutcome: 'No additional CAM escalation required',
  // NO derivedDisposition
}
```

### Manual Cases - No Escalation
```typescript
{
  autoClosed: false,
  modelOutcome: 'No additional CAM escalation required',
  derivedDisposition: 'No additional CAM escalation required'
}
```

### Manual Cases - Escalated
```typescript
{
  autoClosed: false,
  modelOutcome: 'CAM Case Escalated',
  derivedDisposition: 'CAM Case Escalated'
}
```

**Note**: The specific escalation reason (TRMS Filed, Client Closed, etc.) may be captured in additional fields.

---

## Actor Roles and Permissions

### Central Team Manager
**Can**:
- View all cases
- Assign cases from Unassigned workbasket to analysts

**Cannot**:
- Work cases directly
- Disposition cases
- Reopen cases for remediation

---

### Central Team Analyst (Standard)
**Can**:
- Self-select cases from Unassigned workbasket
- Work In Progress cases
- Route cases to sales (if LOB allows)
- Disposition cases → Complete

**Cannot**:
- Reopen completed cases (requires M&I entitlement)

---

### Central Team Analyst (with M&I Entitlement)
**All Standard Analyst Permissions PLUS**:
- Reopen Complete cases → Defect Remediation
- Work Defect Remediation cases
- Re-complete remediation cases → Complete

**M&I Entitled Users** (from mock data):
- Michael Chen
- Jennifer Wu

---

### Sales Owner
**Can**:
- **Open cases** in Pending Sales Review → In Sales Review
- Work cases In Sales Review
- Add comments and context
- Complete sales review → Sales Review Complete

**Cannot**:
- Self-select cases from workbasket
- Disposition cases
- Complete cases (only provide feedback)

**Note**: Sales Owner is not a system role but rather identified per case based on client relationship.

---

### View Only
**Can**:
- View all cases and data

**Cannot**:
- Modify any cases
- Change case status
- Add comments

---

## Data Examples

### Example 1: Auto-Closed Case
```typescript
{
  id: '312-2025-AUTO-001',
  clientName: 'Standard Manufacturing Inc',
  lineOfBusiness: 'GB/GM',
  status: 'Complete',
  autoClosed: true,
  modelOutcome: 'No additional CAM escalation required',
  completionDate: '2025-10-26',
  model312Score: 3.2 // Low risk
}
```

---

### Example 2: Pending Sales Review (PB LOB)
```typescript
{
  id: '312-2025-SALES-001',
  clientName: 'Meridian Capital Holdings',
  lineOfBusiness: 'PB', // Private Bank - Sales review allowed
  status: 'Pending Sales Review',
  assignedTo: 'Michael Chen', // Analyst
  salesOwner: 'David Park', // Sales owner identified
  autoClosed: false,
  // Waiting for David Park to open case
}
```

---

### Example 3: Consumer LOB (No Sales Review)
```typescript
{
  id: '312-2025-CONS-001',
  clientName: 'Maria Rodriguez',
  lineOfBusiness: 'Consumer', // Consumer - NO sales review option
  status: 'In Progress',
  assignedTo: 'Lisa Brown',
  autoClosed: false,
  // Analyst can only self-solve, cannot route to sales
}
```

---

### Example 4: Completed - No Escalation
```typescript
{
  id: '312-2025-COMP-001',
  clientName: 'United Manufacturing Corp',
  lineOfBusiness: 'GB/GM',
  status: 'Complete',
  assignedTo: 'Michael Chen',
  autoClosed: false,
  modelOutcome: 'No additional CAM escalation required',
  derivedDisposition: 'No additional CAM escalation required',
  completionDate: '2025-10-24'
}
```

---

### Example 5: Completed - Escalated
```typescript
{
  id: '312-2025-ESC-001',
  clientName: 'Offshore Holdings Ltd',
  lineOfBusiness: 'PB',
  status: 'Complete',
  assignedTo: 'Sarah Mitchell',
  autoClosed: false,
  modelOutcome: 'CAM Case Escalated',
  derivedDisposition: 'CAM Case Escalated',
  completionDate: '2025-10-19',
  trmsCase: {
    caseId: 'TRMS-2025-1234',
    caseType: 'AML Investigation',
    status: 'Open'
  }
}
```

---

### Example 6: Defect Remediation
```typescript
{
  id: '312-2025-REM-001',
  clientName: 'Global Enterprise Solutions',
  lineOfBusiness: 'GB/GM',
  status: 'Defect Remediation',
  assignedTo: 'Jennifer Wu', // M&I entitled
  autoClosed: false,
  modelOutcome: 'No additional CAM escalation required',
  derivedDisposition: 'No additional CAM escalation required',
  originalCompletionDate: '2025-09-28', // PRESERVED for SLA
  remediationDate: '2025-10-15', // When reopened
  defectRemediationFlag: true
}
```

---

## Key Validation Rules

### Rule 1: Auto-Close Validation
```typescript
if (autoClosed === true) {
  assert(modelOutcome === 'No additional CAM escalation required');
  assert(status === 'Complete');
  assert(derivedDisposition === undefined); // Not manually reviewed
}
```

---

### Rule 2: Manual Completion
```typescript
if (autoClosed === false && status === 'Complete') {
  assert(derivedDisposition !== undefined);
  assert(modelOutcome !== undefined);
  assert(completionDate !== undefined);
}
```

---

### Rule 3: Sales Review LOB Restriction
```typescript
if (status === 'Pending Sales Review' || status === 'In Sales Review') {
  const restrictedLOBs = ['CI', 'Consumer'];
  assert(!restrictedLOBs.includes(lineOfBusiness));
}
```

---

### Rule 4: Sales Owner Opens Case
```typescript
// Transition: Pending Sales Review → In Sales Review
if (fromStatus === 'Pending Sales Review' && toStatus === 'In Sales Review') {
  assert(actor === salesOwner); // Sales owner opens the case
}
```

---

### Rule 5: Defect Remediation Preservation
```typescript
if (defectRemediationFlag === true) {
  assert(originalCompletionDate !== undefined);
  assert(new Date(originalCompletionDate) < new Date(remediationDate));
  assert(user.hasM_I_Entitlement === true);
}
```

---

## Reporting Considerations

### SLA Metrics
For **defect remediation cases**, use the **original completion date** for SLA reporting:

```typescript
const slaDate = caseData.defectRemediationFlag 
  ? caseData.originalCompletionDate  // Use original date
  : caseData.completionDate;
```

---

### Metrics

**Auto-Close Rate**:
```typescript
const autoCloseRate = (autoClosedCases / totalCases) * 100;
```

**Escalation Rate**:
```typescript
const escalationRate = (escalatedCases / manualReviewCases) * 100;
```

**Sales Review Rate** (by LOB):
```typescript
const salesReviewRate = (salesReviewCases / eligibleLOBCases) * 100;
// Only count GB/GM, PB, ML cases as eligible
```

**Remediation Rate**:
```typescript
const remediationRate = (remediatedCases / completedCases) * 100;
```

---

## Summary of Changes

### ✅ CORRECTED: Disposition Terminology
- **OLD**: "312 Activity in line with expected activity"
- **NEW**: "No additional CAM escalation required"
- **OLD**: "312 Activity Escalated"
- **NEW**: "CAM Case Escalated"

### ✅ CORRECTED: Sales Owner Opens Case
- **Pending Sales Review → In Sales Review**: Sales Owner (not analyst)
- Analyst routes TO sales, Sales Owner opens and completes review

### ✅ NEW: LOB Restrictions
- Sales review **NOT available** for CI and Consumer LOBs
- Only available for GB/GM, PB, ML

### ✅ PRESERVED: M&I Remediation Logic
- M&I entitlement required to reopen cases
- Original completion date preserved for SLA reporting
- M&I entitled users: Michael Chen, Jennifer Wu

---

## Related Files

- `/types/index.ts` - Updated disposition and model outcome types
- `/data/caseFlowValidation.ts` - Status transition validation
- `/data/caseFlowScenarios.ts` - Mock cases with new dispositions and LOB fields
- `/data/caseFlowHelpers.ts` - **NEW** Helper functions for LOB checks and validations
- `/data/caseFlowActivities.ts` - Activity logs
- `/STATUS_TRANSITION_MATRIX.md` - Status transition matrix

---

**Document Version**: 2.0 (Corrected)  
**Last Updated**: October 26, 2025  
**Status**: Official - Reflects corrected requirements with disposition terminology, sales owner actions, and LOB restrictions
