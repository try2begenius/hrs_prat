# How to Access the Enhanced Case UI

## 🎯 Quick Access Guide

The new **5-section Case UI** is now integrated into the CAM Platform and can be accessed through multiple routes.

---

## 📍 Access Methods

### Method 1: Via "My Cases" (Individual Worklist)
1. **Login as any user** (use the User Switcher in top-right)
2. Click **"My Cases"** in the left sidebar
3. Find a case assigned to you
4. Click **"View Details"** button on any case row
5. ✅ You'll see the **Enhanced Case UI** with expandable sections

### Method 2: Via "Case Worklist" (Full Worklist)
1. **Login as a Manager or Analyst** (Sarah Mitchell, Michael Chen, etc.)
2. Click **"Case Worklist"** in the left sidebar
3. Browse all cases in the system
4. Click **"View"** button on any case row
5. ✅ Enhanced Case UI opens

### Method 3: Via Dashboard
1. Click **"Dashboard"** in the left sidebar
2. Find the **"Recent Cases"** or **"High Priority Cases"** card
3. Click on any case name link
4. ✅ Enhanced Case UI opens

---

## 👥 Recommended Test Users

Switch between these users to see different perspectives:

| User | Role | Password | What to Test |
|------|------|----------|--------------|
| **Sarah Mitchell** | Central Team Manager | - | Full access, can assign cases |
| **Michael Chen** | Central Team Analyst | - | Review and disposition cases |
| **David Park** | Sales Owner | - | Sales Owner worklist and review section |
| **Jennifer Wu** | Central Team Analyst | - | M&I entitlement access |

**To Switch Users**: Use the dropdown in the top-right corner with the user icon.

---

## 🔍 What Cases Have Enhanced UI Data?

### Case with Full 312 Data
**Case ID**: `312-2025-001`  
**Client**: GlobalTech Industries Corp  
**Assigned To**: Sarah Mitchell  
**Features**:
- ✅ Section 1: Case Banner (always visible with GCI/MP ID and Party ID)
- ✅ Section 2: Case and Client Details (expanded by default)
- ✅ Section 3: 312 Case Review (fully functional)
  - Read-only 312 data fields
  - 4 required questions with validation
  - Case action dropdown (Complete/TRMS/Send to Sales)
  - Save/Submit functionality
- ⏳ Section 4: CAM Case (not yet implemented)
- ⏳ Section 5: Sales Owner Review (not yet implemented)

### Other Test Cases
All cases in the system will show the Case UI, but only `312-2025-001` has the complete enhanced data structure for Section 3.

---

## 🎨 UI Features to Test

### Section 1: Case Banner (Always Visible)
- Sticky at top while scrolling
- Shows: Case ID, Client Name, GCI, Client ID, Status Badge, Assignee
- "Back to Worklist" button
- Color-coded status badge

### Section 2: Case and Client Details (Collapsible)
- Numbered badge: **1** in blue circle
- Click to expand/collapse
- Responsive 3-column grid
- Shows 312 fields (if 312 case)
- Shows CAM fields (if CAM case)
- LOB, NAICS, Client Owners, etc.

### Section 3: 312 Case (Collapsible, 312 Cases Only)
- Numbered badge: **2** in blue circle
- **Read-Only Section**:
  - 312 Due Date, Model Result, Description
  - Expected Activity (Volume & Value) broken out by LOB
  - Purpose of Relationship/Account
  - Source of Funds
- **Actionable Questions**:
  - Question 1: Change to expectations? (Yes/No radio)
    - If Yes → Rationale dropdown appears
  - Question 2: Change to expectations? (Yes/No radio)
    - If Yes → Comments textarea appears
  - Question 3: Misaligned activity? (Yes/No radio)
    - If Yes → Comments textarea appears
  - Question 4: Case Action dropdown
    - Complete - No action
    - Complete - TRMS filed (shows TRMS# input)
    - Send to Sales (shows Sales Owner dropdown)
- **Action Buttons**:
  - Cancel: Returns to worklist
  - Save: Validates and saves (shows toast)
  - Submit: Final submission (shows confirmation dialog, locks section)

### Validation Testing
1. **Try to Save without answering Question 1**
   - ⚠️ Validation warning appears
2. **Select "Yes" for Question 1, then try to Save without selecting rationale**
   - ⚠️ Validation warning appears
3. **Select "Complete - TRMS filed" without entering TRMS#**
   - ⚠️ Validation warning appears
4. **Fill all required fields and click Submit**
   - ℹ️ Confirmation dialog appears
   - After confirming, section locks with green banner
   - 🔒 "Submitted" badge appears
   - All fields become read-only

---

## 🚀 Step-by-Step Testing Flow

### Test Scenario 1: Analyst Reviews and Completes 312 Case

1. **Switch to Michael Chen** (Analyst)
2. Go to **"My Cases"**
3. Click **"View Details"** on `312-2025-001`
4. ✅ See Case Banner at top
5. ✅ Section 2 auto-expanded showing case details
6. Click to **expand Section 3** (312 Case)
7. Review the read-only 312 data
8. Scroll to **Required Questions**
9. **Answer Question 1**: Select "No"
10. **Answer Question 2**: Select "No"
11. **Answer Question 3**: Select "No"
12. **Question 4 (Case Action)**: Select "Complete – No action"
13. Click **"Save"** button
    - ✅ Toast notification: "312 Case responses saved successfully"
14. Click **"Submit"** button
    - ⚠️ Confirmation dialog appears
15. Click **"Confirm"**
    - ✅ Section locks
    - 🔒 "Submitted" badge appears
    - ✅ Green banner: "This section has been submitted and is now read-only"
    - ✅ Toast: "312 Case submitted successfully"

### Test Scenario 2: Analyst Routes to Sales

1. **Open case** `312-2025-001`
2. **Expand Section 3**
3. **Answer all questions**
4. **Question 4**: Select "Send to Sales (PB, ML, GB/GM only)"
5. **Sales Owner dropdown appears**
6. Select **"David Park"** from dropdown
7. Click **"Save"**
8. Click **"Submit"**
9. Confirm
10. ✅ Case should route to David Park (in real implementation)

### Test Scenario 3: Incomplete Form Validation

1. **Open case** `312-2025-001`
2. **Expand Section 3**
3. Leave Question 1 blank
4. Click **"Save"**
5. ⚠️ Alert dialog: "Question 1 is required."
6. Click **"OK"**
7. Answer **Question 1: Yes**
8. Click **"Save"** (without filling Q 1.1)
9. ⚠️ Alert dialog: "Please provide rationale for Question 1.1"
10. Select rationale from dropdown
11. Continue filling form
12. ✅ Save succeeds when all required fields complete

---

## 📊 Current Implementation Status

| Section | Status | Accessible | Functional |
|---------|--------|------------|------------|
| **Section 1: Case Banner** | ✅ Complete | ✅ Yes | ✅ Yes |
| **Section 2: Case & Client Details** | ✅ Complete | ✅ Yes | ✅ Yes |
| **Section 3: 312 Case** | ✅ Complete | ✅ Yes | ✅ Yes |
| **Section 4: CAM Case** | ⏳ In Progress | ❌ No | ❌ No |
| **Section 5: Sales Owner Review** | ⏳ In Progress | ❌ No | ❌ No |

**Overall Progress**: ~30% Complete

---

## 🐛 Known Limitations

1. **Section 4 (CAM Case)** - Not yet implemented
   - Monitoring dashboard tables not visible
   - CAM disposition questions not available

2. **Section 5 (Sales Owner Review)** - Not yet implemented
   - Sales Owner cannot yet respond to cases
   - Privacy-filtered view not available

3. **Mock Data** - Limited
   - Only `312-2025-001` has full enhanced data
   - Other cases will show basic structure but may have missing fields

4. **Persistence** - In-Memory Only
   - Responses are stored in component state only
   - Refreshing page will reset responses
   - In production, this would save to backend

5. **Status Transitions** - Not Wired
   - Submitting 312 section doesn't update case status yet
   - "Send to Sales" doesn't reassign case yet

---

## 🎯 What You Should See

### When Opening Case `312-2025-001`:

```
┌─────────────────────────────────────────────────────────┐
│ ← Back to Worklist              [In Progress] ← Badge  │
├─────────────────────────────────────────────────────────┤
│ Case ID: 312-2025-001    Client: GlobalTech Industries │
│ GCI: GCI-892341          Client ID: GCI-892341          │
│ Status: In Progress      Assignee: Sarah Mitchell       │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ ⊕ 1  Case and Client Details                       ▼   │  ← Expanded by default
├─────────────────────────────────────────────────────────┤
│ [Grid of case fields]                                   │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ ⊕ 2  312 Case                                       ▼   │  ← Click to expand
├─────────────────────────────────────────────────────────┤
│ [When expanded, shows all 312 fields and questions]    │
│                                                          │
│ [Action buttons at bottom: Cancel | Save | Submit]      │
└─────────────────────────────────────────────────────────┘
```

---

## 💡 Tips for Testing

1. **Use Browser DevTools Console** - Check for any React errors
2. **Test Responsiveness** - Resize browser to see grid adapt
3. **Test Validation** - Try to break the form (skip fields, etc.)
4. **Test User Switching** - Switch between users to see different permissions
5. **Check Toast Notifications** - Look for success/error toasts in bottom-right

---

## 📞 Next Steps

To see the **complete Case UI** with all 5 sections:

1. **Section 4: CAM Case** needs to be implemented (~700 lines)
   - Monitoring dashboard with 7 data grid subsections
   - CAM disposition questions

2. **Section 5: Sales Owner Review** needs to be implemented (~450 lines)
   - Privacy-filtered data display
   - Sales response form

3. **Mock Data Enhancement** (~600 lines)
   - Add monitoring dashboard data
   - Add case processor comments
   - Add more test cases

**Would you like me to continue building these sections?**

---

## 🎓 Understanding the Structure

### File Organization

```
/components/
  CaseDetailsEnhanced.tsx          ← Main container (Sections 1-2 + integration)
  /case-sections/
    Section312Case.tsx             ← Section 3 (Complete ✅)
    SectionCAMCase.tsx             ← Section 4 (Not created ❌)
    SectionSalesReview.tsx         ← Section 5 (Not created ❌)

/types/index.ts                    ← All TypeScript interfaces ✅

/data/enhancedMockData.ts          ← Mock data (partially enhanced)
```

### How It Works

1. **App.tsx** routes to `CaseDetailsEnhanced` when viewing a case
2. **CaseDetailsEnhanced** loads case data and manages state for all sections
3. **Section components** are self-contained with their own UI and logic
4. **Validation functions** in main component ensure data integrity
5. **Alert dialogs** provide user feedback for validation and confirmations

---

**Last Updated**: October 26, 2025  
**Version**: 1.0  
**Status**: Sections 1-3 Accessible and Functional
