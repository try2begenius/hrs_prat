# Quick User/Persona Switch Guide

## How to Switch Users to Test Different Cases

The application defaults to **Sarah Mitchell (Central Team Manager)**. To test cases assigned to different users, you need to switch personas using the user selector in the application header.

---

## Finding the User Selector

**Location**: Top right corner of the application header

**Look for**:
- User avatar/icon (shows initials like "SM", "MC", "JW", etc.)
- User name and role
- Dropdown arrow

**Click** on the user info to open the persona selector dropdown

---

## Available Test Personas

### Central Team Managers
1. **Sarah Mitchell** (Default)
   - ID: USR-001
   - Avatar: SM
   - Has M&I Entitlement
   - LOBs: GB/GM, PB, ML
   - Can assign/reassign cases

2. **Carlos Rivera**
   - ID: USR-005
   - Avatar: CR
   - Has M&I Entitlement
   - LOBs: All LOBs
   - Can assign/reassign cases

### Central Team Analysts
3. **Michael Chen** ⭐ (USE THIS FOR CASE 312-2025-PROG-300)
   - ID: USR-002
   - Avatar: MC
   - Has M&I Entitlement
   - LOBs: GB/GM, PB
   - This is who you need to test case **312-2025-PROG-300**

4. **Jennifer Wu** ⭐ (For Sales Review Cases)
   - ID: USR-003
   - Avatar: JW
   - Has M&I Entitlement
   - LOBs: ML, Consumer, CI
   - Assigned to cases **312-2025-PSR-400** and **312-2025-SRC-600**

5. **Lisa Brown**
   - ID: USR-006
   - Avatar: LB
   - No M&I Entitlement
   - LOBs: GB/GM, ML

6. **Kevin Rogers**
   - ID: USR-007
   - Avatar: KR
   - No M&I Entitlement
   - LOBs: Consumer, CI

### Sales Owners
7. **David Park** ⭐ (For Sales Review Testing)
   - ID: USR-004
   - Avatar: DP
   - LOBs: GB/GM
   - Access Sales Owner Worklist
   - Can see cases **312-2025-PSR-400**, **312-2025-ISR-500**, **312-2025-SRC-600**

8. **Amanda Torres**
   - ID: USR-008
   - Avatar: AT
   - LOBs: PB, ML

### View Only
9. **Robert Anderson**
   - ID: USR-009
   - Avatar: RA
   - Can view but cannot edit or action cases

---

## Step-by-Step: How to Test Case 312-2025-PROG-300

### Problem
You're currently logged in as **Sarah Mitchell** (Manager), but case **312-2025-PROG-300** is assigned to **Michael Chen** (Analyst). This case only appears in Michael Chen's Individual Worklist.

### Solution - Switch to Michael Chen

**Step 1**: Find the user selector
- Look at the **top right** of the application
- Click on the user avatar/name showing "Sarah Mitchell"

**Step 2**: Select Michael Chen
- In the dropdown, select **Michael Chen**
- Avatar shows: **MC**
- Role shows: **Central Team Analyst**

**Step 3**: Navigate to Individual Worklist
- From the left sidebar, click **"My Cases"** or **"Individual Worklist"**
- Alternative: Click on "Case Worklist" but you'll need to filter

**Step 4**: Find the case
- Search for case ID: **312-2025-PROG-300**
- OR scroll through the list - it should be near the top
- Client Name: **Premier Trading Partners LLC**

**Step 5**: Open the case
- Click on the case row or the "View Case" button
- You should now see the full case details

---

## Quick Reference: Which User for Which Test Case

| Case ID | Case Name | Assigned To | Persona to Use |
|---------|-----------|-------------|----------------|
| 312-2025-AUTO-100 | Reliable Logistics | System | Any user (visible to all) |
| 312-2025-UNASSIGN-200 | Global Tech Solutions | Unassigned | Any Manager (to assign) |
| **312-2025-PROG-300** | **Premier Trading Partners** | **Michael Chen** | **Switch to: Michael Chen** |
| 312-2025-PSR-400 | Apex Capital Ventures | Jennifer Wu | Switch to: Jennifer Wu or David Park (Sales) |
| 312-2025-ISR-500 | Meridian Holdings | Michael Chen | Switch to: Michael Chen or David Park (Sales) |
| 312-2025-SRC-600 | Sterling Investment Partners | Jennifer Wu | Switch to: Jennifer Wu |
| 312-2025-COMP-700 | Northeast Distribution | Michael Chen | Switch to: Michael Chen (or any - it's complete) |
| 312-2025-ESC-800 | Offshore Financial Services | Sarah Mitchell | Default user (or any - it's complete) |
| 312-2025-ESC-900 | High Risk Trading | Carlos Rivera | Switch to: Carlos Rivera (or any - it's complete) |
| 312-2025-REM-1000 | Pacific Rim Imports | Jennifer Wu | Switch to: Jennifer Wu |

---

## Tips for Testing

### Viewing Cases in Different States

**Unassigned Cases** (Workbasket):
- Any Manager or Analyst can see these
- Use Sarah Mitchell or Carlos Rivera to assign them

**In Progress Cases** (Individual Worklist):
- Only visible to the assigned user
- Must switch to that user's persona

**Pending/In Sales Review**:
- Analyst view: Switch to assigned analyst (Jennifer Wu, Michael Chen)
- Sales Owner view: Switch to Sales Owner (David Park, Amanda Torres)

**Complete Cases**:
- Visible to all users (in completed cases list)
- Anyone can view for reference

### Testing Sales Review Workflow

For **complete sales review testing**, you need to switch between personas:

1. **Start as Analyst** (Jennifer Wu)
   - View case 312-2025-PSR-400
   - See it's in "Pending Sales Review"

2. **Switch to Sales Owner** (David Park)
   - Navigate to Sales Owner Worklist
   - Open same case
   - See Sales Owner Review section
   - Can provide feedback

3. **Switch back to Analyst** (Jennifer Wu)
   - Case now shows sales feedback
   - Can complete disposition

---

## Common Issues and Solutions

### "I don't see any cases in My Cases"
**Solution**: You're viewing as a user with no assigned cases. Switch to:
- Michael Chen (has multiple assigned cases)
- Jennifer Wu (has multiple assigned cases)

### "I can't see case 312-2025-PROG-300"
**Solution**: You're not logged in as Michael Chen. Switch to Michael Chen persona.

### "I don't see Sales Owner Worklist"
**Solution**: You're logged in as an Analyst or Manager. Switch to David Park or Amanda Torres (Sales Owner role).

### "Case shows but I can't open it"
**Solution**: Check if you have the right entitlements:
- 312 cases require `has312Access: true`
- CAM cases require `hasCAMAccess: true`
- Employee cases require `hasEmployeeCaseAccess: true`

---

## Testing Workflow - Recommended Persona Sequence

To test the complete 312 CAM workflow, switch personas in this order:

### Test Sequence 1: Auto-Close
1. **Any user** → View 312-2025-AUTO-100

### Test Sequence 2: Assignment
1. **Sarah Mitchell** (Manager) → Assign 312-2025-UNASSIGN-200
2. **Michael Chen** (Analyst) → See it in My Cases

### Test Sequence 3: In Progress
1. **Michael Chen** (Analyst) → Open 312-2025-PROG-300

### Test Sequence 4: Sales Review
1. **Jennifer Wu** (Analyst) → Open 312-2025-PSR-400
2. **David Park** (Sales) → Open same case from Sales Worklist
3. **David Park** → Submit response
4. **Jennifer Wu** → View response and complete

### Test Sequence 5: Completions
1. **Michael Chen** → View 312-2025-COMP-700 (no escalation)
2. **Sarah Mitchell** → View 312-2025-ESC-800 (TRMS filed)
3. **Carlos Rivera** → View 312-2025-ESC-900 (client closed)

### Test Sequence 6: Remediation
1. **Jennifer Wu** (with M&I) → Open 312-2025-REM-1000

---

## User Entitlements Quick Reference

| User | Role | 312 Access | CAM Access | M&I | LOBs |
|------|------|-----------|-----------|-----|------|
| Sarah Mitchell | Manager | ✅ | ✅ | ✅ | GB/GM, PB, ML |
| Carlos Rivera | Manager | ✅ | ✅ | ✅ | All |
| **Michael Chen** | **Analyst** | **✅** | **✅** | **✅** | **GB/GM, PB** |
| **Jennifer Wu** | **Analyst** | **✅** | **✅** | **✅** | **ML, Consumer, CI** |
| Lisa Brown | Analyst | ✅ | ✅ | ❌ | GB/GM, ML |
| Kevin Rogers | Analyst | ✅ | ✅ | ❌ | Consumer, CI |
| **David Park** | **Sales Owner** | **✅** | **❌** | **❌** | **GB/GM** |
| Amanda Torres | Sales Owner | ✅ | ❌ | ❌ | PB, ML |
| Robert Anderson | View Only | ✅ | ✅ | ❌ | All (read-only) |

**Legend**:
- ✅ = Has access
- ❌ = No access
- M&I = Monitoring & Investigations (allows defect remediation)

---

## Where is the User Switcher?

The user switcher should be visible in the **application header** (top bar). 

If you can't find it, look for:
- A dropdown menu in the top right
- User name display
- Avatar with initials
- A "Switch User" or "User Profile" button

**Click on it** to see the list of available test personas.

---

## Next Steps

After switching to the correct user:

1. **Verify** you see the user name in the header
2. **Navigate** to the appropriate worklist:
   - **My Cases** (Individual Worklist) for assigned cases
   - **Case Worklist** (Workbasket) for unassigned cases
   - **Sales Owner Worklist** for sales review cases (Sales Owners only)
3. **Search** for the case ID you want to test
4. **Click** to open the case details

---

**Still having issues?**

Make sure:
- ✅ You clicked the user dropdown/selector
- ✅ You selected the correct persona (Michael Chen for 312-2025-PROG-300)
- ✅ You're in "My Cases" or "Individual Worklist" (not general Workbasket)
- ✅ The case is assigned to the persona you selected

---

**Last Updated**: November 1, 2025  
**Version**: 1.0
