# 312 CAM Workflow Diagram Guide

## Overview

The **Workflow Diagram** is an interactive visual tool that explains the complete 312 CAM case lifecycle from creation to closure. It provides a clear, color-coded representation of all workflow paths, decision points, and outcomes.

---

## How to Access

### Method 1: Navigation Menu
1. Launch the CAM Platform application
2. Look at the left sidebar navigation menu
3. Click on **"Workflow Diagram"** (icon: GitBranch)
4. The diagram will load in the main content area

### Method 2: Direct Link
- The Workflow Diagram is available to **all user personas**
- No special permissions required

---

## Three Workflow Views

The diagram is organized into **3 interactive tabs**:

### 📊 Tab 1: 312 Case Flow
**What it shows:** Complete lifecycle of a 312 case from creation to completion

**Key Sections:**
- ✅ **Path 1: Auto-Close** - Low-risk cases automatically closed by system
- 🔄 **Path 2: Manual Review** - Medium/High/Critical risk cases requiring analyst review
- 📝 **Path 2A: Direct Completion** - Analyst completes without sales input
- 👥 **Path 2B: Sales Review** - Cases requiring sales owner context
- 🔴 **Special Path: Defect Remediation** - Cases reopened for quality review

**Color Coding:**
- 🟢 **Green** = Auto-close path, successful completion
- 🔵 **Blue** = Standard manual review process
- 🟣 **Purple** = Direct completion (no sales review)
- 🟠 **Orange** = Sales review workflow
- 🔴 **Red** = Remediation workflow

**Test Cases Referenced:**
Each path includes specific test case IDs you can use to see that workflow in action.

---

### 👥 Tab 2: Sales Review Flow
**What it shows:** Detailed 6-step process of sales owner involvement

**The 6 Steps:**
1. **Analyst Initiates Sales Review** - Central Team Analyst requests sales context
2. **Sales Owner Receives Case** - Case appears in Sales Owner Worklist
3. **Sales Owner Opens Case** - Status changes to "In Sales Review"
4. **Sales Owner Provides Feedback** - Business context and relationship information added
5. **Returned to Analyst** - Case status: "Sales Review Complete"
6. **Analyst Completes Case** - Final disposition with sales context

**Prerequisites for Sales Review:**
- ✅ Case type: 312 Review
- ✅ Line of Business: GB/GM, PB, or ML only
- ✅ Current status: In Progress
- ❌ Consumer and CI cannot route to sales

**Privacy Filtering:**
Sales owners see:
- ✅ Case details, 312 case info, model results
- ✅ Expected activity data
- ✅ Processor comments/questions

Sales owners do NOT see:
- ❌ Transaction details
- ❌ Monitoring alerts
- ❌ Detailed investigation data

**Test Cases:**
- **312-2025-PSR-400** - Pending Sales Review state
- **312-2025-ISR-500** - In Sales Review state
- **312-2025-SRC-600** - Sales Review Complete state

---

### 🚨 Tab 3: CAM Escalation Flow
**What it shows:** Four possible disposition outcomes for completed 312 cases

**Outcome 1: No Escalation** 🟢
- **Disposition:** "No additional CAM escalation required"
- **When Used:** Activity explained by business model, no red flags
- **Result:** No CAM case created
- **Test Case:** 312-2025-COMP-700

**Outcome 2: CAM Review** 🔵
- **Disposition:** "Route to CAM Review"
- **When Used:** Requires enhanced monitoring, ongoing tracking
- **Result:** Separate CAM case created for monitoring
- **Test Case:** Available in case flow scenarios

**Outcome 3: TRMS Investigation** 🔴
- **Disposition:** "TRMS Filed"
- **When Used:** Suspicious activity, potential AML/BSA violation, may require SAR
- **Result:** TRMS case created (Enhanced Due Diligence - AML)
- **Test Case:** 312-2025-ESC-800 (TRMS-2025-8234)

**Outcome 4: Relationship Exit** ⚫
- **Disposition:** "Client Closed"
- **When Used:** Unacceptable risk, cannot verify business, sanctions/reputational concerns
- **Result:** Client relationship terminated, exit date recorded, SAR filed if applicable
- **Test Case:** 312-2025-ESC-900 (SAR-2025-4567)

**Disposition Decision Matrix:**
The tab includes a helpful table showing:
- Risk finding → Recommended disposition → Whether CAM case is created

---

## Visual Design Elements

### Status Badges
Each status in the workflow is represented by a colored badge:

| Badge Color | Status | Meaning |
|-------------|--------|---------|
| Gray | Unassigned | In workbasket, awaiting assignment |
| Blue | In Progress | Assigned to analyst for review |
| Orange (light) | Pending Sales Review | Routed to sales, not yet opened |
| Orange (medium) | In Sales Review | Sales owner actively reviewing |
| Orange (dark) | Sales Review Complete | Returned to analyst with feedback |
| Green | Complete | Case closed with disposition |
| Green (dark) | Auto-Closed | System-closed, low risk |
| Red | Defect Remediation | Reopened for quality review |

### Arrows & Flow Indicators
- **ArrowDown** ⬇️ - Sequential progression
- **ArrowRight** ➡️ - Lateral transition or parallel path
- **Decision Points** ⚠️ - Yellow boxes with alert icon

### Cards & Containers
- **Solid borders** - Active paths
- **Dashed borders** - Optional paths
- **Colored backgrounds** - Path categorization
- **White inset boxes** - Test case references

---

## How to Use the Diagram

### For Learning the Workflow
1. Start with **Tab 1: 312 Case Flow**
2. Follow the arrows from top to bottom
3. Note the two main branches (auto-close vs manual review)
4. Understand decision points (yellow boxes)
5. See where paths diverge and converge

### For Testing
1. Each workflow section includes **test case references**
2. Note the case ID (e.g., 312-2025-PROG-300)
3. Note the user persona to switch to
4. Open that case in the application to see the workflow state
5. Compare what you see in the case with the diagram

### For Training
1. Use the diagram as a visual aid during training sessions
2. Reference specific tabs when explaining different processes
3. Point to test cases for hands-on practice
4. Use the Status Legend at the bottom to explain status meanings

### For Documentation
1. Screenshot specific workflow paths for documentation
2. Reference the diagram in process documents
3. Use as a quick reference guide for analysts and managers
4. Include in onboarding materials

---

## Interactive Features

### Tabbed Navigation
- Click between the three tabs to switch views
- Each tab is self-contained with its own workflow
- Tabs remember your position when switching

### Scrollable Content
- Diagrams are vertically scrollable for complex workflows
- Horizontal scrolling on smaller screens for wide content
- Tables and matrices are fully scrollable

### Responsive Design
- Adapts to different screen sizes
- Mobile-friendly layout adjustments
- Cards stack vertically on narrow screens

---

## Common Questions

### Q: Can I print the workflow diagram?
**A:** Yes! Use your browser's print function. The diagram is designed to be print-friendly. Consider printing each tab separately for better clarity.

### Q: Do I need special permissions to view the diagram?
**A:** No. The Workflow Diagram is available to all user personas without restriction.

### Q: Can I export the diagram?
**A:** Currently, the diagram is view-only within the application. You can take screenshots or print to PDF for external use.

### Q: Are the test cases real?
**A:** The test cases reference mock data scenarios that are pre-loaded in the application. They represent realistic cases demonstrating each workflow state.

### Q: What if a workflow step is different in my environment?
**A:** This diagram represents the standard workflow. Some organizations may have customized processes. Consult your local process documentation if differences exist.

---

## Related Documentation

For more detailed information, refer to:

- **312_CAM_WORKFLOW_TESTING_GUIDE.md** - Step-by-step testing procedures for each workflow scenario
- **VISUAL_QUICK_TEST_312_CASES.md** - Quick visual guide for finding and testing cases
- **312_CAM_WORKFLOW_DEMO.md** - Detailed specifications and data for all 10 test scenarios
- **OFFICIAL_CASE_WORKFLOW.md** - Complete workflow specification and business rules
- **STATUS_TRANSITION_MATRIX.md** - Valid status transitions and state management
- **DATA_VISIBILITY_MATRIX.md** - Role-based data access and privacy rules

---

## Updates and Maintenance

**Version:** 1.0  
**Last Updated:** November 3, 2025  
**Maintained By:** CAM Platform Development Team

The Workflow Diagram is kept in sync with the official workflow specifications and test data. If you notice any discrepancies between the diagram and actual system behavior, please report them to the development team.

---

## Tips for Maximum Benefit

### For Analysts
- ✅ Use the diagram to understand all possible case paths
- ✅ Reference when deciding whether to route to sales
- ✅ Check disposition decision matrix before completing cases
- ✅ Understand what data sales owners can and cannot see

### For Managers
- ✅ Use during team training and onboarding
- ✅ Reference when explaining case assignment logic
- ✅ Show team members where their cases are in the workflow
- ✅ Use to explain the defect remediation process

### For Sales Owners
- ✅ Understand the full sales review process (Tab 2)
- ✅ See what happens before and after your involvement
- ✅ Know what data you can access vs. what's filtered
- ✅ Understand your role in the complete workflow

### For Administrators
- ✅ Use as documentation artifact
- ✅ Reference in system design discussions
- ✅ Include in audit and compliance documentation
- ✅ Share with stakeholders to explain the system

---

## Keyboard Shortcuts

- **Tab** - Navigate between interactive elements
- **Enter** or **Space** - Activate tab selection
- **Arrow Keys** - Navigate within tabs (when focused)
- **Ctrl/Cmd + F** - Search within the page (browser function)

---

## Feedback

If you have suggestions for improving the Workflow Diagram or notice any inaccuracies, please contact the CAM Platform development team. We welcome feedback to make this tool more useful for all users.

---

**Remember:** The Workflow Diagram is a **living document** represented as an interactive component. As the workflow evolves, the diagram will be updated to reflect the current process.
