import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { Progress } from "./ui/progress";
import { CheckCircle2, XCircle, AlertCircle, FileText, PlayCircle, Calendar, Shield, TrendingUp, Lock, Zap, Database } from 'lucide-react';
import { mockClientsForEvaluation, calculateStats, ClientForEvaluation } from '../data/caseCreationMockData';

export function CaseCreationLogic() {
  const [clients] = useState<ClientForEvaluation[]>(mockClientsForEvaluation);
  const [selectedClient, setSelectedClient] = useState<ClientForEvaluation | null>(null);
  const stats = calculateStats(clients);

  const getDecisionBadge = (decision?: string) => {
    switch (decision) {
      case 'Full Review':
        return <Badge variant="destructive" className="gap-1"><AlertCircle className="h-3 w-3" />Full Review</Badge>;
      case 'Auto-Close':
        return <Badge variant="secondary" className="gap-1 bg-green-100 text-green-700 border-green-200"><CheckCircle2 className="h-3 w-3" />Auto-Close</Badge>;
      case 'Not Applicable':
        return <Badge variant="outline" className="gap-1"><XCircle className="h-3 w-3" />N/A</Badge>;
      case 'Pending 312':
        return <Badge variant="outline" className="gap-1 bg-orange-50 text-orange-700 border-orange-200"><Lock className="h-3 w-3" />Pending 312</Badge>;
      default:
        return <Badge variant="outline">—</Badge>;
    }
  };

  const getRiskBadge = (risk: string) => {
    const variants: Record<string, string> = {
      'High': 'destructive',
      'Elevated': 'default',
      'Standard': 'secondary',
      'Low': 'outline'
    };
    return <Badge variant={variants[risk] as any}>{risk}</Badge>;
  };

  const evaluate312Rules = (client: ClientForEvaluation) => {
    const rules = [];
    
    // Not in 312 scope
    if (!client.has312Flag) {
      return [{
        passed: false,
        rule: 'Client not in 312 population',
        result: 'Not Applicable'
      }];
    }

    // Rule 1: Trigger timing
    if (client.lob === 'PB' || client.lob === 'ML') {
      rules.push({
        passed: client.daysToRefresh <= 180 && client.riskRating === 'High',
        rule: `${client.lob} High Risk - Refresh within 180 days`,
        result: client.daysToRefresh <= 180 && client.riskRating === 'High' ? 'Triggered' : 'Not Met'
      });
    } else if (client.lob === 'GB/GM') {
      if (client.riskRating === 'High') {
        rules.push({
          passed: !!client.dgaDueDate,
          rule: 'GB/GM High Risk - DGA Due Date',
          result: client.dgaDueDate ? 'Triggered' : 'Not Met'
        });
      } else {
        rules.push({
          passed: !!client.familyAnniversaryDate,
          rule: 'GB/GM Elevated/Standard - Family Anniversary',
          result: client.familyAnniversaryDate ? 'Triggered' : 'Not Met'
        });
      }
    }

    // Rule 2: 312 Model Alert
    rules.push({
      passed: client.has312ModelAlert,
      rule: '312 Model Alert Present',
      result: client.has312ModelAlert ? 'Alert Found → Full Review' : 'No Alert → Auto-Close'
    });

    return rules;
  };

  const evaluateCAMRules = (client: ClientForEvaluation) => {
    const rules = [];
    
    // Check if High risk
    if (client.riskRating !== 'High') {
      return [{
        passed: false,
        rule: 'Client must have High risk rating',
        result: 'Not Applicable - Not High Risk'
      }];
    }

    // For 312 Elevated/Standard, CAM is N/A
    if (client.has312Flag && (client.riskRating === 'Elevated' || client.riskRating === 'Standard')) {
      return [{
        passed: false,
        rule: '312 Elevated/Standard risk clients',
        result: 'Not Applicable - CAM not required'
      }];
    }

    // Trigger 1: 312 case not auto-closed
    rules.push({
      passed: client.had312CaseNotAutoClosed,
      rule: 'Had 312 case NOT auto-closed',
      result: client.had312CaseNotAutoClosed ? 'YES (Trigger met)' : 'No'
    });

    // Trigger 2: Case volume
    rules.push({
      passed: client.completedCasesLast12Months > 5,
      rule: `Completed cases last 12 months (${client.completedCasesLast12Months} cases)`,
      result: client.completedCasesLast12Months > 5 ? 'YES (>5 cases)' : `No (${client.completedCasesLast12Months} cases)`
    });

    // Trigger 3: SAR case
    rules.push({
      passed: client.hasSARLast12Months,
      rule: 'SAR case in last 12 months',
      result: client.hasSARLast12Months ? 'YES (SAR filed)' : 'No SAR'
    });

    // Required: No recent CAM review
    rules.push({
      passed: !client.hadCAMReviewLast12Months,
      rule: 'No CAM review in last 12 months (Required)',
      result: !client.hadCAMReviewLast12Months ? 'YES (No recent review)' : 'FAILED - Recent review exists'
    });

    return rules;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2>Case Creation Engine</h2>
          <p className="text-muted-foreground">Real-time evaluation of case creation logic</p>
        </div>
        <Button>
          <PlayCircle className="mr-2 h-4 w-4" />
          Run Evaluation
        </Button>
      </div>

      {/* Summary Statistics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Clients Evaluated</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{stats.totalEvaluated}</div>
            <p className="text-xs text-muted-foreground">
              In evaluation queue
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">312 Full Reviews</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-red-600">{stats.cam312FullReview}</div>
            <Progress value={(stats.cam312FullReview / stats.totalEvaluated) * 100} className="h-1 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">CAM Full Reviews</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-red-600">{stats.camFullReview}</div>
            <Progress value={(stats.camFullReview / stats.totalEvaluated) * 100} className="h-1 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Auto-Closed</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-600">{stats.cam312AutoClose + stats.camAutoClose}</div>
            <p className="text-xs text-muted-foreground">
              {stats.cam312AutoClose} 312 | {stats.camAutoClose} CAM
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Outcome Distribution */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">CAM 312 Case Outcomes</CardTitle>
            <CardDescription>Based on 312 model alerts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 border rounded-md">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <span className="text-sm">Full Review Required</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{stats.cam312FullReview}</span>
                <Badge variant="destructive">{((stats.cam312FullReview / stats.totalEvaluated) * 100).toFixed(0)}%</Badge>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 border rounded-md">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <span className="text-sm">Auto-Closed</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{stats.cam312AutoClose}</span>
                <Badge variant="secondary" className="bg-green-100 text-green-700">{((stats.cam312AutoClose / stats.totalEvaluated) * 100).toFixed(0)}%</Badge>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 border rounded-md">
              <div className="flex items-center gap-2">
                <XCircle className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Not Applicable</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{stats.cam312NotApplicable}</span>
                <Badge variant="outline">{((stats.cam312NotApplicable / stats.totalEvaluated) * 100).toFixed(0)}%</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">CAM Case Outcomes</CardTitle>
            <CardDescription>Based on trigger conditions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 border rounded-md">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <span className="text-sm">Full Review Required</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{stats.camFullReview}</span>
                <Badge variant="destructive">{((stats.camFullReview / stats.totalEvaluated) * 100).toFixed(0)}%</Badge>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 border rounded-md">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <span className="text-sm">Auto-Closed</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{stats.camAutoClose}</span>
                <Badge variant="secondary" className="bg-green-100 text-green-700">{((stats.camAutoClose / stats.totalEvaluated) * 100).toFixed(0)}%</Badge>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 border rounded-md">
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4 text-orange-600" />
                <span className="text-sm">Pending 312 Completion</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{stats.camPending312}</span>
                <Badge variant="outline" className="bg-orange-50 text-orange-700">{((stats.camPending312 / stats.totalEvaluated) * 100).toFixed(0)}%</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="evaluation" className="space-y-4">
        <TabsList>
          <TabsTrigger value="evaluation">Case Evaluation Results</TabsTrigger>
          <TabsTrigger value="details">Rule Evaluation Details</TabsTrigger>
        </TabsList>

        <TabsContent value="evaluation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Client Case Creation Decisions</CardTitle>
              <CardDescription>Click a row to see detailed rule evaluation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client Name</TableHead>
                      <TableHead>LOB</TableHead>
                      <TableHead>Risk</TableHead>
                      <TableHead>Days to Refresh</TableHead>
                      <TableHead>CAM 312 Decision</TableHead>
                      <TableHead>CAM Decision</TableHead>
                      <TableHead>Case IDs</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {clients.map((client) => (
                      <TableRow 
                        key={client.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => setSelectedClient(client)}
                      >
                        <TableCell className="font-medium">{client.legalName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{client.lob}</Badge>
                        </TableCell>
                        <TableCell>{getRiskBadge(client.riskRating)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            {client.daysToRefresh} days
                          </div>
                        </TableCell>
                        <TableCell>{getDecisionBadge(client.cam312Decision)}</TableCell>
                        <TableCell>{getDecisionBadge(client.camDecision)}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {client.cam312CaseId && <div>312: {client.cam312CaseId}</div>}
                          {client.camCaseId && <div>CAM: {client.camCaseId}</div>}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="details" className="space-y-4">
          {!selectedClient ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Select a client from the "Case Evaluation Results" tab to view detailed rule evaluation
              </AlertDescription>
            </Alert>
          ) : (
            <>
              {/* Client Overview */}
              <Card className="border-l-4 border-l-primary">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{selectedClient.legalName}</CardTitle>
                      <CardDescription className="mt-2 space-x-2">
                        <Badge variant="outline">{selectedClient.clientId}</Badge>
                        <Badge variant="outline">{selectedClient.lob}</Badge>
                        {getRiskBadge(selectedClient.riskRating)}
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => setSelectedClient(null)}>
                      Clear Selection
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3 md:grid-cols-3">
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">Refresh Due Date</div>
                      <div className="font-medium">{selectedClient.refreshDueDate}</div>
                      <div className="text-xs text-muted-foreground">{selectedClient.daysToRefresh} days away</div>
                    </div>
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">312 Model Alert</div>
                      <div className="font-medium">{selectedClient.has312ModelAlert ? 'YES' : 'NO'}</div>
                      {selectedClient.has312ModelAlert && (
                        <div className="text-xs text-red-600">Alert detected</div>
                      )}
                    </div>
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">Cases (12 months)</div>
                      <div className="font-medium">{selectedClient.completedCasesLast12Months} completed</div>
                      {selectedClient.hasSARLast12Months && (
                        <div className="text-xs text-red-600">SAR filed</div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 312 Rule Evaluation */}
              <Card className="border-l-4 border-l-primary">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Shield className="h-5 w-5 text-primary" />
                        CAM 312 Rule Evaluation
                      </CardTitle>
                      <CardDescription className="mt-1">312 Model alert determines full review vs auto-close</CardDescription>
                    </div>
                    {getDecisionBadge(selectedClient.cam312Decision)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {evaluate312Rules(selectedClient).map((rule, index) => (
                    <div key={index} className={`flex items-start gap-3 p-3 border rounded-md ${rule.passed ? 'bg-green-50 border-green-200' : 'bg-muted'}`}>
                      {rule.passed ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      ) : (
                        <XCircle className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                      )}
                      <div className="flex-1">
                        <div className="text-sm font-medium">{rule.rule}</div>
                        <div className={`text-xs mt-1 ${rule.passed ? 'text-green-700' : 'text-muted-foreground'}`}>
                          {rule.result}
                        </div>
                      </div>
                    </div>
                  ))}

                  {selectedClient.cam312Decision === 'Full Review' && (
                    <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-md mt-3">
                      <AlertCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-red-900">Decision: Full Review Required</div>
                        <div className="text-red-700 mt-1">312 model alert detected. Case created for analyst review. Case ID: {selectedClient.cam312CaseId}</div>
                      </div>
                    </div>
                  )}

                  {selectedClient.cam312Decision === 'Auto-Close' && (
                    <div className="flex items-start gap-2 p-3 bg-green-50 border border-green-200 rounded-md mt-3">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-green-900">Decision: Auto-Close</div>
                        <div className="text-green-700 mt-1">
                          No 312 model alert. Case auto-closed with disposition: "312 Activity in line with expected activity"
                          {selectedClient.cam312CaseId && <> • Case ID: {selectedClient.cam312CaseId}</>}
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedClient.cam312Decision === 'Not Applicable' && (
                    <div className="flex items-start gap-2 p-3 bg-gray-50 border border-gray-200 rounded-md mt-3">
                      <XCircle className="h-4 w-4 text-gray-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">Decision: Not Applicable</div>
                        <div className="text-gray-700 mt-1">Client not in 312 population scope</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* CAM Rule Evaluation */}
              <Card className="border-l-4 border-l-destructive">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Zap className="h-5 w-5 text-destructive" />
                        CAM Rule Evaluation
                      </CardTitle>
                      <CardDescription className="mt-1">
                        Logic: (312 Not Auto-Closed OR Cases &gt;5 OR SAR) AND No Recent CAM
                      </CardDescription>
                    </div>
                    {getDecisionBadge(selectedClient.camDecision)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {evaluateCAMRules(selectedClient).map((rule, index) => (
                    <div key={index} className={`flex items-start gap-3 p-3 border rounded-md ${rule.passed ? 'bg-green-50 border-green-200' : rule.result.includes('FAILED') ? 'bg-red-50 border-red-200' : 'bg-muted'}`}>
                      {rule.passed ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      ) : rule.result.includes('FAILED') ? (
                        <XCircle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
                      ) : (
                        <XCircle className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                      )}
                      <div className="flex-1">
                        <div className="text-sm font-medium">{rule.rule}</div>
                        <div className={`text-xs mt-1 ${rule.passed ? 'text-green-700' : rule.result.includes('FAILED') ? 'text-red-700' : 'text-muted-foreground'}`}>
                          {rule.result}
                        </div>
                      </div>
                    </div>
                  ))}

                  {selectedClient.camDecision === 'Full Review' && (
                    <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-md mt-3">
                      <AlertCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-red-900">Decision: Full Review Required</div>
                        <div className="text-red-700 mt-1">
                          Trigger conditions met and no recent CAM review. Case created for analyst review.
                          {selectedClient.camCaseId && <> • Case ID: {selectedClient.camCaseId}</>}
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedClient.camDecision === 'Auto-Close' && (
                    <div className="flex items-start gap-2 p-3 bg-green-50 border border-green-200 rounded-md mt-3">
                      <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-green-900">Decision: Auto-Close</div>
                        <div className="text-green-700 mt-1">
                          No trigger conditions met. Case auto-closed.
                          {selectedClient.camCaseId && <> • Case ID: {selectedClient.camCaseId}</>}
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedClient.camDecision === 'Pending 312' && (
                    <div className="flex items-start gap-2 p-3 bg-orange-50 border border-orange-200 rounded-md mt-3">
                      <Lock className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-orange-900">Decision: Pending 312 Completion</div>
                        <div className="text-orange-700 mt-1">
                          CAM triggered ONLY by 312 alert. Case created but cannot be placed in terminal status until 312 is complete. If 312 disposition is "no action", CAM can auto-close.
                          {selectedClient.camCaseId && <> • Case ID: {selectedClient.camCaseId}</>}
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedClient.camDecision === 'Not Applicable' && (
                    <div className="flex items-start gap-2 p-3 bg-gray-50 border border-gray-200 rounded-md mt-3">
                      <XCircle className="h-4 w-4 text-gray-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">Decision: Not Applicable</div>
                        <div className="text-gray-700 mt-1">
                          {selectedClient.riskRating !== 'High' && 'Client does not have High risk rating. '}
                          {selectedClient.riskRating === 'Elevated' || selectedClient.riskRating === 'Standard' ? 'CAM not required for 312 Elevated/Standard risk clients.' : ''}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Combined Logic (AC 3.3) */}
              {selectedClient.cam312Decision !== 'Not Applicable' && selectedClient.camDecision !== 'Not Applicable' && (
                <Card className="border-l-4 border-l-gold">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-gold" />
                      Combined Case Creation
                    </CardTitle>
                    <CardDescription>How 312 and CAM cases are created together</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="p-3 border rounded-md">
                        <div className="text-xs text-muted-foreground mb-1">Trigger Timing</div>
                        <div className="font-medium text-sm">
                          {selectedClient.lob === 'PB' || selectedClient.lob === 'ML' ? 
                            `Refresh within 180 days (${selectedClient.daysToRefresh} days)` :
                            selectedClient.lob === 'GB/GM' ?
                              (selectedClient.riskRating === 'High' ? 'DGA Due Date' : 'Family Anniversary - 180 days') :
                              'At refresh completion'
                          }
                        </div>
                      </div>
                      <div className="p-3 border rounded-md">
                        <div className="text-xs text-muted-foreground mb-1">Cases Created</div>
                        <div className="font-medium text-sm">
                          Simultaneous: Both 312 and CAM
                        </div>
                      </div>
                    </div>

                    {selectedClient.camDecision === 'Pending 312' && (
                      <Alert>
                        <Lock className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Dependency:</strong> CAM case is created but locked. It cannot be completed until 312 case is in terminal status. If 312 disposition is "no action", CAM can auto-close as the original trigger is no longer valid.
                        </AlertDescription>
                      </Alert>
                    )}
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
