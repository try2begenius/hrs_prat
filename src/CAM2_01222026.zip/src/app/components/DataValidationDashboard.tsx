import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import { 
  AlertCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Database,
  Search,
  FileText,
  TrendingUp,
  Activity,
  Users,
  Settings
} from 'lucide-react';
import { Case, User, SystemIntegration } from '@/app/components/types';
import {
  ValidationResult,
  DataQualityReport,
  generateDataQualityReport,
  validateCase,
  validateClientData,
  validateMonitoringData,
  validate312CaseData,
  validateCAMCaseData,
  validateUser,
  validateSystemIntegration,
  queryCasesMissingCriticalData,
  queryCasesWithIntegrityIssues,
  queryPastDueCases,
  queryHighRiskCases,
  queryCasesWithStaleMonitoring,
  queryCasesWith312ModelFlag,
  queryClientsWithoutMPID,
  queryEmployeeAccounts,
  queryOverdue312Cases,
  query312CasesMissingActivityData,
  queryOverdueCAMCases,
  queryIntegrationsWithErrors,
  queryIntegrationsNeedingSync,
  logValidationResults,
  logDataQualityReport
} from '@/app/utils/dataValidation';

interface DataValidationDashboardProps {
  cases: Case[];
  users?: User[];
  systemIntegrations?: SystemIntegration[];
}

export function DataValidationDashboard({ 
  cases, 
  users = [], 
  systemIntegrations = [] 
}: DataValidationDashboardProps) {
  const [dataQualityReport, setDataQualityReport] = useState<DataQualityReport | null>(null);
  const [selectedQuery, setSelectedQuery] = useState<string>('overview');
  const [queryResults, setQueryResults] = useState<any[]>([]);

  useEffect(() => {
    const report = generateDataQualityReport(cases);
    setDataQualityReport(report);
    
    // Log to console for debugging
    console.log('🔍 Running Data Validation...');
    logDataQualityReport(report);
  }, [cases]);

  const executeQuery = (queryName: string) => {
    setSelectedQuery(queryName);
    
    let results: any[] = [];
    
    switch (queryName) {
      case 'missingCriticalData':
        results = queryCasesMissingCriticalData(cases);
        console.log(`📋 Query: Cases Missing Critical Data - Found ${results.length} records`);
        break;
      
      case 'integrityIssues':
        results = queryCasesWithIntegrityIssues(cases);
        console.log(`📋 Query: Cases with Integrity Issues - Found ${results.length} records`);
        logValidationResults(results);
        break;
      
      case 'pastDue':
        results = queryPastDueCases(cases);
        console.log(`📋 Query: Past Due Cases - Found ${results.length} records`);
        break;
      
      case 'highRisk':
        results = queryHighRiskCases(cases);
        console.log(`📋 Query: High Risk Cases - Found ${results.length} records`);
        break;
      
      case 'staleMonitoring':
        results = queryCasesWithStaleMonitoring(cases, 90);
        console.log(`📋 Query: Cases with Stale Monitoring - Found ${results.length} records`);
        break;
      
      case '312ModelFlag':
        results = queryCasesWith312ModelFlag(cases);
        console.log(`📋 Query: Cases with 312 Model Flag - Found ${results.length} records`);
        break;
      
      case 'missingMPID':
        results = queryClientsWithoutMPID(cases);
        console.log(`📋 Query: Clients Missing MP ID - Found ${results.length} records`);
        break;
      
      case 'employeeAccounts':
        results = queryEmployeeAccounts(cases);
        console.log(`📋 Query: Employee Accounts - Found ${results.length} records`);
        break;
      
      case 'overdue312':
        results = queryOverdue312Cases(cases);
        console.log(`📋 Query: Overdue 312 Cases - Found ${results.length} records`);
        break;
      
      case '312MissingActivity':
        results = query312CasesMissingActivityData(cases);
        console.log(`📋 Query: 312 Cases Missing Activity Data - Found ${results.length} records`);
        break;
      
      case 'overdueCAM':
        results = queryOverdueCAMCases(cases);
        console.log(`📋 Query: Overdue CAM Cases - Found ${results.length} records`);
        break;
      
      case 'integrationErrors':
        results = queryIntegrationsWithErrors(systemIntegrations);
        console.log(`📋 Query: Integrations with Errors - Found ${results.length} records`);
        break;
      
      case 'integrationSync':
        results = queryIntegrationsNeedingSync(systemIntegrations, 24);
        console.log(`📋 Query: Integrations Needing Sync - Found ${results.length} records`);
        break;
      
      default:
        results = [];
    }
    
    setQueryResults(results);
  };

  if (!dataQualityReport) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Activity className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Running data validation...</p>
        </div>
      </div>
    );
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadgeVariant = (score: number): "default" | "secondary" | "destructive" | "outline" => {
    if (score >= 90) return 'default';
    if (score >= 70) return 'secondary';
    return 'destructive';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold mb-2">Data Validation & Quality Dashboard</h2>
        <p className="text-muted-foreground">
          Comprehensive validation queries and data quality metrics for all components
        </p>
      </div>

      {/* Data Quality Score */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Overall Data Quality Score
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <div className={`text-6xl font-bold ${getScoreColor(dataQualityReport.summary.dataQualityScore)}`}>
                {dataQualityReport.summary.dataQualityScore}
                <span className="text-2xl text-muted-foreground">/100</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Based on {dataQualityReport.totalRecords} total records
              </p>
            </div>
            <div className="text-right space-y-2">
              <Badge variant={getScoreBadgeVariant(dataQualityReport.summary.dataQualityScore)} className="text-lg px-4 py-2">
                {dataQualityReport.summary.dataQualityScore >= 90 ? 'Excellent' :
                 dataQualityReport.summary.dataQualityScore >= 70 ? 'Good' : 'Needs Attention'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Valid Records</p>
                <p className="text-2xl font-bold text-green-600">{dataQualityReport.validRecords}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {Math.round(dataQualityReport.validRecords / dataQualityReport.totalRecords * 100)}%
                </p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Invalid Records</p>
                <p className="text-2xl font-bold text-red-600">{dataQualityReport.invalidRecords}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {Math.round(dataQualityReport.invalidRecords / dataQualityReport.totalRecords * 100)}%
                </p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Critical Errors</p>
                <p className="text-2xl font-bold text-red-600">{dataQualityReport.summary.criticalErrors}</p>
                <p className="text-xs text-muted-foreground mt-1">Require attention</p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Warnings</p>
                <p className="text-2xl font-bold text-yellow-600">{dataQualityReport.summary.warnings}</p>
                <p className="text-xs text-muted-foreground mt-1">Review recommended</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Validation Queries */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Data Validation Queries
          </CardTitle>
          <CardDescription>
            Run queries to identify specific data quality issues across components
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {/* Case Queries */}
            <div className="space-y-2">
              <h4 className="font-semibold text-sm flex items-center gap-2">
                <Database className="h-4 w-4" />
                Case Data Queries
              </h4>
              <div className="space-y-1">
                <Button
                  variant={selectedQuery === 'missingCriticalData' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('missingCriticalData')}
                >
                  Missing Critical Data
                </Button>
                <Button
                  variant={selectedQuery === 'integrityIssues' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('integrityIssues')}
                >
                  Integrity Issues
                </Button>
                <Button
                  variant={selectedQuery === 'pastDue' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('pastDue')}
                >
                  Past Due Cases
                </Button>
                <Button
                  variant={selectedQuery === 'highRisk' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('highRisk')}
                >
                  High Risk Cases
                </Button>
              </div>
            </div>

            {/* Client & Monitoring Queries */}
            <div className="space-y-2">
              <h4 className="font-semibold text-sm flex items-center gap-2">
                <Users className="h-4 w-4" />
                Client & Monitoring Queries
              </h4>
              <div className="space-y-1">
                <Button
                  variant={selectedQuery === 'staleMonitoring' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('staleMonitoring')}
                >
                  Stale Monitoring Data
                </Button>
                <Button
                  variant={selectedQuery === '312ModelFlag' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('312ModelFlag')}
                >
                  312 Model Flags
                </Button>
                <Button
                  variant={selectedQuery === 'missingMPID' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('missingMPID')}
                >
                  Missing MP ID (GWIM Hub)
                </Button>
                <Button
                  variant={selectedQuery === 'employeeAccounts' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('employeeAccounts')}
                >
                  Employee Accounts
                </Button>
              </div>
            </div>

            {/* 312 & CAM Queries */}
            <div className="space-y-2">
              <h4 className="font-semibold text-sm flex items-center gap-2">
                <FileText className="h-4 w-4" />
                312 & CAM Queries
              </h4>
              <div className="space-y-1">
                <Button
                  variant={selectedQuery === 'overdue312' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('overdue312')}
                >
                  Overdue 312 Cases
                </Button>
                <Button
                  variant={selectedQuery === '312MissingActivity' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('312MissingActivity')}
                >
                  312 Missing Activity Data
                </Button>
                <Button
                  variant={selectedQuery === 'overdueCAM' ? 'default' : 'outline'}
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => executeQuery('overdueCAM')}
                >
                  Overdue CAM Cases
                </Button>
              </div>
            </div>

            {/* Integration Queries */}
            {systemIntegrations.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Integration Queries
                </h4>
                <div className="space-y-1">
                  <Button
                    variant={selectedQuery === 'integrationErrors' ? 'default' : 'outline'}
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => executeQuery('integrationErrors')}
                  >
                    Integration Errors
                  </Button>
                  <Button
                    variant={selectedQuery === 'integrationSync' ? 'default' : 'outline'}
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => executeQuery('integrationSync')}
                  >
                    Needs Sync
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Query Results */}
      {selectedQuery !== 'overview' && (
        <Card>
          <CardHeader>
            <CardTitle>Query Results</CardTitle>
            <CardDescription>
              Found {queryResults.length} record(s) matching the query criteria
            </CardDescription>
          </CardHeader>
          <CardContent>
            {queryResults.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <CheckCircle2 className="h-12 w-12 mx-auto mb-4 text-green-600" />
                <p>No issues found! All records pass this validation check.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {queryResults.map((result, index) => (
                  <div key={index} className="border rounded-lg p-3 hover:bg-muted/50">
                    {/* For ValidationResult objects */}
                    {result.componentName ? (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold font-mono text-sm">
                            {result.recordId || 'Unknown ID'}
                          </span>
                          <Badge variant={result.isValid ? 'default' : 'destructive'}>
                            {result.componentName}
                          </Badge>
                        </div>
                        {result.errors && result.errors.length > 0 && (
                          <div className="space-y-1 mb-2">
                            {result.errors.map((error: string, i: number) => (
                              <div key={i} className="flex items-start gap-2 text-sm text-red-600">
                                <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                                <span>{error}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {result.warnings && result.warnings.length > 0 && (
                          <div className="space-y-1">
                            {result.warnings.map((warning: string, i: number) => (
                              <div key={i} className="flex items-start gap-2 text-sm text-yellow-600">
                                <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                                <span>{warning}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ) : (
                      /* For Case/Integration objects */
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-semibold font-mono text-sm">
                            {result.id || result.name}
                          </span>
                          <Badge variant="outline">
                            {result.clientName || result.type || 'Record'}
                          </Badge>
                        </div>
                        {result.description && (
                          <p className="text-sm text-muted-foreground mt-1">{result.description}</p>
                        )}
                        {result.status && (
                          <div className="mt-2">
                            <Badge variant="secondary">{result.status}</Badge>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Top Missing Fields */}
      {dataQualityReport.summary.missingFields.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Top Missing Fields
            </CardTitle>
            <CardDescription>
              Most common validation errors across all records
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {dataQualityReport.summary.missingFields.map((field, index) => (
                <div key={index} className="flex items-center gap-3 p-2 rounded-md hover:bg-muted/50">
                  <div className="flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-600 text-xs font-bold">
                    {index + 1}
                  </div>
                  <span className="text-sm">{field}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
