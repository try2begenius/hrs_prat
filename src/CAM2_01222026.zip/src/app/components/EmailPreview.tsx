import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { ScrollArea } from "./ui/scroll-area";
import { Mail, Send, Clock, User, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { EmailNotification, mockSentEmails } from '../data/emailNotifications';
import { UserAccess } from '../data/rolesEntitlementsMockData';

interface EmailPreviewProps {
  currentUser: UserAccess;
  caseId?: string; // If provided, filter emails for specific case
}

export function EmailPreview({ currentUser, caseId }: EmailPreviewProps) {
  const [selectedEmail, setSelectedEmail] = useState<EmailNotification | null>(null);
  const [viewMode, setViewMode] = useState<'html' | 'text'>('html');

  // Filter emails based on user and optional case ID
  const filteredEmails = mockSentEmails.filter(email => {
    if (caseId && email.caseId !== caseId) return false;
    
    // Sales Owners see emails sent to them
    if (currentUser.role === 'Sales Owner') {
      return email.recipientName === currentUser.name;
    }
    
    // Analysts/Managers see emails they sent (or all if admin)
    return true;
  });

  const getEmailTypeIcon = (type: string) => {
    return type === 'action_required' 
      ? <AlertCircle className="h-4 w-4 text-destructive" />
      : <CheckCircle2 className="h-4 w-4 text-green-500" />;
  };

  const getEmailTypeBadge = (type: string) => {
    return type === 'action_required'
      ? <Badge variant="destructive">Action Required</Badge>
      : <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">No Action Required</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Email Notifications
          </h3>
          <p className="text-sm text-muted-foreground">
            {caseId ? `Emails for case ${caseId}` : 'All sent email notifications'}
          </p>
        </div>
        <Badge variant="secondary">
          {filteredEmails.length} {filteredEmails.length === 1 ? 'Email' : 'Emails'}
        </Badge>
      </div>

      {filteredEmails.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Mail className="h-12 w-12 mx-auto mb-4 opacity-50 text-muted-foreground" />
            <p className="text-muted-foreground">No email notifications found</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredEmails.map((email) => (
            <Card key={email.id} className="hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {getEmailTypeIcon(email.type)}
                      <CardTitle className="text-base">{email.subject}</CardTitle>
                    </div>
                    <CardDescription className="space-y-1">
                      <div className="flex items-center gap-4 text-xs">
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          To: {email.recipientName}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {email.sentDate} at {email.sentTime}
                        </span>
                        {!caseId && (
                          <span className="flex items-center gap-1">
                            <FileText className="h-3 w-3" />
                            {email.caseId}
                          </span>
                        )}
                      </div>
                    </CardDescription>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    {getEmailTypeBadge(email.type)}
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setSelectedEmail(email)}
                        >
                          <Mail className="mr-2 h-4 w-4" />
                          View Email
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[90vh]">
                        <DialogHeader>
                          <DialogTitle>Email Preview</DialogTitle>
                          <DialogDescription>
                            Sent to {email.recipientName} ({email.recipientEmail}) on {email.sentDate} at {email.sentTime}
                          </DialogDescription>
                        </DialogHeader>
                        
                        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'html' | 'text')} className="w-full">
                          <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="html">HTML View</TabsTrigger>
                            <TabsTrigger value="text">Plain Text</TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="html" className="mt-4">
                            <ScrollArea className="h-[60vh] w-full rounded-md border">
                              <div 
                                className="p-4"
                                dangerouslySetInnerHTML={{ __html: email.htmlBody }}
                              />
                            </ScrollArea>
                          </TabsContent>
                          
                          <TabsContent value="text" className="mt-4">
                            <ScrollArea className="h-[60vh] w-full rounded-md border">
                              <pre className="p-4 text-sm whitespace-pre-wrap font-sans">
                                {email.plainTextBody}
                              </pre>
                            </ScrollArea>
                          </TabsContent>
                        </Tabs>

                        <div className="flex items-center justify-between pt-4 border-t">
                          <div className="text-sm text-muted-foreground">
                            <strong>Subject:</strong> {email.subject}
                          </div>
                          <Button variant="outline" size="sm">
                            <Send className="mr-2 h-4 w-4" />
                            Resend Email
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Status:</span>
                    <div className="mt-1">
                      <Badge variant="secondary">{email.caseStatus}</Badge>
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">312 Action:</span>
                    <div className="mt-1">
                      <Badge variant="outline">{email.action312Status}</Badge>
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">CAM Action:</span>
                    <div className="mt-1">
                      <Badge variant="outline">{email.actionCAMStatus}</Badge>
                    </div>
                  </div>
                </div>
                {email.dueDate && (
                  <div className="mt-3 p-3 bg-destructive/10 rounded-md border border-destructive/20">
                    <div className="flex items-center gap-2 text-sm">
                      <AlertCircle className="h-4 w-4 text-destructive" />
                      <span><strong>Response Due:</strong> {email.dueDate}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
