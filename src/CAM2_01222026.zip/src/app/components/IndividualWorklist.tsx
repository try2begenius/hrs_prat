import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { 
  Search, 
  Download, 
  Eye, 
  User, 
  Users, 
  Building2, 
  Clock, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  UserPlus,
  AlertCircle
} from 'lucide-react';
import { mockCases } from '../data/enhancedMockData';
import { Case, CaseStatus, RiskLevel, LineOfBusiness } from '../types';
import { UserAccess, mockUsers } from '../data/rolesEntitlementsMockData';
import { toast } from 'sonner';

interface IndividualWorklistProps {
  onViewCase: (caseId: string) => void;
  currentUser: UserAccess;
  onCaseAssigned?: (caseId: string, assignee: string) => void;
}

type SortField = 'id' | 'clientName' | 'status' | 'createdDate' | 'dueDate' | 'riskLevel' | 'lineOfBusiness';
type SortDirection = 'asc' | 'desc' | null;

export function IndividualWorklist({ onViewCase, currentUser, onCaseAssigned }: IndividualWorklistProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [lobFilter, setLobFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('createdDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedCases, setSelectedCases] = useState<Set<string>>(new Set());
  const [bulkAssignDialogOpen, setBulkAssignDialogOpen] = useState(false);
  const [selectedAssignee, setSelectedAssignee] = useState<string>('');
  const [editCaseDialogOpen, setEditCaseDialogOpen] = useState(false);

  const isManager = currentUser.role === 'Manager' || currentUser.role === 'Central Team Manager';
  const isAnalyst = currentUser.role === 'Analyst' || currentUser.role === 'Central Team Analyst';

  // Get permissions for current user
  const permissions = useMemo(() => {
    if (isManager) {
      return {
        reopenCases: true,
        assignCases: true,
        reassignCases: true
      };
    }
    return {
      reopenCases: false,
      assignCases: false,
      reassignCases: false
    };
  }, [isManager]);

  // Filter to only cases assigned to current user
  const myAssignedCases = mockCases.filter(c => {
    // Must be assigned to the current user
    if (c.assignedTo !== currentUser.name) return false;
    
    // Filter by case type access
    if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
    if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
    
    // Filter employee cases
    if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
    
    return true;
  });

  // Get today's date for past due calculation
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Apply filters and sorting
  const filteredAndSortedCases = useMemo(() => {
    let filtered = myAssignedCases.filter(caseItem => {
      // Search filter
      const matchesSearch = 
        caseItem.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.gci?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.clientId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.coperId?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || caseItem.status === statusFilter;
      const matchesRisk = riskFilter === 'all' || caseItem.riskLevel === riskFilter;
      const matchesLOB = lobFilter === 'all' || caseItem.lineOfBusiness === lobFilter;

      return matchesSearch && matchesStatus && matchesRisk && matchesLOB;
    });

    // Sort cases
    if (sortField && sortDirection) {
      filtered.sort((a, b) => {
        let aVal: any;
        let bVal: any;

        switch (sortField) {
          case 'id':
            aVal = a.id;
            bVal = b.id;
            break;
          case 'clientName':
            aVal = a.clientName;
            bVal = b.clientName;
            break;
          case 'status':
            aVal = a.status;
            bVal = b.status;
            break;
          case 'createdDate':
            aVal = new Date(a.createdDate);
            bVal = new Date(b.createdDate);
            break;
          case 'dueDate':
            aVal = new Date(a.dueDate);
            bVal = new Date(b.dueDate);
            break;
          case 'riskLevel':
            const riskOrder = { 'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
            aVal = riskOrder[a.riskLevel];
            bVal = riskOrder[b.riskLevel];
            break;
          case 'lineOfBusiness':
            aVal = a.lineOfBusiness || '';
            bVal = b.lineOfBusiness || '';
            break;
          default:
            return 0;
        }

        if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [myAssignedCases, searchTerm, statusFilter, riskFilter, lobFilter, sortField, sortDirection]);

  // Statistics by Case Status
  const statusStats = useMemo(() => {
    const stats: Record<string, number> = {};
    myAssignedCases.forEach(c => {
      stats[c.status] = (stats[c.status] || 0) + 1;
    });
    return stats;
  }, [myAssignedCases]);

  // Statistics by LOB
  const lobStats = useMemo(() => {
    const stats: Record<string, number> = {};
    myAssignedCases.forEach(c => {
      if (c.lineOfBusiness) {
        stats[c.lineOfBusiness] = (stats[c.lineOfBusiness] || 0) + 1;
      }
    });
    return stats;
  }, [myAssignedCases]);

  const pastDueCount = myAssignedCases.filter(c => {
    const dueDate = new Date(c.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    return dueDate < today;
  }).length;

  // Get status border color (for left border in cards)
  const getStatusBorderColor = (status: string) => {
    switch (status) {
      case 'Cancelled': return 'border-l-red-600';
      case 'Complete': return 'border-l-green-600';
      case 'Not Started': return 'border-l-gray-600';
      case 'In Progress': return 'border-l-amber-600';
      case 'Pending Sales Review': return 'border-l-blue-600';
      case 'In Sales Review': return 'border-l-purple-600';
      case 'Sales Review Complete': return 'border-l-indigo-600';
      case 'Defect Remediation': return 'border-l-red-600';
      case 'Pending Reassignment': return 'border-l-orange-600';
      default: return 'border-l-gray-400';
    }
  };

  // Get LOB border color (for left border in cards)
  const getLOBBorderColor = (lob: string) => {
    switch (lob) {
      case 'GB/GM': return 'border-l-red-600';
      case 'PB': return 'border-l-blue-600';
      case 'ML': return 'border-l-purple-600';
      case 'Consumer': return 'border-l-green-600';
      case 'CI': return 'border-l-orange-600';
      default: return 'border-l-gray-400';
    }
  };

  // Get status widget border color (for all borders)
  const getStatusWidgetBorder = (status: string) => {
    switch (status) {
      case 'Cancelled': return 'border-red-500 hover:border-red-600';
      case 'Complete': return 'border-green-500 hover:border-green-600';
      case 'Not Started': return 'border-gray-400 hover:border-gray-500';
      case 'In Progress': return 'border-amber-500 hover:border-amber-600';
      case 'Pending Sales Review': return 'border-blue-500 hover:border-blue-600';
      case 'In Sales Review': return 'border-purple-500 hover:border-purple-600';
      case 'Sales Review Complete': return 'border-indigo-500 hover:border-indigo-600';
      case 'Defect Remediation': return 'border-red-500 hover:border-red-600';
      case 'Pending Reassignment': return 'border-orange-500 hover:border-orange-600';
      default: return 'border-gray-300 hover:border-gray-400';
    }
  };

  // Get LOB widget border color (for all borders)
  const getLOBWidgetBorder = (lob: string) => {
    switch (lob) {
      case 'GB/GM': return 'border-red-500 hover:border-red-600';
      case 'PB': return 'border-blue-500 hover:border-blue-600';
      case 'ML': return 'border-purple-500 hover:border-purple-600';
      case 'Consumer': return 'border-green-500 hover:border-green-600';
      case 'CI': return 'border-orange-500 hover:border-orange-600';
      default: return 'border-gray-300 hover:border-gray-400';
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else if (sortDirection === 'desc') {
        setSortDirection(null);
        setSortField('createdDate');
      } else {
        setSortDirection('asc');
      }
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-3 w-3 opacity-50" />;
    if (sortDirection === 'asc') return <ArrowUp className="h-3 w-3" />;
    if (sortDirection === 'desc') return <ArrowDown className="h-3 w-3" />;
    return <ArrowUpDown className="h-3 w-3 opacity-50" />;
  };

  const getRiskBadgeVariant = (risk: RiskLevel) => {
    switch (risk) {
      case 'Critical': return 'destructive';
      case 'High': return 'default';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
    }
  };

  const getStatusColor = (status: CaseStatus) => {
    switch (status) {
      case 'Unassigned': return 'bg-gray-100 text-gray-800';
      case 'In Progress': return 'bg-amber-100 text-amber-800';
      case 'Pending Sales Review': return 'bg-blue-100 text-blue-800';
      case 'In Sales Review': return 'bg-purple-100 text-purple-800';
      case 'Sales Review Complete': return 'bg-indigo-100 text-indigo-800';
      case 'Complete': return 'bg-green-100 text-green-800';
      case 'Defect Remediation': return 'bg-red-100 text-red-800';
      case 'Under Review': return 'bg-purple-100 text-purple-800';
      case 'Escalated': return 'bg-destructive/10 text-destructive';
      case 'Closed': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-gray-100 text-gray-800';
    }
  };

  const formatLOB = (lob?: LineOfBusiness) => {
    if (!lob) return '-';
    const lobMap: Record<LineOfBusiness, string> = {
      'GB/GM': 'GB/GM',
      'PB': 'Private Bank',
      'ML': 'ML',
      'Consumer': 'Consumer',
      'CI': 'CI'
    };
    return lobMap[lob] || lob;
  };

  const isPastDue = (dueDate: string) => {
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    return due < today;
  };

  // Bulk assignment handlers for managers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedCases(new Set(filteredAndSortedCases.map(c => c.id)));
    } else {
      setSelectedCases(new Set());
    }
  };

  const handleSelectCase = (caseId: string, checked: boolean) => {
    const newSelected = new Set(selectedCases);
    if (checked) {
      newSelected.add(caseId);
    } else {
      newSelected.delete(caseId);
    }
    setSelectedCases(newSelected);
  };

  const confirmBulkAssignment = () => {
    if (!selectedAssignee) {
      toast.error('Please select an assignee');
      return;
    }

    const assigneeName = mockUsers.find(u => u.id === selectedAssignee)?.name || selectedAssignee;
    
    selectedCases.forEach(caseId => {
      if (onCaseAssigned) {
        onCaseAssigned(caseId, assigneeName);
      }
    });

    toast.success(`${selectedCases.size} case(s) assigned`, {
      description: `Successfully assigned to ${assigneeName}`
    });

    setSelectedCases(new Set());
    setBulkAssignDialogOpen(false);
    setSelectedAssignee('');
  };

  // Self-assign handler for analysts
  const handleSelfAssign = (caseItem: Case) => {
    if (caseItem.assignedTo === currentUser.name) {
      // Already assigned to user, just view
      onViewCase(caseItem.id);
      return;
    }

    if (caseItem.assignedTo === 'Unassigned' && isAnalyst) {
      // Self-assign functionality
      if (onCaseAssigned) {
        onCaseAssigned(caseItem.id, currentUser.name);
      }
      toast.success('Case assigned to you', {
        description: `Case ${caseItem.id} is now in your worklist`
      });
      // Also open the case
      setTimeout(() => onViewCase(caseItem.id), 500);
    } else {
      // Just view the case
      onViewCase(caseItem.id);
    }
  };

  const activeUsersForAssignment = mockUsers.filter(u => u.status === 'Active');

  // Check if selected cases include complete cases that can be edited
  const selectedCasesDetails = useMemo(() => {
    return filteredAndSortedCases.filter(c => selectedCases.has(c.id));
  }, [filteredAndSortedCases, selectedCases]);

  const completeCasesSelected = useMemo(() => {
    return selectedCasesDetails.filter(c => c.status === 'Complete');
  }, [selectedCasesDetails]);

  const hasCompleteCases = completeCasesSelected.length > 0;

  // Handle reopening cases for remediation
  const handleReopenForRemediation = () => {
    if (completeCasesSelected.length === 0) {
      toast.error('No complete cases selected');
      return;
    }

    // Update cases to Defect Remediation status
    completeCasesSelected.forEach(caseItem => {
      const caseToUpdate = mockCases.find(c => c.id === caseItem.id);
      if (caseToUpdate && caseToUpdate.status === 'Complete') {
        caseToUpdate.status = 'Defect Remediation';
        caseToUpdate.defectRemediationFlag = true;
        if (caseToUpdate.completionDate && !caseToUpdate.originalCompletionDate) {
          caseToUpdate.originalCompletionDate = caseToUpdate.completionDate;
        }
        caseToUpdate.completionDate = undefined;
      }
    });

    toast.success(`${completeCasesSelected.length} case(s) reopened for remediation`, {
      description: 'Cases have been moved to Defect Remediation status'
    });

    setSelectedCases(new Set());
    setEditCaseDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="text-muted-foreground">
          Cases assigned to you - all stages and statuses
        </p>
      </div>

      {/* Statistics - Two Row Layout */}
      <div className="space-y-4">
        {/* Case Status Row */}
        <div className="flex items-center gap-4">
          <div className="flex-1 overflow-x-auto">
            <div className="flex gap-2 pb-2">
              {Object.entries(statusStats)
                .sort(([, a], [, b]) => b - a)
                .map(([status, count]) => (
                  <button
                    key={status}
                    onClick={() => setStatusFilter(status)}
                    className={`px-4 py-2.5 rounded-lg border-2 transition-all hover:shadow-md whitespace-nowrap ${
                      statusFilter === status 
                        ? `${getStatusWidgetBorder(status)} bg-muted/40 shadow-sm` 
                        : `${getStatusWidgetBorder(status)} bg-background`
                    }`}
                  >
                    <div className="text-xs text-muted-foreground mb-0.5">{status}</div>
                    <div className="text-lg font-semibold">{count}</div>
                  </button>
                ))}
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-xs text-primary shrink-0"
            onClick={() => { setStatusFilter('all'); setLobFilter('all'); }}
          >
            Show All
          </Button>
        </div>

        {/* Line of Business Row */}
        <div className="flex items-center gap-4">
          <div className="flex gap-2 flex-wrap">
            {Object.entries(lobStats)
              .sort(([, a], [, b]) => b - a)
              .map(([lob, count]) => (
                <button
                  key={lob}
                  onClick={() => setLobFilter(lob)}
                  className={`px-4 py-2.5 rounded-lg border-2 transition-all hover:shadow-md ${
                    lobFilter === lob 
                      ? `${getLOBWidgetBorder(lob)} bg-muted/40 shadow-sm` 
                      : `${getLOBWidgetBorder(lob)} bg-background`
                  }`}
                >
                  <div className="text-xs text-muted-foreground mb-0.5">{formatLOB(lob as LineOfBusiness)}</div>
                  <div className="text-lg font-semibold">{count}</div>
                </button>
              ))}
          </div>
        </div>
      </div>

      <Card className="card-elevated">
        <CardHeader className="border-b bg-muted/30">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>My Cases</CardTitle>
              <CardDescription className="mt-1">
                <span className="font-medium text-primary">{filteredAndSortedCases.length}</span> of {myAssignedCases.length} cases
                {isAnalyst && (
                  <span className="ml-2 text-xs">
                    • User can self assign from the worklist
                  </span>
                )}
                {isManager && selectedCases.size > 0 && (
                  <span className="ml-2 text-xs text-primary">
                    • {selectedCases.size} case(s) selected
                  </span>
                )}
              </CardDescription>
            </div>
            <div className="flex gap-2">
              {isManager && selectedCases.size > 0 && (
                <>
                  {hasCompleteCases && permissions.reopenCases && (
                    <Button 
                      onClick={() => setEditCaseDialogOpen(true)}
                      variant="outline"
                      className="border-primary text-primary hover:bg-primary/10"
                    >
                      <Eye className="mr-2 h-4 w-4" />
                      Edit Case{completeCasesSelected.length > 1 ? 's' : ''} ({completeCasesSelected.length})
                    </Button>
                  )}
                  <Button 
                    onClick={() => setBulkAssignDialogOpen(true)}
                    className="bg-primary"
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    Assign {selectedCases.size} Case{selectedCases.size !== 1 ? 's' : ''}
                  </Button>
                </>
              )}
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export My Cases
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search case, client, GCI, CoPer..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Pending Sales Review">Pending Sales Review</SelectItem>
                <SelectItem value="In Sales Review">In Sales Review</SelectItem>
                <SelectItem value="Sales Review Complete">Sales Review Complete</SelectItem>
                <SelectItem value="Complete">Complete</SelectItem>
                <SelectItem value="Defect Remediation">Defect Remediation</SelectItem>
              </SelectContent>
            </Select>

            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Risk Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select value={lobFilter} onValueChange={setLobFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All LOBs" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All LOBs</SelectItem>
                <SelectItem value="GB/GM">GB/GM</SelectItem>
                <SelectItem value="PB">Private Bank</SelectItem>
                <SelectItem value="ML">Merrill Lynch</SelectItem>
                <SelectItem value="Consumer">Consumer</SelectItem>
                <SelectItem value="CI">CI</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Cases Table */}
          <div className="rounded-md border overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    {isManager && (
                      <TableHead className="w-[40px]">
                        <Checkbox
                          checked={selectedCases.size === filteredAndSortedCases.length && filteredAndSortedCases.length > 0}
                          onCheckedChange={handleSelectAll}
                        />
                      </TableHead>
                    )}
                    <TableHead className="font-semibold min-w-[140px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('id')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Case Number
                        <SortIcon field="id" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[180px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('clientName')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Client Name
                        <SortIcon field="clientName" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[120px]">GCI</TableHead>
                    <TableHead className="font-semibold min-w-[100px]">Party ID</TableHead>
                    <TableHead className="font-semibold min-w-[100px]">MP ID</TableHead>
                    <TableHead className="font-semibold min-w-[100px]">CoPer ID</TableHead>
                    <TableHead className="font-semibold min-w-[140px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('status')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Case Status
                        <SortIcon field="status" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[120px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('createdDate')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Created Date
                        <SortIcon field="createdDate" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[120px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('dueDate')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Due Date
                        <SortIcon field="dueDate" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[140px]">Assignee</TableHead>
                    <TableHead className="font-semibold min-w-[100px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('lineOfBusiness')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        LOB
                        <SortIcon field="lineOfBusiness" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[100px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('riskLevel')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Risk Rating
                        <SortIcon field="riskLevel" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[100px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAndSortedCases.map((caseItem) => {
                    const pastDue = isPastDue(caseItem.dueDate);

                    return (
                      <TableRow 
                        key={caseItem.id} 
                        className={`hover:bg-muted/30 transition-colors ${pastDue ? 'bg-red-50' : ''}`}
                      >
                        {isManager && (
                          <TableCell>
                            <Checkbox
                              checked={selectedCases.has(caseItem.id)}
                              onCheckedChange={(checked) => handleSelectCase(caseItem.id, checked as boolean)}
                            />
                          </TableCell>
                        )}
                        <TableCell>
                          <button 
                            onClick={() => handleSelfAssign(caseItem)}
                            className="font-mono text-sm font-medium text-primary hover:underline hover:text-primary/80 transition-colors text-left"
                          >
                            {caseItem.id}
                          </button>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{caseItem.clientName}</div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{caseItem.gci || '-'}</TableCell>
                        <TableCell className="font-mono text-sm text-muted-foreground">{caseItem.clientId || '-'}</TableCell>
                        <TableCell className="font-mono text-sm text-muted-foreground">
                          {caseItem.clientData?.mpId || <span className="text-gray-400">N/A</span>}
                        </TableCell>
                        <TableCell className="font-mono text-sm text-muted-foreground">
                          {caseItem.coperId || <span className="text-gray-400">N/A</span>}
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(caseItem.status) + ' border-0'} variant="outline">
                            {caseItem.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{caseItem.createdDate}</TableCell>
                        <TableCell className="text-sm">
                          <div className={`flex items-center gap-1 ${pastDue ? 'text-red-600 font-medium' : ''}`}>
                            {pastDue && <Clock className="h-3 w-3" />}
                            {caseItem.dueDate}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-2">
                            <User className="h-3 w-3 text-muted-foreground" />
                            {caseItem.assignedTo}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="border-blue-200 text-blue-800 bg-blue-50">
                            <Building2 className="h-3 w-3 mr-1" />
                            {formatLOB(caseItem.lineOfBusiness)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={getRiskBadgeVariant(caseItem.riskLevel)}
                            className={
                              caseItem.riskLevel === 'Critical' ? 'bg-red-600 text-white' : 
                              caseItem.riskLevel === 'High' ? 'bg-red-100 text-red-800 border-red-200' :
                              caseItem.riskLevel === 'Medium' ? 'bg-amber-100 text-amber-800 border-amber-200' :
                              'bg-green-100 text-green-800 border-green-200'
                            }
                          >
                            {caseItem.riskLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onViewCase(caseItem.id)}
                            className="hover:bg-primary/10 hover:text-primary"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>

          {filteredAndSortedCases.length === 0 && (
            <div className="py-12 text-center text-muted-foreground">
              {myAssignedCases.length === 0 ? (
                <div>
                  <p className="text-lg">No cases assigned to you</p>
                  <p className="text-sm mt-2">Cases will appear here when assigned by a manager or when you self-assign from the worklist.</p>
                </div>
              ) : (
                'No cases match your filters'
              )}
            </div>
          )}

          {/* Results summary */}
          {filteredAndSortedCases.length > 0 && (
            <div className="text-sm text-muted-foreground">
              Showing {filteredAndSortedCases.length} case{filteredAndSortedCases.length !== 1 ? 's' : ''}
              {sortField && sortDirection && (
                <span> • Sorted by {sortField} ({sortDirection === 'asc' ? 'ascending' : 'descending'})</span>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bulk Assignment Dialog for Managers */}
      <Dialog open={bulkAssignDialogOpen} onOpenChange={setBulkAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Cases</DialogTitle>
            <DialogDescription>
              Assign {selectedCases.size} selected case{selectedCases.size !== 1 ? 's' : ''} to a team member
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Assign to:</label>
              <Select value={selectedAssignee} onValueChange={setSelectedAssignee}>
                <SelectTrigger>
                  <SelectValue placeholder="Select team member" />
                </SelectTrigger>
                <SelectContent>
                  <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">
                    Central Team Members
                  </div>
                  {activeUsersForAssignment
                    .filter(u => u.role === 'Central Team Analyst' || u.role === 'Central Team Manager' || u.role === 'Analyst' || u.role === 'Manager')
                    .map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span>{user.name}</span>
                          <span className="text-xs text-muted-foreground">({user.role})</span>
                        </div>
                      </SelectItem>
                    ))}
                  <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground mt-2">
                    Sales Owners
                  </div>
                  {activeUsersForAssignment
                    .filter(u => u.role === 'Sales Owner')
                    .map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span>{user.name}</span>
                          <span className="text-xs text-muted-foreground">(Sales)</span>
                        </div>
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="text-sm text-muted-foreground">
              Managers can also bulk assign to users. You can assign and reassign cases to any Central Team member or Sales Owner.
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkAssignDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={confirmBulkAssignment} className="bg-primary">
              Assign Cases
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Case Dialog for Managers - Reopen for Remediation */}
      <Dialog open={editCaseDialogOpen} onOpenChange={setEditCaseDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Complete Cases - Quality Remediation</DialogTitle>
            <DialogDescription>
              Reopen {completeCasesSelected.length} complete case{completeCasesSelected.length !== 1 ? 's' : ''} for defect remediation
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="rounded-md border bg-muted/30 p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
                <div className="space-y-2">
                  <p className="text-sm font-medium">Quality Remediation Action</p>
                  <p className="text-sm text-muted-foreground">
                    This action will reopen the selected complete cases and change their status to <span className="font-semibold text-red-600">Defect Remediation</span>. 
                    The cases will need to be re-reviewed and re-dispositioned by an analyst.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Selected Complete Cases:</label>
              <div className="rounded-md border max-h-[200px] overflow-y-auto">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead className="font-semibold">Case Number</TableHead>
                      <TableHead className="font-semibold">Client Name</TableHead>
                      <TableHead className="font-semibold">Status</TableHead>
                      <TableHead className="font-semibold">Completed Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {completeCasesSelected.map((caseItem) => (
                      <TableRow key={caseItem.id}>
                        <TableCell className="font-mono text-sm">{caseItem.id}</TableCell>
                        <TableCell className="text-sm">{caseItem.clientName}</TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800 border-0">
                            {caseItem.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{caseItem.completionDate || '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="text-sm text-muted-foreground bg-blue-50 border border-blue-200 rounded-md p-3">
              <p className="font-medium text-blue-900 mb-1">Manager Permission Required</p>
              <p className="text-blue-800">
                Only Central Team Managers can reopen complete cases for quality remediation. 
                The original completion date will be preserved for audit purposes.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditCaseDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleReopenForRemediation} className="bg-red-600 hover:bg-red-700 text-white">
              Reopen for Remediation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}