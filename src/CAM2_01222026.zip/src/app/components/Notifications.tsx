import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Switch } from "./ui/switch";
import { Separator } from "./ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Bell, Mail, AlertCircle, CheckCircle2, Clock, User, FileText, Send } from 'lucide-react';
import { UserAccess } from '../data/rolesEntitlementsMockData';
import { mockNotifications } from '../data/enhancedMockData';
import { EmailPreview } from './EmailPreview';

interface NotificationsProps {
  currentUser: UserAccess;
}

export function Notifications({ currentUser }: NotificationsProps) {
  const [activeTab, setActiveTab] = useState('notifications');
  
  // Map user names to IDs
  const userIdMap: { [key: string]: string } = {
    'Sarah Mitchell': 'U001',
    'Carlos Rivera': 'U002',
    'Michael Chen': 'U003',
    'Jennifer Wu': 'U004',
    'Lisa Brown': 'U005',
    'Kevin Rogers': 'U006',
    'Robert Anderson': 'U007',
    'David Park': 'U008',
    'Amanda Torres': 'U009',
  };

  // Filter notifications for current user
  const userNotifications = mockNotifications.filter(n => 
    n.userId === userIdMap[currentUser.name]
  );

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'case_assigned': return <User className="h-5 w-5 text-primary" />;
      case 'case_escalated': return <AlertCircle className="h-5 w-5 text-destructive" />;
      case 'deadline': return <Clock className="h-5 w-5 text-orange-500" />;
      case 'comment': return <Mail className="h-5 w-5 text-purple-500" />;
      case 'status_change': return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'feedback_request': return <User className="h-5 w-5 text-primary" />;
      case 'sales_feedback_requested': return <FileText className="h-5 w-5 text-blue-500" />;
      case 'report_ready': return <FileText className="h-5 w-5 text-green-500" />;
      default: return <Bell className="h-5 w-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2>Notifications & Emails</h2>
          <p className="text-muted-foreground">
            Viewing notifications for {currentUser.name} ({currentUser.role})
          </p>
        </div>
        <Button variant="outline">Mark All as Read</Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notifications
            {userNotifications.filter(n => !n.read).length > 0 && (
              <Badge variant="destructive" className="ml-1 h-5 min-w-5 px-1">
                {userNotifications.filter(n => !n.read).length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="emails" className="flex items-center gap-2">
            <Send className="h-4 w-4" />
            Sent Emails
          </TabsTrigger>
        </TabsList>

        <TabsContent value="notifications" className="mt-6">
          <div className="grid gap-6 lg:grid-cols-3">
        {/* Notifications List */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Notifications</CardTitle>
              <CardDescription>
                {userNotifications.filter(n => !n.read).length} unread notification{userNotifications.filter(n => !n.read).length !== 1 ? 's' : ''}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {userNotifications.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No notifications</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {userNotifications.map((notification, index) => (
                    <div key={notification.id}>
                      <div className={`flex gap-4 ${!notification.read ? 'bg-accent/50 p-3 rounded-lg' : 'p-3'}`}>
                        <div className="flex-shrink-0 mt-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className={!notification.read ? 'font-medium' : ''}>
                                  {notification.title}
                                </span>
                                {!notification.read && (
                                  <Badge variant="default" className="h-5 px-1.5">New</Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{notification.message}</p>
                            </div>
                            <Badge 
                              variant={notification.priority === 'urgent' ? 'destructive' : 'outline'} 
                              className="ml-2 flex-shrink-0"
                            >
                              {notification.priority}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>{notification.time}</span>
                            {notification.caseId && (
                              <span className="text-primary">Case: {notification.caseId}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      {index < userNotifications.length - 1 && <Separator className="mt-4" />}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Notification Settings */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Email Settings</CardTitle>
              <CardDescription>Configure email notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm">Case Assignments</div>
                  <div className="text-xs text-muted-foreground">When assigned a new case</div>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm">Escalations</div>
                  <div className="text-xs text-muted-foreground">When a case is escalated</div>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm">Deadlines</div>
                  <div className="text-xs text-muted-foreground">24 hours before due date</div>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm">Comments</div>
                  <div className="text-xs text-muted-foreground">New comments on your cases</div>
                </div>
                <Switch />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm">Status Changes</div>
                  <div className="text-xs text-muted-foreground">When case status updates</div>
                </div>
                <Switch />
              </div>
              {currentUser.role === 'Sales Owner' && (
                <>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-sm">Feedback Requests</div>
                      <div className="text-xs text-muted-foreground">When feedback is requested</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Digest Settings</CardTitle>
              <CardDescription>Daily summary emails</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm">Daily Digest</div>
                  <div className="text-xs text-muted-foreground">Summary of all activity</div>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm">Weekly Report</div>
                  <div className="text-xs text-muted-foreground">Weekly case statistics</div>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
        </TabsContent>

        <TabsContent value="emails" className="mt-6">
          <EmailPreview currentUser={currentUser} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
