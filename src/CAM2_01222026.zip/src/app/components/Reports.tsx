import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Checkbox } from "./ui/checkbox";
import { Separator } from "./ui/separator";
import { FileText, Download, Plus, Calendar as CalendarIcon, TrendingUp, BarChart3, PieChart, FileSpreadsheet, FileDown, RotateCcw, Filter, Database, AlertTriangle, Clock } from 'lucide-react';
import { mockReports, mockCases } from '../data/enhancedMockData';
import { UserAccess } from '../data/rolesEntitlementsMockData';
import { Case } from '../types';
import { useState } from 'react';
import { generateAKRITExtract, exportToCSV, exportToExcel, AKRITExtractRow, generateDelinquencyReport, exportDelinquencyReportToCSV, exportDelinquencyReportToExcel, DelinquencyReportRow } from '../utils/reportExports';
import { toast } from 'sonner';

interface ReportsProps {
  currentUser: UserAccess;
}

export function Reports({ currentUser }: ReportsProps) {
  const [date, setDate] = useState<Date | undefined>(new Date());
  
  // AKRIT Extract filters
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  const [exportFormat, setExportFormat] = useState<'csv' | 'excel'>('csv');
  const [include312Cases, setInclude312Cases] = useState(true);
  const [includeCAMCases, setIncludeCAMCases] = useState(true);
  const [filterBy312Flag, setFilterBy312Flag] = useState(false);
  const [filterByEmployeeFlag, setFilterByEmployeeFlag] = useState(false);
  
  // LOB filters
  const [includeGBGM, setIncludeGBGM] = useState(false);
  const [includePB, setIncludePB] = useState(false);
  const [includeML, setIncludeML] = useState(false);
  const [includeConsumer, setIncludeConsumer] = useState(false);
  const [includeCI, setIncludeCI] = useState(false);

  // Delinquency Report filters
  const [delinquencyExportFormat, setDelinquencyExportFormat] = useState<'csv' | 'excel'>('csv');
  const [delinquencyLOBFilter, setDelinquencyLOBFilter] = useState<string[]>([]);
  const [delinquencyOnlyEmployee, setDelinquencyOnlyEmployee] = useState(false);
  const [delinquencyOnly312, setDelinquencyOnly312] = useState(false);
  const [delinquencyMinDaysOverdue, setDelinquencyMinDaysOverdue] = useState<number>(0);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Completed': return <Download className="h-4 w-4 text-green-600" />;
      case 'Processing': return <TrendingUp className="h-4 w-4 text-primary" />;
      case 'Failed': return <FileText className="h-4 w-4 text-destructive" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  // Filter cases for AKRIT export
  const getFilteredCasesForExport = (): Case[] => {
    let filtered = [...mockCases];

    // Filter by date range
    if (fromDate || toDate) {
      filtered = filtered.filter(c => {
        const caseDate = new Date(c.createdDate);
        if (fromDate && caseDate < fromDate) return false;
        if (toDate && caseDate > toDate) return false;
        return true;
      });
    }

    // Filter by case type
    if (!include312Cases || !includeCAMCases) {
      filtered = filtered.filter(c => {
        if (include312Cases && c.caseType === '312 Review') return true;
        if (includeCAMCases && c.caseType === 'CAM Review') return true;
        return false;
      });
    }

    // Filter by LOB (if any selected)
    const anyLOBSelected = includeGBGM || includePB || includeML || includeConsumer || includeCI;
    if (anyLOBSelected) {
      filtered = filtered.filter(c => {
        const lob = c.lineOfBusiness || c.clientData?.lineOfBusiness || '';
        if (includeGBGM && lob === 'GB/GM') return true;
        if (includePB && lob === 'PB') return true;
        if (includeML && lob === 'ML') return true;
        if (includeConsumer && lob === 'Consumer') return true;
        if (includeCI && lob === 'CI') return true;
        return false;
      });
    }

    // Filter by 312 flag
    if (filterBy312Flag) {
      filtered = filtered.filter(c => c.is312Case === true);
    }

    // Filter by employee flag
    if (filterByEmployeeFlag) {
      filtered = filtered.filter(c => c.clientData?.isEmployee === true);
    }

    return filtered;
  };

  // Handle AKRIT export
  const handleAKRITExport = () => {
    const filteredCases = getFilteredCasesForExport();

    if (filteredCases.length === 0) {
      toast.error('No cases to export', {
        description: 'No cases match the selected filters. Please adjust your criteria.',
      });
      return;
    }

    const akritData = generateAKRITExtract(filteredCases);
    const today = new Date().toISOString().split('T')[0];
    const filename = `AKRIT_Extract_${today}.${exportFormat === 'csv' ? 'csv' : 'xlsx'}`;

    if (exportFormat === 'csv') {
      exportToCSV(akritData, filename);
    } else {
      exportToExcel(akritData, filename);
    }

    toast.success('Export Complete', {
      description: `Successfully exported ${filteredCases.length} case${filteredCases.length !== 1 ? 's' : ''} to ${filename}`,
    });
  };

  // Reset all AKRIT filters
  const resetAKRITFilters = () => {
    setFromDate(undefined);
    setToDate(undefined);
    setExportFormat('csv');
    setInclude312Cases(true);
    setIncludeCAMCases(true);
    setFilterBy312Flag(false);
    setFilterByEmployeeFlag(false);
    setIncludeGBGM(false);
    setIncludePB(false);
    setIncludeML(false);
    setIncludeConsumer(false);
    setIncludeCI(false);
    toast.info('Filters Reset', {
      description: 'All AKRIT export filters have been reset to defaults.',
    });
  };

  const filteredCaseCount = getFilteredCasesForExport().length;

  // Delinquency Report Functions
  const getDelinquencyCases = (): DelinquencyReportRow[] => {
    let delinquencyData = generateDelinquencyReport(mockCases);

    // Filter by LOB
    if (delinquencyLOBFilter.length > 0) {
      delinquencyData = delinquencyData.filter(row => 
        delinquencyLOBFilter.includes(row.lineOfBusiness)
      );
    }

    // Filter by employee flag
    if (delinquencyOnlyEmployee) {
      delinquencyData = delinquencyData.filter(row => row.isEmployeeAffiliate === 'Yes');
    }

    // Filter by 312 flag
    if (delinquencyOnly312) {
      delinquencyData = delinquencyData.filter(row => row.is312Client === 'Yes');
    }

    // Filter by minimum days overdue
    if (delinquencyMinDaysOverdue > 0) {
      delinquencyData = delinquencyData.filter(row => row.daysOverdue >= delinquencyMinDaysOverdue);
    }

    // Sort by days overdue (most overdue first)
    return delinquencyData.sort((a, b) => b.daysOverdue - a.daysOverdue);
  };

  const handleDelinquencyExport = () => {
    const delinquencyData = getDelinquencyCases();

    if (delinquencyData.length === 0) {
      toast.error('No delinquent cases found', {
        description: 'No cases match the delinquency criteria. Try adjusting your filters.',
      });
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const filename = `Delinquency_Report_${today}.${delinquencyExportFormat === 'csv' ? 'csv' : 'xlsx'}`;

    if (delinquencyExportFormat === 'csv') {
      exportDelinquencyReportToCSV(delinquencyData, filename);
    } else {
      exportDelinquencyReportToExcel(delinquencyData, filename);
    }

    toast.success('Delinquency Report Exported', {
      description: `Successfully exported ${delinquencyData.length} delinquent case${delinquencyData.length !== 1 ? 's' : ''} to ${filename}`,
    });
  };

  const resetDelinquencyFilters = () => {
    setDelinquencyExportFormat('csv');
    setDelinquencyLOBFilter([]);
    setDelinquencyOnlyEmployee(false);
    setDelinquencyOnly312(false);
    setDelinquencyMinDaysOverdue(0);
    toast.info('Delinquency Filters Reset', {
      description: 'All delinquency report filters have been reset to defaults.',
    });
  };

  const toggleDelinquencyLOB = (lob: string) => {
    setDelinquencyLOBFilter(prev => 
      prev.includes(lob) 
        ? prev.filter(l => l !== lob)
        : [...prev, lob]
    );
  };

  const delinquentCaseCount = getDelinquencyCases().length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2>Reports & Analytics</h2>
          <p className="text-muted-foreground">Generate and manage AML compliance reports</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Generate Report
        </Button>
      </div>

      <Tabs defaultValue="reports" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="reports">Generated Reports</TabsTrigger>
          <TabsTrigger value="akrit" className="flex items-center gap-1">
            <Database className="h-4 w-4" />
            AKRIT
          </TabsTrigger>
          <TabsTrigger value="delinquency" className="flex items-center gap-1">
            <AlertTriangle className="h-4 w-4" />
            Delinquency
          </TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Reports</CardTitle>
              <CardDescription>View and download generated reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Report Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Generated By</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Format</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockReports.map((report) => (
                      <TableRow key={report.id}>
                        <TableCell className="font-medium">{report.name}</TableCell>
                        <TableCell>{report.type}</TableCell>
                        <TableCell className="text-sm">{report.generatedBy}</TableCell>
                        <TableCell className="text-sm">{report.generatedDate}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(report.status)}
                            <Badge variant={report.status === 'Completed' ? 'default' : report.status === 'Processing' ? 'secondary' : 'destructive'}>
                              {report.status}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{report.format}</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" disabled={report.status !== 'Completed'}>
                            <Download className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="akrit" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Filter Panel */}
            <div className="lg:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Database className="h-5 w-5" />
                        AKRIT Data Extract
                      </CardTitle>
                      <CardDescription>
                        Export case data for quality review inspections in AKRIT
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={resetAKRITFilters}>
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Reset Filters
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Date Range */}
                  <div>
                    <h3 className="mb-3 flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      Date Range (Optional)
                    </h3>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm text-muted-foreground">From Date</label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="outline" className="w-full justify-start text-left">
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {fromDate ? fromDate.toLocaleDateString() : 'Select start date'}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={fromDate} onSelect={setFromDate} />
                          </PopoverContent>
                        </Popover>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm text-muted-foreground">To Date</label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="outline" className="w-full justify-start text-left">
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {toDate ? toDate.toLocaleDateString() : 'Select end date'}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={toDate} onSelect={setToDate} />
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Export Format */}
                  <div>
                    <h3 className="mb-3 flex items-center gap-2">
                      <FileDown className="h-4 w-4" />
                      Export Format
                    </h3>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Button
                        variant={exportFormat === 'csv' ? 'default' : 'outline'}
                        className="justify-start"
                        onClick={() => setExportFormat('csv')}
                      >
                        <FileSpreadsheet className="mr-2 h-4 w-4" />
                        CSV (Recommended)
                      </Button>
                      <Button
                        variant={exportFormat === 'excel' ? 'default' : 'outline'}
                        className="justify-start"
                        onClick={() => setExportFormat('excel')}
                      >
                        <FileText className="mr-2 h-4 w-4" />
                        Excel (.xlsx)
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  {/* Case Type Filter */}
                  <div>
                    <h3 className="mb-3 flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      Case Types
                    </h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="include-312"
                          checked={include312Cases}
                          onCheckedChange={(checked) => setInclude312Cases(checked as boolean)}
                        />
                        <label
                          htmlFor="include-312"
                          className="text-sm cursor-pointer leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          312 Review Cases
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="include-cam"
                          checked={includeCAMCases}
                          onCheckedChange={(checked) => setIncludeCAMCases(checked as boolean)}
                        />
                        <label
                          htmlFor="include-cam"
                          className="text-sm cursor-pointer leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          CAM Review Cases
                        </label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* LOB Filter */}
                  <div>
                    <h3 className="mb-3">Line of Business (Optional)</h3>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="lob-gbgm"
                          checked={includeGBGM}
                          onCheckedChange={(checked) => setIncludeGBGM(checked as boolean)}
                        />
                        <label htmlFor="lob-gbgm" className="text-sm cursor-pointer">
                          GB/GM - Global Banking / Markets
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="lob-pb"
                          checked={includePB}
                          onCheckedChange={(checked) => setIncludePB(checked as boolean)}
                        />
                        <label htmlFor="lob-pb" className="text-sm cursor-pointer">
                          PB - Private Bank
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="lob-ml"
                          checked={includeML}
                          onCheckedChange={(checked) => setIncludeML(checked as boolean)}
                        />
                        <label htmlFor="lob-ml" className="text-sm cursor-pointer">
                          ML - Merrill Lynch
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="lob-consumer"
                          checked={includeConsumer}
                          onCheckedChange={(checked) => setIncludeConsumer(checked as boolean)}
                        />
                        <label htmlFor="lob-consumer" className="text-sm cursor-pointer">
                          Consumer Banking
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="lob-ci"
                          checked={includeCI}
                          onCheckedChange={(checked) => setIncludeCI(checked as boolean)}
                        />
                        <label htmlFor="lob-ci" className="text-sm cursor-pointer">
                          CI - Corporate & Investment
                        </label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Additional Filters */}
                  <div>
                    <h3 className="mb-3">Additional Filters (Optional)</h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="filter-312-flag"
                          checked={filterBy312Flag}
                          onCheckedChange={(checked) => setFilterBy312Flag(checked as boolean)}
                        />
                        <label htmlFor="filter-312-flag" className="text-sm cursor-pointer">
                          312 Client Flag = Yes only
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="filter-employee-flag"
                          checked={filterByEmployeeFlag}
                          onCheckedChange={(checked) => setFilterByEmployeeFlag(checked as boolean)}
                        />
                        <label htmlFor="filter-employee-flag" className="text-sm cursor-pointer">
                          BAC Affiliate/Employee Flag = Yes only
                        </label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Preview & Export Panel */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Export Preview</CardTitle>
                  <CardDescription>Review before exporting</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-lg border-2 border-dashed border-primary/20 bg-primary/5 p-6 text-center">
                    <div className="text-4xl mb-2">{filteredCaseCount}</div>
                    <div className="text-sm text-muted-foreground">
                      case{filteredCaseCount !== 1 ? 's' : ''} will be exported
                    </div>
                  </div>

                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Case Types:</span>
                      <span className="text-right">
                        {include312Cases && includeCAMCases ? 'Both' : 
                         include312Cases ? '312 Only' : 
                         includeCAMCases ? 'CAM Only' : 'None'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">LOBs:</span>
                      <span className="text-right">
                        {!includeGBGM && !includePB && !includeML && !includeConsumer && !includeCI ? 'All' :
                         [includeGBGM && 'GB/GM', includePB && 'PB', includeML && 'ML', 
                          includeConsumer && 'Consumer', includeCI && 'CI']
                          .filter(Boolean).join(', ')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date Range:</span>
                      <span className="text-right">
                        {!fromDate && !toDate ? 'All Dates' :
                         `${fromDate?.toLocaleDateString() || '...'} - ${toDate?.toLocaleDateString() || '...'}`}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Format:</span>
                      <span className="text-right uppercase">{exportFormat}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Button 
                      className="w-full" 
                      size="lg"
                      onClick={handleAKRITExport}
                      disabled={filteredCaseCount === 0}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Export {filteredCaseCount} Case{filteredCaseCount !== 1 ? 's' : ''} to AKRIT
                    </Button>
                    {filteredCaseCount === 0 && (
                      <p className="text-xs text-center text-destructive">
                        No cases match the selected filters
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Field Reference Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Exported Fields</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">1</Badge>
                      <span>Case ID</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">2</Badge>
                      <span>Client ID</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">3</Badge>
                      <span>GCI</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">4</Badge>
                      <span>CoPer ID</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">5</Badge>
                      <span>Line of Business</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">6</Badge>
                      <span>312 Client Flag</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">7</Badge>
                      <span>BAC Affiliate/Employee Flag</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="delinquency" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Filter Panel */}
            <div className="lg:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <AlertTriangle className="h-5 w-5 text-destructive" />
                        Delinquency Report
                      </CardTitle>
                      <CardDescription>
                        Identify overdue cases for LOB AML lead escalation
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={resetDelinquencyFilters}>
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Reset Filters
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Info Banner */}
                  <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4">
                    <div className="flex items-start gap-3">
                      <Clock className="h-5 w-5 text-destructive mt-0.5" />
                      <div className="flex-1">
                        <h4 className="text-sm mb-1">Delinquent Cases Criteria</h4>
                        <p className="text-xs text-muted-foreground">
                          Cases with expired refresh dates OR overdue case dates that remain in open status (not Complete or Closed).
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Export Format */}
                  <div>
                    <h3 className="mb-3 flex items-center gap-2">
                      <FileDown className="h-4 w-4" />
                      Export Format
                    </h3>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Button
                        variant={delinquencyExportFormat === 'csv' ? 'default' : 'outline'}
                        className="justify-start"
                        onClick={() => setDelinquencyExportFormat('csv')}
                      >
                        <FileSpreadsheet className="mr-2 h-4 w-4" />
                        CSV (Recommended)
                      </Button>
                      <Button
                        variant={delinquencyExportFormat === 'excel' ? 'default' : 'outline'}
                        className="justify-start"
                        onClick={() => setDelinquencyExportFormat('excel')}
                      >
                        <FileText className="mr-2 h-4 w-4" />
                        Excel (.xlsx)
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  {/* LOB Filter */}
                  <div>
                    <h3 className="mb-3 flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      Filter by Line of Business (Optional)
                    </h3>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="delinq-lob-gbgm"
                          checked={delinquencyLOBFilter.includes('GB/GM')}
                          onCheckedChange={() => toggleDelinquencyLOB('GB/GM')}
                        />
                        <label htmlFor="delinq-lob-gbgm" className="text-sm cursor-pointer">
                          GB/GM - Global Banking / Markets
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="delinq-lob-pb"
                          checked={delinquencyLOBFilter.includes('PB')}
                          onCheckedChange={() => toggleDelinquencyLOB('PB')}
                        />
                        <label htmlFor="delinq-lob-pb" className="text-sm cursor-pointer">
                          PB - Private Bank
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="delinq-lob-ml"
                          checked={delinquencyLOBFilter.includes('ML')}
                          onCheckedChange={() => toggleDelinquencyLOB('ML')}
                        />
                        <label htmlFor="delinq-lob-ml" className="text-sm cursor-pointer">
                          ML - Merrill Lynch
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="delinq-lob-consumer"
                          checked={delinquencyLOBFilter.includes('Consumer')}
                          onCheckedChange={() => toggleDelinquencyLOB('Consumer')}
                        />
                        <label htmlFor="delinq-lob-consumer" className="text-sm cursor-pointer">
                          Consumer Banking
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="delinq-lob-ci"
                          checked={delinquencyLOBFilter.includes('CI')}
                          onCheckedChange={() => toggleDelinquencyLOB('CI')}
                        />
                        <label htmlFor="delinq-lob-ci" className="text-sm cursor-pointer">
                          CI - Corporate & Investment
                        </label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Additional Filters */}
                  <div>
                    <h3 className="mb-3">Additional Filters (Optional)</h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="delinq-312-only"
                          checked={delinquencyOnly312}
                          onCheckedChange={(checked) => setDelinquencyOnly312(checked as boolean)}
                        />
                        <label htmlFor="delinq-312-only" className="text-sm cursor-pointer">
                          312 Client Flag = Yes only
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="delinq-employee-only"
                          checked={delinquencyOnlyEmployee}
                          onCheckedChange={(checked) => setDelinquencyOnlyEmployee(checked as boolean)}
                        />
                        <label htmlFor="delinq-employee-only" className="text-sm cursor-pointer">
                          BAC Affiliate/Employee Flag = Yes only
                        </label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Days Overdue Filter */}
                  <div>
                    <h3 className="mb-3">Minimum Days Overdue</h3>
                    <div className="space-y-3">
                      <Select 
                        value={String(delinquencyMinDaysOverdue)} 
                        onValueChange={(val) => setDelinquencyMinDaysOverdue(Number(val))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="All overdue cases" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">All overdue cases</SelectItem>
                          <SelectItem value="1">1+ days overdue</SelectItem>
                          <SelectItem value="3">3+ days overdue</SelectItem>
                          <SelectItem value="7">7+ days overdue</SelectItem>
                          <SelectItem value="14">14+ days overdue</SelectItem>
                          <SelectItem value="30">30+ days overdue</SelectItem>
                          <SelectItem value="60">60+ days overdue</SelectItem>
                          <SelectItem value="90">90+ days overdue</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        Filter cases by how many days past their due date
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Preview & Export Panel */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Delinquent Cases</CardTitle>
                  <CardDescription>Review before exporting</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-lg border-2 border-dashed border-destructive/30 bg-destructive/5 p-6 text-center">
                    <div className="text-4xl text-destructive mb-2">{delinquentCaseCount}</div>
                    <div className="text-sm text-muted-foreground">
                      delinquent case{delinquentCaseCount !== 1 ? 's' : ''}
                    </div>
                  </div>

                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">LOBs:</span>
                      <span className="text-right">
                        {delinquencyLOBFilter.length === 0 ? 'All' : delinquencyLOBFilter.join(', ')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Min Days Overdue:</span>
                      <span className="text-right">
                        {delinquencyMinDaysOverdue === 0 ? 'All' : `${delinquencyMinDaysOverdue}+ days`}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">312 Only:</span>
                      <span className="text-right">{delinquencyOnly312 ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Employee Only:</span>
                      <span className="text-right">{delinquencyOnlyEmployee ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Format:</span>
                      <span className="text-right uppercase">{delinquencyExportFormat}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Button 
                      className="w-full" 
                      size="lg"
                      variant="destructive"
                      onClick={handleDelinquencyExport}
                      disabled={delinquentCaseCount === 0}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Export {delinquentCaseCount} Case{delinquentCaseCount !== 1 ? 's' : ''}
                    </Button>
                    {delinquentCaseCount === 0 && (
                      <p className="text-xs text-center text-muted-foreground">
                        No delinquent cases found
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Field Reference Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Report Fields (13)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">1</Badge>
                      <span>Client ID</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">2</Badge>
                      <span>GCI</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">3</Badge>
                      <span>CoPer ID</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">4</Badge>
                      <span>Line of Business</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">5</Badge>
                      <span>312 Client Flag</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">6</Badge>
                      <span>Employee Flag</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">7</Badge>
                      <span>Refresh Due Date</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">8</Badge>
                      <span>312 Case Due Date</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">9</Badge>
                      <span>CAM Case Due Date</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">10</Badge>
                      <span>Central Team Member</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">11</Badge>
                      <span>Sales Owner</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs text-destructive">12</Badge>
                      <span className="text-destructive">Days Overdue</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">13</Badge>
                      <span>Case Status</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Use Case Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Report Use</CardTitle>
                </CardHeader>
                <CardContent className="text-xs space-y-2">
                  <p className="text-muted-foreground">
                    Share with LOB AML leads for escalation of overdue cases requiring attention.
                  </p>
                  <div className="pt-2 space-y-1">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary"></div>
                      <span>Sorted by most overdue first</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary"></div>
                      <span>Includes all stakeholder contacts</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary"></div>
                      <span>Ready for escalation workflow</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: BarChart3, title: 'Case Volume Report', desc: 'Summary of case creation and resolution' },
              { icon: PieChart, title: 'Risk Distribution', desc: 'Analysis of risk levels across cases' },
              { icon: TrendingUp, title: 'Trend Analysis', desc: 'Monthly trends and patterns' },
              { icon: FileText, title: 'SAR Filing Report', desc: 'Suspicious Activity Report filings' },
              { icon: FileText, title: 'Regulatory Compliance', desc: 'Compliance status and metrics' },
              { icon: BarChart3, title: 'Population Analytics', desc: 'Population monitoring insights' },
            ].map((template, i) => (
              <Card key={i} className="cursor-pointer transition-colors hover:bg-accent">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <template.icon className="h-5 w-5" />
                    </div>
                    <CardTitle className="text-base">{template.title}</CardTitle>
                  </div>
                  <CardDescription>{template.desc}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full">Generate</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Cases This Month</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl">{mockCases.length}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+23%</span> vs last month
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Avg. Resolution Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl">5.2 days</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">-1.3 days</span> improvement
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">SAR Filings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl">12</div>
                <p className="text-xs text-muted-foreground">
                  This month
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Custom Report Builder</CardTitle>
              <CardDescription>Create a customized report</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm">Report Type</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="case">Case Statistics</SelectItem>
                      <SelectItem value="risk">Risk Analysis</SelectItem>
                      <SelectItem value="regulatory">Regulatory</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm">Date Range</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? date.toLocaleDateString() : 'Pick a date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar mode="single" selected={date} onSelect={setDate} />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <label className="text-sm">Include Cases</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="All cases" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Cases</SelectItem>
                      <SelectItem value="open">Open Only</SelectItem>
                      <SelectItem value="closed">Closed Only</SelectItem>
                      <SelectItem value="high-risk">High Risk</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm">Output Format</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="PDF" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button className="w-full">
                <FileText className="mr-2 h-4 w-4" />
                Generate Custom Report
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}