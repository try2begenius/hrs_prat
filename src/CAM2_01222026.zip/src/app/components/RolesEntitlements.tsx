import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { CheckCircle2, XCircle, Shield, Users, Key, Lock, UserCheck, Settings, AlertCircle, Clock, Ban } from 'lucide-react';
import { 
  roleDefinitions, 
  entitlementDefinitions, 
  mockUsers, 
  calculateAccessStats,
  UserAccess,
  RoleDefinition
} from '../data/rolesEntitlementsMockData';

export function RolesEntitlements() {
  const [users] = useState<UserAccess[]>(mockUsers);
  const [selectedUser, setSelectedUser] = useState<UserAccess | null>(null);
  const [selectedRole, setSelectedRole] = useState<RoleDefinition | null>(null);
  const stats = calculateAccessStats(users);

  const getRoleBadge = (role: string) => {
    const variants: Record<string, any> = {
      'Central Team Manager': 'default',
      'Central Team Analyst': 'secondary',
      'View Only': 'outline',
      'Sales Owner': 'default'
    };
    const colors: Record<string, string> = {
      'Central Team Manager': 'bg-blue-100 text-blue-700 border-blue-200',
      'Central Team Analyst': 'bg-green-100 text-green-700 border-green-200',
      'View Only': '',
      'Sales Owner': 'bg-purple-100 text-purple-700 border-purple-200'
    };
    return (
      <Badge variant={variants[role]} className={colors[role]}>
        {role}
      </Badge>
    );
  };

  const getStatusBadge = (status: string) => {
    const icons = {
      'Active': <CheckCircle2 className="h-3 w-3" />,
      'Pending': <Clock className="h-3 w-3" />,
      'Revoked': <Ban className="h-3 w-3" />
    };
    const variants: Record<string, any> = {
      'Active': 'default',
      'Pending': 'secondary',
      'Revoked': 'destructive'
    };
    return (
      <Badge variant={variants[status]} className="gap-1">
        {icons[status as keyof typeof icons]}
        {status}
      </Badge>
    );
  };

  const getPermissionIcon = (hasPermission: boolean) => {
    return hasPermission ? (
      <CheckCircle2 className="h-4 w-4 text-green-600" />
    ) : (
      <XCircle className="h-4 w-4 text-muted-foreground" />
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2>Roles & Entitlements Management</h2>
          <p className="text-muted-foreground">Access control and permissions via ARM approval workflow</p>
        </div>
        <Button>
          <Settings className="mr-2 h-4 w-4" />
          Request Access
        </Button>
      </div>

      {/* Summary Statistics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{stats.totalUsers}</div>
            <p className="text-xs text-muted-foreground">
              Across all roles
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Active Access</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-600">{stats.activeUsers}</div>
            <p className="text-xs text-muted-foreground">
              {stats.pendingUsers} pending approval
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Role Types</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{roleDefinitions.length}</div>
            <p className="text-xs text-muted-foreground">
              Different role definitions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Entitlements</CardTitle>
            <Key className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{entitlementDefinitions.length}</div>
            <p className="text-xs text-muted-foreground">
              Available entitlements
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ARM Approval Workflow */}
      <Alert>
        <UserCheck className="h-4 w-4" />
        <AlertDescription>
          <strong>Access Request Management (ARM):</strong> Users must request access via ARM based on roles and entitlements. 
          All access requests are reviewed and approved by the user's manager to ensure appropriate access levels.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="users" className="space-y-4">
        <TabsList>
          <TabsTrigger value="users">User Access</TabsTrigger>
          <TabsTrigger value="roles">Role Definitions</TabsTrigger>
          <TabsTrigger value="entitlements">Entitlements</TabsTrigger>
          <TabsTrigger value="matrix">Access Matrix</TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Access Management</CardTitle>
              <CardDescription>Click a user to see detailed role and entitlement information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Entitlements</TableHead>
                      <TableHead>LOBs</TableHead>
                      <TableHead>Manager</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow 
                        key={user.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => setSelectedUser(user)}
                      >
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{user.email}</TableCell>
                        <TableCell>{getRoleBadge(user.role)}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {user.entitlements?.has312Access && (
                              <Badge variant="outline" className="text-xs">312</Badge>
                            )}
                            {user.entitlements?.hasCAMAccess && (
                              <Badge variant="outline" className="text-xs">CAM</Badge>
                            )}
                            {user.entitlements?.hasEmployeeCaseAccess && (
                              <Badge variant="secondary" className="text-xs">Emp</Badge>
                            )}
                            {user.entitlements?.hasManualCaseCreation && (
                              <Badge variant="secondary" className="text-xs">Manual</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {user.entitlements?.lobs?.map(lob => (
                              <Badge key={lob} variant="outline" className="text-xs">
                                {lob}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">{user.manager}</TableCell>
                        <TableCell>{getStatusBadge(user.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {selectedUser && (
            <Card className="border-l-4 border-l-primary">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{selectedUser.name}</CardTitle>
                    <CardDescription className="mt-2 space-x-2">
                      <span>{selectedUser.email}</span>
                    </CardDescription>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setSelectedUser(null)}>
                    Clear Selection
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Role Information */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">Role Assignment</span>
                  </div>
                  <div className="p-3 bg-muted rounded-md">
                    {getRoleBadge(selectedUser.role)}
                    <div className="text-sm text-muted-foreground mt-2">
                      {roleDefinitions.find(r => r.type === selectedUser.role)?.description}
                    </div>
                  </div>
                </div>

                {/* Entitlements */}
                {selectedUser.entitlements && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Key className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">Entitlements</span>
                  </div>
                  <div className="grid gap-2 md:grid-cols-2">
                    <div className={`p-3 border rounded-md ${selectedUser.entitlements.has312Access ? 'bg-blue-50 border-blue-200' : 'bg-muted'}`}>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">312 Access</span>
                        {getPermissionIcon(selectedUser.entitlements.has312Access)}
                      </div>
                    </div>
                    <div className={`p-3 border rounded-md ${selectedUser.entitlements.hasCAMAccess ? 'bg-red-50 border-red-200' : 'bg-muted'}`}>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">CAM Access</span>
                        {getPermissionIcon(selectedUser.entitlements.hasCAMAccess)}
                      </div>
                    </div>
                    <div className={`p-3 border rounded-md ${selectedUser.entitlements.hasEmployeeCaseAccess ? 'bg-green-50 border-green-200' : 'bg-muted'}`}>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Employee Cases</span>
                        {getPermissionIcon(selectedUser.entitlements.hasEmployeeCaseAccess)}
                      </div>
                      {selectedUser.entitlements.hasEmployeeCaseAccess && (
                        <Badge variant="secondary" className="text-xs mt-1">Limited Access</Badge>
                      )}
                    </div>
                    <div className={`p-3 border rounded-md ${selectedUser.entitlements.hasManualCaseCreation ? 'bg-green-50 border-green-200' : 'bg-muted'}`}>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Manual Case Creation</span>
                        {getPermissionIcon(selectedUser.entitlements.hasManualCaseCreation)}
                      </div>
                      {selectedUser.entitlements.hasManualCaseCreation && (
                        <Badge variant="secondary" className="text-xs mt-1">Limited Access</Badge>
                      )}
                    </div>
                  </div>
                </div>
                )}

                {/* LOB Access */}
                {selectedUser.entitlements && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">Line of Business (LOB) Access</span>
                  </div>
                  <div className="p-3 bg-muted rounded-md">
                    <div className="flex flex-wrap gap-2">
                      {selectedUser.entitlements.lobs.length > 0 ? (
                        selectedUser.entitlements.lobs.map(lob => (
                          <Badge key={lob} variant="default">
                            {lob}
                          </Badge>
                        ))
                      ) : (
                        <span className="text-sm text-muted-foreground">No LOB access assigned</span>
                      )}
                    </div>
                    {selectedUser.role === 'Sales Owner' && selectedUser.entitlements.lobs.length > 1 && (
                      <Alert className="mt-3">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription className="text-xs">
                          Sales owners should be limited to one LOB per policy
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </div>
                )}

                {/* Access Request Information */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <UserCheck className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">Access Request Details</span>
                  </div>
                  <div className="grid gap-2 md:grid-cols-3">
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">Approving Manager</div>
                      <div className="text-sm font-medium">{selectedUser.manager}</div>
                    </div>
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">Request Date</div>
                      <div className="text-sm font-medium">{selectedUser.accessRequestDate}</div>
                    </div>
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">Approval Date</div>
                      <div className="text-sm font-medium">{selectedUser.accessApprovedDate}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Roles Tab */}
        <TabsContent value="roles" className="space-y-4">
          <div className="grid gap-4">
            {roleDefinitions.map((role) => (
              <Card 
                key={role.id} 
                className={`cursor-pointer transition-all ${selectedRole?.id === role.id ? 'border-l-4 border-l-primary' : ''}`}
                onClick={() => setSelectedRole(role)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{role.name}</CardTitle>
                      <CardDescription className="mt-1">{role.description}</CardDescription>
                    </div>
                    <Badge variant="outline">
                      {users.filter(u => u.role === role.type).length} users
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2 md:grid-cols-4">
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.viewDashboard)}
                      <span className="text-xs">View Dashboard</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.viewWorklist)}
                      <span className="text-xs">View Worklist</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.openCases)}
                      <span className="text-xs">Open Cases</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.reviewData)}
                      <span className="text-xs">Review Data</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.actionCases)}
                      <span className="text-xs">Action Cases</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.assignCases)}
                      <span className="text-xs">Assign Cases</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.reassignCases)}
                      <span className="text-xs">Reassign Cases</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.reopenCases)}
                      <span className="text-xs">Reopen Cases</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.abandonCases)}
                      <span className="text-xs">Abandon Cases</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.salesFeedback)}
                      <span className="text-xs">Sales Feedback</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 border rounded-md">
                      {getPermissionIcon(role.permissions.returnToAnalyst)}
                      <span className="text-xs">Return to Analyst</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Entitlements Tab */}
        <TabsContent value="entitlements" className="space-y-4">
          <Alert>
            <Lock className="h-4 w-4" />
            <AlertDescription>
              Entitlements can be partitioned to ensure certain users may only access cases they have responsibility or expertise to action.
            </AlertDescription>
          </Alert>

          <div className="grid gap-4 md:grid-cols-2">
            {entitlementDefinitions.map((entitlement) => (
              <Card key={entitlement.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{entitlement.name}</CardTitle>
                      <CardDescription className="mt-1">{entitlement.description}</CardDescription>
                    </div>
                    <Badge 
                      variant={
                        entitlement.restrictionLevel === 'Limited' ? 'destructive' : 
                        entitlement.restrictionLevel === 'Required' ? 'default' : 'secondary'
                      }
                      className="text-xs"
                    >
                      {entitlement.restrictionLevel}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Category</span>
                      <Badge variant="outline">{entitlement.category}</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Users with Access</span>
                      <span className="font-medium">
                        {stats.byEntitlement.find(e => e.entitlement.includes(entitlement.category))?.count || 0}
                      </span>
                    </div>
                    {entitlement.restrictionLevel === 'Limited' && (
                      <Alert className="mt-2">
                        <Lock className="h-3 w-3" />
                        <AlertDescription className="text-xs">
                          This entitlement is limited to select users with specific business needs
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* LOB Restrictions */}
          <Card className="border-l-4 border-l-gold">
            <CardHeader>
              <CardTitle className="text-base">LOB Entitlement Rules</CardTitle>
              <CardDescription>Special restrictions for Line of Business access</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-2 p-3 bg-muted rounded-md">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <div className="text-sm">
                  <div className="font-medium">Central Team Users - Multiple LOBs</div>
                  <div className="text-muted-foreground">Central team analysts and managers may have access to more than one LOB based on expertise</div>
                </div>
              </div>
              <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-md">
                <Lock className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                <div className="text-sm">
                  <div className="font-medium text-red-900">Sales Owners - Single LOB</div>
                  <div className="text-red-700">Sales owners will be limited to one LOB to maintain clear accountability</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Access Matrix Tab */}
        <TabsContent value="matrix" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Role-Based Access Control Matrix</CardTitle>
              <CardDescription>Comprehensive view of permissions by role type</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[200px]">Permission</TableHead>
                      <TableHead className="text-center">Central Team Analyst</TableHead>
                      <TableHead className="text-center">Central Team Manager</TableHead>
                      <TableHead className="text-center">View Only</TableHead>
                      <TableHead className="text-center">Sales Owner</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">View Dashboard</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.viewDashboard)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.viewDashboard)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.viewDashboard)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.viewDashboard)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">View Worklist</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.viewWorklist)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.viewWorklist)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.viewWorklist)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.viewWorklist)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Open Cases</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.openCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.openCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.openCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.openCases)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Review All Data</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.reviewData)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.reviewData)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.reviewData)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.reviewData)}</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/50">
                      <TableCell className="font-medium">Action Cases</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.actionCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.actionCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.actionCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.actionCases)}</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/50">
                      <TableCell className="font-medium">Assign Cases</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.assignCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.assignCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.assignCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.assignCases)}</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/50">
                      <TableCell className="font-medium">Reassign Cases</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.reassignCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.reassignCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.reassignCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.reassignCases)}</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/50">
                      <TableCell className="font-medium">Reopen Cases (Quality)</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.reopenCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.reopenCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.reopenCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.reopenCases)}</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/50">
                      <TableCell className="font-medium">Abandon Cases</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.abandonCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.abandonCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.abandonCases)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.abandonCases)}</TableCell>
                    </TableRow>
                    <TableRow className="bg-blue-50">
                      <TableCell className="font-medium">Provide Sales Feedback</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.salesFeedback)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.salesFeedback)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.salesFeedback)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.salesFeedback)}</TableCell>
                    </TableRow>
                    <TableRow className="bg-blue-50">
                      <TableCell className="font-medium">Return to Analyst</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[0].permissions.returnToAnalyst)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[1].permissions.returnToAnalyst)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[2].permissions.returnToAnalyst)}</TableCell>
                      <TableCell className="text-center">{getPermissionIcon(roleDefinitions[3].permissions.returnToAnalyst)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* User Distribution */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Users by Role</CardTitle>
                <CardDescription>Distribution of active users across roles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {stats.byRole.map((role) => (
                  <div key={role.role} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>{role.role}</span>
                      <span className="font-medium">{role.count}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Top Entitlements</CardTitle>
                <CardDescription>Most commonly assigned entitlements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {stats.byEntitlement.slice(0, 5).map((ent) => (
                  <div key={ent.entitlement} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>{ent.entitlement}</span>
                      <span className="font-medium">{ent.count}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}