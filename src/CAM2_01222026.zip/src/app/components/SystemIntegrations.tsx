import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { Progress } from "./ui/progress";
import { Separator } from "./ui/separator";
import { Database, CheckCircle2, AlertCircle, RefreshCw, Settings, Activity, TrendingUp, Server, AlertTriangle } from 'lucide-react';
import { SystemIntegration, IntegrationStatus, CAMIntegrationCategory } from '../types';

const systemIntegrations: SystemIntegration[] = [
  {
    id: 'INT-001',
    name: 'Cesium',
    type: 'Client Data',
    description: 'Global Banking and Global Markets client data',
    status: 'Connected',
    lastSync: '2025-10-26T10:30:00',
    recordCount: 45230,
    errorCount: 0,
    dataAttributes: ['Party ID', 'Legal Name', 'GCI Number', 'CoPer ID', 'Sales Owner(s)', 'Purpose of Relationship'],
    linesOfBusiness: ['GB/GM']
  },
  {
    id: 'INT-002',
    name: 'AWARE Datamari',
    type: 'Client Data',
    description: 'GBGM 312 expected activity data',
    status: 'Connected',
    lastSync: '2025-10-26T10:25:00',
    recordCount: 38456,
    errorCount: 0,
    dataAttributes: ['Expected Activity Volume', 'Expected Activity Value', 'Expected Cross-Border Activity'],
    linesOfBusiness: ['GB/GM']
  },
  {
    id: 'INT-003',
    name: 'Population Manager Tool',
    type: 'Client Data',
    description: 'DGA due dates for all lines of business',
    status: 'Connected',
    lastSync: '2025-10-26T10:27:00',
    recordCount: 12890,
    errorCount: 0,
    dataAttributes: ['Refresh Due Date', 'Due Date', 'DGA Anniversary Dates', 'Family Anniversary Date', 'Review Cycle Data'],
    linesOfBusiness: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI']
  },
  {
    id: 'INT-004',
    name: 'CRH',
    type: 'Client Data',
    description: 'Consumer client data (Consumer Relationship Hub)',
    status: 'Connected',
    lastSync: '2025-10-26T10:15:00',
    recordCount: 128456,
    errorCount: 3,
    dataAttributes: ['Party ID', 'Legal Name', 'First Name', 'Middle Name', 'Last Name', 'Refresh Completion Date'],
    linesOfBusiness: ['Consumer']
  },
  {
    id: 'INT-005',
    name: 'GDPP',
    type: 'Client Data',
    description: 'Private Bank, Merrill Lynch, Consumer investments (Global Data Privacy Platform)',
    status: 'Connected',
    lastSync: '2025-10-26T10:28:00',
    recordCount: 67543,
    errorCount: 1,
    dataAttributes: ['Party ID', 'GCI Number', 'MP ID', 'Purpose of Account', 'Source of Funds', 'PVT Code'],
    linesOfBusiness: ['PB', 'ML', 'Consumer']
  },
  {
    id: 'INT-006',
    name: 'GWIM Hub',
    type: 'Client Data',
    description: 'Merrill Lynch and Consumer Investments (Global Wealth & Investment Management Hub)',
    status: 'Connected',
    lastSync: '2025-10-26T10:32:00',
    recordCount: 89234,
    errorCount: 0,
    dataAttributes: ['Party ID', 'MP ID', 'Producer ID', 'ML Flag', 'Client Owners', 'Refresh Completion Date'],
    linesOfBusiness: ['ML', 'Consumer']
  },
  {
    id: 'INT-007',
    name: 'PRDS',
    type: 'Client Data',
    description: 'All Lines of Business (Party Reference Data System)',
    status: 'Connected',
    lastSync: '2025-10-26T10:35:00',
    recordCount: 234567,
    errorCount: 0,
    dataAttributes: ['Party ID', 'Employee Indicator', 'Affiliate Indicator'],
    linesOfBusiness: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI']
  },
  {
    id: 'INT-008',
    name: 'GFC Search Analytics',
    type: 'Monitoring Data',
    description: 'Global Financial Crimes search and analytics data layer - Consumes CAM case data',
    status: 'Connected',
    lastSync: '2025-10-26T10:20:00',
    recordCount: 89234,
    errorCount: 0,
    dataAttributes: ['Search Results', 'Alert History', 'Investigation Notes', 'Case Links', 'CAM Case Status', 'CAM Case Disposition']
  },
  {
    id: 'INT-009',
    name: 'FLU Data Sources',
    type: 'Monitoring Data',
    description: 'Foreign Location Usage monitoring data - Consumes 312 completion status for refresh enablement',
    status: 'Error',
    lastSync: '2025-10-26T08:45:00',
    recordCount: 23456,
    errorCount: 45,
    dataAttributes: ['FLU Cases', 'Geographic Risk', 'Transaction Location', 'Monitoring Status', '312 Completion Status']
  },
  {
    id: 'INT-010',
    name: 'TRMS',
    type: 'Monitoring Data',
    description: 'Transaction Risk Management System',
    status: 'Connected',
    lastSync: '2025-10-26T10:30:00',
    recordCount: 45678,
    errorCount: 2,
    dataAttributes: ['TRMS Case ID', 'Case Type', 'Open Date', 'Status', 'Due Date']
  },
  {
    id: 'INT-011',
    name: 'SAR System',
    type: 'Monitoring Data',
    description: 'Suspicious Activity Report filing system',
    status: 'Connected',
    lastSync: '2025-10-26T10:22:00',
    recordCount: 3456,
    errorCount: 0,
    dataAttributes: ['SAR ID', 'Filing Date', 'SAR Type', 'Amount', 'Narrative']
  },
  {
    id: 'INT-012',
    name: 'Alert Management System',
    type: 'Monitoring Data',
    description: 'Consolidated alerts for sanctions, fraud, payments, and AML',
    status: 'Connected',
    lastSync: '2025-10-26T10:33:00',
    recordCount: 67890,
    errorCount: 5,
    dataAttributes: ['Sanctions Alerts', 'Fraud Alerts', 'Payment Alerts', 'AML Alerts', 'Alert Severity']
  },
  {
    id: 'INT-013',
    name: 'ORRCA',
    type: 'Risk Data',
    description: 'Operational Risk and Client Assessment - Dynamic Risk Rating',
    status: 'Connected',
    lastSync: '2025-10-26T10:35:00',
    recordCount: 156789,
    errorCount: 0,
    dataAttributes: ['Dynamic Risk Rating', 'Risk Score', 'Risk Factors', 'PVT Code from CRA', 'Last Assessment Date']
  },
  {
    id: 'INT-014',
    name: '312 Model',
    type: 'Risk Data',
    description: '312 client population identification model - Provides and consumes 312 completion status',
    status: 'Connected',
    lastSync: '2025-10-26T09:00:00',
    recordCount: 1247,
    errorCount: 0,
    dataAttributes: ['312 Flag', 'Model Score', 'Risk Indicators', 'Model Run Date', '312 Completion Status', '312 Disposition']
  }
];

const dataAttributes = [
  { category: 'Client Information', attributes: [
    { name: 'Legal Name', source: 'Cesium, AWAREWCC, CMT', type: 'String', required: true },
    { name: 'Client ID', source: 'All Systems', type: 'String', required: true },
    { name: 'GCI Number', source: 'Cesium, PRDS', type: 'String', required: true },
    { name: 'Sales Owner', source: 'Cesium, CMT', type: 'String', required: true },
    { name: 'Line of Business', source: 'PRDS', type: 'Enum', required: true },
    { name: 'Account Open Date', source: 'Cesium, AWAREWCC', type: 'Date', required: true },
  ]},
  { category: 'Risk and Monitoring', attributes: [
    { name: 'Dynamic Risk Rating', source: 'ORRCA', type: 'Number', required: true },
    { name: '312 Model Score', source: '312 Model', type: 'Number', required: false },
    { name: '312 Flag', source: '312 Model', type: 'Boolean', required: true },
    { name: 'FLU Case Status', source: 'FLU Data Sources', type: 'String', required: false },
    { name: 'Last Assessment Date', source: 'ORRCA', type: 'Date', required: true },
  ]},
  { category: 'Case and Alert Data', attributes: [
    { name: 'TRMS Case ID', source: 'TRMS', type: 'String', required: false },
    { name: 'TRMS Case Type', source: 'TRMS', type: 'String', required: false },
    { name: 'TRMS Case Status', source: 'TRMS', type: 'String', required: false },
    { name: 'SAR Filed', source: 'SAR System', type: 'Boolean', required: true },
    { name: 'SAR Details', source: 'SAR System', type: 'Object', required: false },
    { name: 'Sanctions Alerts', source: 'Alert Management', type: 'Number', required: true },
    { name: 'Fraud Alerts', source: 'Alert Management', type: 'Number', required: true },
    { name: 'Payment Alerts', source: 'Alert Management', type: 'Number', required: true },
    { name: 'AML Alerts', source: 'Alert Management', type: 'Number', required: true },
  ]},
];

const camIntegrationAttributes: CAMIntegrationCategory[] = [
  { 
    category: '312 Case Data (Outbound to FLU Tools & GFC Search)', 
    description: 'Data exported from CAM to enable refresh completion and case tracking',
    attributes: [
      { 
        name: 'CAM Case Number', 
        source: 'CAM Platform', 
        type: 'String', 
        required: true,
        consumers: 'FLU Tools, GFC Search Analytics',
        description: 'Unique identifier for the CAM case'
      },
      { 
        name: '312 Case Completion Status', 
        source: 'CAM Platform (Derived)', 
        type: 'Enum', 
        required: true,
        consumers: 'FLU Tools, 312 Model',
        description: 'Status at LOB level - enables/disables refresh completion in FLU tools. Values: Complete, Incomplete, Pending'
      },
      { 
        name: '312 Case Disposition', 
        source: 'CAM Platform (Derived)', 
        type: 'Enum', 
        required: true,
        consumers: 'GFC Search Analytics, 312 Model',
        description: 'Derived field indicating escalation. Values: "312 Activity Escalated" (TRMS filed or client closed), "312 Activity in line with expected activity"'
      },
      { 
        name: '312 Case Auto-Closure', 
        source: 'CAM Platform (Derived)', 
        type: 'Boolean', 
        required: true,
        consumers: 'All FLU Tools, Reporting',
        description: 'Indicates if 312 case was auto-closed based on system rules'
      },
    ]
  },
  { 
    category: 'CAM Case Data (Outbound to GFC Search & All FLU Tools)', 
    description: 'General CAM case outcome data available for all downstream systems',
    attributes: [
      { 
        name: 'CAM Case Completion Status', 
        source: 'CAM Platform', 
        type: 'Enum', 
        required: true,
        consumers: 'GFC Search Analytics, All FLU Tools',
        description: 'Overall CAM case completion status. Available as a case type in client profile on GFC Search Analytics'
      },
      { 
        name: 'CAM Case Disposition', 
        source: 'CAM Platform (Derived)', 
        type: 'Enum', 
        required: true,
        consumers: 'GFC Search Analytics, All FLU Tools',
        description: 'Derived field indicating escalation. Values: "CAM Case Escalated" (TRMS filed), "No additional CAM escalation required"'
      },
      { 
        name: 'CAM Case Auto Closure', 
        source: 'CAM Platform (Derived)', 
        type: 'Boolean', 
        required: true,
        consumers: 'All FLU Tools, Reporting',
        description: 'Indicates if CAM case was auto-closed based on system rules'
      },
    ]
  },
  { 
    category: 'Client Data Sources (Inbound to CAM)', 
    description: 'Client data ingested into CAM for case completion',
    attributes: [
      { 
        name: 'Consumer Client Data', 
        source: 'AWAREWCC', 
        type: 'Object', 
        required: true,
        consumers: 'CAM Platform',
        description: 'Consumer banking client profiles and account information'
      },
      { 
        name: 'Consumer Due Dates', 
        source: 'CRH', 
        type: 'Date', 
        required: true,
        consumers: 'CAM Platform',
        description: 'Consumer-specific case due dates and refresh schedules'
      },
      { 
        name: 'Private Banking Data', 
        source: 'CMT', 
        type: 'Object', 
        required: true,
        consumers: 'CAM Platform',
        description: 'Private banking client management and relationship data'
      },
      { 
        name: 'Merrill Lynch/CI Profile', 
        source: 'Client Profile/GWIM Hub', 
        type: 'Object', 
        required: true,
        consumers: 'CAM Platform',
        description: 'Merrill Lynch and Consumer Investments client profiles'
      },
    ]
  },
];

export function SystemIntegrations() {
  const getStatusIcon = (status: IntegrationStatus) => {
    switch (status) {
      case 'Connected':
        return <CheckCircle2 className="h-5 w-5 text-green-600" />;
      case 'Syncing':
        return <RefreshCw className="h-5 w-5 text-primary animate-spin" />;
      case 'Error':
        return <AlertCircle className="h-5 w-5 text-destructive" />;
      case 'Disconnected':
        return <AlertTriangle className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: IntegrationStatus) => {
    const variants: Record<IntegrationStatus, any> = {
      'Connected': 'default',
      'Syncing': 'secondary',
      'Error': 'destructive',
      'Disconnected': 'outline'
    };
    return <Badge variant={variants[status]}>{status}</Badge>;
  };

  const connectedCount = systemIntegrations.filter(i => i.status === 'Connected').length;
  const errorCount = systemIntegrations.filter(i => i.status === 'Error').length;
  const totalRecords = systemIntegrations.reduce((sum, i) => sum + i.recordCount, 0);
  const totalErrors = systemIntegrations.reduce((sum, i) => sum + i.errorCount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2>System Integrations</h2>
          <p className="text-muted-foreground">Manage data sources and system connections for CAM</p>
        </div>
        <Button>
          <RefreshCw className="mr-2 h-4 w-4" />
          Sync All Systems
        </Button>
      </div>

      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Connected Systems</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{connectedCount}/{systemIntegrations.length}</div>
            <Progress value={(connectedCount / systemIntegrations.length) * 100} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Records</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{(totalRecords / 1000).toFixed(0)}K</div>
            <p className="text-xs text-muted-foreground">Records synced</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">System Errors</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-red-600">{errorCount}</div>
            <p className="text-xs text-muted-foreground">Systems with errors</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Data Quality</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">99.{totalErrors < 100 ? '9' : '8'}%</div>
            <p className="text-xs text-muted-foreground">Accuracy rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Error Alert */}
      {errorCount > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {errorCount} system integration{errorCount > 1 ? 's have' : ' has'} errors. Please review and resolve integration issues.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="integrations" className="space-y-4">
        <TabsList>
          <TabsTrigger value="integrations">System Integrations</TabsTrigger>
          <TabsTrigger value="client-data">Client Data Sources</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring & Risk</TabsTrigger>
          <TabsTrigger value="cam-312">CAM & 312 Data Flow</TabsTrigger>
          <TabsTrigger value="attributes">Data Attributes</TabsTrigger>
        </TabsList>

        <TabsContent value="integrations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All System Integrations</CardTitle>
              <CardDescription>Complete list of integrated systems and their status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>System Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Sync</TableHead>
                      <TableHead>Records</TableHead>
                      <TableHead>Errors</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {systemIntegrations.map((integration) => (
                      <TableRow key={integration.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(integration.status)}
                            <span className="font-medium">{integration.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{integration.type}</Badge>
                        </TableCell>
                        <TableCell className="max-w-xs text-sm text-muted-foreground">
                          {integration.description}
                        </TableCell>
                        <TableCell>{getStatusBadge(integration.status)}</TableCell>
                        <TableCell className="text-sm">
                          {new Date(integration.lastSync).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-sm">
                          {integration.recordCount.toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {integration.errorCount > 0 ? (
                            <Badge variant="destructive">{integration.errorCount}</Badge>
                          ) : (
                            <span className="text-sm text-muted-foreground">0</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Settings className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="client-data" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {systemIntegrations
              .filter(i => i.type === 'Client Data')
              .map(integration => (
                <Card key={integration.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Server className="h-5 w-5" />
                        <CardTitle className="text-base">{integration.name}</CardTitle>
                      </div>
                      {getStatusBadge(integration.status)}
                    </div>
                    <CardDescription>{integration.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Records Synced</span>
                        <span className="font-medium">{integration.recordCount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Last Sync</span>
                        <span className="font-medium">
                          {new Date(integration.lastSync).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Error Count</span>
                        <span className={integration.errorCount > 0 ? 'font-medium text-red-600' : 'font-medium'}>
                          {integration.errorCount}
                        </span>
                      </div>
                    </div>
                    <Separator />
                    {integration.linesOfBusiness && (
                      <div className="space-y-2">
                        <div className="text-sm text-muted-foreground">Lines of Business</div>
                        <div className="flex flex-wrap gap-1">
                          {integration.linesOfBusiness.map(lob => (
                            <Badge key={lob} variant="secondary" className="text-xs">
                              {lob}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Data Attributes</div>
                      <div className="flex flex-wrap gap-1">
                        {integration.dataAttributes.slice(0, 3).map(attr => (
                          <Badge key={attr} variant="outline" className="text-xs">
                            {attr}
                          </Badge>
                        ))}
                        {integration.dataAttributes.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{integration.dataAttributes.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {systemIntegrations
              .filter(i => i.type === 'Monitoring Data' || i.type === 'Risk Data')
              .map(integration => (
                <Card key={integration.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Activity className="h-5 w-5" />
                        <CardTitle className="text-base">{integration.name}</CardTitle>
                      </div>
                      {getStatusBadge(integration.status)}
                    </div>
                    <CardDescription>{integration.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Records Synced</span>
                        <span className="font-medium">{integration.recordCount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Last Sync</span>
                        <span className="font-medium">
                          {new Date(integration.lastSync).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Error Count</span>
                        <span className={integration.errorCount > 0 ? 'font-medium text-red-600' : 'font-medium'}>
                          {integration.errorCount}
                        </span>
                      </div>
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Data Attributes</div>
                      <div className="flex flex-wrap gap-1">
                        {integration.dataAttributes.map(attr => (
                          <Badge key={attr} variant="outline" className="text-xs">
                            {attr}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      <Settings className="mr-2 h-4 w-4" />
                      Configure Integration
                    </Button>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="cam-312" className="space-y-4">
          <Alert>
            <Activity className="h-4 w-4" />
            <AlertDescription>
              This section details the bi-directional data flow between CAM and integrated systems for 312 population monitoring and case completion.
            </AlertDescription>
          </Alert>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="border-primary/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-primary" />
                  <CardTitle className="text-base">Data Flow Summary</CardTitle>
                </div>
                <CardDescription>Integration between CAM, 312 Model, and FLU Tools</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <div className="font-medium">Inbound: Client Data Sources</div>
                      <div className="text-muted-foreground">AWAREWCC, CRH, CMT, GWIM Hub → CAM Platform</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <div className="font-medium">Outbound: 312 Completion Status</div>
                      <div className="text-muted-foreground">CAM Platform → FLU Tools (enables refresh completion)</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <div className="font-medium">Outbound: Case Disposition Data</div>
                      <div className="text-muted-foreground">CAM Platform → GFC Search Analytics (case panel)</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-gold mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <div className="font-medium">Derived Data Fields</div>
                      <div className="text-muted-foreground">Auto-closure flags, dispositions, escalation indicators</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-gold/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-gold" />
                  <CardTitle className="text-base">Key Integration Points</CardTitle>
                </div>
                <CardDescription>Critical system dependencies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="p-2 bg-muted rounded-md">
                    <div className="text-sm font-medium">312 Completion → FLU Refresh</div>
                    <div className="text-xs text-muted-foreground">312 case completion at LOB level enables/disables refresh functionality in FLU tools</div>
                  </div>
                  <div className="p-2 bg-muted rounded-md">
                    <div className="text-sm font-medium">CAM Cases → GFC Search</div>
                    <div className="text-xs text-muted-foreground">CAM case outcomes appear as case type in client profile on GFC Search Analytics</div>
                  </div>
                  <div className="p-2 bg-muted rounded-md">
                    <div className="text-sm font-medium">Escalation Logic</div>
                    <div className="text-xs text-muted-foreground">TRMS filed or client closed triggers "312 Activity Escalated" disposition</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>CAM & 312 Data Attributes</CardTitle>
              <CardDescription>Complete mapping of data attributes for CAM case ingestion and 312 population disposition</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {camIntegrationAttributes.map(category => (
                <div key={category.category} className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Server className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <h3 className="text-sm font-medium">{category.category}</h3>
                      <p className="text-xs text-muted-foreground mt-1">{category.description}</p>
                    </div>
                  </div>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Attribute Name</TableHead>
                          <TableHead>Source System</TableHead>
                          <TableHead>Consumer Systems</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Description</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {category.attributes.map(attr => (
                          <TableRow key={attr.name}>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                {attr.required && (
                                  <span className="text-xs text-red-600">*</span>
                                )}
                                {attr.name}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {attr.source}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground max-w-[200px]">
                              {attr.consumers}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="text-xs">
                                {attr.type}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs text-muted-foreground max-w-xs">
                              {attr.description}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-primary">
            <CardHeader>
              <CardTitle className="text-base">Derived Data Field Definitions</CardTitle>
              <CardDescription>Logic and calculation rules for derived attributes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 bg-muted rounded-md space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="default">312 Case Disposition</Badge>
                  </div>
                  <div className="text-sm space-y-1">
                    <div className="font-medium">Values:</div>
                    <ul className="list-disc list-inside text-muted-foreground pl-2 space-y-1">
                      <li><span className="font-medium text-foreground">"312 Activity Escalated"</span> - When TRMS is filed OR client indicated as closed</li>
                      <li><span className="font-medium text-foreground">"312 Activity in line with expected activity"</span> - No escalation required</li>
                    </ul>
                  </div>
                </div>

                <div className="p-3 bg-muted rounded-md space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="default">CAM Case Disposition</Badge>
                  </div>
                  <div className="text-sm space-y-1">
                    <div className="font-medium">Values:</div>
                    <ul className="list-disc list-inside text-muted-foreground pl-2 space-y-1">
                      <li><span className="font-medium text-foreground">"CAM Case Escalated"</span> - When TRMS is filed</li>
                      <li><span className="font-medium text-foreground">"No additional CAM escalation required"</span> - No escalation</li>
                    </ul>
                  </div>
                </div>

                <div className="p-3 bg-muted rounded-md space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="default">312 Completion Status</Badge>
                  </div>
                  <div className="text-sm space-y-1">
                    <div className="font-medium">Purpose:</div>
                    <p className="text-muted-foreground">Status at LOB level determines if FLU tools can complete refresh operations. FLU tools leverage this to enable/disable refresh completion functionality.</p>
                    <div className="font-medium mt-2">Values:</div>
                    <ul className="list-disc list-inside text-muted-foreground pl-2">
                      <li>Complete, Incomplete, Pending</li>
                    </ul>
                  </div>
                </div>

                <div className="p-3 bg-muted rounded-md space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="default">Auto-Closure Flags</Badge>
                  </div>
                  <div className="text-sm space-y-1">
                    <div className="font-medium">Purpose:</div>
                    <p className="text-muted-foreground">Boolean indicators showing whether cases were closed automatically based on system-defined rules vs. manual analyst review and disposition.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attributes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Data Attribute Mapping</CardTitle>
              <CardDescription>Complete list of data attributes ingested from integrated systems</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {dataAttributes.map(category => (
                <div key={category.category} className="space-y-3">
                  <h3 className="text-sm font-medium">{category.category}</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Attribute Name</TableHead>
                          <TableHead>Source System(s)</TableHead>
                          <TableHead>Data Type</TableHead>
                          <TableHead>Required</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {category.attributes.map(attr => (
                          <TableRow key={attr.name}>
                            <TableCell className="font-medium">{attr.name}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">{attr.source}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{attr.type}</Badge>
                            </TableCell>
                            <TableCell>
                              {attr.required ? (
                                <Badge variant="default">Required</Badge>
                              ) : (
                                <Badge variant="secondary">Optional</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}