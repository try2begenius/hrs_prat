export type CaseStatus = 'Unassigned' | 'In Progress' | 'Pending Sales Review' | 'In Sales Review' | 'Sales Review Complete' | 'Complete' | 'Defect Remediation' | 'Under Review' | 'Escalated' | 'Closed' | 'Rejected';
export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';
export type Priority = 'Low' | 'Medium' | 'High' | 'Urgent';
export type UserRole = 'Analyst' | 'Manager' | 'Administrator';
export type LineOfBusiness = 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI';
export type IntegrationStatus = 'Connected' | 'Syncing' | 'Error' | 'Disconnected';
export type ModelOutcome = 'No additional CAM escalation required' | 'CAM Case Escalated' | 'Pending Review';
export type CaseDisposition = 'No additional CAM escalation required' | 'CAM Case Escalated' | 'TRMS Filed' | 'Client Closed' | 'Escalated to Compliance' | 'Pending';

// Client Data (from various sources)
export interface ClientData {
  clientId: string;
  gciNumber: string;
  legalName: string;
  businessName?: string;
  salesOwner: string;
  lineOfBusiness: LineOfBusiness;
  accountOpenDate: string;
  clientType: string;
  jurisdiction: string;
  dataSource: 'Cesium' | 'WCC' | 'CMT' | 'GWIM Hub' | 'PRDS' | 'CP';
  lastUpdated: string;
  isEmployee?: boolean;
  mpId?: string; // MP ID from GWIM Hub
}

// Monitoring and Risk Data
export interface MonitoringData {
  dynamicRiskRating: number; // ORRCA
  riskRatingDate: string;
  model312Score?: number; // 312 model
  model312Flag: boolean;
  fluMonitoringStatus?: string; // FLU Data Sources
  fluCaseId?: string;
  lastMonitoringDate: string;
}

// TRMS Case Details
export interface TRMSCase {
  caseId: string;
  caseType: string;
  openDate: string;
  status: string;
  priority: string;
  dueDate: string;
}

// Alert Data
export interface AlertData {
  sanctionsAlerts: number;
  fraudAlerts: number;
  paymentAlerts: number;
  moneyLaunderingAlerts: number;
  totalAlerts: number;
}

// SAR Details
export interface SARData {
  sarFiled: boolean;
  sarId?: string;
  sarFilingDate?: string;
  sarType?: string;
  sarAmount?: number;
}

// Enhanced Case with full integration data
export interface Case {
  id: string;
  clientId: string;
  gci: string; // GCI Number (Global Client Identifier)
  mpId?: string; // MP ID (Master Party ID)
  partyId?: string; // Party ID
  coperId?: string; // CoPer ID (not all clients have this)
  clientName: string;
  caseType: string;
  status: CaseStatus;
  riskLevel: RiskLevel;
  priority: Priority;
  assignedTo: string;
  centralTeamContact?: string; // Original analyst who sent case to sales (for sales owner view)
  createdDate: string;
  dueDate: string;
  lastActivity: string;
  // Workbasket indicators
  isBACEmployee?: boolean; // BAC Employee Indicator
  isBACAffiliate?: boolean; // BAC Affiliate Indicator
  isRegO?: boolean; // Reg O Indicator
  isManuallyTriggered?: boolean; // Manually Triggered (ad-hoc process)
  alertCount: number;
  transactionCount: number;
  totalAmount: number;
  description: string;
  lineOfBusiness?: LineOfBusiness; // Used to restrict sales review for CI/Consumer
  is312Case?: boolean; // Indicator if case is 312 combination or CAM only
  // Case Flow Fields
  autoClosed?: boolean;
  modelOutcome?: ModelOutcome;
  derivedDisposition?: CaseDisposition;
  completionDate?: string;
  originalCompletionDate?: string; // Preserved when reopened for remediation
  defectRemediationFlag?: boolean;
  salesReviewComments?: string;
  // Enhanced fields from integrations
  clientData?: ClientData;
  monitoringData?: MonitoringData;
  trmsCase?: TRMSCase;
  alertData?: AlertData;
  sarData?: SARData;
  gfcSearchAnalytics?: any; // GFC Search Analytics data
  // Enhanced Case UI Data
  case312Data?: Case312Data;
  case312Response?: Case312Response;
  camCaseData?: CAMCaseData;
  camCaseResponse?: CAMCaseResponse;
  monitoringDashboard?: MonitoringDashboard;
  caseProcessorComments?: CaseProcessorComment[];
  salesOwnerResponse?: SalesOwnerResponse;
  entityName?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  naicsCode?: string;
  naicsDescription?: string;
  refreshDueDates?: string[];
  lastRefreshCompletionDate?: string; // Last Refresh Completion Date
  clientOwners?: string[];
  amlAttributes?: string[]; // AML Attributes / CBA codes
}

export interface Activity {
  id: string;
  caseId: string;
  type: string;
  description: string;
  user: string;
  timestamp: string;
}

export interface Alert {
  id: string;
  caseId: string;
  type: string;
  severity: RiskLevel;
  description: string;
  date: string;
  status: 'Open' | 'Acknowledged' | 'Resolved';
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  hasM_I_Entitlement?: boolean; // M&I (Monitoring & Investigations) entitlement for defect remediation
}

export interface Population {
  id: string;
  name: string;
  criteria: string;
  clientCount: number;
  riskScore: number;
  lastRun: string;
  status: 'Active' | 'Inactive' | 'Pending';
}

export interface Report {
  id: string;
  name: string;
  type: string;
  generatedBy: string;
  generatedDate: string;
  status: 'Completed' | 'Processing' | 'Failed';
  format: 'PDF' | 'Excel' | 'CSV';
}

// System Integrations
export interface SystemIntegration {
  id: string;
  name: string;
  type: 'Client Data' | 'Monitoring Data' | 'Risk Data';
  description: string;
  status: IntegrationStatus;
  lastSync: string;
  recordCount: number;
  errorCount: number;
  dataAttributes: string[];
  linesOfBusiness?: LineOfBusiness[];
}

export interface DataAttribute {
  name: string;
  source: string;
  type: string;
  required: boolean;
  description: string;
  consumers?: string;
}

// CAM & 312 Integration specific types
export interface CAMIntegrationAttribute {
  name: string;
  source: string;
  type: string;
  required: boolean;
  consumers: string;
  description: string;
}

export interface CAMIntegrationCategory {
  category: string;
  description: string;
  attributes: CAMIntegrationAttribute[];
}

// Enhanced Case UI Types
export interface Case312Account {
  accountNumber: string;
  accountName: string;
  sourceOfFunds: string;
}

export interface Case312Data {
  dueDate: string;
  aging: number;
  status: string;
  disposition?: string;
  completedDate?: string;
  modelResult: string;
  modelResultDescription: string;
  expectedActivityVolume: {
    electronicTransfers?: number;
    cashChecks?: number;
    ddqFields?: Record<string, number>;
  };
  expectedActivityValue: {
    electronicTransfers?: number;
    cashChecks?: number;
    ddqFields?: Record<string, number>;
  };
  expectedCrossBorderActivity?: string; // Expected cross-border countries/activities
  purposeOfRelationship?: string; // GB/GM only
  purposeOfAccount?: string; // ML/PB only - text description
  purposeOfAccountDetails?: Case312Account[]; // ML/PB only - account grid details
  sourceOfFunds?: string; // ML/PB only - general source of funds
}

export interface Case312Response {
  // Question 1: Expected Value and Volume of Money Movement, Inclusive of Cash Review
  question1_disposition?: 'need_trms' | 'not_unusual_other' | 'not_unusual_market_volatility';
  question1_commentary?: string;
  
  // Question 2: Cross Border Money Movement Review
  question2_disposition?: 'need_trms' | 'not_unusual';
  question2_commentary?: string;
  
  // Question 3: Purpose of Relationship/Account
  question3_option?: 'all_aligned' | 'need_trms' | 'activity_differed';
  question3_comments?: string; // Required if 'activity_differed'
  
  // Question 4: Source of Funds (ML only)
  question4_disposition?: 'need_trms' | 'not_unusual';
  question4_commentary?: string;
  
  // Case Action
  caseAction?: 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales';
  trmsNumber?: string; // Required if caseAction = 'complete_trms_filed'
  salesOwner?: string; // Required if caseAction = 'send_to_sales'
  salesComments?: string; // Optional for send_to_sales
  
  // Submission metadata
  submittedBy?: string;
  submittedDate?: string;
  isSubmitted?: boolean;
}

export interface CAMCaseData {
  dueDate: string;
  aging: number;
  status: string;
  disposition?: string;
  completedDate?: string;
  triggers: string[];
}

export interface TRMSRecord {
  id: string;
  type: string;
  monitoringProcess: string;
  descriptionReason: string;
  impactType: string;
  narrative: string;
  date: string;
  submitterLOB: string;
}

export interface SecondLineCase {
  caseId: string;
  caseType: string;
  caseStatus: string;
  caseDescription: string;
  monitoringProcess: string;
  narrative: string;
  date: string;
  lob: string;
  linkedTRMS?: string;
  sarYN: boolean;
  partyInSAR?: string;
}

export interface FraudCase {
  caseId: string;
  caseStatus: string;
  narrative: string;
  date: string;
  lob: string;
  sarYN: boolean;
  partyInSAR?: string;
}

export interface SanctionDetail {
  caseId: string;
  product: string;
  alertDate: string;
  alertDescription: string;
  blockReject: boolean;
  lob: string;
  outcome: string;
}

export interface Alert312Detail {
  lob312: string;
  alertDate: string;
  alertDescription: string;
}

export interface LOBMonitoringControl {
  activityDescription: string;
  supportingDataPoints: string;
}

export interface CAMCaseResponse {
  question1: boolean | null;
  question1_1_attestations?: string[];
  question1_2_trms?: string;
  question1_3_trmsNumber?: string;
  question2_confirmation?: boolean;
  question3_action?: 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales';
  question3_trms?: string;
  question3_salesOwner?: string;
  question3_comments?: string;
  question3_confirmation?: boolean; // Confirmation checkbox for case action attestation
  submittedBy?: string;
  submittedDate?: string;
  isSubmitted?: boolean;
}

export interface CaseProcessorComment {
  caseType: '312' | 'CAM';
  processorName: string;
  comment: string;
  date: string;
}

export interface SalesOwnerResponse {
  comments: string;
  submittedBy?: string;
  submittedDate?: string;
  isSubmitted?: boolean;
}

export interface MonitoringDashboard {
  trmsFLU: TRMSRecord[];
  trmsOther: TRMSRecord[];
  secondLineCases: SecondLineCase[];
  fraudCases: FraudCase[];
  sanctionDetails: SanctionDetail[];
  alert312Details: Alert312Detail[];
  lobMonitoringControls: LOBMonitoringControl[];
}