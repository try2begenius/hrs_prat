export interface ClientForEvaluation {
  id: string;
  clientId: string;
  legalName: string;
  riskRating: 'High' | 'Elevated' | 'Standard' | 'Low';
  has312Flag: boolean;
  hasModelActivity: boolean;
  cam312Decision?: 'Full Review' | 'Auto-Close' | 'Not Applicable';
  camDecision?: 'Full Review' | 'Auto-Close' | 'Pending 312';
  cam312CaseId?: string;
  camCaseId?: string;
  createdDate?: string;
}

export const mockClientsForEvaluation: ClientForEvaluation[] = [
  {
    id: '1',
    clientId: 'GB-10234',
    legalName: 'Horizon Capital Partners Ltd',
    riskRating: 'High',
    has312Flag: true,
    hasModelActivity: true,
    cam312Decision: 'Full Review',
    camDecision: 'Full Review',
    cam312CaseId: 'CAM312-2026-001',
    camCaseId: 'CAM-2026-001',
    createdDate: '2026-01-15'
  },
  {
    id: '2',
    clientId: 'PB-20451',
    legalName: 'Westfield Family Trust',
    riskRating: 'High',
    has312Flag: true,
    hasModelActivity: false,
    cam312Decision: 'Auto-Close',
    camDecision: 'Full Review',
    cam312CaseId: 'CAM312-2026-002',
    camCaseId: 'CAM-2026-002',
    createdDate: '2026-01-16'
  },
  {
    id: '3',
    clientId: 'GB-10567',
    legalName: 'Sterling Investments Group',
    riskRating: 'Elevated',
    has312Flag: true,
    hasModelActivity: true,
    cam312Decision: 'Full Review',
    camDecision: 'Auto-Close',
    cam312CaseId: 'CAM312-2026-003',
    createdDate: '2026-01-17'
  },
  {
    id: '4',
    clientId: 'ML-30234',
    legalName: 'Global Trade Solutions Inc',
    riskRating: 'High',
    has312Flag: true,
    hasModelActivity: true,
    cam312Decision: 'Full Review',
    camDecision: 'Full Review',
    cam312CaseId: 'CAM312-2026-004',
    camCaseId: 'CAM-2026-004',
    createdDate: '2026-01-18'
  },
  {
    id: '5',
    clientId: 'GB-10789',
    legalName: 'Oakmont Holdings LLC',
    riskRating: 'Standard',
    has312Flag: true,
    hasModelActivity: false,
    cam312Decision: 'Auto-Close',
    camDecision: 'Auto-Close',
    cam312CaseId: 'CAM312-2026-005',
    createdDate: '2026-01-19'
  },
  {
    id: '6',
    clientId: 'PB-20678',
    legalName: 'Anderson Private Wealth',
    riskRating: 'Elevated',
    has312Flag: false,
    hasModelActivity: false,
    cam312Decision: 'Not Applicable',
    camDecision: 'Auto-Close',
    createdDate: '2026-01-20'
  },
  {
    id: '7',
    clientId: 'GB-10890',
    legalName: 'Pacific Rim Enterprises',
    riskRating: 'Low',
    has312Flag: false,
    hasModelActivity: false,
    cam312Decision: 'Not Applicable',
    camDecision: 'Auto-Close'
  },
  {
    id: '8',
    clientId: 'ML-30456',
    legalName: 'Silverstone Capital Management',
    riskRating: 'High',
    has312Flag: true,
    hasModelActivity: true,
    cam312Decision: 'Full Review',
    camDecision: 'Pending 312',
    cam312CaseId: 'CAM312-2026-008',
    createdDate: '2026-01-21'
  },
  {
    id: '9',
    clientId: 'GB-11001',
    legalName: 'Meridian Strategic Advisors',
    riskRating: 'High',
    has312Flag: true,
    hasModelActivity: true,
    cam312Decision: 'Full Review',
    camDecision: 'Full Review',
    cam312CaseId: 'CAM312-2026-009',
    camCaseId: 'CAM-2026-009',
    createdDate: '2026-01-22'
  },
  {
    id: '10',
    clientId: 'PB-20890',
    legalName: 'Thompson Family Office',
    riskRating: 'High',
    has312Flag: true,
    hasModelActivity: false,
    cam312Decision: 'Auto-Close',
    camDecision: 'Full Review',
    cam312CaseId: 'CAM312-2026-010',
    camCaseId: 'CAM-2026-010',
    createdDate: '2026-01-22'
  }
];

export function calculateStats(clients: ClientForEvaluation[]) {
  const totalEvaluated = clients.length;
  
  // CAM 312 decisions
  const cam312FullReview = clients.filter(c => c.cam312Decision === 'Full Review').length;
  const cam312AutoClose = clients.filter(c => c.cam312Decision === 'Auto-Close').length;
  const cam312NotApplicable = clients.filter(c => c.cam312Decision === 'Not Applicable').length;
  
  // CAM decisions
  const camFullReview = clients.filter(c => c.camDecision === 'Full Review').length;
  const camAutoClose = clients.filter(c => c.camDecision === 'Auto-Close').length;
  const camPending312 = clients.filter(c => c.camDecision === 'Pending 312').length;
  
  return {
    totalEvaluated,
    cam312FullReview,
    cam312AutoClose,
    cam312NotApplicable,
    camFullReview,
    camAutoClose,
    camPending312
  };
}
