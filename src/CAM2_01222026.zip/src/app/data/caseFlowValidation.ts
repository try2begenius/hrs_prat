import { CaseStatus, ModelOutcome, CaseDisposition } from '../types';

/**
 * Case Flow Validation Rules for CAM 312 Cases
 * Based on the requirements for case lifecycle management
 */

export interface StatusTransition {
  from: CaseStatus;
  to: CaseStatus;
  allowedRoles: string[];
  requiresFields?: string[];
  description: string;
}

export interface CaseFlowRule {
  status: CaseStatus;
  nextStatuses: CaseStatus[];
  allowedActions: string[];
  requiredFields: string[];
  actorRoles: string[];
}

// Valid status transitions for CAM 312 cases
export const statusTransitions: StatusTransition[] = [
  // Auto-closed case creation
  {
    from: 'Unassigned',
    to: 'Complete',
    allowedRoles: ['System'],
    requiresFields: ['autoClosed', 'modelOutcome'],
    description: 'Auto-closed case with 312 activity in line with expected activity'
  },
  
  // Manual case assignment
  {
    from: 'Unassigned',
    to: 'In Progress',
    allowedRoles: ['Central Team Manager', 'Central Team Analyst'],
    requiresFields: ['assignedTo'],
    description: 'Case assigned to analyst or selected from workbasket'
  },
  
  // Analyst self-disposition (ONLY Analyst, not Manager)
  {
    from: 'In Progress',
    to: 'Complete',
    allowedRoles: ['Central Team Analyst'],
    requiresFields: ['derivedDisposition', 'modelOutcome'],
    description: 'Central team analyst dispositioned the case'
  },
  
  // Route to sales for review (ONLY Analyst, NOT for CI/Consumer LOBs)
  {
    from: 'In Progress',
    to: 'Pending Sales Review',
    allowedRoles: ['Central Team Analyst'],
    requiresFields: [],
    description: 'Analyst routed case to sales owner for review',
    restrictions: 'Not available for CI and Consumer LOBs'
  },
  
  // Sales owner opens case for review
  {
    from: 'Pending Sales Review',
    to: 'In Sales Review',
    allowedRoles: ['Sales Owner'],
    requiresFields: [],
    description: 'Sales owner opened case for review'
  },
  
  // Sales owner completes review
  {
    from: 'In Sales Review',
    to: 'Sales Review Complete',
    allowedRoles: ['Sales Owner'],
    requiresFields: ['salesReviewComments'],
    description: 'Sales owner provided feedback and returned to analyst'
  },
  
  // Analyst final disposition after sales review (ONLY Analyst)
  {
    from: 'Sales Review Complete',
    to: 'Complete',
    allowedRoles: ['Central Team Analyst'],
    requiresFields: ['derivedDisposition', 'modelOutcome'],
    description: 'Analyst dispositioned and submitted case after sales review'
  },
  
  // Reopen for defect remediation (ONLY Analyst with M&I entitlement)
  {
    from: 'Complete',
    to: 'Defect Remediation',
    allowedRoles: ['Central Team Analyst'],
    requiresFields: ['defectRemediationFlag'],
    description: 'Case reopened for M&I quality review remediation by M&I entitled analyst'
  },
  
  // Complete remediation (ONLY Analyst with M&I entitlement)
  {
    from: 'Defect Remediation',
    to: 'Complete',
    allowedRoles: ['Central Team Analyst'],
    requiresFields: ['derivedDisposition', 'modelOutcome'],
    description: 'Remediation completed and case re-closed by M&I entitled analyst'
  }
];

// Case flow rules by status
export const caseFlowRules: Record<CaseStatus, CaseFlowRule> = {
  'Unassigned': {
    status: 'Unassigned',
    nextStatuses: ['In Progress', 'Complete'],
    allowedActions: ['Assign', 'Auto-Close', 'Select from Workbasket'],
    requiredFields: [],
    actorRoles: ['Central Team Manager', 'Central Team Analyst', 'System']
  },
  
  'In Progress': {
    status: 'In Progress',
    nextStatuses: ['Complete', 'Pending Sales Review'],
    allowedActions: ['Disposition', 'Route to Sales', 'Add Comments', 'Upload Documents'],
    requiredFields: ['assignedTo'],
    actorRoles: ['Central Team Analyst']
  },
  
  'Pending Sales Review': {
    status: 'Pending Sales Review',
    nextStatuses: ['In Sales Review'],
    allowedActions: ['Open Case'],
    requiredFields: ['assignedTo'],
    actorRoles: ['Sales Owner']
  },
  
  'In Sales Review': {
    status: 'In Sales Review',
    nextStatuses: ['Sales Review Complete'],
    allowedActions: ['Add Comments', 'Provide Feedback', 'Return to Analyst'],
    requiredFields: ['assignedTo'],
    actorRoles: ['Sales Owner']
  },
  
  'Sales Review Complete': {
    status: 'Sales Review Complete',
    nextStatuses: ['Complete'],
    allowedActions: ['Disposition', 'Submit', 'Add Comments'],
    requiredFields: ['assignedTo', 'salesReviewComments'],
    actorRoles: ['Central Team Analyst']
  },
  
  'Complete': {
    status: 'Complete',
    nextStatuses: ['Defect Remediation'],
    allowedActions: ['Reopen for Remediation', 'View'],
    requiredFields: ['derivedDisposition', 'modelOutcome', 'completionDate'],
    actorRoles: ['Central Team Analyst', 'View Only']
  },
  
  'Defect Remediation': {
    status: 'Defect Remediation',
    nextStatuses: ['Complete'],
    allowedActions: ['Update', 'Re-Disposition', 'Submit'],
    requiredFields: ['assignedTo', 'defectRemediationFlag', 'originalCompletionDate'],
    actorRoles: ['Central Team Analyst']
  },
  
  // Legacy statuses (for backward compatibility)
  'Under Review': {
    status: 'Under Review',
    nextStatuses: ['Complete', 'Escalated'],
    allowedActions: ['Review', 'Escalate', 'Complete'],
    requiredFields: ['assignedTo'],
    actorRoles: ['Central Team Manager']
  },
  
  'Escalated': {
    status: 'Escalated',
    nextStatuses: ['Complete'],
    allowedActions: ['Resolve', 'Close'],
    requiredFields: ['assignedTo'],
    actorRoles: ['Central Team Manager', 'Administrator']
  },
  
  'Closed': {
    status: 'Closed',
    nextStatuses: [],
    allowedActions: ['View'],
    requiredFields: ['completionDate'],
    actorRoles: ['View Only']
  },
  
  'Rejected': {
    status: 'Rejected',
    nextStatuses: [],
    allowedActions: ['View'],
    requiredFields: ['completionDate'],
    actorRoles: ['View Only']
  }
};

// Model outcome determination logic
export const determineModelOutcome = (
  derivedDisposition: CaseDisposition,
  autoClosed: boolean
): ModelOutcome => {
  if (autoClosed) {
    return '312 Activity in line with expected activity';
  }
  
  if (derivedDisposition === 'TRMS Filed' || derivedDisposition === 'Client Closed') {
    return '312 Activity Escalated';
  }
  
  return '312 Activity in line with expected activity';
};

// Derived disposition logic
export const derivedDispositionRules = {
  'TRMS Filed': 'Case escalated with TRMS filing',
  'Client Closed': 'Case escalated due to client closure',
  'Escalated to Compliance': 'Case escalated to compliance team',
  'No Action Required': 'Activity in line with expected patterns',
  'Pending': 'Awaiting final disposition'
};

// Validation functions
export const canTransitionStatus = (
  currentStatus: CaseStatus,
  newStatus: CaseStatus,
  userRole: string
): { allowed: boolean; reason?: string } => {
  const transition = statusTransitions.find(
    t => t.from === currentStatus && t.to === newStatus
  );
  
  if (!transition) {
    return { 
      allowed: false, 
      reason: `Invalid status transition from ${currentStatus} to ${newStatus}` 
    };
  }
  
  if (!transition.allowedRoles.includes(userRole)) {
    return { 
      allowed: false, 
      reason: `Role ${userRole} is not authorized to perform this transition` 
    };
  }
  
  return { allowed: true };
};

export const validateCaseCompletion = (caseData: any): { valid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  // Auto-closed cases
  if (caseData.autoClosed) {
    if (!caseData.modelOutcome) {
      errors.push('Auto-closed cases must have a model outcome');
    }
    if (caseData.modelOutcome !== '312 Activity in line with expected activity') {
      errors.push('Auto-closed cases must have outcome: 312 Activity in line with expected activity');
    }
  }
  
  // Manual cases
  if (!caseData.autoClosed && caseData.status === 'Complete') {
    if (!caseData.derivedDisposition) {
      errors.push('Completed cases must have a derived disposition');
    }
    if (!caseData.modelOutcome) {
      errors.push('Completed cases must have a model outcome');
    }
    if (!caseData.completionDate) {
      errors.push('Completed cases must have a completion date');
    }
  }
  
  // Defect remediation cases
  if (caseData.defectRemediationFlag) {
    if (!caseData.originalCompletionDate) {
      errors.push('Remediation cases must preserve original completion date');
    }
  }
  
  // Sales review cases
  if (caseData.status === 'Sales Review Complete') {
    if (!caseData.salesReviewComments) {
      errors.push('Sales review must include comments');
    }
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
};

// Get available actions for a case based on status and user role
export const getAvailableActions = (
  status: CaseStatus,
  userRole: string
): string[] => {
  const rule = caseFlowRules[status];
  if (!rule) return [];
  
  // Filter actions based on role
  if (!rule.actorRoles.includes(userRole)) {
    // View Only can only view
    if (userRole === 'View Only') {
      return ['View'];
    }
    return [];
  }
  
  return rule.allowedActions;
};

// Get next possible statuses
export const getNextStatuses = (currentStatus: CaseStatus, userRole: string): CaseStatus[] => {
  const validTransitions = statusTransitions.filter(
    t => t.from === currentStatus && t.allowedRoles.includes(userRole)
  );
  
  return validTransitions.map(t => t.to);
};

// Case assignment validation
export const canAssignCase = (
  userRole: string,
  targetRole: string
): { allowed: boolean; reason?: string } => {
  // Only managers can assign cases to analysts
  if (userRole === 'Central Team Manager') {
    if (targetRole === 'Central Team Analyst' || targetRole === 'Central Team Manager') {
      return { allowed: true };
    }
  }
  
  // Analysts can self-select from workbasket
  if (userRole === 'Central Team Analyst') {
    return { allowed: true };
  }
  
  return { 
    allowed: false, 
    reason: 'Only Central Team Managers can assign cases to others' 
  };
};

// M&I Entitlement validation for defect remediation
export const hasM_I_Entitlement = (user: any): boolean => {
  return user.hasM_I_Entitlement === true;
};

// Enhanced status transition validation with M&I check
export const canTransitionStatusWithEntitlement = (
  currentStatus: CaseStatus,
  newStatus: CaseStatus,
  user: any
): { allowed: boolean; reason?: string } => {
  // Check basic role-based transition
  const basicCheck = canTransitionStatus(currentStatus, newStatus, user.role);
  
  if (!basicCheck.allowed) {
    return basicCheck;
  }
  
  // Additional check for defect remediation transitions
  if (
    (currentStatus === 'Complete' && newStatus === 'Defect Remediation') ||
    (currentStatus === 'Defect Remediation' && newStatus === 'Complete')
  ) {
    if (!hasM_I_Entitlement(user)) {
      return {
        allowed: false,
        reason: 'M&I entitlement required for defect remediation actions'
      };
    }
  }
  
  return { allowed: true };
};
