/**
 * Data Validation Test Suite
 * 
 * Demonstrates usage of all validation queries and functions
 */

import {
  validateCase,
  validateClientData,
  validateMonitoringData,
  validate312CaseData,
  validateCAMCaseData,
  validateUser,
  validateSystemIntegration,
  queryCasesMissingCriticalData,
  queryCasesWithIntegrityIssues,
  queryPastDueCases,
  queryHighRiskCases,
  queryCasesWithStaleMonitoring,
  queryCasesWith312ModelFlag,
  queryClientsWithoutMPID,
  queryEmployeeAccounts,
  queryOverdue312Cases,
  query312CasesMissingActivityData,
  queryOverdueCAMCases,
  queryUsersWithMIEntitlement,
  queryUsersByRole,
  queryIntegrationsWithErrors,
  queryIntegrationsNeedingSync,
  generateDataQualityReport,
  logDataQualityReport,
  logValidationResults
} from '../dataValidation';

import { Case, User, SystemIntegration, ClientData, MonitoringData } from '@/app/components/types';

// ============================================================================
// TEST DATA
// ============================================================================

const validCase: Case = {
  id: 'TEST-001',
  clientId: 'GCI-TEST-001',
  gci: 'GCI-TEST-001',
  mpId: 'MP-12345',
  partyId: 'PTY-001',
  clientName: 'Test Client Corp',
  caseType: '312 Review',
  status: 'In Progress',
  riskLevel: 'Medium',
  priority: 'Medium',
  assignedTo: 'Test Analyst',
  createdDate: '2025-01-01',
  dueDate: '2025-01-15',
  lastActivity: '2025-01-10',
  alertCount: 5,
  transactionCount: 100,
  totalAmount: 1000000,
  description: 'Test case for validation',
  is312Case: true,
  lineOfBusiness: 'GB/GM',
  clientData: {
    clientId: 'GCI-TEST-001',
    gciNumber: 'GCI-TEST-001',
    legalName: 'Test Client Corporation',
    salesOwner: 'Test Sales Owner',
    lineOfBusiness: 'GB/GM',
    accountOpenDate: '2020-01-01',
    clientType: 'Corporation',
    jurisdiction: 'United States',
    dataSource: 'GWIM Hub',
    lastUpdated: '2025-01-20',
    isEmployee: false,
    mpId: 'MP-12345'
  },
  monitoringData: {
    dynamicRiskRating: 6.5,
    riskRatingDate: '2025-01-15',
    model312Score: 7.0,
    model312Flag: true,
    lastMonitoringDate: '2025-01-20'
  },
  case312Data: {
    dueDate: '2025-01-15',
    aging: 5,
    status: 'Under Review',
    modelResult: 'Medium Risk',
    modelResultDescription: 'Standard periodic review',
    expectedActivityVolume: {
      'Wire Transfers': 50,
      'ACH Transactions': 100
    },
    expectedActivityValue: {
      'Wire Transfers': 500000,
      'ACH Transactions': 200000
    }
  }
};

const invalidCase: Case = {
  id: '', // Invalid: empty
  clientId: '', // Invalid: empty
  gci: '', // Invalid: empty
  clientName: 'Invalid Case',
  caseType: '312 Review',
  status: 'In Progress',
  riskLevel: 'Medium',
  priority: 'Medium',
  assignedTo: '',
  createdDate: '2025-12-31', // Invalid: future date before due date logic issue
  dueDate: '2025-01-01', // Invalid: before created date
  lastActivity: '2025-01-10',
  alertCount: -5, // Invalid: negative
  transactionCount: -10, // Invalid: negative
  totalAmount: -1000, // Invalid: negative
  description: 'Invalid test case',
  is312Case: true,
  lineOfBusiness: 'GB/GM'
  // Missing clientData and monitoringData
};

const pastDueCase: Case = {
  ...validCase,
  id: 'PAST-DUE-001',
  dueDate: '2024-12-01',
  status: 'In Progress'
};

const highRiskCase: Case = {
  ...validCase,
  id: 'HIGH-RISK-001',
  riskLevel: 'Critical',
  monitoringData: {
    ...validCase.monitoringData!,
    dynamicRiskRating: 9.5
  }
};

const employeeCase: Case = {
  ...validCase,
  id: 'EMPLOYEE-001',
  isBACEmployee: true,
  clientData: {
    ...validCase.clientData!,
    isEmployee: true
  }
};

const gwimWithoutMPID: Case = {
  ...validCase,
  id: 'NO-MPID-001',
  mpId: undefined,
  clientData: {
    ...validCase.clientData!,
    dataSource: 'GWIM Hub',
    mpId: undefined
  }
};

const staleMonitoringCase: Case = {
  ...validCase,
  id: 'STALE-001',
  monitoringData: {
    ...validCase.monitoringData!,
    riskRatingDate: '2024-01-01' // Over 90 days old
  }
};

const validUser: User = {
  id: 'U001',
  name: 'Test User',
  email: 'test@ml.com',
  role: 'Analyst',
  hasM_I_Entitlement: true
};

const invalidUser: User = {
  id: '',
  name: '',
  email: 'invalid-email',
  role: 'Analyst'
};

const validIntegration: SystemIntegration = {
  id: 'INT-001',
  name: 'GWIM Hub',
  type: 'Client Data',
  description: 'Client data source',
  status: 'Connected',
  lastSync: '2025-01-22T10:00:00Z',
  recordCount: 1000,
  errorCount: 0,
  dataAttributes: ['MP ID', 'GCI', 'Client Name']
};

const errorIntegration: SystemIntegration = {
  id: 'INT-002',
  name: 'Failing System',
  type: 'Client Data',
  description: 'System with errors',
  status: 'Error',
  lastSync: '2025-01-20T10:00:00Z',
  recordCount: 500,
  errorCount: 25,
  dataAttributes: []
};

// ============================================================================
// VALIDATION TESTS
// ============================================================================

describe('Case Validation', () => {
  test('validateCase - valid case should pass', () => {
    const result = validateCase(validCase);
    
    console.log('✅ Valid Case Test:');
    console.log(`  Valid: ${result.isValid}`);
    console.log(`  Errors: ${result.errors.length}`);
    console.log(`  Warnings: ${result.warnings.length}`);
    
    expect(result.isValid).toBe(true);
    expect(result.errors.length).toBe(0);
  });

  test('validateCase - invalid case should fail', () => {
    const result = validateCase(invalidCase);
    
    console.log('\n❌ Invalid Case Test:');
    console.log(`  Valid: ${result.isValid}`);
    console.log(`  Errors: ${result.errors.length}`);
    result.errors.forEach(error => console.log(`    - ${error}`));
    
    expect(result.isValid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
  });

  test('validateCase - complete case without completion date should warn', () => {
    const completeCase: Case = {
      ...validCase,
      status: 'Complete',
      completionDate: undefined
    };
    
    const result = validateCase(completeCase);
    
    console.log('\n⚠️  Complete Case Warning Test:');
    console.log(`  Warnings: ${result.warnings.length}`);
    result.warnings.forEach(warning => console.log(`    - ${warning}`));
    
    expect(result.warnings.length).toBeGreaterThan(0);
  });
});

describe('Client Data Validation', () => {
  test('validateClientData - valid client data should pass', () => {
    const result = validateClientData(validCase.clientData!, validCase.id);
    
    console.log('\n✅ Valid Client Data Test:');
    console.log(`  Valid: ${result.isValid}`);
    console.log(`  Errors: ${result.errors.length}`);
    
    expect(result.isValid).toBe(true);
  });

  test('validateClientData - GWIM Hub without MP ID should warn', () => {
    const clientData: ClientData = {
      ...validCase.clientData!,
      dataSource: 'GWIM Hub',
      mpId: undefined
    };
    
    const result = validateClientData(clientData);
    
    console.log('\n⚠️  GWIM Hub MP ID Warning Test:');
    console.log(`  Warnings: ${result.warnings.length}`);
    result.warnings.forEach(warning => console.log(`    - ${warning}`));
    
    expect(result.warnings.some(w => w.includes('MP ID'))).toBe(true);
  });
});

describe('Monitoring Data Validation', () => {
  test('validateMonitoringData - valid monitoring data should pass', () => {
    const result = validateMonitoringData(validCase.monitoringData!, validCase.id);
    
    console.log('\n✅ Valid Monitoring Data Test:');
    console.log(`  Valid: ${result.isValid}`);
    
    expect(result.isValid).toBe(true);
  });

  test('validateMonitoringData - stale data should warn', () => {
    const staleData: MonitoringData = {
      ...validCase.monitoringData!,
      riskRatingDate: '2024-01-01'
    };
    
    const result = validateMonitoringData(staleData);
    
    console.log('\n⚠️  Stale Monitoring Data Warning Test:');
    console.log(`  Warnings: ${result.warnings.length}`);
    result.warnings.forEach(warning => console.log(`    - ${warning}`));
    
    expect(result.warnings.some(w => w.includes('days old'))).toBe(true);
  });
});

// ============================================================================
// QUERY TESTS
// ============================================================================

describe('Case Query Functions', () => {
  const testCases = [
    validCase,
    invalidCase,
    pastDueCase,
    highRiskCase,
    employeeCase,
    gwimWithoutMPID,
    staleMonitoringCase
  ];

  test('queryCasesMissingCriticalData', () => {
    const results = queryCasesMissingCriticalData(testCases);
    
    console.log('\n🔍 Cases Missing Critical Data:');
    console.log(`  Found: ${results.length} cases`);
    results.forEach(c => console.log(`    - ${c.id}`));
    
    expect(results.length).toBeGreaterThan(0);
    expect(results.some(c => c.id === 'TEST-INVALID')).toBe(false);
  });

  test('queryCasesWithIntegrityIssues', () => {
    const results = queryCasesWithIntegrityIssues(testCases);
    
    console.log('\n🔍 Cases with Integrity Issues:');
    console.log(`  Found: ${results.length} validation results`);
    results.forEach(r => {
      console.log(`    - ${r.recordId}: ${r.errors.length} errors`);
    });
    
    expect(results.length).toBeGreaterThan(0);
  });

  test('queryPastDueCases', () => {
    const results = queryPastDueCases(testCases);
    
    console.log('\n🔍 Past Due Cases:');
    console.log(`  Found: ${results.length} cases`);
    results.forEach(c => console.log(`    - ${c.id} (Due: ${c.dueDate})`));
    
    expect(results.some(c => c.id === 'PAST-DUE-001')).toBe(true);
  });

  test('queryHighRiskCases', () => {
    const results = queryHighRiskCases(testCases);
    
    console.log('\n🔍 High Risk Cases:');
    console.log(`  Found: ${results.length} cases`);
    results.forEach(c => {
      const rating = c.monitoringData?.dynamicRiskRating || 0;
      console.log(`    - ${c.id} (Risk: ${c.riskLevel}, Rating: ${rating})`);
    });
    
    expect(results.some(c => c.id === 'HIGH-RISK-001')).toBe(true);
  });

  test('queryCasesWithStaleMonitoring', () => {
    const results = queryCasesWithStaleMonitoring(testCases, 90);
    
    console.log('\n🔍 Cases with Stale Monitoring (>90 days):');
    console.log(`  Found: ${results.length} cases`);
    results.forEach(c => {
      console.log(`    - ${c.id} (Rating Date: ${c.monitoringData?.riskRatingDate})`);
    });
    
    expect(results.some(c => c.id === 'STALE-001')).toBe(true);
  });

  test('queryCasesWith312ModelFlag', () => {
    const results = queryCasesWith312ModelFlag(testCases);
    
    console.log('\n🔍 Cases with 312 Model Flag:');
    console.log(`  Found: ${results.length} cases`);
    results.forEach(c => console.log(`    - ${c.id}`));
    
    expect(results.length).toBeGreaterThan(0);
  });

  test('queryClientsWithoutMPID', () => {
    const results = queryClientsWithoutMPID(testCases);
    
    console.log('\n🔍 Clients Missing MP ID (GWIM Hub):');
    console.log(`  Found: ${results.length} cases`);
    results.forEach(c => {
      console.log(`    - ${c.id} (Source: ${c.clientData?.dataSource})`);
    });
    
    expect(results.some(c => c.id === 'NO-MPID-001')).toBe(true);
  });

  test('queryEmployeeAccounts', () => {
    const results = queryEmployeeAccounts(testCases);
    
    console.log('\n🔍 Employee Accounts:');
    console.log(`  Found: ${results.length} cases`);
    results.forEach(c => {
      console.log(`    - ${c.id} (Employee: ${c.isBACEmployee})`);
    });
    
    expect(results.some(c => c.id === 'EMPLOYEE-001')).toBe(true);
  });
});

describe('User Query Functions', () => {
  const testUsers = [
    validUser,
    { ...validUser, id: 'U002', hasM_I_Entitlement: false },
    { ...validUser, id: 'U003', role: 'Manager' as const },
    invalidUser
  ];

  test('queryUsersWithMIEntitlement', () => {
    const results = queryUsersWithMIEntitlement(testUsers);
    
    console.log('\n🔍 Users with M&I Entitlement:');
    console.log(`  Found: ${results.length} users`);
    results.forEach(u => console.log(`    - ${u.name} (${u.email})`));
    
    expect(results.some(u => u.id === 'U001')).toBe(true);
  });

  test('queryUsersByRole', () => {
    const results = queryUsersByRole(testUsers, 'Manager');
    
    console.log('\n🔍 Users by Role (Manager):');
    console.log(`  Found: ${results.length} users`);
    results.forEach(u => console.log(`    - ${u.name} (${u.role})`));
    
    expect(results.some(u => u.id === 'U003')).toBe(true);
  });
});

describe('Integration Query Functions', () => {
  const testIntegrations = [
    validIntegration,
    errorIntegration,
    {
      ...validIntegration,
      id: 'INT-003',
      name: 'Stale System',
      lastSync: '2025-01-20T10:00:00Z' // Over 24 hours ago
    }
  ];

  test('queryIntegrationsWithErrors', () => {
    const results = queryIntegrationsWithErrors(testIntegrations);
    
    console.log('\n🔍 Integrations with Errors:');
    console.log(`  Found: ${results.length} integrations`);
    results.forEach(i => {
      console.log(`    - ${i.name} (Status: ${i.status}, Errors: ${i.errorCount})`);
    });
    
    expect(results.some(i => i.id === 'INT-002')).toBe(true);
  });

  test('queryIntegrationsNeedingSync', () => {
    const results = queryIntegrationsNeedingSync(testIntegrations, 24);
    
    console.log('\n🔍 Integrations Needing Sync (>24 hours):');
    console.log(`  Found: ${results.length} integrations`);
    results.forEach(i => {
      console.log(`    - ${i.name} (Last Sync: ${i.lastSync})`);
    });
    
    // Results may vary based on current time
    expect(Array.isArray(results)).toBe(true);
  });
});

// ============================================================================
// DATA QUALITY REPORT TESTS
// ============================================================================

describe('Data Quality Report', () => {
  const testCases = [
    validCase,
    invalidCase,
    pastDueCase,
    highRiskCase,
    employeeCase
  ];

  test('generateDataQualityReport', () => {
    const report = generateDataQualityReport(testCases);
    
    console.log('\n📊 Data Quality Report:');
    console.log(`  Total Records: ${report.totalRecords}`);
    console.log(`  Valid Records: ${report.validRecords}`);
    console.log(`  Invalid Records: ${report.invalidRecords}`);
    console.log(`  Critical Errors: ${report.summary.criticalErrors}`);
    console.log(`  Warnings: ${report.summary.warnings}`);
    console.log(`  Data Quality Score: ${report.summary.dataQualityScore}/100`);
    
    if (report.summary.missingFields.length > 0) {
      console.log('\n  Top Missing Fields:');
      report.summary.missingFields.slice(0, 5).forEach((field, i) => {
        console.log(`    ${i + 1}. ${field}`);
      });
    }
    
    expect(report.totalRecords).toBe(testCases.length);
    expect(report.summary.dataQualityScore).toBeGreaterThanOrEqual(0);
    expect(report.summary.dataQualityScore).toBeLessThanOrEqual(100);
    
    // Log full report
    logDataQualityReport(report);
  });
});

// ============================================================================
// CONSOLE LOGGING TESTS
// ============================================================================

describe('Console Logging Functions', () => {
  test('logValidationResults', () => {
    const testCases = [validCase, invalidCase];
    const results = testCases.map(c => validateCase(c));
    
    console.log('\n📋 Logging Validation Results:');
    logValidationResults(results);
    
    expect(results.length).toBe(2);
  });

  test('logDataQualityReport', () => {
    const testCases = [validCase, invalidCase, pastDueCase];
    const report = generateDataQualityReport(testCases);
    
    console.log('\n📈 Logging Data Quality Report:');
    logDataQualityReport(report);
    
    expect(report).toBeDefined();
  });
});

// ============================================================================
// RUN ALL TESTS
// ============================================================================

console.log('\n' + '='.repeat(80));
console.log('🧪 DATA VALIDATION TEST SUITE');
console.log('='.repeat(80));

// Note: In a real test environment, these would be run by Jest or similar
// For demonstration, you can manually run: npm test dataValidation.test.ts
