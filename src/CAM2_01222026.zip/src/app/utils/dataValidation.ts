/**
 * Data Validation Queries and Utilities
 * 
 * This module provides validation queries for each component and data model
 * to ensure data integrity and completeness across the application.
 */

import { 
  Case, 
  ClientData, 
  MonitoringData, 
  User, 
  Case312Data,
  CAMCaseData,
  Activity,
  Alert,
  Population,
  SystemIntegration
} from '../components/types';

// ============================================================================
// VALIDATION RESULT TYPES
// ============================================================================

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  componentName: string;
  recordId?: string;
}

export interface DataQualityReport {
  totalRecords: number;
  validRecords: number;
  invalidRecords: number;
  validationResults: ValidationResult[];
  summary: {
    criticalErrors: number;
    warnings: number;
    missingFields: string[];
    dataQualityScore: number; // 0-100
  };
}

// ============================================================================
// CASE DATA VALIDATION QUERIES
// ============================================================================

/**
 * Validates Case data structure and required fields
 */
export function validateCase(caseData: Case): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required field validations
  if (!caseData.id || caseData.id.trim() === '') {
    errors.push('Case ID is required');
  }

  if (!caseData.clientId || caseData.clientId.trim() === '') {
    errors.push('Client ID is required');
  }

  if (!caseData.clientName || caseData.clientName.trim() === '') {
    errors.push('Client Name is required');
  }

  if (!caseData.gci || caseData.gci.trim() === '') {
    errors.push('GCI Number is required');
  }

  if (!caseData.caseType) {
    errors.push('Case Type is required');
  }

  if (!caseData.status) {
    errors.push('Case Status is required');
  }

  if (!caseData.riskLevel) {
    errors.push('Risk Level is required');
  }

  if (!caseData.priority) {
    errors.push('Priority is required');
  }

  if (!caseData.assignedTo || caseData.assignedTo.trim() === '') {
    errors.push('Assignee is required');
  }

  // Date validations
  if (!caseData.createdDate) {
    errors.push('Created Date is required');
  } else if (!isValidDate(caseData.createdDate)) {
    errors.push('Created Date has invalid format');
  }

  if (!caseData.dueDate) {
    errors.push('Due Date is required');
  } else if (!isValidDate(caseData.dueDate)) {
    errors.push('Due Date has invalid format');
  }

  // Business rule validations
  if (caseData.createdDate && caseData.dueDate) {
    if (new Date(caseData.createdDate) > new Date(caseData.dueDate)) {
      errors.push('Due Date cannot be before Created Date');
    }
  }

  // Numeric field validations
  if (caseData.alertCount < 0) {
    errors.push('Alert Count cannot be negative');
  }

  if (caseData.transactionCount < 0) {
    errors.push('Transaction Count cannot be negative');
  }

  if (caseData.totalAmount < 0) {
    errors.push('Total Amount cannot be negative');
  }

  // Conditional validations
  if (caseData.status === 'Complete' && !caseData.completionDate) {
    warnings.push('Complete cases should have a completion date');
  }

  if (caseData.status === 'Pending Sales Review' && !caseData.lineOfBusiness) {
    warnings.push('Sales review cases should have Line of Business specified');
  }

  if (caseData.is312Case && !caseData.case312Data) {
    warnings.push('312 cases should have case312Data populated');
  }

  if (!caseData.is312Case && caseData.camRequired && !caseData.camCaseData) {
    warnings.push('CAM cases should have camCaseData populated');
  }

  // Integration data warnings
  if (!caseData.clientData) {
    warnings.push('Client Data integration missing');
  }

  if (!caseData.monitoringData) {
    warnings.push('Monitoring Data integration missing');
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: 'Case',
    recordId: caseData.id
  };
}

/**
 * Query to find cases missing critical data
 */
export function queryCasesMissingCriticalData(cases: Case[]): Case[] {
  return cases.filter(c => {
    return !c.clientData || 
           !c.monitoringData || 
           !c.gci || 
           !c.clientId ||
           (c.is312Case && !c.case312Data) ||
           (!c.is312Case && !c.camCaseData);
  });
}

/**
 * Query to find cases with data integrity issues
 */
export function queryCasesWithIntegrityIssues(cases: Case[]): ValidationResult[] {
  return cases
    .map(c => validateCase(c))
    .filter(result => !result.isValid);
}

/**
 * Query to find past due cases
 */
export function queryPastDueCases(cases: Case[]): Case[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  return cases.filter(c => {
    const dueDate = new Date(c.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    return dueDate < today && c.status !== 'Complete' && c.status !== 'Closed';
  });
}

/**
 * Query to find cases by status
 */
export function queryCasesByStatus(cases: Case[], status: string): Case[] {
  return cases.filter(c => c.status === status);
}

/**
 * Query to find high-risk cases
 */
export function queryHighRiskCases(cases: Case[]): Case[] {
  return cases.filter(c => 
    c.riskLevel === 'High' || 
    c.riskLevel === 'Critical' ||
    (c.monitoringData && c.monitoringData.dynamicRiskRating >= 8.0)
  );
}

// ============================================================================
// CLIENT DATA VALIDATION QUERIES
// ============================================================================

/**
 * Validates Client Data structure
 */
export function validateClientData(clientData: ClientData, parentCaseId?: string): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required field validations
  if (!clientData.clientId || clientData.clientId.trim() === '') {
    errors.push('Client ID is required');
  }

  if (!clientData.gciNumber || clientData.gciNumber.trim() === '') {
    errors.push('GCI Number is required');
  }

  if (!clientData.legalName || clientData.legalName.trim() === '') {
    errors.push('Legal Name is required');
  }

  if (!clientData.salesOwner || clientData.salesOwner.trim() === '') {
    errors.push('Sales Owner is required');
  }

  if (!clientData.lineOfBusiness) {
    errors.push('Line of Business is required');
  }

  if (!clientData.accountOpenDate) {
    errors.push('Account Open Date is required');
  } else if (!isValidDate(clientData.accountOpenDate)) {
    errors.push('Account Open Date has invalid format');
  }

  if (!clientData.clientType || clientData.clientType.trim() === '') {
    errors.push('Client Type is required');
  }

  if (!clientData.jurisdiction || clientData.jurisdiction.trim() === '') {
    errors.push('Jurisdiction is required');
  }

  if (!clientData.dataSource) {
    errors.push('Data Source is required');
  }

  if (!clientData.lastUpdated) {
    errors.push('Last Updated timestamp is required');
  }

  // GWIM Hub specific validations
  if (clientData.dataSource === 'GWIM Hub' && !clientData.mpId) {
    warnings.push('GWIM Hub records should include MP ID');
  }

  // Business rule validations
  if (clientData.accountOpenDate) {
    const openDate = new Date(clientData.accountOpenDate);
    const today = new Date();
    if (openDate > today) {
      errors.push('Account Open Date cannot be in the future');
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: 'ClientData',
    recordId: parentCaseId || clientData.clientId
  };
}

/**
 * Query to find client records missing MP ID from GWIM Hub
 */
export function queryClientsWithoutMPID(cases: Case[]): Case[] {
  return cases.filter(c => 
    c.clientData && 
    c.clientData.dataSource === 'GWIM Hub' && 
    !c.clientData.mpId
  );
}

/**
 * Query to find client records by data source
 */
export function queryClientsByDataSource(
  cases: Case[], 
  dataSource: 'Cesium' | 'WCC' | 'CMT' | 'GWIM Hub' | 'PRDS' | 'CP'
): Case[] {
  return cases.filter(c => c.clientData?.dataSource === dataSource);
}

/**
 * Query to find employee accounts
 */
export function queryEmployeeAccounts(cases: Case[]): Case[] {
  return cases.filter(c => 
    c.isBACEmployee === true || 
    c.clientData?.isEmployee === true
  );
}

// ============================================================================
// MONITORING DATA VALIDATION QUERIES
// ============================================================================

/**
 * Validates Monitoring Data structure
 */
export function validateMonitoringData(monitoringData: MonitoringData, parentCaseId?: string): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required field validations
  if (monitoringData.dynamicRiskRating === undefined || monitoringData.dynamicRiskRating === null) {
    errors.push('Dynamic Risk Rating is required');
  } else if (monitoringData.dynamicRiskRating < 0 || monitoringData.dynamicRiskRating > 10) {
    errors.push('Dynamic Risk Rating must be between 0 and 10');
  }

  if (!monitoringData.riskRatingDate) {
    errors.push('Risk Rating Date is required');
  } else if (!isValidDate(monitoringData.riskRatingDate)) {
    errors.push('Risk Rating Date has invalid format');
  }

  if (!monitoringData.lastMonitoringDate) {
    errors.push('Last Monitoring Date is required');
  }

  // 312 Model validations
  if (monitoringData.model312Flag) {
    if (monitoringData.model312Score === undefined || monitoringData.model312Score === null) {
      warnings.push('312 Model Flag is true but model312Score is missing');
    } else if (monitoringData.model312Score < 0 || monitoringData.model312Score > 10) {
      errors.push('312 Model Score must be between 0 and 10');
    }
  }

  // Date freshness validation
  if (monitoringData.riskRatingDate) {
    const ratingDate = new Date(monitoringData.riskRatingDate);
    const today = new Date();
    const daysDiff = Math.floor((today.getTime() - ratingDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysDiff > 90) {
      warnings.push(`Risk Rating is ${daysDiff} days old - may need refresh`);
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: 'MonitoringData',
    recordId: parentCaseId
  };
}

/**
 * Query to find cases with stale monitoring data
 */
export function queryCasesWithStaleMonitoring(cases: Case[], daysThreshold: number = 90): Case[] {
  const today = new Date();
  
  return cases.filter(c => {
    if (!c.monitoringData?.riskRatingDate) return true;
    
    const ratingDate = new Date(c.monitoringData.riskRatingDate);
    const daysDiff = Math.floor((today.getTime() - ratingDate.getTime()) / (1000 * 60 * 60 * 24));
    
    return daysDiff > daysThreshold;
  });
}

/**
 * Query to find cases with 312 model flags
 */
export function queryCasesWith312ModelFlag(cases: Case[]): Case[] {
  return cases.filter(c => c.monitoringData?.model312Flag === true);
}

/**
 * Query to find cases by risk rating threshold
 */
export function queryCasesByRiskRating(cases: Case[], minRating: number, maxRating: number = 10): Case[] {
  return cases.filter(c => {
    const rating = c.monitoringData?.dynamicRiskRating;
    return rating !== undefined && rating >= minRating && rating <= maxRating;
  });
}

// ============================================================================
// 312 CASE DATA VALIDATION QUERIES
// ============================================================================

/**
 * Validates 312 Case Data
 */
export function validate312CaseData(case312Data: Case312Data, parentCaseId?: string): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required field validations
  if (!case312Data.dueDate) {
    errors.push('312 Due Date is required');
  }

  if (case312Data.aging === undefined || case312Data.aging === null) {
    errors.push('312 Aging is required');
  } else if (case312Data.aging < 0) {
    errors.push('312 Aging cannot be negative');
  }

  if (!case312Data.status) {
    errors.push('312 Status is required');
  }

  if (!case312Data.modelResult) {
    errors.push('312 Model Result is required');
  }

  if (!case312Data.modelResultDescription) {
    warnings.push('312 Model Result Description is missing');
  }

  // Expected activity validations
  if (!case312Data.expectedActivityVolume || Object.keys(case312Data.expectedActivityVolume).length === 0) {
    warnings.push('Expected Activity Volume is empty');
  }

  if (!case312Data.expectedActivityValue || Object.keys(case312Data.expectedActivityValue).length === 0) {
    warnings.push('Expected Activity Value is empty');
  }

  // Aging threshold warnings
  if (case312Data.aging > 30) {
    warnings.push(`312 case is significantly overdue (${case312Data.aging} days)`);
  } else if (case312Data.aging > 14) {
    warnings.push(`312 case is overdue (${case312Data.aging} days)`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: '312CaseData',
    recordId: parentCaseId
  };
}

/**
 * Query to find overdue 312 cases
 */
export function queryOverdue312Cases(cases: Case[]): Case[] {
  return cases.filter(c => 
    c.is312Case && 
    c.case312Data && 
    c.case312Data.aging > 0
  );
}

/**
 * Query to find 312 cases missing expected activity data
 */
export function query312CasesMissingActivityData(cases: Case[]): Case[] {
  return cases.filter(c => 
    c.is312Case && 
    c.case312Data &&
    (!c.case312Data.expectedActivityVolume || 
     Object.keys(c.case312Data.expectedActivityVolume).length === 0 ||
     !c.case312Data.expectedActivityValue ||
     Object.keys(c.case312Data.expectedActivityValue).length === 0)
  );
}

// ============================================================================
// CAM CASE DATA VALIDATION QUERIES
// ============================================================================

/**
 * Validates CAM Case Data
 */
export function validateCAMCaseData(camCaseData: CAMCaseData, parentCaseId?: string): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required field validations
  if (!camCaseData.dueDate) {
    errors.push('CAM Due Date is required');
  }

  if (camCaseData.aging === undefined || camCaseData.aging === null) {
    errors.push('CAM Aging is required');
  } else if (camCaseData.aging < 0) {
    errors.push('CAM Aging cannot be negative');
  }

  if (!camCaseData.status) {
    errors.push('CAM Status is required');
  }

  if (!camCaseData.triggers || camCaseData.triggers.length === 0) {
    warnings.push('CAM Triggers are empty');
  }

  // Aging threshold warnings
  if (camCaseData.aging > 30) {
    warnings.push(`CAM case is significantly overdue (${camCaseData.aging} days)`);
  } else if (camCaseData.aging > 14) {
    warnings.push(`CAM case is overdue (${camCaseData.aging} days)`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: 'CAMCaseData',
    recordId: parentCaseId
  };
}

/**
 * Query to find overdue CAM cases
 */
export function queryOverdueCAMCases(cases: Case[]): Case[] {
  return cases.filter(c => 
    !c.is312Case && 
    c.camCaseData && 
    c.camCaseData.aging > 0
  );
}

// ============================================================================
// USER DATA VALIDATION QUERIES
// ============================================================================

/**
 * Validates User data
 */
export function validateUser(user: User): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!user.id || user.id.trim() === '') {
    errors.push('User ID is required');
  }

  if (!user.name || user.name.trim() === '') {
    errors.push('User Name is required');
  }

  if (!user.email || user.email.trim() === '') {
    errors.push('User Email is required');
  } else if (!isValidEmail(user.email)) {
    errors.push('User Email format is invalid');
  }

  if (!user.role) {
    errors.push('User Role is required');
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: 'User',
    recordId: user.id
  };
}

/**
 * Query to find users with M&I entitlement
 */
export function queryUsersWithMIEntitlement(users: User[]): User[] {
  return users.filter(u => u.hasM_I_Entitlement === true);
}

/**
 * Query to find users by role
 */
export function queryUsersByRole(users: User[], role: string): User[] {
  return users.filter(u => u.role === role);
}

// ============================================================================
// SYSTEM INTEGRATION VALIDATION QUERIES
// ============================================================================

/**
 * Validates System Integration data
 */
export function validateSystemIntegration(integration: SystemIntegration): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!integration.id || integration.id.trim() === '') {
    errors.push('Integration ID is required');
  }

  if (!integration.name || integration.name.trim() === '') {
    errors.push('Integration Name is required');
  }

  if (!integration.type) {
    errors.push('Integration Type is required');
  }

  if (!integration.status) {
    errors.push('Integration Status is required');
  }

  if (integration.status === 'Error') {
    warnings.push(`Integration ${integration.name} has error status`);
  }

  if (integration.errorCount > 0) {
    warnings.push(`Integration ${integration.name} has ${integration.errorCount} errors`);
  }

  if (!integration.lastSync) {
    warnings.push('Last Sync date is missing');
  } else {
    const lastSync = new Date(integration.lastSync);
    const today = new Date();
    const hoursDiff = Math.floor((today.getTime() - lastSync.getTime()) / (1000 * 60 * 60));
    
    if (hoursDiff > 24) {
      warnings.push(`Integration ${integration.name} hasn't synced in ${hoursDiff} hours`);
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    componentName: 'SystemIntegration',
    recordId: integration.id
  };
}

/**
 * Query to find integrations with errors
 */
export function queryIntegrationsWithErrors(integrations: SystemIntegration[]): SystemIntegration[] {
  return integrations.filter(i => 
    i.status === 'Error' || 
    i.errorCount > 0
  );
}

/**
 * Query to find integrations needing sync
 */
export function queryIntegrationsNeedingSync(integrations: SystemIntegration[], hoursThreshold: number = 24): SystemIntegration[] {
  const now = new Date();
  
  return integrations.filter(i => {
    if (!i.lastSync) return true;
    
    const lastSync = new Date(i.lastSync);
    const hoursDiff = Math.floor((now.getTime() - lastSync.getTime()) / (1000 * 60 * 60));
    
    return hoursDiff > hoursThreshold;
  });
}

// ============================================================================
// COMPREHENSIVE DATA QUALITY REPORT
// ============================================================================

/**
 * Generates comprehensive data quality report for all cases
 */
export function generateDataQualityReport(cases: Case[]): DataQualityReport {
  const validationResults: ValidationResult[] = [];
  let validCount = 0;
  let criticalErrors = 0;
  let totalWarnings = 0;
  const missingFieldsMap = new Map<string, number>();

  // Validate each case and its nested data
  cases.forEach(caseData => {
    // Validate case
    const caseValidation = validateCase(caseData);
    validationResults.push(caseValidation);
    
    if (caseValidation.isValid) {
      validCount++;
    } else {
      criticalErrors += caseValidation.errors.length;
    }
    totalWarnings += caseValidation.warnings.length;

    // Track missing fields
    caseValidation.errors.forEach(error => {
      const count = missingFieldsMap.get(error) || 0;
      missingFieldsMap.set(error, count + 1);
    });

    // Validate client data if present
    if (caseData.clientData) {
      const clientValidation = validateClientData(caseData.clientData, caseData.id);
      validationResults.push(clientValidation);
      
      if (!clientValidation.isValid) {
        criticalErrors += clientValidation.errors.length;
      }
      totalWarnings += clientValidation.warnings.length;
    }

    // Validate monitoring data if present
    if (caseData.monitoringData) {
      const monitoringValidation = validateMonitoringData(caseData.monitoringData, caseData.id);
      validationResults.push(monitoringValidation);
      
      if (!monitoringValidation.isValid) {
        criticalErrors += monitoringValidation.errors.length;
      }
      totalWarnings += monitoringValidation.warnings.length;
    }

    // Validate 312 data if present
    if (caseData.is312Case && caseData.case312Data) {
      const case312Validation = validate312CaseData(caseData.case312Data, caseData.id);
      validationResults.push(case312Validation);
      
      if (!case312Validation.isValid) {
        criticalErrors += case312Validation.errors.length;
      }
      totalWarnings += case312Validation.warnings.length;
    }

    // Validate CAM data if present
    if (!caseData.is312Case && caseData.camCaseData) {
      const camValidation = validateCAMCaseData(caseData.camCaseData, caseData.id);
      validationResults.push(camValidation);
      
      if (!camValidation.isValid) {
        criticalErrors += camValidation.errors.length;
      }
      totalWarnings += camValidation.warnings.length;
    }
  });

  // Calculate data quality score (0-100)
  const totalRecords = cases.length;
  const invalidRecords = totalRecords - validCount;
  const errorRate = invalidRecords / totalRecords;
  const warningRate = totalWarnings / (totalRecords * 10); // Normalized
  const dataQualityScore = Math.max(0, Math.round(100 - (errorRate * 70) - (warningRate * 30)));

  return {
    totalRecords,
    validRecords: validCount,
    invalidRecords,
    validationResults,
    summary: {
      criticalErrors,
      warnings: totalWarnings,
      missingFields: Array.from(missingFieldsMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([field]) => field),
      dataQualityScore
    }
  };
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Validates date string format (YYYY-MM-DD)
 */
function isValidDate(dateString: string): boolean {
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!regex.test(dateString)) return false;
  
  const date = new Date(dateString);
  return date instanceof Date && !isNaN(date.getTime());
}

/**
 * Validates email format
 */
function isValidEmail(email: string): boolean {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

/**
 * Exports validation results to console in formatted way
 */
export function logValidationResults(results: ValidationResult[]): void {
  console.group('📊 Data Validation Results');
  
  const errors = results.filter(r => !r.isValid);
  const warnings = results.filter(r => r.warnings.length > 0);
  
  console.log(`✅ Valid Records: ${results.length - errors.length}`);
  console.log(`❌ Invalid Records: ${errors.length}`);
  console.log(`⚠️  Records with Warnings: ${warnings.length}`);
  
  if (errors.length > 0) {
    console.group('❌ Validation Errors');
    errors.forEach(result => {
      console.group(`${result.componentName} - ${result.recordId || 'Unknown'}`);
      result.errors.forEach(error => console.error(`  • ${error}`));
      console.groupEnd();
    });
    console.groupEnd();
  }
  
  if (warnings.length > 0) {
    console.group('⚠️  Validation Warnings');
    warnings.forEach(result => {
      console.group(`${result.componentName} - ${result.recordId || 'Unknown'}`);
      result.warnings.forEach(warning => console.warn(`  • ${warning}`));
      console.groupEnd();
    });
    console.groupEnd();
  }
  
  console.groupEnd();
}

/**
 * Exports data quality report to console
 */
export function logDataQualityReport(report: DataQualityReport): void {
  console.group('📈 Data Quality Report');
  
  console.log(`Total Records: ${report.totalRecords}`);
  console.log(`Valid Records: ${report.validRecords} (${Math.round(report.validRecords / report.totalRecords * 100)}%)`);
  console.log(`Invalid Records: ${report.invalidRecords}`);
  console.log(`\n📊 Data Quality Score: ${report.summary.dataQualityScore}/100`);
  
  if (report.summary.criticalErrors > 0) {
    console.error(`\n❌ Critical Errors: ${report.summary.criticalErrors}`);
  }
  
  if (report.summary.warnings > 0) {
    console.warn(`⚠️  Warnings: ${report.summary.warnings}`);
  }
  
  if (report.summary.missingFields.length > 0) {
    console.group('\n🔍 Top Missing Fields');
    report.summary.missingFields.forEach((field, index) => {
      console.log(`${index + 1}. ${field}`);
    });
    console.groupEnd();
  }
  
  console.groupEnd();
}
