# 312 & CAM Data Attributes Summary

## Quick Reference Guide

This document provides a concise overview of all data attributes for Section 312 and CAM workflows.

---

## 📋 Section 312 Attributes

### Required Attributes (All LOBs)
| Attribute | Type | Description |
|-----------|------|-------------|
| `partyId` | string | **PRIMARY KEY** - Unique client identifier (MUST BE PROVIDED) |
| `legalName` | string | Client legal entity name |
| `employeeIndicator` | boolean | BAC employee flag |
| `affiliateIndicator` | boolean | BAC affiliate flag |
| `expectedActivityVolume` | object | Expected transaction volumes |
| `expectedActivityValue` | object | Expected transaction values |

### LOB-Specific Identifiers

| Attribute | LOBs | Description |
|-----------|------|-------------|
| `gciNumber` | PB, GB/GM | Global Client Identifier (pattern: `GCI[0-9]{8,12}`) |
| `mpId` | ML | Merrill Portfolio ID (pattern: `MP[0-9]{6,10}`) |
| `coperId` | GM | Corporate Relationship ID (pattern: `CP[0-9]{8,12}`) |

### Client Name Attributes

| Attribute | LOBs | Type | Description |
|-----------|------|------|-------------|
| `firstName` | PB, ML, Consumer | string | First name (individual clients) |
| `middleName` | PB, ML, Consumer | string | Middle name (individual clients) |
| `lastName` | PB, ML, Consumer | string | Last name (individual clients) |

### Line of Business

| Attribute | Description |
|-----------|-------------|
| `lob` | LOB triggering 312 review (for requesting LOB/312 trigger) |
| `lobCoverage[]` | All LOBs where client is covered |

### Ownership & Coverage

| Attribute | LOBs | Description |
|-----------|------|-------------|
| `salesOwners[]` | GB/GM, PB, ML | Sales owner(s) responsible for relationship |
| `producerId` | ML | Producer/Financial Advisor ID |
| `coverageTeamId` | PB | Coverage team identifier |

### Dates

| Attribute | Description |
|-----------|-------------|
| `refreshDueDate` | Refresh due date or family anniversary date |
| `last312CompletionDate` | Last 312 review completion date |

### Flags & Codes

| Attribute | LOBs | Description |
|-----------|------|-------------|
| `flag312` | GB/GM | 312 review requirement flag |
| `pvtCodeFromCRA` | ML, PB | PVT code from CRA (values: PVT01-PVT05) |

### Expected Activity Details

```typescript
expectedActivityVolume: {
  electronicTransfers: number;  // Expected # of electronic transfers
  cashChecks: number;           // Expected # of cash/check transactions
  ddqFields: Record<string, number>; // Custom DDQ fields
}

expectedActivityValue: {
  electronicTransfers: number;  // Expected USD value
  cashChecks: number;           // Expected USD value
  ddqFields: Record<string, number>; // Custom DDQ value fields
}
```

### Geographic & Purpose

| Attribute | LOBs | Max Length | Description |
|-----------|------|------------|-------------|
| `expectedCrossBorderActivity` | All | 1000 | Cross-border countries/activities |
| `purposeOfRelationship` | GB/GM | 1000 | Purpose of banking relationship |
| `purposeOfAccount` | ML, PB | 1000 | Purpose of account (text) |
| `purposeOfAccountDetails[]` | ML, PB | - | Account-level purpose grid |
| `sourceOfFunds` | ML, PB | 1000 | Source of funds for account(s) |

### Purpose of Account Details (ML/PB)

```typescript
purposeOfAccountDetails: [
  {
    accountNumber: string;
    accountName: string;
    sourceOfFunds: string;
  }
]
```

---

## 📋 CAM Attributes

### Required Attributes (All LOBs)
| Attribute | Type | Description |
|-----------|------|-------------|
| `partyId` | string | **PRIMARY KEY** - Unique client identifier |
| `legalName` | string | Client legal entity name |
| `lob` | enum | LOB triggering the CAM case (required) |
| `employeeIndicator` | boolean | BAC employee flag |
| `affiliateIndicator` | boolean | BAC affiliate flag |

### Shared with 312
All client information and LOB-specific identifiers are the same as 312.

### CAM-Specific Ownership

| Attribute | LOBs | Description |
|-----------|------|-------------|
| `clientOwners[]` | All | Client owner(s) responsible for relationship |
| `producerId` | ML | Producer/Financial Advisor ID |
| `coverageTeamIdentifier` | PB | Coverage team identifier |

### CAM-Specific Flags

| Attribute | LOBs | Description |
|-----------|------|-------------|
| `mlFlag` | ML, Consumer | Indicates consumer accounts can't be seen by FA |
| `excFlFlag` | Consumer | Executive flag - filters out if yes/Y |

### CAM-Specific Dates

| Attribute | Description |
|-----------|-------------|
| `refreshDueDate` | Family anniversary due (GB/GM from Cesium) OR Refresh completion (ML/PB/CI/Cons) |
| `refreshCompletionDate` | Refresh completion date (ML/PB/CI/Consumer) |
| `lastCAMCompletionDate` | Last CAM review completion date |

### CAM Review Data

| Attribute | Type | Description |
|-----------|------|-------------|
| `alerts[]` | CAMAlert[] | Associated alerts |
| `riskFactors[]` | string[] | Identified risk factors |
| `recommendations` | string | Analyst recommendations |

### CAM Alert Structure

```typescript
CAMAlert {
  id: string;
  type: string;              // e.g., "High Value Transaction"
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  description: string;
  dateGenerated: string;     // ISO 8601 datetime
  resolved: boolean;
}
```

---

## 🎯 LOB-Specific Requirements Matrix

### GB/GM
✅ **Required:** partyId, legalName, employeeIndicator, affiliateIndicator  
🔹 **Optional:** gciNumber, coperId, salesOwners, flag312, purposeOfRelationship  
❌ **Not Applicable:** mpId, producerId, coverageTeamId, pvtCodeFromCRA, sourceOfFunds, mlFlag, excFlFlag

### PB
✅ **Required:** partyId, legalName, employeeIndicator, affiliateIndicator  
🔹 **Optional:** firstName, lastName, gciNumber, salesOwners, coverageTeamId, pvtCodeFromCRA, purposeOfAccount, sourceOfFunds  
❌ **Not Applicable:** mpId, coperId, producerId, flag312, purposeOfRelationship, mlFlag, excFlFlag

### ML
✅ **Required:** partyId, legalName, employeeIndicator, affiliateIndicator  
🔹 **Optional:** firstName, lastName, mpId, producerId, pvtCodeFromCRA, purposeOfAccount, sourceOfFunds, mlFlag  
❌ **Not Applicable:** gciNumber, coperId, coverageTeamId, flag312, purposeOfRelationship, excFlFlag

### Consumer
✅ **Required:** partyId, legalName, employeeIndicator, affiliateIndicator  
🔹 **Optional:** firstName, middleName, lastName, mlFlag, excFlFlag  
❌ **Not Applicable:** gciNumber, mpId, coperId, producerId, salesOwners, coverageTeamId, pvtCodeFromCRA, purposeOfRelationship, sourceOfFunds

### CI
✅ **Required:** partyId, legalName, employeeIndicator, affiliateIndicator  
🔹 **Optional:** expectedActivityVolume, expectedActivityValue  
❌ **Not Applicable:** Most LOB-specific attributes

---

## 🗺️ Data Source Mapping

| Source System | Provides | LOBs |
|---------------|----------|------|
| **Cesium** | partyId, legalName, gciNumber, coperId, salesOwners, refreshDueDate, purposeOfRelationship | GB/GM |
| **AWARE Datamari** | expectedActivityVolume, expectedActivityValue, expectedCrossBorderActivity | GB/GM |
| **Population Manager Tool** | refreshDueDate, dueDate (DGA due dates) | All LOBs |
| **CRH** | partyId, legalName, firstName, middleName, lastName, refreshCompletionDate | Consumer |
| **GDPP** | partyId, legalName, gciNumber, mpId, purposeOfAccount, sourceOfFunds, pvtCodeFromCRA | PB, ML, Consumer |
| **GWIM Hub** | partyId, legalName, mpId, producerId, mlFlag, refreshCompletionDate | ML, Consumer |
| **PRDS** | employeeIndicator, affiliateIndicator, partyId | All LOBs |
| **ORRCA** | pvtCodeFromCRA, riskScore, riskLevel | ML, PB |
| **312 Model** | flag312, modelResult | GB/GM |
| **GFC Search Analytics** | (Outbound consumer: receives case status, disposition) | All LOBs |
| **FLU Data Sources** | (Outbound consumer: receives 312 completion status) | All LOBs |
| **TRMS** | trmsNumber, trmsCaseId (bidirectional) | All LOBs |
| **CAM Platform** | last312CompletionDate, lastCAMCompletionDate | All LOBs |

---

## ✅ Validation Rules

### ID Patterns
```
gciNumber:  ^GCI[0-9]{8,12}$
mpId:       ^MP[0-9]{6,10}$
coperId:    ^CP[0-9]{8,12}$
partyId:    ^[A-Z0-9-]+$  (1-50 chars)
```

### String Lengths
```
legalName:                  max 200 chars
firstName/middleName/lastName: max 100 chars
expectedCrossBorderActivity:   max 1000 chars
purposeOfRelationship:         max 1000 chars
purposeOfAccount:              max 1000 chars
sourceOfFunds:                 max 1000 chars
```

### Required Objects
```typescript
// Both volume and value required for 312
expectedActivityVolume: {
  electronicTransfers: number (min: 0),
  cashChecks: number (min: 0)
}

expectedActivityValue: {
  electronicTransfers: number (min: 0),
  cashChecks: number (min: 0)
}
```

### Enum Values
```
LOB: 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI'
pvtCodeFromCRA: 'PVT01' | 'PVT02' | 'PVT03' | 'PVT04' | 'PVT05'
CAMAlert.severity: 'Low' | 'Medium' | 'High' | 'Critical'
```

---

## 🔄 Attribute Comparison: 312 vs CAM

### Shared Attributes
- All core identifiers (partyId, legalName, names)
- All LOB-specific identifiers (gciNumber, mpId, coperId)
- All workbasket indicators (employeeIndicator, affiliateIndicator)
- LOB and LOB coverage fields
- producerId

### Unique to 312
- `salesOwners[]` (CAM uses `clientOwners[]`)
- `coverageTeamId` (CAM uses `coverageTeamIdentifier`)
- `refreshDueDate` (different meaning)
- `last312CompletionDate`
- `flag312`
- `pvtCodeFromCRA`
- `expectedActivityVolume` & `expectedActivityValue`
- `expectedCrossBorderActivity`
- `purposeOfRelationship`
- `purposeOfAccount` & `purposeOfAccountDetails[]`
- `sourceOfFunds`

### Unique to CAM
- `clientOwners[]` (312 uses `salesOwners[]`)
- `coverageTeamIdentifier` (312 uses `coverageTeamId`)
- `mlFlag`
- `excFlFlag`
- `refreshCompletionDate`
- `lastCAMCompletionDate`
- `alerts[]`
- `riskFactors[]`
- `recommendations`

---

## 📊 Quick Usage Examples

### 312 Data Payload (GB/GM Client)
```json
{
  "partyId": "PTY-12345678",
  "legalName": "Acme Corporation",
  "gciNumber": "GCI123456789",
  "employeeIndicator": false,
  "affiliateIndicator": false,
  "salesOwners": ["jsmith", "mjones"],
  "refreshDueDate": "2025-12-31",
  "flag312": true,
  "expectedActivityVolume": {
    "electronicTransfers": 50,
    "cashChecks": 20
  },
  "expectedActivityValue": {
    "electronicTransfers": 1000000.00,
    "cashChecks": 500000.00
  },
  "purposeOfRelationship": "Commercial banking and treasury services"
}
```

### CAM Data Payload (ML Client)
```json
{
  "partyId": "PTY-87654321",
  "legalName": "Jane Doe",
  "firstName": "Jane",
  "lastName": "Doe",
  "mpId": "MP9876543",
  "lob": "ML",
  "lobCoverage": ["ML", "Consumer"],
  "employeeIndicator": false,
  "affiliateIndicator": false,
  "clientOwners": ["asmith"],
  "producerId": "PROD-12345",
  "mlFlag": false,
  "refreshCompletionDate": "2025-10-20",
  "alerts": [
    {
      "id": "ALR-001",
      "type": "High Value Transaction",
      "severity": "High",
      "description": "Unusual transaction pattern",
      "dateGenerated": "2025-10-25T08:30:00Z",
      "resolved": false
    }
  ],
  "riskFactors": ["High transaction volume", "New geographic activity"]
}
```

---

## 📖 Reference Files

For complete details, see:
- **TypeScript Schemas:** `/src/schemas/CaseManagement.schema.ts`
- **Detailed Reference:** `/src/schemas/DataAttributes.reference.ts`
- **Swagger Schemas:** `/src/schemas/swagger-312-cam-schemas.yaml`
- **API Documentation:** `/src/schemas/swagger.yaml`

---

**Last Updated:** October 26, 2025  
**Version:** 1.0.0