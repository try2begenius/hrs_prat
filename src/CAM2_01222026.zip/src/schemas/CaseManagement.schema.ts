/**
 * Case Management Schema
 * 
 * Data taxonomy, schemas, and API endpoints for case management including
 * 312 and CAM workflows, case assignments, status tracking, and dispositions.
 */

// ============================================================================
// TYPE DEFINITIONS & DATA TAXONOMY
// ============================================================================

export type CaseStatus = 
  | 'Unassigned' 
  | 'In Progress' 
  | 'Pending Sales Review' 
  | 'In Sales Review' 
  | 'Sales Review Complete' 
  | 'Complete' 
  | 'Defect Remediation' 
  | 'Under Review' 
  | 'Escalated' 
  | 'Closed' 
  | 'Rejected';

export type Priority = 'Low' | 'Medium' | 'High' | 'Urgent';
export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';
export type LineOfBusiness = 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI';
export type CaseType = '312 Only' | 'CAM Only' | '312 + CAM';

export type ModelOutcome = 
  | 'No additional CAM escalation required' 
  | 'CAM Case Escalated' 
  | 'Pending Review';

export type CaseDisposition = 
  | 'No additional CAM escalation required' 
  | 'CAM Case Escalated' 
  | 'TRMS Filed' 
  | 'Client Closed' 
  | 'Escalated to Compliance' 
  | 'Pending';

export type Section312Status = 
  | 'Not Started' 
  | 'In Progress' 
  | 'Completed' 
  | 'Not Required';

export type Section312Disposition = 
  | 'need_trms' 
  | 'not_unusual_other' 
  | 'not_unusual_market_volatility' 
  | 'not_unusual' 
  | 'all_aligned' 
  | 'activity_differed';

export type CAMStatus = 
  | 'Not Started' 
  | 'In Progress' 
  | 'Pending Sales Review' 
  | 'Sales Review Complete' 
  | 'Completed';

export type CAMDisposition = 
  | 'No CAM Escalation' 
  | 'CAM Escalated' 
  | 'TRMS Filed' 
  | 'Client Closed';

export type CaseAction = 
  | 'complete_no_action' 
  | 'complete_trms_filed' 
  | 'send_to_sales';

/**
 * Core Case Entity
 * Represents a single case in the CAM system
 */
export interface Case {
  // Identifiers
  id: string;                        // Unique case identifier (e.g., "CASE-2025-001")
  clientId: string;                  // Client identifier
  clientName: string;                // Client legal name
  accountNumber: string;             // Primary account number
  gciNumber?: string;                // GCI number (GB/GM only)
  
  // Classification
  caseType: CaseType;                // Type of case workflow
  lineOfBusiness?: LineOfBusiness;   // Line of business
  status: CaseStatus;                // Current case status
  priority: Priority;                // Case priority level
  riskScore: number;                 // Risk score (0-100)
  riskLevel?: RiskLevel;             // Derived risk level
  
  // Assignment and Ownership
  assignedTo: string;                // Assigned analyst username
  assignedToName?: string;           // Assigned analyst full name
  salesOwner?: string;               // Sales owner username
  salesOwnerName?: string;           // Sales owner full name
  salesOwnerStatus?: string;         // Sales review status
  
  // Dates
  createdDate: string;               // ISO 8601 datetime - case creation
  dueDate: string;                   // ISO 8601 datetime - case due date
  lastUpdated: string;               // ISO 8601 datetime - last modification
  completionDate?: string;           // ISO 8601 datetime - completion
  originalCompletionDate?: string;   // Preserved for defect remediation
  
  // Activity Summary
  suspiciousActivity: string;        // Description of suspicious activity
  totalTransactions: number;         // Total transaction count
  flaggedTransactions: number;       // Flagged transaction count
  totalAmount: string;               // Total dollar amount (formatted)
  alertCount: number;                // Associated alert count
  description: string;               // Case description
  
  // Section 312 Fields
  section312Required: boolean;       // 312 review required flag
  section312Status?: Section312Status; // 312 workflow status
  section312Disposition?: string;    // 312 disposition
  section312ReviewedBy?: string;     // 312 reviewer username
  section312ReviewedDate?: string;   // ISO 8601 datetime
  section312Notes?: string;          // 312 review notes
  section312Data?: Case312Data;      // Detailed 312 data
  section312Response?: Case312Response; // 312 response data
  
  // CAM Fields
  camRequired: boolean;              // CAM review required flag
  camStatus?: CAMStatus;             // CAM workflow status
  camDisposition?: CAMDisposition;   // CAM disposition
  camReviewedBy?: string;            // CAM reviewer username
  camReviewedDate?: string;          // ISO 8601 datetime
  camNotes?: string;                 // CAM review notes
  camData?: CAMCaseData;             // Detailed CAM data
  
  // Sales Review Fields
  salesOwnerReviewedDate?: string;   // ISO 8601 datetime
  salesOwnerNotes?: string;          // Sales owner comments
  salesReviewComments?: string;      // Additional sales comments
  
  // Workflow Indicators
  is312Case?: boolean;               // Is this a 312 combination case
  autoClosed?: boolean;              // Auto-closed by system
  modelOutcome?: ModelOutcome;       // Model-generated outcome
  derivedDisposition?: CaseDisposition; // System-derived disposition
  defectRemediationFlag?: boolean;   // Defect remediation indicator
  isManuallyTriggered?: boolean;     // Manual ad-hoc case
  
  // Workbasket Indicators
  isBACEmployee?: boolean;           // BAC Employee indicator
  isBACAffiliate?: boolean;          // BAC Affiliate indicator
  isRegO?: boolean;                  // Reg O indicator
  
  // Integration References
  trmsNumber?: string;               // TRMS case number
  sarFiled?: boolean;                // SAR filing indicator
  sarNumber?: string;                // SAR case number
}

/**
 * Section 312 Data Structure
 * Detailed information for 312 reviews
 */
export interface Case312Data {
  // Primary Identifiers (REQUIRED)
  partyId: string;                   // Primary Key - MUST BE PROVIDED
  
  // Client Information
  legalName: string;                 // Client legal entity name
  firstName?: string;                // First name
  middleName?: string;               // Middle name
  lastName?: string;                 // Last name
  
  // LOB-Specific Identifiers
  gciNumber?: string;                // GCI number (PB/GB/GM only)
  mpId?: string;                     // MP ID (ML only)
  coperId?: string;                  // CoPer ID (GM only)
  
  // Line of Business
  lob?: LineOfBusiness;              // LOB triggering 312 review
  lobCoverage?: LineOfBusiness[];    // All LOBs where client is covered
  
  // Workbasket Indicators
  employeeIndicator: boolean;        // Employee indicator
  affiliateIndicator: boolean;       // Affiliate indicator
  
  // Ownership & Coverage
  salesOwners?: string[];            // Sales Owner(s)
  producerId?: string;               // Producer ID (ML only)
  coverageTeamId?: string;           // Coverage team ID (PB only)
  
  // Dates
  refreshDueDate?: string;           // Refresh due date / family anniversary date (ISO 8601)
  last312CompletionDate?: string;    // Last 312 completion date (ISO 8601)
  
  // Flags and Codes
  flag312?: boolean;                 // 312 Flag (GB/GM clients)
  pvtCodeFromCRA?: string;           // PVT code from CRA (ML/PB clients)
  
  // 312 Review Fields
  dueDate: string;                   // ISO 8601 datetime
  aging: number;                     // Days since creation
  status: string;                    // 312 status
  disposition?: string;              // 312 disposition
  completedDate?: string;            // ISO 8601 datetime
  modelResult: string;               // Model outcome
  modelResultDescription: string;    // Model rationale
  
  // Expected Activity (Value and Volume)
  expectedActivityVolume: {
    electronicTransfers?: number;
    cashChecks?: number;
    ddqFields?: Record<string, number>; // DDQ custom fields
  };
  expectedActivityValue: {
    electronicTransfers?: number;
    cashChecks?: number;
    ddqFields?: Record<string, number>;
  };
  
  // Geographic and Purpose
  expectedCrossBorderActivity?: string; // Cross-border countries/activities
  purposeOfRelationship?: string;    // GB/GM only
  purposeOfAccount?: string;         // ML/PB only - text description
  purposeOfAccountDetails?: Case312Account[]; // ML/PB only - account grid
  sourceOfFunds?: string;            // ML/PB only - Source of Funds
}

/**
 * 312 Account Detail (ML/PB)
 */
export interface Case312Account {
  accountNumber: string;
  accountName: string;
  sourceOfFunds: string;
}

/**
 * Section 312 Response/Questionnaire
 * Analyst responses to 312 questions
 */
export interface Case312Response {
  // Question 1: Expected Value and Volume of Money Movement
  question1_disposition?: Section312Disposition;
  question1_commentary?: string;
  
  // Question 2: Cross Border Money Movement Review
  question2_disposition?: 'need_trms' | 'not_unusual';
  question2_commentary?: string;
  
  // Question 3: Purpose of Relationship/Account
  question3_option?: 'all_aligned' | 'need_trms' | 'activity_differed';
  question3_comments?: string;       // Required if 'activity_differed'
  
  // Question 4: Source of Funds (ML only)
  question4_disposition?: 'need_trms' | 'not_unusual';
  question4_commentary?: string;
  
  // Case Action
  caseAction?: CaseAction;
  trmsNumber?: string;               // Required if caseAction = 'complete_trms_filed'
  salesOwner?: string;               // Required if caseAction = 'send_to_sales'
  salesComments?: string;            // Optional for send_to_sales
  
  // Submission metadata
  submittedBy?: string;
  submittedDate?: string;
  isSubmitted?: boolean;
}

/**
 * CAM Case Data Structure
 */
export interface CAMCaseData {
  // Primary Identifiers (REQUIRED)
  partyId: string;                   // Primary Key
  
  // Client Information
  legalName: string;                 // Client legal entity name
  firstName?: string;                // First name
  middleName?: string;               // Middle name
  lastName?: string;                 // Last name
  
  // LOB-Specific Identifiers
  gciNumber?: string;                // GCI Number
  mpId?: string;                     // MP ID
  coperId?: string;                  // CoPer ID
  
  // Line of Business
  lob?: LineOfBusiness;              // LOB triggering CAM case
  lobCoverage?: LineOfBusiness[];    // All LOBs where client is covered
  
  // Workbasket Indicators
  employeeIndicator: boolean;        // Employee indicator
  affiliateIndicator: boolean;       // Affiliate indicator
  
  // Ownership & Coverage
  clientOwners?: string[];           // Client Owner(s)
  producerId?: string;               // Producer ID (ML only)
  coverageTeamIdentifier?: string;   // Coverage team identifier (PB only)
  
  // Flags
  mlFlag?: boolean;                  // Indicates consumer accounts can't be seen by FA
  excFlFlag?: boolean;               // EXC_FL Flag from WCC (Consumer only) - filters out if yes/Y
  
  // Dates
  refreshDueDate?: string;           // Family anniversary due date for GB/GM (ISO 8601)
  refreshCompletionDate?: string;    // ML/PB/CI/Cons refresh completion date (ISO 8601)
  lastCAMCompletionDate?: string;    // Last CAM completion date (ISO 8601)
  
  // CAM Review Fields
  dueDate: string;                   // ISO 8601 datetime
  aging: number;                     // Days since creation
  status: string;                    // CAM status
  disposition?: string;              // CAM disposition
  completedDate?: string;            // ISO 8601 datetime
  modelResult: string;               // Model outcome
  alerts: CAMAlert[];                // Associated alerts
  riskFactors: string[];             // Risk factors
  recommendations?: string;          // Analyst recommendations
}

/**
 * CAM Alert Detail
 */
export interface CAMAlert {
  id: string;
  type: string;                      // Alert type
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  description: string;
  dateGenerated: string;             // ISO 8601 datetime
  resolved: boolean;
}

/**
 * Case Assignment Request
 */
export interface CaseAssignment {
  caseId: string;
  assignedTo: string;                // Username
  assignedBy: string;                // Username of assigner
  assignmentDate: string;            // ISO 8601 datetime
  notes?: string;                    // Assignment notes
}

/**
 * Case Note/Comment
 */
export interface CaseNote {
  id: string;
  caseId: string;
  author: string;                    // Username
  authorName: string;                // Full name
  content: string;                   // Note content
  timestamp: string;                 // ISO 8601 datetime
  noteType: 'General' | '312' | 'CAM' | 'Sales' | 'System';
  isSystemGenerated: boolean;
}

/**
 * Case Activity Log
 */
export interface CaseActivity {
  id: string;
  caseId: string;
  action: string;                    // Action performed
  performedBy: string;               // Username
  performedByName: string;           // Full name
  timestamp: string;                 // ISO 8601 datetime
  details?: Record<string, any>;     // Additional details
  previousValue?: string;            // Previous state
  newValue?: string;                 // New state
}

/**
 * Case Statistics
 */
export interface CaseStatistics {
  totalCases: number;
  casesByStatus: Record<CaseStatus, number>;
  casesByPriority: Record<Priority, number>;
  casesByType: Record<CaseType, number>;
  averageResolutionTime: number;    // Days
  overdueCases: number;
  dueSoon: number;                   // Due within 3 days
  defectRemediationCount: number;
  assignedToUser: number;            // For individual view
}

// ============================================================================
// JSON SCHEMA DEFINITIONS
// ============================================================================

export const CaseSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: [
    "id", "clientId", "clientName", "accountNumber", "caseType",
    "status", "priority", "riskScore", "assignedTo", "createdDate",
    "dueDate", "lastUpdated", "section312Required", "camRequired"
  ],
  properties: {
    id: {
      type: "string",
      pattern: "^CASE-[0-9]{4}-[0-9]{3,}$",
      description: "Unique case identifier"
    },
    clientId: {
      type: "string",
      minLength: 1
    },
    clientName: {
      type: "string",
      minLength: 1,
      maxLength: 200
    },
    accountNumber: {
      type: "string",
      pattern: "^[0-9]{10,16}$"
    },
    caseType: {
      type: "string",
      enum: ["312 Only", "CAM Only", "312 + CAM"]
    },
    lineOfBusiness: {
      type: "string",
      enum: ["GB/GM", "PB", "ML", "Consumer", "CI"]
    },
    status: {
      type: "string",
      enum: [
        "Unassigned", "In Progress", "Pending Sales Review",
        "In Sales Review", "Sales Review Complete", "Complete",
        "Defect Remediation", "Under Review", "Escalated", "Closed", "Rejected"
      ]
    },
    priority: {
      type: "string",
      enum: ["Low", "Medium", "High", "Urgent"]
    },
    riskScore: {
      type: "number",
      minimum: 0,
      maximum: 100
    },
    section312Required: {
      type: "boolean"
    },
    camRequired: {
      type: "boolean"
    }
  }
};

// ============================================================================
// API ENDPOINTS SPECIFICATION
// ============================================================================

export const CaseManagementAPI = {
  baseUrl: "/api/v1/cases",
  
  endpoints: {
    /**
     * GET /api/v1/cases
     * List cases with filtering and pagination
     */
    listCases: {
      method: "GET",
      path: "/",
      queryParams: {
        status: "string (optional) - Filter by status",
        assignedTo: "string (optional) - Filter by assigned user",
        priority: "string (optional) - Filter by priority",
        caseType: "string (optional) - Filter by case type",
        lineOfBusiness: "string (optional) - Filter by LOB",
        dueAfter: "string (optional) - ISO 8601 date",
        dueBefore: "string (optional) - ISO 8601 date",
        search: "string (optional) - Search by client name, case ID",
        page: "number (optional) - Page number (default: 1)",
        pageSize: "number (optional) - Items per page (default: 20)",
        sortBy: "string (optional) - Sort field (default: createdDate)",
        sortOrder: "string (optional) - asc | desc (default: desc)"
      },
      response: {
        status: 200,
        body: {
          data: "Case[]",
          total: "number",
          page: "number",
          pageSize: "number",
          totalPages: "number"
        }
      },
      example: `
GET /api/v1/cases?status=In Progress&assignedTo=jdoe&page=1&pageSize=20

Response:
{
  "data": [
    {
      "id": "CASE-2025-001",
      "clientName": "Acme Corporation",
      "clientId": "CLI-12345",
      "accountNumber": "1234567890",
      "status": "In Progress",
      "priority": "High",
      "assignedTo": "jdoe",
      "dueDate": "2025-11-05T00:00:00Z",
      ...
    }
  ],
  "total": 45,
  "page": 1,
  "pageSize": 20,
  "totalPages": 3
}
      `
    },

    /**
     * GET /api/v1/cases/:id
     * Get case by ID
     */
    getCaseById: {
      method: "GET",
      path: "/:id",
      pathParams: {
        id: "string - Case identifier"
      },
      response: {
        status: 200,
        body: "Case"
      },
      errors: {
        404: "Case not found",
        403: "Insufficient permissions"
      },
      example: `
GET /api/v1/cases/CASE-2025-001

Response:
{
  "id": "CASE-2025-001",
  "clientName": "Acme Corporation",
  "section312Data": { ... },
  "camData": { ... }
}
      `
    },

    /**
     * POST /api/v1/cases
     * Create new case
     */
    createCase: {
      method: "POST",
      path: "/",
      requestBody: {
        clientId: "string (required)",
        clientName: "string (required)",
        accountNumber: "string (required)",
        caseType: "CaseType (required)",
        priority: "Priority (required)",
        section312Required: "boolean (required)",
        camRequired: "boolean (required)",
        assignedTo: "string (optional)",
        lineOfBusiness: "LineOfBusiness (optional)",
        description: "string (optional)",
        notes: "string (optional)"
      },
      response: {
        status: 201,
        body: "Case"
      },
      permissions: ["Analyst", "Manager", "Administrator"],
      example: `
POST /api/v1/cases
Content-Type: application/json

{
  "clientId": "CLI-12345",
  "clientName": "Acme Corporation",
  "accountNumber": "1234567890",
  "caseType": "312 + CAM",
  "priority": "High",
  "section312Required": true,
  "camRequired": true,
  "assignedTo": "jdoe"
}

Response: 201 Created
{
  "id": "CASE-2025-156",
  "status": "In Progress",
  "createdDate": "2025-10-26T10:30:00Z",
  ...
}
      `
    },

    /**
     * PUT /api/v1/cases/:id
     * Update case
     */
    updateCase: {
      method: "PUT",
      path: "/:id",
      pathParams: {
        id: "string - Case identifier"
      },
      requestBody: "Partial<Case>",
      response: {
        status: 200,
        body: "Case"
      },
      permissions: ["Analyst", "Manager", "Administrator"],
      example: `
PUT /api/v1/cases/CASE-2025-001
Content-Type: application/json

{
  "status": "Complete",
  "section312Status": "Completed",
  "section312Disposition": "not_unusual_other"
}
      `
    },

    /**
     * POST /api/v1/cases/:id/assign
     * Assign case to user
     */
    assignCase: {
      method: "POST",
      path: "/:id/assign",
      pathParams: {
        id: "string - Case identifier"
      },
      requestBody: {
        assignedTo: "string (required) - Username",
        notes: "string (optional) - Assignment notes"
      },
      response: {
        status: 200,
        body: {
          case: "Case",
          assignment: "CaseAssignment"
        }
      },
      permissions: ["Manager", "Administrator"],
      example: `
POST /api/v1/cases/CASE-2025-001/assign
Content-Type: application/json

{
  "assignedTo": "jsmith",
  "notes": "High priority client - please review ASAP"
}
      `
    },

    /**
     * POST /api/v1/cases/:id/312/submit
     * Submit 312 review
     */
    submit312Review: {
      method: "POST",
      path: "/:id/312/submit",
      pathParams: {
        id: "string - Case identifier"
      },
      requestBody: "Case312Response",
      response: {
        status: 200,
        body: "Case"
      },
      permissions: ["Analyst", "Manager"],
      example: `
POST /api/v1/cases/CASE-2025-001/312/submit
Content-Type: application/json

{
  "question1_disposition": "not_unusual_other",
  "question1_commentary": "Activity consistent with business model",
  "question2_disposition": "not_unusual",
  "question3_option": "all_aligned",
  "caseAction": "complete_no_action"
}
      `
    },

    /**
     * GET /api/v1/cases/:id/notes
     * Get case notes
     */
    getCaseNotes: {
      method: "GET",
      path: "/:id/notes",
      pathParams: {
        id: "string - Case identifier"
      },
      queryParams: {
        noteType: "string (optional) - Filter by note type"
      },
      response: {
        status: 200,
        body: "CaseNote[]"
      }
    },

    /**
     * POST /api/v1/cases/:id/notes
     * Add case note
     */
    addCaseNote: {
      method: "POST",
      path: "/:id/notes",
      pathParams: {
        id: "string - Case identifier"
      },
      requestBody: {
        content: "string (required)",
        noteType: "string (required) - General | 312 | CAM | Sales"
      },
      response: {
        status: 201,
        body: "CaseNote"
      }
    },

    /**
     * GET /api/v1/cases/:id/activity
     * Get case activity log
     */
    getCaseActivity: {
      method: "GET",
      path: "/:id/activity",
      pathParams: {
        id: "string - Case identifier"
      },
      queryParams: {
        startDate: "string (optional) - ISO 8601 date",
        endDate: "string (optional) - ISO 8601 date",
        limit: "number (optional) - Max results"
      },
      response: {
        status: 200,
        body: "CaseActivity[]"
      }
    },

    /**
     * GET /api/v1/cases/statistics
     * Get case statistics
     */
    getCaseStatistics: {
      method: "GET",
      path: "/statistics",
      queryParams: {
        assignedTo: "string (optional) - Filter by user",
        lineOfBusiness: "string (optional) - Filter by LOB",
        startDate: "string (optional) - ISO 8601 date",
        endDate: "string (optional) - ISO 8601 date"
      },
      response: {
        status: 200,
        body: "CaseStatistics"
      },
      example: `
GET /api/v1/cases/statistics?assignedTo=jdoe

Response:
{
  "totalCases": 45,
  "casesByStatus": {
    "In Progress": 12,
    "Complete": 28,
    "Pending Sales Review": 5
  },
  "averageResolutionTime": 4.5,
  "overdueCases": 2,
  "dueSoon": 5
}
      `
    },

    /**
     * GET /api/v1/cases/my-cases
     * Get cases for current user
     */
    getMyCases: {
      method: "GET",
      path: "/my-cases",
      queryParams: {
        status: "string (optional)",
        priority: "string (optional)"
      },
      response: {
        status: 200,
        body: "Case[]"
      },
      description: "Returns cases assigned to the authenticated user"
    },

    /**
     * POST /api/v1/cases/bulk-assign
     * Bulk assign cases
     */
    bulkAssignCases: {
      method: "POST",
      path: "/bulk-assign",
      requestBody: {
        caseIds: "string[] (required)",
        assignedTo: "string (required)"
      },
      response: {
        status: 200,
        body: {
          successCount: "number",
          failedCount: "number",
          failures: "Array<{ caseId: string, reason: string }>"
        }
      },
      permissions: ["Manager", "Administrator"]
    }
  }
};

export default {
  CaseSchema,
  CaseManagementAPI
};