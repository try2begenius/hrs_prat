/**
 * Dashboard Schema
 * 
 * Data taxonomy, schemas, and API endpoints for dashboard metrics,
 * KPIs, and real-time monitoring data.
 */

// ============================================================================
// TYPE DEFINITIONS & DATA TAXONOMY
// ============================================================================

export type MetricTrend = 'up' | 'down' | 'stable';
export type TimeRange = '24h' | '7d' | '30d' | '90d' | 'ytd' | 'custom';

/**
 * Dashboard Overview Metrics
 * High-level KPIs displayed on main dashboard
 */
export interface DashboardMetrics {
  // Case Volume Metrics
  totalCases: number;
  activeCases: number;
  completedCases: number;
  overdueCases: number;
  
  // Trends
  totalCasesTrend: MetricTrend;
  activeCasesTrend: MetricTrend;
  completedCasesTrend: MetricTrend;
  overdueCasesTrend: MetricTrend;
  
  // Percentages
  totalCasesChange: number;          // Percentage change
  activeCasesChange: number;
  completedCasesChange: number;
  overdueCasesChange: number;
  
  // Time-based Metrics
  averageResolutionTime: number;     // Days
  averageTimeToAssignment: number;   // Hours
  
  // Workload Metrics
  casesAssignedToUser: number;       // For individual dashboard
  userCompletionRate: number;        // Percentage
  
  // 312 & CAM Specific
  section312Cases: number;
  camCases: number;
  combinedCases: number;
  
  // Risk Metrics
  highRiskCases: number;
  criticalRiskCases: number;
}

/**
 * Case Volume by Status
 */
export interface CaseVolumeByStatus {
  status: string;
  count: number;
  percentage: number;
  trend: MetricTrend;
  change: number;                    // Absolute change from previous period
}

/**
 * Case Volume by Priority
 */
export interface CaseVolumeByPriority {
  priority: string;
  count: number;
  percentage: number;
  averageResolutionTime: number;     // Days
}

/**
 * Case Volume by Type
 */
export interface CaseVolumeByType {
  caseType: string;
  count: number;
  percentage: number;
  completionRate: number;            // Percentage
}

/**
 * Case Volume by Line of Business
 */
export interface CaseVolumeByLOB {
  lineOfBusiness: string;
  count: number;
  percentage: number;
  averageRiskScore: number;
}

/**
 * Time Series Data Point
 */
export interface TimeSeriesDataPoint {
  date: string;                      // ISO 8601 date
  value: number;
  label?: string;                    // Optional display label
}

/**
 * Case Volume Trend
 * Time series data for case volume over time
 */
export interface CaseVolumeTrend {
  period: TimeRange;
  dataPoints: TimeSeriesDataPoint[];
  total: number;
  average: number;
  peak: number;
  peakDate: string;
}

/**
 * Completion Rate Trend
 */
export interface CompletionRateTrend {
  period: TimeRange;
  dataPoints: TimeSeriesDataPoint[];
  averageRate: number;               // Percentage
  targetRate: number;                // Target percentage
  isAboveTarget: boolean;
}

/**
 * Resolution Time Distribution
 */
export interface ResolutionTimeDistribution {
  range: string;                     // e.g., "0-2 days", "3-5 days"
  count: number;
  percentage: number;
}

/**
 * User Performance Metrics
 */
export interface UserPerformanceMetrics {
  username: string;
  fullName: string;
  casesAssigned: number;
  casesCompleted: number;
  completionRate: number;            // Percentage
  averageResolutionTime: number;     // Days
  overdueCases: number;
  qualityScore?: number;             // 0-100
}

/**
 * Team Performance Summary
 */
export interface TeamPerformanceMetrics {
  totalAnalysts: number;
  activeAnalysts: number;            // Analysts with active cases
  totalCasesAssigned: number;
  totalCasesCompleted: number;
  teamCompletionRate: number;        // Percentage
  teamAverageResolutionTime: number; // Days
  topPerformers: UserPerformanceMetrics[];
  bottomPerformers: UserPerformanceMetrics[];
}

/**
 * Risk Score Distribution
 */
export interface RiskScoreDistribution {
  riskLevel: string;                 // Low, Medium, High, Critical
  count: number;
  percentage: number;
  averageResolutionTime: number;     // Days
}

/**
 * Alert Summary
 */
export interface AlertSummary {
  totalAlerts: number;
  unreadAlerts: number;
  criticalAlerts: number;
  recentAlerts: Alert[];
}

/**
 * Alert Detail
 */
export interface Alert {
  id: string;
  type: string;                      // e.g., "Case Overdue", "High Risk"
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  title: string;
  message: string;
  timestamp: string;                 // ISO 8601 datetime
  read: boolean;
  actionUrl?: string;                // Link to related resource
  metadata?: Record<string, any>;
}

/**
 * Upcoming Deadlines
 */
export interface UpcomingDeadline {
  caseId: string;
  clientName: string;
  dueDate: string;                   // ISO 8601 datetime
  daysUntilDue: number;
  priority: string;
  assignedTo: string;
  caseType: string;
}

/**
 * Recent Activity
 */
export interface RecentActivity {
  id: string;
  action: string;
  performedBy: string;
  performedByName: string;
  timestamp: string;                 // ISO 8601 datetime
  resourceType: string;              // e.g., "Case", "Assignment"
  resourceId: string;
  description: string;
}

/**
 * Integration Health Summary
 */
export interface IntegrationHealthSummary {
  totalIntegrations: number;
  connectedIntegrations: number;
  errorIntegrations: number;
  lastSyncTime: string;              // ISO 8601 datetime
  healthPercentage: number;          // 0-100
}

/**
 * Dashboard Widget Configuration
 */
export interface DashboardWidget {
  id: string;
  type: string;                      // Widget type identifier
  title: string;
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  config: Record<string, any>;       // Widget-specific configuration
  visible: boolean;
}

/**
 * User Dashboard Preferences
 */
export interface DashboardPreferences {
  userId: string;
  layout: 'default' | 'compact' | 'custom';
  widgets: DashboardWidget[];
  defaultTimeRange: TimeRange;
  refreshInterval: number;           // Seconds
  theme?: 'light' | 'dark' | 'auto';
}

// ============================================================================
// JSON SCHEMA DEFINITIONS
// ============================================================================

export const DashboardMetricsSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: [
    "totalCases", "activeCases", "completedCases", "overdueCases",
    "averageResolutionTime"
  ],
  properties: {
    totalCases: {
      type: "integer",
      minimum: 0
    },
    activeCases: {
      type: "integer",
      minimum: 0
    },
    completedCases: {
      type: "integer",
      minimum: 0
    },
    overdueCases: {
      type: "integer",
      minimum: 0
    },
    totalCasesTrend: {
      type: "string",
      enum: ["up", "down", "stable"]
    },
    averageResolutionTime: {
      type: "number",
      minimum: 0
    },
    section312Cases: {
      type: "integer",
      minimum: 0
    },
    camCases: {
      type: "integer",
      minimum: 0
    },
    combinedCases: {
      type: "integer",
      minimum: 0
    }
  }
};

export const TimeSeriesDataPointSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: ["date", "value"],
  properties: {
    date: {
      type: "string",
      format: "date"
    },
    value: {
      type: "number"
    },
    label: {
      type: "string"
    }
  }
};

// ============================================================================
// API ENDPOINTS SPECIFICATION
// ============================================================================

export const DashboardAPI = {
  baseUrl: "/api/v1/dashboard",
  
  endpoints: {
    /**
     * GET /api/v1/dashboard/metrics
     * Get overall dashboard metrics
     */
    getMetrics: {
      method: "GET",
      path: "/metrics",
      queryParams: {
        timeRange: "TimeRange (optional) - default: 30d",
        userId: "string (optional) - For user-specific metrics"
      },
      response: {
        status: 200,
        body: "DashboardMetrics"
      },
      example: `
GET /api/v1/dashboard/metrics?timeRange=30d

Response:
{
  "totalCases": 1245,
  "activeCases": 423,
  "completedCases": 789,
  "overdueCases": 33,
  "totalCasesTrend": "up",
  "totalCasesChange": 12.5,
  "averageResolutionTime": 4.8,
  "section312Cases": 456,
  "camCases": 234,
  "combinedCases": 555
}
      `
    },

    /**
     * GET /api/v1/dashboard/volume-by-status
     * Get case volume breakdown by status
     */
    getVolumeByStatus: {
      method: "GET",
      path: "/volume-by-status",
      queryParams: {
        timeRange: "TimeRange (optional)"
      },
      response: {
        status: 200,
        body: "CaseVolumeByStatus[]"
      },
      example: `
GET /api/v1/dashboard/volume-by-status

Response:
[
  {
    "status": "In Progress",
    "count": 245,
    "percentage": 45.2,
    "trend": "up",
    "change": 12
  },
  {
    "status": "Complete",
    "count": 189,
    "percentage": 34.8,
    "trend": "stable",
    "change": 2
  }
]
      `
    },

    /**
     * GET /api/v1/dashboard/volume-by-priority
     * Get case volume breakdown by priority
     */
    getVolumeByPriority: {
      method: "GET",
      path: "/volume-by-priority",
      queryParams: {
        timeRange: "TimeRange (optional)"
      },
      response: {
        status: 200,
        body: "CaseVolumeByPriority[]"
      }
    },

    /**
     * GET /api/v1/dashboard/volume-by-type
     * Get case volume breakdown by type
     */
    getVolumeByType: {
      method: "GET",
      path: "/volume-by-type",
      queryParams: {
        timeRange: "TimeRange (optional)"
      },
      response: {
        status: 200,
        body: "CaseVolumeByType[]"
      }
    },

    /**
     * GET /api/v1/dashboard/volume-by-lob
     * Get case volume breakdown by line of business
     */
    getVolumeByLOB: {
      method: "GET",
      path: "/volume-by-lob",
      queryParams: {
        timeRange: "TimeRange (optional)"
      },
      response: {
        status: 200,
        body: "CaseVolumeByLOB[]"
      }
    },

    /**
     * GET /api/v1/dashboard/volume-trend
     * Get case volume trend over time
     */
    getVolumeTrend: {
      method: "GET",
      path: "/volume-trend",
      queryParams: {
        timeRange: "TimeRange (required)",
        granularity: "string (optional) - daily | weekly | monthly"
      },
      response: {
        status: 200,
        body: "CaseVolumeTrend"
      },
      example: `
GET /api/v1/dashboard/volume-trend?timeRange=30d&granularity=daily

Response:
{
  "period": "30d",
  "dataPoints": [
    { "date": "2025-10-01", "value": 45 },
    { "date": "2025-10-02", "value": 52 },
    { "date": "2025-10-03", "value": 48 }
  ],
  "total": 1245,
  "average": 41.5,
  "peak": 67,
  "peakDate": "2025-10-15"
}
      `
    },

    /**
     * GET /api/v1/dashboard/completion-trend
     * Get completion rate trend
     */
    getCompletionTrend: {
      method: "GET",
      path: "/completion-trend",
      queryParams: {
        timeRange: "TimeRange (required)",
        granularity: "string (optional) - daily | weekly | monthly"
      },
      response: {
        status: 200,
        body: "CompletionRateTrend"
      }
    },

    /**
     * GET /api/v1/dashboard/resolution-distribution
     * Get resolution time distribution
     */
    getResolutionDistribution: {
      method: "GET",
      path: "/resolution-distribution",
      queryParams: {
        timeRange: "TimeRange (optional)"
      },
      response: {
        status: 200,
        body: "ResolutionTimeDistribution[]"
      },
      example: `
GET /api/v1/dashboard/resolution-distribution

Response:
[
  { "range": "0-2 days", "count": 234, "percentage": 32.5 },
  { "range": "3-5 days", "count": 345, "percentage": 47.8 },
  { "range": "6-10 days", "count": 98, "percentage": 13.6 },
  { "range": "10+ days", "count": 44, "percentage": 6.1 }
]
      `
    },

    /**
     * GET /api/v1/dashboard/user-performance
     * Get user performance metrics
     */
    getUserPerformance: {
      method: "GET",
      path: "/user-performance",
      queryParams: {
        userId: "string (optional) - Specific user or current user",
        timeRange: "TimeRange (optional)"
      },
      response: {
        status: 200,
        body: "UserPerformanceMetrics"
      }
    },

    /**
     * GET /api/v1/dashboard/team-performance
     * Get team performance summary
     */
    getTeamPerformance: {
      method: "GET",
      path: "/team-performance",
      queryParams: {
        timeRange: "TimeRange (optional)",
        topN: "number (optional) - Number of top/bottom performers (default: 5)"
      },
      response: {
        status: 200,
        body: "TeamPerformanceMetrics"
      },
      permissions: ["Manager", "Administrator"]
    },

    /**
     * GET /api/v1/dashboard/risk-distribution
     * Get risk score distribution
     */
    getRiskDistribution: {
      method: "GET",
      path: "/risk-distribution",
      queryParams: {
        timeRange: "TimeRange (optional)"
      },
      response: {
        status: 200,
        body: "RiskScoreDistribution[]"
      }
    },

    /**
     * GET /api/v1/dashboard/alerts
     * Get alert summary
     */
    getAlerts: {
      method: "GET",
      path: "/alerts",
      queryParams: {
        unreadOnly: "boolean (optional)",
        severity: "string (optional) - Filter by severity",
        limit: "number (optional) - Max results (default: 10)"
      },
      response: {
        status: 200,
        body: "AlertSummary"
      }
    },

    /**
     * GET /api/v1/dashboard/upcoming-deadlines
     * Get upcoming case deadlines
     */
    getUpcomingDeadlines: {
      method: "GET",
      path: "/upcoming-deadlines",
      queryParams: {
        days: "number (optional) - Days ahead to look (default: 7)",
        userId: "string (optional) - Filter by assigned user",
        limit: "number (optional) - Max results (default: 10)"
      },
      response: {
        status: 200,
        body: "UpcomingDeadline[]"
      },
      example: `
GET /api/v1/dashboard/upcoming-deadlines?days=7&limit=5

Response:
[
  {
    "caseId": "CASE-2025-045",
    "clientName": "ABC Corp",
    "dueDate": "2025-10-28T00:00:00Z",
    "daysUntilDue": 2,
    "priority": "High",
    "assignedTo": "jdoe",
    "caseType": "312 + CAM"
  }
]
      `
    },

    /**
     * GET /api/v1/dashboard/recent-activity
     * Get recent system activity
     */
    getRecentActivity: {
      method: "GET",
      path: "/recent-activity",
      queryParams: {
        userId: "string (optional) - Filter by user",
        limit: "number (optional) - Max results (default: 20)"
      },
      response: {
        status: 200,
        body: "RecentActivity[]"
      }
    },

    /**
     * GET /api/v1/dashboard/integration-health
     * Get integration health summary
     */
    getIntegrationHealth: {
      method: "GET",
      path: "/integration-health",
      response: {
        status: 200,
        body: "IntegrationHealthSummary"
      }
    },

    /**
     * GET /api/v1/dashboard/preferences
     * Get user dashboard preferences
     */
    getPreferences: {
      method: "GET",
      path: "/preferences",
      response: {
        status: 200,
        body: "DashboardPreferences"
      }
    },

    /**
     * PUT /api/v1/dashboard/preferences
     * Update user dashboard preferences
     */
    updatePreferences: {
      method: "PUT",
      path: "/preferences",
      requestBody: "Partial<DashboardPreferences>",
      response: {
        status: 200,
        body: "DashboardPreferences"
      }
    },

    /**
     * POST /api/v1/dashboard/export
     * Export dashboard data
     */
    exportDashboard: {
      method: "POST",
      path: "/export",
      requestBody: {
        format: "string (required) - pdf | excel | csv",
        timeRange: "TimeRange (required)",
        sections: "string[] (optional) - Specific sections to include"
      },
      response: {
        status: 200,
        body: {
          downloadUrl: "string",
          expiresAt: "string",
          fileSize: "number"
        }
      }
    }
  }
};

// ============================================================================
// WIDGET TYPES CATALOG
// ============================================================================

export const DashboardWidgetTypes = {
  metrics: {
    id: "metrics-card",
    name: "Metrics Card",
    description: "Display single KPI metric with trend",
    configSchema: {
      metric: "string - Metric to display",
      showTrend: "boolean",
      showChange: "boolean"
    }
  },
  chart: {
    id: "chart-widget",
    name: "Chart Widget",
    description: "Display data as chart",
    configSchema: {
      chartType: "string - line | bar | pie | doughnut",
      dataSource: "string - API endpoint",
      timeRange: "TimeRange"
    }
  },
  table: {
    id: "table-widget",
    name: "Table Widget",
    description: "Display tabular data",
    configSchema: {
      dataSource: "string",
      columns: "string[]",
      sortable: "boolean"
    }
  },
  alerts: {
    id: "alerts-widget",
    name: "Alerts Widget",
    description: "Display recent alerts",
    configSchema: {
      maxItems: "number",
      severityFilter: "string[]"
    }
  }
};

export default {
  DashboardMetricsSchema,
  TimeSeriesDataPointSchema,
  DashboardAPI,
  DashboardWidgetTypes
};
