/**
 * Data Attributes Reference
 * 
 * Comprehensive reference for all 312 and CAM data attributes including
 * LOB-specific requirements, field descriptions, and data lineage.
 */

// ============================================================================
// SECTION 312 DATA ATTRIBUTES
// ============================================================================

export const Section312DataAttributes = {
  description: 'Complete attribute set for Section 312 review workflows',
  
  // CORE IDENTIFIERS (REQUIRED)
  identifiers: {
    partyId: {
      name: 'Party ID',
      required: true,
      isPrimaryKey: true,
      type: 'string',
      description: 'Unique client identifier - Acts as Primary Key and MUST BE PROVIDED',
      source: ['Cesium', 'CMT', 'AWAREWCC', 'GWIM Hub'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      validationRules: {
        minLength: 1,
        maxLength: 50,
        pattern: '^[A-Z0-9-]+$'
      }
    }
  },
  
  // CLIENT INFORMATION
  clientInfo: {
    legalName: {
      name: 'Legal Name',
      required: true,
      type: 'string',
      description: 'Client legal entity name',
      source: ['Cesium', 'CMT', 'AWAREWCC'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      maxLength: 200
    },
    firstName: {
      name: 'First Name',
      required: false,
      type: 'string',
      description: 'Client first name (individual clients)',
      source: ['CMT', 'AWAREWCC'],
      applicableLOBs: ['PB', 'ML', 'Consumer'],
      maxLength: 100
    },
    middleName: {
      name: 'Middle Name',
      required: false,
      type: 'string',
      description: 'Client middle name (individual clients)',
      source: ['CMT', 'AWAREWCC'],
      applicableLOBs: ['PB', 'ML', 'Consumer'],
      maxLength: 100
    },
    lastName: {
      name: 'Last Name',
      required: false,
      type: 'string',
      description: 'Client last name (individual clients)',
      source: ['CMT', 'AWAREWCC'],
      applicableLOBs: ['PB', 'ML', 'Consumer'],
      maxLength: 100
    }
  },
  
  // LOB-SPECIFIC IDENTIFIERS
  lobSpecificIdentifiers: {
    gciNumber: {
      name: 'GCI Number',
      required: false,
      type: 'string',
      description: 'Global Client Identifier number',
      source: ['Cesium'],
      applicableLOBs: ['GB/GM', 'PB'],
      lobRestriction: 'PB/GB/GM only',
      pattern: '^GCI[0-9]{8,12}$'
    },
    mpId: {
      name: 'MP ID',
      required: false,
      type: 'string',
      description: 'Merrill Portfolio ID',
      source: ['GWIM Hub'],
      applicableLOBs: ['ML'],
      lobRestriction: 'ML only',
      pattern: '^MP[0-9]{6,10}$'
    },
    coperId: {
      name: 'CoPer ID',
      required: false,
      type: 'string',
      description: 'Corporate Relationship ID',
      source: ['Cesium'],
      applicableLOBs: ['GB/GM'],
      lobRestriction: 'GM only',
      pattern: '^CP[0-9]{8,12}$'
    }
  },
  
  // LINE OF BUSINESS
  lob: {
    lob: {
      name: 'LOB',
      required: false,
      type: 'enum',
      description: 'Line of Business triggering the 312 review',
      allowedValues: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      purpose: 'Used only for requesting LOB/312 trigger'
    },
    lobCoverage: {
      name: 'LOB Coverage',
      required: false,
      type: 'array',
      description: 'All lines of business (LOB) where client is covered',
      allowedValues: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      purpose: 'Comprehensive view of client coverage across all LOBs'
    }
  },
  
  // WORKBASKET INDICATORS
  workbasketIndicators: {
    employeeIndicator: {
      name: 'Employee Indicator',
      required: true,
      type: 'boolean',
      description: 'Indicates if client is a Bank of America employee',
      source: ['PRDS'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      defaultValue: false,
      businessRule: 'Used for workbasket filtering and special handling'
    },
    affiliateIndicator: {
      name: 'Affiliate Indicator',
      required: true,
      type: 'boolean',
      description: 'Indicates if client is a Bank of America affiliate',
      source: ['PRDS'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      defaultValue: false,
      businessRule: 'Used for workbasket filtering and special handling'
    }
  },
  
  // OWNERSHIP & COVERAGE
  ownershipCoverage: {
    salesOwners: {
      name: 'Sales Owner(s)',
      required: false,
      type: 'array',
      description: 'Sales owner(s) responsible for the client relationship',
      source: ['Cesium', 'CMT'],
      applicableLOBs: ['GB/GM', 'PB', 'ML'],
      itemType: 'string',
      businessRule: 'Used for sales review routing and notifications'
    },
    producerId: {
      name: 'Producer ID',
      required: false,
      type: 'string',
      description: 'Financial advisor/producer identifier',
      source: ['GWIM Hub'],
      applicableLOBs: ['ML'],
      lobRestriction: 'ML only',
      businessRule: 'Links client to assigned financial advisor'
    },
    coverageTeamId: {
      name: 'Coverage Team ID',
      required: false,
      type: 'string',
      description: 'Coverage team identifier for client relationship',
      source: ['CMT'],
      applicableLOBs: ['PB'],
      lobRestriction: 'PB only',
      businessRule: 'Identifies the relationship management team'
    }
  },
  
  // DATES
  dates: {
    refreshDueDate: {
      name: 'Refresh Due Date',
      required: false,
      type: 'date',
      format: 'ISO 8601',
      description: 'Refresh due date or family anniversary date',
      source: ['Cesium', 'CMT'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      businessRule: 'Determines when 312 review is required',
      alias: 'Family Anniversary Date'
    },
    last312CompletionDate: {
      name: 'Last 312 Completion Date',
      required: false,
      type: 'date',
      format: 'ISO 8601',
      description: 'Date when last 312 review was completed',
      source: ['CAM Platform'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      businessRule: 'Tracks completion history for audit purposes'
    }
  },
  
  // FLAGS AND CODES
  flagsCodes: {
    flag312: {
      name: '312 Flag',
      required: false,
      type: 'boolean',
      description: '312 review requirement flag',
      source: ['312 Model'],
      applicableLOBs: ['GB/GM'],
      lobRestriction: 'GB/GM clients',
      businessRule: 'Triggers 312 review workflow when true',
      defaultValue: false
    },
    pvtCodeFromCRA: {
      name: 'PVT Code from CRA',
      required: false,
      type: 'string',
      description: 'Private Banking code from Client Risk Assessment',
      source: ['ORRCA'],
      applicableLOBs: ['ML', 'PB'],
      lobRestriction: 'ML/PB clients',
      businessRule: 'Used for risk classification and review requirements',
      allowedValues: ['PVT01', 'PVT02', 'PVT03', 'PVT04', 'PVT05']
    }
  },
  
  // EXPECTED ACTIVITY
  expectedActivity: {
    expectedActivityVolume: {
      name: 'Expected Activity (Volume)',
      required: true,
      type: 'object',
      description: 'Expected transaction volumes by type',
      source: ['Cesium', 'CMT', 'DDQ'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      fields: {
        electronicTransfers: {
          type: 'number',
          description: 'Expected number of electronic transfers',
          min: 0
        },
        cashChecks: {
          type: 'number',
          description: 'Expected number of cash/check transactions',
          min: 0
        },
        ddqFields: {
          type: 'object',
          description: 'Custom fields from Due Diligence Questionnaire',
          additionalProperties: true
        }
      }
    },
    expectedActivityValue: {
      name: 'Expected Activity (Value)',
      required: true,
      type: 'object',
      description: 'Expected transaction values by type',
      source: ['Cesium', 'CMT', 'DDQ'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      fields: {
        electronicTransfers: {
          type: 'number',
          description: 'Expected USD value of electronic transfers',
          min: 0
        },
        cashChecks: {
          type: 'number',
          description: 'Expected USD value of cash/check transactions',
          min: 0
        },
        ddqFields: {
          type: 'object',
          description: 'Custom value fields from DDQ',
          additionalProperties: true
        }
      }
    }
  },
  
  // GEOGRAPHIC AND PURPOSE
  geographicPurpose: {
    expectedCrossBorderActivity: {
      name: 'Expected Cross-Border Activity',
      required: false,
      type: 'string',
      description: 'Expected cross-border countries and activities',
      source: ['Cesium', 'CMT', 'DDQ'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      maxLength: 1000,
      businessRule: 'Analyzed in Question 2 of 312 review'
    },
    purposeOfRelationship: {
      name: 'Purpose of Relationship',
      required: false,
      type: 'string',
      description: 'Purpose of banking relationship',
      source: ['Cesium', 'DDQ'],
      applicableLOBs: ['GB/GM'],
      lobRestriction: 'GB/GM only',
      maxLength: 1000,
      businessRule: 'Analyzed in Question 3 of 312 review'
    },
    purposeOfAccount: {
      name: 'Purpose of Account',
      required: false,
      type: 'string',
      description: 'Purpose of account(s) - text description',
      source: ['CMT', 'DDQ'],
      applicableLOBs: ['ML', 'PB'],
      lobRestriction: 'ML/PB only',
      maxLength: 1000,
      businessRule: 'Analyzed in Question 3 of 312 review'
    },
    purposeOfAccountDetails: {
      name: 'Purpose of Account Details',
      required: false,
      type: 'array',
      description: 'Detailed account-level purpose grid',
      source: ['CMT'],
      applicableLOBs: ['ML', 'PB'],
      lobRestriction: 'ML/PB only',
      itemSchema: {
        accountNumber: 'string',
        accountName: 'string',
        sourceOfFunds: 'string'
      },
      businessRule: 'Account-level granularity for ML/PB clients'
    },
    sourceOfFunds: {
      name: 'Source of Funds',
      required: false,
      type: 'string',
      description: 'Source of funds for the account(s)',
      source: ['CMT', 'DDQ'],
      applicableLOBs: ['ML', 'PB'],
      lobRestriction: 'ML/PB only',
      maxLength: 1000,
      businessRule: 'Analyzed in Question 4 of 312 review (ML only)'
    }
  }
};

// ============================================================================
// CAM DATA ATTRIBUTES
// ============================================================================

export const CAMDataAttributes = {
  description: 'Complete attribute set for CAM (Client Account Management) workflows',
  
  // CORE IDENTIFIERS (REQUIRED)
  identifiers: {
    partyId: {
      name: 'Party ID',
      required: true,
      isPrimaryKey: true,
      type: 'string',
      description: 'Unique client identifier - Primary Key',
      source: ['Cesium', 'CMT', 'AWAREWCC', 'GWIM Hub'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI']
    }
  },
  
  // CLIENT INFORMATION
  clientInfo: {
    legalName: {
      name: 'Legal Name',
      required: true,
      type: 'string',
      description: 'Client legal entity name',
      source: ['Cesium', 'CMT', 'AWAREWCC'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      maxLength: 200
    },
    firstName: {
      name: 'First Name',
      required: false,
      type: 'string',
      description: 'Client first name',
      source: ['CMT', 'AWAREWCC'],
      applicableLOBs: ['PB', 'ML', 'Consumer'],
      maxLength: 100
    },
    middleName: {
      name: 'Middle Name',
      required: false,
      type: 'string',
      description: 'Client middle name',
      source: ['CMT', 'AWAREWCC'],
      applicableLOBs: ['PB', 'ML', 'Consumer'],
      maxLength: 100
    },
    lastName: {
      name: 'Last Name',
      required: false,
      type: 'string',
      description: 'Client last name',
      source: ['CMT', 'AWAREWCC'],
      applicableLOBs: ['PB', 'ML', 'Consumer'],
      maxLength: 100
    }
  },
  
  // LOB-SPECIFIC IDENTIFIERS
  lobSpecificIdentifiers: {
    gciNumber: {
      name: 'GCI Number',
      required: false,
      type: 'string',
      description: 'Global Client Identifier number',
      source: ['Cesium'],
      applicableLOBs: ['GB/GM', 'PB']
    },
    mpId: {
      name: 'MP ID',
      required: false,
      type: 'string',
      description: 'Merrill Portfolio ID',
      source: ['GWIM Hub'],
      applicableLOBs: ['ML']
    },
    coperId: {
      name: 'CoPer ID',
      required: false,
      type: 'string',
      description: 'Corporate Relationship ID',
      source: ['Cesium'],
      applicableLOBs: ['GB/GM']
    }
  },
  
  // LINE OF BUSINESS
  lob: {
    lob: {
      name: 'LOB',
      required: true,
      type: 'enum',
      description: 'Line of Business triggering the CAM case',
      allowedValues: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      businessRule: 'Identifies which LOB initiated the CAM review'
    },
    lobCoverage: {
      name: 'LOB(s) Coverage',
      required: false,
      type: 'array',
      description: 'LOB coverage for client across all lines of business',
      allowedValues: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      businessRule: 'Shows all LOBs where client has relationships'
    }
  },
  
  // WORKBASKET INDICATORS
  workbasketIndicators: {
    employeeIndicator: {
      name: 'Employee Indicator',
      required: true,
      type: 'boolean',
      description: 'Indicates if client is a Bank of America employee',
      source: ['PRDS'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      defaultValue: false
    },
    affiliateIndicator: {
      name: 'Affiliate Indicator',
      required: true,
      type: 'boolean',
      description: 'Indicates if client is a Bank of America affiliate',
      source: ['PRDS'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      defaultValue: false
    }
  },
  
  // OWNERSHIP & COVERAGE
  ownershipCoverage: {
    clientOwners: {
      name: 'Client Owners',
      required: false,
      type: 'array',
      description: 'Client owner(s) responsible for the relationship',
      source: ['Cesium', 'CMT'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      itemType: 'string',
      businessRule: 'Used for case assignment and notifications'
    },
    producerId: {
      name: 'Producer ID',
      required: false,
      type: 'string',
      description: 'Financial advisor/producer identifier',
      source: ['GWIM Hub'],
      applicableLOBs: ['ML'],
      lobRestriction: 'ML only'
    },
    coverageTeamIdentifier: {
      name: 'Coverage Team Identifier',
      required: false,
      type: 'string',
      description: 'Coverage team identifier for PB clients',
      source: ['CMT'],
      applicableLOBs: ['PB'],
      lobRestriction: 'PB only'
    }
  },
  
  // FLAGS
  flags: {
    mlFlag: {
      name: 'ML Flag',
      required: false,
      type: 'boolean',
      description: 'Indicates that consumer accounts cannot be seen by Financial Advisor',
      source: ['GWIM Hub'],
      applicableLOBs: ['ML', 'Consumer'],
      businessRule: 'Controls visibility of consumer accounts for ML advisors',
      defaultValue: false
    },
    excFlFlag: {
      name: 'EXC_FL Flag from WCC',
      required: false,
      type: 'boolean',
      description: 'Executive flag - filters client out of CAM population if yes/Y',
      source: ['AWAREWCC'],
      applicableLOBs: ['Consumer'],
      lobRestriction: 'Consumer only',
      businessRule: 'Any client with EXEC_FL = yes or Y will be filtered out of CAM population',
      defaultValue: false,
      filterRule: 'If true, exclude from CAM workbasket'
    }
  },
  
  // DATES
  dates: {
    refreshDueDate: {
      name: 'Refresh Due/Completion Date',
      required: false,
      type: 'date',
      format: 'ISO 8601',
      description: 'Family anniversary due date for GB/GM from Cesium; Refresh completion date for ML/PB/CI/Cons',
      source: ['Cesium', 'CMT', 'AWAREWCC', 'GWIM Hub'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      businessRule: {
        'GB/GM': 'Family anniversary due date from Cesium',
        'PB': 'Refresh completion date',
        'ML': 'Refresh completion date',
        'Consumer': 'Refresh completion date',
        'CI': 'Refresh completion date'
      }
    },
    refreshCompletionDate: {
      name: 'Refresh Completion Date',
      required: false,
      type: 'date',
      format: 'ISO 8601',
      description: 'Date when refresh was completed for ML/PB/CI/Consumer',
      source: ['CMT', 'AWAREWCC', 'GWIM Hub'],
      applicableLOBs: ['PB', 'ML', 'Consumer', 'CI'],
      businessRule: 'Tracks when client information refresh was completed'
    },
    lastCAMCompletionDate: {
      name: 'Last CAM Completion Date',
      required: false,
      type: 'date',
      format: 'ISO 8601',
      description: 'Date when last CAM review was completed',
      source: ['CAM Platform'],
      applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      businessRule: 'Tracks CAM completion history for audit purposes'
    }
  }
};

// ============================================================================
// ATTRIBUTE COMPARISON: 312 vs CAM
// ============================================================================

export const AttributeComparison = {
  sharedAttributes: [
    'partyId', 'legalName', 'firstName', 'middleName', 'lastName',
    'gciNumber', 'mpId', 'coperId', 'lob', 'lobCoverage',
    'employeeIndicator', 'affiliateIndicator', 'producerId'
  ],
  
  unique312Attributes: [
    'salesOwners', 'coverageTeamId', 'refreshDueDate', 'last312CompletionDate',
    'flag312', 'pvtCodeFromCRA', 'expectedActivityVolume', 'expectedActivityValue',
    'expectedCrossBorderActivity', 'purposeOfRelationship', 'purposeOfAccount',
    'purposeOfAccountDetails', 'sourceOfFunds'
  ],
  
  uniqueCAMAttributes: [
    'clientOwners', 'coverageTeamIdentifier', 'mlFlag', 'excFlFlag',
    'refreshCompletionDate', 'lastCAMCompletionDate'
  ],
  
  differentMeaning: {
    refreshDueDate: {
      '312': 'Refresh due date or family anniversary date',
      'CAM': 'Family anniversary due date (GB/GM) or completion date (others)'
    },
    owners: {
      '312': 'salesOwners - Sales Owner(s)',
      'CAM': 'clientOwners - Client Owner(s)'
    },
    coverageTeam: {
      '312': 'coverageTeamId - Coverage team ID',
      'CAM': 'coverageTeamIdentifier - Coverage team identifier'
    }
  }
};

// ============================================================================
// LOB-SPECIFIC ATTRIBUTE MATRIX
// ============================================================================

export const LOBAttributeMatrix = {
  'GB/GM': {
    required: ['partyId', 'legalName', 'employeeIndicator', 'affiliateIndicator'],
    optional: ['gciNumber', 'coperId', 'salesOwners', 'refreshDueDate', 'flag312', 
               'expectedActivityVolume', 'expectedActivityValue', 'purposeOfRelationship'],
    notApplicable: ['mpId', 'producerId', 'coverageTeamId', 'pvtCodeFromCRA', 
                    'purposeOfAccount', 'sourceOfFunds', 'mlFlag', 'excFlFlag']
  },
  
  'PB': {
    required: ['partyId', 'legalName', 'employeeIndicator', 'affiliateIndicator'],
    optional: ['firstName', 'lastName', 'gciNumber', 'salesOwners', 'coverageTeamId',
               'pvtCodeFromCRA', 'expectedActivityVolume', 'expectedActivityValue',
               'purposeOfAccount', 'purposeOfAccountDetails', 'sourceOfFunds'],
    notApplicable: ['mpId', 'coperId', 'producerId', 'flag312', 'purposeOfRelationship',
                    'mlFlag', 'excFlFlag']
  },
  
  'ML': {
    required: ['partyId', 'legalName', 'employeeIndicator', 'affiliateIndicator'],
    optional: ['firstName', 'lastName', 'mpId', 'producerId', 'salesOwners',
               'pvtCodeFromCRA', 'expectedActivityVolume', 'expectedActivityValue',
               'purposeOfAccount', 'purposeOfAccountDetails', 'sourceOfFunds', 'mlFlag'],
    notApplicable: ['gciNumber', 'coperId', 'coverageTeamId', 'flag312', 
                    'purposeOfRelationship', 'excFlFlag']
  },
  
  'Consumer': {
    required: ['partyId', 'legalName', 'employeeIndicator', 'affiliateIndicator'],
    optional: ['firstName', 'middleName', 'lastName', 'expectedActivityVolume',
               'expectedActivityValue', 'mlFlag', 'excFlFlag'],
    notApplicable: ['gciNumber', 'mpId', 'coperId', 'producerId', 'salesOwners',
                    'coverageTeamId', 'flag312', 'pvtCodeFromCRA', 'purposeOfRelationship',
                    'purposeOfAccount', 'sourceOfFunds']
  },
  
  'CI': {
    required: ['partyId', 'legalName', 'employeeIndicator', 'affiliateIndicator'],
    optional: ['expectedActivityVolume', 'expectedActivityValue'],
    notApplicable: ['gciNumber', 'mpId', 'coperId', 'producerId', 'salesOwners',
                    'coverageTeamId', 'flag312', 'pvtCodeFromCRA', 'purposeOfRelationship',
                    'purposeOfAccount', 'sourceOfFunds', 'mlFlag', 'excFlFlag']
  }
};

// ============================================================================
// DATA SOURCE MAPPING
// ============================================================================

export const DataSourceMapping = {
  Cesium: {
    provides: ['partyId', 'legalName', 'gciNumber', 'coperId', 'salesOwners', 
               'refreshDueDate', 'expectedActivityVolume', 'expectedActivityValue',
               'purposeOfRelationship', 'clientOwners'],
    applicableLOBs: ['GB/GM'],
    syncFrequency: 'Daily',
    priority: 'High',
    description: 'Global Banking and Global Markets client data'
  },
  
  'AWARE Datamari': {
    provides: ['expectedActivityVolume', 'expectedActivityValue', 
               'expectedCrossBorderActivity'],
    applicableLOBs: ['GB/GM'],
    syncFrequency: 'Daily',
    priority: 'High',
    description: 'GBGM 312 expected activity data'
  },
  
  'Population Manager Tool': {
    provides: ['refreshDueDate', 'dueDate'],
    applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
    syncFrequency: 'Daily',
    priority: 'High',
    description: 'DGA due dates for all lines of business'
  },
  
  CRH: {
    provides: ['partyId', 'legalName', 'firstName', 'middleName', 'lastName',
               'refreshCompletionDate'],
    applicableLOBs: ['Consumer'],
    syncFrequency: 'Daily',
    priority: 'High',
    description: 'Consumer client data (Consumer Relationship Hub)'
  },
  
  GDPP: {
    provides: ['partyId', 'legalName', 'gciNumber', 'mpId',
               'purposeOfAccount', 'sourceOfFunds', 'pvtCodeFromCRA'],
    applicableLOBs: ['PB', 'ML', 'Consumer'],
    syncFrequency: 'Daily',
    priority: 'High',
    description: 'Private Bank, Merrill Lynch, Consumer investments (Global Data Privacy Platform)'
  },
  
  'GWIM Hub': {
    provides: ['partyId', 'legalName', 'mpId', 'producerId', 'refreshCompletionDate',
               'mlFlag', 'clientOwners'],
    applicableLOBs: ['ML', 'Consumer'],
    syncFrequency: 'Daily',
    priority: 'High',
    description: 'Merrill Lynch and Consumer Investments (Global Wealth & Investment Management Hub)'
  },
  
  PRDS: {
    provides: ['employeeIndicator', 'affiliateIndicator', 'partyId'],
    applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
    syncFrequency: 'Daily',
    priority: 'Critical',
    description: 'All Lines of Business (Party Reference Data System)'
  },
  
  ORRCA: {
    provides: ['pvtCodeFromCRA', 'riskScore', 'riskLevel'],
    applicableLOBs: ['ML', 'PB'],
    syncFrequency: 'Weekly',
    priority: 'Medium',
    description: 'Risk assessment and PVT codes'
  },
  
  '312 Model': {
    provides: ['flag312', 'modelResult', 'modelResultDescription'],
    applicableLOBs: ['GB/GM'],
    syncFrequency: 'Daily',
    priority: 'High',
    description: '312 review requirement flags and model results'
  },
  
  'GFC Search Analytics': {
    provides: [],
    consumes: ['camCaseNumber', 'caseStatus', 'caseDisposition', 'completionDate'],
    applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
    syncFrequency: 'Real-time',
    priority: 'High',
    description: 'Analytics and reporting (outbound consumer)'
  },
  
  'FLU Data Sources': {
    provides: [],
    consumes: ['section312CompletionStatus', 'caseDisposition'],
    applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
    syncFrequency: 'Real-time',
    priority: 'High',
    description: 'Enable FLU refresh after 312 completion (outbound consumer)'
  },
  
  TRMS: {
    provides: ['trmsNumber', 'trmsCaseId', 'trmsCaseType'],
    consumes: ['camCaseNumber', 'caseStatus'],
    applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
    syncFrequency: 'Real-time',
    priority: 'High',
    description: 'Transaction Reporting & Management System (bidirectional)'
  },
  
  'CAM Platform': {
    provides: ['last312CompletionDate', 'lastCAMCompletionDate'],
    applicableLOBs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
    syncFrequency: 'Real-time',
    priority: 'Critical',
    notes: 'Internal system data'
  }
};

// ============================================================================
// VALIDATION RULES
// ============================================================================

export const ValidationRules = {
  partyId: {
    required: true,
    type: 'string',
    minLength: 1,
    maxLength: 50,
    pattern: '^[A-Z0-9-]+$',
    errorMessage: 'Party ID is required and must be alphanumeric'
  },
  
  legalName: {
    required: true,
    type: 'string',
    minLength: 1,
    maxLength: 200,
    errorMessage: 'Legal Name is required'
  },
  
  gciNumber: {
    pattern: '^GCI[0-9]{8,12}$',
    errorMessage: 'GCI Number must start with GCI followed by 8-12 digits'
  },
  
  mpId: {
    pattern: '^MP[0-9]{6,10}$',
    errorMessage: 'MP ID must start with MP followed by 6-10 digits'
  },
  
  coperId: {
    pattern: '^CP[0-9]{8,12}$',
    errorMessage: 'CoPer ID must start with CP followed by 8-12 digits'
  },
  
  employeeIndicator: {
    required: true,
    type: 'boolean',
    defaultValue: false
  },
  
  affiliateIndicator: {
    required: true,
    type: 'boolean',
    defaultValue: false
  },
  
  expectedActivityVolume: {
    required: true,
    type: 'object',
    properties: {
      electronicTransfers: { type: 'number', min: 0 },
      cashChecks: { type: 'number', min: 0 }
    }
  },
  
  expectedActivityValue: {
    required: true,
    type: 'object',
    properties: {
      electronicTransfers: { type: 'number', min: 0 },
      cashChecks: { type: 'number', min: 0 }
    }
  }
};

export default {
  Section312DataAttributes,
  CAMDataAttributes,
  AttributeComparison,
  LOBAttributeMatrix,
  DataSourceMapping,
  ValidationRules
};