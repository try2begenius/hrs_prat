/**
 * Notifications Schema
 * 
 * Data taxonomy, schemas, and API endpoints for notification system,
 * alerts, and user communication.
 */

// ============================================================================
// TYPE DEFINITIONS & DATA TAXONOMY
// ============================================================================

export type NotificationType = 
  | 'Case Assignment' 
  | 'Case Update' 
  | 'Case Due Soon' 
  | 'Case Overdue' 
  | 'Sales Review Required' 
  | 'System Alert' 
  | 'Integration Error' 
  | 'Report Ready' 
  | 'Mention' 
  | 'Access Request';

export type NotificationPriority = 'Low' | 'Normal' | 'High' | 'Urgent';

export type NotificationChannel = 'In-App' | 'Email' | 'SMS' | 'Push';

export type NotificationStatus = 'Unread' | 'Read' | 'Archived' | 'Dismissed';

/**
 * Notification Entity
 */
export interface Notification {
  id: string;                        // Unique notification identifier
  type: NotificationType;            // Notification classification
  priority: NotificationPriority;    // Urgency level
  status: NotificationStatus;        // Current status
  
  // Recipients
  recipientId: string;               // User ID
  recipientUsername: string;         // Username
  
  // Content
  title: string;                     // Notification title
  message: string;                   // Notification body
  shortMessage?: string;             // Brief summary for mobile/email
  
  // Metadata
  createdDate: string;               // ISO 8601 datetime
  readDate?: string;                 // ISO 8601 datetime - when read
  expiresAt?: string;                // ISO 8601 datetime - expiration
  
  // Context
  relatedResourceType?: string;      // e.g., "Case", "Report"
  relatedResourceId?: string;        // Resource identifier
  actionUrl?: string;                // Deep link to related resource
  actionLabel?: string;              // Action button text
  
  // Sender (if applicable)
  senderId?: string;                 // User ID of sender
  senderUsername?: string;           // Username of sender
  senderName?: string;               // Full name of sender
  
  // Delivery
  channels: NotificationChannel[];   // Delivery channels
  emailSent?: boolean;               // Email delivery status
  emailSentDate?: string;            // ISO 8601 datetime
  
  // Additional data
  metadata?: Record<string, any>;    // Extra context data
  groupId?: string;                  // Group related notifications
}

/**
 * Notification Preferences
 * User's notification settings
 */
export interface NotificationPreferences {
  userId: string;
  
  // Channel Preferences
  enableInApp: boolean;
  enableEmail: boolean;
  enableSMS: boolean;
  enablePush: boolean;
  
  // Type-specific Settings
  typePreferences: NotificationTypePreference[];
  
  // Timing
  quietHoursEnabled: boolean;
  quietHoursStart?: string;          // HH:mm format
  quietHoursEnd?: string;            // HH:mm format
  timezone?: string;                 // IANA timezone
  
  // Digest Settings
  enableDigest: boolean;             // Send summary digest
  digestFrequency?: 'Daily' | 'Weekly';
  digestTime?: string;               // HH:mm format
  
  // General Settings
  notifyOnMention: boolean;
  notifyOnAssignment: boolean;
  notifyOnCaseUpdate: boolean;
  notifyDueSoonDays: number;         // Days before due date to notify
  
  lastUpdated: string;               // ISO 8601 datetime
}

/**
 * Notification Type Preference
 */
export interface NotificationTypePreference {
  type: NotificationType;
  enabled: boolean;
  channels: NotificationChannel[];   // Which channels to use
  priority: NotificationPriority;    // Override priority
}

/**
 * Notification Template
 * Template for generating notifications
 */
export interface NotificationTemplate {
  id: string;
  type: NotificationType;
  name: string;
  titleTemplate: string;             // Handlebars template
  messageTemplate: string;           // Handlebars template
  defaultPriority: NotificationPriority;
  defaultChannels: NotificationChannel[];
  variables: string[];               // Required template variables
  isActive: boolean;
}

/**
 * Notification Rule
 * Automated notification trigger
 */
export interface NotificationRule {
  id: string;
  name: string;
  description: string;
  type: NotificationType;
  enabled: boolean;
  
  // Trigger Conditions
  triggerEvent: string;              // Event that triggers notification
  conditions: NotificationCondition[];
  
  // Recipient Selection
  recipientType: 'Specific' | 'Role' | 'Dynamic';
  specificRecipients?: string[];     // Usernames
  roleRecipients?: string[];         // Roles
  dynamicRecipientRule?: string;     // Expression for dynamic selection
  
  // Template and Configuration
  templateId: string;
  priority: NotificationPriority;
  channels: NotificationChannel[];
  
  // Throttling
  throttleEnabled: boolean;
  throttleMinutes?: number;          // Min time between notifications
  
  createdBy: string;
  createdDate: string;               // ISO 8601 datetime
  lastTriggered?: string;            // ISO 8601 datetime
}

/**
 * Notification Condition
 */
export interface NotificationCondition {
  field: string;                     // Field to evaluate
  operator: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'contains' | 'in';
  value: any;                        // Comparison value
}

/**
 * Notification Summary
 */
export interface NotificationSummary {
  totalUnread: number;
  totalRead: number;
  byType: Record<NotificationType, number>;
  byPriority: Record<NotificationPriority, number>;
  urgentCount: number;
  recentNotifications: Notification[];
}

/**
 * Notification Digest
 * Summary email/notification
 */
export interface NotificationDigest {
  id: string;
  userId: string;
  period: string;                    // e.g., "2025-10-26"
  generatedDate: string;             // ISO 8601 datetime
  notificationCount: number;
  sections: DigestSection[];
  sent: boolean;
  sentDate?: string;                 // ISO 8601 datetime
}

/**
 * Digest Section
 */
export interface DigestSection {
  title: string;
  notificationCount: number;
  items: Array<{
    title: string;
    message: string;
    timestamp: string;
    actionUrl?: string;
  }>;
}

/**
 * Broadcast Notification
 * System-wide announcement
 */
export interface BroadcastNotification {
  id: string;
  title: string;
  message: string;
  priority: NotificationPriority;
  channels: NotificationChannel[];
  
  // Targeting
  targetAllUsers: boolean;
  targetRoles?: string[];            // Specific roles
  targetUsers?: string[];            // Specific users
  
  // Scheduling
  scheduledDate?: string;            // ISO 8601 datetime
  expiresAt?: string;                // ISO 8601 datetime
  
  // Status
  status: 'Draft' | 'Scheduled' | 'Sent';
  sentDate?: string;                 // ISO 8601 datetime
  recipientCount?: number;
  
  createdBy: string;
  createdDate: string;               // ISO 8601 datetime
}

// ============================================================================
// NOTIFICATION TEMPLATES
// ============================================================================

export const NotificationTemplates: NotificationTemplate[] = [
  {
    id: 'TMPL-001',
    type: 'Case Assignment',
    name: 'Case Assigned',
    titleTemplate: 'Case {{caseId}} assigned to you',
    messageTemplate: 'Case {{caseId}} for {{clientName}} has been assigned to you by {{assignedBy}}. Priority: {{priority}}, Due: {{dueDate}}',
    defaultPriority: 'Normal',
    defaultChannels: ['In-App', 'Email'],
    variables: ['caseId', 'clientName', 'assignedBy', 'priority', 'dueDate'],
    isActive: true
  },
  {
    id: 'TMPL-002',
    type: 'Case Due Soon',
    name: 'Case Due Soon',
    titleTemplate: 'Case {{caseId}} due in {{daysUntilDue}} days',
    messageTemplate: 'Case {{caseId}} for {{clientName}} is due on {{dueDate}}. Please complete your review.',
    defaultPriority: 'High',
    defaultChannels: ['In-App', 'Email'],
    variables: ['caseId', 'clientName', 'dueDate', 'daysUntilDue'],
    isActive: true
  },
  {
    id: 'TMPL-003',
    type: 'Case Overdue',
    name: 'Case Overdue',
    titleTemplate: 'Case {{caseId}} is overdue',
    messageTemplate: 'Case {{caseId}} for {{clientName}} was due on {{dueDate}} and is now {{daysOverdue}} days overdue.',
    defaultPriority: 'Urgent',
    defaultChannels: ['In-App', 'Email'],
    variables: ['caseId', 'clientName', 'dueDate', 'daysOverdue'],
    isActive: true
  },
  {
    id: 'TMPL-004',
    type: 'Sales Review Required',
    name: 'Sales Review Needed',
    titleTemplate: 'Sales review required for case {{caseId}}',
    messageTemplate: 'Case {{caseId}} for {{clientName}} requires your sales owner review. Submitted by {{submittedBy}}.',
    defaultPriority: 'High',
    defaultChannels: ['In-App', 'Email'],
    variables: ['caseId', 'clientName', 'submittedBy'],
    isActive: true
  },
  {
    id: 'TMPL-005',
    type: 'Case Update',
    name: 'Case Status Update',
    titleTemplate: 'Case {{caseId}} status updated',
    messageTemplate: 'Case {{caseId}} status changed from {{oldStatus}} to {{newStatus}} by {{updatedBy}}.',
    defaultPriority: 'Normal',
    defaultChannels: ['In-App'],
    variables: ['caseId', 'oldStatus', 'newStatus', 'updatedBy'],
    isActive: true
  },
  {
    id: 'TMPL-006',
    type: 'Integration Error',
    name: 'Integration Error',
    titleTemplate: 'Integration error: {{integrationName}}',
    messageTemplate: 'Integration {{integrationName}} encountered errors during sync. {{errorCount}} records failed.',
    defaultPriority: 'Urgent',
    defaultChannels: ['In-App', 'Email'],
    variables: ['integrationName', 'errorCount'],
    isActive: true
  },
  {
    id: 'TMPL-007',
    type: 'Report Ready',
    name: 'Report Ready',
    titleTemplate: 'Report "{{reportName}}" is ready',
    messageTemplate: 'Your report "{{reportName}}" has been generated and is ready for download.',
    defaultPriority: 'Normal',
    defaultChannels: ['In-App', 'Email'],
    variables: ['reportName', 'reportId'],
    isActive: true
  }
];

// ============================================================================
// JSON SCHEMA DEFINITIONS
// ============================================================================

export const NotificationSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: ["id", "type", "priority", "status", "recipientId", "title", "message", "createdDate", "channels"],
  properties: {
    id: {
      type: "string",
      pattern: "^NOTIF-[0-9]{4,}$"
    },
    type: {
      type: "string",
      enum: [
        "Case Assignment", "Case Update", "Case Due Soon", "Case Overdue",
        "Sales Review Required", "System Alert", "Integration Error",
        "Report Ready", "Mention", "Access Request"
      ]
    },
    priority: {
      type: "string",
      enum: ["Low", "Normal", "High", "Urgent"]
    },
    status: {
      type: "string",
      enum: ["Unread", "Read", "Archived", "Dismissed"]
    },
    title: {
      type: "string",
      minLength: 1,
      maxLength: 200
    },
    message: {
      type: "string",
      minLength: 1,
      maxLength: 1000
    },
    channels: {
      type: "array",
      items: {
        type: "string",
        enum: ["In-App", "Email", "SMS", "Push"]
      },
      minItems: 1
    }
  }
};

// ============================================================================
// API ENDPOINTS SPECIFICATION
// ============================================================================

export const NotificationsAPI = {
  baseUrl: "/api/v1/notifications",
  
  endpoints: {
    /**
     * GET /api/v1/notifications
     * List notifications for current user
     */
    listNotifications: {
      method: "GET",
      path: "/",
      queryParams: {
        status: "NotificationStatus (optional) - Filter by status",
        type: "NotificationType (optional) - Filter by type",
        priority: "NotificationPriority (optional) - Filter by priority",
        unreadOnly: "boolean (optional) - Show only unread",
        startDate: "string (optional) - ISO 8601 date",
        endDate: "string (optional) - ISO 8601 date",
        page: "number (optional)",
        pageSize: "number (optional)"
      },
      response: {
        status: 200,
        body: {
          data: "Notification[]",
          total: "number",
          unreadCount: "number",
          page: "number",
          pageSize: "number"
        }
      },
      example: `
GET /api/v1/notifications?unreadOnly=true&pageSize=10

Response:
{
  "data": [
    {
      "id": "NOTIF-0001",
      "type": "Case Assignment",
      "priority": "Normal",
      "status": "Unread",
      "title": "Case CASE-2025-045 assigned to you",
      "message": "Case CASE-2025-045 for ABC Corp has been assigned...",
      "createdDate": "2025-10-26T09:00:00Z",
      "actionUrl": "/cases/CASE-2025-045",
      "actionLabel": "View Case"
    }
  ],
  "total": 15,
  "unreadCount": 15,
  "page": 1,
  "pageSize": 10
}
      `
    },

    /**
     * GET /api/v1/notifications/:id
     * Get notification by ID
     */
    getNotificationById: {
      method: "GET",
      path: "/:id",
      pathParams: {
        id: "string - Notification identifier"
      },
      response: {
        status: 200,
        body: "Notification"
      }
    },

    /**
     * GET /api/v1/notifications/summary
     * Get notification summary
     */
    getSummary: {
      method: "GET",
      path: "/summary",
      response: {
        status: 200,
        body: "NotificationSummary"
      },
      example: `
GET /api/v1/notifications/summary

Response:
{
  "totalUnread": 15,
  "totalRead": 234,
  "byType": {
    "Case Assignment": 5,
    "Case Update": 8,
    "Case Due Soon": 2
  },
  "byPriority": {
    "Normal": 10,
    "High": 3,
    "Urgent": 2
  },
  "urgentCount": 2,
  "recentNotifications": [...]
}
      `
    },

    /**
     * PUT /api/v1/notifications/:id/read
     * Mark notification as read
     */
    markAsRead: {
      method: "PUT",
      path: "/:id/read",
      pathParams: {
        id: "string - Notification identifier"
      },
      response: {
        status: 200,
        body: "Notification"
      }
    },

    /**
     * PUT /api/v1/notifications/read-all
     * Mark all notifications as read
     */
    markAllAsRead: {
      method: "PUT",
      path: "/read-all",
      requestBody: {
        type: "NotificationType (optional) - Mark specific type only",
        beforeDate: "string (optional) - ISO 8601 date"
      },
      response: {
        status: 200,
        body: {
          updatedCount: "number"
        }
      }
    },

    /**
     * DELETE /api/v1/notifications/:id
     * Delete/dismiss notification
     */
    deleteNotification: {
      method: "DELETE",
      path: "/:id",
      pathParams: {
        id: "string - Notification identifier"
      },
      response: {
        status: 204,
        body: null
      }
    },

    /**
     * PUT /api/v1/notifications/:id/archive
     * Archive notification
     */
    archiveNotification: {
      method: "PUT",
      path: "/:id/archive",
      pathParams: {
        id: "string - Notification identifier"
      },
      response: {
        status: 200,
        body: "Notification"
      }
    },

    /**
     * POST /api/v1/notifications/send
     * Send notification (admin/system use)
     */
    sendNotification: {
      method: "POST",
      path: "/send",
      requestBody: {
        recipientIds: "string[] (required) - User IDs",
        type: "NotificationType (required)",
        priority: "NotificationPriority (required)",
        title: "string (required)",
        message: "string (required)",
        channels: "NotificationChannel[] (required)",
        actionUrl: "string (optional)",
        actionLabel: "string (optional)",
        metadata: "Record<string, any> (optional)"
      },
      response: {
        status: 201,
        body: {
          notifications: "Notification[]",
          successCount: "number",
          failedCount: "number"
        }
      },
      permissions: ["Administrator"]
    },

    /**
     * GET /api/v1/notifications/preferences
     * Get user notification preferences
     */
    getPreferences: {
      method: "GET",
      path: "/preferences",
      response: {
        status: 200,
        body: "NotificationPreferences"
      }
    },

    /**
     * PUT /api/v1/notifications/preferences
     * Update notification preferences
     */
    updatePreferences: {
      method: "PUT",
      path: "/preferences",
      requestBody: "Partial<NotificationPreferences>",
      response: {
        status: 200,
        body: "NotificationPreferences"
      },
      example: `
PUT /api/v1/notifications/preferences
Content-Type: application/json

{
  "enableEmail": true,
  "enableInApp": true,
  "notifyDueSoonDays": 3,
  "quietHoursEnabled": true,
  "quietHoursStart": "22:00",
  "quietHoursEnd": "08:00"
}
      `
    },

    /**
     * GET /api/v1/notifications/templates
     * List notification templates
     */
    listTemplates: {
      method: "GET",
      path: "/templates",
      queryParams: {
        type: "NotificationType (optional)"
      },
      response: {
        status: 200,
        body: "NotificationTemplate[]"
      },
      permissions: ["Administrator"]
    },

    /**
     * POST /api/v1/notifications/broadcast
     * Send broadcast notification
     */
    sendBroadcast: {
      method: "POST",
      path: "/broadcast",
      requestBody: {
        title: "string (required)",
        message: "string (required)",
        priority: "NotificationPriority (required)",
        channels: "NotificationChannel[] (required)",
        targetAllUsers: "boolean (optional)",
        targetRoles: "string[] (optional)",
        targetUsers: "string[] (optional)",
        scheduledDate: "string (optional) - ISO 8601 datetime",
        expiresAt: "string (optional) - ISO 8601 datetime"
      },
      response: {
        status: 201,
        body: "BroadcastNotification"
      },
      permissions: ["Administrator"]
    },

    /**
     * GET /api/v1/notifications/broadcasts
     * List broadcast notifications
     */
    listBroadcasts: {
      method: "GET",
      path: "/broadcasts",
      queryParams: {
        status: "string (optional) - Draft | Scheduled | Sent"
      },
      response: {
        status: 200,
        body: "BroadcastNotification[]"
      },
      permissions: ["Administrator"]
    },

    /**
     * GET /api/v1/notifications/digest
     * Get notification digest
     */
    getDigest: {
      method: "GET",
      path: "/digest",
      queryParams: {
        period: "string (required) - Date in YYYY-MM-DD format"
      },
      response: {
        status: 200,
        body: "NotificationDigest"
      }
    },

    /**
     * GET /api/v1/notifications/rules
     * List notification rules
     */
    listRules: {
      method: "GET",
      path: "/rules",
      response: {
        status: 200,
        body: "NotificationRule[]"
      },
      permissions: ["Administrator"]
    },

    /**
     * POST /api/v1/notifications/rules
     * Create notification rule
     */
    createRule: {
      method: "POST",
      path: "/rules",
      requestBody: {
        name: "string (required)",
        description: "string (required)",
        type: "NotificationType (required)",
        triggerEvent: "string (required)",
        conditions: "NotificationCondition[] (required)",
        recipientType: "string (required)",
        templateId: "string (required)",
        priority: "NotificationPriority (required)",
        channels: "NotificationChannel[] (required)"
      },
      response: {
        status: 201,
        body: "NotificationRule"
      },
      permissions: ["Administrator"]
    },

    /**
     * PUT /api/v1/notifications/rules/:id
     * Update notification rule
     */
    updateRule: {
      method: "PUT",
      path: "/rules/:id",
      pathParams: {
        id: "string - Rule identifier"
      },
      requestBody: "Partial<NotificationRule>",
      response: {
        status: 200,
        body: "NotificationRule"
      },
      permissions: ["Administrator"]
    },

    /**
     * DELETE /api/v1/notifications/rules/:id
     * Delete notification rule
     */
    deleteRule: {
      method: "DELETE",
      path: "/rules/:id",
      pathParams: {
        id: "string - Rule identifier"
      },
      response: {
        status: 204,
        body: null
      },
      permissions: ["Administrator"]
    }
  }
};

export default {
  NotificationSchema,
  NotificationsAPI,
  NotificationTemplates
};
