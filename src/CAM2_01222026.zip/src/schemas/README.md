# Data Schemas Documentation

This folder contains comprehensive data taxonomy, schemas, and API endpoint specifications for the CAM (Client Account Management) and 312 Case Management System.

## 📁 Folder Structure

```
/src/schemas/
├── index.ts                          # Central export and aggregated documentation
├── SystemIntegrations.schema.ts      # System integrations and data sources
├── CaseManagement.schema.ts          # Case workflows, 312 & CAM
├── Dashboard.schema.ts               # Metrics, KPIs, and analytics
├── RolesEntitlements.schema.ts       # Users, roles, and permissions
├── Reports.schema.ts                 # Reporting and data export
├── Notifications.schema.ts           # Notifications and alerts
├── DataAttributes.reference.ts       # 🆕 Detailed 312 & CAM attribute reference
├── swagger.yaml                      # OpenAPI 3.0 Swagger specification
├── swagger-312-cam-schemas.yaml      # 🆕 Enhanced 312 & CAM schemas for Swagger
├── swagger-integration.ts            # Swagger UI integration utilities
├── SWAGGER_QUICKSTART.md             # Quick start guide
└── README.md                         # This file
```

## 🚀 NEW: Swagger/OpenAPI Documentation

We've added comprehensive **OpenAPI 3.0** (Swagger) documentation for all API endpoints!

### 📖 View the API Documentation

#### Option 1: Online Swagger Editor (Quickest)
1. Go to [https://editor.swagger.io/](https://editor.swagger.io/)
2. Click **File > Import File**
3. Select `/src/schemas/swagger.yaml`
4. 🎉 Interactive API docs are ready!

#### Option 2: Integrate Swagger UI in Your App
```bash
# Install dependencies
npm install swagger-ui-react swagger-ui-dist

# See swagger-integration.ts for complete setup guide
```

#### Option 3: Use Redoc (Cleaner UI)
```bash
npm install redoc
npx redoc-cli serve src/schemas/swagger.yaml --watch
```

### 🔑 Key Features of Swagger Docs

✅ **100+ API Endpoints** - All documented with examples  
✅ **Interactive Testing** - Try endpoints directly in the UI  
✅ **Authentication** - Built-in Bearer token support  
✅ **Request/Response Examples** - Real-world usage patterns  
✅ **Schema Validation** - Complete data model definitions  
✅ **Export to Postman** - One-click Postman collection import  

### 📝 What's Included in Swagger

- **6 Main API Modules:**
  - `/cases` - Case Management (17 endpoints)
  - `/dashboard` - Dashboard & Metrics (10 endpoints)
  - `/integrations` - System Integrations (8 endpoints)
  - `/rbac` - Users & Roles (10 endpoints)
  - `/reports` - Reports & Export (9 endpoints)
  - `/notifications` - Notifications (10 endpoints)

- **Complete Schemas:**
  - 50+ data models with validation
  - Enum definitions for all types
  - Reusable components
  - Error response formats

- **Authentication:**
  - Bearer token security scheme
  - Authorization examples
  - Permission requirements per endpoint

### 🧪 Testing APIs with Swagger

1. **Open Swagger UI** (see options above)
2. **Click "Authorize"** button at top
3. **Enter token:** `Bearer YOUR_TOKEN_HERE`
4. **Select any endpoint** and click "Try it out"
5. **Fill parameters** and click "Execute"
6. **View response** with status code and data

### 📦 Export to Postman

```bash
# Method 1: Direct import in Postman
# Import > Link > Paste swagger.yaml URL

# Method 2: Convert to JSON first
npm install -g swagger-cli
swagger-cli bundle src/schemas/swagger.yaml -o swagger.json
# Then import swagger.json into Postman
```

## 📚 What's Included in Each Schema File

Each schema file contains:

1. **TypeScript Type Definitions** - Complete data taxonomy with interfaces and types
2. **JSON Schema Definitions** - Validation schemas for data structures
3. **API Endpoint Specifications** - RESTful API documentation with examples
4. **Data Flow Mappings** - Integration points and data lineage
5. **Usage Examples** - Request/response examples for each endpoint

## 🔍 Quick Reference

### System Integrations (`SystemIntegrations.schema.ts`)

**Purpose:** External system integrations, data synchronization, and integration health monitoring.

**Key Entities:**
- `SystemIntegration` - Integration connection details
- `DataAttribute` - Data field metadata
- `IntegrationSyncLog` - Sync history
- `IntegrationHealthMetrics` - Health monitoring

**API Base:** `/api/v1/integrations`

**Key Endpoints:**
- `GET /integrations` - List all integrations
- `GET /integrations/:id/health` - Integration health metrics
- `POST /integrations/:id/sync` - Trigger manual sync
- `GET /integrations/cam-attributes` - CAM data flow attributes

---

### Case Management (`CaseManagement.schema.ts`)

**Purpose:** Core case management for 312 and CAM workflows, assignments, and dispositions.

**Key Entities:**
- `Case` - Main case entity with 312 and CAM data
- `Case312Data` - Section 312 review details
- `Case312Response` - 312 questionnaire responses
- `CAMCaseData` - CAM review details
- `CaseAssignment` - Case assignment tracking
- `CaseNote` - Case notes and comments
- `CaseActivity` - Audit trail

**API Base:** `/api/v1/cases`

**Key Endpoints:**
- `GET /cases` - List cases with filtering
- `POST /cases` - Create new case
- `POST /cases/:id/assign` - Assign case to user
- `POST /cases/:id/312/submit` - Submit 312 review
- `GET /cases/my-cases` - Get cases for current user

---

### Dashboard (`Dashboard.schema.ts`)

**Purpose:** Dashboard metrics, KPIs, trends, and real-time monitoring.

**Key Entities:**
- `DashboardMetrics` - High-level KPIs
- `CaseVolumeTrend` - Time series case volume
- `CompletionRateTrend` - Completion rate over time
- `UserPerformanceMetrics` - Individual user metrics
- `TeamPerformanceMetrics` - Team-level metrics
- `UpcomingDeadline` - Cases due soon

**API Base:** `/api/v1/dashboard`

**Key Endpoints:**
- `GET /dashboard/metrics` - Overall dashboard metrics
- `GET /dashboard/volume-trend` - Case volume time series
- `GET /dashboard/user-performance` - User performance data
- `GET /dashboard/upcoming-deadlines` - Cases due soon

---

### Roles & Entitlements (`RolesEntitlements.schema.ts`)

**Purpose:** Role-based access control, user management, and permissions.

**Key Entities:**
- `User` - User profile with role
- `Role` - Role definition with permissions
- `Permission` - Granular permission
- `UserAccess` - Complete user access profile
- `AuditLogEntry` - Security audit log
- `AccessRequest` - Access request workflow

**API Base:** `/api/v1/rbac`

**Roles:**
- `Analyst` - Case analysts
- `Manager` - Team managers
- `Administrator` - System administrators
- `Sales Owner` - Sales review owners
- `Read Only` - View-only access

**Key Endpoints:**
- `GET /rbac/users` - List users
- `GET /rbac/users/:id/access` - User access profile
- `POST /rbac/users/:id/role` - Assign role
- `POST /rbac/check-permission` - Check permission
- `GET /rbac/audit-logs` - Security audit logs

---

### Reports (`Reports.schema.ts`)

**Purpose:** Report generation, scheduling, templates, and data export.

**Key Entities:**
- `Report` - Report metadata and configuration
- `ReportParameters` - Report filters and settings
- `ReportSchedule` - Recurring report schedule
- `ReportTemplate` - Predefined report templates
- `CaseSummaryReportData` - Case summary data
- `PerformanceReportData` - Performance metrics
- `ComplianceReportData` - Compliance data

**API Base:** `/api/v1/reports`

**Report Types:**
- Case Summary
- Performance
- Compliance
- Audit
- Integration
- Custom

**Key Endpoints:**
- `GET /reports/templates` - List report templates
- `POST /reports` - Generate report
- `POST /reports/from-template` - Create from template
- `GET /reports/:id/download` - Download report file
- `POST /reports/export-cases` - Quick case export

---

### Notifications (`Notifications.schema.ts`)

**Purpose:** User notifications, alerts, preferences, and broadcast messaging.

**Key Entities:**
- `Notification` - Individual notification
- `NotificationPreferences` - User preferences
- `NotificationTemplate` - Notification templates
- `NotificationRule` - Automated notification rules
- `BroadcastNotification` - System-wide announcements
- `NotificationDigest` - Daily/weekly summary

**API Base:** `/api/v1/notifications`

**Notification Types:**
- Case Assignment
- Case Update
- Case Due Soon
- Case Overdue
- Sales Review Required
- System Alert
- Integration Error
- Report Ready

**Key Endpoints:**
- `GET /notifications` - List user notifications
- `GET /notifications/summary` - Notification summary
- `PUT /notifications/:id/read` - Mark as read
- `GET /notifications/preferences` - Get preferences
- `POST /notifications/broadcast` - Send broadcast

---

### 🆕 Data Attributes Reference (`DataAttributes.reference.ts`)

**Purpose:** Comprehensive 312 and CAM data attribute catalog with LOB-specific requirements.

**What's Included:**

#### **Section 312 Data Attributes (30+ attributes)**

**Core Identifiers:**
- `partyId` *(Required, Primary Key)* - Unique client identifier
- `legalName` *(Required)* - Client legal entity name
- `firstName`, `middleName`, `lastName` - Individual client names

**LOB-Specific Identifiers:**
- `gciNumber` *(PB/GB/GM only)* - Global Client Identifier
- `mpId` *(ML only)* - Merrill Portfolio ID
- `coperId` *(GM only)* - Corporate Relationship ID

**Workbasket Indicators:**
- `employeeIndicator` *(Required)* - BAC employee flag
- `affiliateIndicator` *(Required)* - BAC affiliate flag

**Ownership & Coverage:**
- `salesOwners[]` - Sales owner(s)
- `producerId` *(ML only)* - Producer/FA ID
- `coverageTeamId` *(PB only)* - Coverage team

**Flags & Codes:**
- `flag312` *(GB/GM only)* - 312 review flag
- `pvtCodeFromCRA` *(ML/PB only)* - PVT code from risk assessment

**Expected Activity:**
- `expectedActivityVolume` - Transaction volume expectations
- `expectedActivityValue` - Transaction value expectations

**Purpose & Geographic:**
- `expectedCrossBorderActivity` - Cross-border activities
- `purposeOfRelationship` *(GB/GM only)*
- `purposeOfAccount` *(ML/PB only)*
- `sourceOfFunds` *(ML/PB only)*

#### **CAM Data Attributes (25+ attributes)**

**All Core & Client Info** (same as 312)

**CAM-Specific Ownership:**
- `clientOwners[]` - Client owner(s)
- `coverageTeamIdentifier` *(PB only)*

**CAM-Specific Flags:**
- `mlFlag` - Consumer accounts visibility flag
- `excFlFlag` *(Consumer only)* - Executive flag (filters out if yes)

**CAM-Specific Dates:**
- `refreshDueDate` - Family anniversary due (GB/GM) or completion date
- `refreshCompletionDate` - Refresh completion date
- `lastCAMCompletionDate` - Last CAM completion

#### **LOB Attribute Matrix**

Detailed requirements by Line of Business:

**GB/GM:**
- Required: partyId, legalName, employeeIndicator, affiliateIndicator
- LOB-Specific: gciNumber, coperId, flag312, purposeOfRelationship

**PB:**
- Required: partyId, legalName, employeeIndicator, affiliateIndicator
- LOB-Specific: gciNumber, coverageTeamId, pvtCodeFromCRA, purposeOfAccount, sourceOfFunds

**ML:**
- Required: partyId, legalName, employeeIndicator, affiliateIndicator
- LOB-Specific: mpId, producerId, pvtCodeFromCRA, mlFlag, sourceOfFunds

**Consumer:**
- Required: partyId, legalName, employeeIndicator, affiliateIndicator
- LOB-Specific: firstName, lastName, excFlFlag

**CI:**
- Required: partyId, legalName, employeeIndicator, affiliateIndicator
- LOB-Specific: (minimal additional requirements)

#### **Data Source Mapping**

Shows which systems provide which attributes:

- **Cesium** → GB/GM, PB data (gciNumber, coperId, salesOwners, etc.)
- **CMT** → PB data (coverageTeamId, purposeOfAccount, sourceOfFunds)
- **AWAREWCC** → Consumer data (excFlFlag)
- **GWIM Hub** → ML data (mpId, producerId, mlFlag)
- **PRDS** → Employee/affiliate indicators (all LOBs)
- **ORRCA** → PVT codes (ML/PB)
- **312 Model** → 312 flags (GB/GM)

#### **Validation Rules**

Complete validation specifications:
- Pattern matching for IDs (GCI, MP, CoPer)
- Required field enforcement
- Data type validation
- Length constraints
- Enum value restrictions

**See the file for:**
- Complete attribute descriptions
- Business rules
- Source systems
- Applicable LOBs
- Validation patterns
- Default values

---

## 🚀 Usage

### Importing Schemas

```typescript
// Import all schemas
import * from '@/schemas';

// Import specific schema
import { CaseSchema, CaseManagementAPI } from '@/schemas/CaseManagement.schema';

// Import types
import type { Case, User, SystemIntegration } from '@/schemas';
```

### Validating Data

```typescript
import Ajv from 'ajv';
import { CaseSchema } from '@/schemas/CaseManagement.schema';

const ajv = new Ajv();
const validate = ajv.compile(CaseSchema);

const isValid = validate(caseData);
if (!isValid) {
  console.error(validate.errors);
}
```

### API Documentation Reference

```typescript
import { CaseManagementAPI } from '@/schemas/CaseManagement.schema';

// View endpoint specification
console.log(CaseManagementAPI.endpoints.listCases);
// Shows: method, path, queryParams, response, example
```

## 🔗 Data Relationships

### Key Entity Relationships

```
User
├── has one Role
├── has many assigned Cases
└── has many Notifications

Case
├── belongs to one User (assignedTo)
├── belongs to one User (salesOwner - optional)
├── has one Case312Data (if section312Required)
├── has one CAMCaseData (if camRequired)
├── has many CaseNotes
└── has many CaseActivities

SystemIntegration
├── has many DataAttributes
├── has many IntegrationSyncLogs
└── has one IntegrationHealthMetrics

Report
├── belongs to one User (createdBy)
├── uses one ReportTemplate (optional)
└── has one ReportSchedule (if recurring)

Role
└── has many Permissions
```

### Data Flow

**Inbound to CAM System:**
```
External Systems → SystemIntegration → Case Creation
  - Cesium (GB/GM client data)
  - CMT (PB client data)
  - ORRCA (Risk ratings)
  - 312 Model (312 flags)
```

**Outbound from CAM System:**
```
Case Completion → External Consumers
  - FLU Data Sources (312 completion enables refresh)
  - GFC Search Analytics (case status and disposition)
  - 312 Model (completion status updates)
```

## 📖 API Standards

### Authentication

All API endpoints require authentication via Bearer token:

```http
Authorization: Bearer <your-token>
```

### Common Response Format

```json
{
  "data": [...],
  "total": 100,
  "page": 1,
  "pageSize": 20
}
```

### Error Response Format

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request parameters",
    "details": [
      {
        "field": "priority",
        "message": "Must be one of: Low, Medium, High, Urgent"
      }
    ]
  }
}
```

### Pagination

All list endpoints support pagination:

```http
GET /api/v1/cases?page=2&pageSize=50
```

### Filtering

Common filter patterns:

```http
GET /api/v1/cases?status=In Progress&priority=High
GET /api/v1/cases?startDate=2025-10-01&endDate=2025-10-31
GET /api/v1/cases?search=ABC Corp
```

### Sorting

```http
GET /api/v1/cases?sortBy=dueDate&sortOrder=asc
```

## 🔐 Permissions

Each API endpoint specifies required permissions. See `RolesEntitlements.schema.ts` for complete permission definitions.

**Common Permissions:**
- `cases.view` - View own cases
- `cases.view.all` - View all cases
- `cases.create` - Create cases
- `cases.edit` - Edit own cases
- `cases.assign` - Assign cases to users
- `users.view` - View users
- `users.roles` - Manage user roles
- `reports.export` - Export report data
- `system.audit` - View audit logs

## 📊 Rate Limiting

API requests are rate-limited:

- **Default:** 1000 requests per hour per user
- **Burst:** 100 requests per minute
- **Export endpoints:** 10 requests per hour

Rate limit headers in responses:
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 842
X-RateLimit-Reset: 1635187200
```

## 🧪 Testing

Use these schemas for:

1. **API Integration Testing** - Validate API responses
2. **Mock Data Generation** - Generate test data
3. **Type Safety** - TypeScript compile-time checks
4. **Documentation** - Reference for developers

## 📝 Version History

- **v1.0.0** (2025-10-26) - Initial schema documentation
  - SystemIntegrations schema
  - CaseManagement schema
  - Dashboard schema
  - RolesEntitlements schema
  - Reports schema
  - Notifications schema

## 🤝 Contributing

When adding new schemas:

1. Follow the existing structure and format
2. Include TypeScript types, JSON schemas, and API specs
3. Add usage examples for all endpoints
4. Document data relationships
5. Update this README with new schema information

## 📞 Support

For questions or issues with schemas:
- Review the specific schema file for detailed documentation
- Check API examples in each endpoint specification
- Refer to type definitions for data structure details

---

**Last Updated:** October 26, 2025  
**Schema Version:** 1.0.0  
**API Version:** v1