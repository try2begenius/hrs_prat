/**
 * Reports Schema
 * 
 * Data taxonomy, schemas, and API endpoints for reporting,
 * analytics, and data export functionality.
 */

// ============================================================================
// TYPE DEFINITIONS & DATA TAXONOMY
// ============================================================================

export type ReportType = 
  | 'Case Summary' 
  | 'Performance' 
  | 'Compliance' 
  | 'Audit' 
  | 'Integration' 
  | 'Custom';

export type ReportFormat = 'PDF' | 'Excel' | 'CSV' | 'JSON';

export type ReportStatus = 'Draft' | 'Scheduled' | 'Processing' | 'Completed' | 'Failed';

export type ReportFrequency = 'Once' | 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly';

/**
 * Report Entity
 */
export interface Report {
  id: string;                        // Unique report identifier
  name: string;                      // Report name/title
  type: ReportType;                  // Report classification
  description?: string;              // Report description
  status: ReportStatus;              // Current status
  createdBy: string;                 // Creator username
  createdByName: string;             // Creator full name
  createdDate: string;               // ISO 8601 datetime
  generatedDate?: string;            // ISO 8601 datetime - when generated
  format: ReportFormat;              // Output format
  
  // Report Configuration
  parameters: ReportParameters;      // Report parameters
  schedule?: ReportSchedule;         // Schedule config if recurring
  
  // Output
  fileUrl?: string;                  // Download URL
  fileSize?: number;                 // File size in bytes
  expiresAt?: string;                // ISO 8601 datetime - URL expiration
  
  // Metadata
  rowCount?: number;                 // Number of records
  executionTime?: number;            // Generation time in seconds
  tags?: string[];                   // Categorization tags
  isPublic: boolean;                 // Accessible to all users
  sharedWith?: string[];             // Specific users with access
}

/**
 * Report Parameters
 * Configuration and filters for report generation
 */
export interface ReportParameters {
  // Date Range
  startDate?: string;                // ISO 8601 date
  endDate?: string;                  // ISO 8601 date
  dateField?: string;                // Field to filter on (e.g., "createdDate")
  
  // Filters
  status?: string[];                 // Case statuses
  priority?: string[];               // Priorities
  caseType?: string[];               // Case types
  lineOfBusiness?: string[];         // LOBs
  assignedTo?: string[];             // Assigned users
  riskLevel?: string[];              // Risk levels
  
  // Grouping and Sorting
  groupBy?: string[];                // Group by fields
  sortBy?: string;                   // Sort field
  sortOrder?: 'asc' | 'desc';        // Sort direction
  
  // Aggregations
  includeMetrics?: boolean;          // Include summary metrics
  includeCharts?: boolean;           // Include visualizations
  includeTrends?: boolean;           // Include trend analysis
  
  // Data Selection
  fields?: string[];                 // Specific fields to include
  maxRows?: number;                  // Row limit
  
  // Custom Filters
  customFilters?: Record<string, any>; // Additional custom filters
}

/**
 * Report Schedule
 * Configuration for recurring reports
 */
export interface ReportSchedule {
  id: string;
  frequency: ReportFrequency;
  dayOfWeek?: number;                // 0-6 for weekly reports
  dayOfMonth?: number;               // 1-31 for monthly reports
  time?: string;                     // HH:mm format
  timezone?: string;                 // IANA timezone
  recipients: string[];              // Email recipients
  enabled: boolean;
  nextRunDate?: string;              // ISO 8601 datetime
  lastRunDate?: string;              // ISO 8601 datetime
}

/**
 * Report Template
 * Predefined report configuration
 */
export interface ReportTemplate {
  id: string;
  name: string;
  type: ReportType;
  description: string;
  defaultParameters: ReportParameters;
  requiredParameters?: string[];     // Parameters that must be provided
  availableFormats: ReportFormat[];
  category: string;
  icon?: string;
  isCustom: boolean;                 // User-created template
  createdBy?: string;
}

/**
 * Case Summary Report Data
 */
export interface CaseSummaryReportData {
  summary: {
    totalCases: number;
    completedCases: number;
    activeCases: number;
    averageResolutionTime: number;
    completionRate: number;
  };
  byStatus: Array<{
    status: string;
    count: number;
    percentage: number;
  }>;
  byPriority: Array<{
    priority: string;
    count: number;
    percentage: number;
  }>;
  byType: Array<{
    caseType: string;
    count: number;
    percentage: number;
  }>;
  cases: Array<{
    id: string;
    clientName: string;
    status: string;
    priority: string;
    assignedTo: string;
    createdDate: string;
    completedDate?: string;
    resolutionTime?: number;
  }>;
}

/**
 * Performance Report Data
 */
export interface PerformanceReportData {
  summary: {
    totalAnalysts: number;
    totalCasesAssigned: number;
    totalCasesCompleted: number;
    teamCompletionRate: number;
    teamAverageResolutionTime: number;
  };
  analystPerformance: Array<{
    username: string;
    fullName: string;
    casesAssigned: number;
    casesCompleted: number;
    completionRate: number;
    averageResolutionTime: number;
    overdueCases: number;
    qualityScore?: number;
  }>;
  trends: {
    volumeTrend: Array<{
      date: string;
      assigned: number;
      completed: number;
    }>;
    completionRateTrend: Array<{
      date: string;
      rate: number;
    }>;
  };
}

/**
 * Compliance Report Data
 */
export interface ComplianceReportData {
  summary: {
    totalCases: number;
    section312Cases: number;
    camCases: number;
    complianceRate: number;           // Percentage
    averageTimeToCompletion: number;  // Days
  };
  dispositions: Array<{
    disposition: string;
    count: number;
    percentage: number;
  }>;
  trmsFilings: {
    total: number;
    byMonth: Array<{
      month: string;
      count: number;
    }>;
  };
  sarFilings: {
    total: number;
    byMonth: Array<{
      month: string;
      count: number;
    }>;
  };
  riskDistribution: Array<{
    riskLevel: string;
    count: number;
    percentage: number;
  }>;
}

/**
 * Audit Report Data
 */
export interface AuditReportData {
  summary: {
    totalEvents: number;
    uniqueUsers: number;
    successfulActions: number;
    deniedActions: number;
    errorActions: number;
  };
  byAction: Array<{
    action: string;
    count: number;
    percentage: number;
  }>;
  byUser: Array<{
    username: string;
    fullName: string;
    actionCount: number;
    successRate: number;
  }>;
  events: Array<{
    timestamp: string;
    username: string;
    action: string;
    resourceType: string;
    resourceId: string;
    result: string;
    ipAddress?: string;
  }>;
}

/**
 * Report Export Job
 * Tracks report generation progress
 */
export interface ReportExportJob {
  id: string;
  reportId: string;
  status: 'Queued' | 'Processing' | 'Completed' | 'Failed';
  progress: number;                  // 0-100
  startTime: string;                 // ISO 8601 datetime
  endTime?: string;                  // ISO 8601 datetime
  error?: string;                    // Error message if failed
  downloadUrl?: string;              // URL when completed
  expiresAt?: string;                // ISO 8601 datetime
}

// ============================================================================
// REPORT TEMPLATES CATALOG
// ============================================================================

export const ReportTemplates: ReportTemplate[] = [
  {
    id: 'TPL-001',
    name: 'Daily Case Summary',
    type: 'Case Summary',
    description: 'Daily summary of case volume and status',
    defaultParameters: {
      dateField: 'createdDate',
      includeMetrics: true,
      includeCharts: true
    },
    requiredParameters: ['startDate', 'endDate'],
    availableFormats: ['PDF', 'Excel', 'CSV'],
    category: 'Operations',
    isCustom: false
  },
  {
    id: 'TPL-002',
    name: 'Analyst Performance',
    type: 'Performance',
    description: 'Individual and team performance metrics',
    defaultParameters: {
      includeMetrics: true,
      includeTrends: true,
      groupBy: ['assignedTo']
    },
    requiredParameters: ['startDate', 'endDate'],
    availableFormats: ['PDF', 'Excel'],
    category: 'Management',
    isCustom: false
  },
  {
    id: 'TPL-003',
    name: 'Compliance Dashboard',
    type: 'Compliance',
    description: 'Regulatory compliance and disposition summary',
    defaultParameters: {
      includeMetrics: true,
      includeCharts: true
    },
    requiredParameters: ['startDate', 'endDate'],
    availableFormats: ['PDF', 'Excel'],
    category: 'Compliance',
    isCustom: false
  },
  {
    id: 'TPL-004',
    name: 'Overdue Cases',
    type: 'Case Summary',
    description: 'Cases past due date',
    defaultParameters: {
      status: ['In Progress', 'Pending Sales Review'],
      sortBy: 'dueDate',
      sortOrder: 'asc'
    },
    availableFormats: ['Excel', 'CSV'],
    category: 'Operations',
    isCustom: false
  },
  {
    id: 'TPL-005',
    name: 'High Risk Cases',
    type: 'Case Summary',
    description: 'Cases with high or critical risk scores',
    defaultParameters: {
      riskLevel: ['High', 'Critical'],
      sortBy: 'riskScore',
      sortOrder: 'desc',
      includeMetrics: true
    },
    availableFormats: ['PDF', 'Excel'],
    category: 'Risk',
    isCustom: false
  },
  {
    id: 'TPL-006',
    name: 'Audit Log',
    type: 'Audit',
    description: 'User activity and system audit trail',
    defaultParameters: {
      sortBy: 'timestamp',
      sortOrder: 'desc'
    },
    requiredParameters: ['startDate', 'endDate'],
    availableFormats: ['Excel', 'CSV'],
    category: 'Security',
    isCustom: false
  },
  {
    id: 'TPL-007',
    name: 'Integration Status',
    type: 'Integration',
    description: 'System integration health and sync status',
    defaultParameters: {
      includeMetrics: true
    },
    availableFormats: ['PDF', 'Excel'],
    category: 'Technical',
    isCustom: false
  }
];

// ============================================================================
// JSON SCHEMA DEFINITIONS
// ============================================================================

export const ReportSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: ["id", "name", "type", "status", "createdBy", "createdDate", "format", "parameters", "isPublic"],
  properties: {
    id: {
      type: "string",
      pattern: "^RPT-[0-9]{4,}$"
    },
    name: {
      type: "string",
      minLength: 1,
      maxLength: 200
    },
    type: {
      type: "string",
      enum: ["Case Summary", "Performance", "Compliance", "Audit", "Integration", "Custom"]
    },
    status: {
      type: "string",
      enum: ["Draft", "Scheduled", "Processing", "Completed", "Failed"]
    },
    format: {
      type: "string",
      enum: ["PDF", "Excel", "CSV", "JSON"]
    },
    isPublic: {
      type: "boolean"
    }
  }
};

// ============================================================================
// API ENDPOINTS SPECIFICATION
// ============================================================================

export const ReportsAPI = {
  baseUrl: "/api/v1/reports",
  
  endpoints: {
    /**
     * GET /api/v1/reports
     * List reports
     */
    listReports: {
      method: "GET",
      path: "/",
      queryParams: {
        type: "ReportType (optional) - Filter by type",
        status: "ReportStatus (optional) - Filter by status",
        createdBy: "string (optional) - Filter by creator",
        startDate: "string (optional) - Created after date",
        endDate: "string (optional) - Created before date",
        page: "number (optional)",
        pageSize: "number (optional)"
      },
      response: {
        status: 200,
        body: {
          data: "Report[]",
          total: "number",
          page: "number",
          pageSize: "number"
        }
      },
      permissions: ["reports.view"],
      example: `
GET /api/v1/reports?type=Case Summary&status=Completed

Response:
{
  "data": [
    {
      "id": "RPT-0001",
      "name": "Daily Case Summary - Oct 26",
      "type": "Case Summary",
      "status": "Completed",
      "createdBy": "jdoe",
      "createdDate": "2025-10-26T09:00:00Z",
      "generatedDate": "2025-10-26T09:05:23Z",
      "format": "PDF",
      "fileUrl": "https://...",
      "fileSize": 524288,
      "expiresAt": "2025-11-26T09:05:23Z"
    }
  ],
  "total": 45,
  "page": 1,
  "pageSize": 20
}
      `
    },

    /**
     * GET /api/v1/reports/:id
     * Get report by ID
     */
    getReportById: {
      method: "GET",
      path: "/:id",
      pathParams: {
        id: "string - Report identifier"
      },
      response: {
        status: 200,
        body: "Report"
      },
      permissions: ["reports.view"]
    },

    /**
     * POST /api/v1/reports
     * Create and generate report
     */
    createReport: {
      method: "POST",
      path: "/",
      requestBody: {
        name: "string (required)",
        type: "ReportType (required)",
        description: "string (optional)",
        format: "ReportFormat (required)",
        parameters: "ReportParameters (required)",
        schedule: "ReportSchedule (optional)",
        isPublic: "boolean (optional, default: false)",
        sharedWith: "string[] (optional)"
      },
      response: {
        status: 201,
        body: {
          report: "Report",
          exportJob: "ReportExportJob"
        }
      },
      permissions: ["reports.create"],
      example: `
POST /api/v1/reports
Content-Type: application/json

{
  "name": "Weekly Performance Report",
  "type": "Performance",
  "format": "Excel",
  "parameters": {
    "startDate": "2025-10-20",
    "endDate": "2025-10-26",
    "includeMetrics": true,
    "includeTrends": true
  },
  "isPublic": false
}

Response: 201 Created
{
  "report": {
    "id": "RPT-0045",
    "status": "Processing",
    ...
  },
  "exportJob": {
    "id": "JOB-12345",
    "status": "Queued",
    "progress": 0
  }
}
      `
    },

    /**
     * GET /api/v1/reports/templates
     * List report templates
     */
    listTemplates: {
      method: "GET",
      path: "/templates",
      queryParams: {
        type: "ReportType (optional) - Filter by type",
        category: "string (optional) - Filter by category"
      },
      response: {
        status: 200,
        body: "ReportTemplate[]"
      },
      example: `
GET /api/v1/reports/templates?category=Operations

Response:
[
  {
    "id": "TPL-001",
    "name": "Daily Case Summary",
    "type": "Case Summary",
    "description": "Daily summary of case volume and status",
    "defaultParameters": {...},
    "availableFormats": ["PDF", "Excel", "CSV"],
    "category": "Operations"
  }
]
      `
    },

    /**
     * POST /api/v1/reports/from-template
     * Create report from template
     */
    createFromTemplate: {
      method: "POST",
      path: "/from-template",
      requestBody: {
        templateId: "string (required)",
        name: "string (required)",
        format: "ReportFormat (required)",
        parameters: "Partial<ReportParameters> (optional) - Override defaults",
        schedule: "ReportSchedule (optional)"
      },
      response: {
        status: 201,
        body: {
          report: "Report",
          exportJob: "ReportExportJob"
        }
      },
      permissions: ["reports.create"]
    },

    /**
     * GET /api/v1/reports/:id/download
     * Download report file
     */
    downloadReport: {
      method: "GET",
      path: "/:id/download",
      pathParams: {
        id: "string - Report identifier"
      },
      response: {
        status: 200,
        contentType: "application/octet-stream",
        body: "Binary file data"
      },
      permissions: ["reports.view"]
    },

    /**
     * GET /api/v1/reports/:id/data
     * Get report data (JSON format)
     */
    getReportData: {
      method: "GET",
      path: "/:id/data",
      pathParams: {
        id: "string - Report identifier"
      },
      response: {
        status: 200,
        body: "CaseSummaryReportData | PerformanceReportData | ComplianceReportData | AuditReportData"
      },
      permissions: ["reports.view"]
    },

    /**
     * GET /api/v1/reports/jobs/:jobId
     * Get export job status
     */
    getExportJobStatus: {
      method: "GET",
      path: "/jobs/:jobId",
      pathParams: {
        jobId: "string - Export job identifier"
      },
      response: {
        status: 200,
        body: "ReportExportJob"
      },
      example: `
GET /api/v1/reports/jobs/JOB-12345

Response:
{
  "id": "JOB-12345",
  "reportId": "RPT-0045",
  "status": "Processing",
  "progress": 65,
  "startTime": "2025-10-26T09:00:00Z"
}
      `
    },

    /**
     * DELETE /api/v1/reports/:id
     * Delete report
     */
    deleteReport: {
      method: "DELETE",
      path: "/:id",
      pathParams: {
        id: "string - Report identifier"
      },
      response: {
        status: 204,
        body: null
      },
      permissions: ["reports.create"]
    },

    /**
     * GET /api/v1/reports/schedules
     * List scheduled reports
     */
    listSchedules: {
      method: "GET",
      path: "/schedules",
      queryParams: {
        enabled: "boolean (optional) - Filter by enabled status"
      },
      response: {
        status: 200,
        body: "Array<Report & { schedule: ReportSchedule }>"
      },
      permissions: ["reports.view"]
    },

    /**
     * PUT /api/v1/reports/:id/schedule
     * Update report schedule
     */
    updateSchedule: {
      method: "PUT",
      path: "/:id/schedule",
      pathParams: {
        id: "string - Report identifier"
      },
      requestBody: "Partial<ReportSchedule>",
      response: {
        status: 200,
        body: "ReportSchedule"
      },
      permissions: ["reports.create"]
    },

    /**
     * POST /api/v1/reports/:id/share
     * Share report with users
     */
    shareReport: {
      method: "POST",
      path: "/:id/share",
      pathParams: {
        id: "string - Report identifier"
      },
      requestBody: {
        usernames: "string[] (required)",
        message: "string (optional)"
      },
      response: {
        status: 200,
        body: {
          success: "boolean",
          sharedWith: "string[]"
        }
      },
      permissions: ["reports.view"]
    },

    /**
     * POST /api/v1/reports/export-cases
     * Quick export cases to file
     */
    exportCases: {
      method: "POST",
      path: "/export-cases",
      requestBody: {
        caseIds: "string[] (optional) - Specific cases to export",
        format: "ReportFormat (required)",
        filters: "Partial<ReportParameters> (optional)"
      },
      response: {
        status: 202,
        body: "ReportExportJob"
      },
      permissions: ["data.export"]
    }
  }
};

export default {
  ReportSchema,
  ReportsAPI,
  ReportTemplates
};
