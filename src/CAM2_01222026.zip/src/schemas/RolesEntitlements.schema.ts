/**
 * Roles and Entitlements Schema
 * 
 * Data taxonomy, schemas, and API endpoints for user roles, permissions,
 * and access control within the CAM system.
 */

// ============================================================================
// TYPE DEFINITIONS & DATA TAXONOMY
// ============================================================================

export type UserRole = 
  | 'Analyst' 
  | 'Manager' 
  | 'Administrator' 
  | 'Sales Owner' 
  | 'Read Only';

export type PermissionScope = 'own' | 'team' | 'all';

/**
 * User Entity
 */
export interface User {
  id: string;                        // Unique user identifier
  username: string;                  // Login username
  email: string;                     // Email address
  fullName: string;                  // Full display name
  role: UserRole;                    // Primary role
  lineOfBusiness?: string[];         // LOB access
  department?: string;               // Department/team
  manager?: string;                  // Manager username
  active: boolean;                   // Active status
  createdDate: string;               // ISO 8601 datetime
  lastLogin?: string;                // ISO 8601 datetime
  avatar?: string;                   // Avatar URL
  
  // Special Entitlements
  hasM_I_Entitlement?: boolean;      // M&I (Monitoring & Investigations) for defect remediation
  canReassignCases?: boolean;        // Can reassign cases to others
  canBulkAssign?: boolean;           // Can bulk assign cases
  canExportData?: boolean;           // Can export sensitive data
  canManageUsers?: boolean;          // Can manage user accounts
  canViewAllCases?: boolean;         // Can view cases outside assignment
  canEditIntegrations?: boolean;     // Can modify integration settings
}

/**
 * Permission Entity
 * Granular permission definition
 */
export interface Permission {
  id: string;                        // Permission identifier
  name: string;                      // Permission name
  code: string;                      // Permission code (e.g., "cases.create")
  description: string;               // Permission description
  category: PermissionCategory;      // Permission grouping
  scope: PermissionScope;            // Access scope
  requiresApproval?: boolean;        // Requires manager approval
}

export type PermissionCategory = 
  | 'Cases' 
  | 'Users' 
  | 'Reports' 
  | 'Integrations' 
  | 'System' 
  | 'Data';

/**
 * Role Definition
 * Complete role with associated permissions
 */
export interface Role {
  id: string;                        // Role identifier
  name: UserRole;                    // Role name
  displayName: string;               // Human-readable name
  description: string;               // Role description
  permissions: Permission[];         // Associated permissions
  isSystemRole: boolean;             // Cannot be deleted
  createdDate: string;               // ISO 8601 datetime
  modifiedDate?: string;             // ISO 8601 datetime
}

/**
 * User Access Summary
 * Complete access profile for a user
 */
export interface UserAccess {
  user: User;
  role: Role;
  effectivePermissions: Permission[];
  accessRestrictions?: AccessRestriction[];
  lastAccessReview?: string;         // ISO 8601 datetime
}

/**
 * Access Restriction
 * Specific access limitations
 */
export interface AccessRestriction {
  id: string;
  type: string;                      // e.g., "LOB", "Geography", "DataClass"
  restriction: string;               // Restriction value
  reason?: string;                   // Restriction reason
  expiresAt?: string;                // ISO 8601 datetime
}

/**
 * Permission Check Request
 */
export interface PermissionCheckRequest {
  userId: string;
  permissionCode: string;            // e.g., "cases.create"
  resourceId?: string;               // Optional resource identifier
  context?: Record<string, any>;     // Additional context
}

/**
 * Permission Check Result
 */
export interface PermissionCheckResult {
  allowed: boolean;
  reason?: string;                   // Explanation if denied
  scope?: PermissionScope;           // Effective scope
  conditions?: string[];             // Any conditions that apply
}

/**
 * Audit Log Entry
 */
export interface AuditLogEntry {
  id: string;
  timestamp: string;                 // ISO 8601 datetime
  userId: string;
  username: string;
  action: string;                    // Action performed
  resourceType: string;              // Resource type affected
  resourceId: string;                // Resource identifier
  result: 'Success' | 'Denied' | 'Error';
  ipAddress?: string;
  userAgent?: string;
  details?: Record<string, any>;
}

/**
 * Role Assignment History
 */
export interface RoleAssignmentHistory {
  id: string;
  userId: string;
  previousRole?: UserRole;
  newRole: UserRole;
  assignedBy: string;
  assignedDate: string;              // ISO 8601 datetime
  reason?: string;
  effectiveDate?: string;            // ISO 8601 datetime
  expirationDate?: string;           // ISO 8601 datetime
}

/**
 * Access Request
 */
export interface AccessRequest {
  id: string;
  requestedBy: string;               // Username
  requestedByName: string;           // Full name
  requestType: 'Role' | 'Permission' | 'Resource';
  requestedAccess: string;           // What is being requested
  businessJustification: string;     // Justification
  status: 'Pending' | 'Approved' | 'Denied' | 'Expired';
  requestDate: string;               // ISO 8601 datetime
  reviewedBy?: string;               // Reviewer username
  reviewedDate?: string;             // ISO 8601 datetime
  reviewComments?: string;
  expiresAt?: string;                // ISO 8601 datetime
}

// ============================================================================
// PERMISSION DEFINITIONS
// ============================================================================

export const PermissionDefinitions: Record<string, Permission> = {
  // Case Permissions
  'cases.view': {
    id: 'PERM-001',
    name: 'View Cases',
    code: 'cases.view',
    description: 'View case details',
    category: 'Cases',
    scope: 'own'
  },
  'cases.view.all': {
    id: 'PERM-002',
    name: 'View All Cases',
    code: 'cases.view.all',
    description: 'View all cases in the system',
    category: 'Cases',
    scope: 'all'
  },
  'cases.create': {
    id: 'PERM-003',
    name: 'Create Cases',
    code: 'cases.create',
    description: 'Create new cases',
    category: 'Cases',
    scope: 'all'
  },
  'cases.edit': {
    id: 'PERM-004',
    name: 'Edit Cases',
    code: 'cases.edit',
    description: 'Edit case details',
    category: 'Cases',
    scope: 'own'
  },
  'cases.edit.all': {
    id: 'PERM-005',
    name: 'Edit All Cases',
    code: 'cases.edit.all',
    description: 'Edit any case in the system',
    category: 'Cases',
    scope: 'all'
  },
  'cases.delete': {
    id: 'PERM-006',
    name: 'Delete Cases',
    code: 'cases.delete',
    description: 'Delete cases',
    category: 'Cases',
    scope: 'all',
    requiresApproval: true
  },
  'cases.assign': {
    id: 'PERM-007',
    name: 'Assign Cases',
    code: 'cases.assign',
    description: 'Assign cases to users',
    category: 'Cases',
    scope: 'team'
  },
  'cases.close': {
    id: 'PERM-008',
    name: 'Close Cases',
    code: 'cases.close',
    description: 'Close and complete cases',
    category: 'Cases',
    scope: 'own'
  },
  'cases.reopen': {
    id: 'PERM-009',
    name: 'Reopen Cases',
    code: 'cases.reopen',
    description: 'Reopen closed cases',
    category: 'Cases',
    scope: 'team',
    requiresApproval: true
  },
  
  // Sales Review Permissions
  'sales.review': {
    id: 'PERM-010',
    name: 'Sales Review',
    code: 'sales.review',
    description: 'Perform sales owner reviews',
    category: 'Cases',
    scope: 'own'
  },
  'sales.approve': {
    id: 'PERM-011',
    name: 'Sales Approval',
    code: 'sales.approve',
    description: 'Approve sales review decisions',
    category: 'Cases',
    scope: 'own'
  },
  
  // User Management Permissions
  'users.view': {
    id: 'PERM-020',
    name: 'View Users',
    code: 'users.view',
    description: 'View user profiles',
    category: 'Users',
    scope: 'all'
  },
  'users.create': {
    id: 'PERM-021',
    name: 'Create Users',
    code: 'users.create',
    description: 'Create new user accounts',
    category: 'Users',
    scope: 'all'
  },
  'users.edit': {
    id: 'PERM-022',
    name: 'Edit Users',
    code: 'users.edit',
    description: 'Edit user profiles',
    category: 'Users',
    scope: 'all'
  },
  'users.delete': {
    id: 'PERM-023',
    name: 'Delete Users',
    code: 'users.delete',
    description: 'Delete user accounts',
    category: 'Users',
    scope: 'all',
    requiresApproval: true
  },
  'users.roles': {
    id: 'PERM-024',
    name: 'Manage Roles',
    code: 'users.roles',
    description: 'Assign and modify user roles',
    category: 'Users',
    scope: 'all'
  },
  
  // Reports Permissions
  'reports.view': {
    id: 'PERM-030',
    name: 'View Reports',
    code: 'reports.view',
    description: 'View reports',
    category: 'Reports',
    scope: 'own'
  },
  'reports.view.all': {
    id: 'PERM-031',
    name: 'View All Reports',
    code: 'reports.view.all',
    description: 'View all system reports',
    category: 'Reports',
    scope: 'all'
  },
  'reports.create': {
    id: 'PERM-032',
    name: 'Create Reports',
    code: 'reports.create',
    description: 'Create custom reports',
    category: 'Reports',
    scope: 'all'
  },
  'reports.export': {
    id: 'PERM-033',
    name: 'Export Reports',
    code: 'reports.export',
    description: 'Export report data',
    category: 'Reports',
    scope: 'own'
  },
  
  // Data Export Permissions
  'data.export': {
    id: 'PERM-040',
    name: 'Export Data',
    code: 'data.export',
    description: 'Export case and client data',
    category: 'Data',
    scope: 'own',
    requiresApproval: true
  },
  'data.export.sensitive': {
    id: 'PERM-041',
    name: 'Export Sensitive Data',
    code: 'data.export.sensitive',
    description: 'Export PII and sensitive data',
    category: 'Data',
    scope: 'all',
    requiresApproval: true
  },
  
  // Integration Permissions
  'integrations.view': {
    id: 'PERM-050',
    name: 'View Integrations',
    code: 'integrations.view',
    description: 'View integration status',
    category: 'Integrations',
    scope: 'all'
  },
  'integrations.manage': {
    id: 'PERM-051',
    name: 'Manage Integrations',
    code: 'integrations.manage',
    description: 'Configure and manage integrations',
    category: 'Integrations',
    scope: 'all'
  },
  'integrations.sync': {
    id: 'PERM-052',
    name: 'Trigger Sync',
    code: 'integrations.sync',
    description: 'Manually trigger data synchronization',
    category: 'Integrations',
    scope: 'all'
  },
  
  // System Permissions
  'system.settings': {
    id: 'PERM-060',
    name: 'System Settings',
    code: 'system.settings',
    description: 'Manage system settings',
    category: 'System',
    scope: 'all'
  },
  'system.audit': {
    id: 'PERM-061',
    name: 'View Audit Logs',
    code: 'system.audit',
    description: 'View system audit logs',
    category: 'System',
    scope: 'all'
  }
};

// ============================================================================
// ROLE DEFINITIONS
// ============================================================================

export const RoleDefinitions: Record<UserRole, string[]> = {
  'Analyst': [
    'cases.view',
    'cases.create',
    'cases.edit',
    'cases.close',
    'reports.view',
    'reports.export',
    'integrations.view'
  ],
  'Manager': [
    'cases.view.all',
    'cases.create',
    'cases.edit.all',
    'cases.assign',
    'cases.close',
    'cases.reopen',
    'users.view',
    'reports.view.all',
    'reports.create',
    'reports.export',
    'data.export',
    'integrations.view',
    'integrations.sync'
  ],
  'Administrator': [
    'cases.view.all',
    'cases.create',
    'cases.edit.all',
    'cases.delete',
    'cases.assign',
    'cases.close',
    'cases.reopen',
    'users.view',
    'users.create',
    'users.edit',
    'users.delete',
    'users.roles',
    'reports.view.all',
    'reports.create',
    'reports.export',
    'data.export',
    'data.export.sensitive',
    'integrations.view',
    'integrations.manage',
    'integrations.sync',
    'system.settings',
    'system.audit'
  ],
  'Sales Owner': [
    'cases.view',
    'sales.review',
    'sales.approve',
    'reports.view',
    'integrations.view'
  ],
  'Read Only': [
    'cases.view',
    'reports.view',
    'integrations.view'
  ]
};

// ============================================================================
// JSON SCHEMA DEFINITIONS
// ============================================================================

export const UserSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: ["id", "username", "email", "fullName", "role", "active"],
  properties: {
    id: {
      type: "string",
      pattern: "^USR-[0-9]{4,}$"
    },
    username: {
      type: "string",
      minLength: 3,
      maxLength: 50,
      pattern: "^[a-z0-9_-]+$"
    },
    email: {
      type: "string",
      format: "email"
    },
    fullName: {
      type: "string",
      minLength: 1,
      maxLength: 100
    },
    role: {
      type: "string",
      enum: ["Analyst", "Manager", "Administrator", "Sales Owner", "Read Only"]
    },
    active: {
      type: "boolean"
    },
    lineOfBusiness: {
      type: "array",
      items: {
        type: "string",
        enum: ["GB/GM", "PB", "ML", "Consumer", "CI"]
      }
    }
  }
};

export const PermissionSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: ["id", "name", "code", "description", "category", "scope"],
  properties: {
    id: {
      type: "string"
    },
    name: {
      type: "string"
    },
    code: {
      type: "string",
      pattern: "^[a-z]+\\.[a-z]+(\\.[a-z]+)?$"
    },
    description: {
      type: "string"
    },
    category: {
      type: "string",
      enum: ["Cases", "Users", "Reports", "Integrations", "System", "Data"]
    },
    scope: {
      type: "string",
      enum: ["own", "team", "all"]
    },
    requiresApproval: {
      type: "boolean"
    }
  }
};

// ============================================================================
// API ENDPOINTS SPECIFICATION
// ============================================================================

export const RolesEntitlementsAPI = {
  baseUrl: "/api/v1/rbac",
  
  endpoints: {
    /**
     * GET /api/v1/rbac/users
     * List all users
     */
    listUsers: {
      method: "GET",
      path: "/users",
      queryParams: {
        role: "UserRole (optional) - Filter by role",
        active: "boolean (optional) - Filter by active status",
        search: "string (optional) - Search by name or username",
        page: "number (optional)",
        pageSize: "number (optional)"
      },
      response: {
        status: 200,
        body: {
          data: "User[]",
          total: "number",
          page: "number",
          pageSize: "number"
        }
      },
      permissions: ["users.view"],
      example: `
GET /api/v1/rbac/users?role=Analyst&active=true

Response:
{
  "data": [
    {
      "id": "USR-001",
      "username": "jdoe",
      "email": "jdoe@example.com",
      "fullName": "John Doe",
      "role": "Analyst",
      "active": true,
      "department": "AML",
      "lastLogin": "2025-10-26T09:15:00Z"
    }
  ],
  "total": 25,
  "page": 1,
  "pageSize": 20
}
      `
    },

    /**
     * GET /api/v1/rbac/users/:id
     * Get user by ID
     */
    getUserById: {
      method: "GET",
      path: "/users/:id",
      pathParams: {
        id: "string - User identifier"
      },
      response: {
        status: 200,
        body: "User"
      },
      permissions: ["users.view"]
    },

    /**
     * GET /api/v1/rbac/users/:id/access
     * Get user access profile
     */
    getUserAccess: {
      method: "GET",
      path: "/users/:id/access",
      pathParams: {
        id: "string - User identifier"
      },
      response: {
        status: 200,
        body: "UserAccess"
      },
      permissions: ["users.view"]
    },

    /**
     * POST /api/v1/rbac/users
     * Create new user
     */
    createUser: {
      method: "POST",
      path: "/users",
      requestBody: {
        username: "string (required)",
        email: "string (required)",
        fullName: "string (required)",
        role: "UserRole (required)",
        lineOfBusiness: "string[] (optional)",
        department: "string (optional)",
        manager: "string (optional)"
      },
      response: {
        status: 201,
        body: "User"
      },
      permissions: ["users.create"]
    },

    /**
     * PUT /api/v1/rbac/users/:id
     * Update user
     */
    updateUser: {
      method: "PUT",
      path: "/users/:id",
      pathParams: {
        id: "string - User identifier"
      },
      requestBody: "Partial<User>",
      response: {
        status: 200,
        body: "User"
      },
      permissions: ["users.edit"]
    },

    /**
     * DELETE /api/v1/rbac/users/:id
     * Delete user (soft delete)
     */
    deleteUser: {
      method: "DELETE",
      path: "/users/:id",
      pathParams: {
        id: "string - User identifier"
      },
      response: {
        status: 204,
        body: null
      },
      permissions: ["users.delete"]
    },

    /**
     * POST /api/v1/rbac/users/:id/role
     * Assign role to user
     */
    assignRole: {
      method: "POST",
      path: "/users/:id/role",
      pathParams: {
        id: "string - User identifier"
      },
      requestBody: {
        role: "UserRole (required)",
        reason: "string (optional)",
        effectiveDate: "string (optional) - ISO 8601 date",
        expirationDate: "string (optional) - ISO 8601 date"
      },
      response: {
        status: 200,
        body: "RoleAssignmentHistory"
      },
      permissions: ["users.roles"]
    },

    /**
     * GET /api/v1/rbac/roles
     * List all roles
     */
    listRoles: {
      method: "GET",
      path: "/roles",
      response: {
        status: 200,
        body: "Role[]"
      },
      example: `
GET /api/v1/rbac/roles

Response:
[
  {
    "id": "ROLE-001",
    "name": "Analyst",
    "displayName": "Case Analyst",
    "description": "Analysts can manage assigned cases",
    "permissions": [...],
    "isSystemRole": true
  }
]
      `
    },

    /**
     * GET /api/v1/rbac/roles/:id
     * Get role by ID
     */
    getRoleById: {
      method: "GET",
      path: "/roles/:id",
      pathParams: {
        id: "string - Role identifier"
      },
      response: {
        status: 200,
        body: "Role"
      }
    },

    /**
     * GET /api/v1/rbac/permissions
     * List all permissions
     */
    listPermissions: {
      method: "GET",
      path: "/permissions",
      queryParams: {
        category: "PermissionCategory (optional) - Filter by category"
      },
      response: {
        status: 200,
        body: "Permission[]"
      }
    },

    /**
     * POST /api/v1/rbac/check-permission
     * Check if user has permission
     */
    checkPermission: {
      method: "POST",
      path: "/check-permission",
      requestBody: "PermissionCheckRequest",
      response: {
        status: 200,
        body: "PermissionCheckResult"
      },
      example: `
POST /api/v1/rbac/check-permission
Content-Type: application/json

{
  "userId": "USR-001",
  "permissionCode": "cases.edit.all",
  "resourceId": "CASE-2025-001"
}

Response:
{
  "allowed": true,
  "scope": "all"
}
      `
    },

    /**
     * GET /api/v1/rbac/audit-logs
     * Get audit logs
     */
    getAuditLogs: {
      method: "GET",
      path: "/audit-logs",
      queryParams: {
        userId: "string (optional) - Filter by user",
        action: "string (optional) - Filter by action",
        resourceType: "string (optional) - Filter by resource type",
        result: "string (optional) - Success | Denied | Error",
        startDate: "string (optional) - ISO 8601 date",
        endDate: "string (optional) - ISO 8601 date",
        page: "number (optional)",
        pageSize: "number (optional)"
      },
      response: {
        status: 200,
        body: {
          data: "AuditLogEntry[]",
          total: "number"
        }
      },
      permissions: ["system.audit"]
    },

    /**
     * GET /api/v1/rbac/access-requests
     * List access requests
     */
    listAccessRequests: {
      method: "GET",
      path: "/access-requests",
      queryParams: {
        status: "string (optional) - Pending | Approved | Denied",
        requestedBy: "string (optional) - Filter by requester"
      },
      response: {
        status: 200,
        body: "AccessRequest[]"
      },
      permissions: ["users.roles"]
    },

    /**
     * POST /api/v1/rbac/access-requests
     * Create access request
     */
    createAccessRequest: {
      method: "POST",
      path: "/access-requests",
      requestBody: {
        requestType: "string (required) - Role | Permission | Resource",
        requestedAccess: "string (required)",
        businessJustification: "string (required)"
      },
      response: {
        status: 201,
        body: "AccessRequest"
      }
    },

    /**
     * PUT /api/v1/rbac/access-requests/:id/review
     * Review access request
     */
    reviewAccessRequest: {
      method: "PUT",
      path: "/access-requests/:id/review",
      pathParams: {
        id: "string - Access request ID"
      },
      requestBody: {
        status: "string (required) - Approved | Denied",
        comments: "string (optional)"
      },
      response: {
        status: 200,
        body: "AccessRequest"
      },
      permissions: ["users.roles"]
    }
  }
};

export default {
  UserSchema,
  PermissionSchema,
  RolesEntitlementsAPI,
  PermissionDefinitions,
  RoleDefinitions
};
