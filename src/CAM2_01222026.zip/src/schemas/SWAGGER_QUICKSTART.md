# Swagger/OpenAPI Quick Start Guide

## 🚀 Quick Access Methods

### Method 1: Online Swagger Editor (No Installation Required)
**⏱️ Setup Time: 30 seconds**

1. Open [https://editor.swagger.io/](https://editor.swagger.io/)
2. Click **File > Import File**
3. Navigate to `/src/schemas/swagger.yaml`
4. ✅ Done! Interactive API docs are live

### Method 2: Swagger UI in React App
**⏱️ Setup Time: 5 minutes**

```bash
# Install dependencies
npm install swagger-ui-react swagger-ui-dist

# Create component (src/components/SwaggerUI.tsx)
import SwaggerUI from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';

export function APIDocumentation() {
  return <SwaggerUI url="/src/schemas/swagger.yaml" />;
}

# Add to App.tsx routing
{currentPage === 'api-docs' && <APIDocumentation />}
```

### Method 3: Redoc (Beautiful Alternative)
**⏱️ Setup Time: 1 minute**

```bash
# Serve instantly
npx redoc-cli serve src/schemas/swagger.yaml --watch

# Opens at http://localhost:8080
```

## 🔑 Authentication in Swagger UI

1. Click the green **"Authorize"** button (🔓 icon) at the top
2. In the dialog, enter: `Bearer YOUR_JWT_TOKEN_HERE`
3. Click **"Authorize"**
4. Click **"Close"**
5. ✅ All subsequent requests will include your token

## 🧪 Testing an Endpoint

### Example: Get All Cases

1. Navigate to **Cases** section
2. Find **GET /cases** endpoint
3. Click to expand
4. Click **"Try it out"** button
5. Enter parameters:
   - `status`: In Progress
   - `priority`: High
   - `page`: 1
   - `pageSize`: 20
6. Click **"Execute"**
7. View the response below:
   - Status Code: 200
   - Response Body: JSON data
   - Response Headers
   - Request URL used

### Example: Create a Case

1. Find **POST /cases** endpoint
2. Click **"Try it out"**
3. Edit the request body JSON:
```json
{
  "clientId": "CLI-12345",
  "clientName": "Acme Corporation",
  "accountNumber": "1234567890",
  "caseType": "312 + CAM",
  "priority": "High",
  "section312Required": true,
  "camRequired": true,
  "assignedTo": "jdoe"
}
```
4. Click **"Execute"**
5. Check response for created case with ID

## 📋 Available Endpoints Summary

### Cases (17 endpoints)
- `GET /cases` - List all cases
- `POST /cases` - Create case
- `GET /cases/{caseId}` - Get case details
- `PUT /cases/{caseId}` - Update case
- `POST /cases/{caseId}/assign` - Assign case
- `POST /cases/{caseId}/312/submit` - Submit 312 review
- `GET /cases/{caseId}/notes` - Get case notes
- `POST /cases/{caseId}/notes` - Add note
- `GET /cases/my-cases` - My assigned cases
- `GET /cases/statistics` - Case statistics

### Dashboard (10 endpoints)
- `GET /dashboard/metrics` - Overall metrics
- `GET /dashboard/volume-trend` - Case volume over time
- `GET /dashboard/upcoming-deadlines` - Cases due soon
- And more...

### Integrations (8 endpoints)
- `GET /integrations` - List integrations
- `GET /integrations/{id}/health` - Health metrics
- `POST /integrations/{id}/sync` - Trigger sync
- And more...

### Users & Roles (10 endpoints)
- `GET /rbac/users` - List users
- `POST /rbac/users` - Create user
- `GET /rbac/roles` - List roles
- `POST /rbac/check-permission` - Check permission
- And more...

### Reports (9 endpoints)
- `GET /reports` - List reports
- `POST /reports` - Create report
- `GET /reports/templates` - List templates
- `GET /reports/{id}/download` - Download report
- And more...

### Notifications (10 endpoints)
- `GET /notifications` - List notifications
- `PUT /notifications/{id}/read` - Mark as read
- `GET /notifications/preferences` - Get preferences
- And more...

## 💾 Export to Postman

### Method 1: Direct Import
1. Open Postman
2. Click **Import** button
3. Select **Link** tab
4. Paste URL to `swagger.yaml` (if hosted)
5. OR select **File** tab and upload `swagger.yaml`
6. Click **Import**

### Method 2: Convert to JSON First
```bash
npm install -g swagger-cli
swagger-cli bundle src/schemas/swagger.yaml -o swagger.json
```
Then import `swagger.json` into Postman.

### Method 3: Online Converter
1. Visit [https://www.apimatic.io/transformer](https://www.apimatic.io/transformer)
2. Upload `swagger.yaml`
3. Select output: **Postman Collection v2.1**
4. Download and import to Postman

## 🎨 Customization

### Hide Top Bar
```css
.swagger-ui .topbar {
  display: none;
}
```

### Dark Mode
```css
.swagger-ui {
  filter: invert(88%) hue-rotate(180deg);
}
```

### Custom Colors
```jsx
<SwaggerUI 
  url="/swagger.yaml"
  theme={{
    colors: {
      primary: '#3b82f6'
    }
  }}
/>
```

## 📝 Common Parameters

### Pagination
- `page` - Page number (default: 1)
- `pageSize` - Items per page (default: 20, max: 100)

### Filtering
- `status` - Filter by status
- `priority` - Filter by priority
- `startDate` - Start date for range
- `endDate` - End date for range
- `search` - Search query

### Sorting
- `sortBy` - Field to sort by (default: createdDate)
- `sortOrder` - asc or desc (default: desc)

## ⚡ Response Codes

- **200** - OK (Success)
- **201** - Created (Resource created)
- **202** - Accepted (Processing)
- **204** - No Content (Success, no body)
- **400** - Bad Request (Invalid params)
- **401** - Unauthorized (Not authenticated)
- **403** - Forbidden (No permission)
- **404** - Not Found (Resource doesn't exist)
- **422** - Validation Error (Invalid data)
- **500** - Server Error

## 🔍 Search & Filter in Swagger UI

1. Click the **Filter** field at top
2. Type keyword (e.g., "case", "user", "report")
3. Only matching endpoints will show
4. Clear to show all again

## 📦 What's Documented

✅ **64+ API Endpoints** across 6 modules  
✅ **50+ Data Schemas** with validation rules  
✅ **Request/Response Examples** for every endpoint  
✅ **Authentication** with Bearer token  
✅ **Error Responses** with details  
✅ **Enums** for all status types  
✅ **Pagination** support  
✅ **Filtering & Sorting** parameters  

## 🛠️ Validation

Validate your Swagger spec:

```bash
# Install validator
npm install -g @apidevtools/swagger-cli

# Validate
swagger-cli validate src/schemas/swagger.yaml

# Output: ✅ Swagger spec is valid
```

## 🌐 Host Your Docs

### GitHub Pages
1. Commit `swagger.yaml` to repo
2. Enable GitHub Pages
3. Access via: `https://yourusername.github.io/repo/src/schemas/swagger.yaml`

### Netlify
```bash
# Deploy folder with swagger.yaml
netlify deploy --dir=src/schemas
```

### Swagger Hub
1. Go to [https://app.swaggerhub.com/](https://app.swaggerhub.com/)
2. Create free account
3. Import `swagger.yaml`
4. Get public URL

## 🎯 Tips & Tricks

### Mock Server
Generate mock responses for testing:
```bash
npm install -g @stoplight/prism-cli
prism mock src/schemas/swagger.yaml
# Server runs on http://localhost:4010
```

### Generate Client Code
```bash
# Install generator
npm install -g @openapitools/openapi-generator-cli

# Generate TypeScript client
openapi-generator-cli generate \
  -i src/schemas/swagger.yaml \
  -g typescript-axios \
  -o ./generated-client
```

### Diff Two Specs
Compare spec versions:
```bash
npm install -g @useoptic/openapi-utilities
openapi diff swagger-v1.yaml swagger-v2.yaml
```

## 📚 Additional Resources

- [Swagger Editor](https://editor.swagger.io/) - Online editor
- [OpenAPI Specification](https://swagger.io/specification/) - Official docs
- [Redoc](https://redocly.com/) - Alternative UI
- [Swagger UI Docs](https://swagger.io/tools/swagger-ui/) - UI documentation
- [Postman](https://www.postman.com/) - API testing tool

## 🆘 Troubleshooting

### CORS Issues
Add CORS headers to your API:
```javascript
res.header('Access-Control-Allow-Origin', '*');
```

### Can't Load Swagger File
- Ensure path is correct
- Check file is valid YAML
- Validate with `swagger-cli validate`

### Authentication Not Working
- Check token format: `Bearer <token>`
- Verify token is not expired
- Ensure API accepts Bearer auth

---

**Need Help?** Check the full documentation in the schema files or visit [Swagger Documentation](https://swagger.io/docs/)
