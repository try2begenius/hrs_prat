/**
 * System Integrations Schema
 * 
 * Data taxonomy, schemas, and API endpoints for external system integrations
 * including client data sources, monitoring systems, and risk platforms.
 */

// ============================================================================
// TYPE DEFINITIONS & DATA TAXONOMY
// ============================================================================

export type IntegrationStatus = 'Connected' | 'Syncing' | 'Error' | 'Disconnected';
export type IntegrationType = 'Client Data' | 'Monitoring Data' | 'Risk Data';
export type LineOfBusiness = 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI';

/**
 * Core SystemIntegration Entity
 * Represents an external system integrated with the CAM platform
 */
export interface SystemIntegration {
  id: string;                        // Unique identifier (e.g., "INT-001")
  name: string;                      // System name (e.g., "Cesium", "TRMS")
  type: IntegrationType;             // Data classification
  description: string;               // System purpose and scope
  status: IntegrationStatus;         // Current connection state
  lastSync: string;                  // ISO 8601 datetime of last sync
  recordCount: number;               // Total records synchronized
  errorCount: number;                // Count of sync errors
  dataAttributes: string[];          // List of available data fields
  linesOfBusiness?: LineOfBusiness[]; // Optional LOB filter
}

/**
 * Detailed Data Attribute Metadata
 * Describes individual fields within integrated systems
 */
export interface DataAttribute {
  name: string;                      // Attribute name
  source: string;                    // Source system(s) - comma separated
  type: DataAttributeType;           // Data type
  required: boolean;                 // Mandatory field indicator
  description: string;               // Purpose and usage notes
  consumers?: string;                // Downstream consuming systems
}

export type DataAttributeType = 'String' | 'Number' | 'Date' | 'Boolean' | 'Object' | 'Enum' | 'Array';

/**
 * CAM Integration Attribute (Enhanced)
 * Includes bidirectional data flow information
 */
export interface CAMIntegrationAttribute {
  name: string;                      // Field name
  source: string;                    // Originating system
  type: DataAttributeType;           // Data type
  required: boolean;                 // Required field flag
  consumers: string;                 // Systems consuming this data
  description: string;               // Field purpose and business logic
}

/**
 * CAM Integration Category
 * Groups related integration attributes
 */
export interface CAMIntegrationCategory {
  category: string;                  // Category name/title
  description: string;               // Category purpose
  attributes: CAMIntegrationAttribute[]; // Grouped attributes
}

/**
 * Integration Sync Log
 * Tracks synchronization history and errors
 */
export interface IntegrationSyncLog {
  id: string;                        // Log entry ID
  integrationId: string;             // Foreign key to SystemIntegration
  syncStartTime: string;             // ISO 8601 datetime
  syncEndTime: string;               // ISO 8601 datetime
  status: 'Success' | 'Partial' | 'Failed';
  recordsProcessed: number;          // Total records attempted
  recordsSucceeded: number;          // Successfully synced
  recordsFailed: number;             // Failed to sync
  errorDetails?: IntegrationError[]; // Detailed error information
}

/**
 * Integration Error Detail
 */
export interface IntegrationError {
  recordId: string;                  // Identifier of failed record
  errorCode: string;                 // Error classification code
  errorMessage: string;              // Human-readable error
  timestamp: string;                 // ISO 8601 datetime
  retryable: boolean;                // Can this error be retried
}

/**
 * Integration Health Metrics
 */
export interface IntegrationHealthMetrics {
  integrationId: string;
  uptime: number;                    // Percentage (0-100)
  avgSyncDuration: number;           // Average sync time in seconds
  successRate: number;               // Percentage (0-100)
  lastSuccessfulSync: string;        // ISO 8601 datetime
  errorRate: number;                 // Errors per 1000 records
  dataFreshness: number;             // Age of data in hours
}

// ============================================================================
// JSON SCHEMA DEFINITIONS
// ============================================================================

export const SystemIntegrationSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: ["id", "name", "type", "description", "status", "lastSync", "recordCount", "errorCount", "dataAttributes"],
  properties: {
    id: {
      type: "string",
      pattern: "^INT-[0-9]{3,}[A-Z]?$",
      description: "Unique integration identifier"
    },
    name: {
      type: "string",
      minLength: 1,
      maxLength: 100,
      description: "Integration system name"
    },
    type: {
      type: "string",
      enum: ["Client Data", "Monitoring Data", "Risk Data"],
      description: "Data classification category"
    },
    description: {
      type: "string",
      minLength: 1,
      maxLength: 500,
      description: "System purpose description"
    },
    status: {
      type: "string",
      enum: ["Connected", "Syncing", "Error", "Disconnected"],
      description: "Current connection status"
    },
    lastSync: {
      type: "string",
      format: "date-time",
      description: "Last synchronization timestamp"
    },
    recordCount: {
      type: "integer",
      minimum: 0,
      description: "Total synchronized records"
    },
    errorCount: {
      type: "integer",
      minimum: 0,
      description: "Count of sync errors"
    },
    dataAttributes: {
      type: "array",
      items: { type: "string" },
      minItems: 1,
      description: "Available data fields"
    },
    linesOfBusiness: {
      type: "array",
      items: {
        type: "string",
        enum: ["GB/GM", "PB", "ML", "Consumer", "CI"]
      },
      description: "Lines of business filter"
    }
  }
};

export const DataAttributeSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  required: ["name", "source", "type", "required", "description"],
  properties: {
    name: {
      type: "string",
      minLength: 1,
      maxLength: 100
    },
    source: {
      type: "string",
      description: "Source system(s) - comma separated"
    },
    type: {
      type: "string",
      enum: ["String", "Number", "Date", "Boolean", "Object", "Enum", "Array"]
    },
    required: {
      type: "boolean"
    },
    description: {
      type: "string",
      minLength: 1,
      maxLength: 500
    },
    consumers: {
      type: "string",
      description: "Downstream consuming systems"
    }
  }
};

// ============================================================================
// API ENDPOINTS SPECIFICATION
// ============================================================================

export const SystemIntegrationsAPI = {
  baseUrl: "/api/v1/integrations",
  
  endpoints: {
    /**
     * GET /api/v1/integrations
     * List all system integrations
     */
    listIntegrations: {
      method: "GET",
      path: "/",
      queryParams: {
        type: "string (optional) - Filter by integration type",
        status: "string (optional) - Filter by status",
        lineOfBusiness: "string (optional) - Filter by LOB"
      },
      response: {
        status: 200,
        body: {
          data: "SystemIntegration[]",
          total: "number",
          page: "number",
          pageSize: "number"
        }
      },
      example: `
GET /api/v1/integrations?type=Client Data&status=Connected

Response:
{
  "data": [
    {
      "id": "INT-001",
      "name": "Cesium",
      "type": "Client Data",
      "description": "Global Banking and Global Markets client data",
      "status": "Connected",
      "lastSync": "2025-10-26T10:30:00Z",
      "recordCount": 45230,
      "errorCount": 0,
      "dataAttributes": ["Legal Name", "Client ID", "GCI Number"],
      "linesOfBusiness": ["GB/GM"]
    }
  ],
  "total": 12,
  "page": 1,
  "pageSize": 20
}
      `
    },

    /**
     * GET /api/v1/integrations/:id
     * Get integration by ID
     */
    getIntegrationById: {
      method: "GET",
      path: "/:id",
      pathParams: {
        id: "string - Integration identifier"
      },
      response: {
        status: 200,
        body: "SystemIntegration"
      },
      errors: {
        404: "Integration not found"
      },
      example: `
GET /api/v1/integrations/INT-001

Response:
{
  "id": "INT-001",
  "name": "Cesium",
  "type": "Client Data",
  ...
}
      `
    },

    /**
     * GET /api/v1/integrations/:id/health
     * Get integration health metrics
     */
    getIntegrationHealth: {
      method: "GET",
      path: "/:id/health",
      pathParams: {
        id: "string - Integration identifier"
      },
      response: {
        status: 200,
        body: "IntegrationHealthMetrics"
      },
      example: `
GET /api/v1/integrations/INT-001/health

Response:
{
  "integrationId": "INT-001",
  "uptime": 99.8,
  "avgSyncDuration": 45.5,
  "successRate": 99.9,
  "lastSuccessfulSync": "2025-10-26T10:30:00Z",
  "errorRate": 0.1,
  "dataFreshness": 0.5
}
      `
    },

    /**
     * GET /api/v1/integrations/:id/sync-logs
     * Get sync history
     */
    getSyncLogs: {
      method: "GET",
      path: "/:id/sync-logs",
      pathParams: {
        id: "string - Integration identifier"
      },
      queryParams: {
        startDate: "string (optional) - ISO 8601 date",
        endDate: "string (optional) - ISO 8601 date",
        status: "string (optional) - Filter by sync status",
        limit: "number (optional) - Max results (default: 50)"
      },
      response: {
        status: 200,
        body: {
          data: "IntegrationSyncLog[]",
          total: "number"
        }
      },
      example: `
GET /api/v1/integrations/INT-001/sync-logs?limit=10

Response:
{
  "data": [
    {
      "id": "LOG-001",
      "integrationId": "INT-001",
      "syncStartTime": "2025-10-26T10:30:00Z",
      "syncEndTime": "2025-10-26T10:31:23Z",
      "status": "Success",
      "recordsProcessed": 45230,
      "recordsSucceeded": 45230,
      "recordsFailed": 0
    }
  ],
  "total": 145
}
      `
    },

    /**
     * POST /api/v1/integrations/:id/sync
     * Trigger manual sync
     */
    triggerSync: {
      method: "POST",
      path: "/:id/sync",
      pathParams: {
        id: "string - Integration identifier"
      },
      requestBody: {
        fullSync: "boolean (optional) - Full or incremental sync",
        priority: "string (optional) - high | normal | low"
      },
      response: {
        status: 202,
        body: {
          syncJobId: "string",
          status: "string",
          message: "string"
        }
      },
      example: `
POST /api/v1/integrations/INT-001/sync
Content-Type: application/json

{
  "fullSync": false,
  "priority": "high"
}

Response:
{
  "syncJobId": "SYNC-12345",
  "status": "Queued",
  "message": "Sync job queued successfully"
}
      `
    },

    /**
     * GET /api/v1/integrations/attributes
     * Get all data attributes catalog
     */
    getDataAttributes: {
      method: "GET",
      path: "/attributes",
      queryParams: {
        category: "string (optional) - Filter by category",
        source: "string (optional) - Filter by source system",
        required: "boolean (optional) - Filter by required flag"
      },
      response: {
        status: 200,
        body: {
          categories: "Array<{ category: string, attributes: DataAttribute[] }>"
        }
      },
      example: `
GET /api/v1/integrations/attributes?category=Client Information

Response:
{
  "categories": [
    {
      "category": "Client Information",
      "attributes": [
        {
          "name": "Legal Name",
          "source": "Cesium, AWAREWCC, CMT",
          "type": "String",
          "required": true,
          "description": "Client legal entity name"
        }
      ]
    }
  ]
}
      `
    },

    /**
     * GET /api/v1/integrations/cam-attributes
     * Get CAM integration attributes with data flow
     */
    getCAMAttributes: {
      method: "GET",
      path: "/cam-attributes",
      response: {
        status: 200,
        body: "CAMIntegrationCategory[]"
      },
      example: `
GET /api/v1/integrations/cam-attributes

Response:
[
  {
    "category": "312 Case Data (Outbound to FLU Tools & GFC Search)",
    "description": "Data exported from CAM to enable refresh completion",
    "attributes": [
      {
        "name": "CAM Case Number",
        "source": "CAM Platform",
        "type": "String",
        "required": true,
        "consumers": "FLU Tools, GFC Search Analytics",
        "description": "Unique case identifier for tracking"
      }
    ]
  }
]
      `
    },

    /**
     * PUT /api/v1/integrations/:id
     * Update integration configuration
     */
    updateIntegration: {
      method: "PUT",
      path: "/:id",
      pathParams: {
        id: "string - Integration identifier"
      },
      requestBody: "Partial<SystemIntegration>",
      response: {
        status: 200,
        body: "SystemIntegration"
      },
      permissions: ["Administrator"],
      example: `
PUT /api/v1/integrations/INT-001
Content-Type: application/json

{
  "description": "Updated description",
  "status": "Connected"
}
      `
    },

    /**
     * GET /api/v1/integrations/:id/errors
     * Get integration errors
     */
    getIntegrationErrors: {
      method: "GET",
      path: "/:id/errors",
      pathParams: {
        id: "string - Integration identifier"
      },
      queryParams: {
        startDate: "string (optional) - ISO 8601 date",
        endDate: "string (optional) - ISO 8601 date",
        retryable: "boolean (optional) - Filter by retryable flag",
        limit: "number (optional) - Max results"
      },
      response: {
        status: 200,
        body: {
          data: "IntegrationError[]",
          total: "number"
        }
      }
    }
  }
};

// ============================================================================
// SYSTEM CATALOG
// ============================================================================

export const IntegratedSystems = {
  clientData: [
    { 
      id: "INT-001", 
      name: "Cesium", 
      lob: ["GB/GM"], 
      records: 45230,
      description: "Global Banking and Global Markets client data"
    },
    { 
      id: "INT-002", 
      name: "AWARE Datamari", 
      lob: ["GB/GM"], 
      records: 38456,
      description: "GBGM 312 expected activity data"
    },
    { 
      id: "INT-003", 
      name: "Population Manager Tool", 
      lob: ["GB/GM", "PB", "ML", "Consumer", "CI"], 
      records: 12890,
      description: "DGA due dates for all lines of business"
    },
    { 
      id: "INT-004", 
      name: "CRH", 
      lob: ["Consumer"], 
      records: 128456,
      description: "Consumer client data (Consumer Relationship Hub)"
    },
    { 
      id: "INT-005", 
      name: "GDPP", 
      lob: ["PB", "ML", "Consumer"], 
      records: 67543,
      description: "Private Bank, Merrill Lynch, Consumer investments (Global Data Privacy Platform)"
    },
    { 
      id: "INT-006", 
      name: "GWIM Hub", 
      lob: ["ML", "Consumer"], 
      records: 89234,
      description: "Merrill Lynch and Consumer Investments (Global Wealth & Investment Management Hub)"
    },
    { 
      id: "INT-007", 
      name: "PRDS", 
      lob: ["GB/GM", "PB", "ML", "Consumer", "CI"], 
      records: 234567,
      description: "All Lines of Business (Party Reference Data System)"
    }
  ],
  monitoringData: [
    { id: "INT-008", name: "GFC Search Analytics", records: 89234 },
    { id: "INT-009", name: "FLU Data Sources", records: 23456 },
    { id: "INT-010", name: "TRMS", records: 45678 },
    { id: "INT-011", name: "SAR System", records: 3456 },
    { id: "INT-012", name: "Alert Management System", records: 67890 }
  ],
  riskData: [
    { id: "INT-013", name: "ORRCA", records: 156789 },
    { id: "INT-014", name: "312 Model", records: 1247 }
  ]
};

// ============================================================================
// DATA FLOW MAPPINGS
// ============================================================================

export const DataFlowMappings = {
  inbound: {
    description: "Data flowing INTO CAM Platform",
    sources: [
      {
        system: "Cesium",
        data: ["Legal Name", "Client ID", "GCI Number", "Sales Owner"],
        target: "ClientData entity"
      },
      {
        system: "ORRCA",
        data: ["Dynamic Risk Rating", "Risk Score"],
        target: "RiskData entity"
      },
      {
        system: "312 Model",
        data: ["312 Flag", "Model Score"],
        target: "Case312Data entity"
      }
    ]
  },
  outbound: {
    description: "Data flowing OUT OF CAM Platform",
    consumers: [
      {
        system: "FLU Data Sources",
        data: ["312 Completion Status", "Case Disposition"],
        purpose: "Enable FLU refresh after 312 completion"
      },
      {
        system: "GFC Search Analytics",
        data: ["CAM Case Status", "Case Disposition", "Completion Date"],
        purpose: "Analytics and reporting"
      },
      {
        system: "312 Model",
        data: ["312 Completion Status", "312 Disposition"],
        purpose: "Update model with completion results"
      }
    ]
  },
  bidirectional: [
    {
      system: "TRMS",
      inbound: ["TRMS Case ID", "TRMS Case Type"],
      outbound: ["CAM Case Number", "Case Status"],
      purpose: "Case escalation and cross-referencing"
    }
  ]
};

export default {
  SystemIntegrationSchema,
  DataAttributeSchema,
  SystemIntegrationsAPI,
  IntegratedSystems,
  DataFlowMappings
};