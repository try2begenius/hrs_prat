/**
 * Schema Index
 * 
 * Central export point for all data schemas, taxonomies, and API specifications
 * for the CAM (Client Account Management) and 312 Case Management System.
 */

// System Integrations
export * from './SystemIntegrations.schema';
export { default as SystemIntegrationsSchema } from './SystemIntegrations.schema';

// Case Management
export * from './CaseManagement.schema';
export { default as CaseManagementSchema } from './CaseManagement.schema';

// Dashboard
export * from './Dashboard.schema';
export { default as DashboardSchema } from './Dashboard.schema';

// Roles and Entitlements
export * from './RolesEntitlements.schema';
export { default as RolesEntitlementsSchema } from './RolesEntitlements.schema';

// Reports
export * from './Reports.schema';
export { default as ReportsSchema } from './Reports.schema';

// Notifications
export * from './Notifications.schema';
export { default as NotificationsSchema } from './Notifications.schema';

// Swagger/OpenAPI Integration
export * from './swagger-integration';
export { default as SwaggerIntegration } from './swagger-integration';

/**
 * Complete API Documentation
 * Aggregated API endpoints from all modules
 * 
 * 🚀 INTERACTIVE SWAGGER DOCS AVAILABLE!
 * See swagger.yaml and SWAGGER_QUICKSTART.md for interactive API documentation
 */
export const CompleteAPIDocumentation = {
  version: '1.0.0',
  baseUrl: '/api/v1',
  
  // Swagger/OpenAPI Documentation
  swagger: {
    specFile: '/src/schemas/swagger.yaml',
    quickstart: '/src/schemas/SWAGGER_QUICKSTART.md',
    onlineEditor: 'https://editor.swagger.io/',
    format: 'OpenAPI 3.0.3'
  },
  
  authentication: {
    type: 'Bearer Token',
    header: 'Authorization: Bearer <token>',
    tokenEndpoint: '/api/v1/auth/token'
  },
  
  modules: {
    systemIntegrations: {
      path: '/integrations',
      description: 'Manage external system integrations and data synchronization',
      endpoints: 8
    },
    caseManagement: {
      path: '/cases',
      description: 'Manage 312 and CAM cases, assignments, and workflows',
      endpoints: 17
    },
    dashboard: {
      path: '/dashboard',
      description: 'Dashboard metrics, KPIs, and analytics',
      endpoints: 10
    },
    rolesEntitlements: {
      path: '/rbac',
      description: 'Role-based access control and user management',
      endpoints: 10
    },
    reports: {
      path: '/reports',
      description: 'Report generation, scheduling, and export',
      endpoints: 9
    },
    notifications: {
      path: '/notifications',
      description: 'User notifications and alerts',
      endpoints: 10
    }
  },
  
  totalEndpoints: 64,
  totalSchemas: 50
};

/**
 * Data Model Overview
 * High-level description of system entities and relationships
 */
export const DataModelOverview = {
  coreEntities: {
    Case: 'Central entity representing a 312 and/or CAM case',
    User: 'System user with role-based permissions',
    SystemIntegration: 'External system connection and sync status',
    Report: 'Generated report with data and metadata',
    Notification: 'User notification or alert'
  },
  relationships: {
    'Case -> User': 'Many-to-One (assignedTo)',
    'Case -> User (Sales)': 'Many-to-One (salesOwner)',
    'Case -> Section312Data': 'One-to-One',
    'Case -> CAMCaseData': 'One-to-One',
    'User -> Role': 'Many-to-One',
    'Role -> Permission': 'Many-to-Many',
    'Report -> User': 'Many-to-One (createdBy)',
    'Notification -> User': 'Many-to-One (recipient)',
    'SystemIntegration -> DataAttribute': 'One-to-Many'
  },
  dataFlow: {
    inbound: [
      'External Systems -> SystemIntegration -> Case Data',
      'User Input -> Case -> Workflow Engine'
    ],
    outbound: [
      'Case Completion -> FLU Data Sources',
      'Case Disposition -> GFC Search Analytics',
      'Case Status -> 312 Model'
    ]
  }
};

/**
 * Schema Validation Utilities
 */
export const SchemaValidation = {
  validateCase: 'Use CaseSchema for JSON validation',
  validateUser: 'Use UserSchema for JSON validation',
  validateNotification: 'Use NotificationSchema for JSON validation',
  validateReport: 'Use ReportSchema for JSON validation',
  validateSystemIntegration: 'Use SystemIntegrationSchema for JSON validation'
};

/**
 * Common HTTP Status Codes
 */
export const HTTPStatusCodes = {
  200: 'OK - Request succeeded',
  201: 'Created - Resource created successfully',
  202: 'Accepted - Request accepted for processing',
  204: 'No Content - Request succeeded with no response body',
  400: 'Bad Request - Invalid request parameters',
  401: 'Unauthorized - Authentication required',
  403: 'Forbidden - Insufficient permissions',
  404: 'Not Found - Resource not found',
  409: 'Conflict - Resource conflict',
  422: 'Unprocessable Entity - Validation failed',
  500: 'Internal Server Error - Server error',
  503: 'Service Unavailable - Service temporarily unavailable'
};

/**
 * Common Query Parameters
 */
export const CommonQueryParameters = {
  page: 'number - Page number for pagination (default: 1)',
  pageSize: 'number - Items per page (default: 20, max: 100)',
  sortBy: 'string - Field to sort by',
  sortOrder: 'string - Sort direction: asc | desc',
  search: 'string - Search query',
  startDate: 'string - ISO 8601 date for date range filtering',
  endDate: 'string - ISO 8601 date for date range filtering'
};

/**
 * Common Request Headers
 */
export const CommonRequestHeaders = {
  'Authorization': 'Bearer <token> - Authentication token',
  'Content-Type': 'application/json - Request body format',
  'Accept': 'application/json - Expected response format',
  'X-Request-ID': 'string - Unique request identifier for tracing'
};

/**
 * Common Response Headers
 */
export const CommonResponseHeaders = {
  'Content-Type': 'application/json - Response format',
  'X-Request-ID': 'string - Request identifier from request',
  'X-RateLimit-Limit': 'number - Rate limit maximum',
  'X-RateLimit-Remaining': 'number - Remaining requests',
  'X-RateLimit-Reset': 'number - Rate limit reset time (Unix timestamp)'
};

export default {
  CompleteAPIDocumentation,
  DataModelOverview,
  SchemaValidation,
  HTTPStatusCodes,
  CommonQueryParameters,
  CommonRequestHeaders,
  CommonResponseHeaders
};