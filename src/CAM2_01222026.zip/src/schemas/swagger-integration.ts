/**
 * Swagger UI Integration
 * 
 * This file provides utilities for integrating Swagger UI into your application
 * to visualize and interact with the API documentation.
 */

// =============================================================================
// SWAGGER CONFIGURATION
// =============================================================================

export const swaggerConfig = {
  // Swagger spec location
  specUrl: '/src/schemas/swagger.yaml',
  
  // Swagger UI options
  swaggerOptions: {
    persistAuthorization: true,
    displayRequestDuration: true,
    filter: true,
    tryItOutEnabled: true,
    syntaxHighlight: {
      activate: true,
      theme: 'monokai'
    },
    defaultModelsExpandDepth: 1,
    defaultModelExpandDepth: 1,
    docExpansion: 'list', // 'list', 'full', or 'none'
    tagsSorter: 'alpha',
    operationsSorter: 'alpha'
  }
};

// =============================================================================
// INSTALLATION INSTRUCTIONS
// =============================================================================

export const installationGuide = `
# Swagger UI Integration Guide

## Option 1: Standalone Swagger UI (Recommended for Development)

### 1. Install Swagger UI
npm install swagger-ui-react swagger-ui-dist

### 2. Create Swagger Component
// src/components/SwaggerUI.tsx
import React from 'react';
import SwaggerUI from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';

export function SwaggerUIComponent() {
  return (
    <div className="swagger-container">
      <SwaggerUI 
        url="/src/schemas/swagger.yaml"
        persistAuthorization={true}
        displayRequestDuration={true}
        filter={true}
        tryItOutEnabled={true}
      />
    </div>
  );
}

### 3. Add Route to App
Add a route in your App.tsx to display the Swagger UI:

{currentPage === 'api-docs' && <SwaggerUIComponent />}

## Option 2: Swagger UI Express (For Backend)

### 1. Install Dependencies
npm install swagger-ui-express yamljs

### 2. Setup in Express Server
const express = require('express');
const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');

const app = express();
const swaggerDocument = YAML.load('./src/schemas/swagger.yaml');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument, {
  customCss: '.swagger-ui .topbar { display: none }',
  customSiteTitle: 'CAM API Documentation'
}));

app.listen(3000);

## Option 3: Redoc (Alternative Documentation UI)

### 1. Install Redoc
npm install redoc

### 2. Create Redoc Component
import { RedocStandalone } from 'redoc';

export function ApiDocs() {
  return (
    <RedocStandalone
      specUrl="/src/schemas/swagger.yaml"
      options={{
        nativeScrollbars: true,
        theme: {
          colors: {
            primary: { main: '#3b82f6' }
          }
        }
      }}
    />
  );
}

## Option 4: Online Swagger Editor

1. Go to https://editor.swagger.io/
2. File > Import File
3. Select /src/schemas/swagger.yaml
4. View and test the API documentation

## Testing with Swagger UI

### Set Authentication Token
1. Click "Authorize" button at the top
2. Enter: Bearer YOUR_TOKEN_HERE
3. Click "Authorize"
4. Token will be included in all requests

### Try API Endpoints
1. Expand any endpoint
2. Click "Try it out"
3. Fill in required parameters
4. Click "Execute"
5. View the response

## Customization

### Custom CSS for Swagger UI
.swagger-ui .topbar {
  display: none; /* Hide top bar */
}

.swagger-ui .info {
  margin: 20px 0;
}

.swagger-ui .scheme-container {
  padding: 20px 0;
}

### Dark Mode Theme
import 'swagger-ui-react/swagger-ui.css';
import './swagger-dark-theme.css';

// swagger-dark-theme.css
.swagger-ui {
  filter: invert(88%) hue-rotate(180deg);
}

.swagger-ui img {
  filter: invert(100%) hue-rotate(180deg);
}
`;

// =============================================================================
// EXAMPLE REACT COMPONENT
// =============================================================================

export const swaggerUIComponentExample = `
import React from 'react';
import SwaggerUI from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';

interface SwaggerUIProps {
  onAuthChange?: (token: string) => void;
}

export function APIDocumentation({ onAuthChange }: SwaggerUIProps) {
  const requestInterceptor = (request: any) => {
    // Add custom headers or modify requests
    request.headers['X-Custom-Header'] = 'custom-value';
    return request;
  };

  const responseInterceptor = (response: any) => {
    // Handle responses
    console.log('API Response:', response);
    return response;
  };

  return (
    <div className="api-documentation">
      <div className="api-header">
        <h1>CAM & 312 API Documentation</h1>
        <p>Interactive API documentation with live testing capabilities</p>
      </div>
      
      <SwaggerUI 
        url="/src/schemas/swagger.yaml"
        
        // UI Options
        docExpansion="list"
        defaultModelsExpandDepth={1}
        displayRequestDuration={true}
        filter={true}
        showExtensions={true}
        showCommonExtensions={true}
        
        // Try it out
        tryItOutEnabled={true}
        supportedSubmitMethods={['get', 'post', 'put', 'delete', 'patch']}
        
        // Auth
        persistAuthorization={true}
        
        // Interceptors
        requestInterceptor={requestInterceptor}
        responseInterceptor={responseInterceptor}
        
        // Plugins
        plugins={[]}
        
        // Custom options
        onComplete={(swaggerApi: any) => {
          console.log('Swagger UI loaded', swaggerApi);
        }}
      />
    </div>
  );
}

// Styling
const styles = \`
.api-documentation {
  height: 100vh;
  overflow-y: auto;
}

.api-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 2rem;
  text-align: center;
}

.api-header h1 {
  margin: 0 0 0.5rem 0;
  font-size: 2rem;
}

.api-header p {
  margin: 0;
  opacity: 0.9;
}

/* Hide Swagger UI top bar */
.swagger-ui .topbar {
  display: none;
}

/* Customize info section */
.swagger-ui .info {
  margin: 2rem 0;
}

/* Customize authorize button */
.swagger-ui .btn.authorize {
  background: #667eea;
  border-color: #667eea;
}

.swagger-ui .btn.authorize:hover {
  background: #5568d3;
  border-color: #5568d3;
}
\`;
`;

// =============================================================================
// VITE CONFIGURATION
// =============================================================================

export const viteConfigExample = `
// vite.config.ts
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 3000,
    proxy: {
      // Proxy API requests to backend
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\\/api/, '')
      }
    }
  },
  // Ensure YAML files are served correctly
  assetsInclude: ['**/*.yaml', '**/*.yml']
});
`;

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

/**
 * Generate Bearer token for testing
 */
export function generateTestToken(userId: string, role: string): string {
  // This is a mock token for development only
  // In production, obtain real JWT tokens from your auth server
  const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const payload = btoa(JSON.stringify({
    sub: userId,
    role: role,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + (60 * 60) // 1 hour
  }));
  const signature = 'mock_signature_for_testing';
  
  return `${header}.${payload}.${signature}`;
}

/**
 * Export Swagger spec as JSON
 */
export async function exportSwaggerAsJSON() {
  try {
    const yaml = await import('yaml');
    const fs = await import('fs');
    
    const yamlContent = fs.readFileSync('./src/schemas/swagger.yaml', 'utf8');
    const jsonContent = yaml.parse(yamlContent);
    
    fs.writeFileSync(
      './src/schemas/swagger.json',
      JSON.stringify(jsonContent, null, 2)
    );
    
    console.log('✅ Swagger JSON exported successfully');
  } catch (error) {
    console.error('❌ Failed to export Swagger JSON:', error);
  }
}

/**
 * Validate Swagger specification
 */
export async function validateSwaggerSpec() {
  try {
    const SwaggerParser = await import('@apidevtools/swagger-parser');
    const api = await SwaggerParser.default.validate('./src/schemas/swagger.yaml');
    console.log('✅ Swagger spec is valid!', api.info.title);
    return true;
  } catch (error) {
    console.error('❌ Swagger spec validation failed:', error);
    return false;
  }
}

// =============================================================================
// PACKAGE.JSON SCRIPTS
// =============================================================================

export const packageJsonScripts = {
  "swagger:validate": "swagger-cli validate src/schemas/swagger.yaml",
  "swagger:bundle": "swagger-cli bundle src/schemas/swagger.yaml -o src/schemas/swagger.json",
  "swagger:serve": "swagger-ui-watcher src/schemas/swagger.yaml",
  "api:docs": "npx redoc-cli serve src/schemas/swagger.yaml --watch"
};

// =============================================================================
// POSTMAN COLLECTION EXPORT
// =============================================================================

export const postmanCollectionInfo = `
# Export to Postman

## Method 1: Direct Import
1. Open Postman
2. Click "Import"
3. Select "Link" tab
4. Paste the Swagger spec URL
5. Click "Continue"

## Method 2: Convert YAML to JSON
1. Run: npm run swagger:bundle
2. Import the generated swagger.json file into Postman

## Method 3: Online Converter
1. Go to https://www.apimatic.io/transformer
2. Upload swagger.yaml
3. Select "Postman Collection v2.1" as output format
4. Download and import into Postman
`;

export default {
  swaggerConfig,
  installationGuide,
  swaggerUIComponentExample,
  viteConfigExample,
  generateTestToken,
  validateSwaggerSpec,
  packageJsonScripts,
  postmanCollectionInfo
};
