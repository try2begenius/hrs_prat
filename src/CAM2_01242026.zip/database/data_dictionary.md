# CAM Case Creation System - Data Dictionary

**Version:** 1.0  
**Date:** January 23, 2026  
**Database:** Oracle 19c or higher  
**Schema Owner:** CAM_SCHEMA

---

## Table of Contents
1. [CAM_PARTY_MASTER](#1-cam_party_master)
2. [CAM_POPULATION_TRIGGER](#2-cam_population_trigger)
3. [CAM_312_CASES](#3-cam_312_cases)
4. [CAM_CASES](#4-cam_cases)
5. [CAM_GFC_CASES](#5-cam_gfc_cases)
6. [CAM_CASE_GFC_LINK](#6-cam_case_gfc_link)
7. [CAM_REVIEW_HISTORY](#7-cam_review_history)
8. [CAM_ASSIGNMENT_HISTORY](#8-cam_assignment_history)
9. [CAM_LOB_CONFIG](#9-cam_lob_config)
10. [CAM_AUDIT_TRAIL](#10-cam_audit_trail)

---

## 1. CAM_PARTY_MASTER

**Purpose:** Master table for client/party information including LOB, risk ratings, and refresh schedules.

**Primary Key:** PARTY_ID

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| PARTY_ID | VARCHAR2(20) | No | - | PK | Unique internal party identifier (e.g., P12345) |
| CLIENT_ID | VARCHAR2(20) | No | - | UNIQUE | External client identifier (business key) (e.g., GB-10234, PB-20451) |
| LEGAL_NAME | VARCHAR2(500) | No | - | - | Legal name of the client/entity |
| LOB | VARCHAR2(20) | No | - | CHECK | Line of Business: 'GB/GM', 'PB', 'ML', 'Consumer', 'CI', 'Small Business' |
| RISK_RATING | VARCHAR2(20) | No | - | CHECK | Current risk rating: 'High', 'Elevated', 'Standard', 'Low' |
| REFRESH_DUE_DATE | DATE | Yes | - | - | Date when next refresh is due |
| REFRESH_ANNIVERSARY_MONTH | VARCHAR2(20) | Yes | - | - | Anniversary month for refresh (Small Business LOB) |
| DGA_DUE_DATE | DATE | Yes | - | - | DGA (Due Diligence Assessment) due date |
| GLOBAL_DGA_DUE_DATE | DATE | Yes | - | - | Global DGA due date (GB/GM LOB) |
| FAMILY_ANNIVERSARY_DATE | DATE | Yes | - | - | Family anniversary date for refresh scheduling |
| HAS_312_FLAG | CHAR(1) | Yes | 'N' | CHECK | Indicates if party is subject to 312 review ('Y' or 'N') |
| ACTIVE_STATUS | CHAR(1) | Yes | 'Y' | CHECK | Active status of party record ('Y' or 'N') |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |
| CREATED_BY | VARCHAR2(50) | Yes | - | - | User who created the record |
| MODIFIED_DATE | TIMESTAMP | Yes | - | - | Last modification timestamp |
| MODIFIED_BY | VARCHAR2(50) | Yes | - | - | User who last modified the record |

**Indexes:**
- IDX_PARTY_CLIENT_ID (CLIENT_ID)
- IDX_PARTY_LOB (LOB)
- IDX_PARTY_RISK (RISK_RATING)
- IDX_PARTY_REFRESH_DUE (REFRESH_DUE_DATE)

**Business Rules:**
- Each party must have a valid LOB and risk rating
- For Small Business LOB, REFRESH_ANNIVERSARY_MONTH is required
- For GB/GM LOB, GLOBAL_DGA_DUE_DATE typically drives case creation
- HAS_312_FLAG determines eligibility for 312 case creation

---

## 2. CAM_POPULATION_TRIGGER

**Purpose:** Tracks population identification triggers that initiate case creation based on LOB-specific rules.

**Primary Key:** TRIGGER_ID (auto-generated)

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| TRIGGER_ID | NUMBER | No | IDENTITY | PK | Auto-generated unique trigger identifier |
| PARTY_ID | VARCHAR2(20) | No | - | FK | Reference to CAM_PARTY_MASTER |
| TRIGGER_TYPE | VARCHAR2(30) | No | - | CHECK | Type of trigger: 'Refresh 180 Days', 'Refresh 120 Days', 'Refresh 95 Days', 'DGA Due Date', 'Manual Upload' |
| TRIGGER_DATE | DATE | No | - | - | Date when trigger was activated |
| DAYS_TO_REFRESH | NUMBER | Yes | - | - | Number of days until refresh due date at time of trigger |
| IS_MANUAL_UPLOAD | CHAR(1) | Yes | 'N' | CHECK | Flag indicating manual exception by CAM team ('Y' or 'N') |
| MANUAL_UPLOAD_REASON | VARCHAR2(1000) | Yes | - | - | Explanation for manual upload exception |
| TRIGGERED_BY | VARCHAR2(50) | Yes | - | - | User or system process that triggered |
| TRIGGER_STATUS | VARCHAR2(20) | Yes | 'Active' | CHECK | Status: 'Active', 'Processed', 'Cancelled' |
| CASES_CREATED_FLAG | CHAR(1) | Yes | 'N' | CHECK | Flag indicating if cases were created ('Y' or 'N') |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |
| CREATED_BY | VARCHAR2(50) | Yes | - | - | User who created the record |

**Indexes:**
- IDX_POP_PARTY_ID (PARTY_ID)
- IDX_POP_TRIGGER_DATE (TRIGGER_DATE)
- IDX_POP_STATUS (TRIGGER_STATUS)

**Foreign Keys:**
- FK_POP_PARTY → CAM_PARTY_MASTER(PARTY_ID)

**Business Rules:**
- PB/ML/CI LOB: High Risk clients trigger at 180 days before refresh
- Consumer LOB: High Risk clients trigger at 120 days before refresh
- Small Business LOB: Client-managed, triggers at 95 days before anniversary month
- GB/GM LOB: Triggers based on Global DGA Due Date
- Manual uploads bypass standard trigger logic

---

## 3. CAM_312_CASES

**Purpose:** 312 review cases with model alert evaluation and auto-closure logic.

**Primary Key:** CAM_312_CASE_ID

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| CAM_312_CASE_ID | VARCHAR2(30) | No | - | PK | Unique 312 case identifier (e.g., CAM312-2026-001) |
| PARTY_ID | VARCHAR2(20) | No | - | FK | Reference to CAM_PARTY_MASTER |
| TRIGGER_ID | NUMBER | Yes | - | FK | Reference to CAM_POPULATION_TRIGGER |
| CASE_STATUS | VARCHAR2(20) | No | - | CHECK | Current status: 'Unassigned', 'In Progress', 'Complete', 'Closed', 'Cancelled' |
| DECISION | VARCHAR2(20) | No | - | CHECK | Case decision: 'Full Review', 'Auto-Close', 'Not Applicable' |
| HAS_MODEL_ALERT | CHAR(1) | Yes | 'N' | CHECK | 'Y' if 312 model detected alert requiring manual review |
| AUTO_COMPLETE_FLAG | CHAR(1) | Yes | 'N' | CHECK | 'Y' if case was auto-closed without manual review |
| MODEL_OUTPUT | VARCHAR2(2000) | Yes | - | - | 312 model output message explaining decision |
| CASE_CREATED_DATE | DATE | No | - | - | Date case was created |
| CASE_ASSIGNED_DATE | DATE | Yes | - | - | Date case was assigned to analyst |
| CASE_COMPLETED_DATE | DATE | Yes | - | - | Date case was completed |
| ASSIGNED_TO | VARCHAR2(50) | Yes | - | - | User assigned to the case |
| COMPLETED_BY | VARCHAR2(50) | Yes | - | - | User who completed the case |
| DISPOSITION_CODE | VARCHAR2(50) | Yes | - | - | Final disposition code |
| DISPOSITION_NOTES | CLOB | Yes | - | - | Detailed disposition notes |
| SLA_DUE_DATE | DATE | Yes | - | - | Service Level Agreement due date |
| PRIORITY | VARCHAR2(20) | Yes | - | CHECK | Priority: 'High', 'Medium', 'Low' |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |
| CREATED_BY | VARCHAR2(50) | Yes | - | - | User who created the record |
| MODIFIED_DATE | TIMESTAMP | Yes | - | - | Last modification timestamp |
| MODIFIED_BY | VARCHAR2(50) | Yes | - | - | User who last modified the record |

**Indexes:**
- IDX_312_PARTY_ID (PARTY_ID)
- IDX_312_STATUS (CASE_STATUS)
- IDX_312_DECISION (DECISION)
- IDX_312_CREATED_DATE (CASE_CREATED_DATE)
- IDX_312_ASSIGNED_TO (ASSIGNED_TO)
- IDX_312_SLA_DUE (SLA_DUE_DATE)

**Foreign Keys:**
- FK_312_PARTY → CAM_PARTY_MASTER(PARTY_ID)
- FK_312_TRIGGER → CAM_POPULATION_TRIGGER(TRIGGER_ID)

**Business Rules:**
- HAS_MODEL_ALERT = 'Y' → DECISION must be 'Full Review'
- HAS_MODEL_ALERT = 'N' → DECISION = 'Auto-Close', AUTO_COMPLETE_FLAG = 'Y'
- Small Business LOB → DECISION = 'Not Applicable' (no 312 flag)
- Elevated/Standard risk → Case created but typically auto-closes
- Auto-closed cases still populate all data for visibility

---

## 4. CAM_CASES

**Purpose:** CAM review cases with GFC case evaluation and auto-closure logic.

**Primary Key:** CAM_CASE_ID

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| CAM_CASE_ID | VARCHAR2(30) | No | - | PK | Unique CAM case identifier (e.g., CAM-2026-001) |
| PARTY_ID | VARCHAR2(20) | No | - | FK | Reference to CAM_PARTY_MASTER |
| TRIGGER_ID | NUMBER | Yes | - | FK | Reference to CAM_POPULATION_TRIGGER |
| CAM_312_CASE_ID | VARCHAR2(30) | Yes | - | FK | Reference to related 312 case |
| CASE_STATUS | VARCHAR2(20) | No | - | CHECK | Current status: 'Unassigned', 'In Progress', 'Complete', 'Closed', 'Cancelled' |
| DECISION | VARCHAR2(20) | No | - | CHECK | Case decision: 'Full Review', 'Auto-Close', 'Pending 312', 'Not Applicable' |
| AUTO_COMPLETE_FLAG | CHAR(1) | Yes | 'N' | CHECK | 'Y' if case was auto-closed without manual review |
| GFC_COUNT_TOTAL | NUMBER | Yes | 0 | - | Total count of GFC cases in last 12 months |
| GFC_COUNT_OPEN | NUMBER | Yes | 0 | - | Count of open GFC cases |
| GFC_COUNT_NEW | NUMBER | Yes | 0 | - | Count of new/unreviewed GFC cases in last 12 months |
| HAD_312_NOT_AUTO_CLOSED | CHAR(1) | Yes | 'N' | CHECK | Flag if prior 312 case was not auto-closed ('Y' or 'N') |
| COMPLETED_CASES_12M | NUMBER | Yes | 0 | - | Count of completed GFC cases in last 12 months |
| HAS_SAR_12M | CHAR(1) | Yes | 'N' | CHECK | Flag if SAR filed in last 12 months ('Y' or 'N') |
| HAD_CAM_REVIEW_12M | CHAR(1) | Yes | 'N' | CHECK | Flag if CAM review conducted in last 12 months ('Y' or 'N') |
| CASE_CREATED_DATE | DATE | No | - | - | Date case was created |
| CASE_ASSIGNED_DATE | DATE | Yes | - | - | Date case was assigned to analyst |
| CASE_COMPLETED_DATE | DATE | Yes | - | - | Date case was completed |
| ASSIGNED_TO | VARCHAR2(50) | Yes | - | - | User assigned to the case |
| COMPLETED_BY | VARCHAR2(50) | Yes | - | - | User who completed the case |
| DISPOSITION_CODE | VARCHAR2(50) | Yes | - | - | Final disposition code |
| DISPOSITION_NOTES | CLOB | Yes | - | - | Detailed disposition notes |
| SLA_DUE_DATE | DATE | Yes | - | - | Service Level Agreement due date |
| PRIORITY | VARCHAR2(20) | Yes | - | CHECK | Priority: 'High', 'Medium', 'Low' |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |
| CREATED_BY | VARCHAR2(50) | Yes | - | - | User who created the record |
| MODIFIED_DATE | TIMESTAMP | Yes | - | - | Last modification timestamp |
| MODIFIED_BY | VARCHAR2(50) | Yes | - | - | User who last modified the record |

**Indexes:**
- IDX_CAM_PARTY_ID (PARTY_ID)
- IDX_CAM_312_CASE (CAM_312_CASE_ID)
- IDX_CAM_STATUS (CASE_STATUS)
- IDX_CAM_DECISION (DECISION)
- IDX_CAM_CREATED_DATE (CASE_CREATED_DATE)
- IDX_CAM_ASSIGNED_TO (ASSIGNED_TO)
- IDX_CAM_SLA_DUE (SLA_DUE_DATE)

**Foreign Keys:**
- FK_CAM_PARTY → CAM_PARTY_MASTER(PARTY_ID)
- FK_CAM_TRIGGER → CAM_POPULATION_TRIGGER(TRIGGER_ID)
- FK_CAM_312_CASE → CAM_312_CASES(CAM_312_CASE_ID)

**Business Rules:**
- **Full Review** if: GFC_COUNT_NEW >= 2 OR HAD_312_NOT_AUTO_CLOSED = 'Y' OR HAS_SAR_12M = 'Y'
- **Auto-Close** if: All GFC cases reviewed in prior CAM AND HAD_CAM_REVIEW_12M = 'Y'
- **Pending 312** if: 312 case is still in progress and CAM decision depends on outcome
- **Not Applicable** if: Risk rating is Elevated/Standard (not High)
- Auto-closed cases still create record with all data populated
- All monitoring data limited to 12-month window from CASE_CREATED_DATE

---

## 5. CAM_GFC_CASES

**Purpose:** Generic Findings Cases from various monitoring systems (Transaction Monitoring, Sanctions Screening, Name Screening, SAR, etc.)

**Primary Key:** GFC_CASE_ID

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| GFC_CASE_ID | VARCHAR2(30) | No | - | PK | Unique GFC case identifier (e.g., GFC-2026-001) |
| PARTY_ID | VARCHAR2(20) | No | - | FK | Reference to CAM_PARTY_MASTER |
| CASE_TYPE | VARCHAR2(50) | No | - | - | Type: 'Transaction Monitoring', 'Sanctions Screening', 'Name Screening', 'SAR', 'Negative News', etc. |
| OPENED_DATE | DATE | No | - | - | Date the GFC case was opened |
| CLOSED_DATE | DATE | Yes | - | - | Date the GFC case was closed (NULL if still open) |
| CASE_STATUS | VARCHAR2(20) | No | - | CHECK | Status: 'Open', 'Closed', 'Cancelled' |
| IS_IN_SCOPE | CHAR(1) | Yes | 'Y' | CHECK | Whether GFC case is in scope for CAM review (last 12 months) |
| IS_SAR | CHAR(1) | Yes | 'N' | CHECK | Flag indicating if this is a Suspicious Activity Report |
| PRIORITY | VARCHAR2(20) | Yes | - | - | Priority level |
| DISPOSITION_CODE | VARCHAR2(50) | Yes | - | - | Final disposition code |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |
| CREATED_BY | VARCHAR2(50) | Yes | - | - | User who created the record |
| MODIFIED_DATE | TIMESTAMP | Yes | - | - | Last modification timestamp |
| MODIFIED_BY | VARCHAR2(50) | Yes | - | - | User who last modified the record |

**Indexes:**
- IDX_GFC_PARTY_ID (PARTY_ID)
- IDX_GFC_STATUS (CASE_STATUS)
- IDX_GFC_OPENED_DATE (OPENED_DATE)
- IDX_GFC_TYPE (CASE_TYPE)
- IDX_GFC_IS_SAR (IS_SAR)

**Foreign Keys:**
- FK_GFC_PARTY → CAM_PARTY_MASTER(PARTY_ID)

**Business Rules:**
- IS_IN_SCOPE = 'Y' if OPENED_DATE within 12 months of CAM case creation
- IS_SAR = 'Y' triggers automatic Full Review decision for CAM case
- GFC cases can be linked to multiple CAM cases over time
- Open vs Closed status affects CAM decision logic

---

## 6. CAM_CASE_GFC_LINK

**Purpose:** Many-to-many relationship linking CAM cases to related GFC cases with review tracking.

**Primary Key:** LINK_ID (auto-generated)

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| LINK_ID | NUMBER | No | IDENTITY | PK | Auto-generated unique link identifier |
| CAM_CASE_ID | VARCHAR2(30) | No | - | FK | Reference to CAM_CASES |
| GFC_CASE_ID | VARCHAR2(30) | No | - | FK | Reference to CAM_GFC_CASES |
| WAS_REVIEWED | CHAR(1) | Yes | 'N' | CHECK | Flag if GFC was reviewed in this CAM case ('Y' or 'N') |
| REVIEWED_IN_PRIOR_CAM | CHAR(1) | Yes | 'N' | CHECK | Flag if GFC was already reviewed in a prior CAM case |
| PRIOR_CAM_CASE_ID | VARCHAR2(30) | Yes | - | - | Reference to prior CAM case that reviewed this GFC |
| LINKED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Date the link was created |
| LINKED_BY | VARCHAR2(50) | Yes | - | - | User who created the link |

**Indexes:**
- IDX_LINK_CAM_CASE (CAM_CASE_ID)
- IDX_LINK_GFC_CASE (GFC_CASE_ID)
- IDX_LINK_PRIOR_CAM (PRIOR_CAM_CASE_ID)

**Foreign Keys:**
- FK_LINK_CAM → CAM_CASES(CAM_CASE_ID)
- FK_LINK_GFC → CAM_GFC_CASES(GFC_CASE_ID)

**Unique Constraints:**
- UQ_CAM_GFC_LINK (CAM_CASE_ID, GFC_CASE_ID) - prevents duplicate links

**Business Rules:**
- REVIEWED_IN_PRIOR_CAM = 'Y' indicates GFC was covered in previous review
- If all linked GFCs have REVIEWED_IN_PRIOR_CAM = 'Y', CAM case may auto-close
- New GFCs (REVIEWED_IN_PRIOR_CAM = 'N') trigger Full Review decision

---

## 7. CAM_REVIEW_HISTORY

**Purpose:** Historical record of completed CAM and 312 reviews for trending and reporting.

**Primary Key:** REVIEW_ID (auto-generated)

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| REVIEW_ID | NUMBER | No | IDENTITY | PK | Auto-generated unique review identifier |
| CAM_CASE_ID | VARCHAR2(30) | No | - | FK | Reference to CAM_CASES |
| PARTY_ID | VARCHAR2(20) | No | - | FK | Reference to CAM_PARTY_MASTER |
| REVIEW_DATE | DATE | No | - | - | Date the review was completed |
| REVIEW_TYPE | VARCHAR2(30) | Yes | - | CHECK | Type: '312 Review', 'CAM Review', 'Combined Review' |
| GFC_CASES_REVIEWED | NUMBER | Yes | 0 | - | Count of GFC cases reviewed |
| DISPOSITION_CODE | VARCHAR2(50) | Yes | - | - | Final disposition code |
| DISPOSITION_SUMMARY | VARCHAR2(2000) | Yes | - | - | Summary of review outcome |
| REVIEWER_NAME | VARCHAR2(100) | Yes | - | - | Name of reviewer who completed the review |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |
| CREATED_BY | VARCHAR2(50) | Yes | - | - | User who created the record |

**Indexes:**
- IDX_HISTORY_CAM_CASE (CAM_CASE_ID)
- IDX_HISTORY_PARTY (PARTY_ID)
- IDX_HISTORY_REVIEW_DATE (REVIEW_DATE)

**Foreign Keys:**
- FK_HISTORY_CAM → CAM_CASES(CAM_CASE_ID)
- FK_HISTORY_PARTY → CAM_PARTY_MASTER(PARTY_ID)

**Business Rules:**
- Created when CAM or 312 case reaches 'Complete' status
- Used to determine HAD_CAM_REVIEW_12M flag for subsequent cases
- Provides audit trail of which GFC cases were reviewed

---

## 8. CAM_ASSIGNMENT_HISTORY

**Purpose:** Tracks case assignment changes over time for workload management and reporting.

**Primary Key:** ASSIGNMENT_ID (auto-generated)

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| ASSIGNMENT_ID | NUMBER | No | IDENTITY | PK | Auto-generated unique assignment identifier |
| CASE_ID | VARCHAR2(30) | No | - | - | Case identifier (either 312 or CAM case) |
| CASE_TYPE | VARCHAR2(10) | No | - | CHECK | Type: '312' or 'CAM' |
| ASSIGNED_TO | VARCHAR2(50) | No | - | - | User assigned to the case |
| ASSIGNED_BY | VARCHAR2(50) | Yes | - | - | User who made the assignment |
| ASSIGNMENT_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Date/time of assignment |
| UNASSIGNMENT_DATE | TIMESTAMP | Yes | - | - | Date/time of unassignment (NULL if still assigned) |
| ASSIGNMENT_REASON | VARCHAR2(500) | Yes | - | - | Reason for assignment/reassignment |
| IS_CURRENT | CHAR(1) | Yes | 'Y' | CHECK | Flag indicating if this is the current assignment |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |

**Indexes:**
- IDX_ASSIGN_CASE_ID (CASE_ID)
- IDX_ASSIGN_USER (ASSIGNED_TO)
- IDX_ASSIGN_CURRENT (IS_CURRENT)

**Business Rules:**
- IS_CURRENT = 'Y' for active assignment, 'N' for historical
- Only one record per CASE_ID should have IS_CURRENT = 'Y'
- When reassigning, previous assignment gets IS_CURRENT = 'N', UNASSIGNMENT_DATE populated

---

## 9. CAM_LOB_CONFIG

**Purpose:** Configuration table for LOB-specific population trigger rules and thresholds.

**Primary Key:** LOB_CODE

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| LOB_CODE | VARCHAR2(20) | No | - | PK | LOB code: 'PB', 'ML', 'CI', 'Consumer', 'GB/GM', 'Small Business' |
| LOB_NAME | VARCHAR2(100) | No | - | - | Full name of Line of Business |
| TRIGGER_TYPE | VARCHAR2(30) | No | - | - | Default trigger type for this LOB |
| DAYS_THRESHOLD | NUMBER | Yes | - | - | Number of days threshold for trigger (NULL for DGA-based) |
| REQUIRES_312 | CHAR(1) | Yes | 'Y' | CHECK | Whether 312 cases apply to this LOB ('Y' or 'N') |
| DESCRIPTION | VARCHAR2(500) | Yes | - | - | Description of trigger rule |
| ACTIVE_FLAG | CHAR(1) | Yes | 'Y' | CHECK | Whether this LOB configuration is active |
| CREATED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Record creation timestamp |
| MODIFIED_DATE | TIMESTAMP | Yes | - | - | Last modification timestamp |

**Initial Data:**
| LOB_CODE | LOB_NAME | TRIGGER_TYPE | DAYS_THRESHOLD | REQUIRES_312 |
|----------|----------|--------------|----------------|--------------|
| PB | Private Banking | Refresh 180 Days | 180 | Y |
| ML | Middle Market Lending | Refresh 180 Days | 180 | Y |
| CI | Commercial & Institutional | Refresh 180 Days | 180 | Y |
| Consumer | Consumer Banking | Refresh 120 Days | 120 | Y |
| GB/GM | Global Banking/Global Markets | DGA Due Date | NULL | Y |
| Small Business | Small Business | Refresh 95 Days | 95 | N |

**Business Rules:**
- Reference data table - changes require change control
- REQUIRES_312 = 'N' for Small Business (no 312 flag)
- DAYS_THRESHOLD = NULL for GB/GM (uses DGA due date instead)

---

## 10. CAM_AUDIT_TRAIL

**Purpose:** Comprehensive audit trail for all data changes across critical tables.

**Primary Key:** AUDIT_ID (auto-generated)

| Column Name | Data Type | Nullable | Default | Constraints | Description |
|------------|-----------|----------|---------|-------------|-------------|
| AUDIT_ID | NUMBER | No | IDENTITY | PK | Auto-generated unique audit identifier |
| TABLE_NAME | VARCHAR2(50) | No | - | - | Name of table where change occurred |
| RECORD_ID | VARCHAR2(30) | No | - | - | Primary key value of changed record |
| ACTION_TYPE | VARCHAR2(20) | No | - | CHECK | Type of action: 'INSERT', 'UPDATE', 'DELETE' |
| CHANGED_BY | VARCHAR2(50) | No | - | - | User who made the change |
| CHANGED_DATE | TIMESTAMP | Yes | CURRENT_TIMESTAMP | - | Date/time of change |
| OLD_VALUES | CLOB | Yes | - | - | JSON/XML of old column values (for UPDATE/DELETE) |
| NEW_VALUES | CLOB | Yes | - | - | JSON/XML of new column values (for INSERT/UPDATE) |
| CHANGE_REASON | VARCHAR2(500) | Yes | - | - | Reason for change (if provided) |

**Indexes:**
- IDX_AUDIT_TABLE (TABLE_NAME)
- IDX_AUDIT_RECORD (RECORD_ID)
- IDX_AUDIT_DATE (CHANGED_DATE)

**Business Rules:**
- Populated via database triggers on key tables
- OLD_VALUES and NEW_VALUES stored as JSON for flexibility
- Retention policy: 7 years for compliance

---

## Entity Relationship Diagram (ERD)

```
CAM_PARTY_MASTER
    |
    |-- 1:N --> CAM_POPULATION_TRIGGER
    |               |
    |-- 1:N --> CAM_312_CASES
    |               |
    |               |-- 1:1 --> CAM_CASES
    |                               |
    |-- 1:N --> CAM_GFC_CASES       |
                    |               |
                    |-- N:M --------|
                         (via CAM_CASE_GFC_LINK)
```

---

## Key Relationships

1. **CAM_PARTY_MASTER → CAM_POPULATION_TRIGGER** (1:N)
   - One party can have multiple population triggers over time

2. **CAM_POPULATION_TRIGGER → CAM_312_CASES** (1:1 or 1:N)
   - Each trigger creates one 312 case (if applicable)

3. **CAM_POPULATION_TRIGGER → CAM_CASES** (1:1 or 1:N)
   - Each trigger creates one CAM case

4. **CAM_312_CASES → CAM_CASES** (1:1)
   - Each 312 case may have a corresponding CAM case

5. **CAM_PARTY_MASTER → CAM_GFC_CASES** (1:N)
   - One party can have multiple GFC cases

6. **CAM_CASES ↔ CAM_GFC_CASES** (N:M via CAM_CASE_GFC_LINK)
   - Many-to-many: GFC cases can be reviewed in multiple CAM cases

---

## Naming Conventions

- **Tables:** `CAM_<entity>` (uppercase, snake_case)
- **Columns:** `<descriptive_name>` (uppercase, snake_case)
- **Primary Keys:** Always named after the entity (e.g., PARTY_ID, CAM_CASE_ID)
- **Foreign Keys:** Named `FK_<child_table>_<parent_table>`
- **Indexes:** Named `IDX_<table>_<column(s)>`
- **Constraints:** Named `CHK_<table>_<column>` or `UQ_<table>_<column>`

---

## Data Retention Policy

| Table | Retention Period | Archive Strategy |
|-------|------------------|------------------|
| CAM_PARTY_MASTER | Indefinite (soft delete) | Mark ACTIVE_STATUS = 'N' |
| CAM_312_CASES | 7 years | Archive to cold storage |
| CAM_CASES | 7 years | Archive to cold storage |
| CAM_GFC_CASES | 7 years | Archive to cold storage |
| CAM_AUDIT_TRAIL | 7 years | Archive to cold storage |
| CAM_REVIEW_HISTORY | 10 years | Archive to cold storage |

---

## Security Considerations

1. **Row-Level Security (RLS):** Implement Virtual Private Database (VPD) policies for role-based data access
2. **Column Encryption:** Encrypt sensitive columns (LEGAL_NAME, DISPOSITION_NOTES) using TDE
3. **Audit Triggers:** Create triggers on all critical tables to populate CAM_AUDIT_TRAIL
4. **Role-Based Grants:** Implement grants based on user roles (Analyst, Manager, Administrator)

---

## Performance Tuning Recommendations

1. **Partitioning:**
   - Partition CAM_312_CASES and CAM_CASES by CASE_CREATED_DATE (monthly)
   - Partition CAM_AUDIT_TRAIL by CHANGED_DATE (monthly)

2. **Statistics:**
   - Gather table statistics weekly
   - Enable dynamic sampling for complex queries

3. **Indexes:**
   - All provided indexes are essential for performance
   - Monitor and add function-based indexes as needed

---

## Change Log

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-01-23 | System Architect | Initial database schema and data dictionary |

---

**End of Data Dictionary**
