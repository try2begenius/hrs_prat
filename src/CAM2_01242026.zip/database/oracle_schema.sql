-- =====================================================
-- CAM CASE CREATION SYSTEM - ORACLE DATABASE SCHEMA
-- =====================================================
-- Version: 1.0
-- Date: 2026-01-23
-- Description: Database schema for 312 and CAM case creation workflow
-- =====================================================

-- =====================================================
-- 1. PARTY/CLIENT MASTER TABLE
-- =====================================================
CREATE TABLE CAM_PARTY_MASTER (
    PARTY_ID                VARCHAR2(20) PRIMARY KEY,
    CLIENT_ID               VARCHAR2(20) NOT NULL UNIQUE,
    LEGAL_NAME              VARCHAR2(500) NOT NULL,
    LOB                     VARCHAR2(20) NOT NULL CHECK (LOB IN ('GB/GM', 'PB', 'ML', 'Consumer', 'CI', 'Small Business')),
    RISK_RATING             VARCHAR2(20) NOT NULL CHECK (RISK_RATING IN ('High', 'Elevated', 'Standard', 'Low')),
    REFRESH_DUE_DATE        DATE,
    REFRESH_ANNIVERSARY_MONTH VARCHAR2(20),
    DGA_DUE_DATE            DATE,
    GLOBAL_DGA_DUE_DATE     DATE,
    FAMILY_ANNIVERSARY_DATE DATE,
    HAS_312_FLAG            CHAR(1) DEFAULT 'N' CHECK (HAS_312_FLAG IN ('Y', 'N')),
    ACTIVE_STATUS           CHAR(1) DEFAULT 'Y' CHECK (ACTIVE_STATUS IN ('Y', 'N')),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY              VARCHAR2(50),
    MODIFIED_DATE           TIMESTAMP,
    MODIFIED_BY             VARCHAR2(50),
    CONSTRAINT chk_refresh_date CHECK (REFRESH_DUE_DATE IS NOT NULL OR LOB = 'GB/GM')
);

CREATE INDEX IDX_PARTY_CLIENT_ID ON CAM_PARTY_MASTER(CLIENT_ID);
CREATE INDEX IDX_PARTY_LOB ON CAM_PARTY_MASTER(LOB);
CREATE INDEX IDX_PARTY_RISK ON CAM_PARTY_MASTER(RISK_RATING);
CREATE INDEX IDX_PARTY_REFRESH_DUE ON CAM_PARTY_MASTER(REFRESH_DUE_DATE);

COMMENT ON TABLE CAM_PARTY_MASTER IS 'Master table for client/party information including LOB, risk ratings, and refresh schedules';
COMMENT ON COLUMN CAM_PARTY_MASTER.PARTY_ID IS 'Unique internal party identifier';
COMMENT ON COLUMN CAM_PARTY_MASTER.CLIENT_ID IS 'External client identifier (business key)';
COMMENT ON COLUMN CAM_PARTY_MASTER.LOB IS 'Line of Business: GB/GM, PB, ML, Consumer, CI, Small Business';
COMMENT ON COLUMN CAM_PARTY_MASTER.RISK_RATING IS 'Current risk rating: High, Elevated, Standard, Low';
COMMENT ON COLUMN CAM_PARTY_MASTER.HAS_312_FLAG IS 'Indicates if party is subject to 312 review';

-- =====================================================
-- 2. POPULATION TRIGGER TRACKING
-- =====================================================
CREATE TABLE CAM_POPULATION_TRIGGER (
    TRIGGER_ID              NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    PARTY_ID                VARCHAR2(20) NOT NULL,
    TRIGGER_TYPE            VARCHAR2(30) NOT NULL CHECK (TRIGGER_TYPE IN ('Refresh 180 Days', 'Refresh 120 Days', 'Refresh 95 Days', 'DGA Due Date', 'Manual Upload')),
    TRIGGER_DATE            DATE NOT NULL,
    DAYS_TO_REFRESH         NUMBER,
    IS_MANUAL_UPLOAD        CHAR(1) DEFAULT 'N' CHECK (IS_MANUAL_UPLOAD IN ('Y', 'N')),
    MANUAL_UPLOAD_REASON    VARCHAR2(1000),
    TRIGGERED_BY            VARCHAR2(50),
    TRIGGER_STATUS          VARCHAR2(20) DEFAULT 'Active' CHECK (TRIGGER_STATUS IN ('Active', 'Processed', 'Cancelled')),
    CASES_CREATED_FLAG      CHAR(1) DEFAULT 'N' CHECK (CASES_CREATED_FLAG IN ('Y', 'N')),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY              VARCHAR2(50),
    CONSTRAINT FK_POP_PARTY FOREIGN KEY (PARTY_ID) REFERENCES CAM_PARTY_MASTER(PARTY_ID)
);

CREATE INDEX IDX_POP_PARTY_ID ON CAM_POPULATION_TRIGGER(PARTY_ID);
CREATE INDEX IDX_POP_TRIGGER_DATE ON CAM_POPULATION_TRIGGER(TRIGGER_DATE);
CREATE INDEX IDX_POP_STATUS ON CAM_POPULATION_TRIGGER(TRIGGER_STATUS);

COMMENT ON TABLE CAM_POPULATION_TRIGGER IS 'Tracks population identification triggers for case creation';
COMMENT ON COLUMN CAM_POPULATION_TRIGGER.TRIGGER_TYPE IS 'LOB-specific trigger type that initiated case creation';
COMMENT ON COLUMN CAM_POPULATION_TRIGGER.IS_MANUAL_UPLOAD IS 'Flag indicating manual exception by CAM team';

-- =====================================================
-- 3. CAM 312 CASES
-- =====================================================
CREATE TABLE CAM_312_CASES (
    CAM_312_CASE_ID         VARCHAR2(30) PRIMARY KEY,
    PARTY_ID                VARCHAR2(20) NOT NULL,
    TRIGGER_ID              NUMBER,
    CASE_STATUS             VARCHAR2(20) NOT NULL CHECK (CASE_STATUS IN ('Unassigned', 'In Progress', 'Complete', 'Closed', 'Cancelled')),
    DECISION                VARCHAR2(20) NOT NULL CHECK (DECISION IN ('Full Review', 'Auto-Close', 'Not Applicable')),
    HAS_MODEL_ALERT         CHAR(1) DEFAULT 'N' CHECK (HAS_MODEL_ALERT IN ('Y', 'N')),
    AUTO_COMPLETE_FLAG      CHAR(1) DEFAULT 'N' CHECK (AUTO_COMPLETE_FLAG IN ('Y', 'N')),
    MODEL_OUTPUT            VARCHAR2(2000),
    CASE_CREATED_DATE       DATE NOT NULL,
    CASE_ASSIGNED_DATE      DATE,
    CASE_COMPLETED_DATE     DATE,
    ASSIGNED_TO             VARCHAR2(50),
    COMPLETED_BY            VARCHAR2(50),
    DISPOSITION_CODE        VARCHAR2(50),
    DISPOSITION_NOTES       CLOB,
    SLA_DUE_DATE            DATE,
    PRIORITY                VARCHAR2(20) CHECK (PRIORITY IN ('High', 'Medium', 'Low')),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY              VARCHAR2(50),
    MODIFIED_DATE           TIMESTAMP,
    MODIFIED_BY             VARCHAR2(50),
    CONSTRAINT FK_312_PARTY FOREIGN KEY (PARTY_ID) REFERENCES CAM_PARTY_MASTER(PARTY_ID),
    CONSTRAINT FK_312_TRIGGER FOREIGN KEY (TRIGGER_ID) REFERENCES CAM_POPULATION_TRIGGER(TRIGGER_ID)
);

CREATE INDEX IDX_312_PARTY_ID ON CAM_312_CASES(PARTY_ID);
CREATE INDEX IDX_312_STATUS ON CAM_312_CASES(CASE_STATUS);
CREATE INDEX IDX_312_DECISION ON CAM_312_CASES(DECISION);
CREATE INDEX IDX_312_CREATED_DATE ON CAM_312_CASES(CASE_CREATED_DATE);
CREATE INDEX IDX_312_ASSIGNED_TO ON CAM_312_CASES(ASSIGNED_TO);
CREATE INDEX IDX_312_SLA_DUE ON CAM_312_CASES(SLA_DUE_DATE);

COMMENT ON TABLE CAM_312_CASES IS '312 review cases with model alert evaluation and auto-closure logic';
COMMENT ON COLUMN CAM_312_CASES.HAS_MODEL_ALERT IS 'Y if 312 model detected alert requiring manual review';
COMMENT ON COLUMN CAM_312_CASES.AUTO_COMPLETE_FLAG IS 'Y if case was auto-closed without manual review';
COMMENT ON COLUMN CAM_312_CASES.MODEL_OUTPUT IS '312 model output message explaining decision';

-- =====================================================
-- 4. CAM CASES
-- =====================================================
CREATE TABLE CAM_CASES (
    CAM_CASE_ID             VARCHAR2(30) PRIMARY KEY,
    PARTY_ID                VARCHAR2(20) NOT NULL,
    TRIGGER_ID              NUMBER,
    CAM_312_CASE_ID         VARCHAR2(30),
    CASE_STATUS             VARCHAR2(20) NOT NULL CHECK (CASE_STATUS IN ('Unassigned', 'In Progress', 'Complete', 'Closed', 'Cancelled')),
    DECISION                VARCHAR2(20) NOT NULL CHECK (DECISION IN ('Full Review', 'Auto-Close', 'Pending 312', 'Not Applicable')),
    AUTO_COMPLETE_FLAG      CHAR(1) DEFAULT 'N' CHECK (AUTO_COMPLETE_FLAG IN ('Y', 'N')),
    GFC_COUNT_TOTAL         NUMBER DEFAULT 0,
    GFC_COUNT_OPEN          NUMBER DEFAULT 0,
    GFC_COUNT_NEW           NUMBER DEFAULT 0,
    HAD_312_NOT_AUTO_CLOSED CHAR(1) DEFAULT 'N' CHECK (HAD_312_NOT_AUTO_CLOSED IN ('Y', 'N')),
    COMPLETED_CASES_12M     NUMBER DEFAULT 0,
    HAS_SAR_12M             CHAR(1) DEFAULT 'N' CHECK (HAS_SAR_12M IN ('Y', 'N')),
    HAD_CAM_REVIEW_12M      CHAR(1) DEFAULT 'N' CHECK (HAD_CAM_REVIEW_12M IN ('Y', 'N')),
    CASE_CREATED_DATE       DATE NOT NULL,
    CASE_ASSIGNED_DATE      DATE,
    CASE_COMPLETED_DATE     DATE,
    ASSIGNED_TO             VARCHAR2(50),
    COMPLETED_BY            VARCHAR2(50),
    DISPOSITION_CODE        VARCHAR2(50),
    DISPOSITION_NOTES       CLOB,
    SLA_DUE_DATE            DATE,
    PRIORITY                VARCHAR2(20) CHECK (PRIORITY IN ('High', 'Medium', 'Low')),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY              VARCHAR2(50),
    MODIFIED_DATE           TIMESTAMP,
    MODIFIED_BY             VARCHAR2(50),
    CONSTRAINT FK_CAM_PARTY FOREIGN KEY (PARTY_ID) REFERENCES CAM_PARTY_MASTER(PARTY_ID),
    CONSTRAINT FK_CAM_TRIGGER FOREIGN KEY (TRIGGER_ID) REFERENCES CAM_POPULATION_TRIGGER(TRIGGER_ID),
    CONSTRAINT FK_CAM_312_CASE FOREIGN KEY (CAM_312_CASE_ID) REFERENCES CAM_312_CASES(CAM_312_CASE_ID)
);

CREATE INDEX IDX_CAM_PARTY_ID ON CAM_CASES(PARTY_ID);
CREATE INDEX IDX_CAM_312_CASE ON CAM_CASES(CAM_312_CASE_ID);
CREATE INDEX IDX_CAM_STATUS ON CAM_CASES(CASE_STATUS);
CREATE INDEX IDX_CAM_DECISION ON CAM_CASES(DECISION);
CREATE INDEX IDX_CAM_CREATED_DATE ON CAM_CASES(CASE_CREATED_DATE);
CREATE INDEX IDX_CAM_ASSIGNED_TO ON CAM_CASES(ASSIGNED_TO);
CREATE INDEX IDX_CAM_SLA_DUE ON CAM_CASES(SLA_DUE_DATE);

COMMENT ON TABLE CAM_CASES IS 'CAM review cases with GFC case evaluation and auto-closure logic';
COMMENT ON COLUMN CAM_CASES.DECISION IS 'CAM decision: Full Review, Auto-Close, Pending 312, Not Applicable';
COMMENT ON COLUMN CAM_CASES.GFC_COUNT_NEW IS 'Count of new/unreviewed GFC cases in last 12 months';
COMMENT ON COLUMN CAM_CASES.HAD_312_NOT_AUTO_CLOSED IS 'Flag if prior 312 case was not auto-closed';

-- =====================================================
-- 5. GFC CASES (Generic Findings Cases)
-- =====================================================
CREATE TABLE CAM_GFC_CASES (
    GFC_CASE_ID             VARCHAR2(30) PRIMARY KEY,
    PARTY_ID                VARCHAR2(20) NOT NULL,
    CASE_TYPE               VARCHAR2(50) NOT NULL,
    OPENED_DATE             DATE NOT NULL,
    CLOSED_DATE             DATE,
    CASE_STATUS             VARCHAR2(20) NOT NULL CHECK (CASE_STATUS IN ('Open', 'Closed', 'Cancelled')),
    IS_IN_SCOPE             CHAR(1) DEFAULT 'Y' CHECK (IS_IN_SCOPE IN ('Y', 'N')),
    IS_SAR                  CHAR(1) DEFAULT 'N' CHECK (IS_SAR IN ('Y', 'N')),
    PRIORITY                VARCHAR2(20),
    DISPOSITION_CODE        VARCHAR2(50),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY              VARCHAR2(50),
    MODIFIED_DATE           TIMESTAMP,
    MODIFIED_BY             VARCHAR2(50),
    CONSTRAINT FK_GFC_PARTY FOREIGN KEY (PARTY_ID) REFERENCES CAM_PARTY_MASTER(PARTY_ID)
);

CREATE INDEX IDX_GFC_PARTY_ID ON CAM_GFC_CASES(PARTY_ID);
CREATE INDEX IDX_GFC_STATUS ON CAM_GFC_CASES(CASE_STATUS);
CREATE INDEX IDX_GFC_OPENED_DATE ON CAM_GFC_CASES(OPENED_DATE);
CREATE INDEX IDX_GFC_TYPE ON CAM_GFC_CASES(CASE_TYPE);
CREATE INDEX IDX_GFC_IS_SAR ON CAM_GFC_CASES(IS_SAR);

COMMENT ON TABLE CAM_GFC_CASES IS 'Generic Findings Cases (Transaction Monitoring, Sanctions Screening, Name Screening, SAR, etc.)';
COMMENT ON COLUMN CAM_GFC_CASES.IS_IN_SCOPE IS 'Whether GFC case is in scope for CAM review (last 12 months)';
COMMENT ON COLUMN CAM_GFC_CASES.IS_SAR IS 'Flag indicating if this is a Suspicious Activity Report';

-- =====================================================
-- 6. CAM CASE - GFC CASE RELATIONSHIP
-- =====================================================
CREATE TABLE CAM_CASE_GFC_LINK (
    LINK_ID                 NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    CAM_CASE_ID             VARCHAR2(30) NOT NULL,
    GFC_CASE_ID             VARCHAR2(30) NOT NULL,
    WAS_REVIEWED            CHAR(1) DEFAULT 'N' CHECK (WAS_REVIEWED IN ('Y', 'N')),
    REVIEWED_IN_PRIOR_CAM   CHAR(1) DEFAULT 'N' CHECK (REVIEWED_IN_PRIOR_CAM IN ('Y', 'N')),
    PRIOR_CAM_CASE_ID       VARCHAR2(30),
    LINKED_DATE             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    LINKED_BY               VARCHAR2(50),
    CONSTRAINT FK_LINK_CAM FOREIGN KEY (CAM_CASE_ID) REFERENCES CAM_CASES(CAM_CASE_ID),
    CONSTRAINT FK_LINK_GFC FOREIGN KEY (GFC_CASE_ID) REFERENCES CAM_GFC_CASES(GFC_CASE_ID),
    CONSTRAINT UQ_CAM_GFC_LINK UNIQUE (CAM_CASE_ID, GFC_CASE_ID)
);

CREATE INDEX IDX_LINK_CAM_CASE ON CAM_CASE_GFC_LINK(CAM_CASE_ID);
CREATE INDEX IDX_LINK_GFC_CASE ON CAM_CASE_GFC_LINK(GFC_CASE_ID);
CREATE INDEX IDX_LINK_PRIOR_CAM ON CAM_CASE_GFC_LINK(PRIOR_CAM_CASE_ID);

COMMENT ON TABLE CAM_CASE_GFC_LINK IS 'Links CAM cases to related GFC cases with review tracking';
COMMENT ON COLUMN CAM_CASE_GFC_LINK.REVIEWED_IN_PRIOR_CAM IS 'Flag if GFC was already reviewed in a prior CAM case';

-- =====================================================
-- 7. PRIOR CAM REVIEW HISTORY
-- =====================================================
CREATE TABLE CAM_REVIEW_HISTORY (
    REVIEW_ID               NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    CAM_CASE_ID             VARCHAR2(30) NOT NULL,
    PARTY_ID                VARCHAR2(20) NOT NULL,
    REVIEW_DATE             DATE NOT NULL,
    REVIEW_TYPE             VARCHAR2(30) CHECK (REVIEW_TYPE IN ('312 Review', 'CAM Review', 'Combined Review')),
    GFC_CASES_REVIEWED      NUMBER DEFAULT 0,
    DISPOSITION_CODE        VARCHAR2(50),
    DISPOSITION_SUMMARY     VARCHAR2(2000),
    REVIEWER_NAME           VARCHAR2(100),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY              VARCHAR2(50),
    CONSTRAINT FK_HISTORY_CAM FOREIGN KEY (CAM_CASE_ID) REFERENCES CAM_CASES(CAM_CASE_ID),
    CONSTRAINT FK_HISTORY_PARTY FOREIGN KEY (PARTY_ID) REFERENCES CAM_PARTY_MASTER(PARTY_ID)
);

CREATE INDEX IDX_HISTORY_CAM_CASE ON CAM_REVIEW_HISTORY(CAM_CASE_ID);
CREATE INDEX IDX_HISTORY_PARTY ON CAM_REVIEW_HISTORY(PARTY_ID);
CREATE INDEX IDX_HISTORY_REVIEW_DATE ON CAM_REVIEW_HISTORY(REVIEW_DATE);

COMMENT ON TABLE CAM_REVIEW_HISTORY IS 'Historical record of completed CAM and 312 reviews';

-- =====================================================
-- 8. CASE ASSIGNMENT HISTORY
-- =====================================================
CREATE TABLE CAM_ASSIGNMENT_HISTORY (
    ASSIGNMENT_ID           NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    CASE_ID                 VARCHAR2(30) NOT NULL,
    CASE_TYPE               VARCHAR2(10) NOT NULL CHECK (CASE_TYPE IN ('312', 'CAM')),
    ASSIGNED_TO             VARCHAR2(50) NOT NULL,
    ASSIGNED_BY             VARCHAR2(50),
    ASSIGNMENT_DATE         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNASSIGNMENT_DATE       TIMESTAMP,
    ASSIGNMENT_REASON       VARCHAR2(500),
    IS_CURRENT              CHAR(1) DEFAULT 'Y' CHECK (IS_CURRENT IN ('Y', 'N')),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IDX_ASSIGN_CASE_ID ON CAM_ASSIGNMENT_HISTORY(CASE_ID);
CREATE INDEX IDX_ASSIGN_USER ON CAM_ASSIGNMENT_HISTORY(ASSIGNED_TO);
CREATE INDEX IDX_ASSIGN_CURRENT ON CAM_ASSIGNMENT_HISTORY(IS_CURRENT);

COMMENT ON TABLE CAM_ASSIGNMENT_HISTORY IS 'Tracks case assignment changes over time';

-- =====================================================
-- 9. REFERENCE DATA - LOB CONFIGURATION
-- =====================================================
CREATE TABLE CAM_LOB_CONFIG (
    LOB_CODE                VARCHAR2(20) PRIMARY KEY,
    LOB_NAME                VARCHAR2(100) NOT NULL,
    TRIGGER_TYPE            VARCHAR2(30) NOT NULL,
    DAYS_THRESHOLD          NUMBER,
    REQUIRES_312            CHAR(1) DEFAULT 'Y' CHECK (REQUIRES_312 IN ('Y', 'N')),
    DESCRIPTION             VARCHAR2(500),
    ACTIVE_FLAG             CHAR(1) DEFAULT 'Y' CHECK (ACTIVE_FLAG IN ('Y', 'N')),
    CREATED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    MODIFIED_DATE           TIMESTAMP
);

COMMENT ON TABLE CAM_LOB_CONFIG IS 'Configuration table for LOB-specific population trigger rules';

-- Initial LOB Configuration Data
INSERT INTO CAM_LOB_CONFIG (LOB_CODE, LOB_NAME, TRIGGER_TYPE, DAYS_THRESHOLD, REQUIRES_312, DESCRIPTION) VALUES
('PB', 'Private Banking', 'Refresh 180 Days', 180, 'Y', 'High Risk clients with refresh due within 180 calendar days'),
('ML', 'Middle Market Lending', 'Refresh 180 Days', 180, 'Y', 'High Risk clients with refresh due within 180 calendar days'),
('CI', 'Commercial & Institutional', 'Refresh 180 Days', 180, 'Y', 'High Risk clients with refresh due within 180 calendar days'),
('Consumer', 'Consumer Banking', 'Refresh 120 Days', 120, 'Y', 'High Risk clients with refresh due within 120 calendar days'),
('GB/GM', 'Global Banking/Global Markets', 'DGA Due Date', NULL, 'Y', 'Global DGA Due Date triggers case creation'),
('Small Business', 'Small Business', 'Refresh 95 Days', 95, 'N', 'Client-managed, 95 days before refresh anniversary month');

COMMIT;

-- =====================================================
-- 10. AUDIT TRAIL TABLE
-- =====================================================
CREATE TABLE CAM_AUDIT_TRAIL (
    AUDIT_ID                NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    TABLE_NAME              VARCHAR2(50) NOT NULL,
    RECORD_ID               VARCHAR2(30) NOT NULL,
    ACTION_TYPE             VARCHAR2(20) NOT NULL CHECK (ACTION_TYPE IN ('INSERT', 'UPDATE', 'DELETE')),
    CHANGED_BY              VARCHAR2(50) NOT NULL,
    CHANGED_DATE            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    OLD_VALUES              CLOB,
    NEW_VALUES              CLOB,
    CHANGE_REASON           VARCHAR2(500)
);

CREATE INDEX IDX_AUDIT_TABLE ON CAM_AUDIT_TRAIL(TABLE_NAME);
CREATE INDEX IDX_AUDIT_RECORD ON CAM_AUDIT_TRAIL(RECORD_ID);
CREATE INDEX IDX_AUDIT_DATE ON CAM_AUDIT_TRAIL(CHANGED_DATE);

COMMENT ON TABLE CAM_AUDIT_TRAIL IS 'Comprehensive audit trail for all data changes';

-- =====================================================
-- SEQUENCES (Alternative to IDENTITY if needed)
-- =====================================================
-- These are auto-generated by IDENTITY columns in Oracle 12c+
-- If using Oracle 11g or earlier, create sequences manually:
/*
CREATE SEQUENCE SEQ_POPULATION_TRIGGER START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SEQ_CAM_GFC_LINK START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SEQ_REVIEW_HISTORY START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SEQ_ASSIGNMENT_HISTORY START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SEQ_AUDIT_TRAIL START WITH 1 INCREMENT BY 1;
*/

-- =====================================================
-- GRANTS (Adjust based on your security model)
-- =====================================================
-- Example grants to application roles
/*
GRANT SELECT, INSERT, UPDATE ON CAM_PARTY_MASTER TO CAM_APP_ROLE;
GRANT SELECT, INSERT, UPDATE ON CAM_312_CASES TO CAM_APP_ROLE;
GRANT SELECT, INSERT, UPDATE ON CAM_CASES TO CAM_APP_ROLE;
GRANT SELECT ON CAM_LOB_CONFIG TO CAM_APP_ROLE;
*/

-- =====================================================
-- END OF SCHEMA
-- =====================================================
