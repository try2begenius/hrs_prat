# CAM Platform - Roles & Entitlements Logic

**Version:** 1.0  
**Date:** January 23, 2026  
**Purpose:** Complete documentation of role-based access control (RBAC) logic for all pages

---

## Table of Contents
1. [Role Definitions](#role-definitions)
2. [Page Access Matrix](#page-access-matrix)
3. [Entitlements System](#entitlements-system)
4. [Implementation Logic](#implementation-logic)
5. [User Examples](#user-examples)
6. [Access Control Flows](#access-control-flows)

---

## 1. Role Definitions

### Four Core Roles

#### **1.1 Central Team Analyst**
**Purpose:** Front-line case reviewers who perform daily case analysis

**Permissions:**
| Permission | Access | Description |
|------------|--------|-------------|
| viewDashboard | ✅ Yes | Can view dashboard and metrics |
| viewWorklist | ✅ Yes | Can view case worklist and individual worklist |
| openCases | ✅ Yes | Can open and view case details |
| reviewData | ✅ Yes | Can review all case data |
| actionCases | ✅ Yes | Can complete dispositions and take actions |
| assignCases | ❌ No | Cannot assign cases to others |
| reassignCases | ❌ No | Cannot reassign cases |
| reopenCases | ❌ No | Cannot reopen completed cases |
| abandonCases | ❌ No | Cannot abandon cases |
| salesFeedback | ❌ No | Cannot provide sales feedback |
| returnToAnalyst | ❌ No | Cannot return cases to analyst |

**Use Case:** Analysts work their assigned cases, review GFC activity, complete 312/CAM reviews, and submit dispositions.

---

#### **1.2 Central Team Manager**
**Purpose:** Supervisory role with full case management and quality control capabilities

**Permissions:**
| Permission | Access | Description |
|------------|--------|-------------|
| viewDashboard | ✅ Yes | Can view dashboard and metrics |
| viewWorklist | ✅ Yes | Can view all worklists |
| openCases | ✅ Yes | Can open and view case details |
| reviewData | ✅ Yes | Can review all case data |
| actionCases | ✅ Yes | Can complete dispositions |
| assignCases | ✅ Yes | **Can assign unassigned cases to analysts** |
| reassignCases | ✅ Yes | **Can reassign cases between analysts** |
| reopenCases | ✅ Yes | **Can reopen completed cases for remediation** |
| abandonCases | ✅ Yes | **Can abandon cases** |
| salesFeedback | ❌ No | Cannot provide sales feedback |
| returnToAnalyst | ❌ No | Cannot return cases to analyst |

**Additional Access:**
- Access to Administration pages: System Integrations, Roles & Entitlements
- Can request manual case creation
- Can access employee cases (if entitlement granted)

**Use Case:** Managers oversee workload distribution, perform quality reviews, remediate errors, and manage system configuration.

---

#### **1.3 View Only**
**Purpose:** Read-only access for auditors, compliance officers, or oversight functions

**Permissions:**
| Permission | Access | Description |
|------------|--------|-------------|
| viewDashboard | ✅ Yes | Can view dashboard and metrics |
| viewWorklist | ✅ Yes | Can view all worklists |
| openCases | ✅ Yes | Can open and view case details |
| reviewData | ✅ Yes | Can review all case data |
| actionCases | ❌ No | **Cannot take any actions** |
| assignCases | ❌ No | Cannot assign cases |
| reassignCases | ❌ No | Cannot reassign cases |
| reopenCases | ❌ No | Cannot reopen cases |
| abandonCases | ❌ No | Cannot abandon cases |
| salesFeedback | ❌ No | Cannot provide sales feedback |
| returnToAnalyst | ❌ No | Cannot return cases |

**Use Case:** Compliance oversight, audit reviews, executive visibility without ability to modify cases.

---

#### **1.4 Sales Owner**
**Purpose:** Business line representatives who provide client context and feedback

**Permissions:**
| Permission | Access | Description |
|------------|--------|-------------|
| viewDashboard | ❌ No | **No dashboard access** |
| viewWorklist | ✅ Yes | Can view their sales review worklist only |
| openCases | ✅ Yes | Can open cases sent for sales review |
| reviewData | ✅ Yes | Can review case data |
| actionCases | ❌ No | Cannot complete dispositions |
| assignCases | ❌ No | Cannot assign cases |
| reassignCases | ❌ No | Cannot reassign cases |
| reopenCases | ❌ No | Cannot reopen cases |
| abandonCases | ❌ No | Cannot abandon cases |
| salesFeedback | ✅ Yes | **Can provide sales feedback** |
| returnToAnalyst | ✅ Yes | **Can return cases to central team** |

**Special UI:**
- Shows **Sales Owner Worklist** instead of standard worklist
- Only sees cases in "Pending Sales Review" status for their LOB
- Different action buttons: "Provide Feedback" and "Return to Analyst"
- **Tab Restrictions:** Can ONLY view the "Client/Case Details" tab and "Sales Review" tab
- **312 and CAM tabs are BLOCKED** - Sales Owners cannot access 312 or CAM review sections

**Use Case:** Sales provides client insights, explains unusual activity, and returns cases to analysts for completion.

---

## 2. Page Access Matrix

### Navigation Menu Visibility

| Page | Central Team Analyst | Central Team Manager | View Only | Sales Owner |
|------|---------------------|---------------------|-----------|-------------|
| **Dashboard** | ✅ Visible | ✅ Visible | ✅ Visible | ❌ Hidden |
| **My Cases** | ✅ Visible | ✅ Visible | ✅ Visible | ✅ Visible* |
| **Case Worklist** | ✅ Visible | ✅ Visible | ✅ Visible | ❌ Hidden |
| **Population ID** | ✅ Visible | ✅ Visible | ✅ Visible | ❌ Hidden |
| **Case Creation** | ✅ Visible | ✅ Visible | ✅ Visible | ❌ Hidden |
| **Reports** | ✅ Visible | ✅ Visible | ✅ Visible | ❌ Hidden |
| **Notifications** | ✅ Visible | ✅ Visible | ✅ Visible | ✅ Visible |
| **Workflow Diagram** | ✅ Visible | ✅ Visible | ✅ Visible | ✅ Visible |
| **Integrations** | ❌ Hidden | ✅ Visible | ❌ Hidden | ❌ Hidden |
| **Roles & Entitlements** | ❌ Hidden | ✅ Visible | ❌ Hidden | ❌ Hidden |

*Sales Owner sees "My Cases" but it shows **Sales Owner Worklist** with different UI

---

### Page-Level Access Control Logic

```typescript
// From App.tsx - Menu Item Filtering Logic

const menuItems = [
  { 
    icon: LayoutDashboard, 
    label: 'Dashboard', 
    value: 'dashboard', 
    permission: permissions.viewDashboard  // FALSE for Sales Owner
  },
  { 
    icon: Briefcase, 
    label: 'My Cases', 
    value: 'my-cases', 
    permission: permissions.viewWorklist   // TRUE for all roles
  },
  { 
    icon: FileText, 
    label: 'Case Worklist', 
    value: 'worklist', 
    permission: permissions.viewWorklist   // TRUE except Sales Owner (they get My Cases instead)
  },
  { 
    icon: Users, 
    label: 'Population ID', 
    value: 'populations', 
    permission: permissions.viewDashboard  // FALSE for Sales Owner
  },
  { 
    icon: Workflow, 
    label: 'Case Creation', 
    value: 'case-creation', 
    permission: permissions.viewDashboard  // FALSE for Sales Owner
  },
  { 
    icon: BarChart3, 
    label: 'Reports', 
    value: 'reports', 
    permission: permissions.viewDashboard  // FALSE for Sales Owner
  },
  { 
    icon: Bell, 
    label: 'Notifications', 
    value: 'notifications', 
    permission: true                       // TRUE for all roles
  },
  { 
    icon: GitBranch, 
    label: 'Workflow Diagram', 
    value: 'workflow-diagram', 
    permission: true                       // TRUE for all roles
  }
];

const adminMenuItems = [
  { 
    icon: Settings, 
    label: 'Integrations', 
    value: 'integrations', 
    permission: currentUser.role === 'Central Team Manager'  // Managers only
  },
  { 
    icon: KeyRound, 
    label: 'Roles & Entitlements', 
    value: 'roles', 
    permission: currentUser.role === 'Central Team Manager'  // Managers only
  }
];

// Filter visible items based on permissions
const visibleMenuItems = menuItems.filter(item => item.permission);
const visibleAdminItems = adminMenuItems.filter(item => item.permission);
```

---

## 3. Entitlements System

Entitlements are **granular permissions** layered on top of roles to control:
- Which **case types** a user can access (312 vs CAM)
- Which **LOBs** a user can work with
- Special access to **Employee Cases**
- Ability to **manually create cases**

### Entitlement Categories

#### **3.1 Case Type Entitlements**

**312 Access (ENT-001)**
- **Description:** Access to 312 review cases
- **Restriction Level:** Optional
- **Logic:** If `has312Access = false`, user cannot see 312 cases in worklist or case details

**CAM Access (ENT-002)**
- **Description:** Access to CAM review cases
- **Restriction Level:** Optional
- **Logic:** If `hasCAMAccess = false`, user cannot see CAM cases in worklist or case details

---

#### **3.2 LOB Entitlements**

**Available LOBs:**
- GB/GM (Global Banking / Global Markets) - ENT-003
- PB (Private Banking) - ENT-004
- ML (Merrill Lynch) - ENT-005
- Consumer - ENT-006
- CI (Consumer Investments) - ENT-007

**Logic:**
```typescript
// Filter cases based on user's LOB entitlements
const userAccessibleCases = allCases.filter(case => {
  return currentUser.entitlements.lobs.includes(case.lob);
});
```

**Example:**
- User with `lobs: ['GB/GM', 'PB']` can only see and action cases for GB/GM and PB clients
- User with `lobs: ['ML', 'Consumer', 'CI']` can only see ML, Consumer, and CI cases

---

#### **3.3 Special Access Entitlements**

**Employee Cases Access (ENT-008)**
- **Description:** Access to review cases for employees or affiliates
- **Restriction Level:** Limited (only granted to trusted users)
- **Logic:** Special filtering and handling for sensitive employee-related cases

**Manual Case Creation (ENT-009)**
- **Description:** Ability to request manual case creation ad-hoc
- **Restriction Level:** Limited (typically managers only)
- **UI Impact:** Shows "Request Manual Case" button in Population Identification page

---

### Entitlement Enforcement Logic

```typescript
// Example: Case Worklist Filtering
const getFilteredCases = (allCases: Case[], currentUser: UserAccess): Case[] => {
  return allCases.filter(case => {
    // Check case type entitlement
    if (case.caseType === '312' && !currentUser.entitlements.has312Access) {
      return false; // User cannot see 312 cases
    }
    
    if (case.caseType === 'CAM' && !currentUser.entitlements.hasCAMAccess) {
      return false; // User cannot see CAM cases
    }
    
    // Check LOB entitlement
    if (!currentUser.entitlements.lobs.includes(case.lob)) {
      return false; // User cannot see cases outside their LOBs
    }
    
    // Check employee case access
    if (case.isEmployeeCase && !currentUser.entitlements.hasEmployeeCaseAccess) {
      return false; // User cannot see employee cases
    }
    
    return true; // User has access to this case
  });
};
```

---

## 4. Implementation Logic

### 4.1 Page Rendering Logic

```typescript
// From App.tsx - Dynamic Page Rendering

{currentPage === 'dashboard' && <Dashboard currentUser={currentUser} />}

{currentPage === 'my-cases' && (
  // Different component based on role
  currentUser.role === 'Sales Owner' ? (
    <SalesOwnerWorklist 
      onViewCase={handleViewCase} 
      currentUser={currentUser}
    />
  ) : (
    <IndividualWorklist 
      onViewCase={handleViewCase} 
      currentUser={currentUser}
      onCaseAssigned={handleCaseAssigned}
    />
  )
)}

{currentPage === 'worklist' && (
  <CaseWorklist 
    onViewCase={handleViewCase} 
    currentUser={currentUser} 
    onCaseAssigned={handleCaseAssigned}
  />
)}

{currentPage === 'case-details' && (
  <CaseDetailsEnhanced 
    caseId={selectedCaseId} 
    onBack={handleBackToWorklist} 
    currentUser={currentUser} 
  />
)}

{currentPage === 'populations' && <PopulationIdentification />}
{currentPage === 'case-creation' && <CaseCreationLogic />}
{currentPage === 'reports' && <Reports currentUser={currentUser} />}
{currentPage === 'notifications' && <Notifications currentUser={currentUser} />}
{currentPage === 'integrations' && <SystemIntegrations />}
{currentPage === 'roles' && <RolesEntitlements />}
{currentPage === 'workflow-diagram' && <WorkflowDiagram />}
```

---

### 4.2 Component-Level Access Control

#### **Dashboard Component**
```typescript
// Displays different metrics based on role
- Central Team Analyst: Shows assigned cases, SLA alerts
- Central Team Manager: Shows team metrics, all cases, unassigned queue
- View Only: Shows overview metrics, no action buttons
- Sales Owner: N/A (no access)
```

#### **Case Worklist Component**
```typescript
// Action buttons visible based on permissions
{permissions.assignCases && (
  <Button onClick={handleAssign}>Assign Case</Button>
)}

{permissions.reassignCases && (
  <Button onClick={handleReassign}>Reassign</Button>
)}

// Filter cases by entitlements
const visibleCases = cases.filter(c => 
  currentUser.entitlements.lobs.includes(c.lob) &&
  (c.caseType === '312' ? currentUser.entitlements.has312Access : true) &&
  (c.caseType === 'CAM' ? currentUser.entitlements.hasCAMAccess : true)
);
```

#### **Case Details Component**
```typescript
// Disposition actions based on role
{permissions.actionCases && case.status === 'In Progress' && (
  <Button onClick={handleSubmitDisposition}>Submit Disposition</Button>
)}

{permissions.reopenCases && case.status === 'Complete' && (
  <Button onClick={handleReopen}>Reopen Case</Button>
)}

{permissions.salesFeedback && case.status === 'Pending Sales Review' && (
  <Button onClick={handleProvideFeedback}>Provide Feedback</Button>
)}

{permissions.returnToAnalyst && case.status === 'Pending Sales Review' && (
  <Button onClick={handleReturnToAnalyst}>Return to Analyst</Button>
)}
```

---

### 4.3 Helper Function: Get Permissions for Role

```typescript
export const getPermissionsForRole = (role: RoleDefinition['type']): RoleDefinition['permissions'] => {
  const roleDefinition = roleDefinitions.find(r => r.type === role);
  
  // Default deny all if role not found
  return roleDefinition?.permissions || {
    viewDashboard: false,
    viewWorklist: false,
    openCases: false,
    reviewData: false,
    actionCases: false,
    assignCases: false,
    reassignCases: false,
    reopenCases: false,
    abandonCases: false,
    salesFeedback: false,
    returnToAnalyst: false
  };
};
```

---

## 5. User Examples

### **Example 1: Michael Chen - Central Team Analyst**

**Profile:**
```typescript
{
  name: 'Michael Chen',
  role: 'Central Team Analyst',
  entitlements: {
    has312Access: true,
    hasCAMAccess: true,
    lobs: ['GB/GM', 'PB'],
    hasEmployeeCaseAccess: false,
    hasManualCaseCreation: false
  }
}
```

**What Michael Can Do:**
- ✅ View Dashboard with his assigned cases
- ✅ See "My Cases" (Individual Worklist) with cases assigned to him
- ✅ See "Case Worklist" but filtered to GB/GM and PB cases only
- ✅ Open and review both 312 and CAM cases
- ✅ Complete dispositions and submit reviews
- ✅ View Population ID and Case Creation logic pages
- ❌ Cannot assign/reassign cases
- ❌ Cannot see ML, Consumer, or CI cases
- ❌ Cannot access employee cases
- ❌ Cannot access admin pages (Integrations, Roles & Entitlements)

---

### **Example 2: Sarah Mitchell - Central Team Manager**

**Profile:**
```typescript
{
  name: 'Sarah Mitchell',
  role: 'Central Team Manager',
  entitlements: {
    has312Access: true,
    hasCAMAccess: true,
    lobs: ['GB/GM', 'PB', 'ML'],
    hasEmployeeCaseAccess: true,
    hasManualCaseCreation: true
  }
}
```

**What Sarah Can Do:**
- ✅ View Dashboard with full team metrics
- ✅ See all cases for GB/GM, PB, and ML LOBs
- ✅ Assign unassigned cases to analysts
- ✅ Reassign cases between team members
- ✅ Reopen completed cases for quality remediation
- ✅ Abandon cases if needed
- ✅ Access employee cases (special entitlement)
- ✅ Request manual case creation
- ✅ Access System Integrations page
- ✅ Access Roles & Entitlements management page
- ❌ Cannot see Consumer or CI cases (not in LOB entitlements)

---

### **Example 3: David Park - Sales Owner**

**Profile:**
```typescript
{
  name: 'David Park',
  role: 'Sales Owner',
  entitlements: {
    has312Access: true,
    hasCAMAccess: false,
    lobs: ['GB/GM'],
    hasEmployeeCaseAccess: false,
    hasManualCaseCreation: false
  }
}
```

**What David Can Do:**
- ❌ No access to Dashboard
- ✅ See "My Cases" which shows **Sales Owner Worklist**
- ✅ Only sees 312 cases (no CAM access) in "Pending Sales Review" status for GB/GM
- ✅ Open cases sent to him for sales feedback
- ✅ Provide client context and feedback
- ✅ Return cases to central team analyst
- ✅ View Notifications
- ✅ View Workflow Diagram
- ❌ Cannot complete dispositions or action cases
- ❌ Cannot see full worklist
- ❌ Cannot see cases outside GB/GM LOB

---

### **Example 4: Robert Anderson - View Only**

**Profile:**
```typescript
{
  name: 'Robert Anderson',
  role: 'View Only',
  entitlements: {
    has312Access: true,
    hasCAMAccess: true,
    lobs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
    hasEmployeeCaseAccess: false,
    hasManualCaseCreation: false
  }
}
```

**What Robert Can Do:**
- ✅ View Dashboard (read-only)
- ✅ See all cases across all LOBs (broadest access for oversight)
- ✅ Open and review both 312 and CAM cases
- ✅ View all case details and history
- ✅ View reports and analytics
- ❌ **No action buttons visible** - cannot disposition, assign, or modify cases
- ❌ Cannot access admin pages

---

## 6. Access Control Flows

### Flow 1: User Logs In

```
1. User authenticates
2. System loads user profile from mockUsers array
3. System calls getPermissionsForRole(user.role)
4. Permissions object stored in component state
5. Menu items filtered based on permissions
6. User sees only authorized navigation items
```

---

### Flow 2: User Switches Role (Demo Mode)

```
1. User selects different user from dropdown
2. handleUserChange(userId) called
3. New user profile loaded
4. New permissions calculated
5. currentPage reset to 'dashboard'
6. Menu items re-filtered
7. UI re-renders with new role's view
```

---

### Flow 3: User Opens Worklist

```
1. User clicks "Case Worklist"
2. CaseWorklist component receives currentUser prop
3. Component filters cases:
   - Check LOB entitlements: case.lob in user.entitlements.lobs
   - Check case type: has312Access / hasCAMAccess
   - Check employee cases: hasEmployeeCaseAccess
4. Filtered cases displayed
5. Action buttons shown/hidden based on permissions:
   - Assign button: permissions.assignCases
   - Reassign button: permissions.reassignCases
   - Open button: permissions.openCases (always true for all roles)
```

---

### Flow 4: User Opens Case Details

```
1. User clicks case to view details
2. System checks:
   - Does user have openCases permission? ✓
   - Is case LOB in user's entitlements? ✓
   - Is case type accessible (312/CAM)? ✓
3. Case details loaded
4. Action panel rendered based on:
   - Case status (Unassigned, In Progress, Complete, etc.)
   - User permissions (actionCases, reopenCases, etc.)
   - User role (Sales Owner gets different actions)
5. Appropriate buttons shown:
   - Analyst: "Submit Disposition"
   - Manager: "Assign", "Reassign", "Reopen", "Abandon"
   - Sales Owner: "Provide Feedback", "Return to Analyst"
   - View Only: No action buttons
```

---

### Flow 5: Manager Assigns Case

```
1. Manager views unassigned case
2. permissions.assignCases = true → "Assign" button visible
3. Manager clicks "Assign"
4. Dropdown shows analysts filtered by:
   - Active status
   - Has matching LOB entitlement
   - Has matching case type entitlement (312/CAM)
5. Manager selects analyst
6. Case updated:
   - case.assignedTo = analyst
   - case.status = 'In Progress'
   - case.assignedDate = current timestamp
7. Assignment history record created
8. Notification sent to analyst
```

---

### Flow 6: Sales Owner Provides Feedback

```
1. Analyst sends case to sales for review
2. Case status → 'Pending Sales Review'
3. Sales Owner sees case in "My Cases" (Sales Owner Worklist)
4. permissions.salesFeedback = true → "Provide Feedback" button visible
5. Sales Owner opens case, provides client context
6. Sales Owner clicks "Return to Analyst"
7. Case status → 'In Progress'
8. Case returned to original analyst
9. Feedback attached to case
10. Notification sent to analyst
```

---

## Summary Matrix

### Complete Permissions by Role

| Permission | Analyst | Manager | View Only | Sales Owner |
|-----------|---------|---------|-----------|-------------|
| View Dashboard | ✅ | ✅ | ✅ | ❌ |
| View Worklist | ✅ | ✅ | ✅ | ✅* |
| Open Cases | ✅ | ✅ | ✅ | ✅ |
| Review Data | ✅ | ✅ | ✅ | ✅ |
| Action Cases | ✅ | ✅ | ❌ | ❌ |
| Assign Cases | ❌ | ✅ | ❌ | ❌ |
| Reassign Cases | ❌ | ✅ | ❌ | ❌ |
| Reopen Cases | ❌ | ✅ | ❌ | ❌ |
| Abandon Cases | ❌ | ✅ | ❌ | ❌ |
| Sales Feedback | ❌ | ❌ | ❌ | ✅ |
| Return to Analyst | ❌ | ❌ | ❌ | ✅ |
| Admin Pages | ❌ | ✅ | ❌ | ❌ |

*Sales Owner sees specialized Sales Owner Worklist, not full worklist

---

**End of Documentation**