# CAM & 312 Integration Data Flow

## Overview
This document describes the enhanced System Integrations component with specific CAM (Client Activity Monitoring) and 312 population integration capabilities.

## Updated Client Data Sources

### 1. AWAREWCC (Consumer)
- **Type**: Client Data
- **Description**: Consumer banking client data warehouse
- **LOB**: Consumer
- **Key Attributes**: Client ID, Legal Name, Account Details, Product Holdings, Consumer Profile Data

### 2. CRH (Consumer Resource Hub) - NEW
- **Type**: Client Data
- **Description**: Consumer due dates and refresh scheduling
- **LOB**: Consumer
- **Key Attributes**: Consumer Due Dates, Refresh Schedule, Case Deadlines, Review Cycle Data

### 3. CMT (Private Banking)
- **Type**: Client Data
- **Description**: Private Banking client management tool
- **LOB**: Private Banking
- **Key Attributes**: Client Profile, Relationship Manager, Net Worth, Investment Strategy, Private Banking Data

### 4. Client Profile/GWIM Hub
- **Type**: Client Data
- **Description**: Merrill Lynch and Consumer Investments client profile platform
- **LOB**: Merrill Lynch, Consumer Investments
- **Key Attributes**: Client ID, Account Number, Financial Advisor, Portfolio Value, Client Profile Data

## Enhanced Monitoring Data Sources

### GFC Search Analytics
- **Enhanced with**: CAM Case Status, CAM Case Disposition
- **Purpose**: Consumes CAM case data to display in client profile case panel
- **Integration**: Bi-directional - provides search data, consumes CAM outcomes

### 312 Model
- **Enhanced with**: 312 Completion Status, 312 Disposition
- **Purpose**: Provides and consumes 312 completion status for population identification
- **Integration**: Bi-directional data flow with CAM platform

### FLU Data Sources
- **Enhanced with**: 312 Completion Status
- **Purpose**: Consumes 312 completion status to enable/disable refresh functionality
- **Integration**: Uses 312 completion at LOB level for refresh enablement

## CAM & 312 Data Attributes

### 312 Case Data (Outbound to FLU Tools & GFC Search)

#### a. CAM Case Number
- **Source**: CAM Platform
- **Type**: String (Required)
- **Consumers**: FLU Tools, GFC Search Analytics
- **Description**: Unique identifier for the CAM case

#### b. 312 Case Completion Status
- **Source**: CAM Platform (Derived)
- **Type**: Enum (Required)
- **Consumers**: FLU Tools, 312 Model
- **Values**: Complete, Incomplete, Pending
- **Purpose**: 312 completion is necessary for a refresh to be completed. CAM 2.0 makes the 312 case completion status (at an LOB level) available for consumption by FLU tools. FLU tools can elect to leverage this to enable or disable the refresh completion functionality.

#### c. 312 Case Disposition
- **Source**: CAM Platform (Derived)
- **Type**: Enum (Required)
- **Consumers**: GFC Search Analytics, 312 Model
- **Values**:
  - "312 Activity Escalated" - Case indicated TRMS was filed OR client indicated as closed
  - "312 Activity in line with expected activity" - No escalation required

#### d. 312 Case Auto-Closure
- **Source**: CAM Platform (Derived)
- **Type**: Boolean (Required)
- **Consumers**: All FLU Tools, Reporting
- **Description**: Indicates if case was auto-closed based on system rules

### CAM Case Data (Outbound to GFC Search & All FLU Tools)

#### e. CAM Case Completion Status
- **Source**: CAM Platform
- **Type**: Enum (Required)
- **Consumers**: GFC Search Analytics, All FLU Tools
- **Purpose**: GFC search can leverage the outcome of the CAM case as a case type that can be added to a client's case panel in their profile on search analytics. This will also be available for all FLU tools should they need to leverage the outcome.

#### f. CAM Case Disposition
- **Source**: CAM Platform (Derived)
- **Type**: Enum (Required)
- **Consumers**: GFC Search Analytics, All FLU Tools
- **Values**:
  - "CAM Case Escalated" - Case indicated TRMS was filed
  - "No additional CAM escalation required" - No escalation

#### g. CAM Case Auto Closure
- **Source**: CAM Platform (Derived)
- **Type**: Boolean (Required)
- **Consumers**: All FLU Tools, Reporting
- **Description**: Indicates if case was auto-closed based on system rules

## Data Flow Architecture

### Inbound to CAM (Client Data Ingestion)
```
AWAREWCC → CAM Platform (Consumer data)
CRH → CAM Platform (Consumer due dates)
CMT → CAM Platform (Private Banking data)
Client Profile/GWIM Hub → CAM Platform (ML/CI data)
```

### Outbound from CAM (Case Outcomes & Status)
```
CAM Platform → FLU Tools (312 completion status for refresh enablement)
CAM Platform → GFC Search Analytics (Case outcomes for client profile)
CAM Platform → 312 Model (Completion and disposition data)
```

### Bi-directional Integration Points

1. **312 Completion → FLU Refresh**
   - 312 case completion at LOB level enables/disables refresh functionality in FLU tools

2. **CAM Cases → GFC Search**
   - CAM case outcomes appear as case type in client profile on GFC Search Analytics

3. **Escalation Logic**
   - TRMS filed or client closed triggers "312 Activity Escalated" disposition

## New UI Components

### CAM & 312 Data Flow Tab
A new dedicated tab in the System Integrations page that provides:

1. **Data Flow Summary Card**
   - Visual overview of inbound/outbound data flows
   - Integration points and dependencies

2. **Key Integration Points Card**
   - Critical system dependencies
   - Business logic descriptions

3. **CAM & 312 Data Attributes Table**
   - Complete mapping of all data attributes
   - Source systems, consumer systems, and descriptions
   - Organized by category (312 Case Data, CAM Case Data, Client Data Sources)

4. **Derived Data Field Definitions Card**
   - Detailed logic for derived fields
   - Value definitions and calculation rules
   - Business rules for auto-closure and escalation

## Technical Implementation

### New TypeScript Interfaces
```typescript
export interface CAMIntegrationAttribute {
  name: string;
  source: string;
  type: string;
  required: boolean;
  consumers: string;
  description: string;
}

export interface CAMIntegrationCategory {
  category: string;
  description: string;
  attributes: CAMIntegrationAttribute[];
}
```

### Enhanced SystemIntegration Interface
- Added support for `consumers` field in data attributes
- Extended to support bi-directional data flow documentation

## Benefits

1. **Clear Documentation**: Comprehensive view of all CAM and 312 integration points
2. **Data Lineage**: Complete traceability of data from source to consumer
3. **Business Logic**: Explicit definitions of derived fields and their calculation rules
4. **System Dependencies**: Clear visualization of which systems depend on CAM data
5. **Operational Clarity**: Enables FLU teams to understand refresh dependencies on 312 completion
