# Case & Client Details - Visual Grouping Update ✅

## Overview
The Case & Client Details section (Section 2) has been restructured with visual grouping to clearly separate 312 attributes (left) and CAM attributes (right), making it easier for users to distinguish between the two case types at a glance.

---

## 🎨 New Visual Structure

### Section Organization (4 Subsections)

```
┌─────────────────────────────────────────────────────────────────┐
│  Section 2: Case and Client Details                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─ Client Information ────────────────────────────────────┐  │
│  │ Entity Name  First Name  Middle Name  Last Name         │  │
│  │ Case Number                                              │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌─ Case Attributes ───────────────────────────────────────┐  │
│  │  ┏━━━━━━━━━━━━━━━━━━━┓  ┏━━━━━━━━━━━━━━━━━━━┓         │  │
│  │  ┃ [312] 312 Case    ┃  ┃ [CAM] CAM Case    ┃         │  │
│  │  ┃ Attributes        ┃  ┃ Attributes        ┃         │  │
│  │  ┃───────────────────┃  ┃───────────────────┃         │  │
│  │  ┃ 312 Due Date      ┃  ┃ CAM Due Date      ┃         │  │
│  │  ┃ 312 Aging         ┃  ┃ CAM Aging         ┃         │  │
│  │  ┃ 312 Case Status   ┃  ┃ CAM Case Status   ┃         │  │
│  │  ┃ 312 Disposition   ┃  ┃ CAM Disposition   ┃         │  │
│  │  ┃ 312 Completed     ┃  ┃ CAM Completed     ┃         │  │
│  │  ┃ Source of Funds   ┃  ┃                   ┃         │  │
│  │  ┗━━━━━━━━━━━━━━━━━━━┛  ┗━━━━━━━━━━━━━━━━━━━┛         │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌─ General Case Information ──────────────────────────────┐  │
│  │ Assigned To       LOB(s)           312 Client           │  │
│  │ BOA Employee      BOA Affiliate    Reg O Indicator      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌─ Business & Compliance Information ─────────────────────┐  │
│  │ NAICS Code        NAICS Description                     │  │
│  │ Refresh Due Date  Last Refresh     Client Owners        │  │
│  │ AML Attributes: [Badge] [Badge] [Badge] [Badge]         │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📋 Four Subsections

### 1. Client Information
**Purpose**: Core client identification details  
**Layout**: Responsive 3-column grid  
**Always Visible**: Yes

**Fields**:
- Entity Name
- First Name (conditional - individuals only)
- Middle Name (conditional - individuals only)
- Last Name (conditional - individuals only)
- Case Number

---

### 2. Case Attributes (312 vs CAM Side-by-Side)
**Purpose**: Visual separation of 312 and CAM-specific attributes  
**Layout**: 2-column grid (1 column on mobile)  
**Conditional**: Only shows if case has 312 or CAM data

#### Left Column: 312 Case Attributes
**Visual Design**:
- Light blue background (`bg-blue-50/30`)
- Blue border (`border-blue-200`)
- Blue badge with "312" label
- Rounded corners
- Padding for breathing room

**Fields**:
- 312 Due Date
- 312 Aging (days)
- 312 Case Status
- 312 Case Disposition
- 312 Completed Date (if completed)
- Source of Funds (if available)

#### Right Column: CAM Case Attributes
**Visual Design**:
- Light emerald background (`bg-emerald-50/30`)
- Emerald border (`border-emerald-200`)
- Emerald badge with "CAM" label
- Rounded corners
- Padding for breathing room

**Fields**:
- CAM Due Date
- CAM Aging (days)
- CAM Case Status
- CAM Case Disposition
- CAM Completed Date (if completed)

**Responsive Behavior**:
- Desktop (lg): Side-by-side columns
- Tablet/Mobile: Stacked vertically

---

### 3. General Case Information
**Purpose**: Common case metadata and indicators  
**Layout**: Responsive 3-column grid  
**Always Visible**: Yes

**Fields**:
- Assigned To
- LOB(s)
- 312 Client (badge - conditional)
- BOA Employee (purple badge)
- BOA Affiliate Indicator (indigo badge)
- Reg O Indicator (orange badge)

---

### 4. Business & Compliance Information
**Purpose**: Business classification and compliance attributes  
**Layout**: Responsive 3-column grid + full-width AML section  
**Conditional**: Fields show only if data exists

**Fields**:
- NAICS Code
- NAICS Description (spans 2 columns)
- Refresh Due Date(s)
- Last Refresh Completion Date
- Client Owner(s)
- AML Attributes / CBA Codes (full-width badge array)

---

## 🎨 Visual Design Details

### Color Coding

#### 312 Attributes Box
```css
background: bg-blue-50/30 (very light blue with 30% opacity)
border: border-blue-200 (light blue border)
badge: bg-blue-600 (solid blue badge with "312")
```

#### CAM Attributes Box
```css
background: bg-emerald-50/30 (very light emerald with 30% opacity)
border: border-emerald-200 (light emerald border)
badge: bg-emerald-600 (solid emerald badge with "CAM")
```

### Typography

#### Subsection Headers
```css
className: "text-sm font-semibold text-muted-foreground mb-4"
```

#### Card Headers (312/CAM)
```css
className: "font-semibold text-sm"
Display: Badge + Title side-by-side
```

#### Field Labels
```css
className: "text-xs text-muted-foreground"
```

#### Field Values
```css
className: "mt-1" (standard text)
className: "font-mono mt-1" (for codes/IDs)
```

### Spacing

- **Between Subsections**: `mb-6` (6 units margin-bottom)
- **Grid Gap**: `gap-6` (6 units between grid items)
- **Card Padding**: `p-4` (4 units padding)
- **Field Spacing**: `space-y-4` (4 units vertical spacing between fields)
- **Label-Value Gap**: `mt-1` (1 unit margin-top)

---

## 💻 Implementation Code

### Structure Overview
```tsx
<AccordionContent className="px-6 pb-6">
  <Separator className="my-4" />
  
  {/* Subsection 1: Client Information */}
  <div className="mb-6">
    <h3>Client Information</h3>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Fields */}
    </div>
  </div>

  {/* Subsection 2: Case Attributes (312 vs CAM) */}
  {(is312Case || isCAMCase) && (
    <div className="mb-6">
      <h3>Case Attributes</h3>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 312 Box */}
        {is312Case && caseData.case312Data && (
          <div className="border rounded-lg p-4 bg-blue-50/30 border-blue-200">
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="default" className="bg-blue-600">312</Badge>
              <h4>312 Case Attributes</h4>
            </div>
            <div className="space-y-4">
              {/* 312 Fields */}
            </div>
          </div>
        )}

        {/* CAM Box */}
        {isCAMCase && caseData.camCaseData && (
          <div className="border rounded-lg p-4 bg-emerald-50/30 border-emerald-200">
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="default" className="bg-emerald-600">CAM</Badge>
              <h4>CAM Case Attributes</h4>
            </div>
            <div className="space-y-4">
              {/* CAM Fields */}
            </div>
          </div>
        )}
      </div>
    </div>
  )}

  {/* Subsection 3: General Case Information */}
  <div className="mb-6">
    <h3>General Case Information</h3>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Fields */}
    </div>
  </div>

  {/* Subsection 4: Business & Compliance Information */}
  <div>
    <h3>Business & Compliance Information</h3>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Fields */}
    </div>
    {/* AML Attributes - Full Width */}
    {caseData.amlAttributes && (
      <div className="mt-6">
        {/* Badge array */}
      </div>
    )}
  </div>
</AccordionContent>
```

---

## 📱 Responsive Behavior

### Desktop (≥1024px)
- Client Information: 3 columns
- Case Attributes: **2 columns side-by-side** (312 left, CAM right)
- General Case Info: 3 columns
- Business & Compliance: 3 columns

### Tablet (768-1023px)
- Client Information: 2 columns
- Case Attributes: **2 columns side-by-side** (312 left, CAM right)
- General Case Info: 2 columns
- Business & Compliance: 2 columns

### Mobile (<768px)
- Client Information: 1 column
- Case Attributes: **1 column stacked** (312 on top, CAM below)
- General Case Info: 1 column
- Business & Compliance: 1 column

---

## 🔍 Conditional Display Logic

### Client Information Section
```typescript
// Always visible
- Entity Name: always shown
- Individual Names: only if caseData.firstName exists
- Case Number: always shown
```

### Case Attributes Section
```typescript
// Only visible if case has 312 or CAM data
{(is312Case || isCAMCase) && (
  // Section rendered
)}

// 312 Box only if 312 case
{is312Case && caseData.case312Data && (
  // 312 box rendered
)}

// CAM Box only if CAM case
{isCAMCase && caseData.camCaseData && (
  // CAM box rendered
)}
```

### General Case Information
```typescript
// Always visible
- Assigned To: always shown
- LOB(s): always shown
- 312 Client badge: only if is312Case === true
- BOA indicators: always shown
```

### Business & Compliance Information
```typescript
// Conditional fields
- NAICS: only if caseData.naicsCode exists
- Refresh dates: only if caseData.refreshDueDates exists
- Last Refresh: only if caseData.lastRefreshCompletionDate exists
- Client Owners: only if caseData.clientOwners exists
- AML Attributes: only if caseData.amlAttributes exists
```

---

## 🧪 Testing Scenarios

### Test 1: Combined 312 + CAM Case
**Case ID**: `312-2025-001` (GlobalTech Industries Corp)

**Expected Display**:
1. ✅ Client Information subsection with entity name and case number
2. ✅ Case Attributes subsection with **two boxes side-by-side**:
   - Left: Blue 312 box with 6 fields
   - Right: Emerald CAM box with 5 fields
3. ✅ General Case Information with all 6 fields
4. ✅ Business & Compliance with NAICS, refresh dates, and 3 AML attribute badges

### Test 2: 312-Only Case
**Case ID**: Any 312 case without CAM data

**Expected Display**:
1. ✅ Client Information subsection
2. ✅ Case Attributes subsection with **312 box only** (takes full width if only box)
3. ✅ General Case Information
4. ✅ Business & Compliance

### Test 3: CAM-Only Case
**Case ID**: Any CAM case without 312 data

**Expected Display**:
1. ✅ Client Information subsection
2. ✅ Case Attributes subsection with **CAM box only** (takes full width if only box)
3. ✅ General Case Information (312 Client badge NOT shown)
4. ✅ Business & Compliance

### Test 4: Individual Client
**Case ID**: `312-2025-006` (Johnson Employee Account)

**Expected Display**:
1. ✅ Client Information with First/Middle/Last Name fields
2. ✅ Case Attributes as applicable
3. ✅ General Case Info with BOA Employee = Yes (purple)
4. ✅ Reg O Indicator = Yes (orange)

### Test 5: Mobile Responsive
1. ✅ Resize browser to <768px
2. ✅ All subsections remain visible
3. ✅ 312 and CAM boxes **stack vertically**
4. ✅ All grids collapse to single column
5. ✅ Content remains readable and accessible

---

## ✨ Benefits of New Structure

### 1. **Clear Visual Separation**
- 312 attributes grouped together with blue theme
- CAM attributes grouped together with emerald theme
- Easy to scan and distinguish at a glance

### 2. **Reduced Cognitive Load**
- Related information grouped logically
- Subsection headers provide context
- Color coding aids recognition

### 3. **Better Space Utilization**
- Side-by-side layout on desktop maximizes screen real estate
- Vertical spacing prevents cramming
- Responsive design adapts to all screen sizes

### 4. **Improved Scannability**
- Subsection headers act as visual anchors
- Badges provide quick visual indicators
- Consistent spacing creates rhythm

### 5. **Scalability**
- Easy to add new fields to appropriate subsection
- Structure supports future enhancements
- Conditional sections keep UI clean when data is missing

---

## 📊 Before vs After

### Before (Old Structure)
```
Section 2: Case and Client Details
├── All fields in single 3-column grid
├── 312 fields mixed with CAM fields
├── Hard to distinguish 312 vs CAM attributes
└── No visual grouping
```

### After (New Structure)
```
Section 2: Case and Client Details
├── 1. Client Information (subsection)
│   └── Entity, Names, Case Number
├── 2. Case Attributes (subsection)
│   ├── [Blue Box] 312 Attributes (left)
│   └── [Green Box] CAM Attributes (right)
├── 3. General Case Information (subsection)
│   └── Assignment, LOB, Indicators
└── 4. Business & Compliance (subsection)
    └── NAICS, Refresh, Owners, AML Attributes
```

---

## 📁 Files Modified

| File | Changes Made |
|------|--------------|
| `/components/CaseDetailsEnhanced.tsx` | Restructured Section 2 with 4 subsections, added 312/CAM visual boxes |
| `/CASE_CLIENT_DETAILS_UPDATE.md` | Previous documentation (still valid for field list) |
| `/CASE_DETAILS_VISUAL_GROUPING.md` | This new documentation for visual structure |

---

## 🎯 Requirements Alignment

### User Request
✅ **"Show 312 attributes on the left and CAM attributes on the right"**
- Implemented with side-by-side boxes
- Clear visual distinction with color coding
- Responsive: side-by-side on desktop, stacked on mobile

### Additional Improvements
✅ Organized all fields into logical subsections  
✅ Added descriptive headers for each subsection  
✅ Maintained all existing fields and functionality  
✅ Improved visual hierarchy and scannability  
✅ Preserved responsive behavior  
✅ Enhanced user experience with color-coded boxes  

---

## ✨ Summary

**Status**: ✅ **COMPLETE**

The Case & Client Details section has been successfully restructured with clear visual grouping:

✅ **4 organized subsections** for better information architecture  
✅ **312 attributes in blue box on left** side  
✅ **CAM attributes in emerald box on right** side  
✅ **Side-by-side layout** on desktop for easy comparison  
✅ **Responsive stacking** on mobile devices  
✅ **Color-coded visual distinction** between 312 and CAM  
✅ **Subsection headers** for clear navigation  
✅ **All existing fields preserved** and properly organized  
✅ **Improved scannability** and user experience  

The new structure makes it immediately clear which attributes belong to 312 vs CAM, significantly improving the usability of the Case Details page! 🎉

---

**Last Updated**: November 1, 2025  
**Version**: 3.0 - Visual Grouping Update  
**Section**: UI Section 2 - "Case and Client Details"
