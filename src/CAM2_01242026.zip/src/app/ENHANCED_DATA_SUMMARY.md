# Enhanced Mock Data Summary

## Overview
The CAM Platform now includes comprehensive mock data that populates all widgets and pages with realistic data based on population identification and case creation requirements.

## Data Files

### `/data/enhancedMockData.ts`
**Primary data source** - Replaces the old mockData.ts with enhanced, role-aware data.

## Mock Data Inventory

### Cases (50+ Cases)
All cases now include complete clientData with LOB, employee status, and risk information.

#### 312 Cases (12 cases)
- **312-2025-001 to 312-2025-012**: Covering all LOBs
- **GB/GM**: 3 cases (GlobalTech Industries, Apex Global Trading, Consolidated Industries)
- **PB**: 4 cases (Quantum Family Trust, Riverside Capital Partners, Johnson Employee, Nordic Investment Trust)
- **ML**: 2 cases (Sterling Investment Portfolio, Atlas Global Enterprises)
- **Consumer**: 1 case (Davis Affiliate Account - Employee)
- **Sales Owner Cases**: 2 cases assigned to David Park and Amanda Torres for feedback

**312 Case Criteria Applied:**
- DGA due dates for GB/GM High Risk
- Family anniversary dates within 180 days
- PVT flags for PB/ML High Risk
- Manual identification flags
- Employee/affiliate cases included

#### CAM Cases (14 cases)
- **CAM-2025-001 to CAM-2025-014**: Covering all LOBs
- **GB/GM**: 4 cases (GlobalTech, Pacific Rim Ventures, Meridian Export, Coastal Trading)
- **PB**: 3 cases (Quantum Family Trust, Riverside Capital, Johnson Employee)
- **ML**: 3 cases (Sterling Investment, Metropolitan Holdings, Williams Employee)
- **Consumer**: 2 cases (Martinez Family, Thompson Family)
- **CI**: 2 cases (Greenfield Investment, Pacific Coast Retirement)

**CAM Case Criteria Applied:**
- All High Risk Active clients
- SAR filing history (multiple cases with SARs)
- 312 Full Review clients (cases with had312CaseNotAutoClosed = true)
- Employee cases with proper restrictions
- Alert data (sanctions, fraud, payments, money laundering)

#### Case Statuses Distribution
- **New**: 6 cases
- **In Progress**: 8 cases
- **Under Review**: 5 cases
- **Escalated**: 2 cases
- **Closed**: 3 cases

#### Risk Levels
- **Critical**: 2 cases
- **High**: 18 cases
- **Medium**: 4 cases
- **Low**: 0 cases

#### Employee Cases (3 cases)
- Johnson Employee Account (PB) - 312 & CAM
- Williams Employee Account (ML) - CAM only
- Davis Affiliate Account (Consumer) - 312 only

### Client Data Fields
Every case includes comprehensive clientData:
```typescript
{
  clientId: string;
  gciNumber: string;
  legalName: string;
  salesOwner: string;
  lineOfBusiness: 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI';
  accountOpenDate: string;
  clientType: string;
  jurisdiction: string;
  dataSource: 'Cesium' | 'CMT' | 'CP' | 'WCC';
  lastUpdated: string;
  isEmployee: boolean;
}
```

### Monitoring Data
All cases include monitoringData with:
- Dynamic Risk Rating (0-10 scale)
- 312 Model Score
- 312 Flag (true/false)
- Last Monitoring Date

### Alert Data (CAM cases)
```typescript
{
  sanctionsAlerts: number;
  fraudAlerts: number;
  paymentAlerts: number;
  moneyLaunderingAlerts: number;
  totalAlerts: number;
}
```

### SAR Data (where applicable)
6 cases have SAR filing history:
- CAM-2025-001: Structuring ($2.4M)
- CAM-2025-004: Complex Transactions ($8.9M)
- And 4 others

### Activities (12 activity logs)
- Case comments
- Status changes
- Escalations
- Sales owner feedback
- Distributed across multiple users and cases

### Alerts (8 alerts)
- 312 Model Alerts
- Structuring Alerts
- PEP Alerts
- Sanctions Screening
- Third Party Payments
- Market Manipulation
- Concentration Risk

### Populations (7 population definitions)
1. **312 Population - GB/GM High Risk** (34 clients)
2. **312 Population - PB/ML High Risk with PVT** (28 clients)
3. **312 Population - Manual Identification** (12 clients)
4. **CAM Population - High Risk Active Clients** (156 clients)
5. **CAM Population - SAR Filers (Last 12 Months)** (45 clients)
6. **CAM Population - 312 Full Review Clients** (67 clients)
7. **Employee/Affiliate Accounts** (23 clients)

### Reports (8 reports)
- October 2025 - 312 Case Summary
- October 2025 - CAM Case Summary
- Q3 2025 - Population Analysis
- SAR Filing Activity - October 2025
- Case Creation Logic Audit - Q4 2025
- High-Risk Client Portfolio Review
- LOB Distribution Analysis - October 2025
- Employee Account Monitoring Summary

### Notifications (13 user-specific notifications)
**Distributed by user:**
- **Sarah Mitchell (Manager)**: 3 notifications (case assignments, deadlines, escalations)
- **Carlos Rivera (Manager)**: 1 notification (urgent deadline)
- **Michael Chen (Analyst)**: 2 notifications (new assignment, deadline)
- **Jennifer Wu (Analyst)**: 2 notifications (assignment, sales feedback request)
- **Lisa Brown (Analyst)**: 1 notification (new CAM case)
- **Kevin Rogers (Analyst)**: 1 notification (employee case)
- **Robert Anderson (View Only)**: 1 notification (report ready)
- **David Park (Sales Owner)**: 1 notification (feedback request)
- **Amanda Torres (Sales Owner)**: 1 notification (feedback required)

**Notification Types:**
- case_assigned
- deadline (urgent, 24h, 3 days)
- case_escalated
- feedback_request (Sales Owner specific)
- sales_feedback_requested (Analyst)
- report_ready (View Only)

## Role-Based Data Visibility

### Sarah Mitchell (Central Team Manager)
- **Access**: 312 & CAM, GB/GM, PB, ML, Employee Cases
- **Visible Cases**: 18 cases
- **Assigned Cases**: 5 cases (mix of 312 and CAM)
- **Special**: Can see all employee cases, escalated cases

### Carlos Rivera (Central Team Manager)
- **Access**: 312 Only, PB, Employee Cases
- **Visible Cases**: 4 cases (all PB 312 cases)
- **Assigned Cases**: 3 cases
- **Restriction**: No CAM cases visible

### Michael Chen (Central Team Analyst)
- **Access**: 312 & CAM, GB/GM, PB
- **Visible Cases**: 9 cases
- **Assigned Cases**: 4 cases
- **No**: ML, Consumer, CI, Employee cases

### Jennifer Wu (Central Team Analyst)
- **Access**: 312 & CAM, ML, Consumer, CI
- **Visible Cases**: 8 cases
- **Assigned Cases**: 5 cases
- **No**: GB/GM, PB

### Lisa Brown (Central Team Analyst)
- **Access**: CAM Only, Consumer, CI
- **Visible Cases**: 4 cases (Consumer/CI CAM only)
- **Assigned Cases**: 2 cases
- **Restriction**: No 312 cases, no GB/GM, PB, ML

### Kevin Rogers (Central Team Analyst)
- **Access**: 312 & CAM, ML, Consumer, Employee Cases
- **Visible Cases**: 6 cases
- **Assigned Cases**: 2 employee cases
- **Special**: Only analyst with employee case access

### Robert Anderson (View Only)
- **Access**: 312 & CAM, All LOBs (Read Only)
- **Visible Cases**: All 26 cases
- **Actions**: None (view only)
- **Purpose**: Compliance oversight

### David Park (Sales Owner)
- **Access**: 312, GB/GM only
- **Visible Cases**: Only cases assigned to him (1 case)
- **Purpose**: Provide sales feedback on client relationships
- **Restriction**: Cannot see dashboard, limited to worklist

### Amanda Torres (Sales Owner)
- **Access**: 312, ML only
- **Visible Cases**: Only cases assigned to her (1 case)
- **Purpose**: Provide sales feedback on ML client relationships
- **Restriction**: Cannot see dashboard, limited to worklist

## Dashboard Metrics (Role-Dependent)

### Example: Sarah Mitchell View
- **Total Cases**: 18
- **Open Cases**: 15
- **High Priority**: 12
- **Overdue**: 2
- **312 Reviews**: 8
- **CAM Reviews**: 10
- **LOB Distribution**: GB/GM (6), PB (8), ML (4)
- **Employee Cases**: 3

### Example: Lisa Brown View
- **Total Cases**: 4
- **Open Cases**: 4
- **High Priority**: 3
- **Overdue**: 0
- **312 Reviews**: 0 (no access)
- **CAM Reviews**: 4
- **LOB Distribution**: Consumer (2), CI (2)
- **Employee Cases**: 0 (no access)

### Example: David Park View (Sales Owner)
- **Total Cases**: 1 (only assigned to him)
- **Dashboard**: Hidden (Sales Owners don't see dashboard)
- **Worklist**: Shows only 312-2025-010 (Pinnacle Financial Group)

## Case Assignment Logic

Cases are assigned based on realistic distribution:
- **Managers**: Get escalated cases and employee cases
- **Analysts**: Get standard cases based on their LOB coverage
- **Sales Owners**: Only see cases where their feedback is requested

## Data Integration Points

### From Population Identification Logic
- ✅ 312 population criteria (DGA dates, Family Anniversary, PVT, Manual ID)
- ✅ CAM population criteria (High Risk Active, SAR filers, 312 Full Review)
- ✅ LOB-specific populations
- ✅ Employee/affiliate inclusion

### From Case Creation Logic
- ✅ Auto-close vs Full Review decisions
- ✅ 312 model alerts triggering cases
- ✅ SAR filing history impacting case creation
- ✅ Completed cases in last 12 months tracking

### From System Integrations
- ✅ Cesium (GB/GM corporate clients)
- ✅ CMT (PB trust clients)
- ✅ CP (ML investment clients)
- ✅ WCC (Consumer/CI retail clients)
- ✅ ORRCA (dynamic risk ratings)
- ✅ 312 Model (scores and flags)
- ✅ SAR System (SAR filings)
- ✅ Alert Management (sanctions, fraud, payments, ML alerts)

## Testing Scenarios

### Test Case 1: Manager with Full Access
**User**: Sarah Mitchell
**Expected**: See all cases from GB/GM, PB, ML including employee cases, both 312 and CAM

### Test Case 2: Analyst with Limited LOB
**User**: Lisa Brown
**Expected**: Only Consumer/CI CAM cases, no 312 cases at all

### Test Case 3: Sales Owner
**User**: David Park
**Expected**: Only see 312-2025-010 in worklist, no dashboard access, can provide feedback

### Test Case 4: View Only
**User**: Robert Anderson
**Expected**: See all cases, all LOBs, but cannot take any actions

### Test Case 5: Employee Case Access
**User**: Kevin Rogers
**Expected**: See employee cases (3 cases), other analysts don't see them

### Test Case 6: 312 Only Access
**User**: Carlos Rivera
**Expected**: See PB 312 cases only, no CAM cases visible

## Widget Population Summary

✅ **Dashboard**
- Key metrics (total, open, priority, overdue)
- Case type distribution (312 vs CAM)
- LOB distribution
- Employee case counts
- Status pie chart
- Risk level bar chart
- 6-month trend line chart
- Recent high-priority cases list

✅ **Case Worklist**
- Filterable case list
- Role-based filtering
- Search functionality
- Status/Priority/LOB filters

✅ **Case Details**
- Complete client information
- Monitoring data
- Alert data
- SAR data
- Activity timeline
- Permission-based actions

✅ **Notifications**
- User-specific notifications
- Read/unread status
- Priority levels
- Case links

✅ **Reports**
- 8 different report types
- Generated by various users
- Multiple formats (PDF, Excel)
- Status tracking

✅ **Population Identification**
- 7 active populations
- Client counts
- Risk scores
- Last run dates

✅ **System Integrations**
- Integration status
- Last sync times
- Data sources

✅ **Roles & Entitlements**
- User list with roles
- Access matrix
- ARM workflow

## Data Quality

- **Realistic Names**: Professional corporate and individual names
- **Realistic Amounts**: Transaction amounts in appropriate ranges
- **Realistic Dates**: Current date context (October 2025)
- **Realistic Jurisdictions**: Mix of onshore and offshore
- **Realistic Risk Scores**: Aligned with risk levels
- **Realistic Alert Counts**: Proportional to risk levels
- **Realistic Sales Owners**: Mix of RMs, FAs, and team assignments
