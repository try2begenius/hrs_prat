# CAM 312 Status Transition Matrix

## Official Status Flow

This document defines the exact status transitions, actors, and progression logic for CAM 312 cases.

---

## Status Transition Matrix

| Current Status | Progress To | Actor | Description |
|---------------|-------------|-------|-------------|
| **Unassigned (Pending)** | In Progress | Central Team Analyst, Central Team Manager | Manager assigns case to analyst OR analyst self-selects from workbasket |
| **In Progress** | Pending Sales Review | Central Team Analyst | Analyst routes case to sales owner for additional context |
| **In Progress** | Complete | Central Team Analyst | Analyst self-solves and dispositions case |
| **Pending Sales Review** | In Sales Review | Central Team Analyst | Analyst initiates sales review process |
| **In Sales Review** | Sales Review Complete | Sales Owner | Sales owner completes review and provides feedback |
| **Sales Review Complete** | Complete | Central Team Analyst | Analyst dispositions case after reviewing sales feedback |
| **Complete** | Defect Remediation | Central Team Analyst w/M&I entitlement | M&I quality review identifies defect requiring remediation |
| **Defect Remediation** | Complete | Central Team Analyst w/M&I entitlement | M&I analyst completes remediation and re-closes case |

---

## Detailed Status Definitions

### 1. Unassigned (Pending)

**Description**: Case has been created and is in the workbasket awaiting assignment or selection.

**Entry Point**: 
- System creates case (not auto-closed)

**Available Actions**:
- **Central Team Manager**: Assign to specific analyst
- **Central Team Analyst**: Self-select from workbasket

**Next Status**: In Progress

**Actor**: Central Team Analyst, Central Team Manager

---

### 2. In Progress

**Description**: Case is actively being worked by an analyst.

**Entry Point**: 
- Manager assigns case to analyst
- Analyst self-selects case

**Available Actions**:
1. **Route to Sales**: Send case to sales owner for additional context
   - Next Status: Pending Sales Review
   - Actor: Central Team Analyst
   
2. **Disposition Case**: Complete case if analyst can self-solve
   - Next Status: Complete
   - Actor: Central Team Analyst

**Actor**: Central Team Analyst

---

### 3. Pending Sales Review

**Description**: Case has been routed to sales owner, awaiting analyst to initiate sales review.

**Entry Point**: 
- Analyst routes case from In Progress

**Available Actions**:
- **Initiate Sales Review**: Analyst starts the sales review process
  - Next Status: In Sales Review
  - Actor: Central Team Analyst

**Note**: At this stage, the sales owner has been identified but the review hasn't been formally initiated yet.

**Actor**: Central Team Analyst (to initiate)

---

### 4. In Sales Review

**Description**: Sales owner is actively reviewing case and providing context.

**Entry Point**: 
- Analyst initiates sales review from Pending Sales Review

**Available Actions**:
- **Complete Sales Review**: Sales owner provides feedback and completes review
  - Next Status: Sales Review Complete
  - Actor: Sales Owner
  - Required: Sales owner must provide comments/feedback

**Actor**: Sales Owner

---

### 5. Sales Review Complete

**Description**: Sales owner has completed review and provided feedback. Case returned to analyst's worklist.

**Entry Point**: 
- Sales owner completes review from In Sales Review

**Available Actions**:
- **Disposition Case**: Analyst reviews sales feedback and dispositions case
  - Next Status: Complete
  - Actor: Central Team Analyst (original analyst)
  - Required: Analyst must provide final disposition

**Actor**: Central Team Analyst

---

### 6. Complete

**Description**: Case has been dispositioned and closed. Terminal status unless reopened for remediation.

**Entry Points**: 
- Auto-closed by system (direct to Complete)
- Analyst dispositions from In Progress (self-solved)
- Analyst dispositions from Sales Review Complete (after sales feedback)
- M&I analyst completes remediation from Defect Remediation

**Available Actions**:
- **Reopen for Remediation**: M&I credentialed analyst can reopen case
  - Next Status: Defect Remediation
  - Actor: Central Team Analyst w/M&I entitlement
  - Trigger: M&I quality review identifies defect

**Data Captured**:
- `autoClosed`: true/false
- `derivedDisposition`: For manual cases only
- `modelOutcome`: Final outcome
- `completionDate`: When case was completed
- `originalCompletionDate`: Preserved if case goes through remediation

**Actor**: Central Team Analyst w/M&I entitlement (for reopening only)

---

### 7. Defect Remediation

**Description**: Case has been reopened due to M&I quality review finding. Being corrected by M&I analyst.

**Entry Point**: 
- M&I analyst reopens Complete case

**Available Actions**:
- **Complete Remediation**: M&I analyst finishes corrections and re-closes case
  - Next Status: Complete
  - Actor: Central Team Analyst w/M&I entitlement
  - Note: Original completion date is preserved for SLA reporting

**Actor**: Central Team Analyst w/M&I entitlement

---

## Actor Role Matrix

### Central Team Manager

**Can Progress**:
- Unassigned → In Progress (assign to analyst)

**Cannot Progress**:
- Any other status transitions
- Cannot disposition cases
- Cannot work cases directly

**View Access**: All cases

---

### Central Team Analyst (Standard)

**Can Progress**:
- Unassigned → In Progress (self-select)
- In Progress → Pending Sales Review (route to sales)
- In Progress → Complete (self-solve)
- Pending Sales Review → In Sales Review (initiate review)
- Sales Review Complete → Complete (final disposition)

**Cannot Progress**:
- Complete → Defect Remediation (requires M&I entitlement)

**View Access**: All cases

---

### Central Team Analyst (with M&I Entitlement)

**All Standard Analyst Permissions PLUS**:
- Complete → Defect Remediation (reopen for remediation)
- Defect Remediation → Complete (complete remediation)

**M&I Entitled Users** (from mock data):
- Michael Chen
- Jennifer Wu

**View Access**: All cases

---

### Sales Owner

**Can Progress**:
- In Sales Review → Sales Review Complete (complete review)

**Cannot Progress**:
- Cannot self-select cases
- Cannot disposition cases
- Cannot initiate sales review (analyst does this)

**View Access**: Cases assigned to them for sales review

---

### View Only

**Can Progress**:
- None (read-only)

**View Access**: All cases (read-only)

---

## Workflow Scenarios

### Scenario A: Auto-Closed Case
```
System → Complete
```

**Flow**:
1. System creates case
2. Auto-close logic determines case can be closed automatically
3. Case placed directly in Complete status
4. autoClosed = true
5. modelOutcome = '312 Activity in line with expected activity'

---

### Scenario B: Self-Solved Case (No Sales Review)
```
Unassigned → In Progress → Complete
```

**Flow**:
1. System creates case → Unassigned
2. Analyst self-selects OR manager assigns → In Progress
3. Analyst reviews case
4. Analyst can determine outcome without sales input
5. Analyst dispositions → Complete
6. autoClosed = false
7. derivedDisposition set by analyst

**Actors**: Central Team Analyst

---

### Scenario C: Sales Review Flow
```
Unassigned → In Progress → Pending Sales Review → In Sales Review → Sales Review Complete → Complete
```

**Flow**:
1. System creates case → Unassigned
2. Analyst self-selects → In Progress (Analyst)
3. Analyst needs sales context → Pending Sales Review (Analyst)
4. Analyst initiates sales review → In Sales Review (Analyst)
5. Sales owner reviews and provides feedback → Sales Review Complete (Sales Owner)
6. Analyst reviews sales feedback and dispositions → Complete (Analyst)
7. autoClosed = false
8. derivedDisposition set by analyst

**Actors**: Central Team Analyst, Sales Owner

---

### Scenario D: Defect Remediation Flow
```
Complete → Defect Remediation → Complete
```

**Flow**:
1. Case previously completed → Complete
2. M&I quality review identifies defect
3. M&I analyst reopens case → Defect Remediation (M&I Analyst)
4. M&I analyst corrects defect
5. M&I analyst re-closes case → Complete (M&I Analyst)
6. originalCompletionDate preserved from step 1
7. New completionDate recorded for remediation

**Actors**: Central Team Analyst w/M&I entitlement

---

## Status Transition Validation Rules

### Rule 1: Unassigned → In Progress
```typescript
// Valid actors
allowedRoles: ['Central Team Analyst', 'Central Team Manager']

// Requirements
- Case must be in Unassigned status
- If manager assigns: must specify analyst
- If analyst self-selects: analyst becomes assignedTo
```

---

### Rule 2: In Progress → Pending Sales Review
```typescript
// Valid actors
allowedRoles: ['Central Team Analyst']

// Requirements
- Case must be in In Progress status
- Must specify sales owner
- Actor must be current assignedTo (analyst working the case)
```

---

### Rule 3: In Progress → Complete
```typescript
// Valid actors
allowedRoles: ['Central Team Analyst']

// Requirements
- Case must be in In Progress status
- Must provide disposition
- Must provide model outcome
- Actor must be current assignedTo
- Sets autoClosed = false
```

---

### Rule 4: Pending Sales Review → In Sales Review
```typescript
// Valid actors
allowedRoles: ['Central Team Analyst']

// Requirements
- Case must be in Pending Sales Review status
- Actor must be current assignedTo (analyst)
- Sales owner must already be identified
```

---

### Rule 5: In Sales Review → Sales Review Complete
```typescript
// Valid actors
allowedRoles: ['Sales Owner']

// Requirements
- Case must be in In Sales Review status
- Must provide sales review comments
- Actor must be the assigned sales owner
- Case will be reassigned to original analyst
```

---

### Rule 6: Sales Review Complete → Complete
```typescript
// Valid actors
allowedRoles: ['Central Team Analyst']

// Requirements
- Case must be in Sales Review Complete status
- Must provide final disposition
- Must provide model outcome
- Actor must be current assignedTo (original analyst)
- Sets autoClosed = false
```

---

### Rule 7: Complete → Defect Remediation
```typescript
// Valid actors
allowedRoles: ['Central Team Analyst w/M&I entitlement']

// Requirements
- Case must be in Complete status
- Actor must have hasM_I_Entitlement = true
- Must provide remediation reason
- Original completion date must be preserved
```

---

### Rule 8: Defect Remediation → Complete
```typescript
// Valid actors
allowedRoles: ['Central Team Analyst w/M&I entitlement']

// Requirements
- Case must be in Defect Remediation status
- Actor must have hasM_I_Entitlement = true
- originalCompletionDate must be preserved (for SLA reporting)
- New completionDate recorded for remediation
```

---

## State Machine Diagram

```
┌─────────────────────────────────────────────────────┐
│                    CASE CREATED                      │
└─────────────────────────────────────────────────────┘
                        │
                        │
            ┌───────────┴───────────┐
            │                       │
            │ Auto-Close?           │
            │                       │
    ┌───────┴────────┐      ┌──────┴───────┐
    │      YES       │      │      NO      │
    └───────┬────────┘      └──────┬───────┘
            │                      │
            │                      ▼
            │           ┌─────────────────────┐
            │           │    UNASSIGNED       │
            │           │    (PENDING)        │
            │           └─────────────────────┘
            │                      │
            │                      │ Manager Assigns OR
            │                      │ Analyst Self-Selects
            │                      ▼
            │           ┌─────────────────────┐
            │           │   IN PROGRESS       │
            │           │                     │
            │           │ Actor: Analyst      │
            │           └─────────────────────┘
            │                      │
            │           ┌──────────┴──────────┐
            │           │                     │
            │      Self-Solve            Route to Sales
            │           │                     │
            │           │                     ▼
            │           │          ┌─────────────────────┐
            │           │          │ PENDING SALES       │
            │           │          │ REVIEW              │
            │           │          │                     │
            │           │          │ Actor: Analyst      │
            │           │          │ (to initiate)       │
            │           │          └─────────────────────┘
            │           │                     │
            │           │                     │ Analyst Initiates
            │           │                     ▼
            │           │          ┌─────────────────────┐
            │           │          │  IN SALES REVIEW    │
            │           │          │                     │
            │           │          │ Actor: Sales Owner  │
            │           │          └─────────────────────┘
            │           │                     │
            │           │                     │ Sales Owner Completes
            │           │                     ▼
            │           │          ┌─────────────────────┐
            │           │          │ SALES REVIEW        │
            │           │          │ COMPLETE            │
            │           │          │                     │
            │           │          │ Actor: Analyst      │
            │           │          │ (to disposition)    │
            │           │          └─────────────────────┘
            │           │                     │
            │           │                     │ Analyst Dispositions
            │           │                     │
            │           └──────────┬──────────┘
            │                      │
            ▼                      ▼
┌─────────────────────────────────────────────────────┐
│                    COMPLETE                         │
│                                                     │
│  autoClosed: true/false                            │
│  derivedDisposition: (if manual)                   │
└─────────────────────────────────────────────────────┘
                        │
                        │ M&I Analyst Reopens
                        │ (M&I Entitlement Required)
                        ▼
            ┌─────────────────────┐
            │ DEFECT REMEDIATION  │
            │                     │
            │ Actor: M&I Analyst  │
            └─────────────────────┘
                        │
                        │ M&I Analyst Completes
                        │ (Preserves Original Date)
                        ▼
            ┌─────────────────────┐
            │     COMPLETE        │
            │                     │
            │ originalDate:       │
            │ [preserved]         │
            └─────────────────────┘
```

---

## Permissions Summary

| Status | Can View | Can Edit | Can Progress |
|--------|----------|----------|--------------|
| Unassigned | All roles | Manager (assign), Analyst (select) | Manager, Analyst |
| In Progress | All roles | Assigned Analyst | Assigned Analyst |
| Pending Sales Review | All roles | Assigned Analyst | Assigned Analyst |
| In Sales Review | All roles | Sales Owner | Sales Owner |
| Sales Review Complete | All roles | Assigned Analyst | Assigned Analyst |
| Complete | All roles | M&I Analyst only | M&I Analyst only |
| Defect Remediation | All roles | M&I Analyst | M&I Analyst |

---

## Key Differences from Previous Understanding

### ✅ CORRECTED: Pending Sales Review → In Sales Review

**Previous (Incorrect)**:
- Sales Owner opens the case (moves to In Sales Review)

**Current (Correct)**:
- **Central Team Analyst** initiates sales review (moves to In Sales Review)
- Sales Owner then works the case while In Sales Review
- Sales Owner completes review (moves to Sales Review Complete)

**Rationale**: 
The analyst controls when the sales review formally begins. The sales owner's role is to review and complete, not to initiate.

---

## Related Files

- `/data/caseFlowValidation.ts` - Validation logic for status transitions
- `/data/caseFlowScenarios.ts` - Mock cases in each status
- `/data/caseFlowActivities.ts` - Activity logs showing transitions
- `/OFFICIAL_CASE_WORKFLOW.md` - Comprehensive workflow documentation
- `/types/index.ts` - TypeScript type definitions

---

## Mock Data Examples

### Example 1: Unassigned Case
```typescript
{
  id: '312-2025-UNASSIGN-001',
  status: 'Unassigned',
  assignedTo: null,
  createdDate: '2025-10-26',
  // Waiting for manager to assign OR analyst to self-select
}
```

### Example 2: Pending Sales Review
```typescript
{
  id: '312-2025-SALES-001',
  status: 'Pending Sales Review',
  assignedTo: 'Michael Chen', // Analyst still assigned
  salesOwner: 'David Park', // Sales owner identified
  routedDate: '2025-10-25',
  // Analyst (Michael Chen) will initiate sales review
}
```

### Example 3: In Sales Review
```typescript
{
  id: '312-2025-SALES-002',
  status: 'In Sales Review',
  assignedTo: 'Jennifer Wu', // Original analyst
  salesOwner: 'David Park', // Sales owner working the review
  salesReviewInitiatedDate: '2025-10-26T09:00:00',
  // Sales owner (David Park) will complete review
}
```

### Example 4: Sales Review Complete
```typescript
{
  id: '312-2025-SALES-003',
  status: 'Sales Review Complete',
  assignedTo: 'Michael Chen', // Back to original analyst
  salesOwner: 'David Park',
  salesReviewComments: 'Transactions align with client business expansion...',
  salesReviewCompletedDate: '2025-10-26T15:00:00',
  // Analyst (Michael Chen) will disposition to Complete
}
```

---

**Document Version**: 1.0  
**Last Updated**: October 26, 2025  
**Status**: Official - Matches provided status matrix
