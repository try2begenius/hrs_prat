# Updated CAM 312 Case Workflow

## Overview
This document describes the updated case workflow based on the corrected requirements, including role-based transitions and M&I entitlement requirements.

---

## Case Status Flow

### Status: Unassigned (Pending)
**Progress To**: In Progress  
**Actor**: Central Team Analyst, Central Team Manager

**Description**: 
- Case created and placed in workbasket
- Awaiting assignment by manager OR self-selection by analyst
- Both managers and analysts can initiate the case

**Actions**:
- Central Team Manager: Assign to specific analyst
- Central Team Analyst: Self-select from workbasket
- System: Auto-close (for low-risk cases)

---

### Status: In Progress
**Progress To**: Pending Sales Review, Complete  
**Actor**: Central Team Analyst

**Description**:
- Analyst actively working on the case
- Reviewing client data, ORRCA ratings, alerts, and transactions
- **ONLY ANALYSTS** can progress cases from this status (not managers)

**Actions**:
- Review case data and integrations
- Add comments and documentation
- Upload supporting files
- **Complete**: Self-disposition if analyst can determine outcome
- **Route to Sales**: If sales owner input needed for context

**Key Change**: Only Central Team Analysts (not Managers) can disposition or route cases from In Progress

---

### Status: Pending Sales Review
**Progress To**: In Sales Review  
**Actor**: Central Team Analyst

**Description**:
- Case has been routed to sales for input
- **ANALYST** (not sales owner) will initiate the sales review when ready
- Sales owner receives notification but does not "open" the case

**Actions**:
- Analyst initiates sales review (moves to In Sales Review)
- Analyst coordinates with sales owner for feedback

**Key Change**: Analyst controls the transition to In Sales Review (not Sales Owner opening it)

---

### Status: In Sales Review
**Progress To**: Sales Review Complete  
**Actor**: Sales Owner

**Description**:
- Sales owner actively providing feedback on the case
- Reviews client relationship context
- Provides commentary on transactions

**Actions**:
- Sales Owner: Add comments and feedback
- Sales Owner: Provide client relationship context
- Sales Owner: Mark review as complete (requires comments)

**Required Fields**:
- `salesReviewComments` must be populated before completing

---

### Status: Sales Review Complete
**Progress To**: Complete  
**Actor**: Central Team Analyst

**Description**:
- Sales feedback has been provided
- Analyst reviews sales input and makes final disposition
- **ONLY ANALYSTS** can complete cases (not managers)

**Actions**:
- Review sales feedback
- Make final disposition decision
- Submit case as complete

---

### Status: Complete
**Progress To**: Defect Remediation  
**Actor**: Central Team Analyst w/M&I Entitlement

**Description**:
- Case finalized with disposition
- Can only be reopened by analysts with M&I (Monitoring & Investigations) entitlement
- **NOT** managers or administrators

**Actions**:
- View case (all users)
- Reopen for remediation (only M&I entitled analysts)

**Key Change**: Only M&I entitled analysts (not managers/admins) can reopen for remediation

**M&I Entitled Analysts**:
- Michael Chen (hasM_I_Entitlement: true)
- Jennifer Wu (hasM_I_Entitlement: true)

**Non-M&I Analysts**:
- Lisa Brown (hasM_I_Entitlement: false)
- Kevin Rogers (hasM_I_Entitlement: false)

---

### Status: Defect Remediation
**Progress To**: Complete  
**Actor**: Central Team Analyst w/M&I Entitlement

**Description**:
- Case reopened for quality review remediation
- Only M&I entitled analysts can work remediation cases
- Original completion date is preserved for reporting

**Actions**:
- Update case documentation
- Correct deficiencies
- Re-disposition if needed
- Re-submit as complete

**Required Fields**:
- `originalCompletionDate` - preserved from first completion
- `defectRemediationFlag` - set to true
- `completionDate` - updated to remediation completion date

---

## Complete Workflow Diagrams

### Workflow 1: Simple Case (No Sales Review)
```
┌─────────────┐
│ UNASSIGNED  │
│  (Pending)  │
└─────────────┘
      │
      │ Manager Assigns OR
      │ Analyst Self-Selects
      ▼
┌─────────────┐
│ IN PROGRESS │
│             │
│ Actor:      │
│ Analyst     │
└─────────────┘
      │
      │ Analyst
      │ Dispositions
      ▼
┌─────────────┐
│  COMPLETE   │
└─────────────┘
```

### Workflow 2: Case with Sales Review
```
┌─────────────┐
│ UNASSIGNED  │
│  (Pending)  │
└─────────────┘
      │
      │ Analyst Self-Selects
      ▼
┌─────────────┐
│ IN PROGRESS │
│             │
│ Actor:      │
│ Analyst     │
└─────────────┘
      │
      │ Analyst Routes
      │ to Sales
      ▼
┌─────────────────┐
│ PENDING SALES   │
│    REVIEW       │
│                 │
│ Actor: Analyst  │
└─────────────────┘
      │
      │ Analyst Initiates
      │ Sales Review
      ▼
┌─────────────────┐
│  IN SALES       │
│    REVIEW       │
│                 │
│ Actor: Sales    │
│        Owner    │
└─────────────────┘
      │
      │ Sales Provides
      │ Feedback
      ▼
┌─────────────────┐
│ SALES REVIEW    │
│   COMPLETE      │
│                 │
│ Actor: Analyst  │
└─────────────────┘
      │
      │ Analyst Final
      │ Disposition
      ▼
┌─────────────┐
│  COMPLETE   │
└─────────────┘
```

### Workflow 3: Defect Remediation
```
┌─────────────┐
│  COMPLETE   │
│             │
│ Completed:  │
│ 2025-09-28  │
└─────────────┘
      │
      │ M&I Entitled
      │ Analyst Reopens
      ▼
┌─────────────────┐
│     DEFECT      │
│  REMEDIATION    │
│                 │
│ Actor: M&I      │
│ Entitled Analyst│
│                 │
│ Original Date:  │
│ 2025-09-28      │
└─────────────────┘
      │
      │ M&I Analyst
      │ Completes Remediation
      ▼
┌─────────────┐
│  COMPLETE   │
│             │
│ Original:   │
│ 2025-09-28  │
│ Remediated: │
│ 2025-10-26  │
└─────────────┘
```

---

## Actor Permissions Matrix

| From Status | To Status | Allowed Actors | Entitlement Required |
|------------|-----------|----------------|---------------------|
| Unassigned | In Progress | Central Team Analyst, Central Team Manager | None |
| Unassigned | Complete | System (Auto-Close) | None |
| In Progress | Complete | Central Team Analyst | None |
| In Progress | Pending Sales Review | Central Team Analyst | None |
| Pending Sales Review | In Sales Review | Central Team Analyst | None |
| In Sales Review | Sales Review Complete | Sales Owner | None |
| Sales Review Complete | Complete | Central Team Analyst | None |
| Complete | Defect Remediation | Central Team Analyst | **M&I Entitlement** |
| Defect Remediation | Complete | Central Team Analyst | **M&I Entitlement** |

---

## Key Changes from Previous Workflow

### 1. Managers Cannot Progress Cases
**Old**: Managers could disposition cases from In Progress → Complete  
**New**: **ONLY ANALYSTS** can disposition cases

**Rationale**: Analysts are the case workers; managers oversee and assign

---

### 2. Analyst Controls Sales Review Initiation
**Old**: Sales Owner "opens" case from Pending Sales Review → In Sales Review  
**New**: **ANALYST** initiates the sales review

**Rationale**: Analyst coordinates with sales and controls when to formally engage them in the review

---

### 3. M&I Entitlement Required for Remediation
**Old**: Managers/Administrators could reopen cases  
**New**: **ONLY M&I ENTITLED ANALYSTS** can reopen and work remediation

**Rationale**: Defect remediation requires specialized M&I skills and entitlements

---

### 4. Sales Review Complete Requires Analyst
**Old**: Managers could also complete after sales review  
**New**: **ONLY ANALYSTS** complete cases

**Rationale**: Consistent with analysts being the case workers

---

## Mock Data Scenarios

### Scenario 1: Unassigned Case
**Case**: 312-2025-UNASSIGN-001  
**Status**: Unassigned  
**Next Step**: Manager assigns OR analyst self-selects

---

### Scenario 2: In Progress (Analyst Working)
**Case**: 312-2025-001  
**Status**: In Progress  
**Assigned To**: Sarah Mitchell (Analyst)  
**Next Step**: Sarah can disposition OR route to sales

---

### Scenario 3: Pending Sales Review
**Case**: 312-2025-SALES-001  
**Status**: Pending Sales Review  
**Assigned To**: Michael Chen (Analyst)  
**Next Step**: Michael (analyst) initiates sales review

---

### Scenario 4: In Sales Review
**Case**: 312-2025-SALES-002  
**Status**: In Sales Review  
**Assigned To**: David Park (Sales Owner)  
**Next Step**: David provides feedback and completes review

---

### Scenario 5: Sales Review Complete
**Case**: 312-2025-SALES-003  
**Status**: Sales Review Complete  
**Assigned To**: Michael Chen (Analyst)  
**Next Step**: Michael makes final disposition

---

### Scenario 6: Completed Case
**Case**: 312-2025-COMP-001  
**Status**: Complete  
**Completed**: 2025-10-24  
**Can Reopen**: Only M&I entitled analysts (Michael Chen, Jennifer Wu)

---

### Scenario 7: Defect Remediation
**Case**: 312-2025-REM-001  
**Status**: Defect Remediation  
**Assigned To**: Jennifer Wu (M&I Entitled Analyst)  
**Original Completion**: 2025-09-28  
**Next Step**: Jennifer corrects defects and re-submits

---

## M&I Entitlement Details

### What is M&I Entitlement?
M&I (Monitoring & Investigations) entitlement is a special permission granted to select analysts who are trained and authorized to:
- Conduct quality reviews on completed cases
- Identify defects or missing documentation
- Reopen completed cases for remediation
- Work remediation cases to correct deficiencies

### M&I Entitled Users
```typescript
{ 
  id: 'U003', 
  name: 'Michael Chen', 
  role: 'Central Team Analyst', 
  hasM_I_Entitlement: true 
}

{ 
  id: 'U004', 
  name: 'Jennifer Wu', 
  role: 'Central Team Analyst', 
  hasM_I_Entitlement: true 
}
```

### Non-M&I Users
```typescript
{ 
  id: 'U005', 
  name: 'Lisa Brown', 
  role: 'Central Team Analyst', 
  hasM_I_Entitlement: false 
}

{ 
  id: 'U006', 
  name: 'Kevin Rogers', 
  role: 'Central Team Analyst', 
  hasM_I_Entitlement: false 
}

{ 
  id: 'U001', 
  name: 'Sarah Mitchell', 
  role: 'Central Team Manager', 
  hasM_I_Entitlement: false 
}

{ 
  id: 'U002', 
  name: 'Carlos Rivera', 
  role: 'Central Team Manager', 
  hasM_I_Entitlement: false 
}
```

### Validation
```typescript
// Check if user can reopen case for remediation
const canReopen = (user: User, caseStatus: CaseStatus): boolean => {
  if (caseStatus !== 'Complete') return false;
  if (user.role !== 'Central Team Analyst') return false;
  if (!user.hasM_I_Entitlement) return false;
  return true;
};
```

---

## Validation Rules

### Rule 1: Analyst-Only Progressions
```typescript
// These transitions require Central Team Analyst role
const analystOnlyTransitions = [
  { from: 'In Progress', to: 'Complete' },
  { from: 'In Progress', to: 'Pending Sales Review' },
  { from: 'Pending Sales Review', to: 'In Sales Review' },
  { from: 'Sales Review Complete', to: 'Complete' }
];
```

### Rule 2: M&I Entitlement Transitions
```typescript
// These transitions require M&I entitlement
const miEntitlementTransitions = [
  { from: 'Complete', to: 'Defect Remediation' },
  { from: 'Defect Remediation', to: 'Complete' }
];

// Validation
if (miEntitlementTransitions.includes(transition)) {
  if (!user.hasM_I_Entitlement) {
    throw new Error('M&I entitlement required for this action');
  }
}
```

### Rule 3: Sales Owner Actions
```typescript
// Sales Owner can only act on In Sales Review status
const salesOwnerActions = [
  { from: 'In Sales Review', to: 'Sales Review Complete' }
];
```

---

## Activity Log Examples

### Example 1: Analyst Self-Selects and Completes
```
10/26 09:00 - Case created → Unassigned (System)
10/26 09:15 - Self-selected from workbasket → In Progress (Michael Chen - Analyst)
10/26 10:00 - Reviewed client data (Michael Chen)
10/26 14:30 - Reviewed ORRCA rating and alerts (Michael Chen)
10/27 11:00 - Disposition: No Action Required (Michael Chen)
10/27 11:05 - Status → Complete (Michael Chen - Analyst)
```

### Example 2: Sales Review Flow
```
10/20 08:00 - Case created → Unassigned (System)
10/20 08:30 - Self-selected → In Progress (Jennifer Wu - Analyst)
10/22 14:00 - Routed to sales → Pending Sales Review (Jennifer Wu - Analyst)
10/26 09:00 - Initiated sales review → In Sales Review (Jennifer Wu - Analyst)
10/26 15:00 - Sales feedback provided (David Park - Sales Owner)
10/26 15:05 - Status → Sales Review Complete (David Park - Sales Owner)
10/27 10:00 - Final disposition → Complete (Jennifer Wu - Analyst)
```

### Example 3: Defect Remediation
```
09/28 14:35 - Case completed (Jennifer Wu - Analyst)
10/15 10:00 - M&I quality review found missing docs (Michael Chen - M&I Analyst)
10/15 10:30 - Reopened for remediation → Defect Remediation (Michael Chen - M&I Analyst)
10/15 10:35 - Reassigned to Jennifer Wu for remediation (Michael Chen)
10/26 15:00 - Remediation complete → Complete (Jennifer Wu - M&I Analyst)
              Original date: 09/28, Remediation date: 10/26
```

---

## Implementation Notes

### User Interface Considerations
1. **Workbasket View**: Show "Assign" button for managers, "Select" button for analysts
2. **In Progress Cases**: Only show "Complete" and "Route to Sales" for analysts
3. **Pending Sales Review**: Show "Initiate Sales Review" for analysts
4. **Complete Cases**: Show "Reopen for Remediation" only for M&I entitled analysts
5. **Defect Remediation**: Only M&I entitled analysts can work these cases

### Data Model
```typescript
interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  hasM_I_Entitlement?: boolean; // New field for M&I access
}
```

### Validation Functions
```typescript
// From caseFlowValidation.ts
export const canTransitionStatusWithEntitlement = (
  currentStatus: CaseStatus,
  newStatus: CaseStatus,
  user: User
): { allowed: boolean; reason?: string }

export const hasM_I_Entitlement = (user: User): boolean
```

---

## Reporting Impact

### SLA Metrics
- **Use Original Completion Date** for remediation cases
- Case 312-2025-REM-001:
  - Original Completion: 2025-09-28 ← Use this for SLA
  - Remediation Completion: 2025-10-26 ← Do NOT use for SLA

### Quality Metrics
- **M&I Remediation Rate**: Cases with `defectRemediationFlag` / Total completed
- **M&I Analyst Workload**: Cases in Defect Remediation by M&I analyst
- **Remediation Cycle Time**: Time from reopen to re-complete

---

## Testing Checklist

- [ ] Analyst can self-select from Unassigned
- [ ] Manager can assign case to analyst
- [ ] Only analyst can complete from In Progress (manager cannot)
- [ ] Only analyst can route to Pending Sales Review
- [ ] Analyst (not sales owner) initiates In Sales Review
- [ ] Sales Owner can complete Sales Review (with comments)
- [ ] Only analyst can complete from Sales Review Complete
- [ ] Only M&I entitled analyst can reopen Complete case
- [ ] Non-M&I analyst CANNOT reopen Complete case
- [ ] Manager CANNOT reopen Complete case
- [ ] Only M&I entitled analyst can complete Defect Remediation
- [ ] Original completion date preserved during remediation
- [ ] System correctly validates M&I entitlement for remediation actions

---

## Summary of Actors by Status

| Status | Primary Actor | Can Also Act | Cannot Act |
|--------|--------------|-------------|-----------|
| Unassigned | Analyst, Manager | System (auto-close) | Sales, View Only |
| In Progress | **Analyst Only** | - | Manager, Sales, View Only |
| Pending Sales Review | **Analyst Only** | - | Manager, Sales, View Only |
| In Sales Review | **Sales Owner Only** | - | Analyst, Manager, View Only |
| Sales Review Complete | **Analyst Only** | - | Manager, Sales, View Only |
| Complete | **M&I Analyst Only** (to reopen) | All (to view) | Non-M&I Analyst, Manager |
| Defect Remediation | **M&I Analyst Only** | - | Non-M&I Analyst, Manager, Sales |

---

## Related Documentation
- [CASE_FLOW_LOGIC.md](./CASE_FLOW_LOGIC.md) - Original case flow documentation
- [ROLES_IMPLEMENTATION.md](./ROLES_IMPLEMENTATION.md) - Role-based access control
- [DATA_VISIBILITY_MATRIX.md](./DATA_VISIBILITY_MATRIX.md) - User data access patterns
