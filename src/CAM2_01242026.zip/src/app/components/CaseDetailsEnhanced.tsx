import { Case, CaseStatus, Case312Response, CAMCaseResponse, SalesOwnerResponse } from '../types';
import { UserAccess, getPermissionsForRole } from '../data/rolesEntitlementsMockData';
import { toast } from 'sonner';
import { Section312Case } from './case-sections/Section312Case';
import { SectionCAMCase } from './case-sections/SectionCAMCase';
import { SectionSalesReview } from './case-sections/SectionSalesReview';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Separator } from './ui/separator';
import { ArrowLeft, AlertTriangle, Info } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { mockCases } from '../data/enhancedMockData';

interface CaseDetailsEnhancedProps {
  caseId: string;
  onBack: () => void;
  currentUser: UserAccess;
}

export function CaseDetailsEnhanced({ caseId, onBack, currentUser }: CaseDetailsEnhancedProps) {
  const [caseData, setCaseData] = useState<Case | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Get user permissions
  const permissions = getPermissionsForRole(currentUser.role as any);
  const canEditCases = permissions.actionCases;
  
  // 312 Case Response State
  const [case312Response, setCase312Response] = useState<Case312Response>({
    question1_disposition: undefined,
    question1_commentary: undefined,
    question2_disposition: undefined,
    question2_commentary: undefined,
    question3_option: undefined,
    question3_comments: undefined,
    question4_disposition: undefined,
    question4_commentary: undefined,
    caseAction: undefined,
    trmsNumber: undefined,
    salesOwner: undefined,
    salesComments: undefined,
  });

  // CAM Case Response State
  const [camCaseResponse, setCAMCaseResponse] = useState<CAMCaseResponse>({
    question1: null,
    question1_1_attestations: [],
    question1_2_trms: undefined,
    question1_3_trmsNumber: undefined,
    question2_confirmation: false,
    question3_action: undefined,
    question3_trms: undefined,
    question3_salesOwner: undefined,
    question3_comments: undefined,
    question3_confirmation: false,
  });

  // Sales Owner Response State
  const [salesOwnerResponse, setSalesOwnerResponse] = useState<SalesOwnerResponse>({
    comments: '',
  });

  // Warning/Alert Dialog States
  const [showSaveWarning, setShowSaveWarning] = useState(false);
  const [showSubmitWarning, setShowSubmitWarning] = useState(false);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');
  const [submitSection, setSubmitSection] = useState<'312' | 'CAM' | 'sales' | null>(null);

  useEffect(() => {
    // Load case data
    const foundCase = mockCases.find(c => c.id === caseId);
    if (foundCase) {
      setCaseData(foundCase);
      
      // Load existing responses if any
      if (foundCase.case312Response) {
        setCase312Response(foundCase.case312Response);
      }
      if (foundCase.camCaseResponse) {
        setCAMCaseResponse(foundCase.camCaseResponse);
      }
      if (foundCase.salesOwnerResponse) {
        setSalesOwnerResponse(foundCase.salesOwnerResponse);
      }
    }
    setLoading(false);
  }, [caseId]);

  if (loading || !caseData) {
    return <div className="flex items-center justify-center h-96">Loading case details...</div>;
  }

  const getStatusColor = (status: CaseStatus) => {
    switch (status) {
      case 'Unassigned': return 'bg-gray-100 text-gray-800';
      case 'In Progress': return 'bg-amber-100 text-amber-800';
      case 'Pending Sales Review': return 'bg-blue-100 text-blue-800';
      case 'In Sales Review': return 'bg-purple-100 text-purple-800';
      case 'Sales Review Complete': return 'bg-indigo-100 text-indigo-800';
      case 'Complete': return 'bg-green-100 text-green-800';
      case 'Defect Remediation': return 'bg-red-100 text-red-800';
      case 'Under Review': return 'bg-purple-100 text-purple-800';
      case 'Escalated': return 'bg-destructive/10 text-destructive';
      case 'Closed': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-gray-100 text-gray-800';
    }
  };

  // Validate 312 section before save
  const validate312Save = (): boolean => {
    const lob = caseData.lineOfBusiness || caseData.clientData?.lineOfBusiness;
    const isML = lob === 'ML';
    
    // Question 1 - Required for all LOBs
    if (!case312Response.question1_disposition) {
      setWarningMessage('Question 1: Expected Value and Volume - Disposition is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (!case312Response.question1_commentary || case312Response.question1_commentary.trim() === '') {
      setWarningMessage('Question 1: Expected Value and Volume - Commentary is required.');
      setShowSaveWarning(true);
      return false;
    }
    
    // Question 2 - Required for all LOBs
    if (!case312Response.question2_disposition) {
      setWarningMessage('Question 2: Cross Border Movement - Disposition is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (!case312Response.question2_commentary || case312Response.question2_commentary.trim() === '') {
      setWarningMessage('Question 2: Cross Border Movement - Commentary is required.');
      setShowSaveWarning(true);
      return false;
    }
    
    // Question 3 - Required for all LOBs
    if (!case312Response.question3_option) {
      setWarningMessage('Question 3: Purpose of Relationship/Account - Response is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (case312Response.question3_option === 'activity_differed' && (!case312Response.question3_comments || case312Response.question3_comments.trim() === '')) {
      setWarningMessage('Question 3: Purpose of Relationship/Account - Comments are required when activity differed.');
      setShowSaveWarning(true);
      return false;
    }
    
    // Question 4 - Required for ML only
    if (isML) {
      if (!case312Response.question4_disposition) {
        setWarningMessage('Question 4: Source of Funds - Disposition is required for ML cases.');
        setShowSaveWarning(true);
        return false;
      }
      if (!case312Response.question4_commentary || case312Response.question4_commentary.trim() === '') {
        setWarningMessage('Question 4: Source of Funds - Commentary is required for ML cases.');
        setShowSaveWarning(true);
        return false;
      }
    }
    
    // Case Action - Required for all LOBs
    if (!case312Response.caseAction) {
      setWarningMessage('Case Action is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (case312Response.caseAction === 'complete_trms_filed' && (!case312Response.trmsNumber || case312Response.trmsNumber.trim() === '')) {
      setWarningMessage('Please provide TRMS number when case action is "Complete – TRMS filed".');
      setShowSaveWarning(true);
      return false;
    }
    if (case312Response.caseAction === 'send_to_sales' && !case312Response.salesOwner) {
      setWarningMessage('Please select Sales Owner when case action is "Send to Sales".');
      setShowSaveWarning(true);
      return false;
    }
    
    return true;
  };

  // Validate CAM section before save
  const validateCAMSave = (): boolean => {
    if (camCaseResponse.question1 === null) {
      setWarningMessage('Question 1 is required.');
      setShowSaveWarning(true);
      return false;
    }
    // If No to Q1, must check BOTH attestations
    if (camCaseResponse.question1 === false) {
      const requiredAttestations = [
        'I have reviewed the alerts and escalations and believe no further escalation is required to be raised',
        'No additional findings or knowledge of the client require an escalation outside of what has been already properly escalated'
      ];
      const checkedAttestations = camCaseResponse.question1_1_attestations || [];
      const allChecked = requiredAttestations.every(att => checkedAttestations.includes(att));
      
      if (!allChecked) {
        setWarningMessage('Please check both attestations for Question 1.1');
        setShowSaveWarning(true);
        return false;
      }
    }
    if (camCaseResponse.question1 === true && !camCaseResponse.question1_2_trms) {
      setWarningMessage('Please indicate if TRMS was filed for Question 1.2');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question1 === true && camCaseResponse.question1_2_trms === 'yes' && !camCaseResponse.question1_3_trmsNumber) {
      setWarningMessage('Please provide TRMS number for Question 1.3');
      setShowSaveWarning(true);
      return false;
    }
    if (!camCaseResponse.question2_confirmation) {
      setWarningMessage('Question 2 confirmation is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (!camCaseResponse.question3_action) {
      setWarningMessage('Question 3 (Case Action) is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question3_action === 'complete_trms_filed' && !camCaseResponse.question3_trms) {
      setWarningMessage('Please provide TRMS number for Case Action.');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question3_action === 'send_to_sales' && !camCaseResponse.question3_salesOwner) {
      setWarningMessage('Please select Sales Owner for Case Action.');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question3_action === 'send_to_sales' && !camCaseResponse.question3_comments) {
      setWarningMessage('Comments are mandatory when sending to Sales.');
      setShowSaveWarning(true);
      return false;
    }
    // Confirmation checkbox required for Complete actions
    if ((camCaseResponse.question3_action === 'complete_trms_filed' || camCaseResponse.question3_action === 'complete_no_action') && !camCaseResponse.question3_confirmation) {
      setWarningMessage('Please confirm that all data has been reviewed before completing the case action.');
      setShowSaveWarning(true);
      return false;
    }
    return true;
  };

  // Save handlers
  const handle312Save = () => {
    if (!validate312Save()) return;
    
    toast.success('312 Case responses saved successfully');
  };

  const handleCAMSave = () => {
    if (!validateCAMSave()) return;
    
    toast.success('CAM Case responses saved successfully');
  };

  const handleSalesSave = () => {
    if (!salesOwnerResponse.comments || salesOwnerResponse.comments.trim() === '') {
      setWarningMessage('Please provide comments before saving.');
      setShowSaveWarning(true);
      return;
    }
    if (salesOwnerResponse.comments.length > 4000) {
      setWarningMessage('Comments cannot exceed 4000 characters.');
      setShowSaveWarning(true);
      return;
    }
    
    toast.success('Sales Owner response saved successfully');
  };

  // Submit handlers
  const handle312Submit = () => {
    if (!validate312Save()) return;
    
    setSubmitSection('312');
    setWarningMessage('Once you submit, you will be unable to make edits/changes to this section. Do you want to proceed?');
    setShowSubmitConfirm(true);
  };

  const handleCAMSubmit = () => {
    if (!validateCAMSave()) return;
    
    setSubmitSection('CAM');
    setWarningMessage('Once you submit, you will be unable to make edits/changes to this section. Do you want to proceed?');
    setShowSubmitConfirm(true);
  };

  const handleSalesSubmit = () => {
    if (!salesOwnerResponse.comments || salesOwnerResponse.comments.trim() === '') {
      setWarningMessage('Please provide comments before returning to Case Processor.');
      setShowSubmitWarning(true);
      return;
    }
    
    setSubmitSection('sales');
    setWarningMessage('This will return the case to the Case Processor for final review. Do you want to proceed?');
    setShowSubmitConfirm(true);
  };

  const confirmSubmit = () => {
    if (submitSection === '312') {
      setCase312Response({
        ...case312Response,
        submittedBy: currentUser.name,
        submittedDate: new Date().toISOString(),
        isSubmitted: true,
      });
      toast.success('312 Case submitted successfully');
    } else if (submitSection === 'CAM') {
      setCAMCaseResponse({
        ...camCaseResponse,
        submittedBy: currentUser.name,
        submittedDate: new Date().toISOString(),
        isSubmitted: true,
      });
      toast.success('CAM Case submitted successfully');
    } else if (submitSection === 'sales') {
      setSalesOwnerResponse({
        ...salesOwnerResponse,
        submittedBy: currentUser.name,
        submittedDate: new Date().toISOString(),
        isSubmitted: true,
      });
      toast.success('Case returned to Case Processor successfully');
    }
    setShowSubmitConfirm(false);
    setSubmitSection(null);
  };

  const is312Case = caseData.is312Case || caseData.caseType === '312 Review';
  const isCAMCase = caseData.caseType === 'CAM Review' || is312Case;
  
  // Section 5 is visible to Sales Owners and AML users (access control is in the component itself)
  const canViewSalesSection = true;

  // Check if sections are submitted (read-only)
  const is312Submitted = case312Response.isSubmitted || false;
  const isCAMSubmitted = camCaseResponse.isSubmitted || false;
  const isSalesSubmitted = salesOwnerResponse.isSubmitted || false;

  return (
    <div className="space-y-6">
      {/* Section 1: Case Banner - Always Visible */}
      <Card className="border-l-4 border-l-primary">
        <CardHeader className="bg-muted/30 pb-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={onBack} className="hover:bg-muted">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Worklist
            </Button>
            <Badge className={getStatusColor(caseData.status) + ' text-sm px-3 py-1'}>
              {caseData.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            <div>
              <Label className="text-xs text-muted-foreground">Case ID</Label>
              <p className="font-mono font-semibold text-primary mt-1">{caseData.id}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Client Name</Label>
              <p className="font-medium mt-1">{caseData.clientName}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">GCI/MP ID</Label>
              <p className="font-mono text-sm mt-1">
                {caseData.gci || '-'}
                {caseData.mpId && <span className="text-muted-foreground"> / {caseData.mpId}</span>}
              </p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Party ID</Label>
              <p className="font-mono text-sm mt-1">{caseData.partyId || '-'}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Case Status</Label>
              <p className="font-medium mt-1">{caseData.status}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Case Assignee</Label>
              <p className="font-medium mt-1">{caseData.assignedTo}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sections 2-5: Accordion Sections */}
      <Accordion type="multiple" className="space-y-4" defaultValue={['section2']}>
        {/* Section 2: Case and Client Details */}
        <AccordionItem value="section2" className="border rounded-lg bg-card">
          <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-muted/50">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-sm font-semibold text-primary">1</span>
              </div>
              <span className="font-semibold">Case and Client Details</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-6">
            <Separator className="my-4" />
            
            {/* Common Client Information */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4">Client Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <Label className="text-xs text-muted-foreground">Entity Name</Label>
                  <p className="mt-1">{caseData.entityName || caseData.clientData?.legalName || '-'}</p>
                </div>
                {caseData.firstName && (
                  <>
                    <div>
                      <Label className="text-xs text-muted-foreground">First Name</Label>
                      <p className="mt-1">{caseData.firstName}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Middle Name</Label>
                      <p className="mt-1">{caseData.middleName || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Last Name</Label>
                      <p className="mt-1">{caseData.lastName || '-'}</p>
                    </div>
                  </>
                )}
                <div>
                  <Label className="text-xs text-muted-foreground">Case Number</Label>
                  <p className="font-mono mt-1">{caseData.id}</p>
                </div>
              </div>
            </div>

            {/* 312 and CAM Attributes Side-by-Side */}
            {(is312Case || isCAMCase) && (
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-muted-foreground mb-4">Case Attributes</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  
                  {/* 312 Attributes - Left Column */}
                  {is312Case && caseData.case312Data && (
                    <div className="border rounded-lg p-4 bg-blue-50/30 border-blue-200">
                      <div className="flex items-center gap-2 mb-4">
                        <Badge variant="default" className="bg-blue-600">312</Badge>
                        <h4 className="font-semibold text-sm">312 Case Attributes</h4>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-xs text-muted-foreground">312 Due Date</Label>
                          <p className="mt-1">{caseData.case312Data.dueDate || caseData.dueDate}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">312 Aging</Label>
                          <p className="mt-1">{caseData.case312Data.aging || 0} days</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">312 Case Status</Label>
                          <p className="mt-1">{caseData.case312Data.status || 'In Progress'}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">312 Case Disposition</Label>
                          <p className="mt-1">{caseData.case312Data.disposition || 'Pending'}</p>
                        </div>
                        {caseData.case312Data.completedDate && (
                          <div>
                            <Label className="text-xs text-muted-foreground">312 Completed Date</Label>
                            <p className="mt-1">{caseData.case312Data.completedDate}</p>
                          </div>
                        )}
                        {caseData.case312Data.sourceOfFunds && (
                          <div>
                            <Label className="text-xs text-muted-foreground">Source of Funds</Label>
                            <p className="mt-1">{caseData.case312Data.sourceOfFunds}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* CAM Attributes - Right Column */}
                  {isCAMCase && caseData.camCaseData && (
                    <div className="border rounded-lg p-4 bg-emerald-50/30 border-emerald-200">
                      <div className="flex items-center gap-2 mb-4">
                        <Badge variant="default" className="bg-emerald-600">CAM</Badge>
                        <h4 className="font-semibold text-sm">CAM Case Attributes</h4>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-xs text-muted-foreground">CAM Due Date</Label>
                          <p className="mt-1">{caseData.camCaseData.dueDate || caseData.dueDate}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">CAM Aging</Label>
                          <p className="mt-1">{caseData.camCaseData.aging || 0} days</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">CAM Case Status</Label>
                          <p className="mt-1">{caseData.camCaseData.status || 'In Progress'}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground">CAM Case Disposition</Label>
                          <p className="mt-1">{caseData.camCaseData.disposition || 'Pending'}</p>
                        </div>
                        {caseData.camCaseData.completedDate && (
                          <div>
                            <Label className="text-xs text-muted-foreground">CAM Completed Date</Label>
                            <p className="mt-1">{caseData.camCaseData.completedDate}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* General Case Information */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4">General Case Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <Label className="text-xs text-muted-foreground">Assigned To</Label>
                  <p className="mt-1">{caseData.assignedTo}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">LOB(s)</Label>
                  <p className="mt-1">{caseData.lineOfBusiness || caseData.clientData?.lineOfBusiness || '-'}</p>
                </div>
                {is312Case && (
                  <div>
                    <Label className="text-xs text-muted-foreground">312 Client</Label>
                    <Badge variant={is312Case ? "default" : "outline"} className="mt-1">
                      {is312Case ? 'Yes' : 'No'}
                    </Badge>
                  </div>
                )}
                <div>
                  <Label className="text-xs text-muted-foreground">BOA Employee</Label>
                  <Badge 
                    variant={(caseData.isBACEmployee || caseData.clientData?.isEmployee) ? "default" : "outline"} 
                    className={(caseData.isBACEmployee || caseData.clientData?.isEmployee) ? "mt-1 bg-purple-600" : "mt-1"}
                  >
                    {(caseData.isBACEmployee || caseData.clientData?.isEmployee) ? 'Yes' : 'No'}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">BOA Affiliate Indicator</Label>
                  <Badge 
                    variant={caseData.isBACAffiliate ? "default" : "outline"} 
                    className={caseData.isBACAffiliate ? "mt-1 bg-indigo-600" : "mt-1"}
                  >
                    {caseData.isBACAffiliate ? 'Yes' : 'No'}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Reg O Indicator</Label>
                  <Badge 
                    variant={caseData.isRegO ? "default" : "outline"} 
                    className={caseData.isRegO ? "mt-1 bg-orange-600" : "mt-1"}
                  >
                    {caseData.isRegO ? 'Yes' : 'No'}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Business & Compliance Information */}
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-4">Business & Compliance Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {caseData.naicsCode && (
                  <>
                    <div>
                      <Label className="text-xs text-muted-foreground">NAICS Code</Label>
                      <p className="font-mono mt-1">{caseData.naicsCode}</p>
                    </div>
                    <div className="md:col-span-2">
                      <Label className="text-xs text-muted-foreground">NAICS Description</Label>
                      <p className="mt-1">{caseData.naicsDescription || '-'}</p>
                    </div>
                  </>
                )}
                {caseData.refreshDueDates && caseData.refreshDueDates.length > 0 && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Refresh Due Date(s)</Label>
                    <p className="mt-1">{caseData.refreshDueDates.join(', ')}</p>
                  </div>
                )}
                {caseData.lastRefreshCompletionDate && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Last Refresh Completion Date</Label>
                    <p className="mt-1">{caseData.lastRefreshCompletionDate}</p>
                  </div>
                )}
                {caseData.clientOwners && caseData.clientOwners.length > 0 && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Client Owner(s)</Label>
                    <p className="mt-1">{caseData.clientOwners.join(', ')}</p>
                  </div>
                )}
              </div>
              
              {/* AML Attributes - Full Width */}
              {caseData.amlAttributes && caseData.amlAttributes.length > 0 && (
                <div className="mt-6">
                  <Label className="text-xs text-muted-foreground">AML Attributes / CBA Codes</Label>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {caseData.amlAttributes.map((attr, idx) => (
                      <Badge key={idx} variant="outline" className="border-blue-300 text-blue-800 bg-blue-50">
                        {attr}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Section 3: 312 Case (only if is312Case AND user has permission) */}
        {is312Case && permissions.view312Tab && (
          <Section312Case
            caseData={caseData}
            response={case312Response}
            setResponse={setCase312Response}
            isSubmitted={is312Submitted}
            canEdit={canEditCases}
            onSave={handle312Save}
            onCancel={onBack}
            onSubmit={handle312Submit}
          />
        )}

        {/* Section 4: CAM Case (only if isCAMCase AND user has permission) */}
        {isCAMCase && caseData.camCaseData && permissions.viewCAMTab && (
          <SectionCAMCase
            caseData={caseData}
            response={camCaseResponse}
            setResponse={setCAMCaseResponse}
            isSubmitted={isCAMSubmitted}
            canEdit={canEditCases}
            onSave={handleCAMSave}
            onCancel={onBack}
            onSubmit={handleCAMSubmit}
          />
        )}

        {/* Section 5: Sales Owner Review (visible to Sales Owner and Assignee) */}
        {canViewSalesSection && (
          <SectionSalesReview
            caseData={caseData}
            response={salesOwnerResponse}
            setResponse={setSalesOwnerResponse}
            isSubmitted={isSalesSubmitted}
            onSave={handleSalesSave}
            onCancel={onBack}
            onSubmit={handleSalesSubmit}
            currentUser={currentUser}
          />
        )}
      </Accordion>

      {/* Warning Dialogs */}
      <AlertDialog open={showSaveWarning} onOpenChange={setShowSaveWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600" />
              Validation Warning
            </AlertDialogTitle>
            <AlertDialogDescription>{warningMessage}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowSaveWarning(false)}>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showSubmitWarning} onOpenChange={setShowSubmitWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600" />
              Submission Warning
            </AlertDialogTitle>
            <AlertDialogDescription>{warningMessage}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowSubmitWarning(false)}>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showSubmitConfirm} onOpenChange={setShowSubmitConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Info className="h-5 w-5 text-blue-600" />
              Confirm Submission
            </AlertDialogTitle>
            <AlertDialogDescription>{warningMessage}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setShowSubmitConfirm(false);
              setSubmitSection(null);
            }}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmSubmit}>Confirm</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}