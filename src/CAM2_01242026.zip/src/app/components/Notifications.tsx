import { Box, Card, CardContent, Typography, Chip, Tabs, Tab, List, ListItem, ListItemText, Divider } from '@mui/material';
import { Notifications as NotificationsIcon, Email, CheckCircle, Warning, Schedule } from '@mui/icons-material';
import { UserAccess } from '../data/rolesEntitlementsMockData';
import { useState } from 'react';

interface NotificationsProps {
  currentUser: UserAccess;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

export function Notifications({ currentUser }: NotificationsProps) {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const notifications = [
    {
      id: 1,
      type: 'Case Assignment',
      message: 'New case assigned to you: 312-2025-100',
      time: '2 hours ago',
      read: false,
      icon: <NotificationsIcon />,
    },
    {
      id: 2,
      type: 'Sales Review',
      message: 'Sales review completed for case 312-2025-075',
      time: '5 hours ago',
      read: false,
      icon: <CheckCircle />,
    },
    {
      id: 3,
      type: 'Due Date',
      message: 'Case 312-2025-050 due in 2 days',
      time: '1 day ago',
      read: true,
      icon: <Schedule />,
    },
  ];

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Notifications
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Stay updated on case activities and system events
        </Typography>
      </Box>

      <Card>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={tabValue} onChange={handleTabChange}>
            <Tab label="All Notifications" />
            <Tab label="Unread" />
            <Tab label="Email History" />
          </Tabs>
        </Box>

        <TabPanel value={tabValue} index={0}>
          <List>
            {notifications.map((notification, index) => (
              <Box key={notification.id}>
                <ListItem
                  sx={{
                    bgcolor: notification.read ? 'transparent' : 'action.hover',
                    borderLeft: notification.read ? 0 : 3,
                    borderColor: 'primary.main',
                  }}
                >
                  <Box sx={{ mr: 2, color: 'primary.main' }}>{notification.icon}</Box>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Typography variant="body2" fontWeight={notification.read ? 400 : 600}>
                          {notification.message}
                        </Typography>
                        <Chip label={notification.type} size="small" variant="outlined" />
                      </Box>
                    }
                    secondary={notification.time}
                  />
                </ListItem>
                {index < notifications.length - 1 && <Divider />}
              </Box>
            ))}
          </List>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <CardContent>
            <Typography variant="body2">
              {notifications.filter(n => !n.read).length} unread notifications
            </Typography>
          </CardContent>
        </TabPanel>

        <TabPanel value={tabValue} index={2}>
          <CardContent>
            <Typography variant="body2">Email notification history...</Typography>
          </CardContent>
        </TabPanel>
      </Card>
    </Box>
  );
}
