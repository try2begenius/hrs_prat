import { Box, Card, CardContent, Typography, Button, Chip } from '@mui/material';
import { PlayArrow, CheckCircle, Cancel, Warning } from '@mui/icons-material';

export function PopulationIdentification() {
  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" gutterBottom>
            Population Identification
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Automated identification of clients requiring 312 and CAM review
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<PlayArrow />}>
          Run Identification
        </Button>
      </Box>

      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Population Identification Logic
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            The system automatically identifies clients based on LOB-specific triggers
          </Typography>

          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {[
              { lob: 'PB/ML/CI', rule: '180-day refresh cycles for high-risk ratings' },
              { lob: 'GB/GM', rule: 'Global DGA due dates' },
              { lob: 'Consumer', rule: '120-day refresh cycles' },
              { lob: 'Small Business', rule: '95 days before refresh anniversary' },
            ].map((item) => (
              <Box
                key={item.lob}
                sx={{
                  p: 2,
                  border: 1,
                  borderColor: 'divider',
                  borderRadius: 1,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <Box>
                  <Chip label={item.lob} size="small" sx={{ mb: 1 }} />
                  <Typography variant="body2">{item.rule}</Typography>
                </Box>
                <CheckCircle color="success" />
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
