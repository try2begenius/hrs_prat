import { Box, Card, CardContent, Typography, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, Tab, Alert } from '@mui/material';
import { CheckCircle, Cancel, Security, People, VpnKey, Lock, Person, Settings, Warning, Schedule, Block } from '@mui/icons-material';
import { roleDefinitions, mockUsers, userAccessHistory } from '../data/rolesEntitlementsMockData';
import { useState } from 'react';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

export function RolesEntitlements() {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Roles & Entitlements
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Manage user roles, permissions, and access control across the platform
        </Typography>
      </Box>

      <Alert severity="info" sx={{ mb: 3 }}>
        <Typography variant="body2">
          Role-based access control ensures users only see data relevant to their LOBs and responsibilities
        </Typography>
      </Alert>

      <Card>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={tabValue} onChange={handleTabChange}>
            <Tab label="Role Definitions" />
            <Tab label="User Access" />
            <Tab label="Access History" />
          </Tabs>
        </Box>

        <TabPanel value={tabValue} index={0}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              System Roles
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
              {roleDefinitions.map((role) => (
                <Card key={role.role} variant="outlined">
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Box>
                        <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                          {role.role}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {role.description}
                        </Typography>
                      </Box>
                      <Chip
                        label={`${role.userCount} users`}
                        size="small"
                        color="primary"
                        variant="outlined"
                      />
                    </Box>

                    <Typography variant="caption" color="text.secondary" fontWeight={600}>
                      Key Permissions:
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                      {role.keyPermissions.map((perm) => (
                        <Chip key={perm} label={perm} size="small" variant="outlined" />
                      ))}
                    </Box>
                  </CardContent>
                </Card>
              ))}
            </Box>
          </CardContent>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Active Users
            </Typography>
            <TableContainer sx={{ mt: 2 }}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>User</TableCell>
                    <TableCell>Role</TableCell>
                    <TableCell>LOBs</TableCell>
                    <TableCell>312 Access</TableCell>
                    <TableCell>CAM Access</TableCell>
                    <TableCell>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {mockUsers.filter(u => u.status === 'Active').map((user) => (
                    <TableRow key={user.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600}>
                          {user.name}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {user.email}
                        </Typography>
                      </TableCell>
                      <TableCell>{user.role}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                          {user.entitlements.lobs.map(lob => (
                            <Chip key={lob} label={lob} size="small" variant="outlined" />
                          ))}
                        </Box>
                      </TableCell>
                      <TableCell>
                        {user.entitlements.has312Access ? (
                          <CheckCircle color="success" fontSize="small" />
                        ) : (
                          <Cancel color="action" fontSize="small" />
                        )}
                      </TableCell>
                      <TableCell>
                        {user.entitlements.hasCAMAccess ? (
                          <CheckCircle color="success" fontSize="small" />
                        ) : (
                          <Cancel color="action" fontSize="small" />
                        )}
                      </TableCell>
                      <TableCell>
                        <Chip label={user.status} size="small" color="success" />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </TabPanel>

        <TabPanel value={tabValue} index={2}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Recent Access Changes
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
              {userAccessHistory.slice(0, 10).map((history) => (
                <Box
                  key={history.id}
                  sx={{
                    p: 2,
                    border: 1,
                    borderColor: 'divider',
                    borderRadius: 1,
                  }}
                >
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <Box>
                      <Typography variant="body2" fontWeight={600}>
                        {history.userName}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {history.changeType} - {history.description}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        By {history.changedBy} on {history.timestamp}
                      </Typography>
                    </Box>
                    <Chip label={history.changeType} size="small" variant="outlined" />
                  </Box>
                </Box>
              ))}
            </Box>
          </CardContent>
        </TabPanel>
      </Card>
    </Box>
  );
}
