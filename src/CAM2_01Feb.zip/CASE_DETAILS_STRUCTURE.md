# Case Details Component Structure

## Overview
The CaseDetailsEnhanced_NEW.tsx component has been reorganized into modular sections for better maintainability and organization.

## Folder Structure

```
/src/app/components/
├── case-details/
│   └── SectionCaseClientDetails.tsx    # Case and Client Details tab content
├── case-sections/
│   ├── Section312Case.tsx              # 312 CAM workflow section
│   ├── SectionCAMCase.tsx              # CAM workflow section
│   └── SectionSalesReview.tsx          # Sales Review section
└── CaseDetailsEnhanced_NEW.tsx         # Main component with tabs and orchestration
```

## Component Breakdown

### 1. **SectionCaseClientDetails.tsx** (`/case-details/`)
**Purpose:** Displays Case and Client Details (Tab 1)

**Content:**
- TBD1 Section (Entity information, LOB, Client Owner, Country of Citizenship, BofA flags)
- TBD2 Section (NAICS codes, Source of Wealth/Funds, CRA codes)
- 312 Attributes (312 Due Date, Aging, Status, Disposition)
- CAM Attributes (CAM Due Date, Status, Disposition)

**Props:**
- `caseData: Case` - The case data object

---

### 2. **Section312Case.tsx** (`/case-sections/`)
**Purpose:** 312 CAM workflow questionnaire and actions (Tab 2)

**Content:**
- 312 Case Details (Due Date, Model Result)
- Expected Activity Volume and Value
- Purpose of Relationship/Account
- Source of Funds
- Required Questions (1-4 with LOB-specific logic)
- Case Action (Complete/TRMS/Send to Sales)
- Save/Submit functionality

**Props:**
- `caseData: Case`
- `response: Case312Response`
- `setResponse: (response: Case312Response) => void`
- `isSubmitted: boolean`
- `canEdit: boolean`
- `onSave: () => void`
- `onCancel: () => void`
- `onSubmit: () => void`

---

### 3. **SectionCAMCase.tsx** (`/case-sections/`)
**Purpose:** CAM workflow questionnaire and actions (Tab 3)

**Content:**
- CAM Case Details
- Question 1 (Alerts/Escalations with attestations)
- Question 2 (Data verification confirmation)
- Question 3 (Case Action)
- Save/Submit functionality

**Props:**
- `caseData: Case`
- `response: CAMCaseResponse`
- `setResponse: (response: CAMCaseResponse) => void`
- `isSubmitted: boolean`
- `canEdit: boolean`
- `onSave: () => void`
- `onCancel: () => void`
- `onSubmit: () => void`

---

### 4. **SectionSalesReview.tsx** (`/case-sections/`)
**Purpose:** Sales Owner review and comments (Tab 4)

**Content:**
- Case summary for sales review
- Sales Owner comments textarea
- Return to Case Processor action
- Save/Submit functionality

**Props:**
- `caseData: Case`
- `response: SalesOwnerResponse`
- `setResponse: (response: SalesOwnerResponse) => void`
- `isSubmitted: boolean`
- `onSave: () => void`
- `onCancel: () => void`
- `onSubmit: () => void`
- `currentUser: UserAccess`

---

### 5. **CaseDetailsEnhanced_NEW.tsx** (Main Component)
**Purpose:** Orchestrates all sections with tab navigation and state management

**Responsibilities:**
- Case Banner (Case ID, Client Name, Status, IDs)
- Tab Navigation (Material-UI Tabs)
- State Management (312 Response, CAM Response, Sales Response)
- Validation Logic
- Save/Submit Handlers
- Warning/Confirmation Dialogs
- Permission Checks

**Features:**
- Dynamic tab visibility based on case type and permissions
- Role-based access control
- Submit confirmations with read-only enforcement
- Validation warnings before save/submit

---

## Benefits of This Structure

### ✅ Modularity
Each section is self-contained and can be modified independently

### ✅ Reusability
Section components can be reused in other views if needed

### ✅ Maintainability
Easier to locate and update specific functionality

### ✅ Testing
Individual sections can be tested in isolation

### ✅ Code Organization
Clear separation of concerns between display and business logic

---

## Import Paths

When importing these components:

```typescript
// Case and Client Details
import { SectionCaseClientDetails } from '@/app/components/case-details/SectionCaseClientDetails';

// Workflow Sections
import { Section312Case } from '@/app/components/case-sections/Section312Case';
import { SectionCAMCase } from '@/app/components/case-sections/SectionCAMCase';
import { SectionSalesReview } from '@/app/components/case-sections/SectionSalesReview';
```

---

## Future Enhancements

### Potential Additional Folders:
- `/case-comments/` - Comments section components
- `/case-documents/` - Documents section components
- `/case-history/` - Case history and audit trail
- `/case-actions/` - Reusable action buttons and workflows

---

Last Updated: February 2, 2026
