# Data Dictionary - Excel Guide

## Overview

The CAM Case Management System database schema has been exported to Excel-compatible CSV files that can be easily opened, filtered, and analyzed in Microsoft Excel or Google Sheets.

## Files Created

### 1. **data_dictionary.csv** (Main File)
The primary data dictionary containing all tables and columns in a single file.

**Columns:**
- Table Name
- Column Name
- Data Type
- Nullable
- Default
- Constraints
- Description

**Row Count:** 145 columns across 10 tables

---

### 2. **data_dictionary_tables.csv**
Summary of all database tables with metadata.

**Columns:**
- Table Name
- Purpose
- Primary Key
- Row Count Estimate
- Indexes
- Retention Policy

**Row Count:** 10 tables

---

### 3. **data_dictionary_relationships.csv**
Entity relationships showing foreign key connections between tables.

**Columns:**
- Parent Table
- Child Table
- Relationship Type
- Foreign Key Column
- Cardinality
- Description

**Row Count:** 11 relationships

---

### 4. **data_dictionary_lob_config.csv**
LOB (Line of Business) configuration reference data.

**Columns:**
- LOB Code
- LOB Name
- Trigger Type
- Days Threshold
- Requires 312
- Description

**Row Count:** 6 LOB configurations

---

### 5. **data_dictionary_business_rules.csv**
Business rules and constraints organized by table.

**Columns:**
- Table Name
- Rule Category
- Rule Description
- Impact

**Row Count:** 40+ business rules

---

## How to Use in Excel

### Opening the Files

#### Method 1: Direct Import
1. Open Microsoft Excel
2. Go to **File > Open**
3. Navigate to `/database/` folder
4. Select the CSV file
5. Excel will automatically parse the file

#### Method 2: Import Wizard
1. Open Excel
2. Go to **Data > Get Data > From File > From Text/CSV**
3. Select the CSV file
4. Review the preview
5. Click **Load**

### Creating a Multi-Sheet Workbook

To combine all CSV files into a single Excel workbook with multiple sheets:

1. Open **data_dictionary.csv** in Excel
2. Save as **CAM_Data_Dictionary.xlsx** (Excel format)
3. For each additional CSV file:
   - Right-click on sheet tabs at bottom
   - Select **Insert > Worksheet**
   - Open the CSV file
   - Copy all data (Ctrl+A, Ctrl+C)
   - Paste into the new sheet (Ctrl+V)
   - Rename the sheet tab appropriately

**Suggested Sheet Names:**
- Sheet 1: "All Columns" (from data_dictionary.csv)
- Sheet 2: "Tables Summary" (from data_dictionary_tables.csv)
- Sheet 3: "Relationships" (from data_dictionary_relationships.csv)
- Sheet 4: "LOB Config" (from data_dictionary_lob_config.csv)
- Sheet 5: "Business Rules" (from data_dictionary_business_rules.csv)

---

## Excel Tips for Working with Data Dictionary

### 1. Filter by Table
1. Select the header row
2. Click **Data > Filter** (or Ctrl+Shift+L)
3. Click the dropdown arrow in "Table Name" column
4. Select specific table(s) to view

### 2. Search for Specific Columns
1. Press **Ctrl+F** to open Find
2. Search for column name (e.g., "PARTY_ID")
3. Use **Find All** to see all instances

### 3. Freeze Header Row
1. Select row 2
2. Go to **View > Freeze Panes > Freeze Top Row**
3. Header stays visible while scrolling

### 4. Apply Table Formatting
1. Select all data (Ctrl+A)
2. Go to **Insert > Table** (or Ctrl+T)
3. Check "My table has headers"
4. Click OK

Benefits:
- Automatic filtering
- Better formatting
- Easy sorting
- Dynamic ranges

### 5. Create Pivot Tables
Use pivot tables to analyze the data dictionary:

**Example: Count Columns by Table**
1. Select data range
2. Go to **Insert > PivotTable**
3. Drag "Table Name" to Rows
4. Drag "Column Name" to Values (it will auto-count)

**Example: Tables by Retention Policy**
1. Use data_dictionary_tables.csv
2. Create pivot table
3. Drag "Retention Policy" to Rows
4. Drag "Table Name" to Values

### 6. Conditional Formatting
Highlight important information:

**Highlight Primary Keys:**
1. Select "Constraints" column
2. Go to **Home > Conditional Formatting > New Rule**
3. Select "Format cells that contain"
4. Set to "Specific Text" containing "PK"
5. Choose formatting (e.g., yellow fill)

**Highlight Foreign Keys:**
- Repeat above with "FK" in constraints column

### 7. Add Comments/Notes
1. Right-click on any cell
2. Select **Insert Comment** (or **New Note**)
3. Add your notes for internal documentation

---

## Common Use Cases

### 1. Finding All Foreign Key References
**In Excel:**
1. Open data_dictionary.csv
2. Filter "Constraints" column for "FK"
3. View all foreign key columns

**Result:** List of all relationships between tables

### 2. Understanding a Specific Table
**Steps:**
1. Open data_dictionary.csv
2. Filter "Table Name" to specific table (e.g., "CAM_312_CASES")
3. View all columns for that table
4. Check data_dictionary_business_rules.csv for business rules

### 3. Finding Required Fields
**In Excel:**
1. Open data_dictionary.csv
2. Filter "Nullable" column for "No"
3. View all required fields across all tables

### 4. Audit Trail Analysis
**Steps:**
1. Open data_dictionary_tables.csv
2. Sort by "Retention Policy"
3. Identify tables with compliance requirements

### 5. LOB-Specific Logic
**Steps:**
1. Open data_dictionary_lob_config.csv
2. Review trigger types and thresholds
3. Cross-reference with business rules

---

## Creating Professional Reports

### Export to PDF
1. Adjust column widths for readability
2. Set print area: **Page Layout > Print Area > Set Print Area**
3. Add header/footer: **Insert > Header & Footer**
4. Go to **File > Export > Create PDF/XPS**

### Email-Friendly Version
1. Save as Excel workbook (.xlsx)
2. Compress file if large
3. Include this guide as reference

### SharePoint/Teams Version
1. Save as Excel workbook
2. Upload to SharePoint/Teams
3. Enable co-authoring for team collaboration

---

## Advanced Excel Features

### 1. Data Validation Lists
Create dropdown lists for data entry based on dictionary values:

1. Select cells for dropdown
2. Go to **Data > Data Validation**
3. Select "List"
4. Source: Reference a column (e.g., LOB codes)

### 2. VLOOKUP Formulas
Look up related information across sheets:

```excel
=VLOOKUP(A2,'All Columns'!A:G,7,FALSE)
```

### 3. Create Entity Relationship Diagram
Use Excel's SmartArt or Shapes:

1. Go to **Insert > Illustrations > SmartArt**
2. Select "Hierarchy" or "Relationship"
3. Add table names and connections
4. Reference data_dictionary_relationships.csv

---

## Data Dictionary Statistics

| Metric | Count |
|--------|-------|
| Total Tables | 10 |
| Total Columns | 145 |
| Tables with Foreign Keys | 8 |
| Total Relationships | 11 |
| LOB Configurations | 6 |
| Business Rules Documented | 40+ |

---

## Updating the Data Dictionary

When database schema changes:

1. Update the source markdown file: `/database/data_dictionary.md`
2. Re-export to CSV files
3. Refresh Excel workbook
4. Communicate changes to team

---

## Best Practices

### For Business Analysts
- Use filters to focus on specific tables
- Create custom views for presentations
- Add comments for business context

### For Developers
- Keep Excel version in sync with database
- Use for quick reference during development
- Export subsets for specific features

### For Project Managers
- Use tables summary for project planning
- Track retention policies for compliance
- Monitor business rules for requirements

### For DBAs
- Reference for index optimization
- Use for capacity planning (row estimates)
- Cross-reference for backup strategies

---

## Troubleshooting

### CSV not opening correctly
- Ensure you're using UTF-8 encoding
- Try Import Wizard instead of direct open
- Check for special characters in data

### Columns not aligning
- Use "Text to Columns" feature
- Verify delimiter is comma
- Check for embedded commas in descriptions

### File too large
- Filter data before exporting
- Split into multiple files
- Use Excel's Power Query for large datasets

---

## Additional Resources

- **Source File:** `/database/data_dictionary.md`
- **SQL Schema:** `/database/oracle_schema.sql`
- **API Documentation:** `/src/api/README.md`

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-01-26 | Initial CSV export of database schema |

---

**Need Help?**
Contact the development team for assistance with the data dictionary or Excel formatting questions.
