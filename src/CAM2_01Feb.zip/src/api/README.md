# CAM Case Management System - API Documentation

## Overview

This directory contains the complete API layer for the CAM Case Management System. The API is designed to interact with Oracle 19c database and follows RESTful conventions.

## Architecture

```
/src/api/
├── client.ts              # Base API client with authentication
├── index.ts               # Main export file
├── types/                 # TypeScript type definitions
│   └── index.ts
├── endpoints/             # API endpoint modules
│   ├── cases.ts          # Case management (312 & CAM)
│   ├── population.ts     # Population triggers
│   ├── parties.ts        # Party/client management
│   ├── gfc.ts            # GFC case operations
│   ├── users.ts          # User & authentication
│   ├── dashboard.ts      # Dashboard & reporting
│   └── audit.ts          # Audit trail
└── README.md             # This file
```

## Getting Started

### Basic Usage

```typescript
import { api } from '@/api';

// Get worklist
const response = await api.cases.getWorklist({
  case_type: '312',
  status: 'In Progress',
  page: 1,
  pageSize: 20
});

if (response.success && response.data) {
  console.log('Cases:', response.data);
} else {
  console.error('Error:', response.error);
}
```

### Using Individual Endpoints

```typescript
import { casesApi, partiesApi, usersApi } from '@/api';

// Get a specific case
const caseResponse = await casesApi.get312CaseById('CAM312-2026-001');

// Get party information
const partyResponse = await partiesApi.getPartyById('P12345');

// Get current user
const userResponse = await usersApi.getCurrentUser();
```

## API Endpoints

### 1. Cases API (`casesApi`)

**312 Case Operations:**
- `get312Cases(params?)` - Get all 312 cases with filtering
- `get312CaseById(caseId)` - Get specific 312 case
- `create312Case(data)` - Create new 312 case
- `update312Status(caseId, data)` - Update case status
- `assign312Case(caseId, data)` - Assign case to analyst
- `complete312Case(caseId, data)` - Complete case
- `cancel312Case(caseId, reason)` - Cancel case

**CAM Case Operations:**
- `getCAMCases(params?)` - Get all CAM cases
- `getCAMCaseById(caseId)` - Get specific CAM case
- `createCAMCase(data)` - Create new CAM case
- `updateCAMStatus(caseId, data)` - Update status
- `assignCAMCase(caseId, data)` - Assign case
- `completeCAMCase(caseId, data)` - Complete case
- `cancelCAMCase(caseId, reason)` - Cancel case

**Worklist Operations:**
- `getWorklist(params?)` - Get combined worklist
- `getMyAssignedCases(userId)` - Get user's cases
- `getCasesByParty(partyId)` - Get party's cases
- `searchCases(query, filters?)` - Search cases
- `bulkAssignCases(data)` - Bulk assign
- `exportCases(params?)` - Export to CSV/Excel

**Case Details:**
- `getCaseTimeline(caseId)` - Get activity log
- `addCaseComment(caseId, data)` - Add comment
- `getCaseComments(caseId)` - Get comments
- `linkGFCCases(camCaseId, data)` - Link GFC cases

### 2. Population API (`populationApi`)

**Population Triggers:**
- `getTriggers(params?)` - Get all triggers
- `getTriggerById(triggerId)` - Get specific trigger
- `createTrigger(data)` - Create new trigger
- `cancelTrigger(triggerId, reason)` - Cancel trigger
- `processTrigger(triggerId)` - Process and create cases

**Population Identification:**
- `getEligibleParties(params)` - Get eligible parties
- `runPopulationIdentification(data)` - Run identification
- `getLOBRules(lobCode)` - Get LOB rules
- `previewCaseCreation(partyId)` - Preview case creation

**Manual Uploads:**
- `uploadManualExceptions(data)` - Upload manual file
- `validateManualUpload(fileData)` - Validate file

**LOB Configuration:**
- `getLOBConfigs()` - Get all LOB configs
- `updateLOBConfig(lobCode, data)` - Update config

### 3. Parties API (`partiesApi`)

**Party Operations:**
- `getParties(params?)` - Get all parties
- `getPartyById(partyId)` - Get specific party
- `getPartyByClientId(clientId)` - Get by client ID
- `createParty(data)` - Create new party
- `updateParty(partyId, data)` - Update party
- `updateRiskRating(partyId, data)` - Update risk rating
- `updateRefreshDate(partyId, data)` - Update refresh date
- `deactivateParty(partyId, data)` - Deactivate
- `reactivateParty(partyId, data)` - Reactivate

**Party-Related Data:**
- `getPartyCaseHistory(partyId)` - Get case history
- `getPartyGFCCases(partyId, params?)` - Get GFC cases
- `getPartyTriggerHistory(partyId)` - Get trigger history
- `getPartyRefreshSchedule(partyId)` - Get refresh schedule

**Bulk Operations:**
- `bulkUpdateParties(data)` - Bulk update
- `importParties(data)` - Import from file
- `exportParties(params?)` - Export to CSV/Excel

### 4. GFC API (`gfcApi`)

**GFC Case Operations:**
- `getGFCCases(params?)` - Get all GFC cases
- `getGFCCaseById(gfcCaseId)` - Get specific case
- `createGFCCase(data)` - Create new case
- `updateGFCCase(gfcCaseId, data)` - Update case
- `closeGFCCase(gfcCaseId, data)` - Close case

**GFC-CAM Linking:**
- `getLinkedGFCCases(camCaseId)` - Get linked cases
- `linkGFCToCAM(camCaseId, data)` - Link cases
- `unlinkGFCFromCAM(camCaseId, gfcCaseId)` - Unlink
- `markGFCAsReviewed(camCaseId, gfcCaseId, data)` - Mark reviewed

**GFC Analysis:**
- `getGFCSummary(partyId, params?)` - Get summary
- `checkGFCTrigger(partyId)` - Check if triggers review
- `getGFCTrends(params)` - Get trend analysis

### 5. Users API (`usersApi`)

**Authentication:**
- `login(data)` - User login
- `logout()` - User logout
- `refreshToken()` - Refresh auth token
- `validateSession()` - Validate session

**User Profile:**
- `getCurrentUser()` - Get current user
- `updateProfile(data)` - Update profile
- `changePassword(data)` - Change password

**User Management:**
- `getUsers(params?)` - Get all users
- `getUserById(userId)` - Get specific user
- `createUser(data)` - Create new user
- `updateUser(userId, data)` - Update user
- `deactivateUser(userId)` - Deactivate
- `reactivateUser(userId)` - Reactivate

**Roles & Permissions:**
- `getUserPermissions(userId)` - Get permissions
- `updateUserRole(userId, data)` - Update role
- `getRoles()` - Get available roles

**Workload:**
- `getUserWorkload(userId)` - Get user workload
- `getTeamWorkload(params?)` - Get team workload
- `getAvailableAnalysts(params?)` - Get available analysts

### 6. Dashboard API (`dashboardApi`)

**Dashboard Statistics:**
- `getDashboardStats(params?)` - Get overview stats
- `getCaseMetrics(params?)` - Get case metrics
- `getWorkloadDistribution()` - Get workload distribution
- `getSLACompliance(params?)` - Get SLA compliance
- `getTrendAnalysis(params)` - Get trend analysis

**Reports:**
- `getAvailableReports()` - List available reports
- `generateReport(data)` - Generate report
- `getCaseVolumeReport(params)` - Case volume report
- `getAnalystPerformanceReport(params?)` - Performance report
- `getAutoClosureReport(params)` - Auto-closure analysis
- `getPopulationTriggerReport(params)` - Trigger report
- `getGFCActivityReport(params)` - GFC activity report
- `getLOBPerformanceReport(params?)` - LOB performance

**Export & Scheduling:**
- `exportDashboard(params)` - Export dashboard
- `scheduleReport(data)` - Schedule recurring report
- `getScheduledReports()` - Get scheduled reports
- `cancelScheduledReport(scheduleId)` - Cancel schedule

### 7. Audit API (`auditApi`)

**Audit Trail:**
- `getAuditTrail(params?)` - Get audit entries
- `getRecordAuditTrail(tableName, recordId)` - Get record history
- `createAuditEntry(data)` - Create audit entry

**Assignment History:**
- `getAssignmentHistory(caseId)` - Get assignment history
- `getCurrentAssignment(caseId)` - Get current assignment
- `getUserAssignments(userId, params?)` - Get user assignments
- `createAssignment(data)` - Create assignment
- `endAssignment(assignmentId, data)` - End assignment

**Review History:**
- `getPartyReviewHistory(partyId)` - Get party review history
- `getCaseReviewHistory(camCaseId)` - Get case review history
- `createReviewHistory(data)` - Create review entry
- `checkRecentReview(partyId)` - Check recent review

**Change History:**
- `compareVersions(data)` - Compare versions
- `getFieldHistory(tableName, recordId, fieldName)` - Get field history

**Activity Tracking:**
- `getUserActivity(userId, params?)` - Get user activity
- `getSystemActivity(params?)` - Get system activity
- `logUserAction(data)` - Log user action

## Request/Response Patterns

### Standard Response Format

```typescript
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp: string;
}
```

### Paginated Response Format

```typescript
interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}
```

### Error Handling

```typescript
const response = await api.cases.get312CaseById('CASE-001');

if (response.success && response.data) {
  // Handle success
  const caseData = response.data;
} else {
  // Handle error
  console.error('Error:', response.error);
}
```

## Filtering & Pagination

Most list endpoints support filtering and pagination:

```typescript
const response = await api.cases.getWorklist({
  // Filtering
  case_type: '312',
  status: 'In Progress',
  lob: 'PB',
  risk_rating: 'High',
  assigned_to: 'USER123',
  search: 'Acme Corporation',
  
  // Pagination
  page: 1,
  pageSize: 25,
  
  // Sorting
  sortBy: 'case_created_date',
  sortOrder: 'desc'
});
```

## Authentication

API calls automatically include authentication tokens from sessionStorage:

```typescript
// Login
const loginResponse = await api.users.login({
  username: 'analyst1',
  password: 'password123'
});

if (loginResponse.success && loginResponse.data?.token) {
  // Token is automatically stored and used for subsequent requests
  sessionStorage.setItem('authToken', loginResponse.data.token);
}

// Logout
await api.users.logout();
```

## Environment Configuration

Set the API base URL in your `.env` file:

```
VITE_API_BASE_URL=https://api.example.com/v1
```

Default: `/api`

## Error Codes

| Code | Description |
|------|-------------|
| `UNAUTHORIZED` | Authentication required |
| `FORBIDDEN` | Insufficient permissions |
| `NOT_FOUND` | Resource not found |
| `VALIDATION_ERROR` | Invalid request data |
| `SERVER_ERROR` | Internal server error |
| `NETWORK_ERROR` | Network connection failed |

## Best Practices

1. **Always check response.success** before accessing data
2. **Use TypeScript types** for type safety
3. **Handle errors gracefully** with user-friendly messages
4. **Implement loading states** for better UX
5. **Use pagination** for large datasets
6. **Cache frequently accessed data** when appropriate
7. **Implement retry logic** for critical operations

## Examples

### Creating a 312 Case

```typescript
const response = await api.cases.create312Case({
  party_id: 'P12345',
  trigger_id: 1001,
  has_model_alert: 'Y',
  model_output: 'High risk alert detected',
  priority: 'High',
  assigned_to: 'ANALYST001'
});

if (response.success && response.data) {
  console.log('Case created:', response.data.cam_312_case_id);
}
```

### Assigning a Case

```typescript
const response = await api.cases.assignCAMCase('CAM-2026-001', {
  assigned_to: 'ANALYST002',
  assigned_by: 'MANAGER001',
  assignment_reason: 'Workload balancing'
});
```

### Searching Cases

```typescript
const response = await api.cases.searchCases('Acme Corp', {
  case_type: 'CAM',
  status: 'In Progress',
  lob: 'PB'
});
```

### Generating a Report

```typescript
const response = await api.dashboard.generateReport({
  report_type: 'case_volume',
  parameters: {
    date_from: '2026-01-01',
    date_to: '2026-01-31',
    group_by: 'lob'
  },
  format: 'excel'
});

if (response.success && response.data) {
  // Download or display report
  window.location.href = response.data.download_url;
}
```

## Database Schema Alignment

All API types align with the Oracle database schema defined in `/database/data_dictionary.md`:

- **CAM_PARTY_MASTER** → `Party` type
- **CAM_312_CASES** → `Case312` type
- **CAM_CASES** → `CaseCAM` type
- **CAM_GFC_CASES** → `GFCCase` type
- **CAM_POPULATION_TRIGGER** → `PopulationTrigger` type
- **CAM_ASSIGNMENT_HISTORY** → `AssignmentHistory` type
- **CAM_REVIEW_HISTORY** → `ReviewHistory` type
- **CAM_AUDIT_TRAIL** → `AuditTrailEntry` type

## Support

For questions or issues with the API layer, contact the development team.
