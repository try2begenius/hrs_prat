/**
 * Population Identification & Trigger API Endpoints
 * Handles population triggers and case creation workflows
 */

import { apiClient, ApiResponse, PaginatedResponse } from '../client';
import {
  PopulationTrigger,
  CreatePopulationTriggerRequest,
  LOBConfig,
} from '../types';

/**
 * Population API Endpoints
 */
export const populationApi = {
  // ============================================================================
  // Population Trigger Operations
  // ============================================================================

  /**
   * Get all population triggers with filtering
   */
  getTriggers: async (params?: {
    trigger_type?: string;
    trigger_status?: string;
    party_id?: string;
    date_from?: string;
    date_to?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ApiResponse<PaginatedResponse<PopulationTrigger>>> => {
    return apiClient.get<PaginatedResponse<PopulationTrigger>>('/population/triggers', params);
  },

  /**
   * Get a specific trigger by ID
   */
  getTriggerById: async (triggerId: number): Promise<ApiResponse<PopulationTrigger>> => {
    return apiClient.get<PopulationTrigger>(`/population/triggers/${triggerId}`);
  },

  /**
   * Create a new population trigger
   */
  createTrigger: async (data: CreatePopulationTriggerRequest): Promise<ApiResponse<PopulationTrigger>> => {
    return apiClient.post<PopulationTrigger>('/population/triggers', data);
  },

  /**
   * Cancel a population trigger
   */
  cancelTrigger: async (triggerId: number, reason: string): Promise<ApiResponse<PopulationTrigger>> => {
    return apiClient.post<PopulationTrigger>(`/population/triggers/${triggerId}/cancel`, { reason });
  },

  /**
   * Process a trigger and create cases
   */
  processTrigger: async (triggerId: number): Promise<ApiResponse<{
    trigger: PopulationTrigger;
    cases_created: {
      case_312?: string;
      case_cam?: string;
    };
  }>> => {
    return apiClient.post(`/population/triggers/${triggerId}/process`);
  },

  // ============================================================================
  // Population Identification Queries
  // ============================================================================

  /**
   * Get eligible parties for case creation by LOB
   */
  getEligibleParties: async (params: {
    lob?: string;
    risk_rating?: string;
    days_threshold?: number;
  }): Promise<ApiResponse<any[]>> => {
    return apiClient.get<any[]>('/population/eligible-parties', params);
  },

  /**
   * Run population identification for specific LOB
   */
  runPopulationIdentification: async (data: {
    lob: string;
    dry_run?: boolean;
  }): Promise<ApiResponse<{
    eligible_count: number;
    triggers_created: number;
    parties: any[];
  }>> => {
    return apiClient.post('/population/identify', data);
  },

  /**
   * Get population identification rules for LOB
   */
  getLOBRules: async (lobCode: string): Promise<ApiResponse<{
    rule: LOBConfig;
    current_eligible_count: number;
  }>> => {
    return apiClient.get(`/population/lob-rules/${lobCode}`);
  },

  /**
   * Preview case creation for a party
   */
  previewCaseCreation: async (partyId: string): Promise<ApiResponse<{
    party: any;
    will_create_312: boolean;
    will_create_cam: boolean;
    auto_close_312: boolean;
    auto_close_cam: boolean;
    decision_rationale: string;
  }>> => {
    return apiClient.get(`/population/preview/${partyId}`);
  },

  // ============================================================================
  // Manual Upload Operations
  // ============================================================================

  /**
   * Upload manual exceptions file
   */
  uploadManualExceptions: async (data: {
    file_data: any;
    uploaded_by: string;
    reason: string;
  }): Promise<ApiResponse<{
    triggers_created: number;
    success_count: number;
    failed_count: number;
    errors: any[];
  }>> => {
    return apiClient.post('/population/manual-upload', data);
  },

  /**
   * Validate manual upload file
   */
  validateManualUpload: async (fileData: any): Promise<ApiResponse<{
    valid: boolean;
    errors: any[];
    warnings: any[];
    record_count: number;
  }>> => {
    return apiClient.post('/population/manual-upload/validate', { file_data: fileData });
  },

  // ============================================================================
  // LOB Configuration
  // ============================================================================

  /**
   * Get all LOB configurations
   */
  getLOBConfigs: async (): Promise<ApiResponse<LOBConfig[]>> => {
    return apiClient.get<LOBConfig[]>('/population/lob-configs');
  },

  /**
   * Update LOB configuration
   */
  updateLOBConfig: async (lobCode: string, data: Partial<LOBConfig>): Promise<ApiResponse<LOBConfig>> => {
    return apiClient.put<LOBConfig>(`/population/lob-configs/${lobCode}`, data);
  },

  // ============================================================================
  // Reporting
  // ============================================================================

  /**
   * Get population trigger statistics
   */
  getTriggerStats: async (params?: {
    date_from?: string;
    date_to?: string;
    lob?: string;
  }): Promise<ApiResponse<{
    total_triggers: number;
    by_type: Record<string, number>;
    by_status: Record<string, number>;
    by_lob: Record<string, number>;
    manual_uploads: number;
  }>> => {
    return apiClient.get('/population/stats', params);
  },

  /**
   * Export population data
   */
  exportPopulationData: async (params?: any): Promise<ApiResponse<{ download_url: string }>> => {
    return apiClient.get<{ download_url: string }>('/population/export', params);
  },
};
