/**
 * API Type Definitions
 * Types for API requests and responses
 */

// ============================================================================
// Case Management Types
// ============================================================================

export interface Case312 {
  cam_312_case_id: string;
  party_id: string;
  trigger_id?: number;
  case_status: '312 Unassigned' | '312 In Progress' | '312 Complete' | 'Closed' | 'Cancelled';
  decision: 'Full Review' | 'Auto-Close' | 'Not Applicable';
  has_model_alert: 'Y' | 'N';
  auto_complete_flag: 'Y' | 'N';
  model_output?: string;
  case_created_date: string;
  case_assigned_date?: string;
  case_completed_date?: string;
  assigned_to?: string;
  completed_by?: string;
  disposition_code?: string;
  disposition_notes?: string;
  sla_due_date?: string;
  priority?: 'High' | 'Medium' | 'Low';
  created_date: string;
  created_by?: string;
  modified_date?: string;
  modified_by?: string;
}

export interface CaseCAM {
  cam_case_id: string;
  party_id: string;
  trigger_id?: number;
  cam_312_case_id?: string;
  case_status: 'CAM Unassigned' | 'CAM In Progress' | 'CAM Complete' | 'Closed' | 'Cancelled';
  decision: 'Full Review' | 'Auto-Close' | 'Pending 312' | 'Not Applicable';
  auto_complete_flag: 'Y' | 'N';
  gfc_count_total: number;
  gfc_count_open: number;
  gfc_count_new: number;
  had_312_not_auto_closed: 'Y' | 'N';
  completed_cases_12m: number;
  has_sar_12m: 'Y' | 'N';
  had_cam_review_12m: 'Y' | 'N';
  case_created_date: string;
  case_assigned_date?: string;
  case_completed_date?: string;
  assigned_to?: string;
  completed_by?: string;
  disposition_code?: string;
  disposition_notes?: string;
  sla_due_date?: string;
  priority?: 'High' | 'Medium' | 'Low';
  created_date: string;
  created_by?: string;
  modified_date?: string;
  modified_by?: string;
}

export interface Party {
  party_id: string;
  client_id: string;
  legal_name: string;
  lob: 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI' | 'Small Business';
  risk_rating: 'High' | 'Elevated' | 'Standard' | 'Low';
  refresh_due_date?: string;
  refresh_anniversary_month?: string;
  dga_due_date?: string;
  global_dga_due_date?: string;
  family_anniversary_date?: string;
  has_312_flag: 'Y' | 'N';
  active_status: 'Y' | 'N';
  created_date: string;
  created_by?: string;
  modified_date?: string;
  modified_by?: string;
}

export interface GFCCase {
  gfc_case_id: string;
  party_id: string;
  case_type: string;
  opened_date: string;
  closed_date?: string;
  case_status: 'Open' | 'Closed' | 'Cancelled';
  is_in_scope: 'Y' | 'N';
  is_sar: 'Y' | 'N';
  priority?: string;
  disposition_code?: string;
  created_date: string;
  created_by?: string;
  modified_date?: string;
  modified_by?: string;
}

export interface PopulationTrigger {
  trigger_id: number;
  party_id: string;
  trigger_type: 'Refresh 180 Days' | 'Refresh 120 Days' | 'Refresh 95 Days' | 'DGA Due Date' | 'Manual Upload';
  trigger_date: string;
  days_to_refresh?: number;
  is_manual_upload: 'Y' | 'N';
  manual_upload_reason?: string;
  triggered_by?: string;
  trigger_status: 'Active' | 'Processed' | 'Cancelled';
  cases_created_flag: 'Y' | 'N';
  created_date: string;
  created_by?: string;
}

// ============================================================================
// Request Types
// ============================================================================

export interface CreateCase312Request {
  party_id: string;
  trigger_id?: number;
  has_model_alert: 'Y' | 'N';
  model_output?: string;
  priority?: 'High' | 'Medium' | 'Low';
  assigned_to?: string;
}

export interface CreateCaseCAMRequest {
  party_id: string;
  trigger_id?: number;
  cam_312_case_id?: string;
  gfc_case_ids?: string[];
  priority?: 'High' | 'Medium' | 'Low';
  assigned_to?: string;
}

export interface UpdateCaseStatusRequest {
  case_status: string;
  notes?: string;
  modified_by: string;
}

export interface AssignCaseRequest {
  assigned_to: string;
  assigned_by: string;
  assignment_reason?: string;
}

export interface CompleteCaseRequest {
  disposition_code: string;
  disposition_notes?: string;
  completed_by: string;
}

export interface CreatePopulationTriggerRequest {
  party_id: string;
  trigger_type: string;
  days_to_refresh?: number;
  is_manual_upload: 'Y' | 'N';
  manual_upload_reason?: string;
  triggered_by: string;
}

export interface WorklistFilterParams {
  case_type?: '312' | 'CAM' | 'All';
  status?: string;
  assigned_to?: string;
  lob?: string;
  risk_rating?: string;
  priority?: string;
  search?: string;
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface DashboardStatsRequest {
  user_id?: string;
  role?: string;
  date_from?: string;
  date_to?: string;
}

// ============================================================================
// Response Types
// ============================================================================

export interface WorklistItem {
  case_id: string;
  case_type: '312' | 'CAM';
  party_id: string;
  client_id: string;
  legal_name: string;
  lob: string;
  risk_rating: string;
  case_status: string;
  decision?: string;
  priority?: string;
  assigned_to?: string;
  case_created_date: string;
  sla_due_date?: string;
  days_remaining?: number;
  gfc_count_new?: number;
  has_model_alert?: 'Y' | 'N';
}

export interface CaseDetailResponse {
  case: Case312 | CaseCAM;
  party: Party;
  gfc_cases?: GFCCase[];
  related_312_case?: Case312;
  assignment_history?: AssignmentHistory[];
  review_history?: ReviewHistory[];
}

export interface AssignmentHistory {
  assignment_id: number;
  case_id: string;
  case_type: '312' | 'CAM';
  assigned_to: string;
  assigned_by?: string;
  assignment_date: string;
  unassignment_date?: string;
  assignment_reason?: string;
  is_current: 'Y' | 'N';
}

export interface ReviewHistory {
  review_id: number;
  cam_case_id: string;
  party_id: string;
  review_date: string;
  review_type: '312 Review' | 'CAM Review' | 'Combined Review';
  gfc_cases_reviewed: number;
  disposition_code?: string;
  disposition_summary?: string;
  reviewer_name?: string;
}

export interface DashboardStats {
  total_cases: number;
  cases_by_status: Record<string, number>;
  cases_by_type: Record<string, number>;
  cases_by_priority: Record<string, number>;
  my_assigned_cases: number;
  cases_due_today: number;
  cases_overdue: number;
  avg_completion_time_days: number;
  cases_auto_closed_this_month: number;
  cases_created_this_month: number;
}

export interface LOBConfig {
  lob_code: string;
  lob_name: string;
  trigger_type: string;
  days_threshold?: number;
  requires_312: 'Y' | 'N';
  description?: string;
  active_flag: 'Y' | 'N';
}

export interface AuditTrailEntry {
  audit_id: number;
  table_name: string;
  record_id: string;
  action_type: 'INSERT' | 'UPDATE' | 'DELETE';
  changed_by: string;
  changed_date: string;
  old_values?: Record<string, any>;
  new_values?: Record<string, any>;
  change_reason?: string;
}
