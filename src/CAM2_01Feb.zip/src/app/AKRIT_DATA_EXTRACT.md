# AKRIT Data Extract Documentation

## Overview

The AKRIT Data Extract feature enables the quality review team to export case data into a flat file format for performing inspections in their System of Record (AKRIT). This feature provides flexible filtering and export capabilities to generate precisely targeted datasets.

---

## Purpose

**Primary Use Case**: Export monitoring and inspection data for quality review team  
**Target System**: AKRIT (Quality Review System of Record)  
**File Format**: CSV or Excel  
**Access Level**: All users with access to Reports page

---

## Flat File Contents

The AKRIT extract contains the following **7 required fields**:

| Field Name | Description | Source | Example |
|------------|-------------|--------|---------|
| **Case ID** | Unique case identifier | `case.id` | `312-2025-001` |
| **Client ID** | Internal client identifier | `case.clientId` or `case.clientData.clientId` | `CLI-892341` |
| **GCI** | Global Client Identifier | `case.gci` | `GCI-892341` |
| **CoPer ID** | CoPer system identifier | `case.coperId` | `CPR-89234` |
| **Line of Business** | Business unit/division | `case.lineOfBusiness` | `GB/GM` |
| **312 Client Flag** | Whether client is a 312 case | `case.is312Case` | `Yes` / `No` |
| **BAC Affiliate/Employee Flag** | Employee/affiliate status | `case.clientData.isEmployee` | `Yes` / `No` |

---

## How to Access

### Navigation Path

1. Log into CAM Platform
2. Click **"Reports"** in the sidebar
3. Click **"AKRIT Data Extract"** tab

### User Requirements

- Must have access to Reports functionality
- No special permissions required
- Available to all roles (Analyst, Manager, Administrator, Sales Owner)

---

## Using the AKRIT Data Extract

### Step-by-Step Guide

#### Step 1: Set Date Range (Optional)

1. Click **"From"** date picker
2. Select start date
3. Click **"To"** date picker
4. Select end date
5. Leave blank to include all dates

**Example**: Export cases created between October 1 and October 31, 2025

#### Step 2: Select Export Format

Choose between:
- **CSV (Comma-separated values)** - Universal format, opens in any text editor or Excel
- **Excel (.xlsx)** - Microsoft Excel format with proper formatting

**Recommendation**: Use CSV for AKRIT import (most compatible)

#### Step 3: Filter by Case Type (Optional)

Check one or both:
- ☑ **312 Review** - Include 312 cases
- ☑ **CAM Review** - Include CAM cases

**Default**: Both types selected

#### Step 4: Filter by Line of Business (Optional)

Check desired LOBs:
- ☐ **GB/GM** - Global Banking / Global Markets
- ☐ **PB** - Private Bank
- ☐ **ML** - Merrill Lynch
- ☐ **Consumer** - Consumer Banking
- ☐ **CI** - Corporate & Investment Banking

**Default**: All LOBs included

#### Step 5: Apply Additional Filters (Optional)

- ☐ **312 Client Flag = Yes only** - Include only 312 flagged clients
- ☐ **BAC Affiliate/Employee Flag = Yes only** - Include only employee/affiliate cases

**Default**: Both filters unchecked (include all)

#### Step 6: Review Export Preview

The preview box shows:
- **Number of cases** that will be exported
- **Case Types** selected
- **LOBs** selected
- **Date Range** (if applied)
- **Export Format**

**Example Preview**:
```
23 cases
Case Types: 312 Review, CAM Review
LOBs: All
Date Range: 10/1/2025 - 10/31/2025
Format: CSV
```

#### Step 7: Export Data

1. Click **"Export X Cases to AKRIT"** button
2. File downloads automatically
3. Success toast appears confirming export

**File Name Format**: `AKRIT_Extract_YYYY-MM-DD.csv`

#### Step 8: Reset Filters (Optional)

Click **"Reset Filters"** to clear all selections and start over

---

## Export File Format

### CSV File Structure

```csv
Case ID,Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag
312-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-002,CLI-445122,GCI-445122,CPR-44512,PB,Yes,No
CAM-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-003,CLI-778934,GCI-778934,N/A,ML,Yes,No
CAM-2025-002,CLI-223344,GCI-223344,CPR-22334,GB/GM,No,Yes
```

### Field Details

#### Case ID
- **Format**: `[TYPE]-[YEAR]-[NUMBER]`
- **Examples**: `312-2025-001`, `CAM-2025-015`
- **Always Present**: Yes

#### Client ID
- **Format**: `CLI-[NUMBER]`
- **Examples**: `CLI-892341`, `CLI-445122`
- **Fallback**: Shows as "N/A" if not available

#### GCI (Global Client Identifier)
- **Format**: `GCI-[NUMBER]`
- **Examples**: `GCI-892341`, `GCI-POP-003`
- **Always Present**: Yes (required field)

#### CoPer ID
- **Format**: `CPR-[NUMBER]`
- **Examples**: `CPR-89234`, `CPR-12345`
- **May Show**: "N/A" if client doesn't have CoPer ID

#### Line of Business
- **Valid Values**: `GB/GM`, `PB`, `ML`, `Consumer`, `CI`
- **May Show**: "N/A" if not specified

#### 312 Client Flag
- **Valid Values**: `Yes` or `No`
- **Logic**: `Yes` if case has 312 review component
- **Always Present**: Yes

#### BAC Affiliate/Employee Flag
- **Valid Values**: `Yes` or `No`
- **Logic**: `Yes` if client is employee or affiliate
- **Always Present**: Yes

---

## Common Use Cases

### Use Case 1: Monthly Quality Review

**Objective**: Export all cases from previous month for quality inspection

**Steps**:
1. Set **Date Range**: First day to last day of previous month
2. Keep all **Case Types** selected
3. Keep all **LOBs** selected
4. Export as **CSV**

**Result**: Comprehensive monthly dataset for AKRIT review

---

### Use Case 2: 312 Case Audit

**Objective**: Export only 312-flagged cases for specialized review

**Steps**:
1. Set **Date Range** as needed (or leave blank for all)
2. Check **"312 Client Flag = Yes only"**
3. Select **"312 Review"** case type
4. Export as **CSV**

**Result**: All 312 cases for regulatory audit

---

### Use Case 3: Employee Case Review

**Objective**: Export all employee/affiliate cases for compliance check

**Steps**:
1. Check **"BAC Affiliate/Employee Flag = Yes only"**
2. Keep all **Case Types** selected
3. Export as **Excel**

**Result**: All employee cases for special handling review

---

### Use Case 4: LOB-Specific Analysis

**Objective**: Export only Private Bank cases

**Steps**:
1. Check **"PB"** only in LOB filter
2. Keep all other filters at default
3. Export as **CSV**

**Result**: Private Bank cases only

---

### Use Case 5: Quarterly Report

**Objective**: Export all cases for Q4 2025

**Steps**:
1. Set **Date Range**: October 1, 2025 to December 31, 2025
2. Keep all filters at default
3. Export as **Excel**

**Result**: Complete Q4 dataset with proper Excel formatting

---

## Filtering Logic

### How Filters Combine

Filters use **AND logic** - all selected criteria must be met:

```
Date Range AND Case Type AND LOB AND 312 Flag AND Employee Flag
```

**Example**:
- Date: October 2025
- Case Type: 312 Review
- LOB: GB/GM
- 312 Flag: Yes

**Result**: Only 312 Review cases from GB/GM LOB created in October 2025 with 312 flag = Yes

### Filter Precedence

1. **Date Range** - Applied first
2. **Case Type** - Applied second
3. **LOB** - Applied third
4. **312 Flag** - Applied fourth
5. **Employee Flag** - Applied last

### Empty Filters

If a filter is not set (left empty/unchecked):
- **Date Range**: Include all dates
- **Case Types**: Include all types (if all unchecked)
- **LOBs**: Include all LOBs
- **312 Flag**: Include both Yes and No
- **Employee Flag**: Include both Yes and No

---

## Data Validation

### Before Export

The system validates:
- ✅ At least one case matches filters
- ✅ All required fields are present
- ✅ Data format is correct

### Error Handling

If no cases match filters:
- ❌ Export button shows "0 cases"
- ❌ Button is disabled
- ❌ Toast error if clicked: "No cases match the selected filters"

**Solution**: Adjust filter criteria

---

## File Handling

### Download Process

1. User clicks "Export" button
2. System generates flat file in memory
3. Browser triggers automatic download
4. File saves to default download location
5. Success toast appears

### File Naming Convention

**Format**: `AKRIT_Extract_YYYY-MM-DD.csv`

**Examples**:
- `AKRIT_Extract_2025-10-27.csv`
- `AKRIT_Extract_2025-11-15.xlsx`

**Date**: Export generation date (today's date)

### CSV vs Excel

| Feature | CSV | Excel |
|---------|-----|-------|
| File Size | Smaller | Larger |
| Compatibility | Universal | Excel/LibreOffice |
| Formatting | Plain text | Can include formatting |
| AKRIT Import | ✅ Recommended | ⚠️ May need conversion |
| Open With | Any text editor | Excel required |

---

## Quality Review Workflow

### Complete Workflow

```
1. Quality Team Member Logs into CAM Platform
   ↓
2. Navigates to Reports → AKRIT Data Extract
   ↓
3. Sets Filters (Date Range, LOB, etc.)
   ↓
4. Reviews Export Preview (confirms case count)
   ↓
5. Clicks "Export X Cases to AKRIT"
   ↓
6. File Downloads Automatically
   ↓
7. Opens File in Excel/Text Editor
   ↓
8. Reviews Data Integrity
   ↓
9. Imports File into AKRIT System
   ↓
10. Performs Quality Inspections in AKRIT
    ↓
11. Documents Findings
    ↓
12. Returns to CAM for Any Updates Needed
```

### Integration with AKRIT

**Import Process** (performed in AKRIT):
1. Open AKRIT application
2. Navigate to Import function
3. Select "CAM Platform Import"
4. Choose downloaded CSV file
5. Map fields (should auto-map if format matches)
6. Validate import
7. Confirm import
8. Begin quality review

**Note**: Exact AKRIT import steps may vary based on AKRIT version and configuration

---

## Troubleshooting

### Issue 1: No Data Appears

**Problem**: Export preview shows "0 cases"

**Possible Causes**:
- Date range too narrow
- All case types unchecked
- Filters too restrictive

**Solution**:
1. Click "Reset Filters"
2. Start with broader criteria
3. Gradually narrow down

---

### Issue 2: Missing CoPer IDs

**Problem**: Many rows show "N/A" for CoPer ID

**Explanation**: Not all clients have CoPer IDs assigned

**Solution**: This is expected behavior - proceed with export

---

### Issue 3: File Won't Open

**Problem**: CSV file doesn't open correctly in Excel

**Solution**:
1. Open Excel first
2. Go to File → Open
3. Select "All Files" type
4. Choose the CSV file
5. Follow Text Import Wizard

---

### Issue 4: Special Characters Display Incorrectly

**Problem**: Client names with special characters show as "�"

**Solution**:
1. Open file in Excel
2. Go to Data → Get Data → From File → From Text/CSV
3. Set encoding to "UTF-8"
4. Load data

---

### Issue 5: Download Doesn't Start

**Problem**: Clicking export button does nothing

**Possible Causes**:
- Browser blocking download
- Pop-up blocker enabled
- Extension interfering

**Solution**:
1. Check browser download settings
2. Allow pop-ups for CAM domain
3. Try different browser
4. Check console for errors (F12)

---

## Performance Considerations

### Export Size Limits

| # of Cases | Export Time | File Size (CSV) |
|------------|-------------|-----------------|
| < 100 | Instant | < 10 KB |
| 100-1,000 | < 1 second | 10-100 KB |
| 1,000-10,000 | 1-3 seconds | 100 KB - 1 MB |
| > 10,000 | 3-10 seconds | > 1 MB |

### Best Practices

✅ **Do**:
- Export monthly batches for regular reviews
- Use date range filters for large datasets
- Export during off-peak hours for large files
- Save exports with descriptive names

❌ **Don't**:
- Export all cases at once (use date ranges)
- Export more data than needed
- Generate same export multiple times
- Share exports via unsecured channels

---

## Security & Compliance

### Data Sensitivity

**Classification**: Confidential - Internal Use Only

**Contains**:
- Client identifiers (GCI, Client ID)
- Case information
- Business unit data
- Employee flags

**Does NOT Contain**:
- PII (names, addresses, SSN)
- Transaction details
- Account numbers
- Sensitive financial data

### Handling Requirements

✅ **Required**:
- Store on secure internal systems only
- Delete after quality review complete
- Do not email externally
- Follow data retention policies

❌ **Prohibited**:
- Uploading to public cloud storage
- Emailing to personal accounts
- Sharing with unauthorized users
- Printing unless required

### Audit Trail

All exports are logged:
- User who generated export
- Date and time of export
- Number of records exported
- Filters applied

**Audit Log Location**: System logs (accessible to administrators)

---

## Testing the Feature

### Test Scenario 1: Basic Export

**Steps**:
1. Go to Reports → AKRIT Data Extract
2. Leave all filters at default
3. Click "Export"
4. File downloads

**Expected Result**:
- ✅ All cases exported
- ✅ CSV file opens correctly
- ✅ All 7 fields present
- ✅ No blank rows

---

### Test Scenario 2: Date Range Filter

**Steps**:
1. Set From: October 1, 2025
2. Set To: October 31, 2025
3. Preview shows filtered count
4. Export

**Expected Result**:
- ✅ Only October cases included
- ✅ Case count matches preview
- ✅ All dates within range

---

### Test Scenario 3: 312 Flag Filter

**Steps**:
1. Check "312 Client Flag = Yes only"
2. Preview updates
3. Export

**Expected Result**:
- ✅ All exported cases have "Yes" in 312 Client Flag column
- ✅ No "No" values present

---

### Test Scenario 4: LOB Filter

**Steps**:
1. Check only "GB/GM" LOB
2. Export

**Expected Result**:
- ✅ All rows show "GB/GM" in Line of Business column
- ✅ No other LOBs present

---

### Test Scenario 5: Combined Filters

**Steps**:
1. Set Date Range: Oct 1-31, 2025
2. Check Case Type: 312 Review only
3. Check LOB: PB only
4. Check: 312 Flag = Yes
5. Export

**Expected Result**:
- ✅ All criteria met
- ✅ Smaller, targeted dataset
- ✅ Preview count accurate

---

## Technical Implementation

### Files Involved

```
/components/Reports.tsx           - UI component with AKRIT tab
/utils/reportExports.ts           - Export generation functions
/types/index.ts                   - Type definitions
/data/enhancedMockData.ts         - Case data source
```

### Key Functions

#### `generateAKRITExtract(cases: Case[]): AKRITExtractRow[]`
Transforms case data into AKRIT format

#### `exportToCSV(data: AKRITExtractRow[], filename: string): void`
Generates and downloads CSV file

#### `exportToExcel(data: AKRITExtractRow[], filename: string): void`
Generates and downloads Excel file

#### `filterCasesForExport(): Case[]`
Applies all filters to case list

---

## Future Enhancements

### Planned Features

1. **Scheduled Exports**
   - Auto-generate monthly extracts
   - Email to quality team
   - Store in shared location

2. **Custom Field Selection**
   - Choose which fields to include
   - Reorder columns
   - Save custom templates

3. **Advanced Filtering**
   - Filter by assignee
   - Filter by status
   - Filter by risk level
   - Multiple date ranges

4. **Export History**
   - View past exports
   - Re-download previous files
   - Compare exports

5. **Direct AKRIT Integration**
   - API connection to AKRIT
   - Auto-import without file download
   - Real-time sync

6. **Data Validation Reports**
   - Pre-export data quality check
   - Highlight missing fields
   - Suggest corrections

---

## Support & Contact

### For Questions

- **Technical Issues**: IT Support Team
- **Data Questions**: AML Operations Team
- **AKRIT Import Issues**: Quality Review Team
- **Access Issues**: System Administrator

### Documentation Updates

This documentation is maintained by the CAM Platform Development Team.

**Last Updated**: October 27, 2025  
**Version**: 1.0  
**Next Review**: January 2026

---

## Appendix

### Sample Export Files

#### Sample 1: Small Dataset (5 cases)

```csv
Case ID,Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag
312-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-002,CLI-445122,GCI-445122,N/A,PB,Yes,No
CAM-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-003,CLI-778934,GCI-778934,N/A,ML,Yes,No
CAM-2025-002,CLI-223344,GCI-223344,CPR-22334,Consumer,No,Yes
```

#### Sample 2: Employee Cases Only

```csv
Case ID,Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag
CAM-2025-002,CLI-223344,GCI-223344,CPR-22334,Consumer,No,Yes
312-2025-005,CLI-667788,GCI-667788,CPR-66778,GB/GM,No,Yes
CAM-2025-008,CLI-445566,GCI-445566,N/A,PB,Yes,Yes
```

#### Sample 3: 312 Cases Only

```csv
Case ID,Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag
312-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-002,CLI-445122,GCI-445122,N/A,PB,Yes,No
312-2025-003,CLI-778934,GCI-778934,N/A,ML,Yes,No
312-2025-004,CLI-998877,GCI-998877,CPR-99887,CI,Yes,No
```

---

## Quick Reference

### Essential Information

**Feature Name**: AKRIT Data Extract  
**Location**: Reports → AKRIT Data Extract Tab  
**Export Formats**: CSV (recommended), Excel  
**Required Fields**: 7 (Case ID, Client ID, GCI, CoPer, LOB, 312 Flag, Employee Flag)  
**Access**: All authenticated users  
**File Naming**: `AKRIT_Extract_YYYY-MM-DD.csv`

### Quick Steps

1. Navigate to Reports → AKRIT Data Extract
2. Set filters (optional)
3. Review preview
4. Click "Export X Cases to AKRIT"
5. File downloads automatically

### Common Filters

- **Date Range**: Filter by creation date
- **Case Type**: 312 Review and/or CAM Review
- **LOB**: GB/GM, PB, ML, Consumer, CI
- **312 Flag**: Yes/No
- **Employee Flag**: Yes/No

---

**End of Documentation**
