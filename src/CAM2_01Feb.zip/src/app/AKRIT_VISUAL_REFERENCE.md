# AKRIT Data Extract - Visual Reference Card

## 🎯 Quick Access

**Location**: Reports → AKRIT Extract Tab  
**Icon**: 🗄️ Database  
**Purpose**: Export case data for AKRIT quality review system

---

## 📋 Export Contains 7 Fields

```
┌─────────────────────────────────────────────────────────┐
│  AKRIT EXTRACT FILE STRUCTURE                           │
├──────┬──────────────────────────────────────────────────┤
│  1   │  Case ID                  │ 312-2025-001         │
│  2   │  Client ID                │ CLI-892341           │
│  3   │  GCI                      │ GCI-892341           │
│  4   │  CoPer ID                 │ CPR-89234            │
│  5   │  Line of Business         │ GB/GM                │
│  6   │  312 Client Flag          │ Yes / No             │
│  7   │  BAC Affiliate/Employee   │ Yes / No             │
└──────┴──────────────────────────────────────────────────┘
```

---

## 🎛️ Filter Panel (Left Side)

### 📅 Date Range
```
┌──────────────────────────┐
│ From Date:  [📅 picker] │
│ To Date:    [📅 picker] │
└──────────────────────────┘
Leave blank for all dates
```

### 💾 Export Format
```
┌──────────────────────────┐
│ [●] CSV (Recommended)    │
│ [ ] Excel (.xlsx)        │
└──────────────────────────┘
CSV is recommended for AKRIT
```

### 📋 Case Types
```
┌──────────────────────────┐
│ ☑ 312 Review Cases       │
│ ☑ CAM Review Cases       │
└──────────────────────────┘
Both selected by default
```

### 🏢 Line of Business
```
┌──────────────────────────┐
│ ☐ GB/GM - Global Banking │
│ ☐ PB - Private Bank      │
│ ☐ ML - Merrill Lynch     │
│ ☐ Consumer Banking        │
│ ☐ CI - Corporate/Invest  │
└──────────────────────────┘
Leave all unchecked for all LOBs
```

### 🔍 Additional Filters
```
┌─────────────────────────────────┐
│ ☐ 312 Client Flag = Yes only    │
│ ☐ Employee/Affiliate = Yes only │
└─────────────────────────────────┘
Optional - use for specific exports
```

### 🔄 Reset Button
```
┌──────────────────────┐
│ [↻ Reset Filters]    │
└──────────────────────┘
Clears all selections
```

---

## 📊 Preview Panel (Right Side)

### Case Count Display
```
┌─────────────────────────┐
│                         │
│         23              │
│   cases will be         │
│     exported            │
│                         │
└─────────────────────────┘
Updates in real-time
```

### Export Summary
```
┌─────────────────────────────┐
│ Case Types: Both            │
│ LOBs: All                   │
│ Date Range: All Dates       │
│ Format: CSV                 │
└─────────────────────────────┘
Shows current filter settings
```

### Export Button
```
┌─────────────────────────────────┐
│  ⬇ Export 23 Cases to AKRIT    │
└─────────────────────────────────┘
Disabled if 0 cases
```

### Fields Reference
```
┌──────────────────────┐
│ Exported Fields:     │
│ [1] Case ID          │
│ [2] Client ID        │
│ [3] GCI              │
│ [4] CoPer ID         │
│ [5] LOB              │
│ [6] 312 Flag         │
│ [7] Employee Flag    │
└──────────────────────┘
Always the same 7 fields
```

---

## 🔄 Filter Logic Flow

```
                START
                  │
                  ▼
        ┌─────────────────┐
        │  All Cases      │
        │  (Default)      │
        └────────┬────────┘
                 │
                 ▼
        ┌─────────────────────┐
        │  Date Range Filter  │
        │  (if set)           │
        └────────┬────────────┘
                 │
                 ▼
        ┌─────────────────────┐
        │  Case Type Filter   │
        │  (312 and/or CAM)   │
        └────────┬────────────┘
                 │
                 ▼
        ┌─────────────────────┐
        │  LOB Filter         │
        │  (if any selected)  │
        └────────┬────────────┘
                 │
                 ▼
        ┌─────────────────────┐
        │  312 Flag Filter    │
        │  (if checked)       │
        └────────┬────────────┘
                 │
                 ▼
        ┌─────────────────────┐
        │  Employee Filter    │
        │  (if checked)       │
        └────────┬────────────┘
                 │
                 ▼
        ┌─────────────────────┐
        │  FILTERED CASES     │
        │  Ready to Export    │
        └─────────────────────┘
```

**Logic**: All filters use AND (cases must match ALL selected criteria)

---

## 📝 Example Export File

### CSV Format:
```csv
Case ID,Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag
312-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-002,CLI-445122,GCI-445122,N/A,PB,Yes,No
CAM-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-003,CLI-778934,GCI-778934,N/A,ML,Yes,No
CAM-2025-002,CLI-223344,GCI-223344,CPR-22334,Consumer,No,Yes
```

### Excel Preview:
```
╔════════════╦═══════════╦═══════════╦══════════╦═══════════╦═══════════╦══════════════╗
║ Case ID    ║ Client ID ║ GCI       ║ CoPer ID ║ LOB       ║ 312 Flag  ║ Employee Flag║
╠════════════╬═══════════╬═══════════╬══════════╬═══════════╬═══════════╬══════════════╣
║312-2025-001║CLI-892341 ║GCI-892341 ║CPR-89234 ║GB/GM      ║Yes        ║No            ║
║312-2025-002║CLI-445122 ║GCI-445122 ║N/A       ║PB         ║Yes        ║No            ║
║CAM-2025-001║CLI-892341 ║GCI-892341 ║CPR-89234 ║GB/GM      ║Yes        ║No            ║
╚════════════╩═══════════╩═══════════╩══════════╩═══════════╩═══════════╩══════════════╝
```

---

## 🎬 Export Process Animation

```
1. User Reviews Filters
   ┌─────────────────┐
   │ Filters Panel   │
   │ ☑ 312 Review    │
   │ ☐ LOB: PB       │
   └─────────────────┘
           │
           ▼
2. System Counts Cases
   ┌─────────────────┐
   │   Preview Box   │
   │      12         │
   │     cases       │
   └─────────────────┘
           │
           ▼
3. User Clicks Export
   ┌─────────────────────┐
   │ ⬇ Export 12 Cases  │
   └─────────────────────┘
           │
           ▼
4. File Generates
   ┌─────────────────┐
   │  Generating...  │
   │  [████████]     │
   └─────────────────┘
           │
           ▼
5. Download Starts
   ┌─────────────────────────────┐
   │ AKRIT_Extract_2025-10-27.csv│
   │ ⬇ Downloading...            │
   └─────────────────────────────┘
           │
           ▼
6. Success Toast
   ┌──────────────────────────────┐
   │ ✓ Export Complete            │
   │ Successfully exported 12     │
   │ cases to file.csv            │
   └──────────────────────────────┘
```

---

## 🎨 Color Coding

### UI Elements

**Primary Actions** (Blue #0071CE):
- Export button
- Selected format button
- Active filters

**Success States** (Green):
- Toast notifications
- Successful export

**Warning States** (Gold #D4AF37):
- Preview box border
- Count indicators

**Error States** (Red #E31837):
- Zero cases warning
- Disabled export button text
- Error toast notifications

**Neutral Elements** (Gray):
- Unchecked filters
- Unselected options
- Helper text

---

## 🚦 Status Indicators

### Export Button States

**Ready (Enabled)**:
```
┌─────────────────────────────┐
│ ⬇ Export 23 Cases to AKRIT │  ← Blue, clickable
└─────────────────────────────┘
```

**No Cases (Disabled)**:
```
┌─────────────────────────────┐
│ ⬇ Export 0 Cases to AKRIT  │  ← Gray, not clickable
└─────────────────────────────┘
❌ No cases match the selected filters
```

**Processing (Future)**:
```
┌─────────────────────────────┐
│ ⏳ Generating Export...     │  ← Loading state
└─────────────────────────────┘
```

---

## 📱 Mobile View

```
┌────────────────────────┐
│  AKRIT Data Extract    │
├────────────────────────┤
│  📅 Date Range         │
│  [From Date picker]    │
│  [To Date picker]      │
│                        │
│  💾 Format             │
│  [CSV] [Excel]         │
│                        │
│  📋 Case Types         │
│  ☑ 312  ☑ CAM         │
│                        │
│  🏢 LOBs               │
│  ☐ GB/GM ☐ PB         │
│  ☐ ML ☐ Consumer       │
│  ☐ CI                  │
│                        │
│  🔍 Filters            │
│  ☐ 312 Flag = Yes      │
│  ☐ Employee = Yes      │
│                        │
│  ─────────────────     │
│                        │
│  📊 Preview            │
│      23 cases          │
│                        │
│  Types: Both           │
│  LOBs: All             │
│  Dates: All            │
│                        │
│  [Export 23 Cases]     │
│  [Reset Filters]       │
└────────────────────────┘
```

---

## 🗂️ File Naming Convention

### Auto-Generated Filenames:

**Pattern**: `AKRIT_Extract_YYYY-MM-DD.ext`

**Examples**:
- `AKRIT_Extract_2025-10-27.csv`
- `AKRIT_Extract_2025-10-27.xlsx`
- `AKRIT_Extract_2025-11-15.csv`

**Date**: Always today's date (export generation date)

---

## ⚡ Keyboard Shortcuts (Future)

```
┌──────────────────────────────────┐
│  Keyboard Shortcuts              │
├──────────────────────────────────┤
│  Ctrl + E    Export              │
│  Ctrl + R    Reset Filters       │
│  Ctrl + D    Toggle Date Picker  │
│  Ctrl + F    Focus Filter Panel  │
│  Tab         Navigate Filters    │
│  Enter       Apply Selection     │
└──────────────────────────────────┘
(Not yet implemented)
```

---

## 📊 Common Filter Combinations

### Monthly Quality Review
```
✓ From: Oct 1, 2025
✓ To: Oct 31, 2025
✓ 312 Review: ☑
✓ CAM Review: ☑
✓ All LOBs
✓ Format: CSV
→ Result: All cases for October
```

### 312 Audit Only
```
✓ No date range
✓ 312 Review: ☑
✓ CAM Review: ☐
✓ 312 Flag: ☑ Yes only
✓ Format: CSV
→ Result: All 312 flagged cases
```

### Employee Cases
```
✓ No date range
✓ Both case types: ☑
✓ Employee Flag: ☑ Yes only
✓ Format: Excel
→ Result: All employee/affiliate cases
```

### Private Bank Monthly
```
✓ From: Oct 1, 2025
✓ To: Oct 31, 2025
✓ Both case types: ☑
✓ LOB: PB ☑ only
✓ Format: CSV
→ Result: October PB cases
```

---

## 🎯 Success Checklist

Before exporting, verify:

```
☐ Filters set correctly
☐ Preview shows expected case count
☐ Export format selected (CSV/Excel)
☐ Date range appropriate (if set)
☐ Case types selected
☐ LOBs selected (if specific needed)
☐ Additional flags set (if specific needed)

After exporting, verify:

☐ File downloaded successfully
☐ Filename follows convention
☐ Toast notification appeared
☐ File opens without errors
☐ Row count = preview count + 1 (header)
☐ All 7 columns present
☐ Data looks correct
```

---

## 🔗 Quick Links

**Documentation**:
- Full Guide: `/AKRIT_DATA_EXTRACT.md`
- Quick Start: `/AKRIT_QUICK_START.md`
- Testing Guide: `/AKRIT_TESTING_GUIDE.md`
- Implementation: `/AKRIT_IMPLEMENTATION_SUMMARY.md`

**Code Files**:
- Export Functions: `/utils/reportExports.ts`
- UI Component: `/components/Reports.tsx`

**Support**:
- Technical Issues → IT Support
- Data Questions → AML Operations
- AKRIT Import → Quality Team

---

## 📐 Dimensions & Specs

### UI Measurements:
- **Filter Panel Width**: 2/3 of screen (lg:col-span-2)
- **Preview Panel Width**: 1/3 of screen
- **Button Height**: Large (lg)
- **Card Padding**: Standard (p-6)
- **Gap Between Elements**: 4-6 spacing units

### File Specs:
- **Encoding**: UTF-8
- **Line Endings**: LF (\\n)
- **Delimiter**: Comma (,) for CSV, Tab (\\t) for Excel
- **Quote Character**: Double quote (")
- **Header Row**: Yes (always included)

---

**Visual Reference Version**: 1.0  
**Last Updated**: October 27, 2025  
**Print**: Keep at desk for quick reference
