import { useState } from 'react';
import {
  Box,
  AppBar,
  Toolbar,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Avatar,
  Typography,
  Chip,
  Divider,
  Button,
  Menu,
  MenuItem,
  FormControl,
  Select,
  CssBaseline,
} from '@mui/material';
import {
  Description,
  People,
  BarChart,
  Notifications,
  Settings,
  VpnKey,
  AccountTreeOutlined,
  Security,
  ExpandMore,
  Logout,
  AccountCircle,
  AccountTree,
} from '@mui/icons-material';
import { ThemeWrapper } from './components/ThemeWrapper';
import { Dashboard } from './components/Dashboard';
import { CaseWorkbasket } from './components/CaseWorklist';
import { IndividualWorklist } from './components/IndividualWorklist';
import { SalesOwnerWorklist } from './components/SalesOwnerWorklist';
import { CombinedWorklist } from './components/CombinedWorklist';
import { CaseDetails } from './components/CaseDetails';
import { CaseDetailsEnhanced } from './components/CaseDetailsEnhanced_NEW';
import { PopulationIdentification } from './components/PopulationIdentification';
import { Cam312PopulationLogic } from './components/Cam312PopulationLogic';
import { PopulationDataDictionary } from './components/PopulationDataDictionary';
import { Case312DataDictionary } from './components/Case312DataDictionary';
import { CaseCreationLogic } from './components/CaseCreationLogic';
import { Reports } from './components/Reports';
import { Notifications as NotificationsPage } from './components/Notifications';
import { SystemIntegrations } from './components/SystemIntegrations';
import { RolesEntitlements } from './components/RolesEntitlements';
import { WorkflowDiagram } from './components/WorkflowDiagram';
import { DataModelMapping } from './components/DataModelMapping';
import { DataDictionaryViewer } from './components/DataDictionaryViewer';
import { mockUsers, UserAccess, getPermissionsForRole } from './data/rolesEntitlementsMockData';
import { mockCases } from './data/enhancedMockData';

type Page = 'dashboard' | 'my-cases' | 'worklist' | 'case-details' | 'populations' | 'cam312-logic' | 'population-dictionary' | 'case-creation' | 'reports' | 'notifications' | 'integrations' | 'roles' | 'workflow-diagram' | 'data-model' | '312-dictionary' | 'data-dictionary';

const drawerWidth = 260;

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('my-cases');
  const [selectedCaseId, setSelectedCaseId] = useState<string>('');
  const [currentUser, setCurrentUser] = useState<UserAccess>(mockUsers[0]);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const permissions = getPermissionsForRole(currentUser.role);

  const handleViewCase = (caseId: string) => {
    setSelectedCaseId(caseId);
    setCurrentPage('case-details');
  };

  const handleBackToWorklist = () => {
    setCurrentPage('my-cases');
    setSelectedCaseId('');
  };

  const handleUserChange = (event: any) => {
    const user = mockUsers.find(u => u.id === event.target.value);
    if (user) {
      setCurrentUser(user);
      setCurrentPage('my-cases');
    }
  };

  const handleCaseAssigned = (caseId: string, assignee: string) => {
    const caseToUpdate = mockCases.find(c => c.id === caseId);
    if (caseToUpdate) {
      caseToUpdate.assignedTo = assignee;
      if (caseToUpdate.status === 'Unassigned') {
        caseToUpdate.status = 'In Progress';
      }
    }
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  // Define menu items
  const menuItems = [
    { label: 'Worklist', value: 'my-cases' as Page, icon: Description, badge: '3' },
    { label: 'Population Identification', value: 'populations' as Page, icon: People },
    { label: 'Case Creation', value: 'case-creation' as Page, icon: AccountTree },
    { label: 'Reports', value: 'reports' as Page, icon: BarChart },
    { label: 'Notifications', value: 'notifications' as Page, icon: Notifications },
  ];

  const adminItems = [
    { label: 'System Integrations', value: 'integrations' as Page, icon: Settings },
    { label: 'Roles & Entitlements', value: 'roles' as Page, icon: VpnKey },
    { label: 'Workflow Diagram', value: 'workflow-diagram' as Page, icon: AccountTreeOutlined },
  ];

  // Filter menu items based on permissions
  const visibleMenuItems = menuItems.filter(item => {
    if (item.value === 'my-cases') return permissions.viewWorklist || permissions.viewDashboard;
    if (item.value === 'worklist') return permissions.viewWorklist;
    if (item.value === 'populations') return permissions.viewDashboard;
    if (item.value === 'case-creation') return permissions.viewDashboard;
    if (item.value === 'reports') return permissions.viewDashboard;
    if (item.value === 'notifications') return true;
    return true;
  });

  const visibleAdminItems = adminItems.filter(item => {
    // Only show admin items to managers
    if (currentUser.role === 'Central Team Manager') return true;
    return false;
  });

  return (
    <ThemeWrapper>
      <CssBaseline />
      <Box sx={{ display: 'flex', minHeight: '100vh' }}>
        {/* Sidebar */}
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            '& .MuiDrawer-paper': {
              width: drawerWidth,
              boxSizing: 'border-box',
              borderRight: '1px solid',
              borderColor: 'divider',
              bgcolor: 'oklch(0.985 0 0)',
            },
          }}
        >
          {/* Logo Section */}
          <Box
            sx={{
              bgcolor: 'white',
              px: 3,
              height: 70,
              display: 'flex',
              alignItems: 'center',
              borderBottom: '1px solid',
              borderColor: 'divider',
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 700, color: 'primary.main' }}>
              Bank of America
            </Typography>
          </Box>

          {/* Platform Header */}
          <Box sx={{ p: 2, bgcolor: 'oklch(0.985 0 0)' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <Avatar sx={{ bgcolor: 'primary.main', width: 40, height: 40 }}>
                <Security />
              </Avatar>
              <Box>
                <Typography variant="body2" fontWeight={600}>
                  CAM Platform
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  AML Compliance
                </Typography>
              </Box>
            </Box>
          </Box>

          {/* Navigation Menu */}
          <Box sx={{ overflow: 'auto', flex: 1, bgcolor: 'oklch(0.985 0 0)' }}>
            <Typography
              variant="caption"
              sx={{ px: 2, py: 1, display: 'block', color: 'text.secondary', fontWeight: 600 }}
            >
              NAVIGATION
            </Typography>
            <List>
              {visibleMenuItems.map((item) => (
                <ListItem key={item.value} disablePadding>
                  <ListItemButton
                    selected={currentPage === item.value}
                    onClick={() => setCurrentPage(item.value)}
                    sx={{
                      mx: 1,
                      borderRadius: 1,
                      bgcolor: 'oklch(0.985 0 0)',
                      '&.Mui-selected': {
                        bgcolor: 'primary.main',
                        color: 'white',
                        '&:hover': {
                          bgcolor: 'primary.dark',
                        },
                        '& .MuiListItemIcon-root': {
                          color: 'white',
                        },
                      },
                      '&:hover': {
                        bgcolor: 'action.hover',
                      },
                    }}
                  >
                    <ListItemIcon sx={{ minWidth: 40 }}>
                      <item.icon fontSize="small" />
                    </ListItemIcon>
                    <ListItemText
                      primary={item.label}
                      primaryTypographyProps={{ fontSize: '0.875rem' }}
                    />
                    {item.badge && (
                      <Chip label={item.badge} size="small" color="primary" />
                    )}
                  </ListItemButton>
                </ListItem>
              ))}
            </List>

            {visibleAdminItems.length > 0 && (
              <>
                <Divider sx={{ my: 1 }} />
                <Typography
                  variant="caption"
                  sx={{ px: 2, py: 1, display: 'block', color: 'text.secondary', fontWeight: 600 }}
                >
                  ADMINISTRATION
                </Typography>
                <List>
                  {visibleAdminItems.map((item) => (
                    <ListItem key={item.value} disablePadding>
                      <ListItemButton
                        selected={currentPage === item.value}
                        onClick={() => setCurrentPage(item.value)}
                        sx={{
                          mx: 1,
                          borderRadius: 1,
                          '&.Mui-selected': {
                            bgcolor: 'primary.main',
                            color: 'white',
                            '&:hover': {
                              bgcolor: 'primary.dark',
                            },
                            '& .MuiListItemIcon-root': {
                              color: 'white',
                            },
                          },
                        }}
                      >
                        <ListItemIcon sx={{ minWidth: 40 }}>
                          <item.icon fontSize="small" />
                        </ListItemIcon>
                        <ListItemText
                          primary={item.label}
                          primaryTypographyProps={{ fontSize: '0.875rem' }}
                        />
                      </ListItemButton>
                    </ListItem>
                  ))}
                </List>
              </>
            )}


          </Box>

          {/* User Profile Footer */}
          <Box sx={{ borderTop: '1px solid', borderColor: 'divider', p: 2, bgcolor: 'oklch(0.985 0 0)' }}>
            <Button
              fullWidth
              onClick={handleMenuClick}
              sx={{
                justifyContent: 'flex-start',
                textTransform: 'none',
                color: 'text.primary',
                '&:hover': {
                  bgcolor: 'action.hover',
                },
              }}
            >
              <Avatar sx={{ width: 32, height: 32, mr: 1.5, fontSize: '0.875rem' }}>
                {currentUser.avatar}
              </Avatar>
              <Box sx={{ flex: 1, textAlign: 'left' }}>
                <Typography variant="body2" fontWeight={500}>
                  {currentUser.name}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {currentUser.role}
                </Typography>
              </Box>
              <ExpandMore fontSize="small" />
            </Button>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              transformOrigin={{
                vertical: 'bottom',
                horizontal: 'right',
              }}
            >
              <MenuItem disabled>
                <Typography variant="subtitle2">My Account</Typography>
              </MenuItem>
              <Divider />
              <MenuItem onClick={handleMenuClose}>Profile Settings</MenuItem>
              <MenuItem onClick={handleMenuClose}>Preferences</MenuItem>
              <Divider />
              <MenuItem onClick={handleMenuClose}>
                <Logout fontSize="small" sx={{ mr: 1 }} />
                Sign Out
              </MenuItem>
            </Menu>
          </Box>
        </Drawer>

        {/* Main Content */}
        <Box component="main" sx={{ flexGrow: 1, bgcolor: 'background.default', display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
          {/* Top App Bar */}
          <AppBar
            position="sticky"
            elevation={0}
            sx={{
              bgcolor: 'background.paper',
              borderBottom: '1px solid',
              borderColor: 'divider',
              height: 70,
              justifyContent: 'center',
            }}
          >
            <Toolbar sx={{ justifyContent: 'flex-end' }}>
              <Chip
                icon={<Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: 'success.main' }} />}
                label="All Systems Operational"
                size="small"
                sx={{
                  bgcolor: 'success.lighter',
                  color: 'success.dark',
                  border: '1px solid',
                  borderColor: 'success.light',
                }}
              />

              <Divider orientation="vertical" flexItem sx={{ mx: 2 }} />

              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <AccountCircle color="action" />
                <FormControl size="small" sx={{ minWidth: 200 }}>
                  <Select
                    value={currentUser.id}
                    onChange={handleUserChange}
                    renderValue={() => (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Avatar sx={{ width: 24, height: 24, fontSize: '0.75rem' }}>
                          {currentUser.avatar}
                        </Avatar>
                        <Typography variant="body2">{currentUser.name}</Typography>
                      </Box>
                    )}
                  >
                    {mockUsers.filter(u => u.status === 'Active').map((user) => (
                      <MenuItem key={user.id} value={user.id}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Avatar sx={{ width: 24, height: 24, fontSize: '0.75rem' }}>
                            {user.avatar}
                          </Avatar>
                          <Box>
                            <Typography variant="body2">{user.name}</Typography>
                            <Typography variant="caption" color="text.secondary">
                              {user.role}
                            </Typography>
                          </Box>
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>
            </Toolbar>
          </AppBar>

          {/* Page Content */}
          <Box sx={{ p: 3, width: '100%', flex: 1, display: 'flex', flexDirection: 'column', overflowY: 'auto', bgcolor: 'white' }}>
            {currentPage === 'dashboard' && <Dashboard currentUser={currentUser} />}
            {currentPage === 'my-cases' && (
              <CombinedWorklist 
                onViewCase={handleViewCase} 
                currentUser={currentUser}
                onCaseAssigned={handleCaseAssigned}
              />
            )}
            {currentPage === 'case-details' && (
              <CaseDetailsEnhanced caseId={selectedCaseId} onBack={handleBackToWorklist} currentUser={currentUser} />
            )}
            {currentPage === 'populations' && <PopulationIdentification />}
            {currentPage === 'cam312-logic' && <Cam312PopulationLogic />}
            {currentPage === 'population-dictionary' && <PopulationDataDictionary />}
            {currentPage === 'case-creation' && <CaseCreationLogic />}
            {currentPage === 'reports' && <Reports currentUser={currentUser} />}
            {currentPage === 'notifications' && <NotificationsPage currentUser={currentUser} />}
            {currentPage === 'integrations' && <SystemIntegrations />}
            {currentPage === 'roles' && <RolesEntitlements />}
            {currentPage === 'workflow-diagram' && <WorkflowDiagram />}
            {currentPage === 'data-model' && <DataModelMapping />}
            {currentPage === 'data-dictionary' && <DataDictionaryViewer />}
          </Box>
        </Box>
      </Box>
    </ThemeWrapper>
  );
}