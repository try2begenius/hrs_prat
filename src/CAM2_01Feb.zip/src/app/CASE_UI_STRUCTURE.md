# Case UI Structure - Implementation Guide

## Overview

The Case UI provides a comprehensive 5-section interface for reviewing and dispositioning combined 312 and CAM cases. All sections (except the Case Banner) are expandable and collapsible for flexible navigation.

---

## Section Summary

| Section | Name | Editable | Always Visible | Access Control |
|---------|------|----------|----------------|----------------|
| 1 | Case Banner | ❌ No | ✅ Yes | All users |
| 2 | Case and Client Details | ❌ No | ❌ Collapsible | All users |
| 3 | 312 Case | ✅ Yes (Questions) | ❌ Collapsible | 312 case only |
| 4 | CAM Case | ✅ Yes (Questions) | ❌ Collapsible | CAM case only |
| 5 | Sales Owner Review | ✅ Yes (Comments) | ❌ Collapsible | Sales Owner + Assignee only |

---

## Section 1: Case Banner

### Purpose
Provides at-a-glance case overview that remains visible while scrolling through other sections.

### Layout
- Always visible at top of page
- Non-editable
- Highlighted border (left border in primary color)
- Includes back navigation

### Data Fields (6 total)

| Field | Source | Format |
|-------|--------|--------|
| Case ID | `caseData.id` | Monospace, primary color |
| Client Name | `caseData.clientName` | Regular text |
| GCI/MP ID | `caseData.gci` / `caseData.mpId` | Monospace, combined display (e.g., "GCI-001 / MP-123") |
| Party ID | `caseData.partyId` | Monospace |
| Case Status | `caseData.status` | Badge with color coding |
| Case Assignee | `caseData.assignedTo` | Regular text |

### Status Badge Colors
```typescript
'Unassigned': gray
'In Progress': amber
'Pending Sales Review': blue
'In Sales Review': purple
'Sales Review Complete': indigo
'Complete': green
'Defect Remediation': red
'Escalated': destructive red
'Closed': green
```

---

## Section 2: Case and Client Details

### Purpose
Displays comprehensive case metadata and client information from FLU AML systems.

### Characteristics
- First collapsible section
- All fields non-editable (read-only)
- Data sourced from multiple systems
- **NEW**: Organized into 4 visual subsections with 312/CAM attributes side-by-side
- Grid layout (responsive: 1-3 columns)

### Visual Structure (4 Subsections)
1. **Client Information** - Entity name, individual names, case number
2. **Case Attributes** - 312 attributes (blue box, left) vs CAM attributes (emerald box, right)
3. **General Case Information** - Assignment, LOB, indicators
4. **Business & Compliance Information** - NAICS, refresh dates, AML attributes

### Data Fields

#### Core Fields (Always Visible)
- Entity Name
- Case Number
- Assigned To
- LOB(s)
- 312 Client indicator (badge)
- BOA Employee (badge - purple for Yes)
- BOA Affiliate Indicator (badge - indigo for Yes)
- Reg O Indicator (badge - orange for Yes)

#### Individual Client Fields (Conditional)
- First Name
- Middle Name
- Last Name

#### 312 Fields (Only visible if `is312Case === true`)
- 312 Due Date
- 312 Aging (days)
- 312 Case Status
- 312 Case Disposition
- 312 Completed Date (if completed)
- Source of Funds

#### CAM Fields
- CAM Due Date
- CAM Aging (days)
- CAM Case Status
- CAM Case Disposition
- CAM Completed Date (if completed)

#### Additional Fields (Optional)
- NAICS Code + Description
- Refresh Due Date(s)
- Last Refresh Completion Date
- Client Owner(s)
- AML Attributes / CBA Codes (badge array)
- Refresh Due Date(s) (array)
- Client Owner(s) (array)

### Data Sources
- **Cesium**: Client data
- **WCC**: Wealth client data
- **CMT**: Client management tool
- **GWIM Hub**: Hub data
- **PRDS**: Product data
- **CP**: Client platform
- **FLU Systems**: Monitoring data

---

## Section 3: 312 Case

### Purpose
Subcase section for 312 review with read-only data and actionable questions.

### Visibility Logic
```typescript
const is312Case = caseData.is312Case || caseData.caseType === '312 Review';
// Only render if is312Case === true
```

### Submission State
- **Before Submission**: All fields editable, Save/Cancel/Submit buttons visible
- **After Submission**: All fields read-only, buttons hidden, lock badge shown

### Read-Only Fields

#### 312 Case Information
- 312 Due Date
- 312 Model Result
- 312 Model Result Description

#### Expected Activity - Volume
**ML/PB LOBs**:
- Electronic Transfers (count)
- Cash/Checks (count)

**GB/GM LOB**:
- Broken out by DDQ fields (dynamic)

#### Expected Activity - Value
**ML/PB LOBs**:
- Electronic Transfers (currency)
- Cash/Checks (currency)

**GB/GM LOB**:
- Broken out by DDQ fields (dynamic, currency)

#### Purpose Fields (LOB-specific)
- Purpose of Relationship (GB/GM only)
- Purpose of Account (ML/PB only)
- Source of Funds (ML/PB only)

### Actionable Questions (Required)

#### Question 1
**Prompt**: "Is there any change to expectations for client's activity (based on knowledge of the client)?"  
**Type**: Yes/No radio buttons  
**Required**: Yes

**Sub-Question 1.1** (If Yes):  
**Prompt**: "Please provide rationale"  
**Type**: Dropdown  
**Options**:
- Business Expansion
- New Business Line
- Seasonal Variation
- Client Request
- Regulatory Change
- Other

#### Question 2
**Prompt**: "Is there any change to expectations for client's activity (based on knowledge of the client)?"  
**Type**: Yes/No radio buttons  
**Required**: Yes

**Sub-Question 2.1** (If Yes):  
**Prompt**: "Please provide comments"  
**Type**: Freeform text area  
**Required**: Yes

#### Question 3
**Prompt**: "Is there further activity seen, either in the current review period or historical, which is not aligned with the client's nature and purpose of relationship and expectations for client activity and has not already been explained during this or prior reviews?"  
**Type**: Yes/No radio buttons  
**Required**: Yes

**Sub-Question 3.1** (If Yes):  
**Prompt**: "Please add comments"  
**Type**: Freeform text area  
**Required**: Yes

#### Question 4: Case Action
**Prompt**: "Case Action"  
**Type**: Dropdown  
**Required**: Yes  
**Options**:
1. Complete – No action
2. Complete – TRMS filed (requires TRMS #)
3. Send to Sales (requires Sales Owner selection) - PB, ML, GB/GM only

**Conditional Fields**:
- If "TRMS filed": Text input for TRMS number (required)
- If "Send to Sales": Dropdown for Sales Owner selection (required)

### Action Buttons

#### Save Button
- **Function**: Stores responses until next session
- **Validation**: Warns if required fields incomplete
- **State**: Remains in edit mode

#### Cancel Button
- **Function**: Discards changes, returns to Case Summary/Worklist
- **Validation**: None
- **State**: No data saved

#### Submit Button
- **Function**: Final disposition, locks section
- **Validation**: All required questions must be complete
- **Warning**: "Once you submit you will be unable to make edits/changes to this section"
- **State**: Section becomes read-only after submission

### Validation Rules

**Save Validation**:
```typescript
- Question 1 answered
- If Q1 = Yes → Q1.1 completed
- Question 2 answered
- If Q2 = Yes → Q2.1 completed
- Question 3 answered
- If Q3 = Yes → Q3.1 completed
- Question 4 (Case Action) selected
- If Action = TRMS filed → TRMS# provided
- If Action = Send to Sales → Sales Owner selected
```

**Submit Validation**: Same as Save + confirmation dialog

---

## Section 4: Client Activity Monitoring Case

### Purpose
CAM review section with monitoring dashboard and disposition questions.

### Visibility Logic
```typescript
const isCAMCase = caseData.caseType === 'CAM Review' || is312Case;
// CAM always shows for combined 312+CAM cases
```

### Structure
- Section 4.1: CAM Case Details
- Section 4.2: Monitoring Dashboard (7 subsections)
- Section 4.2.8: CAM Case Disposition (editable)

---

### Section 4.1: CAM Case Details

**Fields**:
- CAM Case Due Date
- CAM Trigger(s) - display all if multiple

---

### Section 4.2: Monitoring Dashboard

Displays 12 months of monitoring data in data grids.

#### Section 4.2.1: TRMS from FLU and FLD Monitoring

**Columns** (7):
1. TRMS ID
2. TRMS Type
3. Monitoring Process
4. Description Reason
5. Impact Type (Product)
6. Narrative (freeform text)
7. TRMS Date
8. Submitter LOB

**Default Sort**: Most recent TRMS date (descending)

#### Section 4.2.2: TRMS (Other)

**Columns** (Same as 4.2.1):
1. TRMS ID
2. TRMS Type
3. Monitoring Process
4. Description Reason
5. Impact Type (Product)
6. Narrative
7. TRMS Date
8. Submitter LOB

**Default Sort**: Most recent TRMS date (descending)

#### Section 4.2.3: Second Line Monitoring Cases

**Columns** (10):
1. Case ID
2. Case Type
3. Case Status
4. Case Description
5. Monitoring Process
6. Narrative
7. Date
8. LOB
9. Linked TRMS
10. SAR Y/N
11. Party in SAR

**Default Sort**: Most recent date (descending)

#### Section 4.2.4: Fraud Cases

**Columns** (6):
1. Case ID
2. Case Status
3. Narrative
4. Date
5. LOB
6. SAR Y/N
7. Party in SAR

**Default Sort**: Most recent date (descending)

#### Section 4.2.5: Sanctions Detail

**Columns** (7):
1. Case ID
2. Product
3. Alert Date
4. Alert Description/Narrative
5. Block/Reject
6. LOB
7. Outcome

**Default Sort**: Most recent alert date (descending)

#### Section 4.2.6: 312 Alert Detail

**Columns** (3):
1. 312 LOB
2. Alert Date
3. Alert Description

**Default Sort**: Most recent alert date (descending)

#### Section 4.2.7: LOB Monitoring Controls

**Columns** (2):
1. Activity Description
2. Supporting data point(s) - count, alerts since last CAM completed date

**Sort**: Not sorted by date (display as configured)

**Note**: Always populated with activity description

---

### Section 4.2.8: CAM Case Disposition

**Purpose**: Editable section where user dispositions the CAM review.

#### Question 1
**Prompt**: "After review of the monitoring activity over the last 12 months – are there any additional items that need to be raised as a result of this monitoring?"  
**Type**: Yes/No dropdown  
**Required**: Yes

**Sub-Question 1.1** (If No):  
**Type**: Attestation checkboxes  
**Display Logic**: Checkboxes displayed based on specific case triggers  
**Options** (trigger-dependent):
- ✓ Triggers and alerts are confirmed in line with the client expectations or already properly escalated
- ✓ I have reviewed the alerts and escalations and believe no further escalation is required to be raised
- ✓ No additional findings or knowledge of the client require an escalation outside of what has been already properly escalated

**Sub-Question 1.2** (If Yes):  
**Prompt**: "Please file a TRMS indicating unusual alert(s) or activity and document TRMS number"  
**Type**: Radio button or instruction

**Sub-Question 1.3**:  
**Prompt**: "TRMS #"  
**Type**: Text input  
**Required**: If Q1 = Yes

#### Question 2
**Prompt**: "I confirm that all data has been reviewed and the responses to the above questions are accurate"  
**Type**: Checkbox  
**Required**: Yes (must be checked)

#### Question 3: Case Action
**Prompt**: "Case Action"  
**Type**: Dropdown  
**Required**: Yes  
**Options**:
1. Complete – No action
2. Complete – TRMS filed (requires TRMS #)
3. Send to Sales (requires Sales Owner + Comments)

**Conditional Fields**:
- If "TRMS filed": Text input for TRMS number (required)
- If "Send to Sales": 
  - Sales Owner dropdown (required)
  - Comments text area (mandatory, max 4000 chars)

### Action Buttons

Same as 312 section:
- Save (with validation)
- Cancel
- Submit (with confirmation + lock warning)

### Validation Rules

**Save/Submit Validation**:
```typescript
- Question 1 answered
- If Q1 = No → Attestations checked
- If Q1 = Yes → Q1.2 answered
- If Q1.2 = Yes → Q1.3 TRMS# provided
- Question 2 checked
- Question 3 (Case Action) selected
- If Action = TRMS filed → TRMS# provided
- If Action = Send to Sales → Sales Owner + Comments provided
- Comments max 4000 characters
```

---

## Section 5: Sales Owner Review

### Purpose
Allows Sales Owners to provide business context and relationship feedback.

### Access Control
```typescript
const isSalesOwner = currentUser.role === 'Sales Owner';
const isAssignee = caseData.assignedTo === currentUser.name;
const canViewSalesSection = isSalesOwner || isAssignee;
```

**Access**: Sales Owner OR Case Assignee only

### Structure
- Section 5.1: Case Details (summary)
- Section 5.2: 312/CAM Details (subset of data)
- Section 5.3: Case Processor Comments
- Section 5.4: Sales Owner Response

### Privacy Note
Subset of data shown to eliminate risk of tipping off.

---

### Section 5.1: Case Details

**Purpose**: Summary of case(s)  
**Visibility Logic**: If 312 auto-closed, hide 312 section. If CAM auto-closed, hide CAM section.

---

### Section 5.2.1: 312 Case (Sales Owner View)

**Read-Only Fields**:
- 312 Due Date
- 312 Model Result
- 312 Model Result Description
- Expected Activity – Volume (broken out by FLU SOR)
- Expected Activity – Value (broken out by FLU SOR)
- Purpose of Relationship (GB/GM only)
- Purpose of Account (ML/PB only)
- Source of Funds

**Note**: No sensitive monitoring data included

---

### Section 5.2.2: CAM Case (Sales Owner View)

**Purpose**: Summarized monitoring dashboard (privacy-filtered)

#### Section 5.2.2.1: FLU Monitoring

**Columns** (3):
- Activity Description
- Activity Count
- Last Completed Date

#### Section 5.2.2.2: TRMS Summary

**Columns** (6):
- Monitoring Process
- Description Reason
- Impact Type (Product)
- Narrative (pop-up to reduce exposure)
- TRMS Date
- Submitter LOB

**Note**: Removes Case ID and other identifiable info

#### Section 5.2.2.3: Second Line Case

**Columns** (5):
- Case Description
- Narrative
- Case Date
- LOB
- Associated TRMS

**Note**: No Case ID, no SAR info

#### Section 5.2.2.4: First Party Fraud Cases

**Columns** (3):
- LOB
- Narrative
- Case Date

**Note**: No Case ID, no SAR info

#### Section 5.2.2.5: Sanctions

**Columns** (5):
- LOB
- Block/Reject
- Product
- Narrative
- Date

**Note**: No Case ID

---

### Section 5.3: Case Processor Comments

**Purpose**: Display analyst's questions/comments to Sales Owner

**Fields**:
- Case Type label (312 or CAM)
- Case Processor Name
- Case Processor Comment
- Date

**Display**: Table or card list format

---

### Section 5.4: Sales Owner Response

**Purpose**: Freeform response area for Sales Owner feedback

**Field**:
- Comments box (freeform text area)
- Character limit: 4000 characters
- Required before submit

**Action Buttons**:

#### Save Button
- Stores response until next session
- Validation: Comments not empty

#### Cancel Button
- Returns to case summary/worklist
- No data saved

#### Return to Case Processor Button
- Similar to Submit
- Routes case back to case processor
- Status changes (e.g., "In Sales Review" → "Sales Review Complete")
- Validation: Comments required
- Warning: Confirms return action

---

## Implementation Architecture

### Component Structure
```
/components/
  CaseDetailsEnhanced.tsx         # Main container
  /case-sections/
    Section312Case.tsx             # Section 3
    SectionCAMCase.tsx             # Section 4
    SectionSalesReview.tsx         # Section 5
    MonitoringDashboard.tsx        # Section 4.2
```

### State Management

**Component State**:
```typescript
const [case312Response, setCase312Response] = useState<Case312Response>({...});
const [camCaseResponse, setCAMCaseResponse] = useState<CAMCaseResponse>({...});
const [salesOwnerResponse, setSalesOwnerResponse] = useState<SalesOwnerResponse>({...});
```

**Validation State**:
```typescript
const [showSaveWarning, setShowSaveWarning] = useState(false);
const [showSubmitWarning, setShowSubmitWarning] = useState(false);
const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
const [warningMessage, setWarningMessage] = useState('');
```

**Submission State**:
```typescript
const is312Submitted = case312Response.isSubmitted || false;
const isCAMSubmitted = camCaseResponse.isSubmitted || false;
const isSalesSubmitted = salesOwnerResponse.isSubmitted || false;
```

### UI Components Used

**shadcn/ui**:
- Accordion (collapsible sections)
- Card (section containers)
- Button (actions)
- Badge (status indicators)
- Label (field labels)
- Input (text fields)
- Textarea (comments)
- Select (dropdowns)
- RadioGroup (yes/no questions)
- Checkbox (attestations)
- Table (monitoring data grids)
- AlertDialog (warnings/confirmations)
- Separator (visual dividers)

**Icons (lucide-react)**:
- ArrowLeft (back navigation)
- Save (save button)
- Send (submit button)
- X (cancel button)
- Lock (submitted indicator)
- AlertTriangle (warnings)
- Info (information)
- CheckCircle2 (success)

---

## Validation Logic

### Save Validation
Checks all required fields are complete before allowing save.

**Warning Types**:
- Missing required question answer
- Missing conditional sub-question
- Missing case action
- Missing TRMS number when required
- Missing Sales Owner when required
- Missing comments when required

### Submit Validation
Same as save + confirmation dialog.

**Confirmation Dialog**:
```
"Once you submit, you will be unable to make edits/changes 
to this section. Do you want to proceed?"
```

**Post-Submit State**:
- All fields become read-only
- Action buttons hidden
- Lock badge displayed
- Submitted by/date shown

---

## Data Persistence

### Mock Data Structure
```typescript
interface Case {
  // Existing fields...
  case312Data?: Case312Data;
  case312Response?: Case312Response;
  camCaseData?: CAMCaseData;
  camCaseResponse?: CAMCaseResponse;
  monitoringDashboard?: MonitoringDashboard;
  caseProcessorComments?: CaseProcessorComment[];
  salesOwnerResponse?: SalesOwnerResponse;
}
```

### Response Tracking
```typescript
interface Case312Response {
  question1: boolean | null;
  question1_1?: string;
  question2: boolean | null;
  question2_1?: string;
  question3: boolean | null;
  question3_1?: string;
  question4_action?: 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales';
  question4_trms?: string;
  question4_salesOwner?: string;
  submittedBy?: string;
  submittedDate?: string;
  isSubmitted?: boolean;
}
```

---

## User Experience Flows

### Flow 1: Analyst Completes 312 Case

1. Opens case from worklist
2. Sees Case Banner (always visible)
3. Expands Section 2 (Case Details) to review data
4. Expands Section 3 (312 Case)
5. Reviews read-only 312 data
6. Answers Question 1 (Yes/No)
7. If Yes → Selects rationale from dropdown
8. Answers Question 2 (Yes/No)
9. If Yes → Enters freeform comments
10. Answers Question 3 (Yes/No)
11. If Yes → Enters freeform comments
12. Selects Case Action → "Complete – No action"
13. Clicks Save → Success toast
14. Clicks Submit → Confirmation dialog
15. Confirms → Section locks, success toast
16. Case status updates

### Flow 2: Analyst Routes to Sales

1. Opens case
2. Completes 312 section questions
3. For Question 4 → Selects "Send to Sales"
4. System prompts for Sales Owner selection
5. Selects "David Park" from dropdown
6. Clicks Save
7. Expands Section 4 (CAM Case)
8. Reviews monitoring dashboard
9. Completes CAM questions
10. For Question 3 → Selects "Send to Sales"
11. Selects Sales Owner
12. Enters mandatory comments (reason for sales review)
13. Clicks Submit on CAM section
14. Case status → "Pending Sales Review"
15. assignedTo → "David Park"
16. centralTeamContact → "Current User"

### Flow 3: Sales Owner Provides Feedback

1. Sales Owner logs in
2. Navigates to "My Cases"
3. Sees case in "Pending Sales Review"
4. Opens case
5. Sees Case Banner
6. Section 5 (Sales Owner Review) auto-expanded
7. Sees 312/CAM summary data (privacy-filtered)
8. Reviews Case Processor Comments
9. Sees analyst's questions/context
10. Scrolls to Sales Owner Response section
11. Enters detailed comments (max 4000 chars)
12. Clicks Save (comments stored)
13. Reviews again, makes edits
14. Clicks "Return to Case Processor"
15. Confirmation dialog → Confirms
16. Case status → "Sales Review Complete"
17. assignedTo → original analyst (from centralTeamContact)
18. Success toast

### Flow 4: Analyst Finalizes After Sales Review

1. Analyst sees case returned from sales
2. Case status = "Sales Review Complete"
3. Opens case
4. Sections 3 & 4 are locked (already submitted)
5. Expands Section 5 to read Sales Owner feedback
6. Reviews sales comments
7. Based on feedback, may file TRMS or complete case
8. Updates case disposition
9. Marks case Complete

---

## Status Transitions via Case UI

| Action | From Status | To Status |
|--------|-------------|-----------|
| Submit 312 (Complete - No action) | In Progress | Complete* |
| Submit 312 (TRMS filed) | In Progress | Complete* |
| Submit 312 (Send to Sales) | In Progress | Pending Sales Review |
| Submit CAM (Send to Sales) | In Progress | Pending Sales Review |
| Sales Owner opens case | Pending Sales Review | In Sales Review |
| Sales Owner returns to processor | In Sales Review | Sales Review Complete |
| Analyst final disposition after sales | Sales Review Complete | Complete |

*If combined case, both 312 and CAM must be submitted before Complete

---

## Error Handling

### Validation Errors
Display in AlertDialog with warning icon:
- Clear error message
- OK button to dismiss
- Focus on missing field

### Network Errors
- Toast notification
- Retry mechanism
- Data preservation (don't lose user input)

### Permission Errors
- Section hidden if no access
- Clear messaging why section unavailable

---

## Accessibility

- Proper ARIA labels
- Keyboard navigation support
- Focus management
- Screen reader announcements for validations
- Color is not sole indicator (icons + text)

---

## Performance Considerations

### Large Monitoring Dashboards
- Virtualized tables for 100+ rows
- Pagination for very large datasets
- Lazy loading of narrative pop-ups

### Data Loading
- Show loading skeleton while fetching
- Cache responses locally
- Debounce auto-save

---

## Testing Scenarios

### 312 Section
- [ ] All questions required validation
- [ ] Conditional sub-questions appear
- [ ] Case action dropdown works
- [ ] TRMS# field shows when needed
- [ ] Sales Owner dropdown shows when needed
- [ ] Save stores data
- [ ] Submit locks section
- [ ] Validation prevents incomplete submit

### CAM Section
- [ ] Monitoring dashboard renders all 7 subsections
- [ ] Data grids sort by date descending
- [ ] Question validation works
- [ ] Attestations display based on triggers
- [ ] Comments mandatory for Send to Sales
- [ ] Character limit enforced
- [ ] Submit locks section

### Sales Section
- [ ] Only visible to Sales Owner + Assignee
- [ ] Privacy-filtered data displays
- [ ] Case processor comments visible
- [ ] Comments field enforces 4000 char limit
- [ ] Return to Processor button works
- [ ] Status changes correctly

---

## Files Modified/Created

### Types
- ✅ `/types/index.ts` - Added Case312Data, CAMCaseData, response interfaces, monitoring types

### Components
- ✅ `/components/CaseDetailsEnhanced.tsx` - Main container (partial)
- ✅ `/components/case-sections/Section312Case.tsx` - Section 3
- ⏳ `/components/case-sections/SectionCAMCase.tsx` - Section 4 (to be created)
- ⏳ `/components/case-sections/SectionSalesReview.tsx` - Section 5 (to be created)
- ⏳ `/components/case-sections/MonitoringDashboard.tsx` - Section 4.2 (to be created)

### Mock Data
- ⏳ `/data/enhancedMockData.ts` - Add sample 312/CAM data, monitoring dashboard data

### Documentation
- ✅ `/CASE_UI_STRUCTURE.md` - This file

---

**Document Version**: 1.0  
**Last Updated**: October 26, 2025  
**Status**: In Progress - Core structure defined, partial implementation complete
