# Data Visibility Matrix

This document shows exactly what data each user should see based on their entitlements.

## User Case Visibility Summary

### Sarah Mitchell (Central Team Manager)
- **Entitlements**: 312 ✓, CAM ✓, GB/GM ✓, PB ✓, ML ✓, Employee ✓
- **Should See**:
  - **312 Cases**: 312-2025-001 (GB/GM), 312-2025-005 (PB), 312-2025-006 (PB Employee), 312-2025-007 (ML)
  - **CAM Cases**: CAM-2025-001 (GB/GM), CAM-2025-004 (PB), CAM-2025-005 (PB), CAM-2025-006 (PB Employee), CAM-2025-007 (ML)
- **Total Cases**: ~9 cases
- **Employee Cases Visible**: Yes (3 cases)

### Carlos Rivera (Central Team Manager)
- **Entitlements**: 312 ✓, CAM ✗, PB ✓, Employee ✓
- **Should See**:
  - **312 Cases**: 312-2025-004 (PB), 312-2025-005 (PB), 312-2025-006 (PB Employee), 312-2025-012 (PB)
  - **CAM Cases**: None (no CAM access)
- **Total Cases**: ~4 cases
- **Employee Cases Visible**: Yes (1 case)

### Michael Chen (Central Team Analyst)
- **Entitlements**: 312 ✓, CAM ✓, GB/GM ✓, PB ✓, Employee ✗
- **Should See**:
  - **312 Cases**: 312-2025-001 (GB/GM), 312-2025-002 (GB/GM), 312-2025-003 (GB/GM)
  - **CAM Cases**: CAM-2025-001 (GB/GM), CAM-2025-002 (GB/GM), CAM-2025-003 (GB/GM), CAM-2025-014 (GB/GM)
- **Total Cases**: ~7 cases
- **Employee Cases Visible**: No

### Jennifer Wu (Central Team Analyst)
- **Entitlements**: 312 ✓, CAM ✓, ML ✓, Consumer ✓, CI ✓, Employee ✗
- **Should See**:
  - **312 Cases**: 312-2025-007 (ML), 312-2025-008 (ML)
  - **CAM Cases**: CAM-2025-007 (ML), CAM-2025-008 (ML), CAM-2025-009 (Consumer), CAM-2025-010 (Consumer), CAM-2025-011 (CI), CAM-2025-012 (CI)
- **Total Cases**: ~8 cases
- **Employee Cases Visible**: No

### Lisa Brown (Central Team Analyst)
- **Entitlements**: 312 ✗, CAM ✓, Consumer ✓, CI ✓, Employee ✗
- **Should See**:
  - **312 Cases**: None (no 312 access)
  - **CAM Cases**: CAM-2025-009 (Consumer), CAM-2025-010 (Consumer), CAM-2025-011 (CI), CAM-2025-012 (CI)
- **Total Cases**: ~4 cases
- **Employee Cases Visible**: No

### Kevin Rogers (Central Team Analyst)
- **Entitlements**: 312 ✓, CAM ✓, ML ✓, Consumer ✓, Employee ✓
- **Should See**:
  - **312 Cases**: 312-2025-007 (ML), 312-2025-008 (ML), 312-2025-009 (Consumer Employee)
  - **CAM Cases**: CAM-2025-007 (ML), CAM-2025-008 (ML), CAM-2025-009 (Consumer), CAM-2025-010 (Consumer), CAM-2025-013 (ML Employee)
- **Total Cases**: ~8 cases
- **Employee Cases Visible**: Yes (2 cases)

### Robert Anderson (View Only)
- **Entitlements**: 312 ✓, CAM ✓, All LOBs ✓, Employee ✗
- **Should See**:
  - **All Cases**: All non-employee cases across all LOBs
- **Total Cases**: ~23 cases (all except employee cases)
- **Employee Cases Visible**: No
- **Actions**: View Only (cannot edit/update)

### David Park (Sales Owner)
- **Entitlements**: 312 ✓, CAM ✗, GB/GM ✓, Employee ✗
- **Should See**:
  - **Only Cases Assigned to Him**: 312-2025-010 (Pinnacle Financial Group)
- **Total Cases**: 1 case
- **Employee Cases Visible**: No
- **Special**: No dashboard access, only sees worklist

### Amanda Torres (Sales Owner)
- **Entitlements**: 312 ✓, CAM ✗, ML ✓, Employee ✗
- **Should See**:
  - **Only Cases Assigned to Her**: 312-2025-011 (Horizon Wealth Management)
- **Total Cases**: 1 case
- **Employee Cases Visible**: No
- **Special**: No dashboard access, only sees worklist

## Filtering Logic

### Case Type Filter
```typescript
if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
```

### LOB Filter
```typescript
const caseLOB = c.clientData?.lineOfBusiness;
if (caseLOB && !currentUser.entitlements.lobs.includes(caseLOB)) return false;
```

### Employee Filter
```typescript
if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
```

### Sales Owner Filter
```typescript
if (currentUser.role === 'Sales Owner' && c.assignedTo !== currentUser.name) return false;
```

## Case Distribution by LOB

### GB/GM Cases
- **312**: 312-2025-001, 312-2025-002, 312-2025-003, 312-2025-010
- **CAM**: CAM-2025-001, CAM-2025-002, CAM-2025-003, CAM-2025-014
- **Total**: 8 cases
- **Users with Access**: Sarah Mitchell, Michael Chen, David Park (312 only, assigned)

### PB Cases
- **312**: 312-2025-004, 312-2025-005, 312-2025-006 (Employee), 312-2025-012
- **CAM**: CAM-2025-004, CAM-2025-005, CAM-2025-006 (Employee)
- **Total**: 7 cases (3 employee)
- **Users with Access**: Sarah Mitchell, Carlos Rivera, Michael Chen (no employee)

### ML Cases
- **312**: 312-2025-007, 312-2025-008, 312-2025-011
- **CAM**: CAM-2025-007, CAM-2025-008, CAM-2025-013 (Employee)
- **Total**: 6 cases (1 employee)
- **Users with Access**: Sarah Mitchell, Jennifer Wu, Kevin Rogers, Amanda Torres (312 only, assigned)

### Consumer Cases
- **312**: 312-2025-009 (Employee)
- **CAM**: CAM-2025-009, CAM-2025-010
- **Total**: 3 cases (1 employee)
- **Users with Access**: Jennifer Wu, Lisa Brown (CAM only), Kevin Rogers

### CI Cases
- **312**: None
- **CAM**: CAM-2025-011, CAM-2025-012
- **Total**: 2 cases
- **Users with Access**: Jennifer Wu, Lisa Brown (CAM only)

## Expected Dashboard Metrics (Examples)

### Sarah Mitchell Dashboard
- **Total Cases**: 9
- **312 Reviews**: 4
- **CAM Reviews**: 5
- **Open Cases**: 7-8
- **High Priority**: 6-7
- **LOB Distribution**: GB/GM (3), PB (4), ML (2)
- **Employee Cases**: 3

### Lisa Brown Dashboard
- **Total Cases**: 4
- **312 Reviews**: 0 (no access)
- **CAM Reviews**: 4
- **Open Cases**: 4
- **High Priority**: 3
- **LOB Distribution**: Consumer (2), CI (2)
- **Employee Cases**: 0 (no access)

### Carlos Rivera Dashboard
- **Total Cases**: 4
- **312 Reviews**: 4
- **CAM Reviews**: 0 (no access)
- **Open Cases**: 3
- **High Priority**: 3
- **LOB Distribution**: PB (4)
- **Employee Cases**: 1

## Notification Distribution

Each user should see only their relevant notifications:
- **Sarah Mitchell**: 3 notifications (assignments, deadlines, escalations)
- **Carlos Rivera**: 1 notification (urgent deadline)
- **Michael Chen**: 2 notifications
- **Jennifer Wu**: 2 notifications
- **Lisa Brown**: 1 notification
- **Kevin Rogers**: 1 notification (employee case)
- **Robert Anderson**: 1 notification (report ready)
- **David Park**: 1 notification (feedback request)
- **Amanda Torres**: 1 notification (feedback required)
