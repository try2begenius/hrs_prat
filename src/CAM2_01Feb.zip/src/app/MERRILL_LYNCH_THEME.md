# Merrill Lynch Theme Documentation

## Overview
The CAM Platform now features a professional Merrill Lynch-inspired design system that reflects the brand's corporate identity and values of trust, stability, and excellence in financial services.

## Typography
- **Font Family**: Roboto
- **Weights Used**: 300 (Light), 400 (Regular), 500 (Medium), 700 (Bold)
- **Source**: Google Fonts

## Color Palette

### Primary Colors
- **ML Blue** (#0071CE): Primary brand color, used for primary actions, links, and key UI elements
- **ML Blue Dark** (#005A9C): Hover states and emphasis
- **ML Blue Light** (#E6F2FA): Backgrounds and subtle highlights

### Accent Colors
- **ML Red** (#E31837): The iconic "Bull Red" - used for destructive actions, alerts, and warnings
- **ML Gold** (#D4AF37): Premium accent color for warnings and important highlights
- **ML Navy** (#002B5C): Deep navy for headers, sidebar, and primary text

### Neutral Colors
- **ML Gray** (#54585A): Professional gray for secondary text
- **ML Gray Light** (#F5F5F5): Light backgrounds and subtle dividers

## Design Tokens

### Light Theme (Root)
```css
--primary: #0071CE (ML Blue)
--destructive: #E31837 (ML Red)
--warning: #D4AF37 (ML Gold)
--foreground: #002B5C (ML Navy)
--sidebar: #002B5C (ML Navy)
```

## Component Styling

### Sidebar
- Background: ML Navy (#002B5C)
- Text: White
- Active states: ML Blue
- Professional, high-contrast appearance

### Cards
- White backgrounds with subtle shadows
- ML Blue accents for borders and highlights
- Elevated appearance with depth

### Buttons
- Primary: ML Blue background
- Hover: ML Blue Dark
- Destructive: ML Red

### Status Indicators
- New/Info: ML Blue
- Success: Green (standard)
- Warning: ML Gold
- Error/Escalated: ML Red
- In Progress: Amber (standard)

## Usage Guidelines

### Do's
✓ Use ML Blue for primary actions and interactive elements
✓ Use ML Red sparingly for critical alerts and destructive actions
✓ Use ML Gold for warnings and premium features
✓ Maintain high contrast ratios for accessibility
✓ Use Roboto font consistently throughout

### Don'ts
✗ Don't use ML Red for non-critical UI elements
✗ Don't mix other blue tones with ML Blue
✗ Don't use colors outside the defined palette
✗ Don't override font-family unless absolutely necessary

## Accessibility
- All color combinations meet WCAG 2.1 AA standards
- Text contrast ratios: minimum 4.5:1 for normal text
- Interactive elements have clear focus states
- Color is not the only means of conveying information

## Chart Colors
1. **Chart 1**: ML Blue (#0071CE)
2. **Chart 2**: ML Red (#E31837)
3. **Chart 3**: ML Gold (#D4AF37)
4. **Chart 4**: ML Navy (#002B5C)
5. **Chart 5**: ML Gray (#54585A)

## Implementation Notes
- Theme is implemented via CSS custom properties in `styles/globals.css`
- All components reference theme tokens, not hardcoded colors
- Roboto font is loaded from Google Fonts CDN
- Dark mode variants are available (though light mode is default for financial applications)
