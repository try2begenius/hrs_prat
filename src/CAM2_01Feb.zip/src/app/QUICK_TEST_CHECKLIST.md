# Quick Test Checklist - Case UI Functions

## ✅ Pre-Test: Verify Case Appears

### As Sarah Mitchell (AML Analyst)
- [ ] Go to **"My Cases"**
- [ ] Case `312-2025-001` appears in the list
- [ ] Click **"View Details"**
- [ ] All **4 numbered badges** (1, 2, 3, 4) are visible

### As David Park (Sales Owner)
- [ ] Go to **"Sales Owner Worklist"**
- [ ] Case `312-2025-001` appears in the list
- [ ] Central Team Contact shows: **Sarah Mitchell**
- [ ] Click **"View"** button
- [ ] All **4 numbered badges** visible
- [ ] Badge 4 has **purple "Sales Owner Access"** indicator

---

## 🧪 Test 1: Section 3 - 312 Case (As Sarah Mitchell)

**Access**: Editable for assignee only

- [ ] **Expand Badge 2**
- [ ] See 4 review questions (Q1-Q4)
- [ ] **Q1**: Select "Yes" → Follow-up field appears ✅
- [ ] Type in follow-up text area
- [ ] **Q2**: Select "Yes" → Follow-up field appears ✅
- [ ] **Q3**: Select "Yes" → Follow-up field appears ✅
- [ ] **Q4**: Select action → Conditional dropdown appears ✅
- [ ] Click **"Save Progress"** → Toast notification appears ✅
- [ ] Fill all required fields
- [ ] Click **"Submit 312 Case"** → Confirmation dialog ✅
- [ ] After submit → Section shows "Submitted" badge 🔒
- [ ] Fields become read-only ✅

---

## 🧪 Test 2: Section 4 - CAM Case (As Sarah Mitchell)

**Access**: Editable for assignee only

- [ ] **Expand Badge 3**
- [ ] See **7 monitoring tabs** at top
- [ ] **Click Tab 1** (Acct Open/Mgmt) → Data table displays ✅
- [ ] **Click Tab 2** (Client Interactions) → Data table displays ✅
- [ ] **Click Tab 3** (Internal Referrals) → Data table displays ✅
- [ ] **Click Tab 4** (OFAC/Sanctions) → Data table displays ✅
- [ ] **Click Tab 5** (News/Media) → Data table displays ✅
- [ ] **Click Tab 6** (Regulatory Actions) → Data table displays ✅
- [ ] **Click Tab 7** (Transaction Activity) → Data table displays ✅

### CAM Questions

- [ ] Scroll to questions below tabs
- [ ] **Q1**: Select "Yes" → Attestation checkboxes appear ✅
- [ ] **Check all attestations** → Q1.2 and Q1.3 appear ✅
- [ ] **Q1.2**: Select "Yes" (TRMS) ✅
- [ ] **Q1.3**: Enter TRMS number ✅
- [ ] **Q2**: Select recommendation → Conditional field may appear ✅
- [ ] **Q3**: Type analysis (minimum 50 characters) ✅
- [ ] Click **"Save Progress"** → Toast notification ✅
- [ ] Click **"Submit CAM Case"** → Validation checks ✅
- [ ] After submit → "Submitted" badge appears 🔒

---

## 🧪 Test 3: Section 5 - Sales Owner Review (As David Park)

**Access**: Read-only for Sarah Mitchell, Editable for David Park

### First: Verify Read-Only for AML User

- [ ] **As Sarah Mitchell**: Expand Badge 4
- [ ] See **"View Only - AML Access"** badge (gray) ✅
- [ ] All fields are plain text (not editable) ✅
- [ ] NO Save or Submit buttons ✅
- [ ] Can read processor comments ✅

### Second: Test Editable for Sales Owner

- [ ] **Switch to David Park**
- [ ] Go to "Sales Owner Worklist" → Find case → Click "View"
- [ ] **Expand Badge 4**
- [ ] See **"Sales Owner Access"** badge (purple) ✅
- [ ] Fields are editable (dropdowns, textareas) ✅

### Edit Sales Owner Questions

- [ ] **Q1**: Select "Yes" / "No" / "Partially Agree" → Follow-up appears ✅
- [ ] Type in follow-up text area ✅
- [ ] **Q2**: Select recommendation → Conditional field may appear ✅
- [ ] **Q3**: Type rationale (minimum 50 characters) ✅
- [ ] Click **"Save Progress"** → Toast notification ✅
- [ ] Click **"Submit Sales Owner Review"** → Confirmation dialog ✅
- [ ] After submit → "Submitted" badge appears 🔒
- [ ] Fields become read-only ✅

---

## 🧪 Test 4: Validation & Error Handling

### Test Missing Required Fields

- [ ] **Section 3**: Leave Q1 blank, try to submit → Error alert ✅
- [ ] **Section 4**: Leave Q3 (analysis) blank, try to submit → Error alert ✅
- [ ] **Section 5**: Leave Q3 (rationale) blank, try to submit → Error alert ✅

### Test Minimum Character Requirements

- [ ] **Section 4, Q3**: Type only "Test" (4 chars) → Submit fails ✅
- [ ] **Section 5, Q3**: Type short text → Submit fails ✅
- [ ] Type 50+ characters → Submit succeeds ✅

### Test Conditional Field Validation

- [ ] **Section 3, Q1**: Select "Yes", leave follow-up blank → Submit fails ✅
- [ ] **Section 4**: Check all attestations, select TRMS "Yes", leave number blank → Submit fails ✅

---

## 🧪 Test 5: Access Control

### Assignee Can Edit Sections 3-4

- [ ] **As Sarah Mitchell** (assignee)
- [ ] Section 3 is editable ✅
- [ ] Section 4 is editable ✅
- [ ] Section 5 is read-only ✅

### Sales Owner Can Edit Section 5

- [ ] **As David Park** (Sales Owner)
- [ ] Sections 2-4 are read-only ✅
- [ ] Section 5 is editable ✅

### Different Analyst Cannot Edit

- [ ] **Switch to Michael Chen** (different analyst)
- [ ] Go to "Case Worklist"
- [ ] Find case `312-2025-001`
- [ ] Click "View Details"
- [ ] All sections are read-only ✅
- [ ] NO Save or Submit buttons ✅

### View-Only User

- [ ] **Switch to Robert Anderson** (View Only role)
- [ ] All sections read-only ✅
- [ ] All buttons disabled or hidden ✅

---

## 🧪 Test 6: Save & Resume

- [ ] **As Sarah Mitchell**: Open Section 3
- [ ] Fill Q1 and Q2 only
- [ ] Click **"Save Progress"** → Toast confirms ✅
- [ ] Click **"Back to Worklist"**
- [ ] Navigate to Dashboard (or elsewhere)
- [ ] Return to "My Cases" → Click "View Details"
- [ ] Expand Section 3
- [ ] Q1 and Q2 still have your answers ✅
- [ ] Q3 and Q4 are blank (as expected) ✅

---

## 🧪 Test 7: Complete Workflow

### Step 1: AML Analyst Completes 312 Review

- [ ] **As Sarah Mitchell**
- [ ] Complete Section 3 (all questions)
- [ ] Submit Section 3
- [ ] "Submitted" badge appears ✅

### Step 2: AML Analyst Completes CAM Review

- [ ] Complete Section 4 (all questions + tabs reviewed)
- [ ] Submit Section 4
- [ ] "Submitted" badge appears ✅
- [ ] Case status may update to "Pending Sales Review" ✅

### Step 3: Sales Owner Reviews

- [ ] **Switch to David Park**
- [ ] Case appears in "Sales Owner Worklist" ✅
- [ ] Status shows "Pending Sales Review" or "In Sales Review" ✅
- [ ] Click "View" → Sections 3-4 are read-only ✅
- [ ] Can read Sarah's 312 and CAM responses ✅
- [ ] Complete Section 5 (Sales Owner Review) ✅
- [ ] Submit Section 5 ✅

### Step 4: Verify Final State

- [ ] **As Sarah Mitchell**
- [ ] Return to case
- [ ] All sections show "Submitted" badges ✅
- [ ] Can read David's sales owner responses in Section 5 ✅
- [ ] Case status shows "Sales Review Complete" ✅

---

## 🧪 Test 8: UI/UX Elements

### Visual Elements

- [ ] **Numbered badges** (1-4) render correctly ✅
- [ ] **"Submitted" badges** show green with lock icon ✅
- [ ] **"Sales Owner Access"** badge shows purple with shield ✅
- [ ] **"View Only"** badge shows gray ✅
- [ ] Toast notifications appear bottom-right ✅
- [ ] Toast auto-dismisses after ~3 seconds ✅

### Form Controls

- [ ] Dropdowns show all options ✅
- [ ] Radio buttons are mutually exclusive ✅
- [ ] Checkboxes toggle independently ✅
- [ ] Text areas expand to fit content ✅
- [ ] Buttons have hover states ✅

### Responsive Behavior

- [ ] Resize browser window ✅
- [ ] Grids adjust (3 cols → 2 cols → 1 col) ✅
- [ ] Tables scroll horizontally on narrow screens ✅
- [ ] Buttons stack on mobile ✅

---

## 🧪 Test 9: Sales Owner Worklist Features

### As David Park

- [ ] Go to **"Sales Owner Worklist"**
- [ ] See **19 cases** (all with David as sales owner) ✅
- [ ] Case `312-2025-001` is in the list ✅

### Filters

- [ ] **Status filter**: Select "Pending Sales Review" ✅
- [ ] **Risk filter**: Select "High" ✅
- [ ] **LOB filter**: Select "GB/GM" ✅
- [ ] **Central Team Contact filter**: Select "Sarah Mitchell" ✅
- [ ] Filters combine correctly ✅

### Sorting

- [ ] Click **"Case Number"** header → Sort asc/desc ✅
- [ ] Click **"Client Name"** header → Sort asc/desc ✅
- [ ] Click **"Status"** header → Sort alphabetically ✅
- [ ] Click **"Due Date"** header → Sort chronologically ✅

### Search

- [ ] Type **"GlobalTech"** → Case appears ✅
- [ ] Type **"312-2025-001"** → Case appears ✅
- [ ] Type **"GCI-892341"** → Case appears ✅

### Quick Stats Cards

- [ ] **Total My Cases** count is correct ✅
- [ ] **Pending My Review** count is correct ✅
- [ ] **In Review** count is correct ✅
- [ ] **Overdue** count is correct ✅

---

## 🧪 Test 10: Edge Cases

### Rapid Clicking

- [ ] Fill Section 3
- [ ] Click "Submit" button **5 times rapidly**
- [ ] Only ONE submission occurs ✅
- [ ] No duplicate toasts ✅

### Empty Text Areas

- [ ] Select answer that shows text area
- [ ] Enter only **spaces** (no real text)
- [ ] Try to submit
- [ ] Validation fails (whitespace trimmed) ✅

### Cancel Changes

- [ ] Make changes to Section 3
- [ ] Click **"Cancel"** button
- [ ] Confirmation dialog appears ✅
- [ ] Click "Discard"
- [ ] Returns to worklist ✅
- [ ] Changes NOT saved ✅

---

## 📊 Expected Results Summary

| Test | Expected Result | Pass/Fail |
|------|----------------|-----------|
| Sections 3-4 visible | ✅ All 4 badges appear | ☐ |
| Section 3 editable | ✅ For Sarah Mitchell only | ☐ |
| Section 4 editable | ✅ For Sarah Mitchell only | ☐ |
| Section 5 editable | ✅ For David Park only | ☐ |
| Conditional fields | ✅ Show/hide correctly | ☐ |
| Save Progress | ✅ Toast + data persists | ☐ |
| Submit validation | ✅ Prevents incomplete | ☐ |
| Read-only after submit | ✅ Fields locked | ☐ |
| Access control | ✅ Role-based | ☐ |
| Sales Owner Worklist | ✅ Shows David's cases | ☐ |

---

## 🚨 Known Limitations (Expected Behavior)

- **No backend**: Changes don't persist after browser refresh (demo mode)
- **Mock data**: All data is client-side, no real API calls
- **Email notifications**: Not implemented (UI only)
- **Audit trail**: Activity log is static mock data

---

## 🎯 Critical Path Test (5 Minutes)

If you only have 5 minutes, test this sequence:

1. [ ] **As Sarah Mitchell** → My Cases → Case 312-2025-001 → View Details
2. [ ] **Verify**: All 4 badges visible ✅
3. [ ] **Section 3**: Expand, fill Q1-Q4, Submit ✅
4. [ ] **Section 4**: Expand, review tabs, fill questions, Submit ✅
5. [ ] **Switch to David Park** → Sales Owner Worklist
6. [ ] **Verify**: Case appears in list ✅
7. [ ] **Open case** → Section 5 is editable (purple badge) ✅
8. [ ] **Fill Section 5**, Submit ✅
9. [ ] **Switch back to Sarah** → View case → See David's responses ✅

**If all 9 steps pass**, the core functionality is working! 🎉

---

**Last Updated**: October 27, 2025  
**Version**: 3.0 (After Sales Owner Worklist fix)
