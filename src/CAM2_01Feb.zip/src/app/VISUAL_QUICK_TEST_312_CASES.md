# Visual Quick Test - 312 CAM Workflow Cases

## How to Find and View the Test Cases

### **Step 1: Launch the Application**

When you open the app, you'll see:
- **Left sidebar** with navigation menu
- **Top right corner** with a user selector dropdown showing "Sarah Mitchell" by default

---

### **Step 2: Switch to Michael Chen**

To see case **312-2025-PROG-300**:

1. **Look at the top right of the screen** (header area)
2. You'll see a **user selector dropdown** with an avatar and name
3. **Click on it** to open the dropdown
4. **Select "Michael Chen"** from the list
   - Avatar: MC
   - Role: Central Team Analyst

---

### **Step 3: Navigate to "My Cases"**

1. Once switched to Michael Chen, look at the **left sidebar**
2. Click on **"My Cases"** (second menu item, with a briefcase icon)
   - This is Michael Chen's Individual Worklist

---

### **Step 4: Find the Case**

You should now see a list of cases assigned to Michael Chen, including:

| Case ID | Client Name | Status | Risk | Priority |
|---------|-------------|--------|------|----------|
| **312-2025-PROG-300** | Premier Trading Partners LLC | In Progress | High | High |

**If you don't see it:**
- Check the search box and make sure it's empty
- Check the filters (Status, Risk, LOB) - set them all to "All"
- Scroll through the list

---

### **Step 5: Open the Case**

1. **Click on case 312-2025-PROG-300** in the table
2. The case details will open

---

## What You Should See in Case 312-2025-PROG-300

### **Case Banner (Top Section)**
✅ **Case ID**: 312-2025-PROG-300  
✅ **Status Badge**: "In Progress" (blue)  
✅ **Risk Level**: High (red badge)  
✅ **Client Name**: Premier Trading Partners LLC  
✅ **Assigned To**: Michael Chen  

### **Section 1: 312 Case**
✅ **Status**: In Progress  
✅ **Model Result**: High Risk  
✅ **Model Result Description**: "Significant deviation from expected activity - detailed review required"  
✅ **Expected Activity - Volume**: Electronic Transfers (320), Cash/Checks (92)  
✅ **Expected Activity - Value**: Shows dollar amounts  
✅ **Source of Funds**: "International commodity trading and brokerage commissions"  

### **Section 3: Monitoring Dashboard**
✅ **TRMS FLU Monitoring**: Shows 1 entry (TRMS-FLU-8901)  
✅ **Alert 312 Details**: Shows alert for volume anomaly  
✅ **LOB Monitoring Controls**: Shows quarterly reviews  

---

## All 10 Test Cases - Quick Reference

Here's where to find ALL the workflow test cases:

### Auto-Closed Case
**Case ID**: `312-2025-AUTO-100`  
**Where**: Workbasket (or search anywhere)  
**User**: Any  
**Status**: Complete (Auto-Closed)

### Unassigned Case  
**Case ID**: `312-2025-UNASSIGN-200`  
**Where**: Workbasket  
**User**: Any (shows as Unassigned)  
**Status**: Unassigned

### In Progress Case ⭐ 
**Case ID**: `312-2025-PROG-300`  
**Where**: My Cases (Michael Chen's worklist)  
**User**: **Switch to Michael Chen** ← YOU ARE HERE  
**Status**: In Progress

### Pending Sales Review
**Case ID**: `312-2025-PSR-400`  
**Where**: My Cases (Jennifer Wu's worklist) OR Sales Owner Worklist (David Park)  
**User**: Switch to **Jennifer Wu** or **David Park**  
**Status**: Pending Sales Review

### In Sales Review
**Case ID**: `312-2025-ISR-500`  
**Where**: My Cases (Michael Chen) OR Sales Owner Worklist (David Park)  
**User**: Switch to **David Park** (Sales Owner) to see sales view  
**Status**: In Sales Review

### Sales Review Complete
**Case ID**: `312-2025-SRC-600`  
**Where**: My Cases (Jennifer Wu's worklist)  
**User**: Switch to **Jennifer Wu**  
**Status**: Sales Review Complete

### Complete - No Escalation
**Case ID**: `312-2025-COMP-700`  
**Where**: Workbasket or My Cases  
**User**: Any  
**Status**: Complete

### Complete - TRMS Filed
**Case ID**: `312-2025-ESC-800`  
**Where**: Workbasket (search for it)  
**User**: Any  
**Status**: Complete (shows TRMS case details)

### Complete - Client Closed
**Case ID**: `312-2025-ESC-900`  
**Where**: Workbasket (search for it)  
**User**: Any  
**Status**: Complete (shows exit information)

### Defect Remediation
**Case ID**: `312-2025-REM-1000`  
**Where**: My Cases (Jennifer Wu's worklist)  
**User**: Switch to **Jennifer Wu**  
**Status**: Defect Remediation

---

## Pro Tips for Testing

### Tip 1: Use the Search Function
- There's a **search box** at the top of the worklist
- Type the case ID (e.g., "312-2025-PROG-300")
- Case will appear immediately

### Tip 2: Check Your Filters
If cases are missing, check these filters:
- **Status**: Set to "All"
- **Risk Level**: Set to "All"  
- **Line of Business**: Set to "All"

### Tip 3: Understanding "My Cases" vs "Workbasket"
- **My Cases** = Cases assigned **to you specifically**
- **Case Worklist** = All cases in the system (shared workbasket)

### Tip 4: User Assignment Mapping
```
Michael Chen    → Cases: 312-2025-PROG-300, 312-2025-ISR-500
Jennifer Wu     → Cases: 312-2025-PSR-400, 312-2025-SRC-600, 312-2025-REM-1000
Sarah Mitchell  → Cases: 312-2025-ESC-800
Carlos Rivera   → Cases: 312-2025-ESC-900
David Park      → All sales review cases (as Sales Owner)
```

---

## Troubleshooting

### "I switched to Michael Chen but don't see any cases"

**Solution**: 
1. Make sure you clicked **"My Cases"** in the sidebar (not "Case Worklist")
2. Check that filters are set to "All"
3. Try typing "312-2025-PROG-300" in the search box

### "The user dropdown doesn't show Michael Chen"

**Solution**:
- Look for avatar **"MC"** in the dropdown
- Full name: "Michael Chen"
- Role should say: "Central Team Analyst"

### "Case shows in list but I can't open it"

**Solution**:
- Click directly on the **case ID** or **client name** in the table
- The row should be clickable

### "I see the case but some sections are empty"

**Solution**:
- This is normal! Not all cases have all data
- Check the **312 Case** section first - this should always have data
- The **Monitoring Dashboard** appears for cases with monitoring data

---

## Quick Navigation Shortcuts

| Goal | Steps |
|------|-------|
| **View any case** | 1. Go to Case Worklist<br>2. Use search box<br>3. Type case ID |
| **View assigned cases** | 1. Switch to the user<br>2. Click "My Cases" |
| **View sales cases** | 1. Switch to David Park or Amanda Torres<br>2. Will see special Sales Owner menu |
| **View all unassigned** | 1. Stay as Manager (Sarah Mitchell)<br>2. Go to "Case Worklist"<br>3. Filter by Status = "Unassigned" |

---

## Expected Case Counts by User

| User | Role | # of Cases in "My Cases" |
|------|------|--------------------------|
| Sarah Mitchell | Central Team Manager | ~3-5 cases |
| Michael Chen | Central Team Analyst | **2 cases (including 312-2025-PROG-300)** |
| Jennifer Wu | Central Team Analyst | **3 cases** |
| David Park | Sales Owner | Sales review cases only |
| Amanda Torres | Sales Owner | Sales review cases only |

---

## Success Checklist

✅ I can see the user selector in the top right  
✅ I can switch to Michael Chen  
✅ I can navigate to "My Cases"  
✅ I can see case 312-2025-PROG-300 in the list  
✅ I can click on the case to open it  
✅ I can see the 312 Case section with data  
✅ I can see the Monitoring Dashboard section  
✅ The case shows "In Progress" status  

---

## Next Steps

Once you can see case **312-2025-PROG-300**, try these:

1. **Switch to Jennifer Wu** → See cases 312-2025-PSR-400 and 312-2025-SRC-600
2. **Switch to David Park** → See Sales Owner Worklist view
3. **Go to Case Worklist** → See all cases including unassigned
4. **Use search** → Find any case by typing its ID

---

**Still having issues?**

Check these files:
- `/QUICK_USER_SWITCH_GUIDE.md` - Detailed user switching guide
- `/312_CAM_WORKFLOW_TESTING_GUIDE.md` - Full testing procedures
- `/312_CAM_WORKFLOW_DEMO.md` - Case descriptions and data structure

**Last Updated**: November 1, 2025
