# 312 CAM Workflow Testing - Quick Start Guide

## 🎯 What You Need to Know

This guide gets you testing the 312 CAM workflow in **under 5 minutes**.

---

## ⚡ Super Quick Start (60 Seconds)

### 1. View the Visual Diagram
```
1. Open the CAM Platform
2. Click "Workflow Diagram" in the left sidebar
3. Browse the three tabs to see all workflows
```

### 2. Test Your First Case
```
1. Click user selector (top right)
2. Select "Michael Chen"
3. Click "My Cases" in sidebar
4. Click case "312-2025-PROG-300"
5. ✅ You're viewing an In Progress case!
```

---

## 📊 The 10 Test Cases

| # | Case ID | Status | User | Where to Find |
|---|---------|--------|------|---------------|
| 1 | 312-2025-AUTO-100 | Auto-Closed | Any | Workbasket |
| 2 | 312-2025-UNASSIGN-200 | Unassigned | Any | Workbasket |
| 3 | 312-2025-PROG-300 | In Progress | **Michael Chen** | My Cases |
| 4 | 312-2025-PSR-400 | Pending Sales | **Jennifer Wu** | My Cases |
| 5 | 312-2025-ISR-500 | In Sales Review | **David Park** | Sales Worklist |
| 6 | 312-2025-SRC-600 | Sales Complete | **Jennifer Wu** | My Cases |
| 7 | 312-2025-COMP-700 | Complete | Any | Workbasket |
| 8 | 312-2025-ESC-800 | Complete (TRMS) | Any | Workbasket |
| 9 | 312-2025-ESC-900 | Complete (Closed) | Any | Workbasket |
| 10 | 312-2025-REM-1000 | Remediation | **Jennifer Wu** | My Cases |

---

## 🔄 The 3 Main Workflows

### Workflow 1: Auto-Close Path (30 seconds)
```
✅ View case 312-2025-AUTO-100
   → Look for "Auto-Closed" badge
   → Check assigned to "System"
   → See disposition: "No additional CAM escalation required"
```

### Workflow 2: Standard Manual Review (2 minutes)
```
Step 1: Switch to Michael Chen
Step 2: Go to "My Cases"
Step 3: Open 312-2025-PROG-300
Step 4: Review case sections:
   ✅ 312 Case section (with data)
   ✅ Monitoring Dashboard
   ✅ Status: In Progress
```

### Workflow 3: Sales Review Process (3 minutes)
```
Part A - Pending:
  1. Switch to Jennifer Wu
  2. Open 312-2025-PSR-400
  3. See: "Pending Sales Review" status

Part B - In Review:
  1. Switch to David Park (Sales Owner)
  2. Open 312-2025-ISR-500  
  3. See: Sales Owner view (privacy filtered)

Part C - Complete:
  1. Switch to Jennifer Wu
  2. Open 312-2025-SRC-600
  3. See: Sales feedback returned, locked
```

---

## 🎨 Visual Workflow Reference

### The Complete Flow
```
Create → Auto-Close ✅ DONE
         OR
Create → Unassigned → Assigned → In Progress
                                      ↓
                          ┌───────────┴───────────┐
                          ↓                       ↓
                   No Sales Needed      Need Sales Context
                          ↓                       ↓
                      Complete          Pending Sales Review
                                               ↓
                                        In Sales Review
                                               ↓
                                     Sales Review Complete
                                               ↓
                                          Complete
```

### Dispositions
```
Complete → No Escalation
           OR
Complete → TRMS Filed (creates TRMS case)
           OR
Complete → Client Closed (exits client)
```

---

## 🧪 Test Scenarios by Goal

### Test Auto-Close Logic
**Case:** 312-2025-AUTO-100  
**What to verify:** System auto-closes low-risk cases without analyst review

### Test Assignment Workflow
**Case:** 312-2025-UNASSIGN-200  
**What to verify:** Unassigned cases sit in workbasket awaiting assignment

### Test Active Review
**Case:** 312-2025-PROG-300  
**User:** Michael Chen  
**What to verify:** Analyst can review all case data and monitoring information

### Test Sales Review Request
**Case:** 312-2025-PSR-400  
**User:** Jennifer Wu  
**What to verify:** Case routed to sales, awaiting sales owner

### Test Sales Owner Experience
**Case:** 312-2025-ISR-500  
**User:** David Park  
**What to verify:** Sales owner sees filtered view, can provide context

### Test Sales Completion
**Case:** 312-2025-SRC-600  
**User:** Jennifer Wu  
**What to verify:** Sales feedback returned and locked, analyst can complete

### Test No Escalation
**Case:** 312-2025-COMP-700  
**What to verify:** Case completed with no further action needed

### Test TRMS Escalation
**Case:** 312-2025-ESC-800  
**What to verify:** Case shows TRMS case details, SAR recommendation

### Test Client Exit
**Case:** 312-2025-ESC-900  
**What to verify:** Client closure data, exit date, SAR filing info

### Test Remediation
**Case:** 312-2025-REM-1000  
**User:** Jennifer Wu (needs M&I entitlement)  
**What to verify:** Original completion date preserved, remediation notes

---

## 🔑 Key User Switches

### To Test Analyst Workflows
```
Switch to: Michael Chen or Jennifer Wu
Access: My Cases
Can See: Cases assigned to them
```

### To Test Sales Owner Workflows
```
Switch to: David Park or Amanda Torres
Access: Special "Sales Owner Worklist" appears in menu
Can See: Cases in sales review states
```

### To Test Manager Workflows
```
Switch to: Sarah Mitchell or Carlos Rivera
Access: Case Worklist (full workbasket)
Can Do: Assign/reassign cases, reopen completed cases
```

---

## ✅ Success Checklist

After testing, you should be able to answer YES to all:

- [ ] I can switch between users using the top-right selector
- [ ] I can navigate to "My Cases" and "Case Worklist"
- [ ] I can find case 312-2025-PROG-300 when logged in as Michael Chen
- [ ] I can see the difference between "Pending Sales Review" and "In Sales Review"
- [ ] I understand what data Sales Owners can and cannot see
- [ ] I can identify the 4 main disposition outcomes
- [ ] I know the difference between Auto-Closed and manually completed cases
- [ ] I can see the Workflow Diagram and understand the three tabs
- [ ] I know where to find unassigned cases (Workbasket)
- [ ] I understand the remediation workflow preserves original completion dates

---

## 🚨 Troubleshooting

### Problem: "I can't see case 312-2025-PROG-300"
**Solution:**
1. Make sure you switched to **Michael Chen** (not Sarah Mitchell)
2. Click **"My Cases"** (not "Case Worklist")
3. Clear any filters (set Status, Risk, LOB to "All")
4. Try searching for "312-2025-PROG-300" in the search box

### Problem: "I don't see Sales Owner Worklist"
**Solution:**
1. Switch to a Sales Owner persona (David Park or Amanda Torres)
2. The menu will show "My Cases" but it will be the Sales Owner view
3. Regular analysts and managers don't see this menu item

### Problem: "Case shows different data than expected"
**Solution:**
1. Check which user you're logged in as (top right)
2. Different roles see different data (privacy filtering)
3. Sales Owners have restricted view compared to Analysts

### Problem: "I can't find unassigned cases"
**Solution:**
1. Go to **"Case Worklist"** (not "My Cases")
2. Set Status filter to "Unassigned"
3. Or search for case ID: "312-2025-UNASSIGN-200"

---

## 📚 Documentation Reference

| Document | Purpose | When to Use |
|----------|---------|-------------|
| **WORKFLOW_DIAGRAM_GUIDE.md** | How to use the visual diagram | Learning the workflow visually |
| **312_CAM_WORKFLOW_TESTING_GUIDE.md** | Detailed test procedures | Step-by-step testing |
| **VISUAL_QUICK_TEST_312_CASES.md** | Quick visual guide | Finding specific cases |
| **WORKFLOW_VISUAL_REFERENCE.md** | ASCII flow diagrams | Text-based workflow reference |
| **312_CAM_WORKFLOW_DEMO.md** | Complete case specifications | Understanding test data |
| **OFFICIAL_CASE_WORKFLOW.md** | Business rules and logic | Understanding workflow rules |

---

## 🎓 Learning Path

### Beginner (30 minutes)
1. ✅ Read this Quick Start guide
2. ✅ View the Workflow Diagram in the app (all 3 tabs)
3. ✅ Test cases 1, 2, 3 (auto-close, unassigned, in progress)
4. ✅ Switch between 2-3 users to see different views

### Intermediate (1 hour)
1. ✅ Test all 10 workflow cases
2. ✅ Switch between all user personas
3. ✅ Compare what different roles can see
4. ✅ Read VISUAL_QUICK_TEST_312_CASES.md

### Advanced (2 hours)
1. ✅ Read 312_CAM_WORKFLOW_TESTING_GUIDE.md (full)
2. ✅ Test complete sales review workflow end-to-end
3. ✅ Test remediation workflow
4. ✅ Read OFFICIAL_CASE_WORKFLOW.md for business rules
5. ✅ Review DATA_VISIBILITY_MATRIX.md for permissions

---

## 💡 Pro Tips

### Tip 1: Use the Search Box
Type case ID directly instead of scrolling through lists

### Tip 2: Check Filters
If cases are missing, filters might be hiding them (set to "All")

### Tip 3: Note the User
Always check who you're logged in as (top right corner)

### Tip 4: Use the Workflow Diagram
Keep it open in a separate tab as reference while testing

### Tip 5: Test Methodically
Go through test cases in order (1-10) to see progression

---

## 🎯 Next Steps

After completing this quick start:

1. **Explore Other Features**
   - Dashboard
   - Reports (AKRIT Data Extract, Delinquency Report)
   - Email Notifications
   - Population Identification

2. **Deep Dive into Workflows**
   - Read the complete testing guide
   - Test edge cases (LOB restrictions, permission limits)
   - Review the Status Transition Matrix

3. **Share Knowledge**
   - Train team members using the Workflow Diagram
   - Reference documentation for questions
   - Provide feedback for improvements

---

## 📞 Getting Help

**If you're stuck:**
1. Check the Troubleshooting section above
2. Review the Workflow Diagram in the app
3. Consult VISUAL_QUICK_TEST_312_CASES.md
4. Read the detailed testing guide

**Documentation Questions:**
- See START_HERE.md for overall platform guide
- See COMPLETE_CASE_UI_GUIDE.md for case details UI

**Workflow Questions:**
- See OFFICIAL_CASE_WORKFLOW.md for business rules
- See STATUS_TRANSITION_MATRIX.md for valid transitions

---

## ⏱️ Time Estimates

| Task | Time |
|------|------|
| View Workflow Diagram | 5 min |
| Test 1 case | 2 min |
| Test all 10 cases | 20 min |
| Test sales workflow end-to-end | 10 min |
| Switch between all users | 5 min |
| Read this guide | 10 min |
| **Total Quick Start** | **~50 min** |

---

**Ready to start?**

1. 🚀 Open the CAM Platform
2. 👀 Click "Workflow Diagram"
3. 🧪 Switch to Michael Chen
4. ✅ Open case 312-2025-PROG-300

**You're now testing the 312 CAM workflow!**

---

**Last Updated:** November 3, 2025  
**Version:** 1.0  
**Maintained By:** CAM Platform Development Team
