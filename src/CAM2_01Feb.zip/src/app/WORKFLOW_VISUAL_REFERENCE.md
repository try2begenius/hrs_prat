# 312 CAM Workflow - Visual ASCII Reference

This document provides a quick text-based visual reference of the complete 312 CAM workflow.

---

## Complete 312 Case Workflow

```
┌─────────────────────────────────────┐
│   312 Population Identified         │
└─────────────────┬───────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│         Case Created                │
└─────────────────┬───────────────────┘
                  │
                  ▼
        ┌─────────────────┐
        │  Decision Point  │
        │  Model Evaluates │
        │   Risk Level     │
        └────┬────────┬────┘
             │        │
    ┌────────┘        └────────┐
    │                          │
    ▼                          ▼
┌─────────────┐         ┌──────────────────┐
│  Low Risk   │         │ Medium/High/     │
│             │         │ Critical Risk    │
└──────┬──────┘         └────────┬─────────┘
       │                         │
       ▼                         ▼
┌─────────────┐         ┌──────────────────┐
│ Auto-Closed │         │   Unassigned     │
│ (Complete)  │         │  (Workbasket)    │
└─────────────┘         └────────┬─────────┘
                                 │
                                 ▼
                        ┌──────────────────┐
                        │  Manager Assigns │
                        │    to Analyst    │
                        └────────┬─────────┘
                                 │
                                 ▼
                        ┌──────────────────┐
                        │   In Progress    │
                        │ Analyst Reviews  │
                        └────────┬─────────┘
                                 │
                   ┌─────────────┴─────────────┐
                   │                           │
                   ▼                           ▼
          ┌──────────────┐          ┌──────────────────┐
          │ No Sales     │          │  Sales Input     │
          │ Input Needed │          │    Needed        │
          └──────┬───────┘          └────────┬─────────┘
                 │                           │
                 │                           ▼
                 │              ┌─────────────────────────┐
                 │              │  Pending Sales Review   │
                 │              └────────┬────────────────┘
                 │                       │
                 │                       ▼
                 │              ┌─────────────────────────┐
                 │              │   In Sales Review       │
                 │              │ Sales Owner Provides    │
                 │              │      Context            │
                 │              └────────┬────────────────┘
                 │                       │
                 │                       ▼
                 │              ┌─────────────────────────┐
                 │              │ Sales Review Complete   │
                 │              │   Returns to Analyst    │
                 │              └────────┬────────────────┘
                 │                       │
                 └───────────┬───────────┘
                             │
                             ▼
                   ┌──────────────────┐
                   │ Analyst Makes    │
                   │  Disposition     │
                   └────────┬─────────┘
                            │
         ┌──────────────────┼──────────────────┐
         │                  │                  │
         ▼                  ▼                  ▼
┌────────────────┐ ┌────────────────┐ ┌────────────────┐
│ No Escalation  │ │  TRMS Filed    │ │ Client Closed  │
│   (Complete)   │ │  (Complete)    │ │  (Complete)    │
└────────────────┘ └────────────────┘ └────────────────┘
```

---

## Path 1: Auto-Close (Green Path)

```
312 Case Created
       │
       ▼
┌──────────────┐
│  Low Risk    │ ← Model Result: Low Risk
│  Activity    │   Activity in line with expected
│  Aligned     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Auto-Closed  │ ✅ Assigned to: System
│  (Complete)  │ ✅ No analyst review needed
└──────────────┘

Test Case: 312-2025-AUTO-100
Client: Reliable Logistics Corp
```

---

## Path 2: Manual Review (Blue Path)

```
312 Case Created
       │
       ▼
┌────────────────┐
│ Medium/High/   │ ← Model Result: Requires review
│ Critical Risk  │
└────────┬───────┘
         │
         ▼
┌────────────────┐
│  Unassigned    │ 🔵 Status: Unassigned
│ In Workbasket  │    Awaiting assignment
└────────┬───────┘
         │
         ▼
┌────────────────┐
│ Manager Assigns│ 👤 Manager action required
│   to Analyst   │
└────────┬───────┘
         │
         ▼
┌────────────────┐
│  In Progress   │ 🔵 Status: In Progress
│ Analyst Reviews│    Assigned to analyst
└────────────────┘

Test Cases: 
- 312-2025-UNASSIGN-200 (Unassigned)
- 312-2025-PROG-300 (In Progress)
```

---

## Path 2A: Direct Completion (Purple Path)

```
Case In Progress
       │
       ▼
┌────────────────────┐
│ Analyst has enough │
│ information to     │
│ complete review    │
└────────┬───────────┘
         │
         ▼
┌────────────────────┐
│ Analyst Completes  │ 🟣 No sales input needed
│   Disposition      │
└────────┬───────────┘
         │
    ┌────┴────┬───────────┬──────────┐
    │         │           │          │
    ▼         ▼           ▼          ▼
┌────────┐ ┌──────┐ ┌─────────┐ ┌────────┐
│   No   │ │ CAM  │ │  TRMS   │ │Client  │
│ Escal. │ │Review│ │ Filed   │ │Closed  │
└────────┘ └──────┘ └─────────┘ └────────┘

Test Cases:
- 312-2025-COMP-700 (No Escalation)
- 312-2025-ESC-800 (TRMS Filed)
- 312-2025-ESC-900 (Client Closed)
```

---

## Path 2B: Sales Review (Orange Path)

```
Case In Progress
       │
       ▼
┌─────────────────────────┐
│ Analyst needs sales     │
│ business context        │
│                         │
│ ✅ LOB: GB/GM, PB, ML   │
│ ❌ NOT: Consumer, CI    │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Click "Request Sales   │ 📧 Email sent to Sales Owner
│       Review"           │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Pending Sales Review    │ 🟠 Status: Pending Sales Review
│  (Awaiting Sales Owner) │    Case in Sales Owner Worklist
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Sales Owner Opens Case  │ 🟠 Status: In Sales Review
│  (Automatically changes │    Privacy-filtered view
│       status)           │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Sales Owner Provides    │ 💬 Business context added
│   Feedback & Context    │    Character limit: 4000
│                         │
│ • Save Draft (temp)     │
│ • Return to Processor   │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Sales Review Complete   │ 🟢 Status: Sales Review Complete
│  Returns to Analyst     │ 📧 Email to Analyst
│  (Locked response)      │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Analyst Reviews Sales   │ 👤 Analyst action
│  Feedback & Completes   │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│      Complete           │ ✅ Case closed with disposition
└─────────────────────────┘

Test Cases:
- 312-2025-PSR-400 (Pending Sales Review)
- 312-2025-ISR-500 (In Sales Review)  
- 312-2025-SRC-600 (Sales Review Complete)
```

---

## Special Path: Defect Remediation (Red Path)

```
┌─────────────────────────┐
│  Case Complete          │ ✅ Status: Complete
│  (Original completion   │    Completion date preserved
│      2025-10-08)        │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  M&I Quality Review     │ 🔍 Management & Independent Review
│  Identifies Defect      │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Case Reopened          │ 🔴 Status: Defect Remediation
│ Defect Remediation      │ 🔒 Requires M&I entitlement
│  (Original completion   │    Original data preserved
│   date maintained)      │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Analyst Addresses       │ 📝 Remediation notes added
│ Quality Findings        │    Additional documentation
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  Re-Completed           │ ✅ Status: Complete
│ (Remediation done)      │    Returns to Complete status
└─────────────────────────┘

Test Case: 312-2025-REM-1000
Client: Pacific Rim Imports Inc
```

---

## Status Progression Summary

### Linear Progression (No Sales Review)
```
Unassigned → In Progress → Complete
```

### With Sales Review
```
Unassigned → In Progress → Pending Sales Review → 
In Sales Review → Sales Review Complete → Complete
```

### Auto-Close
```
Created → Auto-Closed (Complete)
```

### Remediation
```
Complete → Defect Remediation → Complete
```

---

## Disposition Outcomes

```
                    ┌─────────────────┐
                    │  312 Case       │
                    │   Complete      │
                    └────────┬────────┘
                             │
         ┌───────────────────┼───────────────────┐
         │                   │                   │
         ▼                   ▼                   ▼
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│ No Additional   │  │   TRMS Filed    │  │  Client Closed  │
│ CAM Escalation  │  │                 │  │                 │
│                 │  │ Creates:        │  │ Creates:        │
│ ✅ No CAM Case  │  │ • TRMS Case     │  │ • Exit Record   │
│                 │  │ • SAR (maybe)   │  │ • SAR (maybe)   │
└─────────────────┘  └─────────────────┘  └─────────────────┘
        │                    │                     │
        ▼                    ▼                     ▼
     [END]              [TRMS OPEN]          [CLIENT EXITED]
```

---

## User Persona Workflow Views

### Central Team Analyst View
```
My Cases (Individual Worklist)
  ├─ In Progress (assigned to me)
  ├─ Sales Review Complete (returned to me)
  └─ Defect Remediation (if M&I entitlement)

Actions Available:
  ✅ Review case data
  ✅ Request sales review (if eligible LOB)
  ✅ Complete disposition
  ❌ Assign/reassign cases
  ❌ Reopen completed cases
```

### Central Team Manager View
```
Case Worklist (Workbasket)
  ├─ Unassigned (ready for assignment)
  ├─ In Progress (all analysts)
  └─ All statuses (full visibility)

My Cases (Individual Worklist)
  ├─ Cases assigned to me personally
  └─ Same as analyst view when working cases

Actions Available:
  ✅ All analyst actions PLUS:
  ✅ Assign cases to analysts
  ✅ Reassign cases
  ✅ Reopen completed cases (remediation)
  ✅ Abandon cases
```

### Sales Owner View
```
Sales Owner Worklist (Special view)
  ├─ Pending Sales Review (not yet opened)
  ├─ In Sales Review (currently working)
  └─ Sales Review Complete (submitted)

Data Visibility:
  ✅ Case details
  ✅ 312 case info (filtered)
  ✅ Expected activity
  ✅ Processor comments
  ❌ Transaction details (privacy)
  ❌ Monitoring alerts (privacy)

Actions Available:
  ✅ View case
  ✅ Add sales context
  ✅ Save draft
  ✅ Return to AML processor
  ❌ Cannot action case
  ❌ Cannot change disposition
```

---

## Email Notifications Flow

```
Case Event                    →  Email Sent To              →  Subject
─────────────────────────────────────────────────────────────────────────────
Case Created & Assigned      →  Assigned Analyst           →  New 312 Case
Sales Review Requested        →  Sales Owner                →  Sales Review Required
Sales Review Opened           →  Requesting Analyst         →  Sales Review In Progress
Sales Feedback Submitted      →  Requesting Analyst         →  Sales Review Complete
Case Completed                →  Manager, Analyst           →  Case Complete
Case Reopened (Remediation)   →  Assigned Analyst, Manager  →  Case Reopened
```

---

## LOB Restrictions for Sales Review

```
┌─────────────────┬───────────────────┬─────────────────────┐
│ Line of Business│ Can Route to Sales│ Notes               │
├─────────────────┼───────────────────┼─────────────────────┤
│ GB/GM           │       ✅ YES      │ Global Banking      │
│ PB              │       ✅ YES      │ Private Banking     │
│ ML              │       ✅ YES      │ Merrill Lynch       │
│ Consumer        │       ❌ NO       │ Not permitted       │
│ CI              │       ❌ NO       │ Not permitted       │
└─────────────────┴───────────────────┴─────────────────────┘
```

---

## Quick Reference: Case IDs by Workflow State

```
Auto-Closed:           312-2025-AUTO-100
Unassigned:            312-2025-UNASSIGN-200
In Progress:           312-2025-PROG-300
Pending Sales:         312-2025-PSR-400
In Sales Review:       312-2025-ISR-500
Sales Complete:        312-2025-SRC-600
Complete (No Escal):   312-2025-COMP-700
Complete (TRMS):       312-2025-ESC-800
Complete (Closed):     312-2025-ESC-900
Defect Remediation:    312-2025-REM-1000
```

---

## Decision Trees

### Should I Route to Sales?

```
                    Start
                      │
                      ▼
              ┌──────────────┐
              │ Is LOB GB/GM,│
              │   PB, or ML? │
              └───┬──────┬───┘
                  │      │
             YES  │      │ NO
                  │      │
                  ▼      ▼
          ┌──────────┐  ❌ Cannot route
          │ Do I need│     to sales
          │ business │
          │ context? │
          └───┬──────┘
              │
         YES  │
              │
              ▼
        ✅ Route to Sales
           Review
```

### What Disposition Should I Choose?

```
                    Start
                      │
                      ▼
          ┌───────────────────┐
          │ Is activity       │
          │ aligned with DDQ? │
          └────┬──────────┬───┘
               │          │
          YES  │          │ NO
               │          │
               ▼          ▼
        ┌──────────┐  ┌──────────────┐
        │   No     │  │ Suspicious   │
        │Escalation│  │  Activity?   │
        └──────────┘  └───┬──────┬───┘
                          │      │
                     YES  │      │ NO
                          │      │
                          ▼      ▼
                  ┌──────────┐  ┌──────────┐
                  │   TRMS   │  │Enhanced  │
                  │  Filed   │  │Monitoring│
                  └──────────┘  │ (CAM)?   │
                                └──────────┘
```

---

## Time-Based View

### Typical Case Timeline

```
Day 0  │  Case Created
       │  Status: Unassigned
       │
Day 1  │  Manager Assigns to Analyst
       │  Status: In Progress
       │
Day 2-5│  Analyst Reviews Data
       │  • Checks monitoring alerts
       │  • Reviews transaction patterns
       │  • Analyzes risk indicators
       │
Day 6  │  Decision Point: Route to Sales?
       │  
       │  IF YES:
       │  Status: Pending Sales Review
       │
Day 7  │  Sales Owner Opens Case
       │  Status: In Sales Review
       │
Day 8-9│  Sales Owner Provides Context
       │
Day 10 │  Sales Submits Response
       │  Status: Sales Review Complete
       │
Day 11 │  Analyst Reviews Sales Feedback
       │  Makes Final Disposition
       │
Day 12 │  Case Completed
       │  Status: Complete
```

---

## System Integrations

```
CAM Platform
     │
     ├─→ Cesium (Client Data)
     │     └─→ Legal name, account info, ownership
     │
     ├─→ TRMS (Monitoring)
     │     └─→ FLU monitoring, investigation cases
     │
     ├─→ 312 Scoring Engine
     │     └─→ Risk model, expected activity
     │
     ├─→ DDQ System
     │     └─→ Due diligence questionnaire data
     │
     ├─→ Email System
     │     └─→ Notifications to users
     │
     └─→ SAR System
           └─→ Suspicious Activity Report filing
```

---

**Last Updated:** November 3, 2025  
**Version:** 1.0

For interactive visual diagram, navigate to **Workflow Diagram** in the CAM Platform application.
