import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Alert, AlertDescription } from "./ui/alert";
import { Separator } from "./ui/separator";
import { ArrowLeft, AlertCircle, DollarSign, Activity, FileText, MessageSquare, Clock, User, CheckCircle, Lock } from 'lucide-react';
import { mockCases, mockActivities, mockAlerts } from '../data/enhancedMockData';
import { CaseStatus, RiskLevel } from '../types';
import { UserAccess, getPermissionsForRole } from '../data/rolesEntitlementsMockData';

interface CaseDetailsProps {
  caseId: string;
  onBack: () => void;
  currentUser: UserAccess;
}

export function CaseDetails({ caseId, onBack, currentUser }: CaseDetailsProps) {
  const caseData = mockCases.find(c => c.id === caseId);
  const caseActivities = mockActivities.filter(a => a.caseId === caseId);
  const caseAlerts = mockAlerts.filter(a => a.caseId === caseId);
  const permissions = getPermissionsForRole(currentUser.role);

  const [newComment, setNewComment] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<CaseStatus>(caseData?.status || 'New');
  
  // Check if user has access to this case
  const hasAccess = caseData && (
    (caseData.caseType === 'CAM 312' && currentUser.entitlements.has312Access) ||
    (caseData.caseType === 'CAM' && currentUser.entitlements.hasCAMAccess)
  ) && currentUser.entitlements.lobs.includes(caseData.lob);

  if (!caseData || !hasAccess) {
    return (
      <div className="space-y-6">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Workbasket
        </Button>
        <Alert variant="destructive">
          <Lock className="h-4 w-4" />
          <AlertDescription>
            {!caseData ? 'Case not found' : 'You do not have access to this case. Check your entitlements.'}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const getRiskColor = (risk: RiskLevel) => {
    switch (risk) {
      case 'Critical': return 'text-red-600';
      case 'High': return 'text-orange-600';
      case 'Medium': return 'text-yellow-600';
      case 'Low': return 'text-green-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Workbasket
        </Button>
        <div className="flex gap-2">
          <Button variant="outline">Escalate</Button>
          <Button variant="outline">Assign</Button>
          <Button>Close Case</Button>
        </div>
      </div>

      {/* Case Header */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <CardTitle>{caseData.id}</CardTitle>
                <Badge variant={caseData.riskLevel === 'Critical' ? 'destructive' : 'default'}>
                  {caseData.riskLevel} Risk
                </Badge>
                <Badge variant="outline">{caseData.status}</Badge>
                <Badge variant="secondary">{caseData.priority} Priority</Badge>
              </div>
              <CardDescription className="text-base">{caseData.clientName}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">Client ID</div>
              <div className="font-mono">{caseData.clientId}</div>
            </div>
            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">Case Type</div>
              <div>{caseData.caseType}</div>
            </div>
            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">Assigned To</div>
              <div className="flex items-center gap-1">
                <User className="h-3 w-3" />
                {caseData.assignedTo}
              </div>
            </div>
            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">Due Date</div>
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {caseData.dueDate}
              </div>
            </div>
          </div>

          <Separator className="my-4" />

          <div className="grid gap-4 md:grid-cols-3">
            <div className="flex items-center gap-3 rounded-lg border p-3">
              <AlertCircle className="h-8 w-8 text-orange-500" />
              <div>
                <div className="text-2xl">{caseData.alertCount}</div>
                <div className="text-xs text-muted-foreground">Alerts Triggered</div>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-lg border p-3">
              <Activity className="h-8 w-8 text-primary" />
              <div>
                <div className="text-2xl">{caseData.transactionCount}</div>
                <div className="text-xs text-muted-foreground">Transactions</div>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-lg border p-3">
              <DollarSign className="h-8 w-8 text-green-500" />
              <div>
                <div className="text-2xl">${(caseData.totalAmount / 1000).toFixed(0)}K</div>
                <div className="text-xs text-muted-foreground">Total Amount</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="client-data">Client Data</TabsTrigger>
          <TabsTrigger value="alerts">Alerts ({caseAlerts.length})</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="activity">Activity History</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Case Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{caseData.description}</p>
            </CardContent>
          </Card>

          {/* Risk & Monitoring Summary */}
          {caseData.monitoringData && (
            <Card>
              <CardHeader>
                <CardTitle>Risk Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Dynamic Risk Rating</div>
                    <div className="flex items-center gap-2">
                      <div className="text-2xl">{caseData.monitoringData.dynamicRiskRating}</div>
                      <Badge variant="destructive">High Risk</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">Source: ORRCA</div>
                  </div>
                  {caseData.monitoringData.model312Flag && (
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">312 Model Score</div>
                      <div className="text-2xl">{caseData.monitoringData.model312Score}</div>
                      <div className="text-xs text-muted-foreground">312 Population Client</div>
                    </div>
                  )}
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Last Assessment</div>
                    <div>{caseData.monitoringData.riskRatingDate}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* SAR Information */}
          {caseData.sarData?.sarFiled && (
            <Card>
              <CardHeader>
                <CardTitle>SAR Filing Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">SAR ID</div>
                    <div className="font-mono">{caseData.sarData.sarId}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Filing Date</div>
                    <div>{caseData.sarData.sarFilingDate}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">SAR Type</div>
                    <Badge>{caseData.sarData.sarType}</Badge>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Amount</div>
                    <div>${caseData.sarData.sarAmount?.toLocaleString()}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Investigation Notes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder={permissions.actionCases ? "Add investigation notes..." : "View only - cannot add notes"}
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                rows={4}
                disabled={!permissions.actionCases}
              />
              <Button onClick={() => setNewComment('')} disabled={!permissions.actionCases}>
                <MessageSquare className="mr-2 h-4 w-4" />
                Add Note
                {!permissions.actionCases && <Lock className="ml-2 h-3 w-3" />}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Case Management</CardTitle>
              <CardDescription>
                {!permissions.actionCases && (
                  <span className="text-orange-600">View Only - No action permissions</span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm">Update Status</label>
                  <Select 
                    value={selectedStatus} 
                    onValueChange={(value) => setSelectedStatus(value as CaseStatus)}
                    disabled={!permissions.actionCases}
                  >
                    <SelectTrigger disabled={!permissions.actionCases}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="New">New</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Under Review">Under Review</SelectItem>
                      <SelectItem value="Escalated">Escalated</SelectItem>
                      <SelectItem value="Closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm">
                    Reassign Case
                    {!permissions.reassignCases && <Lock className="inline-block ml-1 h-3 w-3 text-muted-foreground" />}
                  </label>
                  <Select disabled={!permissions.reassignCases}>
                    <SelectTrigger disabled={!permissions.reassignCases}>
                      <SelectValue placeholder={permissions.reassignCases ? "Select analyst" : "No permission"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sarah">Sarah Mitchell</SelectItem>
                      <SelectItem value="james">James Chen</SelectItem>
                      <SelectItem value="emily">Emily Watson</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-2">
                <Button disabled={!permissions.actionCases}>
                  Save Changes
                  {!permissions.actionCases && <Lock className="ml-2 h-3 w-3" />}
                </Button>
                {currentUser.role === 'Sales Owner' && permissions.returnToAnalyst && (
                  <Button variant="outline">
                    Return to Analyst
                  </Button>
                )}
                {permissions.abandonCases && (
                  <Button variant="destructive">
                    Abandon Case
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="client-data" className="space-y-4">
          {caseData.clientData && (
            <Card>
              <CardHeader>
                <CardTitle>Client Information</CardTitle>
                <CardDescription>
                  Data Source: <Badge variant="outline">{caseData.clientData.dataSource}</Badge>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Legal Name</div>
                      <div>{caseData.clientData.legalName}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Client ID</div>
                      <div className="font-mono">{caseData.clientData.clientId}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">GCI Number</div>
                      <div className="font-mono">{caseData.clientData.gciNumber}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Client Type</div>
                      <Badge>{caseData.clientData.clientType}</Badge>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Line of Business</div>
                      <Badge variant="secondary">{caseData.clientData.lineOfBusiness}</Badge>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Sales Owner</div>
                      <div>{caseData.clientData.salesOwner}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Jurisdiction</div>
                      <div>{caseData.clientData.jurisdiction}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Account Open Date</div>
                      <div>{caseData.clientData.accountOpenDate}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {caseData.trmsCase && (
            <Card>
              <CardHeader>
                <CardTitle>TRMS Case Details</CardTitle>
                <CardDescription>Related Transaction Risk Management System case</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">TRMS Case ID</div>
                    <div className="font-mono">{caseData.trmsCase.caseId}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Case Type</div>
                    <div>{caseData.trmsCase.caseType}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Status</div>
                    <Badge>{caseData.trmsCase.status}</Badge>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Open Date</div>
                    <div>{caseData.trmsCase.openDate}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {caseData.alertData && (
            <Card>
              <CardHeader>
                <CardTitle>Alert Breakdown</CardTitle>
                <CardDescription>Alert distribution by type from Alert Management System</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <div className="text-sm text-muted-foreground">Sanctions</div>
                      <div className="text-2xl">{caseData.alertData.sanctionsAlerts}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <div className="text-sm text-muted-foreground">Fraud</div>
                      <div className="text-2xl">{caseData.alertData.fraudAlerts}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <div className="text-sm text-muted-foreground">Payment</div>
                      <div className="text-2xl">{caseData.alertData.paymentAlerts}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <div className="text-sm text-muted-foreground">AML</div>
                      <div className="text-2xl">{caseData.alertData.moneyLaunderingAlerts}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {caseData.monitoringData?.fluMonitoringStatus && (
            <Card>
              <CardHeader>
                <CardTitle>FLU Monitoring Data</CardTitle>
                <CardDescription>Foreign Location Usage monitoring information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">FLU Case ID</div>
                    <div className="font-mono">{caseData.monitoringData.fluCaseId}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Monitoring Status</div>
                    <Badge>{caseData.monitoringData.fluMonitoringStatus}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Triggered Alerts</CardTitle>
              <CardDescription>Alerts associated with this case</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {caseAlerts.map(alert => (
                  <div key={alert.id} className="flex items-start justify-between rounded-lg border p-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge variant={alert.severity === 'Critical' ? 'destructive' : 'default'}>
                          {alert.severity}
                        </Badge>
                        <span className="font-mono text-sm">{alert.id}</span>
                        <Badge variant="outline">{alert.status}</Badge>
                      </div>
                      <div className="text-sm">{alert.type}</div>
                      <div className="text-sm text-muted-foreground">{alert.description}</div>
                      <div className="text-xs text-muted-foreground">Date: {alert.date}</div>
                    </div>
                    <Button variant="outline" size="sm">Review</Button>
                  </div>
                ))}
                {caseAlerts.length === 0 && (
                  <div className="py-8 text-center text-muted-foreground">
                    No alerts for this case
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Transaction Analysis</CardTitle>
              <CardDescription>{caseData.transactionCount} transactions under review</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="flex items-center justify-between rounded-lg border p-3">
                    <div className="space-y-1">
                      <div className="font-mono text-sm">TXN-{String(i).padStart(6, '0')}</div>
                      <div className="text-xs text-muted-foreground">
                        {i % 2 === 0 ? 'Wire Transfer' : 'Cash Deposit'}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm">${(Math.random() * 50000 + 10000).toFixed(2)}</div>
                      <div className="text-xs text-muted-foreground">
                        2025-10-{String(20 + i).padStart(2, '0')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Activity Timeline</CardTitle>
              <CardDescription>Case activity and updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {caseActivities.map(activity => (
                  <div key={activity.id} className="flex gap-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                      <CheckCircle className="h-4 w-4" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="text-sm">{activity.type}</div>
                        <div className="text-xs text-muted-foreground">{activity.timestamp}</div>
                      </div>
                      <div className="text-sm text-muted-foreground">{activity.description}</div>
                      <div className="text-xs text-muted-foreground">by {activity.user}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Case Documentation</CardTitle>
              <CardDescription>Supporting documents and evidence</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {['KYC Documents', 'Transaction Reports', 'Investigation Notes', 'SAR Filing'].map((doc, i) => (
                  <div key={i} className="flex items-center justify-between rounded-lg border p-3">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <div className="text-sm">{doc}</div>
                        <div className="text-xs text-muted-foreground">Updated 2025-10-{20 + i}</div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">Download</Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}