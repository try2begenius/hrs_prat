import { Case, CaseStatus, Case312Response, CAMCaseResponse, SalesOwnerResponse } from '../types';
import { UserAccess, getPermissionsForRole } from '../data/rolesEntitlementsMockData';
import { toast } from 'sonner';
import { Section312Case } from './case-sections/Section312Case';
import { SectionCAMCase } from './case-sections/SectionCAMCase';
import { SectionSalesReview } from './case-sections/SectionSalesReview';
import { SectionCaseClientDetails } from './case-details/SectionCaseClientDetails';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Tabs, Tab, Box } from '@mui/material';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Separator } from './ui/separator';
import { ArrowLeft, AlertTriangle, Info, FileText, MessageSquare } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { mockCases } from '../data/enhancedMockData';

interface CaseDetailsEnhancedProps {
  caseId: string;
  onBack: () => void;
  currentUser: UserAccess;
}

export function CaseDetailsEnhanced({ caseId, onBack, currentUser }: CaseDetailsEnhancedProps) {
  const [caseData, setCaseData] = useState<Case | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  
  // Get user permissions
  const permissions = getPermissionsForRole(currentUser.role as any);
  const canEditCases = permissions.actionCases;
  
  // 312 Case Response State
  const [case312Response, setCase312Response] = useState<Case312Response>({
    question1_disposition: undefined,
    question1_commentary: undefined,
    question2_disposition: undefined,
    question2_commentary: undefined,
    question3_option: undefined,
    question3_comments: undefined,
    question4_disposition: undefined,
    question4_commentary: undefined,
    caseAction: undefined,
    trmsNumber: undefined,
    salesOwner: undefined,
    salesComments: undefined,
  });

  // CAM Case Response State
  const [camCaseResponse, setCAMCaseResponse] = useState<CAMCaseResponse>({
    question1: null,
    question1_1_attestations: [],
    question1_2_trms: undefined,
    question1_3_trmsNumber: undefined,
    question2_confirmation: false,
    question3_action: undefined,
    question3_trms: undefined,
    question3_salesOwner: undefined,
    question3_comments: undefined,
    question3_confirmation: false,
  });

  // Sales Owner Response State
  const [salesOwnerResponse, setSalesOwnerResponse] = useState<SalesOwnerResponse>({
    comments: '',
  });

  // Warning/Alert Dialog States
  const [showSaveWarning, setShowSaveWarning] = useState(false);
  const [showSubmitWarning, setShowSubmitWarning] = useState(false);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');
  const [submitSection, setSubmitSection] = useState<'312' | 'CAM' | 'sales' | null>(null);

  useEffect(() => {
    // Load case data
    const foundCase = mockCases.find(c => c.id === caseId);
    if (foundCase) {
      setCaseData(foundCase);
      
      // Load existing responses if any
      if (foundCase.case312Response) {
        setCase312Response(foundCase.case312Response);
      }
      if (foundCase.camCaseResponse) {
        setCAMCaseResponse(foundCase.camCaseResponse);
      }
      if (foundCase.salesOwnerResponse) {
        setSalesOwnerResponse(foundCase.salesOwnerResponse);
      }
    }
    setLoading(false);
  }, [caseId]);

  if (loading || !caseData) {
    return <div className="flex items-center justify-center h-96">Loading case details...</div>;
  }

  const getStatusColor = (status: CaseStatus) => {
    switch (status) {
      case 'Unassigned': return 'bg-gray-100 text-gray-800';
      case 'In Progress': return 'bg-amber-100 text-amber-800';
      case 'Pending Sales Review': return 'bg-blue-100 text-blue-800';
      case 'In Sales Review': return 'bg-purple-100 text-purple-800';
      case 'Sales Review Complete': return 'bg-indigo-100 text-indigo-800';
      case 'Complete': return 'bg-green-100 text-green-800';
      case 'Defect Remediation': return 'bg-red-100 text-red-800';
      case 'Under Review': return 'bg-purple-100 text-purple-800';
      case 'Escalated': return 'bg-destructive/10 text-destructive';
      case 'Closed': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-gray-100 text-gray-800';
    }
  };

  // Validate 312 section before save
  const validate312Save = (): boolean => {
    const lob = caseData.lineOfBusiness || caseData.clientData?.lineOfBusiness;
    const isML = lob === 'ML';
    
    // Question 1 - Required for all LOBs
    if (!case312Response.question1_disposition) {
      setWarningMessage('Question 1: Expected Value and Volume - Disposition is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (!case312Response.question1_commentary || case312Response.question1_commentary.trim() === '') {
      setWarningMessage('Question 1: Expected Value and Volume - Commentary is required.');
      setShowSaveWarning(true);
      return false;
    }
    
    // Question 2 - Required for all LOBs
    if (!case312Response.question2_disposition) {
      setWarningMessage('Question 2: Cross Border Movement - Disposition is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (!case312Response.question2_commentary || case312Response.question2_commentary.trim() === '') {
      setWarningMessage('Question 2: Cross Border Movement - Commentary is required.');
      setShowSaveWarning(true);
      return false;
    }
    
    // Question 3 - Required for all LOBs
    if (!case312Response.question3_option) {
      setWarningMessage('Question 3: Purpose of Relationship/Account - Response is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (case312Response.question3_option === 'activity_differed' && (!case312Response.question3_comments || case312Response.question3_comments.trim() === '')) {
      setWarningMessage('Question 3: Purpose of Relationship/Account - Comments are required when activity differed.');
      setShowSaveWarning(true);
      return false;
    }
    
    // Question 4 - Required for ML only
    if (isML) {
      if (!case312Response.question4_disposition) {
        setWarningMessage('Question 4: Source of Funds - Disposition is required for ML cases.');
        setShowSaveWarning(true);
        return false;
      }
      if (!case312Response.question4_commentary || case312Response.question4_commentary.trim() === '') {
        setWarningMessage('Question 4: Source of Funds - Commentary is required for ML cases.');
        setShowSaveWarning(true);
        return false;
      }
    }
    
    // Case Action - Required for all LOBs
    if (!case312Response.caseAction) {
      setWarningMessage('Case Action is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (case312Response.caseAction === 'complete_trms_filed' && (!case312Response.trmsNumber || case312Response.trmsNumber.trim() === '')) {
      setWarningMessage('Please provide TRMS number when case action is "Complete – TRMS filed".');
      setShowSaveWarning(true);
      return false;
    }
    if (case312Response.caseAction === 'send_to_sales' && !case312Response.salesOwner) {
      setWarningMessage('Please select Sales Owner when case action is "Send to Sales".');
      setShowSaveWarning(true);
      return false;
    }
    
    return true;
  };

  // Validate CAM section before save
  const validateCAMSave = (): boolean => {
    if (camCaseResponse.question1 === null) {
      setWarningMessage('Question 1 is required.');
      setShowSaveWarning(true);
      return false;
    }
    // If No to Q1, must check BOTH attestations
    if (camCaseResponse.question1 === false) {
      const requiredAttestations = [
        'I have reviewed the alerts and escalations and believe no further escalation is required to be raised',
        'No additional findings or knowledge of the client require an escalation outside of what has been already properly escalated'
      ];
      const checkedAttestations = camCaseResponse.question1_1_attestations || [];
      const allChecked = requiredAttestations.every(att => checkedAttestations.includes(att));
      
      if (!allChecked) {
        setWarningMessage('Please check both attestations for Question 1.1');
        setShowSaveWarning(true);
        return false;
      }
    }
    if (camCaseResponse.question1 === true && !camCaseResponse.question1_2_trms) {
      setWarningMessage('Please indicate if TRMS was filed for Question 1.2');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question1 === true && camCaseResponse.question1_2_trms === 'yes' && !camCaseResponse.question1_3_trmsNumber) {
      setWarningMessage('Please provide TRMS number for Question 1.3');
      setShowSaveWarning(true);
      return false;
    }
    if (!camCaseResponse.question2_confirmation) {
      setWarningMessage('Question 2 confirmation is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (!camCaseResponse.question3_action) {
      setWarningMessage('Question 3 (Case Action) is required.');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question3_action === 'complete_trms_filed' && !camCaseResponse.question3_trms) {
      setWarningMessage('Please provide TRMS number for Case Action.');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question3_action === 'send_to_sales' && !camCaseResponse.question3_salesOwner) {
      setWarningMessage('Please select Sales Owner for Case Action.');
      setShowSaveWarning(true);
      return false;
    }
    if (camCaseResponse.question3_action === 'send_to_sales' && !camCaseResponse.question3_comments) {
      setWarningMessage('Comments are mandatory when sending to Sales.');
      setShowSaveWarning(true);
      return false;
    }
    // Confirmation checkbox required for Complete actions
    if ((camCaseResponse.question3_action === 'complete_trms_filed' || camCaseResponse.question3_action === 'complete_no_action') && !camCaseResponse.question3_confirmation) {
      setWarningMessage('Please confirm that all data has been reviewed before completing the case action.');
      setShowSaveWarning(true);
      return false;
    }
    return true;
  };

  // Save handlers
  const handle312Save = () => {
    if (!validate312Save()) return;
    
    toast.success('312 Case responses saved successfully');
  };

  const handleCAMSave = () => {
    if (!validateCAMSave()) return;
    
    toast.success('CAM Case responses saved successfully');
  };

  const handleSalesSave = () => {
    if (!salesOwnerResponse.comments || salesOwnerResponse.comments.trim() === '') {
      setWarningMessage('Please provide comments before saving.');
      setShowSaveWarning(true);
      return;
    }
    if (salesOwnerResponse.comments.length > 4000) {
      setWarningMessage('Comments cannot exceed 4000 characters.');
      setShowSaveWarning(true);
      return;
    }
    
    toast.success('Sales Owner response saved successfully');
  };

  // Submit handlers
  const handle312Submit = () => {
    if (!validate312Save()) return;
    
    setSubmitSection('312');
    setWarningMessage('Once you submit, you will be unable to make edits/changes to this section. Do you want to proceed?');
    setShowSubmitConfirm(true);
  };

  const handleCAMSubmit = () => {
    if (!validateCAMSave()) return;
    
    setSubmitSection('CAM');
    setWarningMessage('Once you submit, you will be unable to make edits/changes to this section. Do you want to proceed?');
    setShowSubmitConfirm(true);
  };

  const handleSalesSubmit = () => {
    if (!salesOwnerResponse.comments || salesOwnerResponse.comments.trim() === '') {
      setWarningMessage('Please provide comments before returning to Case Processor.');
      setShowSubmitWarning(true);
      return;
    }
    
    setSubmitSection('sales');
    setWarningMessage('This will return the case to the Case Processor for final review. Do you want to proceed?');
    setShowSubmitConfirm(true);
  };

  const confirmSubmit = () => {
    if (submitSection === '312') {
      setCase312Response({
        ...case312Response,
        submittedBy: currentUser.name,
        submittedDate: new Date().toISOString(),
        isSubmitted: true,
      });
      toast.success('312 Case submitted successfully');
    } else if (submitSection === 'CAM') {
      setCAMCaseResponse({
        ...camCaseResponse,
        submittedBy: currentUser.name,
        submittedDate: new Date().toISOString(),
        isSubmitted: true,
      });
      toast.success('CAM Case submitted successfully');
    } else if (submitSection === 'sales') {
      setSalesOwnerResponse({
        ...salesOwnerResponse,
        submittedBy: currentUser.name,
        submittedDate: new Date().toISOString(),
        isSubmitted: true,
      });
      toast.success('Case returned to Case Processor successfully');
    }
    setShowSubmitConfirm(false);
    setSubmitSection(null);
  };

  const is312Case = caseData.is312Case || caseData.caseType === '312 Review';
  const isCAMCase = caseData.caseType === 'CAM Review' || is312Case;
  
  // Section 5 is visible to Sales Owners and AML users (access control is in the component itself)
  const canViewSalesSection = true;

  // Check if sections are submitted (read-only)
  const is312Submitted = case312Response.isSubmitted || false;
  const isCAMSubmitted = camCaseResponse.isSubmitted || false;
  const isSalesSubmitted = salesOwnerResponse.isSubmitted || false;

  // Build dynamic tab index mapping
  const tabMapping: { [key: number]: string } = {};
  let tabIndex = 0;
  
  tabMapping[tabIndex++] = 'details';
  if (is312Case && permissions.view312Tab) {
    tabMapping[tabIndex++] = '312';
  }
  if (isCAMCase && caseData.camCaseData && permissions.viewCAMTab) {
    tabMapping[tabIndex++] = 'cam';
  }
  if (canViewSalesSection) {
    tabMapping[tabIndex++] = 'sales';
  }
  tabMapping[tabIndex++] = 'comments';
  tabMapping[tabIndex++] = 'documents';

  const getCurrentTabValue = () => tabMapping[activeTab] || 'details';

  return (
    <div className="space-y-6">
      {/* Section 1: Case Banner - Always Visible */}
      <Card className="border-l-4 border-l-primary">
        <CardHeader className="bg-muted/30 pb-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={onBack} className="hover:bg-muted">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Workbasket
            </Button>
            <Badge className={getStatusColor(caseData.status) + ' text-sm px-3 py-1'}>
              {caseData.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-6">
            <div>
              <Label className="text-xs text-muted-foreground">Case ID</Label>
              <p className="font-mono font-semibold text-primary mt-1">{caseData.id}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Client Name</Label>
              <p className="font-medium mt-1">{caseData.clientName}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Party ID</Label>
              <p className="font-mono text-sm mt-1">{caseData.partyId || '-'}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">GCI</Label>
              <p className="font-mono text-sm mt-1">{caseData.gci || '-'}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">MP ID</Label>
              <p className="font-mono text-sm mt-1">{caseData.mpId || '-'}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">CoPer ID</Label>
              <p className="font-mono text-sm mt-1">{caseData.coperId || '-'}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">LOB</Label>
              <p className="font-medium mt-1">{caseData.lineOfBusiness || '-'}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Assignee</Label>
              <p className="font-medium mt-1">{caseData.assignedTo}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tab Navigation and Content */}
      <Card>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={activeTab} 
            onChange={(e, newValue) => setActiveTab(newValue)}
            variant="fullWidth"
            sx={{
              '& .MuiTab-root': {
                textTransform: 'none',
                fontWeight: 500,
                fontSize: '0.875rem',
                minHeight: '48px',
              },
            }}
          >
            <Tab label="Case and Client Details" />
            {is312Case && permissions.view312Tab && (
              <Tab 
                label={
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', gap: '4px' }}>
                    <span style={{ display: 'flex', alignItems: 'center' }}>312 CAM {caseData.case312Data?.disposition || 'Pending'}</span>
                    <span style={{ 
                      fontSize: '1 rem', 
                      fontWeight: 500, 
                      color: '#7c3aed',
                      display: 'flex',
                      alignItems: 'center'
                    }}>
                    </span>
                  </div>
                } 
                className=""
                sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center' 
                }}
              />
            )}
            {isCAMCase && caseData.camCaseData && permissions.viewCAMTab && (
              <Tab 
                label={
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', gap: '4px' }}>
                    <span>CAM {caseData.camCaseData?.disposition || 'Pending'}</span>
                    <span style={{ 
                      fontSize: '1 rem', 
                      fontWeight: 500, 
                      color: '#7c3aed'
                    }}>
                      
                    </span>
                  </div>
                }
              />
            )}
            {canViewSalesSection && <Tab label="Sales Review" />}
            <Tab label="Comments" />
            <Tab label="Documents" />
          </Tabs>
        </Box>

        {/* Tab Content */}
        <CardContent className="pt-6">
          {/* Tab Panel 0: Case and Client Details */}
          {getCurrentTabValue() === 'details' && (
            <SectionCaseClientDetails caseData={caseData} />
          )}

          {/* Tab Panel: 312 Case */}
          {getCurrentTabValue() === '312' && is312Case && permissions.view312Tab && (
            <Section312Case
              caseData={caseData}
              response={case312Response}
              setResponse={setCase312Response}
              isSubmitted={is312Submitted}
              canEdit={canEditCases}
              onSave={handle312Save}
              onCancel={onBack}
              onSubmit={handle312Submit}
            />
          )}

          {/* Tab Panel: CAM Case */}
          {getCurrentTabValue() === 'cam' && isCAMCase && caseData.camCaseData && permissions.viewCAMTab && (
            <SectionCAMCase
              caseData={caseData}
              response={camCaseResponse}
              setResponse={setCAMCaseResponse}
              isSubmitted={isCAMSubmitted}
              canEdit={canEditCases}
              onSave={handleCAMSave}
              onCancel={onBack}
              onSubmit={handleCAMSubmit}
            />
          )}

          {/* Tab Panel: Sales Review */}
          {getCurrentTabValue() === 'sales' && canViewSalesSection && (
            <SectionSalesReview
              caseData={caseData}
              response={salesOwnerResponse}
              setResponse={setSalesOwnerResponse}
              isSubmitted={isSalesSubmitted}
              onSave={handleSalesSave}
              onCancel={onBack}
              onSubmit={handleSalesSubmit}
              currentUser={currentUser}
            />
          )}

          {/* Tab Panel: Comments */}
          {getCurrentTabValue() === 'comments' && (
            <div className="flex flex-col items-center justify-center py-12">
              <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Comments section - Coming soon</p>
            </div>
          )}

          {/* Tab Panel: Documents */}
          {getCurrentTabValue() === 'documents' && (
            <div className="flex flex-col items-center justify-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Documents section - Coming soon</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Warning Dialogs */}
      <AlertDialog open={showSaveWarning} onOpenChange={setShowSaveWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600" />
              Validation Warning
            </AlertDialogTitle>
            <AlertDialogDescription>{warningMessage}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowSaveWarning(false)}>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showSubmitWarning} onOpenChange={setShowSubmitWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600" />
              Submission Warning
            </AlertDialogTitle>
            <AlertDialogDescription>{warningMessage}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowSubmitWarning(false)}>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showSubmitConfirm} onOpenChange={setShowSubmitConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Info className="h-5 w-5 text-blue-600" />
              Confirm Submission
            </AlertDialogTitle>
            <AlertDialogDescription>{warningMessage}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setShowSubmitConfirm(false);
              setSubmitSection(null);
            }}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmSubmit}>Confirm</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}