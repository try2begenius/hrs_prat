import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Button,
  Alert,
} from '@mui/material';
import {
  CheckCircle,
  Cancel,
  Info,
} from '@mui/icons-material';

interface ClientData {
  clientName: string;
  clientId: string;
  gciNumber: string;
  lob: string;
  fluSystem: string;
  risk: string;
  status: string;
  population: string;
  daysToRefresh: number;
  salesOwner: string;
  refreshDueDate: string;
  has312Flag: boolean;
}

interface CriteriaCheck {
  label: string;
  detail: string;
  passed: boolean;
  optional?: boolean;
}

export function ClientCriteriaDetailView({ client, onClear }: { client: ClientData; onClear: () => void }) {
  // Generate 312 criteria checks based on client data
  const get312Criteria = (): CriteriaCheck[] => {
    const criteria: CriteriaCheck[] = [
      {
        label: 'Client is in Active status',
        detail: client.status,
        passed: client.status === 'Active',
      },
      {
        label: 'Client has 312 Flag in AWARE',
        detail: client.has312Flag ? 'Flag present' : 'Flag not present',
        passed: client.has312Flag,
      },
    ];

    // Risk rating check
    if (client.lob === 'GB/GM') {
      criteria.push({
        label: 'Risk Rating: High, Elevated, or Standard',
        detail: client.risk,
        passed: ['High', 'Elevated', 'Standard'].includes(client.risk),
      });

      // Family anniversary check for non-high risk
      if (client.risk !== 'High') {
        criteria.push({
          label: 'GB/GM Non-High Risk - Family Anniversary within 180 days',
          detail: `${client.daysToRefresh} days ✓`,
          passed: client.daysToRefresh <= 180,
        });
      }
    } else if (client.lob === 'PB' || client.lob === 'ML') {
      criteria.push({
        label: 'Client refresh is due within 180 calendar days',
        detail: `${client.daysToRefresh} days`,
        passed: client.daysToRefresh <= 180,
      });
      criteria.push({
        label: "Client has 'PVT' code from CRA",
        detail: 'PVT present',
        passed: true,
      });
    }

    // Manual identification (optional)
    criteria.push({
      label: 'Manually identified for 312 review (Optional)',
      detail: 'Not flagged',
      passed: false,
      optional: true,
    });

    return criteria;
  };

  // Generate CAM criteria checks
  const getCAMCriteria = (): CriteriaCheck[] => {
    const criteria: CriteriaCheck[] = [
      {
        label: 'Client is in Active status',
        detail: client.status,
        passed: client.status === 'Active',
      },
      {
        label: 'Risk Rating must be High (at time of case creation)',
        detail: client.risk === 'High' ? client.risk : `${client.risk} - EXCLUDED`,
        passed: client.risk === 'High',
      },
    ];

    return criteria;
  };

  const criteria312 = get312Criteria();
  const criteriaCAM = getCAMCriteria();

  const is312Included = client.population === '312' || client.population === 'Both';
  const isCAMIncluded = client.population === 'CAM' || client.population === 'Both';

  return (
    <Box>
      {/* Client Header */}
      <Card sx={{ mb: 3, border: '2px solid', borderColor: 'primary.main' }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
            <Box>
              <Typography variant="h6" fontWeight={600} gutterBottom>
                {client.clientName}
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                <Chip label={client.clientId} size="small" variant="outlined" />
                <Chip label={client.lob} size="small" color="primary" />
                <Chip label={client.fluSystem} size="small" variant="outlined" />
                <Chip
                  label={client.risk}
                  size="small"
                  color={
                    client.risk === 'High'
                      ? 'error'
                      : client.risk === 'Elevated'
                      ? 'warning'
                      : client.risk === 'Standard'
                      ? 'info'
                      : 'default'
                  }
                />
              </Box>
            </Box>
            <Button variant="outlined" size="small" onClick={onClear}>
              Clear Selection
            </Button>
          </Box>

          {/* Client Details Grid */}
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2, mt: 2 }}>
            <Box sx={{ bgcolor: '#e3f2fd', p: 2, borderRadius: 1 }}>
              <Typography variant="caption" color="text.secondary">
                GCI Number
              </Typography>
              <Typography variant="body1" fontWeight={600}>
                {client.gciNumber}
              </Typography>
            </Box>
            <Box sx={{ bgcolor: '#e3f2fd', p: 2, borderRadius: 1 }}>
              <Typography variant="caption" color="text.secondary">
                Sales Owner
              </Typography>
              <Typography variant="body1" fontWeight={600}>
                {client.salesOwner}
              </Typography>
            </Box>
            <Box sx={{ bgcolor: '#e3f2fd', p: 2, borderRadius: 1 }}>
              <Typography variant="caption" color="text.secondary">
                Refresh Due Date
              </Typography>
              <Typography variant="body1" fontWeight={600}>
                {client.refreshDueDate}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {client.daysToRefresh} days
              </Typography>
            </Box>
            <Box sx={{ bgcolor: '#e3f2fd', p: 2, borderRadius: 1 }}>
              <Typography variant="caption" color="text.secondary">
                312 Flag
              </Typography>
              <Typography variant="body1" fontWeight={600} color={client.has312Flag ? 'success.main' : 'error.main'}>
                {client.has312Flag ? 'YES' : 'NO'}
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* CAM 312 Population Criteria Evaluation */}
      <Card sx={{ mb: 3, border: '2px solid', borderColor: is312Included ? 'primary.main' : 'grey.300' }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <Info color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  CAM 312 Population Criteria Evaluation
                </Typography>
              </Box>
              <Typography variant="body2" color="text.secondary">
                {client.lob === 'GB/GM'
                  ? 'GB/GM: Risk rating + timing criteria + 312 flag'
                  : client.lob === 'PB' || client.lob === 'ML'
                  ? `${client.lob}: Refresh within 180 days + PVT code`
                  : 'Evaluation criteria based on LOB'}
              </Typography>
            </Box>
            <Chip label="312" color="primary" />
          </Box>

          {/* Criteria Checks */}
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {criteria312.map((check, idx) => (
              <Box
                key={idx}
                sx={{
                  bgcolor: check.passed ? '#e8f5e9' : check.optional ? '#f5f5f5' : '#ffebee',
                  border: '1px solid',
                  borderColor: check.passed ? 'success.light' : check.optional ? 'grey.300' : 'error.light',
                  borderRadius: 1,
                  p: 2,
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                  {check.passed ? (
                    <CheckCircle sx={{ color: 'success.main', fontSize: 20 }} />
                  ) : check.optional ? (
                    <Cancel sx={{ color: 'grey.500', fontSize: 20 }} />
                  ) : (
                    <Cancel sx={{ color: 'error.main', fontSize: 20 }} />
                  )}
                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" fontWeight={600}>
                        {check.label}
                      </Typography>
                      {check.optional && (
                        <Chip label="Optional" size="small" variant="outlined" sx={{ ml: 1 }} />
                      )}
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                      {check.detail}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            ))}
          </Box>

          {/* Decision */}
          <Alert
            severity={is312Included ? 'info' : 'warning'}
            icon={<Info />}
            sx={{ mt: 2 }}
          >
            <Typography variant="body2" fontWeight={600}>
              Decision: {is312Included ? 'Included in 312 Population' : 'Excluded from 312 Population'}
            </Typography>
            {is312Included && client.lob === 'GB/GM' && client.risk === 'Standard' && (
              <Typography variant="body2" color="text.secondary">
                GB/GM {client.risk} Risk with Family Anniversary within 180 days
              </Typography>
            )}
          </Alert>
        </CardContent>
      </Card>

      {/* CAM Population Criteria Evaluation */}
      <Card sx={{ mb: 3, border: '2px solid', borderColor: isCAMIncluded ? 'error.main' : 'grey.300' }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <Info color="error" />
                <Typography variant="h6" fontWeight={600}>
                  CAM Population Criteria Evaluation
                </Typography>
              </Box>
              <Typography variant="body2" color="text.secondary">
                Simple logic: High risk + Active status (all LOBs)
              </Typography>
            </Box>
            <Chip label={isCAMIncluded ? 'Included' : 'Excluded'} color={isCAMIncluded ? 'error' : 'default'} />
          </Box>

          {/* Criteria Checks */}
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {criteriaCAM.map((check, idx) => (
              <Box
                key={idx}
                sx={{
                  bgcolor: check.passed ? '#e8f5e9' : '#ffebee',
                  border: '1px solid',
                  borderColor: check.passed ? 'success.light' : 'error.light',
                  borderRadius: 1,
                  p: 2,
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                  {check.passed ? (
                    <CheckCircle sx={{ color: 'success.main', fontSize: 20 }} />
                  ) : (
                    <Cancel sx={{ color: 'error.main', fontSize: 20 }} />
                  )}
                  <Box>
                    <Typography variant="body2" fontWeight={600}>
                      {check.label}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {check.detail}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            ))}
          </Box>

          {/* Decision */}
          <Alert
            severity={isCAMIncluded ? 'error' : 'warning'}
            icon={<Info />}
            sx={{ mt: 2 }}
          >
            <Typography variant="body2" fontWeight={600}>
              Decision: {isCAMIncluded ? 'Included in CAM Population' : 'Excluded from CAM Population'}
            </Typography>
            {!isCAMIncluded && (
              <Typography variant="body2" color="text.secondary">
                Client does not meet High risk requirement at time of case creation
              </Typography>
            )}
          </Alert>
        </CardContent>
      </Card>
    </Box>
  );
}
