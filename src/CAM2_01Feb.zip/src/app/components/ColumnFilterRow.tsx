import { TextFilter } from './ui/text-filter';
import { DateFilter } from './ui/date-filter';
import { BooleanFilter } from './ui/boolean-filter';

interface ColumnFilterRowProps {
  // Manager checkbox column
  isManager: boolean;
  
  // Text filters
  caseIdFilter: string;
  caseIdFilterType: string;
  setCaseIdFilter: (value: string) => void;
  setCaseIdFilterType: (value: string) => void;
  
  clientNameFilter: string;
  clientNameFilterType: string;
  setClientNameFilter: (value: string) => void;
  setClientNameFilterType: (value: string) => void;
  
  partyIdFilter: string;
  partyIdFilterType: string;
  setPartyIdFilter: (value: string) => void;
  setPartyIdFilterType: (value: string) => void;
  
  gciFilter: string;
  gciFilterType: string;
  setGciFilter: (value: string) => void;
  setGciFilterType: (value: string) => void;
  
  mpIdFilter: string;
  mpIdFilterType: string;
  setMpIdFilter: (value: string) => void;
  setMpIdFilterType: (value: string) => void;
  
  coperIdFilter: string;
  coperIdFilterType: string;
  setCoperIdFilter: (value: string) => void;
  setCoperIdFilterType: (value: string) => void;
  
  caseStatusFilter: string;
  caseStatusFilterType: string;
  setCaseStatusFilter: (value: string) => void;
  setCaseStatusFilterType: (value: string) => void;
  
  // Date filters
  dueDateFilterType: string;
  dueDateValue: Date | undefined;
  dueDateValueEnd: Date | undefined;
  setDueDateFilterType: (value: string) => void;
  setDueDateValue: (value: Date | undefined) => void;
  setDueDateValueEnd: (value: Date | undefined) => void;
  
  createdDateFilterType: string;
  createdDateValue: Date | undefined;
  createdDateValueEnd: Date | undefined;
  setCreatedDateFilterType: (value: string) => void;
  setCreatedDateValue: (value: Date | undefined) => void;
  setCreatedDateValueEnd: (value: Date | undefined) => void;
  
  assigneeFilter: string;
  assigneeFilterType: string;
  setAssigneeFilter: (value: string) => void;
  setAssigneeFilterType: (value: string) => void;
  
  lobColumnFilter: string;
  lobColumnFilterType: string;
  setLobColumnFilter: (value: string) => void;
  setLobColumnFilterType: (value: string) => void;
  
  riskColumnFilter: string;
  riskColumnFilterType: string;
  setRiskColumnFilter: (value: string) => void;
  setRiskColumnFilterType: (value: string) => void;
  
  // Boolean filters
  boaEmployeeFilter: string;
  setBoaEmployeeFilter: (value: string) => void;
  boaAffiliateFilter: string;
  setBoaAffiliateFilter: (value: string) => void;
  regOFilter: string;
  setRegOFilter: (value: string) => void;
  is312CaseFilter: string;
  setIs312CaseFilter: (value: string) => void;
}

export function ColumnFilterRow(props: ColumnFilterRowProps) {
  return (
    <tr className="border-b bg-muted/10">
      {props.isManager && (
        <th className="h-10 px-2 align-middle bg-background"></th>
      )}
      
      {/* Case ID Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.caseIdFilter}
          onChange={props.setCaseIdFilter}
          filterType={props.caseIdFilterType}
          onFilterTypeChange={props.setCaseIdFilterType}
        />
      </th>
      
      {/* Client Name Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.clientNameFilter}
          onChange={props.setClientNameFilter}
          filterType={props.clientNameFilterType}
          onFilterTypeChange={props.setClientNameFilterType}
        />
      </th>
      
      {/* Party ID Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.partyIdFilter}
          onChange={props.setPartyIdFilter}
          filterType={props.partyIdFilterType}
          onFilterTypeChange={props.setPartyIdFilterType}
        />
      </th>
      
      {/* GCI Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.gciFilter}
          onChange={props.setGciFilter}
          filterType={props.gciFilterType}
          onFilterTypeChange={props.setGciFilterType}
        />
      </th>
      
      {/* MP ID Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.mpIdFilter}
          onChange={props.setMpIdFilter}
          filterType={props.mpIdFilterType}
          onFilterTypeChange={props.setMpIdFilterType}
        />
      </th>
      
      {/* CoPer ID Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.coperIdFilter}
          onChange={props.setCoperIdFilter}
          filterType={props.coperIdFilterType}
          onFilterTypeChange={props.setCoperIdFilterType}
        />
      </th>
      
      {/* Case Status Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.caseStatusFilter}
          onChange={props.setCaseStatusFilter}
          filterType={props.caseStatusFilterType}
          onFilterTypeChange={props.setCaseStatusFilterType}
        />
      </th>
      
      {/* Due Date Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <DateFilter
          filterType={props.dueDateFilterType}
          onFilterTypeChange={props.setDueDateFilterType}
          dateValue={props.dueDateValue}
          onDateValueChange={props.setDueDateValue}
          dateValueEnd={props.dueDateValueEnd}
          onDateValueEndChange={props.setDueDateValueEnd}
        />
      </th>
      
      {/* Created Date Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <DateFilter
          filterType={props.createdDateFilterType}
          onFilterTypeChange={props.setCreatedDateFilterType}
          dateValue={props.createdDateValue}
          onDateValueChange={props.setCreatedDateValue}
          dateValueEnd={props.createdDateValueEnd}
          onDateValueEndChange={props.setCreatedDateValueEnd}
        />
      </th>
      
      {/* Assignee Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.assigneeFilter}
          onChange={props.setAssigneeFilter}
          filterType={props.assigneeFilterType}
          onFilterTypeChange={props.setAssigneeFilterType}
        />
      </th>
      
      {/* Client LOB Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.lobColumnFilter}
          onChange={props.setLobColumnFilter}
          filterType={props.lobColumnFilterType}
          onFilterTypeChange={props.setLobColumnFilterType}
        />
      </th>
      
      {/* Risk Rating Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <TextFilter
          value={props.riskColumnFilter}
          onChange={props.setRiskColumnFilter}
          filterType={props.riskColumnFilterType}
          onFilterTypeChange={props.setRiskColumnFilterType}
        />
      </th>
      
      {/* BOA Employee Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <BooleanFilter
          value={props.boaEmployeeFilter}
          onChange={props.setBoaEmployeeFilter}
        />
      </th>
      
      {/* BOA Affiliate Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <BooleanFilter
          value={props.boaAffiliateFilter}
          onChange={props.setBoaAffiliateFilter}
        />
      </th>
      
      {/* Reg O Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <BooleanFilter
          value={props.regOFilter}
          onChange={props.setRegOFilter}
        />
      </th>
      
      {/* 312 Case Filter */}
      <th className="h-10 px-2 align-middle bg-background">
        <BooleanFilter
          value={props.is312CaseFilter}
          onChange={props.setIs312CaseFilter}
        />
      </th>
    </tr>
  );
}
