import { useState } from 'react';
import { Box, Tabs, Tab } from '@mui/material';
import { UserAccess } from '../data/rolesEntitlementsMockData';
import { IndividualWorklist } from './IndividualWorklist';
import { SalesOwnerWorklist } from './SalesOwnerWorklist';
import { CaseWorkbasket } from './CaseWorklist';

interface CombinedWorklistProps {
  onViewCase: (caseId: string) => void;
  currentUser: UserAccess;
  onCaseAssigned: (caseId: string, assignee: string) => void;
}

export function CombinedWorklist({ onViewCase, currentUser, onCaseAssigned }: CombinedWorklistProps) {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <Box sx={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs 
          value={activeTab} 
          onChange={(e, newValue) => setActiveTab(newValue)}
          sx={{
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 500,
              fontSize: '0.875rem',
              minHeight: '48px',
            },
          }}
        >
          <Tab label="Workbasket" />
          <Tab label="My Worklist" />
        </Tabs>
      </Box>

      <Box sx={{ flex: 1, overflow: 'auto' }}>
        {activeTab === 0 && (
          <CaseWorkbasket 
            onViewCase={onViewCase} 
            currentUser={currentUser} 
            onCaseAssigned={onCaseAssigned}
          />
        )}
        {activeTab === 1 && (
          currentUser.role === 'Sales Owner' ? (
            <SalesOwnerWorklist 
              onViewCase={onViewCase} 
              currentUser={currentUser}
            />
          ) : (
            <IndividualWorklist 
              onViewCase={onViewCase} 
              currentUser={currentUser}
              onCaseAssigned={onCaseAssigned}
            />
          )
        )}
      </Box>
    </Box>
  );
}