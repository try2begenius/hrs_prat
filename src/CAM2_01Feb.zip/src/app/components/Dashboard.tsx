import { 
  Card, 
  CardContent, 
  Typography, 
  Chip, 
  Box, 
  Grid 
} from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from 'recharts';
import { Warning, TrendingUp, People, Description, Schedule, CheckCircle } from '@mui/icons-material';
import { mockCases } from '../data/enhancedMockData';
import { UserAccess } from '../data/rolesEntitlementsMockData';

interface DashboardProps {
  currentUser: UserAccess;
}

const trendData = [
  { month: 'May', cases: 45 },
  { month: 'Jun', cases: 52 },
  { month: 'Jul', cases: 48 },
  { month: 'Aug', cases: 61 },
  { month: 'Sep', cases: 58 },
  { month: 'Oct', cases: 67 },
];

export function Dashboard({ currentUser }: DashboardProps) {
  const filterCasesByUser = (cases: typeof mockCases) => {
    return cases.filter(c => {
      if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
      if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
      
      const caseLOB = c.clientData?.lineOfBusiness;
      if (caseLOB && !currentUser.entitlements.lobs.includes(caseLOB)) return false;
      
      if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
      
      if (currentUser.role === 'Sales Owner' && c.assignedTo !== currentUser.name) return false;
      
      return true;
    });
  };

  const userCases = filterCasesByUser(mockCases);
  
  const statusData = [
    { name: 'Unassigned', value: userCases.filter(c => c.status === 'Unassigned').length, color: '#6B7280' },
    { name: 'In Progress', value: userCases.filter(c => c.status === 'In Progress').length, color: '#F59E0B' },
    { name: 'Pending Sales Review', value: userCases.filter(c => c.status === 'Pending Sales Review').length, color: '#3B82F6' },
    { name: 'In Sales Review', value: userCases.filter(c => c.status === 'In Sales Review').length, color: '#8B5CF6' },
    { name: 'Complete', value: userCases.filter(c => c.status === 'Complete').length, color: '#10B981' },
    { name: 'Defect Remediation', value: userCases.filter(c => c.status === 'Defect Remediation').length, color: '#EF4444' },
  ].filter(item => item.value > 0);

  const riskData = [
    { name: 'Critical', count: userCases.filter(c => c.riskLevel === 'Critical').length },
    { name: 'High', count: userCases.filter(c => c.riskLevel === 'High').length },
    { name: 'Medium', count: userCases.filter(c => c.riskLevel === 'Medium').length },
    { name: 'Low', count: userCases.filter(c => c.riskLevel === 'Low').length },
  ];

  const totalCases = userCases.length;
  const openCases = userCases.filter(c => c.status !== 'Closed').length;
  const highPriority = userCases.filter(c => c.priority === 'Urgent' || c.priority === 'High').length;
  const overdueCount = userCases.filter(c => {
    const dueDate = new Date(c.dueDate);
    const today = new Date();
    return dueDate < today && c.status !== 'Closed';
  }).length;

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Dashboard Overview
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {currentUser.role} View - {currentUser.entitlements.lobs.join(', ')} 
          {currentUser.entitlements.has312Access && currentUser.entitlements.hasCAMAccess && ' | 312 & CAM Access'}
          {currentUser.entitlements.has312Access && !currentUser.entitlements.hasCAMAccess && ' | 312 Access Only'}
          {!currentUser.entitlements.has312Access && currentUser.entitlements.hasCAMAccess && ' | CAM Access Only'}
        </Typography>
      </Box>

      {/* Statistics Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <Card sx={{ borderLeft: 4, borderColor: 'primary.main' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Total Cases
                  </Typography>
                  <Typography variant="h3" color="primary.main" sx={{ my: 1 }}>
                    {totalCases}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    <Box component="span" sx={{ color: 'success.main', fontWeight: 600 }}>+12%</Box> from last month
                  </Typography>
                </Box>
                <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: 'primary.lighter' }}>
                  <Description sx={{ color: 'primary.main' }} />
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <Card sx={{ borderLeft: 4, borderColor: 'warning.main' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Open Cases
                  </Typography>
                  <Typography variant="h3" color="warning.main" sx={{ my: 1 }}>
                    {openCases}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Requires attention
                  </Typography>
                </Box>
                <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: 'warning.lighter' }}>
                  <Warning sx={{ color: 'warning.main' }} />
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <Card sx={{ borderLeft: 4, borderColor: 'error.main' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    High Priority
                  </Typography>
                  <Typography variant="h3" color="error.main" sx={{ my: 1 }}>
                    {highPriority}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Urgent and high priority
                  </Typography>
                </Box>
                <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: 'error.lighter' }}>
                  <TrendingUp sx={{ color: 'error.main' }} />
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <Card sx={{ borderLeft: 4, borderColor: 'success.main' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Overdue
                  </Typography>
                  <Typography variant="h3" color="error.main" sx={{ my: 1 }}>
                    {overdueCount}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Past due date
                  </Typography>
                </Box>
                <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: 'error.lighter' }}>
                  <Schedule sx={{ color: 'error.main' }} />
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Charts Row */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="subtitle2" gutterBottom>
                Case Type Distribution
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2">312 Reviews</Typography>
                  <Typography variant="body2" fontWeight={600} color="primary">
                    {userCases.filter(c => c.caseType === '312 Review').length}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2">CAM Reviews</Typography>
                  <Typography variant="body2" fontWeight={600} color="primary">
                    {userCases.filter(c => c.caseType === 'CAM Review').length}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2">Other</Typography>
                  <Typography variant="body2" fontWeight={600} color="primary">
                    {userCases.filter(c => c.caseType !== '312 Review' && c.caseType !== 'CAM Review').length}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="subtitle2" gutterBottom>
                LOB Distribution
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                {['GB/GM', 'PB', 'ML', 'Consumer', 'CI'].map(lob => {
                  const lobCount = userCases.filter(c => c.clientData?.lineOfBusiness === lob).length;
                  if (lobCount === 0) return null;
                  return (
                    <Box key={lob} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">{lob}</Typography>
                      <Typography variant="body2" fontWeight={600} color="primary">{lobCount}</Typography>
                    </Box>
                  );
                })}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="subtitle2" gutterBottom>
                Employee Cases
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2">Total Employee</Typography>
                  <Typography variant="body2" fontWeight={600} color="primary">
                    {userCases.filter(c => c.clientData?.isEmployee).length}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2">Open Employee</Typography>
                  <Typography variant="body2" fontWeight={600} color="warning.main">
                    {userCases.filter(c => c.clientData?.isEmployee && c.status !== 'Closed').length}
                  </Typography>
                </Box>
                {!currentUser.entitlements.hasEmployeeCaseAccess && (
                  <Typography variant="caption" color="text.secondary" sx={{ mt: 1 }}>
                    * You don't have employee case access
                  </Typography>
                )}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Activity Tables */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Cases by Status
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Current distribution of case statuses
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Risk Level Distribution
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Cases categorized by risk severity
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={riskData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="name" stroke="#64748B" />
                  <YAxis stroke="#64748B" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#ffffff', 
                      border: '1px solid #E2E8F0',
                      borderRadius: '0.5rem'
                    }}
                  />
                  <Bar dataKey="count" fill="#2563EB" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Trend Chart */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Case Volume Trend
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Monthly case creation over the past 6 months
          </Typography>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="month" stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#ffffff', 
                  border: '1px solid #E2E8F0',
                  borderRadius: '0.5rem'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="cases" 
                stroke="#2563EB" 
                strokeWidth={3}
                dot={{ fill: '#2563EB', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Recent High-Priority Cases */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Recent High-Priority Cases
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Cases requiring immediate attention ({currentUser.role})
          </Typography>

          {userCases.filter(c => (c.priority === 'Urgent' || c.priority === 'High') && c.status !== 'Closed').length === 0 ? (
            <Box sx={{ textAlign: 'center', py: 8, color: 'text.secondary' }}>
              <CheckCircle sx={{ fontSize: 48, opacity: 0.5, mb: 2 }} />
              <Typography>No high-priority cases</Typography>
            </Box>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {userCases
                .filter(c => (c.priority === 'Urgent' || c.priority === 'High') && c.status !== 'Closed')
                .slice(0, 5)
                .map(caseItem => (
                  <Box 
                    key={caseItem.id} 
                    sx={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      p: 2,
                      borderBottom: '1px solid',
                      borderColor: 'divider',
                      '&:last-child': { borderBottom: 0 },
                      '&:hover': { bgcolor: 'action.hover' },
                      borderRadius: 1,
                      transition: 'background-color 0.2s'
                    }}
                  >
                    <Box>
                      <Box sx={{ display: 'flex', gap: 1, mb: 0.5, flexWrap: 'wrap' }}>
                        <Typography variant="body2" fontWeight={600} sx={{ fontFamily: 'monospace' }}>
                          {caseItem.id}
                        </Typography>
                        <Chip
                          label={caseItem.riskLevel}
                          color={caseItem.riskLevel === 'Critical' ? 'error' : 'default'}
                          size="small"
                        />
                        <Chip label={caseItem.status} variant="outlined" size="small" />
                        {caseItem.clientData?.isEmployee && (
                          <Chip label="Employee" color="secondary" size="small" />
                        )}
                      </Box>
                      <Typography variant="body2" fontWeight={500}>
                        {caseItem.clientName}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {caseItem.caseType} • {caseItem.clientData?.lineOfBusiness}
                      </Typography>
                    </Box>
                    <Box sx={{ textAlign: 'right' }}>
                      <Typography variant="caption" color="text.secondary" display="block">
                        Due: {caseItem.dueDate}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" display="block">
                        Assigned: {caseItem.assignedTo}
                      </Typography>
                    </Box>
                  </Box>
                ))}
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}