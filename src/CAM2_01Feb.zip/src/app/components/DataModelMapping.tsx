import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Paper,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Alert,
  AlertTitle,
} from '@mui/material';
import {
  ExpandMore,
  Dashboard as DashboardIcon,
  List,
  Assignment,
  PersonAdd,
  BarChart,
  Notifications,
  Settings,
  Storage,
} from '@mui/icons-material';

interface TableMapping {
  tableName: string;
  description: string;
  fields: string[];
}

interface ScreenMapping {
  screenName: string;
  icon: React.ReactNode;
  description: string;
  tables: TableMapping[];
}

const screenMappings: ScreenMapping[] = [
  {
    screenName: 'Dashboard',
    icon: <DashboardIcon fontSize="small" />,
    description: 'Overview of case statistics, distributions, and high-priority cases',
    tables: [
      {
        tableName: 'Cases',
        description: 'Main case table with all case records',
        fields: ['case_id', 'case_type', 'status', 'priority', 'assigned_to', 'created_date', 'due_date', 'lob', 'risk_level']
      },
      {
        tableName: 'Clients',
        description: 'Client/customer information',
        fields: ['client_id', 'legal_name', 'risk_rating', 'lob', 'sales_owner', 'refresh_due_date']
      },
      {
        tableName: 'Case_Activities',
        description: 'Activity history and timeline events',
        fields: ['activity_id', 'case_id', 'activity_type', 'activity_date', 'user', 'description']
      }
    ]
  },
  {
    screenName: 'My Worklist',
    icon: <List fontSize="small" />,
    description: 'Personal worklist showing cases assigned to the current user',
    tables: [
      {
        tableName: 'Cases',
        description: 'Filtered by assigned_to = current user',
        fields: ['case_id', 'case_type', 'status', 'priority', 'client_name', 'due_date', 'days_open', 'lob']
      },
      {
        tableName: 'Users',
        description: 'User information and entitlements',
        fields: ['user_id', 'name', 'role', 'entitlements', 'lob_access']
      },
      {
        tableName: 'Case_Alerts',
        description: 'Active alerts associated with cases',
        fields: ['alert_id', 'case_id', 'alert_type', 'severity', 'alert_date', 'description']
      }
    ]
  },
  {
    screenName: 'Case Workbasket',
    icon: <Assignment fontSize="small" />,
    description: 'Comprehensive view of all cases with filtering and sorting',
    tables: [
      {
        tableName: 'Cases',
        description: 'All cases based on user entitlements (LOB, 312/CAM access)',
        fields: ['case_id', 'case_type', 'status', 'priority', 'assigned_to', 'client_name', 'created_date', 'due_date', 'lob', 'risk_level', 'aum']
      },
      {
        tableName: 'Clients',
        description: 'Client details for each case',
        fields: ['client_id', 'legal_name', 'risk_rating', 'aum', 'sales_owner']
      },
      {
        tableName: 'Case_312_Data',
        description: 'CAM 312 specific fields and responses',
        fields: ['case_id', 'model_alert', 'alert_type', 'model_output', 'analyst_review', 'disposition']
      },
      {
        tableName: 'Case_CAM_Data',
        description: 'CAM case specific fields and responses',
        fields: ['case_id', 'trigger_reason', 'gfc_cases', 'prior_cam_review', 'sales_owner_feedback']
      }
    ]
  },
  {
    screenName: 'Case Details',
    icon: <Assignment fontSize="small" />,
    description: 'Detailed view of individual case with all sections and responses',
    tables: [
      {
        tableName: 'Cases',
        description: 'Primary case information',
        fields: ['case_id', 'case_type', 'status', 'priority', 'assigned_to', 'client_name', 'created_date', 'due_date', 'completion_date']
      },
      {
        tableName: 'Clients',
        description: 'Full client profile',
        fields: ['client_id', 'legal_name', 'risk_rating', 'aum', 'lob', 'sales_owner', 'refresh_due_date', 'global_dga_due_date']
      },
      {
        tableName: 'Case_312_Data',
        description: 'Complete 312 response sections',
        fields: ['case_id', 'model_alert', 'alert_details', 'analyst_review', 'documentation', 'disposition', 'rationale']
      },
      {
        tableName: 'Case_CAM_Data',
        description: 'Complete CAM response sections',
        fields: ['case_id', 'trigger_reason', 'gfc_case_review', 'prior_reviews', 'sales_feedback', 'disposition']
      },
      {
        tableName: 'Case_Activities',
        description: 'Complete activity timeline',
        fields: ['activity_id', 'case_id', 'activity_type', 'activity_date', 'user', 'status_from', 'status_to', 'description', 'comments']
      },
      {
        tableName: 'Case_Alerts',
        description: 'All alerts and notifications for the case',
        fields: ['alert_id', 'case_id', 'alert_type', 'severity', 'alert_date', 'description', 'acknowledged']
      },
      {
        tableName: 'Case_Comments',
        description: 'Comments and notes thread',
        fields: ['comment_id', 'case_id', 'user', 'comment_date', 'comment_text', 'visibility']
      }
    ]
  },
  {
    screenName: 'Population Identification',
    icon: <PersonAdd fontSize="small" />,
    description: 'Logic for identifying which clients enter the 312/CAM population',
    tables: [
      {
        tableName: 'Clients',
        description: 'All client records evaluated for triggers',
        fields: ['client_id', 'legal_name', 'lob', 'risk_rating', 'refresh_due_date', 'days_to_refresh', 'global_dga_due_date', 'refresh_anniversary_month']
      },
      {
        tableName: 'Population_Triggers',
        description: 'Configuration of LOB-specific trigger rules',
        fields: ['trigger_id', 'lob', 'trigger_type', 'threshold_days', 'risk_level_filter', 'description']
      },
      {
        tableName: 'Population_History',
        description: 'Historical record of population identification runs',
        fields: ['run_id', 'run_date', 'clients_evaluated', 'clients_triggered', 'lob', 'trigger_reason']
      },
      {
        tableName: 'Manual_Uploads',
        description: 'Manually uploaded exception cases',
        fields: ['upload_id', 'client_id', 'uploaded_by', 'upload_date', 'reason', 'case_type']
      }
    ]
  },
  {
    screenName: 'Case Creation Logic',
    icon: <Settings fontSize="small" />,
    description: 'Engine that evaluates 312/CAM rules and determines case outcomes',
    tables: [
      {
        tableName: 'Clients',
        description: 'Client data for rule evaluation',
        fields: ['client_id', 'legal_name', 'lob', 'risk_rating', 'has_312_flag', 'has_312_model_alert', 'days_to_refresh']
      },
      {
        tableName: 'Model_312_Alerts',
        description: '312 model output and alerts',
        fields: ['alert_id', 'client_id', 'alert_date', 'alert_type', 'model_score', 'model_output']
      },
      {
        tableName: 'GFC_Cases',
        description: 'GFC search results for CAM evaluation',
        fields: ['gfc_case_id', 'client_id', 'case_date', 'is_in_scope', 'case_type', 'disposition']
      },
      {
        tableName: 'Prior_CAM_Reviews',
        description: 'Historical CAM case reviews',
        fields: ['review_id', 'client_id', 'review_date', 'case_id', 'reviewed_gfc_cases', 'disposition']
      },
      {
        tableName: 'Case_Creation_Rules',
        description: 'Configuration of auto-close and full review rules',
        fields: ['rule_id', 'case_type', 'rule_name', 'condition', 'outcome', 'priority']
      },
      {
        tableName: 'Cases',
        description: 'Created cases with auto-complete flags',
        fields: ['case_id', 'case_type', 'status', 'auto_complete_flag', 'creation_date', 'creation_reason']
      }
    ]
  },
  {
    screenName: 'Reports',
    icon: <BarChart fontSize="small" />,
    description: 'Analytics and reporting on case metrics and performance',
    tables: [
      {
        tableName: 'Cases',
        description: 'Aggregated case data for reporting',
        fields: ['case_id', 'case_type', 'status', 'priority', 'created_date', 'completion_date', 'assigned_to', 'lob', 'disposition']
      },
      {
        tableName: 'Case_Activities',
        description: 'Activity data for cycle time analysis',
        fields: ['activity_id', 'case_id', 'activity_type', 'activity_date', 'status_from', 'status_to']
      },
      {
        tableName: 'Report_Metrics',
        description: 'Pre-calculated metrics and KPIs',
        fields: ['metric_id', 'metric_name', 'metric_value', 'calculation_date', 'dimension', 'period']
      },
      {
        tableName: 'Users',
        description: 'User data for workload and productivity reports',
        fields: ['user_id', 'name', 'role', 'team', 'active_cases', 'completed_cases']
      }
    ]
  },
  {
    screenName: 'Notifications',
    icon: <Notifications fontSize="small" />,
    description: 'Email notifications and system alerts',
    tables: [
      {
        tableName: 'Notification_Queue',
        description: 'Pending notifications to be sent',
        fields: ['notification_id', 'notification_type', 'recipient', 'subject', 'case_id', 'status', 'scheduled_date']
      },
      {
        tableName: 'Notification_History',
        description: 'Log of sent notifications',
        fields: ['history_id', 'notification_id', 'sent_date', 'recipient', 'delivery_status', 'case_id']
      },
      {
        tableName: 'Notification_Templates',
        description: 'Email templates for different notification types',
        fields: ['template_id', 'template_name', 'notification_type', 'subject_template', 'body_template']
      },
      {
        tableName: 'Cases',
        description: 'Case data to populate notification content',
        fields: ['case_id', 'case_type', 'status', 'assigned_to', 'client_name', 'priority', 'due_date']
      }
    ]
  },
  {
    screenName: 'System Integrations',
    icon: <Settings fontSize="small" />,
    description: 'Integration endpoints and data exchange with external systems',
    tables: [
      {
        tableName: 'Integration_Config',
        description: 'Configuration for external system connections',
        fields: ['integration_id', 'system_name', 'endpoint_url', 'auth_type', 'status', 'last_sync_date']
      },
      {
        tableName: 'Integration_Logs',
        description: 'Log of data exchanges and API calls',
        fields: ['log_id', 'integration_id', 'operation', 'timestamp', 'status', 'records_processed', 'error_message']
      },
      {
        tableName: 'Data_Sync_Status',
        description: 'Status of data synchronization jobs',
        fields: ['sync_id', 'source_system', 'sync_date', 'records_synced', 'status', 'next_sync_date']
      }
    ]
  },
  {
    screenName: 'Roles & Entitlements',
    icon: <Settings fontSize="small" />,
    description: 'User role definitions and access control configuration',
    tables: [
      {
        tableName: 'Roles',
        description: 'Role definitions and permissions',
        fields: ['role_id', 'role_name', 'role_type', 'description', 'permissions', 'user_count']
      },
      {
        tableName: 'Users',
        description: 'User accounts and assigned roles',
        fields: ['user_id', 'name', 'email', 'role_id', 'status', 'manager', 'access_request_date']
      },
      {
        tableName: 'Entitlements',
        description: 'Granular entitlements (312, CAM, LOB access)',
        fields: ['entitlement_id', 'user_id', 'has_312_access', 'has_cam_access', 'lob_access', 'has_employee_case_access', 'has_manual_case_creation']
      },
      {
        tableName: 'Audit_Log',
        description: 'Audit trail of access changes',
        fields: ['audit_id', 'user_id', 'change_type', 'change_date', 'changed_by', 'old_value', 'new_value']
      }
    ]
  }
];

export function DataModelMapping() {
  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          Data Model & Table Mapping
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Documentation showing which database tables are used by each screen in the application
        </Typography>
      </Box>

      {/* Info Alert */}
      <Alert severity="info" sx={{ mb: 3 }}>
        <AlertTitle>Database Architecture Overview</AlertTitle>
        This page maps the application screens to their underlying database tables and data sources. 
        Each screen may use multiple tables to construct its view and functionality. Understanding these 
        relationships is critical for data governance, security controls, and system maintenance.
      </Alert>

      {/* Summary Stats */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Total Screens
              </Typography>
              <Typography variant="h4" color="primary.main">
                {screenMappings.length}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Unique Tables
              </Typography>
              <Typography variant="h4" color="primary.main">
                {new Set(screenMappings.flatMap(s => s.tables.map(t => t.tableName))).size}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Total Table References
              </Typography>
              <Typography variant="h4" color="primary.main">
                {screenMappings.reduce((sum, s) => sum + s.tables.length, 0)}
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Screen Mappings */}
      <Typography variant="h6" gutterBottom sx={{ mb: 2 }}>
        Screen-to-Table Mappings
      </Typography>

      {screenMappings.map((screen, index) => (
        <Accordion key={index} defaultExpanded={index === 0}>
          <AccordionSummary expandIcon={<ExpandMore />}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
              <Box sx={{ color: 'primary.main' }}>
                {screen.icon}
              </Box>
              <Box sx={{ flex: 1 }}>
                <Typography variant="h6">
                  {screen.screenName}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {screen.description}
                </Typography>
              </Box>
              <Chip
                label={`${screen.tables.length} table${screen.tables.length !== 1 ? 's' : ''}`}
                color="primary"
                size="small"
              />
            </Box>
          </AccordionSummary>
          <AccordionDetails>
            <TableContainer component={Paper} variant="outlined">
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell><strong>Table Name</strong></TableCell>
                    <TableCell><strong>Purpose</strong></TableCell>
                    <TableCell><strong>Key Fields</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {screen.tables.map((table, tIndex) => (
                    <TableRow key={tIndex} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Storage fontSize="small" color="action" />
                          <Typography variant="body2" fontWeight={600} sx={{ fontFamily: 'monospace' }}>
                            {table.tableName}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="text.secondary">
                          {table.description}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                          {table.fields.map((field, fIndex) => (
                            <Chip
                              key={fIndex}
                              label={field}
                              size="small"
                              variant="outlined"
                              sx={{ fontFamily: 'monospace', fontSize: '0.7rem' }}
                            />
                          ))}
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </AccordionDetails>
        </Accordion>
      ))}

      {/* Commonly Used Tables Section */}
      <Card sx={{ mt: 4 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Most Frequently Used Tables
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Tables referenced across multiple screens
          </Typography>
          
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell><strong>Table Name</strong></TableCell>
                  <TableCell align="right"><strong>Screen References</strong></TableCell>
                  <TableCell><strong>Used In</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(() => {
                  const tableCounts = new Map<string, { count: number; screens: string[] }>();
                  screenMappings.forEach(screen => {
                    screen.tables.forEach(table => {
                      const existing = tableCounts.get(table.tableName) || { count: 0, screens: [] };
                      existing.count++;
                      existing.screens.push(screen.screenName);
                      tableCounts.set(table.tableName, existing);
                    });
                  });
                  
                  return Array.from(tableCounts.entries())
                    .sort((a, b) => b[1].count - a[1].count)
                    .filter(([_, data]) => data.count > 1)
                    .map(([tableName, data]) => (
                      <TableRow key={tableName} hover>
                        <TableCell>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Storage fontSize="small" color="primary" />
                            <Typography variant="body2" fontWeight={600} sx={{ fontFamily: 'monospace' }}>
                              {tableName}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell align="right">
                          <Chip
                            label={data.count}
                            color="primary"
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                            {data.screens.map((screen, idx) => (
                              <Chip
                                key={idx}
                                label={screen}
                                size="small"
                                variant="outlined"
                              />
                            ))}
                          </Box>
                        </TableCell>
                      </TableRow>
                    ));
                })()}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Box>
  );
}