import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Alert,
  Paper,
  Tabs,
  Tab,
  Button,
  Divider,
} from '@mui/material';
import {
  ExpandMore,
  Storage,
  Description,
  AccountTree,
  Timeline,
  TableChart,
  Download,
  SwapHoriz,
  Hub,
  Api,
} from '@mui/icons-material';
import {
  summaryFields,
  clientFields,
  businessRulesSections,
  dataSourceSystems,
} from '@/app/data/populationDataDictionary';
import { databaseTables } from '@/app/data/databaseTables';
import { 
  populationFieldMappings, 
  caseFieldMappings, 
  entityRelationships, 
  apiEndpointMappings 
} from '@/app/data/dataModelMapping';

export function PopulationDataDictionary() {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleExportCSV = () => {
    // Create CSV content
    const csvRows = [
      ['Field Name', 'Display Name', 'Data Type', 'Source', 'Valid Values', 'Description', 'Business Rules', 'Required', 'Example'].join(','),
      ...clientFields.map(field => [
        field.fieldName,
        field.displayName,
        field.dataType,
        field.source,
        field.validValues || '',
        `"${field.description}"`,
        `"${field.businessRules || ''}"`,
        field.required ? 'Yes' : 'No',
        field.example || ''
      ].join(','))
    ];

    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'population_data_dictionary.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Box>
            <Typography variant="h5" fontWeight={600} color="primary" gutterBottom>
              Data Model Mapping & Dictionary
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Comprehensive documentation of data fields, database tables, field mappings, relationships, and API endpoints
            </Typography>
          </Box>
          <Button
            variant="outlined"
            startIcon={<Download />}
            onClick={handleExportCSV}
            sx={{ textTransform: 'none' }}
          >
            Export CSV
          </Button>
        </Box>

        {/* Tab Navigation */}
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange} 
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab icon={<Description />} iconPosition="start" label="Data Dictionary" />
          <Tab icon={<TableChart />} iconPosition="start" label="Database Tables" />
          <Tab icon={<SwapHoriz />} iconPosition="start" label="Field Mapping" />
          <Tab icon={<Hub />} iconPosition="start" label="Relationships" />
          <Tab icon={<Api />} iconPosition="start" label="API Endpoints" />
          <Tab icon={<AccountTree />} iconPosition="start" label="Business Rules" />
          <Tab icon={<Storage />} iconPosition="start" label="Data Sources" />
        </Tabs>
      </Box>

      {/* Tab 0: Data Dictionary */}
      {tabValue === 0 && (
        <Box>
          {/* Overview Alert */}
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight={600} gutterBottom>
              About This Data Dictionary
            </Typography>
            <Typography variant="body2">
              This document defines all data elements used in the Population Identification screen, including field definitions, 
              data types, source systems, valid values, and business rules. Use this as a reference for data mapping, 
              integration development, and business analysis.
            </Typography>
          </Alert>

          {/* Summary Statistics Fields */}
          <Accordion defaultExpanded>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Timeline color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  Summary Statistics Fields
                </Typography>
                <Chip label={`${summaryFields.length} fields`} size="small" color="primary" />
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Field Name</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Display Name</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Data Type</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Source</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Description</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Business Rules</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }} align="center">Required</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {summaryFields.map((field, idx) => (
                      <TableRow key={idx} hover sx={{ '&:nth-of-type(odd)': { bgcolor: 'action.hover' } }}>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" fontWeight={600} color="primary">
                            {field.fieldName}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {field.displayName}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip label={field.dataType} size="small" color="info" variant="outlined" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" color="text.secondary">
                            {field.source}
                          </Typography>
                        </TableCell>
                        <TableCell sx={{ maxWidth: 300 }}>
                          <Typography variant="body2">{field.description}</Typography>
                          {field.example && (
                            <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 0.5 }}>
                              Example: <strong>{field.example}</strong>
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell sx={{ maxWidth: 300 }}>
                          <Typography variant="body2" color="text.secondary">
                            {field.businessRules}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={field.required ? 'Yes' : 'No'}
                            size="small"
                            color={field.required ? 'error' : 'default'}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </AccordionDetails>
          </Accordion>

          {/* Client-Level Fields */}
          <Accordion defaultExpanded sx={{ mt: 2 }}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Description color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  Client-Level Data Fields
                </Typography>
                <Chip label={`${clientFields.length} fields`} size="small" color="primary" />
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Field Name</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Display Name</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Data Type</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Source</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Valid Values</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Description & Business Rules</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }} align="center">Required</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {clientFields.map((field, idx) => (
                      <TableRow key={idx} hover sx={{ '&:nth-of-type(odd)': { bgcolor: 'action.hover' } }}>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" fontWeight={600} color="primary">
                            {field.fieldName}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {field.displayName}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip label={field.dataType} size="small" color="info" variant="outlined" />
                        </TableCell>
                        <TableCell sx={{ maxWidth: 150 }}>
                          <Typography variant="body2" color="text.secondary">
                            {field.source}
                          </Typography>
                        </TableCell>
                        <TableCell sx={{ maxWidth: 120 }}>
                          <Typography variant="body2" color="primary.main" fontWeight={500}>
                            {field.validValues}
                          </Typography>
                        </TableCell>
                        <TableCell sx={{ maxWidth: 400 }}>
                          <Typography variant="body2" sx={{ mb: 1 }}>
                            {field.description}
                          </Typography>
                          {field.businessRules && (
                            <Alert severity="warning" sx={{ py: 0.5, px: 1, mb: 1 }}>
                              <Typography variant="body2" fontSize="0.75rem">
                                <strong>Rule:</strong> {field.businessRules}
                              </Typography>
                            </Alert>
                          )}
                          {field.example && (
                            <Typography variant="caption" color="text.secondary" display="block">
                              Example: <strong>{field.example}</strong>
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={field.required ? 'Yes' : 'No'}
                            size="small"
                            color={field.required ? 'error' : 'default'}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </AccordionDetails>
          </Accordion>
        </Box>
      )}

      {/* Tab 1: Database Tables */}
      {tabValue === 1 && (
        <Box>
          {/* Overview Alert */}
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight={600} gutterBottom>
              About Database Tables
            </Typography>
            <Typography variant="body2">
              This section defines all database tables in the CAM Case Management System, including table structure, columns, 
              data types, constraints, and indexes. This serves as a reference for database administration, development, and integration.
            </Typography>
          </Alert>

          {/* Database Tables */}
          {databaseTables.map((table, tableIdx) => (
            <Accordion key={tableIdx} defaultExpanded={tableIdx === 0}>
              <AccordionSummary expandIcon={<ExpandMore />}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                  <TableChart color="primary" />
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="h6" fontWeight={600} color="primary">
                      {table.tableName}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {table.purpose}
                    </Typography>
                  </Box>
                  <Chip label={`${table.columns.length} columns`} size="small" color="primary" variant="outlined" />
                </Box>
              </AccordionSummary>
              <AccordionDetails>
                {/* Table Metadata */}
                <Box sx={{ mb: 3, p: 2, bgcolor: 'action.hover', borderRadius: 1 }}>
                  <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2 }}>
                    <Box>
                      <Typography variant="caption" color="text.secondary" fontWeight={600}>
                        Primary Key
                      </Typography>
                      <Typography variant="body2" fontFamily="monospace" color="primary.main">
                        {table.primaryKey}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary" fontWeight={600}>
                        Estimated Rows
                      </Typography>
                      <Typography variant="body2">{table.rowCountEstimate}</Typography>
                    </Box>
                    <Box>
                      <Typography variant="caption" color="text.secondary" fontWeight={600}>
                        Indexes
                      </Typography>
                      <Typography variant="body2">{table.indexes.length} indexes</Typography>
                    </Box>
                  </Box>
                  {table.indexes.length > 0 && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="caption" color="text.secondary" fontWeight={600} gutterBottom>
                        Index List
                      </Typography>
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 1 }}>
                        {table.indexes.map((index, idxIdx) => (
                          <Chip key={idxIdx} label={index} size="small" variant="outlined" />
                        ))}
                      </Box>
                    </Box>
                  )}
                </Box>

                {/* Column Definitions */}
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow sx={{ bgcolor: 'primary.main' }}>
                        <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Column Name</TableCell>
                        <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Data Type</TableCell>
                        <TableCell sx={{ color: 'white', fontWeight: 'bold' }} align="center">Nullable</TableCell>
                        <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Default</TableCell>
                        <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Constraints</TableCell>
                        <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Description</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {table.columns.map((column, colIdx) => (
                        <TableRow key={colIdx} hover sx={{ '&:nth-of-type(odd)': { bgcolor: 'action.hover' } }}>
                          <TableCell>
                            <Typography variant="body2" fontFamily="monospace" fontWeight={600} color={column.constraints?.includes('PK') ? 'error.main' : 'primary'}>
                              {column.columnName}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip label={column.dataType} size="small" color="info" variant="outlined" />
                          </TableCell>
                          <TableCell align="center">
                            <Chip
                              label={column.nullable ? 'Yes' : 'No'}
                              size="small"
                              color={column.nullable ? 'default' : 'error'}
                              variant="outlined"
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary" fontStyle={column.defaultValue ? 'normal' : 'italic'}>
                              {column.defaultValue || '-'}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            {column.constraints ? (
                              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                {column.constraints.split(',').map((constraint, cIdx) => (
                                  <Chip
                                    key={cIdx}
                                    label={constraint.trim()}
                                    size="small"
                                    color={constraint.includes('PK') ? 'error' : constraint.includes('FK') ? 'warning' : 'default'}
                                  />
                                ))}
                              </Box>
                            ) : (
                              <Typography variant="body2" color="text.secondary" fontStyle="italic">
                                -
                              </Typography>
                            )}
                          </TableCell>
                          <TableCell sx={{ maxWidth: 400 }}>
                            <Typography variant="body2">{column.description}</Typography>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </AccordionDetails>
            </Accordion>
          ))}
        </Box>
      )}

      {/* Tab 2: Field Mapping */}
      {tabValue === 2 && (
        <Box>
          {/* Overview Alert */}
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight={600} gutterBottom>
              About Field Mapping
            </Typography>
            <Typography variant="body2">
              This section maps UI fields to API fields to database columns, showing the complete data flow from database 
              to user interface. Use this for integration development, API design, and understanding data transformations.
            </Typography>
          </Alert>

          {/* Population Field Mappings */}
          <Accordion defaultExpanded>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <SwapHoriz color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  Population Identification Field Mappings
                </Typography>
                <Chip label={`${populationFieldMappings.length} mappings`} size="small" color="primary" />
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>UI Field</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>API Field</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Database Table</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Database Column</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Data Type</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Transformation</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Notes</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {populationFieldMappings.map((mapping, idx) => (
                      <TableRow key={idx} hover sx={{ '&:nth-of-type(odd)': { bgcolor: 'action.hover' } }}>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {mapping.uiDisplayName}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" fontFamily="monospace">
                            {mapping.uiField}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" color="primary">
                            {mapping.apiField}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip label={mapping.databaseTable} size="small" color="secondary" variant="outlined" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" color="error.main">
                            {mapping.databaseColumn}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip label={mapping.dataType} size="small" color="info" variant="outlined" />
                        </TableCell>
                        <TableCell sx={{ maxWidth: 200 }}>
                          <Typography variant="body2" color="text.secondary">
                            {mapping.transformation}
                          </Typography>
                          {mapping.calculation && (
                            <Alert severity="success" sx={{ py: 0.5, px: 1, mt: 1 }}>
                              <Typography variant="caption">
                                <strong>Calc:</strong> {mapping.calculation}
                              </Typography>
                            </Alert>
                          )}
                        </TableCell>
                        <TableCell sx={{ maxWidth: 250 }}>
                          <Typography variant="body2">{mapping.notes}</Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </AccordionDetails>
          </Accordion>

          {/* Case Field Mappings */}
          <Accordion sx={{ mt: 2 }}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <SwapHoriz color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  Case Management Field Mappings
                </Typography>
                <Chip label={`${caseFieldMappings.length} mappings`} size="small" color="primary" />
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>UI Field</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>API Field</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Database Table</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Database Column</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Data Type</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Transformation</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Notes</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {caseFieldMappings.map((mapping, idx) => (
                      <TableRow key={idx} hover sx={{ '&:nth-of-type(odd)': { bgcolor: 'action.hover' } }}>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {mapping.uiDisplayName}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" fontFamily="monospace">
                            {mapping.uiField}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" color="primary">
                            {mapping.apiField}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip label={mapping.databaseTable} size="small" color="secondary" variant="outlined" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" color="error.main">
                            {mapping.databaseColumn}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip label={mapping.dataType} size="small" color="info" variant="outlined" />
                        </TableCell>
                        <TableCell sx={{ maxWidth: 200 }}>
                          <Typography variant="body2" color="text.secondary">
                            {mapping.transformation}
                          </Typography>
                          {mapping.calculation && (
                            <Alert severity="success" sx={{ py: 0.5, px: 1, mt: 1 }}>
                              <Typography variant="caption">
                                <strong>Calc:</strong> {mapping.calculation}
                              </Typography>
                            </Alert>
                          )}
                        </TableCell>
                        <TableCell sx={{ maxWidth: 250 }}>
                          <Typography variant="body2">{mapping.notes}</Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </AccordionDetails>
          </Accordion>
        </Box>
      )}

      {/* Tab 3: Relationships */}
      {tabValue === 3 && (
        <Box>
          {/* Overview Alert */}
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight={600} gutterBottom>
              About Entity Relationships
            </Typography>
            <Typography variant="body2">
              This section documents the relationships between database tables, including foreign keys, cardinality, 
              and referential integrity constraints. Use this for database design, query optimization, and understanding data dependencies.
            </Typography>
          </Alert>

          {/* Entity Relationships */}
          <Card variant="outlined">
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                <Hub color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  Database Entity Relationships
                </Typography>
                <Chip label={`${entityRelationships.length} relationships`} size="small" color="primary" />
              </Box>

              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'primary.main' }}>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>From Table</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>From Column (FK)</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }} align="center">→</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>To Table</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>To Column (PK)</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Relationship Type</TableCell>
                      <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Description</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {entityRelationships.map((rel, idx) => (
                      <TableRow key={idx} hover sx={{ '&:nth-of-type(odd)': { bgcolor: 'action.hover' } }}>
                        <TableCell>
                          <Chip label={rel.fromTable} size="small" color="secondary" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" color="warning.main">
                            {rel.fromColumn}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <SwapHoriz color="primary" />
                        </TableCell>
                        <TableCell>
                          <Chip label={rel.toTable} size="small" color="secondary" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontFamily="monospace" color="error.main">
                            {rel.toColumn}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={rel.relationshipType} 
                            size="small" 
                            color={rel.relationshipType === 'One-to-One' ? 'success' : rel.relationshipType === 'One-to-Many' ? 'info' : 'warning'}
                          />
                        </TableCell>
                        <TableCell sx={{ maxWidth: 400 }}>
                          <Typography variant="body2">{rel.description}</Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>

          {/* Relationship Diagram Description */}
          <Card sx={{ mt: 3 }} variant="outlined">
            <CardContent>
              <Typography variant="h6" fontWeight={600} color="primary" gutterBottom>
                Key Relationship Patterns
              </Typography>
              <Box component="ul" sx={{ pl: 2 }}>
                <Typography component="li" variant="body2" sx={{ mb: 1 }}>
                  <strong>CAM_PARTY_MASTER</strong> is the central entity - all cases, triggers, and GFC cases reference it via PARTY_ID
                </Typography>
                <Typography component="li" variant="body2" sx={{ mb: 1 }}>
                  <strong>CAM_POPULATION_TRIGGER</strong> serves as the initiating event that creates both 312 and CAM cases
                </Typography>
                <Typography component="li" variant="body2" sx={{ mb: 1 }}>
                  <strong>CAM_312_CASES</strong> and <strong>CAM_CASES</strong> can be linked when both exist for the same party
                </Typography>
                <Typography component="li" variant="body2" sx={{ mb: 1 }}>
                  <strong>CAM_GFC_CASES</strong> are monitored separately but aggregated for CAM case auto-closure logic
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>CAM_CASE_GFC_LINK</strong> is a junction table for many-to-many relationships between CAM and GFC cases
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Box>
      )}

      {/* Tab 4: API Endpoints */}
      {tabValue === 4 && (
        <Box>
          {/* Overview Alert */}
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight={600} gutterBottom>
              About API Endpoints
            </Typography>
            <Typography variant="body2">
              This section documents all REST API endpoints, including HTTP methods, request/response formats, database queries, 
              and business logic. Use this for API development, integration testing, and frontend development.
            </Typography>
          </Alert>

          {/* API Endpoints */}
          {apiEndpointMappings.map((endpoint, idx) => (
            <Accordion key={idx} defaultExpanded={idx === 0}>
              <AccordionSummary expandIcon={<ExpandMore />}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                  <Api color="primary" />
                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                      <Chip 
                        label={endpoint.method} 
                        size="small" 
                        color={endpoint.method === 'GET' ? 'info' : endpoint.method === 'POST' ? 'success' : 'warning'}
                      />
                      <Typography variant="body1" fontFamily="monospace" fontWeight={600} color="primary">
                        {endpoint.endpoint}
                      </Typography>
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                      {endpoint.purpose}
                    </Typography>
                  </Box>
                </Box>
              </AccordionSummary>
              <AccordionDetails>
                {/* Database Tables Used */}
                <Box sx={{ mb: 3, p: 2, bgcolor: 'action.hover', borderRadius: 1 }}>
                  <Typography variant="body2" fontWeight={600} gutterBottom>
                    Database Tables
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    <Chip label={`Primary: ${endpoint.primaryTable}`} size="small" color="error" />
                    {endpoint.relatedTables.map((table, tIdx) => (
                      <Chip key={tIdx} label={table} size="small" variant="outlined" />
                    ))}
                  </Box>
                </Box>

                {/* Response Fields */}
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" fontWeight={600} gutterBottom>
                    Response Fields
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {endpoint.responseFields.map((field, fIdx) => (
                      <Chip key={fIdx} label={field} size="small" color="info" variant="outlined" />
                    ))}
                  </Box>
                </Box>

                {/* Calculations & Logic */}
                {endpoint.calculations.length > 0 && (
                  <Box>
                    <Typography variant="body2" fontWeight={600} gutterBottom>
                      Calculations & Business Logic
                    </Typography>
                    <Box component="ul" sx={{ pl: 2, mb: 0 }}>
                      {endpoint.calculations.map((calc, cIdx) => (
                        <Typography component="li" variant="body2" key={cIdx} sx={{ mb: 0.5 }}>
                          {calc}
                        </Typography>
                      ))}
                    </Box>
                  </Box>
                )}
              </AccordionDetails>
            </Accordion>
          ))}
        </Box>
      )}

      {/* Tab 5: Business Rules */}
      {tabValue === 5 && (
        <Box>
          {/* Overview Alert */}
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight={600} gutterBottom>
              About Business Rules & Logic
            </Typography>
            <Typography variant="body2">
              This document defines all business rules and logic used in the Population Identification screen, including 
              validation rules, calculation methods, and decision-making processes. Use this as a reference for business 
              analysis, integration development, and system design.
            </Typography>
          </Alert>

          {/* Business Rules */}
          <Accordion defaultExpanded>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <AccountTree color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  Business Rules & Logic
                </Typography>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {businessRulesSections.map((section, idx) => (
                  <Card key={idx} variant="outlined">
                    <CardContent>
                      <Typography variant="body1" fontWeight={600} color="primary" gutterBottom>
                        {section.title}
                      </Typography>
                      <Box component="ul" sx={{ pl: 2, mb: 0 }}>
                        {section.rules.map((rule, rIdx) => (
                          <Typography component="li" variant="body2" key={rIdx} sx={{ mb: 0.5 }}>
                            {rule}
                          </Typography>
                        ))}
                      </Box>
                    </CardContent>
                  </Card>
                ))}
              </Box>
            </AccordionDetails>
          </Accordion>
        </Box>
      )}

      {/* Tab 6: Data Source Systems */}
      {tabValue === 6 && (
        <Box>
          {/* Overview Alert */}
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight={600} gutterBottom>
              About Data Source Systems
            </Typography>
            <Typography variant="body2">
              This document defines all data source systems used in the Population Identification screen, including 
              system names, descriptions, and data flow. Use this as a reference for data integration, 
              system design, and business analysis.
            </Typography>
          </Alert>

          {/* Data Source Systems */}
          <Card sx={{ mt: 3, border: '2px solid', borderColor: 'primary.main' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <Storage color="primary" />
                <Typography variant="h6" fontWeight={600}>
                  Data Source Systems Reference
                </Typography>
              </Box>

              <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 2 }}>
                {dataSourceSystems.map((system, idx) => (
                  <Box
                    key={idx}
                    sx={{
                      bgcolor: `${system.color}.lighter`,
                      p: 2,
                      borderRadius: 1,
                    }}
                  >
                    <Typography variant="body2" fontWeight={600} color={`${system.color}.main`} gutterBottom>
                      {system.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {system.description}
                    </Typography>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Box>
      )}
    </Box>
  );
}
