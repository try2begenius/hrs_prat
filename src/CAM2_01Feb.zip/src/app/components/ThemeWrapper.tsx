import { ReactNode } from 'react';
import { ThemeProvider } from '@mui/material';
import { theme } from '@/styles/theme';

interface ThemeWrapperProps {
  children: ReactNode;
  [key: string]: any; // Accept any additional props
}

// This component wraps the MUI ThemeProvider to prevent Figma's data-* attributes
// from being passed down and causing prop-type warnings
export function ThemeWrapper({ children, ...rest }: ThemeWrapperProps) {
  // Filter out Figma-specific data-fg-* attributes
  const filteredProps = Object.keys(rest).reduce((acc, key) => {
    if (!key.startsWith('data-fg-')) {
      acc[key] = rest[key];
    }
    return acc;
  }, {} as Record<string, any>);

  return (
    <ThemeProvider theme={theme} {...filteredProps}>
      {children}
    </ThemeProvider>
  );
}