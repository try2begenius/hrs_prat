import { Box, Card, CardContent, Typography, Chip, Tabs, Tab, Paper } from '@mui/material';
import { 
  Warning, 
  CheckCircle, 
  Schedule, 
  Cancel, 
  ArrowForward, 
  ArrowDownward, 
  People, 
  Description, 
  TrendingUp 
} from '@mui/icons-material';
import { useState } from 'react';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

export function WorkflowDiagram() {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          312 CAM Workflow Diagram
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Visual representation of the complete case lifecycle from creation through closure
        </Typography>
      </Box>

      <Tabs value={tabValue} onChange={handleTabChange} sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tab label="312 Case Flow" />
        <Tab label="Sales Review Flow" />
        <Tab label="CAM Escalation Flow" />
      </Tabs>

      {/* 312 CASE WORKFLOW */}
      <TabPanel value={tabValue} index={0}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              312 Case Workflow - Complete Lifecycle
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Shows all possible paths from case creation to completion
            </Typography>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {/* START */}
              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                <Paper sx={{ px: 4, py: 2, bgcolor: 'primary.main', color: 'white', fontWeight: 600 }}>
                  312 Population Identified
                </Paper>
                <ArrowDownward color="action" />
                <Paper variant="outlined" sx={{ px: 4, py: 2, borderWidth: 2, borderColor: 'primary.main', fontWeight: 600 }}>
                  Case Created
                </Paper>
              </Box>

              {/* DECISION POINT */}
              <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                <Paper sx={{ maxWidth: 500, p: 3, bgcolor: 'warning.lighter', borderColor: 'warning.main', borderWidth: 2, border: '2px solid' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                    <Warning color="warning" />
                    <Typography fontWeight={600}>Decision Point</Typography>
                  </Box>
                  <Typography variant="body2">
                    Model evaluates risk level and activity alignment
                  </Typography>
                </Paper>
              </Box>

              {/* TWO PATHS */}
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 4 }}>
                {/* AUTO CLOSE PATH */}
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, color: 'success.main' }}>
                    <CheckCircle />
                    <Typography fontWeight={600}>Path 1: Auto-Close</Typography>
                  </Box>
                  <Card sx={{ borderWidth: 2, borderColor: 'success.main', bgcolor: 'success.lighter' }}>
                    <CardContent>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <Chip label="Low Risk" color="success" size="small" sx={{ alignSelf: 'flex-start' }} />
                        <Typography variant="body2">Activity within expected parameters</Typography>
                        <ArrowDownward sx={{ alignSelf: 'center', color: 'success.dark' }} />
                        <Paper sx={{ p: 2, bgcolor: 'success.light', textAlign: 'center' }}>
                          <Typography fontWeight={600}>Status: Auto-Closed</Typography>
                          <Typography variant="caption">Assigned to: System</Typography>
                        </Paper>
                        <ArrowDownward sx={{ alignSelf: 'center', color: 'success.dark' }} />
                        <Paper sx={{ p: 2, bgcolor: 'success.main', color: 'white', textAlign: 'center', fontWeight: 600 }}>
                          COMPLETE
                        </Paper>
                      </Box>
                    </CardContent>
                  </Card>
                  <Paper sx={{ mt: 2, p: 2, bgcolor: 'info.lighter', borderColor: 'info.light', border: '1px solid' }}>
                    <Typography variant="caption" fontWeight={600}>Test Case:</Typography>
                    <Typography variant="caption" display="block">312-2025-AUTO-100</Typography>
                    <Typography variant="caption" color="text.secondary">Client: Reliable Logistics Corp</Typography>
                  </Paper>
                </Box>

                {/* MANUAL REVIEW PATH */}
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, color: 'info.main' }}>
                    <Schedule />
                    <Typography fontWeight={600}>Path 2: Manual Review</Typography>
                  </Box>
                  <Card sx={{ borderWidth: 2, borderColor: 'info.main', bgcolor: 'info.lighter' }}>
                    <CardContent>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <Chip label="Medium/High/Critical Risk" color="warning" size="small" sx={{ alignSelf: 'flex-start' }} />
                        <Typography variant="body2">Requires analyst review</Typography>
                        <ArrowDownward sx={{ alignSelf: 'center', color: 'info.main' }} />
                        <Paper sx={{ p: 2, bgcolor: 'grey.100' }}>
                          <Typography fontWeight={600}>Status: Unassigned</Typography>
                          <Typography variant="caption">In Workbasket</Typography>
                        </Paper>
                        <ArrowDownward sx={{ alignSelf: 'center', color: 'info.main' }} />
                        <Paper sx={{ p: 2, bgcolor: 'info.light' }}>
                          <Typography fontWeight={600}>Manager Assigns Case</Typography>
                          <Typography variant="caption">To Central Team Analyst</Typography>
                        </Paper>
                        <ArrowDownward sx={{ alignSelf: 'center', color: 'info.main' }} />
                        <Paper sx={{ p: 2, bgcolor: 'info.main', color: 'white' }}>
                          <Typography fontWeight={600}>Status: In Progress</Typography>
                          <Typography variant="caption">Analyst reviews data</Typography>
                        </Paper>
                        <ArrowDownward sx={{ alignSelf: 'center', color: 'info.main' }} />
                        <Paper sx={{ p: 2, bgcolor: 'warning.lighter', borderColor: 'warning.main', border: '1px solid' }}>
                          <Typography variant="caption" fontWeight={600}>Decision: Sales Input Needed?</Typography>
                        </Paper>
                      </Box>
                    </CardContent>
                  </Card>
                  <Paper sx={{ mt: 2, p: 2, bgcolor: 'info.lighter', borderColor: 'info.light', border: '1px solid' }}>
                    <Typography variant="caption" fontWeight={600}>Test Cases:</Typography>
                    <Typography variant="caption" display="block">312-2025-UNASSIGN-200 (Unassigned)</Typography>
                    <Typography variant="caption" display="block">312-2025-PROG-300 (In Progress)</Typography>
                  </Paper>
                </Box>
              </Box>

              {/* CONTINUATION */}
              <Box sx={{ borderTop: 2, borderColor: 'divider', pt: 4 }}>
                <Typography variant="body2" color="text.secondary" textAlign="center" fontStyle="italic" sx={{ mb: 3 }}>
                  After analyst reviews case (In Progress)...
                </Typography>

                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 4 }}>
                  {/* DIRECT COMPLETION */}
                  <Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, color: 'secondary.main' }}>
                      <CheckCircle />
                      <Typography fontWeight={600}>Path 2A: Direct Completion</Typography>
                    </Box>
                    <Card sx={{ borderWidth: 2, borderColor: 'secondary.main', bgcolor: 'secondary.lighter' }}>
                      <CardContent>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                          <Paper sx={{ p: 2, bgcolor: 'secondary.light' }}>
                            <Typography variant="body2">Analyst has sufficient information</Typography>
                            <Typography variant="caption">No sales context needed</Typography>
                          </Paper>
                          <ArrowDownward sx={{ alignSelf: 'center' }} />
                          <Paper sx={{ p: 2, bgcolor: 'secondary.main', color: 'white' }}>
                            <Typography fontWeight={600}>Analyst Completes Disposition</Typography>
                            <Box component="ul" sx={{ mt: 1, pl: 2, fontSize: '0.75rem' }}>
                              <li>No additional CAM escalation</li>
                              <li>OR: Route to CAM Review</li>
                              <li>OR: TRMS Filed</li>
                              <li>OR: Client Closed</li>
                            </Box>
                          </Paper>
                          <ArrowDownward sx={{ alignSelf: 'center' }} />
                          <Paper sx={{ p: 2, bgcolor: 'secondary.dark', color: 'white', textAlign: 'center', fontWeight: 600 }}>
                            Status: COMPLETE
                          </Paper>
                        </Box>
                      </CardContent>
                    </Card>
                  </Box>

                  {/* SALES REVIEW */}
                  <Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, color: 'warning.main' }}>
                      <People />
                      <Typography fontWeight={600}>Path 2B: Sales Review</Typography>
                    </Box>
                    <Card sx={{ borderWidth: 2, borderColor: 'warning.main', bgcolor: 'warning.lighter' }}>
                      <CardContent>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                          <Paper sx={{ p: 2, bgcolor: 'warning.light' }}>
                            <Typography variant="body2">Sales context required</Typography>
                            <Typography variant="caption">Only for GB/GM, PB, ML LOBs</Typography>
                          </Paper>
                          <ArrowDownward sx={{ alignSelf: 'center', color: 'warning.dark' }} />
                          <Paper sx={{ p: 2, bgcolor: 'warning.main', color: 'white' }}>
                            <Typography fontWeight={600}>Status: Pending Sales Review</Typography>
                            <Typography variant="caption">Case sent to Sales Owner</Typography>
                          </Paper>
                          <ArrowDownward sx={{ alignSelf: 'center', color: 'warning.dark' }} />
                          <Paper sx={{ p: 2, bgcolor: 'warning.dark', color: 'white' }}>
                            <Typography fontWeight={600}>Status: In Sales Review</Typography>
                            <Typography variant="caption">Sales Owner provides context</Typography>
                          </Paper>
                          <ArrowDownward sx={{ alignSelf: 'center', color: 'warning.dark' }} />
                          <Paper sx={{ p: 2, bgcolor: 'warning.main', color: 'white' }}>
                            <Typography fontWeight={600}>Status: Sales Review Complete</Typography>
                            <Typography variant="caption">Returns to Analyst</Typography>
                          </Paper>
                          <ArrowDownward sx={{ alignSelf: 'center', color: 'warning.dark' }} />
                          <Paper sx={{ p: 2, bgcolor: 'warning.dark', color: 'white', textAlign: 'center', fontWeight: 600 }}>
                            Analyst Completes → COMPLETE
                          </Paper>
                        </Box>
                      </CardContent>
                    </Card>
                  </Box>
                </Box>
              </Box>

              {/* REMEDIATION PATH */}
              <Box sx={{ borderTop: 2, borderColor: 'divider', pt: 4 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, color: 'error.main' }}>
                  <Warning />
                  <Typography fontWeight={600}>Special Path: Defect Remediation</Typography>
                </Box>
                <Card sx={{ borderWidth: 2, borderColor: 'error.main', bgcolor: 'error.lighter' }}>
                  <CardContent>
                    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(5, 1fr)' }, gap: 2, alignItems: 'center' }}>
                      <Paper sx={{ p: 2, bgcolor: 'success.light', textAlign: 'center' }}>
                        <Typography variant="body2" fontWeight={600}>COMPLETE</Typography>
                        <Typography variant="caption">Case closed</Typography>
                      </Paper>
                      <ArrowForward sx={{ display: { xs: 'none', md: 'block' }, justifySelf: 'center', color: 'error.main' }} />
                      <ArrowDownward sx={{ display: { xs: 'block', md: 'none' }, justifySelf: 'center', color: 'error.main' }} />
                      <Paper sx={{ p: 2, bgcolor: 'error.light', textAlign: 'center' }}>
                        <Typography variant="body2" fontWeight={600}>M&I Review</Typography>
                        <Typography variant="caption">Quality issue found</Typography>
                      </Paper>
                      <ArrowForward sx={{ display: { xs: 'none', md: 'block' }, justifySelf: 'center', color: 'error.main' }} />
                      <ArrowDownward sx={{ display: { xs: 'block', md: 'none' }, justifySelf: 'center', color: 'error.main' }} />
                      <Paper sx={{ p: 2, bgcolor: 'error.main', color: 'white', textAlign: 'center' }}>
                        <Typography variant="body2" fontWeight={600}>Defect Remediation</Typography>
                        <Typography variant="caption">Case reopened</Typography>
                      </Paper>
                      <ArrowForward sx={{ display: { xs: 'none', md: 'block' }, justifySelf: 'center', color: 'error.main' }} />
                      <ArrowDownward sx={{ display: { xs: 'block', md: 'none' }, justifySelf: 'center', color: 'error.main' }} />
                      <Paper sx={{ p: 2, bgcolor: 'success.light', textAlign: 'center' }}>
                        <Typography variant="body2" fontWeight={600}>COMPLETE</Typography>
                        <Typography variant="caption">Remediation done</Typography>
                      </Paper>
                    </Box>
                  </CardContent>
                </Card>
              </Box>
            </Box>
          </CardContent>
        </Card>
      </TabPanel>

      {/* SALES REVIEW WORKFLOW */}
      <TabPanel value={tabValue} index={1}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Sales Owner Review Workflow
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Detailed flow of sales involvement in case review process
            </Typography>

            <Paper sx={{ p: 3, mb: 3, bgcolor: 'info.lighter', borderColor: 'info.main', border: '2px solid' }}>
              <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                Prerequisites for Sales Review
              </Typography>
              <Box component="ul" sx={{ m: 0, pl: 3 }}>
                <Typography component="li" variant="body2">✅ Case must be 312 Review type</Typography>
                <Typography component="li" variant="body2">✅ Line of Business: GB/GM, PB, or ML only</Typography>
                <Typography component="li" variant="body2">✅ Case must be "In Progress" status</Typography>
                <Typography component="li" variant="body2">❌ Consumer and CI LOBs cannot route to sales</Typography>
              </Box>
            </Paper>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              {[
                { num: 1, title: 'Analyst Initiates Sales Review', color: 'primary', description: 'Central Team Analyst determines sales context is needed' },
                { num: 2, title: 'Sales Owner Receives Case', color: 'warning', description: 'Case appears in Sales Owner Worklist' },
                { num: 3, title: 'Sales Owner Opens Case', color: 'warning', description: 'Status automatically changes when case is viewed' },
                { num: 4, title: 'Sales Owner Provides Feedback', color: 'warning', description: 'Sales Owner adds business context and relationship information' },
                { num: 5, title: 'Returned to Analyst', color: 'success', description: 'Case returns to Central Team Analyst with sales feedback' },
                { num: 6, title: 'Analyst Completes Case', color: 'primary', description: 'Analyst reviews sales feedback and makes final disposition' },
              ].map((step) => (
                <Box key={step.num} sx={{ display: 'flex', gap: 2 }}>
                  <Box
                    sx={{
                      width: 32,
                      height: 32,
                      borderRadius: '50%',
                      bgcolor: `${step.color}.main`,
                      color: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: 600,
                      flexShrink: 0,
                    }}
                  >
                    {step.num}
                  </Box>
                  <Card sx={{ flex: 1, borderColor: `${step.color}.light`, borderWidth: 1, border: '1px solid' }}>
                    <CardContent>
                      <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                        {step.title}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {step.description}
                      </Typography>
                    </CardContent>
                  </Card>
                </Box>
              ))}
            </Box>
          </CardContent>
        </Card>
      </TabPanel>

      {/* CAM ESCALATION WORKFLOW */}
      <TabPanel value={tabValue} index={2}>
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              CAM Escalation Workflow
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Shows when and how cases escalate from 312 to full CAM review
            </Typography>
            <Box sx={{ p: 4, textAlign: 'center' }}>
              <Typography variant="body1" color="text.secondary">
                CAM Escalation workflow details coming soon...
              </Typography>
            </Box>
          </CardContent>
        </Card>
      </TabPanel>
    </Box>
  );
}
