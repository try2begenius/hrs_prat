import { Case } from '@/app/types';
import { Card, CardContent } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Label } from '@/app/components/ui/label';

interface SectionCaseClientDetailsProps {
  caseData: Case;
}

export function SectionCaseClientDetails({ caseData }: SectionCaseClientDetailsProps) {
  const is312Case = caseData.is312Case || caseData.caseType === '312 Review';
  const isCAMCase = caseData.caseType === 'CAM Review' || is312Case;

  return (
    <div className="space-y-6">
      {/* TBD1 and TBD2 Section */}
      <div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* TBD1 - Left Column */}
          <Card className="border rounded-lg bg-blue-50/30 border-blue-200">
            <CardContent className="pt-6">
              <h4 className="font-semibold text-sm mb-4">
                <Badge variant="default" className="bg-blue-600">TBD1</Badge>
              </h4>
              <div className="space-y-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Entity Name</Label>
                  <p className="mt-1">{caseData.entityName || caseData.clientData?.legalName || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Client LOB</Label>
                  <p className="mt-1">{caseData.lineOfBusiness || caseData.clientData?.lineOfBusiness || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Client Owner</Label>
                  <p className="mt-1">{caseData.clientOwners && caseData.clientOwners.length > 0 ? caseData.clientOwners.join(', ') : '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Country of Citizenship</Label>
                  <p className="mt-1">{caseData.clientData?.countryOfCitizenship || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">BofA Employee</Label>
                  <Badge 
                    variant={(caseData.isBACEmployee || caseData.clientData?.isEmployee) ? "default" : "outline"} 
                    className={(caseData.isBACEmployee || caseData.clientData?.isEmployee) ? "mt-1 bg-purple-600" : "mt-1"}
                  >
                    {(caseData.isBACEmployee || caseData.clientData?.isEmployee) ? 'Yes' : 'No'}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">BofA Affiliate</Label>
                  <Badge 
                    variant={caseData.isBACAffiliate ? "default" : "outline"} 
                    className={caseData.isBACAffiliate ? "mt-1 bg-indigo-600" : "mt-1"}
                  >
                    {caseData.isBACAffiliate ? 'Yes' : 'No'}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Reg O</Label>
                  <Badge 
                    variant={caseData.isRegO ? "default" : "outline"} 
                    className={caseData.isRegO ? "mt-1 bg-orange-600" : "mt-1"}
                  >
                    {caseData.isRegO ? 'Yes' : 'No'}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* TBD2 - Right Column */}
          <Card className="border rounded-lg bg-emerald-50/30 border-emerald-200">
            <CardContent className="pt-6">
              <h4 className="font-semibold text-sm mb-4">
                <Badge variant="default" className="bg-emerald-600">TBD2</Badge>
              </h4>
              <div className="space-y-4">
                <div>
                  <Label className="text-xs text-muted-foreground">NAICS</Label>
                  <p className="font-mono mt-1">{caseData.naicsCode || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">NAICS Description</Label>
                  <p className="mt-1">{caseData.naicsDescription || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Source of Wealth / Funds</Label>
                  <p className="mt-1">{caseData.case312Data?.sourceOfFunds || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Source of Income</Label>
                  <p className="mt-1">{caseData.clientData?.sourceOfIncome || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">CRA Codes</Label>
                  <p className="mt-1">{caseData.craCodes || '-'}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">CRA Description</Label>
                  <p className="mt-1">{caseData.craDescription || '-'}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 312 and CAM Attributes Side-by-Side */}
      {(is312Case || isCAMCase) && (
        <div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* 312 Attributes - Left Column */}
            {is312Case && caseData.case312Data && (
              <div className="border rounded-lg p-4 bg-blue-50/30 border-blue-200">
                <div className="flex items-center gap-2 mb-4">
                  <Badge variant="default" className="bg-blue-600">312</Badge>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">312 Due Date</Label>
                    <p className="mt-1">{caseData.case312Data.dueDate || caseData.dueDate}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">312 Aging</Label>
                    <p className="mt-1">{caseData.case312Data.aging || 0} days</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">312 Case Status</Label>
                    <p className="mt-1">{caseData.case312Data.status || 'In Progress'}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">312 Case Disposition</Label>
                    <p className="mt-1">{caseData.case312Data.disposition || 'Pending'}</p>
                  </div>
                  {caseData.case312Data.completedDate && (
                    <div>
                      <Label className="text-xs text-muted-foreground">312 Completed Date</Label>
                      <p className="mt-1">{caseData.case312Data.completedDate}</p>
                    </div>
                  )}
                  {caseData.case312Data.sourceOfFunds && (
                    <div>
                      <Label className="text-xs text-muted-foreground">Source of Funds</Label>
                      <p className="mt-1">{caseData.case312Data.sourceOfFunds}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* CAM Attributes - Right Column */}
            {isCAMCase && caseData.camCaseData && (
              <div className="border rounded-lg p-4 bg-emerald-50/30 border-emerald-200">
                <div className="flex items-center gap-2 mb-4">
                  <Badge variant="default" className="bg-emerald-600">CAM</Badge>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">CAM Due Date</Label>
                    <p className="mt-1">{caseData.camCaseData.dueDate || caseData.dueDate}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">CAM Case Status</Label>
                    <p className="mt-1">{caseData.camCaseData.status || 'In Progress'}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">CAM Case Disposition</Label>
                    <p className="mt-1">{caseData.camCaseData.disposition || 'Pending'}</p>
                  </div>
                  {caseData.camCaseData.completedDate && (
                    <div>
                      <Label className="text-xs text-muted-foreground">CAM Completed Date</Label>
                      <p className="mt-1">{caseData.camCaseData.completedDate}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
