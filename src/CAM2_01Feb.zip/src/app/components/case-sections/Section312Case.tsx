import { useState } from 'react';
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { Separator } from "../ui/separator";
import { Badge } from "../ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "../ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Save, X, Send, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { Case, Case312Response, Case312Account } from '../../types';
import { Alert, AlertDescription } from "../ui/alert";

interface Section312CaseProps {
  caseData: Case;
  response: Case312Response;
  setResponse: (response: Case312Response) => void;
  isSubmitted: boolean;
  canEdit: boolean;
  onSave: () => void;
  onCancel: () => void;
  onSubmit: () => void;
}

export function Section312Case({
  caseData,
  response,
  setResponse,
  isSubmitted,
  canEdit,
  onSave,
  onCancel,
  onSubmit,
}: Section312CaseProps) {
  const case312Data = caseData.case312Data;
  if (!case312Data) return null;

  const lob = caseData.lineOfBusiness || caseData.clientData?.lineOfBusiness;
  const isGBGM = lob === 'GB/GM';
  const isGM = lob === 'GB/GM'; // For market volatility option
  const isMLPB = lob === 'ML' || lob === 'PB';
  const isML = lob === 'ML'; // For Question 4 (Source of Funds)
  
  // Section is read-only if submitted OR user lacks actionCases permission
  const isReadOnly = isSubmitted || !canEdit;

  // State for account details dialog and account number masking
  const [showAccountDialog, setShowAccountDialog] = useState(false);
  const [unmaskedAccounts, setUnmaskedAccounts] = useState<Set<string>>(new Set());
  
  // State for send to sales dialog
  const [showSendToSalesDialog, setShowSendToSalesDialog] = useState(false);

  // Helper to check if all required questions are answered
  const isQuestion1Complete = () => {
    return response.question1_disposition !== undefined && 
           (response.question1_commentary?.trim() || '').length > 0;
  };

  const isQuestion2Complete = () => {
    return response.question2_disposition !== undefined && 
           (response.question2_commentary?.trim() || '').length > 0;
  };

  const isQuestion3Complete = () => {
    if (response.question3_option === 'activity_differed') {
      return response.question3_option !== undefined && 
             (response.question3_comments?.trim() || '').length > 0;
    }
    return response.question3_option !== undefined;
  };

  const isQuestion4Complete = () => {
    // Only required for ML LOB
    if (!isML) return true;
    return response.question4_disposition !== undefined &&
           (response.question4_commentary?.trim() || '').length > 0;
  };

  const isCaseActionComplete = () => {
    if (!response.caseAction) return false;
    if (response.caseAction === 'complete_trms_filed') {
      return (response.trmsNumber?.trim() || '').length > 0;
    }
    if (response.caseAction === 'send_to_sales') {
      return response.salesOwner !== undefined;
    }
    return true;
  };

  const canSubmit = () => {
    return isQuestion1Complete() && 
           isQuestion2Complete() && 
           isQuestion3Complete() && 
           isQuestion4Complete() &&
           isCaseActionComplete();
  };

  const canSave = () => {
    // Allow save even if not complete, but at least one field must be filled
    return response.question1_disposition !== undefined ||
           response.question2_disposition !== undefined ||
           response.question3_option !== undefined ||
           response.question4_disposition !== undefined ||
           response.caseAction !== undefined;
  };

  // Auto-populate Case Action based on question responses
  const shouldAutoPopulateTRMS = () => {
    return response.question1_disposition === 'need_trms' ||
           response.question2_disposition === 'need_trms' ||
           response.question3_option === 'need_trms' ||
           response.question4_disposition === 'need_trms';
  };

  // Handle save with validation
  const handleSave = () => {
    if (!canSave()) {
      alert('Please answer at least one question before saving.');
      return;
    }
    
    if (!isCaseActionComplete()) {
      if (!confirm('Warning: Case Action is not complete. Do you want to save anyway?')) {
        return;
      }
    }
    
    onSave();
  };

  // Handle submit with validation
  const handleSubmit = () => {
    if (!canSubmit()) {
      alert('Please complete all required questions and case action before submitting.');
      return;
    }
    
    if (!confirm('Warning: Once you submit, you will be unable to make edits/changes to this section. Do you want to continue?')) {
      return;
    }
    
    onSubmit();
  };

  // Handle send to sales
  const handleSendToSales = () => {
    if (response.caseAction !== 'send_to_sales') {
      alert('Please set Case Action to "Send to Sales" first.');
      return;
    }
    
    if (!response.salesOwner) {
      alert('Please select a Sales Owner in the Case Action section.');
      return;
    }
    
    setShowSendToSalesDialog(true);
  };

  const confirmSendToSales = () => {
    setShowSendToSalesDialog(false);
    handleSubmit();
  };

  // Mask/unmask account number
  const toggleAccountMask = (accountNumber: string) => {
    const newSet = new Set(unmaskedAccounts);
    if (newSet.has(accountNumber)) {
      newSet.delete(accountNumber);
    } else {
      newSet.add(accountNumber);
    }
    setUnmaskedAccounts(newSet);
  };

  const maskAccountNumber = (accountNumber: string) => {
    if (unmaskedAccounts.has(accountNumber)) {
      return accountNumber;
    }
    // Mask all but last 4 digits
    if (accountNumber.length <= 4) return '****';
    return '*'.repeat(accountNumber.length - 4) + accountNumber.slice(-4);
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between border-b pb-4">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-lg">312 Case</span>
          {isSubmitted && (
            <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
              <Lock className="h-3 w-3 mr-1" />
              Submitted
            </Badge>
          )}
        </div>
        {caseData.case312Data?.disposition && (
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              {caseData.case312Data.disposition}
            </Badge>
          </div>
        )}
      </div>
        
      {/* Read-only Fields */}
      <div className="space-y-6">
        
        {/* 312 Case Information */}
        <div>
          <h4 className="font-medium mb-4">312 Case Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-muted/30 p-4 rounded-lg">
            <div>
              <Label className="text-xs text-muted-foreground">312 Case Due Date</Label>
              <p className="mt-1">{case312Data.dueDate}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">312 Model Result</Label>
              <p className="mt-1">{case312Data.modelResult}</p>
            </div>
            <div className="md:col-span-2">
              <Label className="text-xs text-muted-foreground">312 Model Result Description</Label>
              <p className="mt-1 text-sm">{case312Data.modelResultDescription}</p>
            </div>
          </div>
        </div>

        {/* Expected Activity - Volume */}
        <div>
          <h4 className="font-medium mb-4">Client Expected Activity – Volume</h4>
          <div className="bg-muted/30 p-4 rounded-lg">
            <p className="mt-1">{case312Data.expectedActivityVolume.range || '100-499'}</p>
          </div>
        </div>

        {/* Expected Activity - Value */}
        <div>
          <h4 className="font-medium mb-4">Client Expected Activity – Value</h4>
          <div className="bg-muted/30 p-4 rounded-lg">
            <p className="mt-1">{case312Data.expectedActivityValue.range || '10,000-50,000'}</p>
          </div>
        </div>

        {/* Purpose of Relationship/Account */}
        <div>
          <h4 className="font-medium mb-4">Purpose of Relationship/Account</h4>
          <div className="bg-muted/30 p-4 rounded-lg">
            <p className="mt-1 text-sm">{case312Data.purposeOfRelationship || case312Data.purposeOfAccount || 'N/A'}</p>
          </div>
        </div>

        {/* Source of Funds */}
        <div>
          <h4 className="font-medium mb-4">Source of Funds</h4>
          <div className="bg-muted/30 p-4 rounded-lg">
            <p className="mt-1 text-sm">{case312Data.sourceOfFunds || 'N/A'}</p>
          </div>
        </div>

        {/* Actionable Questions */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 mb-4">
            <h4 className="font-semibold text-lg">Required Questions</h4>
            <Badge variant="outline" className="bg-red-50 text-red-700">All questions required</Badge>
          </div>

          {/* Question 1: Expected Value and Volume of Money Movement */}
          <div className="border rounded-lg p-4 space-y-4 bg-blue-50/30">
            <div>
              <Label className="font-medium text-base">
                Question 1: Expected Value and Volume of Money Movement, Inclusive of Cash Review
                <span className="text-red-600 ml-1">*</span>
              </Label>
              <p className="text-sm text-muted-foreground mt-1">
                Where actual activity (volume and / or value) has exceeded client expected activity, please select from the following dispositions and provide commentary as required to details why the activity was above client exceptions
              </p>
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-2 block">Disposition <span className="text-red-600">*</span></Label>
              <Select
                value={response.question1_disposition}
                onValueChange={(value: any) => setResponse({ ...response, question1_disposition: value })}
                disabled={isReadOnly}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select disposition" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="need_trms">Need to file TRMS</SelectItem>
                  <SelectItem value="not_unusual_other">Is NOT unusual – Other</SelectItem>
                  {isGM && <SelectItem value="not_unusual_market_volatility">Is NOT unusual – Market Volatility (GM Only)</SelectItem>}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Commentary <span className="text-red-600">*</span></Label>
              <Textarea
                value={response.question1_commentary || ''}
                onChange={(e) => setResponse({ ...response, question1_commentary: e.target.value })}
                disabled={isReadOnly}
                placeholder="Enter detailed commentary explaining why activity exceeded expectations..."
                rows={4}
              />
            </div>
          </div>

          {/* Question 2: Cross Border Money Movement Review */}
          <div className="border rounded-lg p-4 space-y-4 bg-blue-50/30">
            <div>
              <Label className="font-medium text-base">
                Question 2: Cross Border Money Movement Review
                <span className="text-red-600 ml-1">*</span>
              </Label>
              <p className="text-sm text-muted-foreground mt-1">
                For the indicated countries where money movement occurred to/from countries outside of what was expected, 
                please detail why the activity occurred outside of expected countries in the commentary box and select from the following dispositions:
              </p>
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-2 block">Disposition <span className="text-red-600">*</span></Label>
              <Select
                value={response.question2_disposition}
                onValueChange={(value: any) => setResponse({ ...response, question2_disposition: value })}
                disabled={isReadOnly}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select disposition" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="need_trms">Need to file TRMS</SelectItem>
                  <SelectItem value="not_unusual">Is NOT unusual</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Commentary <span className="text-red-600">*</span></Label>
              <Textarea
                value={response.question2_commentary || ''}
                onChange={(e) => setResponse({ ...response, question2_commentary: e.target.value })}
                disabled={isReadOnly}
                placeholder="Enter detailed commentary about cross-border activity..."
                rows={4}
              />
            </div>
          </div>

          {/* Question 3: Purpose of Relationship/Account */}
          <div className="border rounded-lg p-4 space-y-4 bg-blue-50/30">
            <div>
              <Label className="font-medium text-base">
                Question 3: Purpose of Relationship/Account
                <span className="text-red-600 ml-1">*</span>
              </Label>
              <p className="text-sm text-muted-foreground mt-1">
                Please detail if the activity that was deemed not aligned with Purpose of account or Purpose of relationship was/was not aligned with expectations or not.
              </p>
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-2 block">Response <span className="text-red-600">*</span></Label>
              <RadioGroup
                value={response.question3_option}
                onValueChange={(value: any) => setResponse({ ...response, question3_option: value, question3_comments: undefined })}
                disabled={isReadOnly}
                className="space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all_aligned" id="q3-aligned" />
                  <Label htmlFor="q3-aligned" className="cursor-pointer font-normal">All activity aligned with expectations</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="need_trms" id="q3-trms" />
                  <Label htmlFor="q3-trms" className="cursor-pointer font-normal">Need to File TRMS</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="activity_differed" id="q3-differed" />
                  <Label htmlFor="q3-differed" className="cursor-pointer font-normal">
                    If the additional activity was not unexpected, please detail why the activity differed from the purpose of relationship/Account
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {response.question3_option === 'activity_differed' && (
              <div>
                <Label className="text-sm font-medium mb-2 block">Comments <span className="text-red-600">*</span></Label>
                <Textarea
                  value={response.question3_comments || ''}
                  onChange={(e) => setResponse({ ...response, question3_comments: e.target.value })}
                  disabled={isReadOnly}
                  placeholder="Enter detailed comments explaining why activity differed..."
                  rows={4}
                />
              </div>
            )}
          </div>

          {/* Question 4: Source of Funds (ML only) */}
          {isML && (
            <div className="border rounded-lg p-4 space-y-4 bg-blue-50/30">
              <div>
                <Label className="font-medium text-base">
                  Question 4: Source of Funds (ML only)
                  <span className="text-red-600 ml-1">*</span>
                </Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Please detail why the activity was not aligned with the client's source of funds and select from the following dispositions:
                </p>
              </div>
              
              <div>
                <Label className="text-sm font-medium mb-2 block">Disposition <span className="text-red-600">*</span></Label>
                <Select
                  value={response.question4_disposition}
                  onValueChange={(value: any) => setResponse({ ...response, question4_disposition: value })}
                  disabled={isReadOnly}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select disposition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="need_trms">Need to file TRMS</SelectItem>
                    <SelectItem value="not_unusual">Is NOT unusual</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Commentary <span className="text-red-600">*</span></Label>
                <Textarea
                  value={response.question4_commentary || ''}
                  onChange={(e) => setResponse({ ...response, question4_commentary: e.target.value })}
                  disabled={isReadOnly}
                  placeholder="Enter detailed commentary about source of funds alignment..."
                  rows={4}
                />
              </div>
            </div>
          )}

          {/* Case Action */}
          <div className="border-2 border-primary/30 rounded-lg p-4 space-y-4 bg-amber-50/50">
            <div>
              <Label className="font-medium text-base">
                Case Action <span className="text-red-600 ml-1">*</span>
              </Label>
              {shouldAutoPopulateTRMS() && (
                <Alert className="mt-2 bg-blue-50 border-blue-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    Based on your responses indicating "Need to file TRMS", you should select "Complete – TRMS filed" as the case action.
                  </AlertDescription>
                </Alert>
              )}
            </div>
            
            <div>
              <Select
                value={response.caseAction}
                onValueChange={(value: any) => setResponse({ 
                  ...response, 
                  caseAction: value,
                  trmsNumber: undefined,
                  salesOwner: undefined,
                  salesComments: undefined,
                })}
                disabled={isReadOnly}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select case action" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="complete_no_action">Complete – No action</SelectItem>
                  <SelectItem value="complete_trms_filed">Complete – TRMS filed</SelectItem>
                  <SelectItem value="send_to_sales">Send to Sales (PB, ML, GB/GM only)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {response.caseAction === 'complete_trms_filed' && (
              <div>
                <Label className="text-sm font-medium mb-2 block">Provide the TRMS # <span className="text-red-600">*</span></Label>
                <input
                  type="text"
                  value={response.trmsNumber || ''}
                  onChange={(e) => setResponse({ ...response, trmsNumber: e.target.value })}
                  disabled={isReadOnly}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  placeholder="Enter TRMS number (e.g., TRMS-2025-001)"
                />
              </div>
            )}

            {response.caseAction === 'send_to_sales' && (
              <>
                <div>
                  <Label className="text-sm font-medium mb-2 block">Sales Owner <span className="text-red-600">*</span></Label>
                  <Select
                    value={response.salesOwner}
                    onValueChange={(value) => setResponse({ ...response, salesOwner: value })}
                    disabled={isReadOnly}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Sales Owner" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="David Park">David Park</SelectItem>
                      <SelectItem value="Amanda Torres">Amanda Torres</SelectItem>
                      <SelectItem value="Patricia Lee">Patricia Lee (RM)</SelectItem>
                      <SelectItem value="Carlos Rivera">Carlos Rivera (RM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-sm font-medium mb-2 block">Comments (Optional)</Label>
                  <Textarea
                    value={response.salesComments || ''}
                    onChange={(e) => setResponse({ ...response, salesComments: e.target.value })}
                    disabled={isReadOnly}
                    placeholder="Add any comments for the sales owner..."
                    rows={3}
                  />
                </div>
              </>
            )}
          </div>
        </div>

        {/* Permission Warning Banner */}
        {!canEdit && !isSubmitted && (
          <Alert className="bg-amber-50 border-amber-200">
            <Lock className="h-4 w-4" />
            <AlertDescription>
              View Only - You do not have permission to action this case.
            </AlertDescription>
          </Alert>
        )}

        {/* Action Buttons */}
        {!isSubmitted && canEdit && (
          <div className="flex gap-3 justify-end mt-6 pt-6 border-t">
            <Button variant="outline" onClick={onCancel}>
              <X className="mr-2 h-4 w-4" />
              Cancel
            </Button>
            <Button 
              variant="secondary" 
              onClick={handleSave}
              disabled={!canSave()}
            >
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
            {response.caseAction === 'send_to_sales' && response.salesOwner && (
              <Button 
                variant="default"
                className="bg-blue-600 hover:bg-blue-700"
                onClick={handleSendToSales}
              >
                <Send className="mr-2 h-4 w-4" />
                Send to Sales
              </Button>
            )}
            <Button 
              onClick={handleSubmit}
              disabled={!canSubmit()}
            >
              <Send className="mr-2 h-4 w-4" />
              Submit
            </Button>
          </div>
        )}

        {isSubmitted && (
          <Alert className="bg-green-50 border-green-200">
            <Lock className="h-4 w-4" />
            <AlertDescription>
              This section has been submitted and is now read-only.
              {response.submittedBy && ` Submitted by ${response.submittedBy} on ${new Date(response.submittedDate!).toLocaleDateString()}`}
            </AlertDescription>
          </Alert>
        )}
      </div>

      {/* Account Details Dialog */}
      {case312Data.purposeOfAccountDetails && (
        <Dialog open={showAccountDialog} onOpenChange={setShowAccountDialog}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Purpose of Account - Account Details</DialogTitle>
              <DialogDescription>
                Account numbers are masked. Hover or click the eye icon to reveal.
              </DialogDescription>
            </DialogHeader>
            <div className="max-h-96 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Account Number</TableHead>
                    <TableHead>Account Name</TableHead>
                    <TableHead>Source of Funds</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {case312Data.purposeOfAccountDetails.map((account: Case312Account, idx: number) => (
                    <TableRow key={idx}>
                      <TableCell className="font-mono">
                        {maskAccountNumber(account.accountNumber)}
                      </TableCell>
                      <TableCell>{account.accountName}</TableCell>
                      <TableCell>{account.sourceOfFunds}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleAccountMask(account.accountNumber)}
                          title={unmaskedAccounts.has(account.accountNumber) ? "Hide account number" : "Show account number"}
                        >
                          {unmaskedAccounts.has(account.accountNumber) ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAccountDialog(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Send to Sales Confirmation Dialog */}
      <Dialog open={showSendToSalesDialog} onOpenChange={setShowSendToSalesDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Send to Sales</DialogTitle>
            <DialogDescription>
              You are about to send this case to the sales owner. This action will submit the 312 section and route the case for sales review.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <div>
              <Label className="text-sm font-medium">Sales Owner:</Label>
              <p className="mt-1">{response.salesOwner}</p>
            </div>
            {response.salesComments && (
              <div>
                <Label className="text-sm font-medium">Comments:</Label>
                <p className="mt-1 text-sm text-muted-foreground">{response.salesComments}</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSendToSalesDialog(false)}>Cancel</Button>
            <Button onClick={confirmSendToSales}>
              <Send className="mr-2 h-4 w-4" />
              Confirm Send to Sales
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}