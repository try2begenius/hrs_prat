import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { Checkbox } from "../ui/checkbox";
import { Separator } from "../ui/separator";
import { Badge } from "../ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Save, X, Send, Lock, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { Case, CAMCaseResponse } from '../../types';

interface SectionCAMCaseProps {
  caseData: Case;
  response: CAMCaseResponse;
  setResponse: (response: CAMCaseResponse) => void;
  isSubmitted: boolean;
  canEdit: boolean;
  onSave: () => void;
  onCancel: () => void;
  onSubmit: () => void;
}

export function SectionCAMCase({
  caseData,
  response,
  setResponse,
  isSubmitted,
  canEdit,
  onSave,
  onCancel,
  onSubmit,
}: SectionCAMCaseProps) {
  const camCaseData = caseData.camCaseData;
  const monitoringDashboard = caseData.monitoringDashboard;
  
  if (!camCaseData) return null;
  
  // Section is read-only if submitted OR user lacks actionCases permission
  const isReadOnly = isSubmitted || !canEdit;

  // Get triggers from case data for display purposes
  const triggers = camCaseData.triggers || [];

  // Fixed attestation options for Q1.1 (when Q1 = No)
  const attestationOptions = [
    'I have reviewed the alerts and escalations and believe no further escalation is required to be raised',
    'No additional findings or knowledge of the client require an escalation outside of what has been already properly escalated'
  ];

  const handleAttestationToggle = (attestation: string) => {
    const current = response.question1_1_attestations || [];
    const updated = current.includes(attestation)
      ? current.filter(a => a !== attestation)
      : [...current, attestation];
    setResponse({ ...response, question1_1_attestations: updated });
  };

  const isAllAttestationsChecked = () => {
    return attestationOptions.length > 0 && 
           attestationOptions.every(att => (response.question1_1_attestations || []).includes(att));
  };

  // Handle case action confirmation checkboxes
  const handleCaseActionConfirmation = (checked: boolean) => {
    setResponse({ ...response, question3_confirmation: checked });
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between border-b pb-4">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-lg">CAM Case</span>
          {isSubmitted && (
            <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
              <Lock className="h-3 w-3 mr-1" />
              Submitted
            </Badge>
          )}
        </div>
        {caseData.camCaseData?.disposition && (
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
              {caseData.camCaseData.disposition}
            </Badge>
          </div>
        )}
      </div>
        
      <div className="space-y-6">
        {/* CAM Case Information */}
        <div>
          <h4 className="font-medium mb-4">CAM Case Information</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-muted/30 p-4 rounded-lg">
            <div>
              <Label className="text-xs text-muted-foreground">CAM Due Date</Label>
              <p className="mt-1">{camCaseData.dueDate}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">CAM Triggers</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {triggers.map((trigger, idx) => (
                  <Badge key={idx} variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    {trigger}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Monitoring Dashboard */}
        <div>
          <h4 className="font-semibold text-lg mb-4">Monitoring Dashboard</h4>
          
          {monitoringDashboard ? (
            <Tabs defaultValue="lob-controls" className="w-full">
              <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
                <TabsTrigger value="lob-controls">LOB Controls</TabsTrigger>
                <TabsTrigger value="trms-flu">TRMS FLU</TabsTrigger>
                <TabsTrigger value="trms-other">TRMS Other</TabsTrigger>
                <TabsTrigger value="second-line">Second Line</TabsTrigger>
                <TabsTrigger value="fraud">Fraud</TabsTrigger>
                <TabsTrigger value="sanctions">Sanctions</TabsTrigger>
                <TabsTrigger value="alerts-312">312 Alerts</TabsTrigger>
              </TabsList>

              {/* 4.2.1: LOB Monitoring Controls */}
              <TabsContent value="lob-controls" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>LOB Monitoring Controls</CardTitle>
                    <CardDescription>Line of Business specific monitoring activities</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {monitoringDashboard.lobMonitoringControls && monitoringDashboard.lobMonitoringControls.length > 0 ? (
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>LOB</TableHead>
                              <TableHead>Activity Name</TableHead>
                              <TableHead>Activity Description</TableHead>
                              <TableHead>Outcome</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monitoringDashboard.lobMonitoringControls.map((record, idx) => (
                              <TableRow key={idx}>
                                <TableCell>{record.lob}</TableCell>
                                <TableCell className="max-w-xs">{record.activityName}</TableCell>
                                <TableCell className="max-w-md whitespace-normal break-words">{record.activityDescription}</TableCell>
                                <TableCell>
                                  <Badge variant={record.outcome === 'Passed' ? 'default' : record.outcome === 'Failed' ? 'destructive' : 'secondary'}>
                                    {record.outcome}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 text-muted-foreground">
                        <Info className="h-5 w-5 mr-2" />
                        No LOB monitoring controls found
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* 4.2.2: TRMS from FLU/FLD */}
              <TabsContent value="trms-flu" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>TRMS from FLU/FLD</CardTitle>
                    <CardDescription>Transaction Reporting and Monitoring System records from FLU/FLD processes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {monitoringDashboard.trmsFLU && monitoringDashboard.trmsFLU.length > 0 ? (
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>TRMS ID</TableHead>
                              <TableHead>TRMS Type</TableHead>
                              <TableHead>Description/Reason</TableHead>
                              <TableHead>Impact Type</TableHead>
                              <TableHead>Narrative</TableHead>
                              <TableHead>TRMS Date</TableHead>
                              <TableHead>Submitter LOB</TableHead>
                              <TableHead>Submitter Name</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monitoringDashboard.trmsFLU.map((record) => (
                              <TableRow key={record.id}>
                                <TableCell className="font-mono text-sm">{record.id}</TableCell>
                                <TableCell>{record.type}</TableCell>
                                <TableCell className="max-w-xs truncate">{record.descriptionReason}</TableCell>
                                <TableCell>
                                  <Badge variant={record.impactType === 'High' ? 'destructive' : 'secondary'}>
                                    {record.impactType}
                                  </Badge>
                                </TableCell>
                                <TableCell className="max-w-md whitespace-normal break-words">{record.narrative}</TableCell>
                                <TableCell className="whitespace-nowrap">{record.date}</TableCell>
                                <TableCell>{record.submitterLOB}</TableCell>
                                <TableCell>{record.submitterName}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 text-muted-foreground">
                        <Info className="h-5 w-5 mr-2" />
                        No TRMS FLU/FLD records found
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* 4.2.3: TRMS Other */}
              <TabsContent value="trms-other" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>TRMS Other</CardTitle>
                    <CardDescription>Other TRMS records not originating from FLU/FLD</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {monitoringDashboard.trmsOther && monitoringDashboard.trmsOther.length > 0 ? (
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>TRMS ID</TableHead>
                              <TableHead>TRMS Type</TableHead>
                              <TableHead>Description/Reason</TableHead>
                              <TableHead>Impact Type</TableHead>
                              <TableHead>Narrative</TableHead>
                              <TableHead>TRMS Date</TableHead>
                              <TableHead>Submitter LOB</TableHead>
                              <TableHead>Submitter Name</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monitoringDashboard.trmsOther.map((record) => (
                              <TableRow key={record.id}>
                                <TableCell className="font-mono text-sm">{record.id}</TableCell>
                                <TableCell>{record.type}</TableCell>
                                <TableCell className="max-w-xs truncate">{record.descriptionReason}</TableCell>
                                <TableCell>
                                  <Badge variant={record.impactType === 'High' ? 'destructive' : 'secondary'}>
                                    {record.impactType}
                                  </Badge>
                                </TableCell>
                                <TableCell className="max-w-md whitespace-normal break-words">{record.narrative}</TableCell>
                                <TableCell className="whitespace-nowrap">{record.date}</TableCell>
                                <TableCell>{record.submitterLOB}</TableCell>
                                <TableCell>{record.submitterName}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 text-muted-foreground">
                        <Info className="h-5 w-5 mr-2" />
                        No other TRMS records found
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* 4.2.4: Second Line Cases */}
              <TabsContent value="second-line" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Second Line Cases</CardTitle>
                    <CardDescription>Second line monitoring and oversight activities</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {monitoringDashboard.secondLineCases && monitoringDashboard.secondLineCases.length > 0 ? (
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Case ID</TableHead>
                              <TableHead>Case Type</TableHead>
                              <TableHead>Case Status</TableHead>
                              <TableHead>Case Description</TableHead>
                              <TableHead>Case Reason</TableHead>
                              <TableHead>Narrative</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>LOB</TableHead>
                              <TableHead>Linked TRMS</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monitoringDashboard.secondLineCases.map((record) => (
                              <TableRow key={record.caseId}>
                                <TableCell className="font-mono text-sm">{record.caseId}</TableCell>
                                <TableCell>{record.caseType}</TableCell>
                                <TableCell>
                                  <Badge variant="outline">{record.caseStatus}</Badge>
                                </TableCell>
                                <TableCell className="max-w-xs truncate">{record.caseDescription}</TableCell>
                                <TableCell className="max-w-xs truncate">{record.caseReason}</TableCell>
                                <TableCell className="max-w-md whitespace-normal break-words">{record.narrative}</TableCell>
                                <TableCell className="whitespace-nowrap">{record.date}</TableCell>
                                <TableCell>{record.lob}</TableCell>
                                <TableCell className="font-mono text-sm">{record.linkedTRMS || '-'}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 text-muted-foreground">
                        <Info className="h-5 w-5 mr-2" />
                        No second line cases found
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* 4.2.5: First Party Fraud Cases */}
              <TabsContent value="fraud" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>First Party Fraud Cases</CardTitle>
                    <CardDescription>First party fraud investigation and monitoring activities</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {monitoringDashboard.fraudCases && monitoringDashboard.fraudCases.length > 0 ? (
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Case ID</TableHead>
                              <TableHead>Case Status</TableHead>
                              <TableHead>Narrative</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>LOB</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monitoringDashboard.fraudCases.map((record) => (
                              <TableRow key={record.caseId}>
                                <TableCell className="font-mono text-sm">{record.caseId}</TableCell>
                                <TableCell>
                                  <Badge variant="outline">{record.caseStatus}</Badge>
                                </TableCell>
                                <TableCell className="max-w-md whitespace-normal break-words">{record.narrative}</TableCell>
                                <TableCell className="whitespace-nowrap">{record.date}</TableCell>
                                <TableCell>{record.lob}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 text-muted-foreground">
                        <Info className="h-5 w-5 mr-2" />
                        No fraud cases found
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* 4.2.6: Sanctions */}
              <TabsContent value="sanctions" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Sanctions Details</CardTitle>
                    <CardDescription>Sanctions screening alerts and resolutions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {monitoringDashboard.sanctionDetails && monitoringDashboard.sanctionDetails.length > 0 ? (
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Case ID</TableHead>
                              <TableHead>LOB</TableHead>
                              <TableHead>Product</TableHead>
                              <TableHead>Alert Date</TableHead>
                              <TableHead>Alert Description</TableHead>
                              <TableHead>Narrative</TableHead>
                              <TableHead>Block/Reject</TableHead>
                              <TableHead>Block/Reject Reason</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monitoringDashboard.sanctionDetails.map((record, idx) => (
                              <TableRow key={idx}>
                                <TableCell className="font-mono text-sm">{record.caseId}</TableCell>
                                <TableCell>{record.lob}</TableCell>
                                <TableCell>{record.product}</TableCell>
                                <TableCell className="whitespace-nowrap">{record.alertDate}</TableCell>
                                <TableCell className="max-w-md">{record.alertDescription}</TableCell>
                                <TableCell className="max-w-md whitespace-normal break-words">{record.narrative || '-'}</TableCell>
                                <TableCell>
                                  {record.blockReject ? (
                                    <Badge variant="destructive">Yes</Badge>
                                  ) : (
                                    <Badge variant="outline">No</Badge>
                                  )}
                                </TableCell>
                                <TableCell className="max-w-xs">{record.blockRejectReason || '-'}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 text-muted-foreground">
                        <Info className="h-5 w-5 mr-2" />
                        No sanctions alerts found
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* 4.2.7: 312 Alerts */}
              <TabsContent value="alerts-312" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>312 Alerts</CardTitle>
                    <CardDescription>312 review triggers and alerts</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {monitoringDashboard.alert312Details && monitoringDashboard.alert312Details.length > 0 ? (
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>LOB 312</TableHead>
                              <TableHead>Alert Date</TableHead>
                              <TableHead>Alert Description</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {monitoringDashboard.alert312Details.map((record, idx) => (
                              <TableRow key={idx}>
                                <TableCell>{record.lob312}</TableCell>
                                <TableCell className="whitespace-nowrap">{record.alertDate}</TableCell>
                                <TableCell className="max-w-lg">{record.alertDescription}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 text-muted-foreground">
                        <Info className="h-5 w-5 mr-2" />
                        No 312 alerts found
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          ) : (
            <div className="flex items-center justify-center py-12 text-muted-foreground border rounded-lg bg-muted/20">
              <AlertTriangle className="h-5 w-5 mr-2" />
              No monitoring dashboard data available
            </div>
          )}
        </div>

        <Separator className="my-6" />

        {/* CAM Case Disposition Questions */}
        <div className="space-y-6">
          <h4 className="font-semibold text-lg">CAM Case Disposition</h4>

          {/* Question 1 */}
          <div className="border rounded-lg p-4 space-y-3">
            <Label className="font-medium">
              Question 1: After review of the monitoring activity over the last 12 months - are there any additional items that need to be raised as a result of this monitoring?
              <span className="text-red-600 ml-1">*</span>
            </Label>
            <RadioGroup
              value={response.question1 === null ? undefined : response.question1.toString()}
              onValueChange={(value) => setResponse({ 
                ...response, 
                question1: value === 'true',
                question1_1_attestations: value === 'true' ? [] : response.question1_1_attestations,
                question1_2_trms: value === 'true' ? response.question1_2_trms : undefined,
                question1_3_trmsNumber: value === 'true' ? response.question1_3_trmsNumber : undefined,
              })}
              disabled={isReadOnly}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="true" id="cam-q1-yes" />
                <Label htmlFor="cam-q1-yes" className="cursor-pointer">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="false" id="cam-q1-no" />
                <Label htmlFor="cam-q1-no" className="cursor-pointer">No</Label>
              </div>
            </RadioGroup>

            {/* If No - Show Attestations */}
            {response.question1 === false && (
              <div className="ml-6 mt-4 p-4 bg-blue-50 rounded-lg space-y-3">
                <Label className="font-medium">
                  Q 1.1: Please check all applicable attestations: <span className="text-red-600">*</span>
                </Label>
                <div className="space-y-2">
                  {attestationOptions.map((attestation, idx) => (
                    <div key={idx} className="flex items-start space-x-2">
                      <Checkbox
                        id={`attestation-${idx}`}
                        checked={(response.question1_1_attestations || []).includes(attestation)}
                        onCheckedChange={() => handleAttestationToggle(attestation)}
                        disabled={isReadOnly}
                      />
                      <Label htmlFor={`attestation-${idx}`} className="cursor-pointer text-sm leading-relaxed">
                        {attestation}
                      </Label>
                    </div>
                  ))}
                </div>

              </div>
            )}

            {/* If Yes - File TRMS */}
            {response.question1 === true && (
              <div className="ml-6 mt-4 space-y-3">
                <div>
                  <Label className="font-medium">Q 1.2: If yes, please file a TRMS indicating unusual alert(s) or activity and document TRMS number <span className="text-red-600">*</span></Label>
                  <Select
                    value={response.question1_2_trms}
                    onValueChange={(value) => setResponse({ 
                      ...response, 
                      question1_2_trms: value,
                      question1_3_trmsNumber: value === 'no' ? undefined : response.question1_3_trmsNumber,
                    })}
                    disabled={isReadOnly}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select option" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="yes">Yes</SelectItem>
                      <SelectItem value="no">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {response.question1_2_trms === 'yes' && (
                  <div>
                    <Label className="font-medium">Q 1.3: TRMS Number <span className="text-red-600">*</span></Label>
                    <input
                      type="text"
                      value={response.question1_3_trmsNumber || ''}
                      onChange={(e) => setResponse({ ...response, question1_3_trmsNumber: e.target.value })}
                      disabled={isReadOnly}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                      placeholder="Enter TRMS number"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Question 2 - Confirmation */}
          <div className="border rounded-lg p-4 space-y-3 bg-amber-50/50">
            <div className="flex items-start space-x-2">
              <Checkbox
                id="cam-q2-confirm"
                checked={response.question2_confirmation || false}
                onCheckedChange={(checked) => setResponse({ ...response, question2_confirmation: checked as boolean })}
                disabled={isReadOnly}
              />
              <Label htmlFor="cam-q2-confirm" className="cursor-pointer font-medium leading-relaxed">
                Question 2: I confirm that I have reviewed the Monitoring Dashboard data and understand the client's activity.
                <span className="text-red-600 ml-1">*</span>
              </Label>
            </div>
          </div>

          {/* Question 3 - Case Action */}
          <div className="border rounded-lg p-4 space-y-3 bg-blue-50/50">
            <Label className="font-medium">
              Question 3: Case Action <span className="text-red-600">*</span>
            </Label>
            <Select
              value={response.question3_action}
              onValueChange={(value: any) => setResponse({ 
                ...response, 
                question3_action: value,
                question3_trms: undefined,
                question3_salesOwner: undefined,
                question3_comments: value === 'send_to_sales' ? response.question3_comments : undefined,
                question3_confirmation: false, // Reset confirmation when action changes
              })}
              disabled={isReadOnly}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select case action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="complete_no_action">Complete – No action</SelectItem>
                <SelectItem value="complete_trms_filed">Complete – TRMS filed</SelectItem>
                <SelectItem value="send_to_sales">Send to Sales</SelectItem>
              </SelectContent>
            </Select>

            {response.question3_action === 'complete_trms_filed' && (
              <div className="mt-3 space-y-3">
                <div>
                  <Label>TRMS Number <span className="text-red-600">*</span></Label>
                  <input
                    type="text"
                    value={response.question3_trms || ''}
                    onChange={(e) => setResponse({ ...response, question3_trms: e.target.value })}
                    disabled={isReadOnly}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mt-2"
                    placeholder="Enter TRMS number"
                  />
                </div>
                <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="cam-action-confirm-trms"
                      checked={response.question3_confirmation || false}
                      onCheckedChange={(checked) => handleCaseActionConfirmation(checked as boolean)}
                      disabled={isReadOnly}
                    />
                    <Label htmlFor="cam-action-confirm-trms" className="cursor-pointer text-sm leading-relaxed">
                      I confirm that all data has been reviewed and a TRMS has been raised accordingly
                      <span className="text-red-600 ml-1">*</span>
                    </Label>
                  </div>
                </div>
              </div>
            )}

            {response.question3_action === 'complete_no_action' && (
              <div className="mt-3">
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="cam-action-confirm-noaction"
                      checked={response.question3_confirmation || false}
                      onCheckedChange={(checked) => handleCaseActionConfirmation(checked as boolean)}
                      disabled={isReadOnly}
                    />
                    <Label htmlFor="cam-action-confirm-noaction" className="cursor-pointer text-sm leading-relaxed">
                      I confirm that all data has been reviewed and the responses to the above questions are accurate
                      <span className="text-red-600 ml-1">*</span>
                    </Label>
                  </div>
                </div>
              </div>
            )}

            {response.question3_action === 'send_to_sales' && (
              <div className="space-y-3 mt-3">
                <div>
                  <Label>Sales Owner Name <span className="text-red-600">*</span></Label>
                  <Select
                    value={response.question3_salesOwner}
                    onValueChange={(value) => setResponse({ ...response, question3_salesOwner: value })}
                    disabled={isReadOnly}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select Sales Owner" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="David Park">David Park</SelectItem>
                      <SelectItem value="Amanda Torres">Amanda Torres</SelectItem>
                      <SelectItem value="Patricia Lee">Patricia Lee (RM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>
                    Comments for Sales Owner <span className="text-red-600">*</span>
                    <span className="text-xs text-muted-foreground ml-2">
                      ({(response.question3_comments || '').length}/4000 characters)
                    </span>
                  </Label>
                  <Textarea
                    value={response.question3_comments || ''}
                    onChange={(e) => {
                      if (e.target.value.length <= 4000) {
                        setResponse({ ...response, question3_comments: e.target.value });
                      }
                    }}
                    disabled={isReadOnly}
                    className="mt-2"
                    placeholder="Enter comments for the Sales Owner (required when sending to sales, max 4000 characters)"
                    rows={4}
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Permission Warning Banner */}
        {!canEdit && !isSubmitted && (
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-800 flex items-center gap-2">
              <Lock className="h-4 w-4" />
              View Only - You do not have permission to action this case.
            </p>
          </div>
        )}

        {/* Action Buttons */}
        {!isSubmitted && canEdit && (
          <div className="flex gap-3 justify-end mt-6 pt-6 border-t">
            <Button variant="outline" onClick={onCancel}>
              <X className="mr-2 h-4 w-4" />
              Cancel
            </Button>
            <Button variant="secondary" onClick={onSave}>
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
            <Button onClick={onSubmit}>
              <Send className="mr-2 h-4 w-4" />
              Submit
            </Button>
          </div>
        )}

        {isSubmitted && (
          <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-sm text-green-800 flex items-center gap-2">
              <Lock className="h-4 w-4" />
              This section has been submitted and is now read-only.
              {response.submittedBy && ` Submitted by ${response.submittedBy} on ${new Date(response.submittedDate!).toLocaleDateString()}`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}