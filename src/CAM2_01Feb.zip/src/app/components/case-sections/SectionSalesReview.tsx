import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Separator } from "../ui/separator";
import { Badge } from "../ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Save, X, Send, Lock, Info, Shield, MessageSquare } from 'lucide-react';
import { Case, SalesOwnerResponse, CaseProcessorComment } from '../../types';
import { UserAccess } from '../../data/rolesEntitlementsMockData';

interface SectionSalesReviewProps {
  caseData: Case;
  response: SalesOwnerResponse;
  setResponse: (response: SalesOwnerResponse) => void;
  isSubmitted: boolean;
  onSave: () => void;
  onCancel: () => void;
  onSubmit: () => void;
  currentUser: UserAccess;
}

export function SectionSalesReview({
  caseData,
  response,
  setResponse,
  isSubmitted,
  onSave,
  onCancel,
  onSubmit,
  currentUser,
}: SectionSalesReviewProps) {
  // Access control: Sales Owners see edit mode, AML users see read-only mode
  const isSalesOwner = currentUser.role === 'Sales Owner';
  const isAMLUser = ['Central Team Analyst', 'Central Team Manager'].includes(currentUser.role);
  const isAssignee = caseData.assignedTo === currentUser.name;
  
  // Section visible to: Sales Owners, AML Analysts, AML Managers (all can view, but only Sales can edit)
  if (!isSalesOwner && !isAMLUser) {
    return null;
  }

  // Check if case is in a sales review state
  const isInSalesReview = ['Pending Sales Review', 'In Sales Review', 'Sales Review Complete'].includes(caseData.status);

  const case312Data = caseData.case312Data;
  const camCaseData = caseData.camCaseData;
  const monitoringDashboard = caseData.monitoringDashboard;
  const processorComments = caseData.caseProcessorComments || [];

  // Privacy-filtered: Only show non-sensitive summary counts
  const getSummaryStats = () => {
    if (!monitoringDashboard) return null;
    
    return {
      trmsFLU: monitoringDashboard.trmsFLU?.length || 0,
      trmsOther: monitoringDashboard.trmsOther?.length || 0,
      secondLine: monitoringDashboard.secondLineCases?.length || 0,
      fraud: monitoringDashboard.fraudCases?.length || 0,
      sanctions: monitoringDashboard.sanctionDetails?.length || 0,
      alerts312: monitoringDashboard.alert312Details?.length || 0,
      lobControls: monitoringDashboard.lobMonitoringControls?.length || 0,
    };
  };

  const summaryStats = getSummaryStats();

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between border-b pb-4">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-lg">Sales Owner Review</span>
          {isSalesOwner && (
            <Badge variant="outline" className="ml-2 bg-purple-50 text-purple-700 border-purple-200">
              <Shield className="h-3 w-3 mr-1" />
              Sales Owner Access
            </Badge>
          )}
          {isSubmitted && (
            <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
              <Lock className="h-3 w-3 mr-1" />
              Submitted
            </Badge>
          )}
        </div>
      </div>
        
      {!isInSalesReview && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg mb-6">
          <p className="text-sm text-amber-800 flex items-center gap-2">
            <Info className="h-4 w-4" />
            This section is only active when the case is sent to Sales for review.
          </p>
        </div>
      )}

      <div className="space-y-6">
        {/* Section 3.1 – Case Details */}
        <div>
          <h4 className="font-medium mb-4 flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" />
            Case Details
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-muted/30 p-4 rounded-lg">
            <div>
              <Label className="text-xs text-muted-foreground">Case ID</Label>
              <p className="mt-1 font-mono">{caseData.id}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Client Name</Label>
              <p className="mt-1">{caseData.clientName}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Case Type</Label>
              <p className="mt-1">{caseData.caseType}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Status</Label>
              <p className="mt-1">{caseData.status}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Line of Business</Label>
              <p className="mt-1">{caseData.lineOfBusiness || caseData.clientData?.lineOfBusiness || '-'}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Sales Owner</Label>
              <p className="mt-1">{caseData.clientData?.salesOwner || '-'}</p>
            </div>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Section 3.2.1 – 312 Case Summary */}
        {/* Only show if case exists and was not auto-closed */}
        {case312Data && case312Data.status !== 'Auto-Closed' && case312Data.disposition !== 'No additional CAM escalation required' && (
          <div>
            <h4 className="font-medium mb-4">312 Case</h4>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">312 Review Information</CardTitle>
                <CardDescription>Privacy-filtered summary for Sales Owner review</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">312 Due Date</Label>
                    <p className="mt-1">{case312Data.dueDate}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">312 Model Result</Label>
                    <p className="mt-1">{case312Data.modelResult}</p>
                  </div>
                  <div className="md:col-span-2">
                    <Label className="text-xs text-muted-foreground">312 Model Result Description</Label>
                    <p className="mt-1">{case312Data.modelResultDescription}</p>
                  </div>
                </div>

                {/* Expected Activity - Volume */}
                {case312Data.expectedActivityVolume && (
                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Expected Activity – Volume (broken out by FLU SOR)</Label>
                    <div className="grid grid-cols-2 gap-3 bg-muted/30 p-3 rounded-lg">
                      {case312Data.expectedActivityVolume.electronicTransfers !== undefined && (
                        <div>
                          <span className="text-xs text-muted-foreground">Electronic Transfers:</span>
                          <p className="font-medium">{case312Data.expectedActivityVolume.electronicTransfers}</p>
                        </div>
                      )}
                      {case312Data.expectedActivityVolume.cashChecks !== undefined && (
                        <div>
                          <span className="text-xs text-muted-foreground">Cash/Checks:</span>
                          <p className="font-medium">{case312Data.expectedActivityVolume.cashChecks}</p>
                        </div>
                      )}
                      {case312Data.expectedActivityVolume.ddqFields && Object.entries(case312Data.expectedActivityVolume.ddqFields).map(([key, value]) => (
                        <div key={key}>
                          <span className="text-xs text-muted-foreground">{key}:</span>
                          <p className="font-medium">{value}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Expected Activity - Value */}
                {case312Data.expectedActivityValue && (
                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">Expected Activity – Value (broken out by FLU SOR)</Label>
                    <div className="grid grid-cols-2 gap-3 bg-muted/30 p-3 rounded-lg">
                      {case312Data.expectedActivityValue.electronicTransfers !== undefined && (
                        <div>
                          <span className="text-xs text-muted-foreground">Electronic Transfers:</span>
                          <p className="font-medium">${case312Data.expectedActivityValue.electronicTransfers.toLocaleString()}</p>
                        </div>
                      )}
                      {case312Data.expectedActivityValue.cashChecks !== undefined && (
                        <div>
                          <span className="text-xs text-muted-foreground">Cash/Checks:</span>
                          <p className="font-medium">${case312Data.expectedActivityValue.cashChecks.toLocaleString()}</p>
                        </div>
                      )}
                      {case312Data.expectedActivityValue.ddqFields && Object.entries(case312Data.expectedActivityValue.ddqFields).map(([key, value]) => (
                        <div key={key}>
                          <span className="text-xs text-muted-foreground">{key}:</span>
                          <p className="font-medium">${value.toLocaleString()}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Purpose of Relationship - GBOM only */}
                {case312Data.purposeOfRelationship && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Purpose of Relationship (GB/GM only)</Label>
                    <p className="mt-1">{case312Data.purposeOfRelationship}</p>
                  </div>
                )}

                {/* Purpose of Account - ML PB only */}
                {case312Data.purposeOfAccount && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Purpose of Account (ML PB only)</Label>
                    <p className="mt-1">{case312Data.purposeOfAccount}</p>
                  </div>
                )}

                {/* Source of Funds */}
                {case312Data.sourceOfFunds && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Source of Funds</Label>
                    <p className="mt-1">{case312Data.sourceOfFunds}</p>
                  </div>
                )}

                <div className="p-3 bg-blue-50 border border-blue-200 rounded text-sm text-blue-800">
                  <Info className="h-4 w-4 inline mr-2" />
                  Detailed transaction data and specific activity metrics are not displayed to prevent tipping off.
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Section 3.2.2 – CAM Case Summary */}
        {/* Only show if case exists and was not auto-closed */}
        {camCaseData && monitoringDashboard && camCaseData.status !== 'Auto-Closed' && camCaseData.disposition !== 'No additional CAM escalation required' && (
          <div>
            <h4 className="font-medium mb-4">CAM Case</h4>
            <div className="space-y-4">
              {/* Section 3.2.2.1 – FLU Monitoring */}
              {monitoringDashboard.lobMonitoringControls && monitoringDashboard.lobMonitoringControls.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">FLU Monitoring</CardTitle>
                    <CardDescription>Front Line Unit monitoring activity summary</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Activity Description</TableHead>
                          <TableHead>Activity Count</TableHead>
                          <TableHead>Last Completed Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monitoringDashboard.lobMonitoringControls.map((control, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{control.activityDescription}</TableCell>
                            <TableCell>{control.supportingDataPoints || '-'}</TableCell>
                            <TableCell>{monitoringDashboard.trmsFLU?.[0]?.date || '-'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              {/* Section 3.2.2.2 – TRMS Summary */}
              {((monitoringDashboard.trmsFLU && monitoringDashboard.trmsFLU.length > 0) || 
                (monitoringDashboard.trmsOther && monitoringDashboard.trmsOther.length > 0)) && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">TRMS Summary</CardTitle>
                    <CardDescription>Transaction Monitoring and Risk Management System cases</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Monitoring Process</TableHead>
                          <TableHead>Description Reason</TableHead>
                          <TableHead>Score Type (Product)</TableHead>
                          <TableHead>Narrative</TableHead>
                          <TableHead>TRMS ID</TableHead>
                          <TableHead>Submitter LOB</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {[...(monitoringDashboard.trmsFLU || []), ...(monitoringDashboard.trmsOther || [])].map((trms, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{trms.monitoringProcess}</TableCell>
                            <TableCell>{trms.descriptionReason}</TableCell>
                            <TableCell>{trms.impactType}</TableCell>
                            <TableCell className="max-w-xs truncate">{trms.narrative}</TableCell>
                            <TableCell className="font-mono text-xs">{trms.id}</TableCell>
                            <TableCell>{trms.submitterLOB}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              {/* Section 3.2.2.3 – Second Line Care */}
              {monitoringDashboard.secondLineCases && monitoringDashboard.secondLineCases.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Second Line Care</CardTitle>
                    <CardDescription>Second Line of Defense cases</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Case Description</TableHead>
                          <TableHead>Narrative</TableHead>
                          <TableHead>Case Date</TableHead>
                          <TableHead>LOB</TableHead>
                          <TableHead>Associated TRMS</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monitoringDashboard.secondLineCases.map((slc, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{slc.caseDescription}</TableCell>
                            <TableCell className="max-w-xs truncate">{slc.narrative}</TableCell>
                            <TableCell>{slc.date}</TableCell>
                            <TableCell>{slc.lob}</TableCell>
                            <TableCell className="font-mono text-xs">{slc.linkedTRMS || '-'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              {/* Section 3.2.2.4 – First Party Fraud Cases */}
              {monitoringDashboard.fraudCases && monitoringDashboard.fraudCases.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">First Party Fraud Cases</CardTitle>
                    <CardDescription>First party fraud detection cases</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>LOB</TableHead>
                          <TableHead>Narrative</TableHead>
                          <TableHead>Case Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monitoringDashboard.fraudCases.map((fraud, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{fraud.lob}</TableCell>
                            <TableCell className="max-w-md">{fraud.narrative}</TableCell>
                            <TableCell>{fraud.date}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              {/* Section 3.2.2.5 – Sanctions */}
              {monitoringDashboard.sanctionDetails && monitoringDashboard.sanctionDetails.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Sanctions</CardTitle>
                    <CardDescription>Sanctions screening alerts and outcomes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>LOB</TableHead>
                          <TableHead>Block/Reject</TableHead>
                          <TableHead>Product</TableHead>
                          <TableHead>Narrative</TableHead>
                          <TableHead>Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monitoringDashboard.sanctionDetails.map((sanction, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{sanction.lob}</TableCell>
                            <TableCell>
                              <Badge variant={sanction.blockReject ? 'destructive' : 'outline'}>
                                {sanction.blockReject ? 'Yes' : 'No'}
                              </Badge>
                            </TableCell>
                            <TableCell>{sanction.product}</TableCell>
                            <TableCell className="max-w-xs">{sanction.alertDescription}</TableCell>
                            <TableCell>{sanction.alertDate}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              {/* CAM Triggers Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">CAM Case Triggers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {camCaseData.triggers?.map((trigger, idx) => (
                      <Badge key={idx} variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                        {trigger}
                      </Badge>
                    )) || <span className="text-sm text-muted-foreground">No triggers</span>}
                  </div>
                </CardContent>
              </Card>

              <div className="p-3 bg-blue-50 border border-blue-200 rounded text-sm text-blue-800">
                <Info className="h-4 w-4 inline mr-2" />
                Detailed SAR information is not displayed to Sales Owners to maintain confidentiality and prevent tipping off.
              </div>
            </div>
          </div>
        )}

        <Separator className="my-6" />

        {/* Section 3.3 – Case Processor Comments */}
        <div>
          <h4 className="font-medium mb-4 flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            Case Processor Comments
          </h4>
          {processorComments.length > 0 ? (
            <div className="space-y-3">
              {processorComments.map((comment, idx) => (
                <Card key={idx}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">
                          {comment.caseType === '312' ? '312 Case' : 'CAM Case'}
                        </Badge>
                        <span className="font-medium">{comment.processorName}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">{comment.date}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{comment.comment}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="p-6 border rounded-lg bg-muted/20 text-center">
              <MessageSquare className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No comments from case processor yet</p>
            </div>
          )}
        </div>

        <Separator className="my-6" />

        {/* Section 3.4 – Sales Owner Response */}
        <div>
          <h4 className="font-semibold text-lg mb-4">Sales Owner Response</h4>
          
          {isSalesOwner ? (
            <div className="space-y-4">
              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <p className="text-sm text-purple-800 flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  As the Sales Owner, please provide your feedback on the case review. Your input will help the AML team understand client context and business relationships.
                </p>
              </div>

              <div>
                <Label className="font-medium">
                  Your Comments and Feedback
                  <span className="text-xs text-muted-foreground ml-2">
                    ({(response.comments || '').length}/4000 characters)
                  </span>
                </Label>
                <Textarea
                  value={response.comments || ''}
                  onChange={(e) => {
                    if (e.target.value.length <= 4000) {
                      setResponse({ ...response, comments: e.target.value });
                    }
                  }}
                  disabled={isSubmitted}
                  className="mt-2"
                  placeholder="Please provide any relevant context about the client's business activities, expected behavior, or other information that may assist the AML review team. Maximum 4000 characters."
                  rows={6}
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Your response will be shared with the AML case processor to aid in their review and disposition decision.
                </p>
              </div>

              {/* Action Buttons */}
              {!isSubmitted && (
                <div className="flex gap-3 justify-end mt-6 pt-6 border-t">
                  <Button variant="outline" onClick={onCancel}>
                    <X className="mr-2 h-4 w-4" />
                    Cancel
                  </Button>
                  <Button variant="secondary" onClick={onSave}>
                    <Save className="mr-2 h-4 w-4" />
                    Save Draft
                  </Button>
                  <Button onClick={onSubmit}>
                    <Send className="mr-2 h-4 w-4" />
                    Return to AML Processor
                  </Button>
                </div>
              )}

              {isSubmitted && (
                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-800 flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    Your response has been submitted and returned to the AML processor.
                    {response.submittedBy && ` Submitted by ${response.submittedBy} on ${new Date(response.submittedDate!).toLocaleDateString()}`}
                  </p>
                </div>
              )}
            </div>
          ) : (
            // View-only for AML Processors
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-800 flex items-center gap-2">
                  <Info className="h-4 w-4" />
                  This section shows the Sales Owner's response once they have reviewed the case.
                </p>
              </div>

              {response.isSubmitted ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Sales Owner Feedback</CardTitle>
                    <CardDescription>
                      Submitted by {response.submittedBy} on {new Date(response.submittedDate!).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {response.comments || 'No comments provided'}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="p-6 border rounded-lg bg-muted/20 text-center">
                  <Shield className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Awaiting Sales Owner response
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}