import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './select';

interface BooleanFilterProps {
  value: string;
  onChange: (value: string) => void;
}

export function BooleanFilter({ value, onChange }: BooleanFilterProps) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="h-7 text-xs">
        <SelectValue placeholder="All" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">All</SelectItem>
        <SelectItem value="yes">Yes</SelectItem>
        <SelectItem value="no">No</SelectItem>
      </SelectContent>
    </Select>
  );
}
