import { useState } from 'react';
import { Button } from './button';
import { Select, SelectContent, SelectItem, SelectTrigger } from './select';
import { Popover, PopoverContent, PopoverTrigger } from './popover';
import { Calendar } from './calendar';
import { Filter, CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';

interface DateFilterProps {
  filterType: string;
  onFilterTypeChange: (value: string) => void;
  dateValue?: Date;
  onDateValueChange: (date: Date | undefined) => void;
  dateValueEnd?: Date;
  onDateValueEndChange?: (date: Date | undefined) => void;
}

export function DateFilter({
  filterType,
  onFilterTypeChange,
  dateValue,
  onDateValueChange,
  dateValueEnd,
  onDateValueEndChange
}: DateFilterProps) {
  return (
    <div className="flex items-center gap-1">
      <Select value={filterType} onValueChange={onFilterTypeChange}>
        <SelectTrigger className="h-7 w-[30px] p-0 border-0">
          <Filter className="h-3 w-3" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="equals">Equals</SelectItem>
          <SelectItem value="notEquals">Doesn't equal</SelectItem>
          <SelectItem value="before">Before</SelectItem>
          <SelectItem value="after">After</SelectItem>
          <SelectItem value="between">Between</SelectItem>
          <SelectItem value="blank">Blank</SelectItem>
          <SelectItem value="notBlank">Not blank</SelectItem>
        </SelectContent>
      </Select>
      
      {filterType !== 'blank' && filterType !== 'notBlank' && (
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className="h-7 text-xs px-2 justify-start text-left font-normal"
            >
              <CalendarIcon className="mr-1 h-3 w-3" />
              {dateValue ? format(dateValue, 'MM/dd/yyyy') : 'Pick...'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={dateValue}
              onSelect={onDateValueChange}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      )}
      
      {filterType === 'between' && onDateValueEndChange && (
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className="h-7 text-xs px-2 justify-start text-left font-normal"
            >
              <CalendarIcon className="mr-1 h-3 w-3" />
              {dateValueEnd ? format(dateValueEnd, 'MM/dd/yyyy') : 'End...'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={dateValueEnd}
              onSelect={onDateValueEndChange}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      )}
    </div>
  );
}
