import { Input } from './input';
import { Select, SelectContent, SelectItem, SelectTrigger } from './select';
import { Filter } from 'lucide-react';

interface TextFilterProps {
  value: string;
  onChange: (value: string) => void;
  filterType: string;
  onFilterTypeChange: (value: string) => void;
  placeholder?: string;
}

export function TextFilter({
  value,
  onChange,
  filterType,
  onFilterTypeChange,
  placeholder = 'Filter...'
}: TextFilterProps) {
  return (
    <div className="flex items-center gap-1">
      <Input 
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-7 text-xs"
      />
      <Select value={filterType} onValueChange={onFilterTypeChange}>
        <SelectTrigger className="h-7 w-[30px] p-0 border-0">
          <Filter className="h-3 w-3" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="contains">Contains</SelectItem>
          <SelectItem value="notContains">Doesn't contain</SelectItem>
          <SelectItem value="equals">Equals</SelectItem>
          <SelectItem value="notEquals">Doesn't equal</SelectItem>
          <SelectItem value="beginsWith">Begins with</SelectItem>
          <SelectItem value="endsWith">Ends with</SelectItem>
          <SelectItem value="blank">Blank</SelectItem>
          <SelectItem value="notBlank">Not blank</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}
