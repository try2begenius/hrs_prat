# Manually Triggered Cases - Documentation

## Overview
Manually triggered cases are cases created through an **ad-hoc manual process** rather than through the automated 312/CAM model triggers. These cases are initiated by analysts or managers when they identify suspicious activity or risk factors that require review outside of the normal automated workflow.

---

## How to Identify Manually Triggered Cases

### 1. **Field Indicator**

```typescript
isManuallyTriggered: boolean
```

**Field Details:**
- **Field Name:** `isManuallyTriggered`
- **Display Name:** "Manually Triggered"
- **Data Type:** Boolean (true/false)
- **Source:** Case Creation Process
- **Default Value:** `false`
- **Description:** Indicates if case was created through ad-hoc manual process vs. automated trigger

**In the Case Object:**
```typescript
interface Case {
  // ... other fields
  isManuallyTriggered?: boolean; // Manually Triggered (ad-hoc process)
  // ... other fields
}
```

### 2. **Database Query (Oracle SQL)**

```sql
-- Find all manually triggered cases
SELECT 
  CASE_ID,
  CLIENT_NAME,
  CASE_TYPE,
  STATUS,
  CREATED_DATE,
  ASSIGNED_TO
FROM CAM_312_CASES
WHERE IS_MANUALLY_TRIGGERED = 'Y';

-- Count manually triggered cases by status
SELECT 
  STATUS,
  COUNT(*) as CASE_COUNT
FROM CAM_312_CASES
WHERE IS_MANUALLY_TRIGGERED = 'Y'
GROUP BY STATUS
ORDER BY CASE_COUNT DESC;

-- Find manually triggered cases created in last 30 days
SELECT 
  CASE_ID,
  CLIENT_NAME,
  CREATED_DATE,
  ASSIGNED_TO
FROM CAM_312_CASES
WHERE IS_MANUALLY_TRIGGERED = 'Y'
  AND CREATED_DATE >= SYSDATE - 30
ORDER BY CREATED_DATE DESC;
```

### 3. **JSON Schema Validation**

```json
{
  "isManuallyTriggered": {
    "type": "boolean",
    "description": "Manually Triggered (ad-hoc)",
    "default": false
  }
}
```

### 4. **UI Identification**

**Worklist Quick Filter:**
The worklist includes a dedicated quick filter button:

```
┌─────────────────────────────────┐
│  🏢 Manually Triggered    [5]   │
└─────────────────────────────────┘
```

- **Icon:** Building2 (🏢)
- **Badge:** Shows real-time count of manually triggered cases
- **Filter:** Clicking this button filters the worklist to show ONLY cases where `isManuallyTriggered = true`

**Location in UI:**
```
My Worklist > Quick Filters:
- [ ] All Cases
- [ ] Unassigned
- [ ] In Progress  
- [ ] Past Due
- [✓] Manually Triggered  ← This filter
```

---

## When Cases Are Manually Triggered

### Common Scenarios:

1. **Ad-Hoc Risk Assessment**
   - Analyst identifies suspicious activity during routine monitoring
   - Risk indicator surfaces outside of scheduled model runs
   - Relationship manager escalates concerns about client behavior

2. **Management Request**
   - Executive or senior management requests review of specific client
   - Regulatory inquiry or examination requires case documentation
   - Internal audit identifies gap requiring investigation

3. **External Triggers**
   - Law enforcement inquiry
   - Media/negative news about client
   - Customer due diligence refresh identifies new risk factors
   - Related party investigation expands to additional clients

4. **System Limitations**
   - Client falls outside automated model scope but requires review
   - Technical issues with automated trigger process
   - New risk typology not yet incorporated into models

5. **Proactive Monitoring**
   - Transaction pattern changes not severe enough to trigger model
   - Client behavior warrants closer examination
   - Portfolio review identifies outlier requiring documentation

---

## Data Characteristics

### Manually Triggered Cases vs. Model-Triggered Cases

| Characteristic | Manually Triggered | Model-Triggered |
|----------------|-------------------|-----------------|
| **Creation Method** | Manual analyst input | Automated process |
| **isManuallyTriggered** | `true` | `false` |
| **Model Score** | May not have 312 score | Always has 312 model score |
| **Trigger Documentation** | Manual notes/justification | Model output report |
| **Frequency** | Ad-hoc/as needed | Scheduled (daily/weekly) |
| **Priority Assignment** | Analyst discretion | Model-based risk scoring |

---

## Example Mock Data

### Manually Triggered Case Example

```typescript
{
  id: '312-2025-015',
  clientId: 'GCI-678901',
  gci: 'GCI-678901',
  clientName: 'Pacific Trade Ventures Limited',
  caseType: '312 Review',
  status: 'In Progress',
  riskLevel: 'High',
  priority: 'High',
  assignedTo: 'Michael Chen',
  createdDate: '2025-10-25',
  dueDate: '2025-11-08',
  lastActivity: '2025-10-28',
  alertCount: 4,
  transactionCount: 89,
  totalAmount: 4200000,
  description: 'Manual trigger - elevated risk based on recent negative news and unusual transaction patterns',
  lineOfBusiness: 'GB/GM',
  is312Case: true,
  
  // ✅ MANUALLY TRIGGERED INDICATOR
  isManuallyTriggered: true,  // <--- THIS IS THE KEY FIELD
  
  isBACEmployee: false,
  isBACAffiliate: false,
  isRegO: false,
  modelOutcome: 'Pending Review',
  derivedDisposition: 'Pending'
}
```

### Standard Model-Triggered Case (for comparison)

```typescript
{
  id: '312-2025-001',
  clientId: 'GCI-AUTO-001',
  gci: 'GCI-AUTO-001',
  clientName: 'Standard Manufacturing Inc.',
  caseType: '312 Review',
  status: 'Complete',
  riskLevel: 'Medium',
  priority: 'Medium',
  assignedTo: 'Sarah Mitchell',
  createdDate: '2025-10-01',
  dueDate: '2025-10-15',
  lastActivity: '2025-10-20',
  alertCount: 2,
  transactionCount: 45,
  totalAmount: 2150000,
  description: 'Standard 312 model trigger - routine enhanced due diligence',
  lineOfBusiness: 'GB/GM',
  is312Case: true,
  
  // ❌ NOT MANUALLY TRIGGERED
  isManuallyTriggered: false,  // <--- Default for automated cases
  
  isBACEmployee: false,
  isBACAffiliate: false,
  isRegO: false,
  modelOutcome: 'No CAM Case',
  derivedDisposition: 'No additional CAM escalation required'
}
```

---

## Code Examples

### TypeScript/JavaScript Filtering

```typescript
// Filter to get only manually triggered cases
const manuallyTriggeredCases = allCases.filter(
  (caseItem) => caseItem.isManuallyTriggered === true
);

// Count manually triggered cases
const manualCount = allCases.filter(c => c.isManuallyTriggered).length;

// Check if specific case is manually triggered
const isManual = caseData.isManuallyTriggered;
if (isManual) {
  console.log('This case was manually created');
} else {
  console.log('This case was triggered by the automated model');
}

// Get cases that are both manually triggered and high risk
const highRiskManualCases = allCases.filter(
  c => c.isManuallyTriggered && c.riskLevel === 'High'
);
```

### React Component Usage

```tsx
// Quick filter button in worklist
const manuallyTriggeredCount = userAccessibleCases.filter(
  c => c.isManuallyTriggered
).length;

<Button
  variant={quickFilter === 'manuallyTriggered' ? 'default' : 'outline'}
  size="sm"
  onClick={() => setQuickFilter('manuallyTriggered')}
>
  <Building2 className="mr-2 h-4 w-4" />
  Manually Triggered
  <Badge variant="secondary" className="ml-2">
    {manuallyTriggeredCount}
  </Badge>
</Button>

// Apply filter logic
if (quickFilter === 'manuallyTriggered' && !caseItem.isManuallyTriggered) {
  return false; // Exclude from filtered results
}
```

---

## API Endpoints

### Get Manually Triggered Cases

```
GET /api/cases?isManuallyTriggered=true
```

**Response:**
```json
{
  "cases": [
    {
      "id": "312-2025-015",
      "clientName": "Pacific Trade Ventures Limited",
      "isManuallyTriggered": true,
      "status": "In Progress",
      "createdDate": "2025-10-25"
    }
  ],
  "totalCount": 5,
  "page": 1,
  "pageSize": 50
}
```

### Create Manually Triggered Case

```
POST /api/cases/manual-create
```

**Request Body:**
```json
{
  "clientId": "GCI-678901",
  "caseType": "312 Review",
  "priority": "High",
  "riskLevel": "High",
  "assignedTo": "Michael Chen",
  "description": "Manual trigger due to negative news and unusual activity",
  "lineOfBusiness": "GB/GM",
  "isManuallyTriggered": true
}
```

---

## Reporting & Analytics

### Key Metrics

```sql
-- Percentage of cases that are manually triggered
SELECT 
  ROUND(
    (SUM(CASE WHEN IS_MANUALLY_TRIGGERED = 'Y' THEN 1 ELSE 0 END) * 100.0) / COUNT(*),
    2
  ) as PCT_MANUAL_TRIGGER
FROM CAM_312_CASES;

-- Average days to complete: Manual vs Automated
SELECT 
  CASE 
    WHEN IS_MANUALLY_TRIGGERED = 'Y' THEN 'Manual'
    ELSE 'Automated'
  END as TRIGGER_TYPE,
  ROUND(AVG(COMPLETION_DATE - CREATED_DATE), 1) as AVG_DAYS_TO_COMPLETE,
  COUNT(*) as CASE_COUNT
FROM CAM_312_CASES
WHERE COMPLETION_DATE IS NOT NULL
GROUP BY IS_MANUALLY_TRIGGERED;

-- Monthly trend of manually triggered cases
SELECT 
  TO_CHAR(CREATED_DATE, 'YYYY-MM') as MONTH,
  COUNT(*) as MANUAL_CASES
FROM CAM_312_CASES
WHERE IS_MANUALLY_TRIGGERED = 'Y'
GROUP BY TO_CHAR(CREATED_DATE, 'YYYY-MM')
ORDER BY MONTH DESC;
```

---

## Business Rules

1. **Creation Authority**
   - Central Team Managers can create manually triggered cases
   - Central Team Analysts can request manual case creation (requires approval)
   - Sales Owners cannot create manually triggered cases

2. **Documentation Requirements**
   - Manual cases require justification in description field
   - Supporting documentation should be attached to case
   - Rationale for manual trigger must be documented in case notes

3. **Priority Assignment**
   - Manually triggered cases typically start with "High" or "Urgent" priority
   - Creator determines initial priority based on risk assessment
   - Priority can be adjusted during case workflow

4. **SLA Considerations**
   - Same SLA rules apply as automated cases
   - Due date calculated from creation date (typically 14 business days)
   - No special SLA extensions for manually triggered cases

5. **Audit Trail**
   - System logs user who created manual case
   - Creation timestamp recorded
   - Justification permanently stored in case history

---

## Best Practices

### For Analysts Creating Manual Cases:

1. **Clear Documentation**
   - Document specific reason for manual trigger
   - Include reference to source of concern (news article, transaction pattern, etc.)
   - Note any time-sensitive factors

2. **Appropriate Use**
   - Use manual triggers for legitimate risk concerns
   - Don't duplicate existing automated model triggers
   - Coordinate with team to avoid duplicate case creation

3. **Risk Assessment**
   - Assign appropriate risk level based on available information
   - Consider client's existing risk rating
   - Factor in urgency and potential regulatory implications

4. **Communication**
   - Notify relevant stakeholders (sales owner, manager)
   - Update case notes with progress
   - Escalate concerns promptly if needed

---

## Related Documentation

- `/src/app/data/dataDictionary.ts` - Field definition
- `/src/app/components/CaseWorklist.tsx` - UI implementation
- `/src/app/WORKBASKET_VALIDATION.md` - Worklist feature validation
- `/src/app/data/enhancedMockDataSchema.json` - JSON schema
- `/documentation/oracle_schema.sql` - Database schema

---

## Summary

**To know if a case is manually triggered, check:**

✅ **Field:** `isManuallyTriggered` = `true`  
✅ **Database:** `IS_MANUALLY_TRIGGERED` = `'Y'`  
✅ **UI:** Case appears when "Manually Triggered" quick filter is active  
✅ **API:** `isManuallyTriggered: true` in JSON response  

**Key Difference:**
- **Manual:** Created by analyst/manager (ad-hoc process)
- **Automated:** Created by 312 model or CAM trigger (scheduled process)
