import { Case, Activity, Alert, User, Population, Report } from '../types';
import { caseFlowScenarios } from './caseFlowScenarios';
import { caseFlowActivities } from './caseFlowActivities';
import { workflow312CamCases } from './312CamWorkflowMockData';

export const mockUsers: User[] = [
  { id: 'U001', name: 'Sarah Mitchell', email: 'sarah.mitchell@ml.com', role: 'Central Team Manager', hasM_I_Entitlement: false },
  { id: 'U002', name: 'Carlos Rivera', email: 'carlos.rivera@ml.com', role: 'Central Team Manager', hasM_I_Entitlement: false },
  { id: 'U003', name: 'Michael Chen', email: 'michael.chen@ml.com', role: 'Central Team Analyst', hasM_I_Entitlement: true },
  { id: 'U004', name: 'Jennifer Wu', email: 'jennifer.wu@ml.com', role: 'Central Team Analyst', hasM_I_Entitlement: true },
  { id: 'U005', name: 'Lisa Brown', email: 'lisa.brown@ml.com', role: 'Central Team Analyst', hasM_I_Entitlement: false },
  { id: 'U006', name: 'Kevin Rogers', email: 'kevin.rogers@ml.com', role: 'Central Team Analyst', hasM_I_Entitlement: false },
  { id: 'U007', name: 'Robert Anderson', email: 'robert.anderson@ml.com', role: 'View Only', hasM_I_Entitlement: false },
  { id: 'U008', name: 'David Park', email: 'david.park@ml.com', role: 'Sales Owner', hasM_I_Entitlement: false },
  { id: 'U009', name: 'Amanda Torres', email: 'amanda.torres@ml.com', role: 'Sales Owner', hasM_I_Entitlement: false },
];

// Comprehensive case data covering all LOBs, case types, user assignments, and case flow scenarios
export const mockCases: Case[] = [
  // Include comprehensive 312 CAM workflow demonstration cases
  ...workflow312CamCases,
  
  // Include all case flow scenarios
  ...caseFlowScenarios,
  
  // COMPLETE CASES for testing Edit Case functionality
  {
    id: '312-2025-099',
    clientId: 'GCI-999111',
    gci: 'GCI-999111',
    mpId: 'MP-45789',
    partyId: 'PTY-88901',
    coperId: 'CPR-QWE456',
    clientName: 'Completed Case Example 1',
    caseType: '312 Review',
    status: 'Complete',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Sarah Mitchell',
    centralTeamContact: 'Sarah Mitchell',
    createdDate: '2025-09-15',
    dueDate: '2025-09-29',
    lastActivity: '2025-10-01',
    completionDate: '2025-10-01',
    alertCount: 5,
    transactionCount: 145,
    totalAmount: 8500000,
    description: 'Completed 312 case - satisfactory review completed',
    is312Case: true,
    lineOfBusiness: 'GB/GM',
    modelOutcome: 'No CAM Case',
    derivedDisposition: 'No Suspicious Activity',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    clientData: {
      clientId: 'GCI-999111',
      gciNumber: 'GCI-999111',
      legalName: 'Completed Case Example 1 Corp',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2020-03-15',
      clientType: 'Corporation',
      jurisdiction: 'United States',
      dataSource: 'CMT',
      lastUpdated: '2025-10-01',
      isEmployee: false
    }
  },
  {
    id: 'CAM-2025-098',
    clientId: 'GCI-999222',
    gci: 'GCI-999222',
    mpId: 'MP-55890',
    partyId: 'PTY-99012',
    coperId: 'CPR-RTY789',
    clientName: 'Completed Case Example 2',
    caseType: 'CAM Review',
    status: 'Complete',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-09-20',
    dueDate: '2025-10-04',
    lastActivity: '2025-10-05',
    completionDate: '2025-10-05',
    alertCount: 3,
    transactionCount: 89,
    totalAmount: 4200000,
    description: 'Completed CAM case - no suspicious activity found',
    lineOfBusiness: 'PB',
    modelOutcome: 'No CAM Case',
    derivedDisposition: 'No Suspicious Activity',
    isBACEmployee: false,
    isBACAffiliate: true,
    isRegO: false,
    isManuallyTriggered: false,
    clientData: {
      clientId: 'GCI-999222',
      gciNumber: 'GCI-999222',
      legalName: 'Completed Case Example 2 LLC',
      salesOwner: 'Patricia Lee (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2019-06-10',
      clientType: 'LLC',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-05',
      isEmployee: false
    }
  },
  {
    id: '312-2025-097',
    clientId: 'GCI-999333',
    clientName: 'Completed Case Example 3',
    caseType: '312 Review',
    status: 'Complete',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    centralTeamContact: 'Sarah Mitchell',
    createdDate: '2025-09-10',
    dueDate: '2025-09-24',
    lastActivity: '2025-09-28',
    completionDate: '2025-09-28',
    alertCount: 7,
    transactionCount: 210,
    totalAmount: 12300000,
    description: 'Completed 312 case - review completed successfully',
    is312Case: true,
    lineOfBusiness: 'ML',
    modelOutcome: 'No CAM Case',
    derivedDisposition: 'No Suspicious Activity',
    clientData: {
      clientId: 'GCI-999333',
      gciNumber: 'GCI-999333',
      legalName: 'Completed Case Example 3 Trust',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2018-11-20',
      clientType: 'Trust',
      jurisdiction: 'United States',
      dataSource: 'WCC',
      lastUpdated: '2025-09-28',
      isEmployee: false
    }
  },

  // 312 Cases - GB/GM LOB
  {
    id: '312-2025-001',
    clientId: 'GCI-892341',
    clientName: 'GlobalTech Industries Corp',
    caseType: '312 Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    centralTeamContact: 'Sarah Mitchell',
    createdDate: '2025-10-15',
    dueDate: '2025-10-29',
    lastActivity: '2025-10-26',
    alertCount: 8,
    transactionCount: 245,
    totalAmount: 15700000,
    description: '312 enhanced due diligence review - DGA due date approaching. Client shows structured transactions and offshore activity.',
    is312Case: true,
    entityName: 'GlobalTech Industries Corporation',
    gci: 'GCI-892341',
    mpId: 'MP-89234',
    partyId: 'PTY-12345',
    lineOfBusiness: 'GB/GM',
    isBACEmployee: false,
    isBACAffiliate: true,
    isRegO: false,
    naicsCode: '541512',
    naicsDescription: 'Computer Systems Design Services',
    refreshDueDates: ['2025-11-15', '2026-05-15'],
    lastRefreshCompletionDate: '2025-05-15',
    clientOwners: ['David Park', 'Sarah Mitchell'],
    amlAttributes: ['CBA-High Risk Jurisdiction', 'CBA-Complex Ownership', 'AML-Enhanced Monitoring'],
    case312Data: {
      dueDate: '2025-10-29',
      aging: 11,
      status: 'In Progress',
      disposition: 'Pending',
      modelResult: 'High Risk',
      modelResultDescription: 'Client exhibits elevated risk indicators including cross-border wire activity, high cash usage relative to business type, and complex ownership structure.',
      expectedActivityVolume: {
        ddqFields: {
          'Wire Transfers': 85,
          'ACH Transactions': 120,
          'Cash Deposits': 25,
          'International Wires': 45,
        }
      },
      expectedActivityValue: {
        ddqFields: {
          'Wire Transfers': 12500000,
          'ACH Transactions': 3200000,
          'Cash Deposits': 450000,
          'International Wires': 8900000,
        }
      },
      expectedCrossBorderActivity: 'Expected countries: Canada, United Kingdom, Germany, France, Netherlands - related to technology consulting and software development services.',
      purposeOfRelationship: 'Technology consulting and software development services with focus on financial services clients across North America and Europe.',
      sourceOfFunds: 'Revenue from software licensing, consulting fees, and managed services contracts',
    },
    clientData: {
      clientId: 'GCI-892341',
      gciNumber: 'GCI-892341',
      legalName: 'GlobalTech Industries Corporation',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2017-05-12',
      clientType: 'Corporate',
      jurisdiction: 'Cayman Islands',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.7,
      riskRatingDate: '2025-10-20',
      model312Score: 8.5,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    camCaseData: {
      dueDate: '2025-10-29',
      aging: 11,
      status: 'In Progress',
      disposition: 'Pending',
      triggers: ['FLU/FLD Activity', 'TRMS Activity', 'Second Line Activity', 'Sanctions Activity']
    },
    monitoringDashboard: {
      trmsFLU: [
        {
          id: 'TRMS-FLU-2025-0451',
          type: 'Follow-up',
          monitoringProcess: 'FLU Weekly Review',
          descriptionReason: 'Unusually large wire transfer to offshore account',
          impactType: 'High',
          narrative: 'Client initiated $2.5M wire to Cayman Islands entity. Transfer appears to be for legitimate business purpose based on client profile, but flagged for review due to amount and jurisdiction.',
          date: '2025-10-15',
          submitterLOB: 'GB/GM',
          submitterName: 'Jennifer Wu'
        },
        {
          id: 'TRMS-FLU-2025-0498',
          type: 'Update',
          monitoringProcess: 'FLD Enhanced Monitoring',
          descriptionReason: 'Structured transaction pattern detected',
          impactType: 'Medium',
          narrative: 'Multiple transactions just below reporting threshold over 2-week period. Client explanation received indicating business operational needs. Monitoring to continue.',
          date: '2025-10-22',
          submitterLOB: 'GB/GM',
          submitterName: 'Kevin Rogers'
        }
      ],
      trmsOther: [
        {
          id: 'TRMS-2025-1247',
          type: 'Informational',
          monitoringProcess: 'Client Risk Rating Review',
          descriptionReason: 'Annual risk rating update',
          impactType: 'Low',
          narrative: 'Client risk rating maintained at High due to offshore jurisdiction and transaction patterns. No change from previous assessment.',
          date: '2025-09-30',
          submitterLOB: 'GB/GM',
          submitterName: 'Lisa Brown'
        }
      ],
      secondLineCases: [
        {
          caseId: '2L-2025-0089',
          caseType: 'Testing',
          caseStatus: 'Closed',
          caseDescription: 'Q3 2025 Transaction Monitoring Testing',
          caseReason: 'Routine Sample Testing',
          narrative: 'Sample testing of transaction monitoring alerts. Client included in sample; no issues identified with alert generation or disposition.',
          date: '2025-10-01',
          lob: 'GB/GM',
          linkedTRMS: 'TRMS-2025-1247',
          sarYN: false,
          partyInSAR: undefined
        },
        {
          caseId: '2L-2025-0124',
          caseType: 'Quality Assurance',
          caseStatus: 'Open',
          caseDescription: 'QA Review of 312 Program',
          caseReason: 'Quality Assurance Sample',
          narrative: 'Quality assurance review of 312 case dispositions. This client file selected for review as part of October 2025 QA sample.',
          date: '2025-10-20',
          lob: 'GB/GM',
          linkedTRMS: undefined,
          sarYN: false,
          partyInSAR: undefined
        }
      ],
      fraudCases: [
        {
          caseId: 'FRD-2025-0334',
          caseStatus: 'Closed',
          narrative: 'Reported potential phishing attempt targeting client. Investigation determined external bad actor; client credentials not compromised. Client notified and security measures reinforced.',
          date: '2025-08-15',
          lob: 'GB/GM',
          sarYN: false,
          partyInSAR: undefined
        }
      ],
      sanctionDetails: [
        {
          caseId: 'SANC-2025-0892',
          product: 'Wire Transfer',
          alertDate: '2025-09-12',
          alertDescription: 'Name match to OFAC SDN list on wire beneficiary',
          narrative: 'Initial screening flagged beneficiary name "Mohamed Al-Rashid Trading LLC" as potential match to OFAC SDN. Enhanced review confirmed different entity with no connection to sanctioned party. Name spelling and date of birth do not match. Transaction cleared after verification.',
          blockReject: true,
          blockRejectReason: 'Temporary hold for enhanced review - False positive confirmed',
          lob: 'GB/GM',
          outcome: 'False Positive - Cleared'
        },
        {
          caseId: 'SANC-2025-1045',
          product: 'Wire Transfer',
          alertDate: '2025-10-08',
          alertDescription: 'Country screen alert - transaction to sanctioned jurisdiction',
          narrative: 'Wire transfer attempted to intermediary bank located in sanctioned jurisdiction. Transaction automatically rejected by sanctions screening system. Client advised of restrictions and alternative routing options provided.',
          blockReject: true,
          blockRejectReason: 'Sanctioned jurisdiction - OFAC restricted country',
          lob: 'GB/GM',
          outcome: 'Blocked - Compliance Hold'
        },
        {
          caseId: 'SANC-2025-1089',
          product: 'ACH',
          alertDate: '2025-10-18',
          alertDescription: 'Periodic re-screen - name fuzzy match',
          narrative: 'Routine quarterly re-screening of existing client relationships flagged potential fuzzy name match. Research confirmed no connection to sanctioned entities. Client information verified against original KYC documentation. No action required.',
          blockReject: false,
          blockRejectReason: undefined,
          lob: 'GB/GM',
          outcome: 'Cleared'
        }
      ],
      alert312Details: [
        {
          lob312: 'GB/GM',
          alertDate: '2025-10-15',
          alertDescription: 'Family anniversary date approaching - annual 312 review required'
        },
        {
          lob312: 'GB/GM',
          alertDate: '2025-10-20',
          alertDescription: 'High-risk client - enhanced due diligence review triggered by risk rating'
        }
      ],
      lobMonitoringControls: [
        {
          lob: 'All',
          activityName: 'Currency Reporting Unit (CTR and monetary instruments inspections)',
          activityDescription: 'Where CTR or MIS trails are triggered, the volume and dollar value are reported to FINCEN. If the activity is deemed suspicious a TRMS is filed',
          outcome: '# of Incidents: 7 Total Value of Transaction 10M'
        },
        {
          lob: 'GBGM',
          activityName: 'GTMS Transaction Monitoring',
          activityDescription: 'Control process to automatically monitor for payments or transactions above credit limits/ balances and control via approvals or rejections to these payment / transaction',
          outcome: 'Number of Alerts: 12 Number of TRMS: 1'
        },
        {
          lob: 'PB',
          activityName: 'Admin Reviews (PB)',
          activityDescription: 'Attestation of account coding/set up to ensure alignment with client instructions',
          outcome: 'Last Date of Review: 12/3/25 Number of TRMS: 1'
        },
        {
          lob: 'PB',
          activityName: 'Req 9 (PB)',
          activityDescription: 'A review of holdings in the client\'s account to verify that what we are holding is aligned to what is outlined in the fiduciary agreement in order to confirm that the strategy in place prior the agreement is being followed correctly',
          outcome: 'Last Date of Review: 12/3/25'
        },
        {
          lob: 'PB',
          activityName: 'Execute Money Movement (PB)',
          activityDescription: 'Preventative controls for money movement to ensure that certain wire or money movement activity is approved internally prior to allowing the activity to occur',
          outcome: '# Transaction requiring approval: 22'
        },
        {
          lob: 'MLCI',
          activityName: 'Execute Trade Oversight - Jess Manning, Special Risks TRMS',
          activityDescription: 'The RMS process alerts on various activity to request additional review of the account and can result in various dispositions including restriction, client contact, or filing of a TRMS',
          outcome: '# Of alerts: 12 # restricted: 2 client contact: 6'
        },
        {
          lob: 'MLCI',
          activityName: 'Execute Trade Oversight - OTR',
          activityDescription: 'Certain trade activity is flagged for review and sent to the supervision queue for review and dispositioning. Activity is flagged for review of internal activity both from a conduct perspective as well as for strategic alignment as oversight, rather than for investigation of suspicious client activity',
          outcome: '# Of alerts: 0 # restricted: 0 # client contact: 0'
        },
        {
          lob: 'MLCI',
          activityName: 'Market Conduct',
          activityDescription: 'Actimize pulls accounts/profiles that meet certain trading criteria and thresholds and creates an alert for review. The review is to determine if there is any internal market misconduct or policy violation and is a review of internal activity rather than client activity',
          outcome: '# Of alerts: 0 # restricted: 2 client contact: 0'
        },
        {
          lob: 'MLCI',
          activityName: 'Reasonable Inquiry',
          activityDescription: 'A LPS Reasonable Inquiry Review request is raised in NSGW if an associates attempts to wetter certain LPS requests for clients such as trading, transfer, journal net receives a block message. A review is completed to ensure there are no issues with the request prior to approving. is any suspicious activity is identified, a TRMS is entered, and the activity is blocked.',
          outcome: '# of blocks # of TRMS filed'
        }
      ]
    },
    caseProcessorComments: [
      {
        caseType: '312',
        processorName: 'Sarah Mitchell',
        comment: 'David - I\'ve reviewed the client\'s 312 profile and noted some elevated activity patterns. The client shows increased wire transfer volume to their Cayman Islands subsidiary compared to prior periods. While the business rationale appears sound based on their tech consulting expansion, I\'d appreciate your insights on whether this increase aligns with their current business strategy and if there are any upcoming contracts or projects that would explain the heightened activity. Additionally, can you confirm the purpose of the recent $2.5M transfer flagged by FLU?',
        date: '2025-10-26'
      },
      {
        caseType: 'CAM',
        processorName: 'Sarah Mitchell',
        comment: 'The monitoring dashboard shows several items requiring follow-up. Notably, there are 2 FLU/FLD TRMS records related to transaction patterns and one sanctions alert that was blocked. While most items appear to have reasonable explanations, your perspective on the business context would help complete our review. Please review the summary statistics and let me know if anything seems inconsistent with your understanding of their current operations.',
        date: '2025-10-26'
      }
    ]
  },
  {
    id: '312-2025-002',
    clientId: 'GCI-445122',
    clientName: 'Apex Global Trading Corp',
    caseType: '312 Review',
    status: 'Under Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Michael Chen',
    createdDate: '2025-10-18',
    dueDate: '2025-11-01',
    lastActivity: '2025-10-25',
    alertCount: 5,
    transactionCount: 187,
    totalAmount: 8900000,
    description: '312 review triggered by family anniversary date. Elevated risk with cross-border transactions.',
    gci: 'GCI-445122',
    is312Case: true,
    lineOfBusiness: 'GB/GM',
    refreshDueDates: ['2025-10-01', '2026-04-01'], // First one is 26 days overdue
    case312Data: {
      dueDate: '2025-11-01',
      aging: 9,
      status: 'Under Review',
      modelResult: 'High Risk',
      modelResultDescription: 'Cross-border trading activity with elevated risk indicators',
      expectedActivityVolume: {},
      expectedActivityValue: {}
    },
    clientData: {
      clientId: 'GCI-445122',
      gciNumber: 'GCI-445122',
      legalName: 'Apex Global Trading Corporation',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2018-11-03',
      clientType: 'Corporate',
      jurisdiction: 'Hong Kong',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.8,
      riskRatingDate: '2025-10-18',
      model312Score: 7.5,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    }
  },
  {
    id: '312-2025-003',
    clientId: 'GCI-778934',
    clientName: 'Consolidated Industries Group',
    caseType: '312 Review',
    status: 'In Progress',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Michael Chen',
    createdDate: '2025-10-24',
    dueDate: '2025-10-10', // Overdue by 17 days
    lastActivity: '2025-10-24',
    alertCount: 3,
    transactionCount: 98,
    totalAmount: 4200000,
    description: '312 periodic review - standard risk client with family anniversary approaching.',
    gci: 'GCI-778934',
    coperId: 'CPR-77893',
    is312Case: true,
    lineOfBusiness: 'GB/GM',
    refreshDueDates: ['2025-10-10', '2026-04-10'], // 17 days overdue
    case312Data: {
      dueDate: '2025-10-10',
      aging: 17,
      status: 'In Progress',
      modelResult: 'Medium Risk',
      modelResultDescription: 'Standard periodic review',
      expectedActivityVolume: {},
      expectedActivityValue: {}
    },
    clientData: {
      clientId: 'GCI-778934',
      gciNumber: 'GCI-778934',
      legalName: 'Consolidated Industries Group Limited',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2019-03-20',
      clientType: 'Corporate',
      jurisdiction: 'Singapore',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-24',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 5.2,
      riskRatingDate: '2025-10-22',
      model312Score: 5.0,
      model312Flag: true,
      lastMonitoringDate: '2025-10-24'
    }
  },

  // 312 Cases - PB LOB
  {
    id: '312-2025-004',
    clientId: 'GCI-556789',
    clientName: 'Quantum Family Trust',
    caseType: '312 Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Carlos Rivera',
    createdDate: '2025-10-12',
    dueDate: '2025-10-26',
    lastActivity: '2025-10-26',
    alertCount: 12,
    transactionCount: 342,
    totalAmount: 28500000,
    description: '312 review for high-risk PB client with PVT. Complex trust structure with international beneficiaries.',
    clientData: {
      clientId: 'GCI-556789',
      gciNumber: 'GCI-556789',
      legalName: 'Quantum Family Trust',
      salesOwner: 'Robert Anderson (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2016-08-15',
      clientType: 'Trust',
      jurisdiction: 'Switzerland',
      dataSource: 'CMT',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 9.1,
      riskRatingDate: '2025-10-10',
      model312Score: 8.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    }
  },
  {
    id: '312-2025-005',
    clientId: 'GCI-223456',
    clientName: 'Riverside Capital Partners',
    caseType: '312 Review',
    status: 'Escalated',
    riskLevel: 'Critical',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-08',
    dueDate: '2025-10-22',
    lastActivity: '2025-10-26',
    alertCount: 15,
    transactionCount: 567,
    totalAmount: 45000000,
    description: '312 review escalated - PEP involvement identified. Requires management approval.',
    clientData: {
      clientId: 'GCI-223456',
      gciNumber: 'GCI-223456',
      legalName: 'Riverside Capital Partners LP',
      salesOwner: 'Patricia Lee (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2015-06-22',
      clientType: 'Partnership',
      jurisdiction: 'Luxembourg',
      dataSource: 'CMT',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 9.5,
      riskRatingDate: '2025-10-08',
      model312Score: 9.3,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    trmsCase: {
      caseId: 'TRMS-2025-8891',
      caseType: 'PEP Enhanced Review',
      openDate: '2025-10-08',
      status: 'Open',
      priority: 'Urgent',
      dueDate: '2025-10-22'
    }
  },
  {
    id: '312-2025-006',
    clientId: 'GCI-112255',
    gci: 'GCI-112255',
    mpId: 'MP-11225',
    partyId: 'PTY-55443',
    clientName: 'Johnson Employee Account',
    caseType: '312 Review',
    status: 'Under Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Carlos Rivera',
    createdDate: '2025-10-20',
    dueDate: '2025-11-03',
    lastActivity: '2025-10-25',
    alertCount: 6,
    transactionCount: 124,
    totalAmount: 5600000,
    description: '312 review for employee account - heightened monitoring required per policy.',
    isBACEmployee: true,
    isBACAffiliate: false,
    isRegO: true,
    is312Case: true,
    lineOfBusiness: 'PB',
    entityName: 'Johnson, Robert M.',
    firstName: 'Robert',
    middleName: 'Michael',
    lastName: 'Johnson',
    refreshDueDates: ['2025-12-01'],
    lastRefreshCompletionDate: '2024-12-01',
    clientOwners: ['Carlos Rivera'],
    amlAttributes: ['CBA-Employee Account', 'AML-Reg O', 'CBA-Enhanced Monitoring'],
    clientData: {
      clientId: 'GCI-112255',
      gciNumber: 'GCI-112255',
      legalName: 'Johnson, Robert M. (Employee)',
      salesOwner: 'Carlos Rivera (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2020-01-10',
      clientType: 'Individual',
      jurisdiction: 'United States',
      dataSource: 'CMT',
      lastUpdated: '2025-10-25',
      isEmployee: true
    },
    monitoringData: {
      dynamicRiskRating: 7.2,
      riskRatingDate: '2025-10-18',
      model312Score: 6.8,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    }
  },

  // 312 Cases - ML LOB
  {
    id: '312-2025-007',
    clientId: 'GCI-889012',
    gci: 'GCI-889012',
    mpId: 'MP-88901',
    partyId: 'PTY-78901',
    clientName: 'Sterling Investment Portfolio',
    entityName: 'Sterling Investment Portfolio Trust',
    caseType: '312 Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Jennifer Wu',
    createdDate: '2025-10-16',
    dueDate: '2025-10-30',
    lastActivity: '2025-10-26',
    alertCount: 7,
    transactionCount: 203,
    totalAmount: 12400000,
    description: '312 review for ML high-risk client with PVT. Concentration in alternative investments.',
    is312Case: true,
    lineOfBusiness: 'ML',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    naicsCode: '523920',
    naicsDescription: 'Portfolio Management and Investment Advice',
    refreshDueDates: ['2025-12-01'],
    lastRefreshCompletionDate: '2024-12-05',
    clientOwners: ['Amanda Torres'],
    amlAttributes: ['CBA-High Risk', 'AML-PVT Client', 'CBA-Alternative Investments'],
    case312Data: {
      dueDate: '2025-10-30',
      aging: 15,
      status: 'In Progress',
      disposition: 'Pending',
      modelResult: 'High Risk',
      modelResultDescription: 'ML client with high concentration in alternative investments, large wire transfers, and international exposure. Portfolio value exceeds $10M with PVT designation.',
      expectedActivityVolume: {
        electronicTransfers: 45,
        cashChecks: 5,
      },
      expectedActivityValue: {
        electronicTransfers: 8500000,
        cashChecks: 150000,
      },
      expectedCrossBorderActivity: 'Expected countries: Cayman Islands, Switzerland, Luxembourg - related to alternative investment fund transfers and portfolio rebalancing.',
      purposeOfAccount: 'Investment portfolio management with focus on alternative investments including hedge funds, private equity, and international securities.',
      purposeOfAccountDetails: [
        {
          accountNumber: '8890123456',
          accountName: 'Sterling Investment - Main Portfolio',
          sourceOfFunds: 'Investment returns, dividends, and capital gains',
        },
        {
          accountNumber: '8890123457',
          accountName: 'Sterling Investment - Alternative Investments',
          sourceOfFunds: 'Private equity distributions and hedge fund redemptions',
        },
        {
          accountNumber: '8890123458',
          accountName: 'Sterling Investment - Operating Account',
          sourceOfFunds: 'Management fees and portfolio rebalancing proceeds',
        },
      ],
      sourceOfFunds: 'Investment returns from diversified portfolio including public equities, fixed income, hedge funds, private equity, and real estate investments. Initial funding from client business sale proceeds.',
    },
    clientData: {
      clientId: 'GCI-889012',
      gciNumber: 'GCI-889012',
      legalName: 'Sterling Investment Portfolio Trust',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2017-09-14',
      clientType: 'Trust',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.3,
      riskRatingDate: '2025-10-14',
      model312Score: 8.0,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    }
  },
  {
    id: '312-2025-008',
    clientId: 'GCI-334567',
    clientName: 'Atlas Global Enterprises',
    caseType: '312 Review',
    status: 'New',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Jennifer Wu',
    createdDate: '2025-10-25',
    dueDate: '2025-11-08',
    lastActivity: '2025-10-25',
    alertCount: 4,
    transactionCount: 87,
    totalAmount: 3800000,
    description: '312 standard risk review - model alert triggered for increased trading activity.',
    clientData: {
      clientId: 'GCI-334567',
      gciNumber: 'GCI-334567',
      legalName: 'Atlas Global Enterprises LLC',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2019-07-28',
      clientType: 'LLC',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 5.5,
      riskRatingDate: '2025-10-23',
      model312Score: 5.8,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    }
  },

  // CAM Cases - GB/GM LOB
  {
    id: 'CAM-2025-001',
    clientId: 'GCI-892341',
    clientName: 'GlobalTech Industries Corp',
    caseType: 'CAM Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-15',
    dueDate: '2025-10-29',
    lastActivity: '2025-10-26',
    alertCount: 8,
    transactionCount: 245,
    totalAmount: 15700000,
    description: 'CAM review - high-risk client with multiple ML alerts and prior SAR filing history.',
    clientData: {
      clientId: 'GCI-892341',
      gciNumber: 'GCI-892341',
      legalName: 'GlobalTech Industries Corporation',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2017-05-12',
      clientType: 'Corporate',
      jurisdiction: 'Cayman Islands',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.7,
      riskRatingDate: '2025-10-20',
      model312Score: 8.5,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 2,
      paymentAlerts: 3,
      moneyLaunderingAlerts: 3,
      totalAlerts: 8
    },
    sarData: {
      sarFiled: true,
      sarId: 'SAR-2024-1123',
      sarFilingDate: '2024-08-15',
      sarType: 'Structuring',
      sarAmount: 2400000
    }
  },
  {
    id: 'CAM-2025-002',
    clientId: 'GCI-556677',
    clientName: 'Pacific Rim Ventures',
    caseType: 'CAM Review',
    status: 'Pending Sales Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Michael Chen',
    createdDate: '2025-10-19',
    dueDate: '2025-09-30', // Overdue by 27 days
    lastActivity: '2025-10-26',
    alertCount: 10,
    transactionCount: 412,
    totalAmount: 23600000,
    description: 'CAM review - unusual transaction patterns detected. Multiple third-party payments.',
    gci: 'GCI-556677',
    coperId: 'CPR-55667',
    is312Case: false,
    lineOfBusiness: 'GB/GM',
    refreshDueDates: ['2025-09-30', '2026-03-30'], // 27 days overdue
    camCaseData: {
      dueDate: '2025-09-30',
      aging: 27,
      status: 'Pending Sales Review',
      triggers: ['Unusual transaction patterns', 'Third-party payments', 'High volume']
    },
    clientData: {
      clientId: 'GCI-556677',
      gciNumber: 'GCI-556677',
      legalName: 'Pacific Rim Ventures Limited',
      salesOwner: 'Mark Thompson',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2018-02-10',
      clientType: 'Corporate',
      jurisdiction: 'British Virgin Islands',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.9,
      riskRatingDate: '2025-10-18',
      model312Score: 7.2,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 1,
      paymentAlerts: 6,
      moneyLaunderingAlerts: 3,
      totalAlerts: 10
    }
  },
  {
    id: 'CAM-2025-003',
    clientId: 'GCI-778456',
    clientName: 'Meridian Export Group',
    caseType: 'CAM Review',
    status: 'Closed',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Michael Chen',
    createdDate: '2025-09-28',
    dueDate: '2025-10-12',
    lastActivity: '2025-10-15',
    alertCount: 5,
    transactionCount: 178,
    totalAmount: 8700000,
    description: 'CAM review completed - activity determined to be consistent with business model. No further action required.',
    clientData: {
      clientId: 'GCI-778456',
      gciNumber: 'GCI-778456',
      legalName: 'Meridian Export Group Inc',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2019-11-05',
      clientType: 'Corporate',
      jurisdiction: 'United States',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-15',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.5,
      riskRatingDate: '2025-09-25',
      model312Score: 6.8,
      model312Flag: false,
      lastMonitoringDate: '2025-10-15'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 0,
      paymentAlerts: 3,
      moneyLaunderingAlerts: 2,
      totalAlerts: 5
    }
  },

  // CAM Cases - PB LOB
  {
    id: 'CAM-2025-004',
    clientId: 'GCI-556789',
    clientName: 'Quantum Family Trust',
    caseType: 'CAM Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-12',
    dueDate: '2025-10-26',
    lastActivity: '2025-10-26',
    alertCount: 12,
    transactionCount: 342,
    totalAmount: 28500000,
    description: 'CAM review for PB high-risk client - recurring SAR filer requiring enhanced scrutiny.',
    clientData: {
      clientId: 'GCI-556789',
      gciNumber: 'GCI-556789',
      legalName: 'Quantum Family Trust',
      salesOwner: 'Robert Anderson (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2016-08-15',
      clientType: 'Trust',
      jurisdiction: 'Switzerland',
      dataSource: 'CMT',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 9.1,
      riskRatingDate: '2025-10-10',
      model312Score: 8.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 1,
      fraudAlerts: 3,
      paymentAlerts: 5,
      moneyLaunderingAlerts: 3,
      totalAlerts: 12
    },
    sarData: {
      sarFiled: true,
      sarId: 'SAR-2024-0892',
      sarFilingDate: '2024-11-20',
      sarType: 'Complex Transactions',
      sarAmount: 8900000
    }
  },
  {
    id: 'CAM-2025-005',
    clientId: 'GCI-223456',
    clientName: 'Riverside Capital Partners',
    caseType: 'CAM Review',
    status: 'Escalated',
    riskLevel: 'Critical',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-08',
    dueDate: '2025-10-22',
    lastActivity: '2025-10-26',
    alertCount: 15,
    transactionCount: 567,
    totalAmount: 45000000,
    description: 'CAM review escalated - PEP with multiple jurisdictions and complex ownership.',
    clientData: {
      clientId: 'GCI-223456',
      gciNumber: 'GCI-223456',
      legalName: 'Riverside Capital Partners LP',
      salesOwner: 'Patricia Lee (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2015-06-22',
      clientType: 'Partnership',
      jurisdiction: 'Luxembourg',
      dataSource: 'CMT',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 9.5,
      riskRatingDate: '2025-10-08',
      model312Score: 9.3,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 2,
      fraudAlerts: 3,
      paymentAlerts: 6,
      moneyLaunderingAlerts: 4,
      totalAlerts: 15
    }
  },
  {
    id: 'CAM-2025-006',
    clientId: 'GCI-112255',
    clientName: 'Johnson Employee Account',
    caseType: 'CAM Review',
    status: 'Under Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-20',
    dueDate: '2025-11-03',
    lastActivity: '2025-10-25',
    alertCount: 6,
    transactionCount: 124,
    totalAmount: 5600000,
    description: 'CAM review for employee account - unusual activity flagged by monitoring systems.',
    clientData: {
      clientId: 'GCI-112255',
      gciNumber: 'GCI-112255',
      legalName: 'Johnson, Robert M. (Employee)',
      salesOwner: 'Carlos Rivera (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2020-01-10',
      clientType: 'Individual',
      jurisdiction: 'United States',
      dataSource: 'CMT',
      lastUpdated: '2025-10-25',
      isEmployee: true
    },
    monitoringData: {
      dynamicRiskRating: 7.2,
      riskRatingDate: '2025-10-18',
      model312Score: 6.8,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 1,
      paymentAlerts: 3,
      moneyLaunderingAlerts: 2,
      totalAlerts: 6
    }
  },

  // CAM Cases - ML LOB
  {
    id: 'CAM-2025-007',
    clientId: 'GCI-889012',
    clientName: 'Sterling Investment Portfolio',
    caseType: 'CAM Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Jennifer Wu',
    createdDate: '2025-10-16',
    dueDate: '2025-10-30',
    lastActivity: '2025-10-26',
    alertCount: 7,
    transactionCount: 203,
    totalAmount: 12400000,
    description: 'CAM review - high concentration in cryptocurrency-related investments.',
    clientData: {
      clientId: 'GCI-889012',
      gciNumber: 'GCI-889012',
      legalName: 'Sterling Investment Portfolio Trust',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2017-09-14',
      clientType: 'Trust',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.3,
      riskRatingDate: '2025-10-14',
      model312Score: 8.0,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 2,
      paymentAlerts: 3,
      moneyLaunderingAlerts: 2,
      totalAlerts: 7
    }
  },
  {
    id: 'CAM-2025-008',
    clientId: 'GCI-992233',
    clientName: 'Metropolitan Holdings LLC',
    caseType: 'CAM Review',
    status: 'New',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Jennifer Wu',
    createdDate: '2025-10-23',
    dueDate: '2025-11-06',
    lastActivity: '2025-10-23',
    alertCount: 9,
    transactionCount: 298,
    totalAmount: 16800000,
    description: 'CAM review - rapid movement of funds between multiple accounts.',
    clientData: {
      clientId: 'GCI-992233',
      gciNumber: 'GCI-992233',
      legalName: 'Metropolitan Holdings LLC',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2018-12-08',
      clientType: 'LLC',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-23',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.6,
      riskRatingDate: '2025-10-22',
      model312Score: 7.8,
      model312Flag: false,
      lastMonitoringDate: '2025-10-23'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 2,
      paymentAlerts: 5,
      moneyLaunderingAlerts: 2,
      totalAlerts: 9
    }
  },

  // CAM Cases - Consumer LOB
  {
    id: 'CAM-2025-009',
    clientId: 'GCI-112233',
    clientName: 'Martinez Family Account',
    caseType: 'CAM Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Lisa Brown',
    createdDate: '2025-10-17',
    dueDate: '2025-10-31',
    lastActivity: '2025-10-26',
    alertCount: 8,
    transactionCount: 167,
    totalAmount: 6700000,
    description: 'CAM review - high-value consumer account with cross-border wire activity.',
    clientData: {
      clientId: 'GCI-112233',
      gciNumber: 'GCI-112233',
      legalName: 'Martinez, Carlos R.',
      salesOwner: 'Consumer Banking Team',
      lineOfBusiness: 'Consumer',
      accountOpenDate: '2020-03-15',
      clientType: 'Individual',
      jurisdiction: 'United States',
      dataSource: 'WCC',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.9,
      riskRatingDate: '2025-10-15',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 2,
      paymentAlerts: 4,
      moneyLaunderingAlerts: 2,
      totalAlerts: 8
    }
  },
  {
    id: 'CAM-2025-010',
    clientId: 'GCI-445566',
    clientName: 'Thompson Family Trust',
    caseType: 'CAM Review',
    status: 'Under Review',
    riskLevel: 'High',
    priority: 'Medium',
    assignedTo: 'Jennifer Wu',
    createdDate: '2025-10-21',
    dueDate: '2025-11-04',
    lastActivity: '2025-10-25',
    alertCount: 6,
    transactionCount: 134,
    totalAmount: 4900000,
    description: 'CAM review - sudden increase in account activity after dormancy period.',
    clientData: {
      clientId: 'GCI-445566',
      gciNumber: 'GCI-445566',
      legalName: 'Thompson Family Trust',
      salesOwner: 'Consumer Banking Team',
      lineOfBusiness: 'Consumer',
      accountOpenDate: '2015-07-22',
      clientType: 'Trust',
      jurisdiction: 'United States',
      dataSource: 'WCC',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.3,
      riskRatingDate: '2025-10-19',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-25'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 1,
      paymentAlerts: 3,
      moneyLaunderingAlerts: 2,
      totalAlerts: 6
    }
  },

  // CAM Cases - CI LOB
  {
    id: 'CAM-2025-011',
    clientId: 'GCI-778899',
    clientName: 'Greenfield Investment Account',
    caseType: 'CAM Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Lisa Brown',
    createdDate: '2025-10-18',
    dueDate: '2025-11-01',
    lastActivity: '2025-10-26',
    alertCount: 7,
    transactionCount: 189,
    totalAmount: 8200000,
    description: 'CAM review - frequent trading in penny stocks with potential manipulation indicators.',
    clientData: {
      clientId: 'GCI-778899',
      gciNumber: 'GCI-778899',
      legalName: 'Greenfield, Sarah M.',
      salesOwner: 'CI Banking Team',
      lineOfBusiness: 'CI',
      accountOpenDate: '2019-05-10',
      clientType: 'Individual',
      jurisdiction: 'United States',
      dataSource: 'WCC',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.1,
      riskRatingDate: '2025-10-16',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 3,
      paymentAlerts: 2,
      moneyLaunderingAlerts: 2,
      totalAlerts: 7
    }
  },
  {
    id: 'CAM-2025-012',
    clientId: 'GCI-334455',
    clientName: 'Pacific Coast Retirement',
    caseType: 'CAM Review',
    status: 'New',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Jennifer Wu',
    createdDate: '2025-10-24',
    dueDate: '2025-11-07',
    lastActivity: '2025-10-24',
    alertCount: 4,
    transactionCount: 92,
    totalAmount: 3200000,
    description: 'CAM review - unusual options trading pattern detected.',
    clientData: {
      clientId: 'GCI-334455',
      gciNumber: 'GCI-334455',
      legalName: 'Pacific Coast Retirement Fund',
      salesOwner: 'CI Banking Team',
      lineOfBusiness: 'CI',
      accountOpenDate: '2017-11-30',
      clientType: 'Retirement Account',
      jurisdiction: 'United States',
      dataSource: 'WCC',
      lastUpdated: '2025-10-24',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 6.2,
      riskRatingDate: '2025-10-22',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-24'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 1,
      paymentAlerts: 2,
      moneyLaunderingAlerts: 1,
      totalAlerts: 4
    }
  },

  // Additional Employee Cases
  {
    id: 'CAM-2025-013',
    clientId: 'GCI-556688',
    clientName: 'Williams Employee Account',
    caseType: 'CAM Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Kevin Rogers',
    createdDate: '2025-10-19',
    dueDate: '2025-11-02',
    lastActivity: '2025-10-26',
    alertCount: 5,
    transactionCount: 78,
    totalAmount: 2800000,
    description: 'CAM review for employee account - concentration in company stock requires review.',
    clientData: {
      clientId: 'GCI-556688',
      gciNumber: 'GCI-556688',
      legalName: 'Williams, Jennifer L. (Employee)',
      salesOwner: 'Employee Services',
      lineOfBusiness: 'ML',
      accountOpenDate: '2021-02-18',
      clientType: 'Individual',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-26',
      isEmployee: true
    },
    monitoringData: {
      dynamicRiskRating: 6.8,
      riskRatingDate: '2025-10-17',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-26'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 1,
      paymentAlerts: 2,
      moneyLaunderingAlerts: 2,
      totalAlerts: 5
    }
  },
  {
    id: '312-2025-009',
    clientId: 'GCI-889900',
    clientName: 'Davis Affiliate Account',
    caseType: '312 Review',
    status: 'Under Review',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Kevin Rogers',
    createdDate: '2025-10-22',
    dueDate: '2025-11-05',
    lastActivity: '2025-10-25',
    alertCount: 3,
    transactionCount: 56,
    totalAmount: 1900000,
    description: '312 review for affiliate account - periodic review per policy.',
    clientData: {
      clientId: 'GCI-889900',
      gciNumber: 'GCI-889900',
      legalName: 'Davis, Michael R. (Affiliate)',
      salesOwner: 'Employee Services',
      lineOfBusiness: 'Consumer',
      accountOpenDate: '2020-08-12',
      clientType: 'Individual',
      jurisdiction: 'United States',
      dataSource: 'WCC',
      lastUpdated: '2025-10-25',
      isEmployee: true
    },
    monitoringData: {
      dynamicRiskRating: 5.5,
      riskRatingDate: '2025-10-20',
      model312Score: 5.2,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    }
  },

  // Cases for Sales Owners (assigned to them specifically)
  {
    id: '312-2025-010',
    clientId: 'GCI-998877',
    clientName: 'Pinnacle Financial Group',
    caseType: '312 Review',
    status: 'New',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'David Park',
    createdDate: '2025-10-25',
    dueDate: '2025-11-08',
    lastActivity: '2025-10-25',
    alertCount: 6,
    transactionCount: 156,
    totalAmount: 9400000,
    description: '312 review assigned to Sales Owner for feedback - complex trust structure.',
    clientData: {
      clientId: 'GCI-998877',
      gciNumber: 'GCI-998877',
      legalName: 'Pinnacle Financial Group Ltd',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2018-04-20',
      clientType: 'Corporate',
      jurisdiction: 'Jersey',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.2,
      riskRatingDate: '2025-10-23',
      model312Score: 7.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    }
  },
  {
    id: '312-2025-011',
    clientId: 'GCI-667788',
    clientName: 'Horizon Wealth Management',
    caseType: '312 Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Amanda Torres',
    createdDate: '2025-10-20',
    dueDate: '2025-11-03',
    lastActivity: '2025-10-26',
    alertCount: 7,
    transactionCount: 213,
    totalAmount: 14600000,
    description: '312 review - Sales Owner providing business context and client background.',
    clientData: {
      clientId: 'GCI-667788',
      gciNumber: 'GCI-667788',
      legalName: 'Horizon Wealth Management LLC',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2016-10-05',
      clientType: 'LLC',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.4,
      riskRatingDate: '2025-10-18',
      model312Score: 8.1,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    }
  },

  // More cases for comprehensive testing
  {
    id: 'CAM-2025-014',
    clientId: 'GCI-223399',
    clientName: 'Coastal Trading Partners',
    caseType: 'CAM Review',
    status: 'Closed',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Michael Chen',
    createdDate: '2025-09-15',
    dueDate: '2025-09-29',
    lastActivity: '2025-10-05',
    alertCount: 4,
    transactionCount: 92,
    totalAmount: 3800000,
    description: 'CAM review completed - no suspicious activity identified.',
    clientData: {
      clientId: 'GCI-223399',
      gciNumber: 'GCI-223399',
      legalName: 'Coastal Trading Partners Inc',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2020-01-15',
      clientType: 'Corporate',
      jurisdiction: 'United States',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-05',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 6.1,
      riskRatingDate: '2025-09-12',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-05'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 1,
      paymentAlerts: 2,
      moneyLaunderingAlerts: 1,
      totalAlerts: 4
    }
  },
  {
    id: '312-2025-012',
    clientId: 'GCI-445577',
    clientName: 'Nordic Investment Trust',
    caseType: '312 Review',
    status: 'Closed',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Carlos Rivera',
    createdDate: '2025-09-20',
    dueDate: '2025-10-04',
    lastActivity: '2025-10-10',
    alertCount: 2,
    transactionCount: 45,
    totalAmount: 2100000,
    description: '312 review completed successfully - client profile updated.',
    clientData: {
      clientId: 'GCI-445577',
      gciNumber: 'GCI-445577',
      legalName: 'Nordic Investment Trust',
      salesOwner: 'Patricia Lee (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2019-06-18',
      clientType: 'Trust',
      jurisdiction: 'Norway',
      dataSource: 'CMT',
      lastUpdated: '2025-10-10',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 4.8,
      riskRatingDate: '2025-09-18',
      model312Score: 4.5,
      model312Flag: true,
      lastMonitoringDate: '2025-10-10'
    }
  },

  // Sales Review Cases - Cases in sales review workflow
  {
    id: 'CAM-2025-SALES-001',
    clientId: 'GCI-SR-001',
    gci: 'GCI-SR-001',
    coperId: 'CPR-SR-001',
    clientName: 'Sterling Capital Partners',
    caseType: 'CAM Review',
    status: 'Pending Sales Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'David Park',
    centralTeamContact: 'Michael Chen',
    createdDate: '2025-10-20',
    dueDate: '2025-11-03',
    lastActivity: '2025-10-24',
    alertCount: 5,
    transactionCount: 178,
    totalAmount: 8500000,
    description: 'CAM review routed to sales for business context - complex hedge fund structure.',
    lineOfBusiness: 'GB/GM',
    is312Case: false,
    clientData: {
      clientId: 'GCI-SR-001',
      gciNumber: 'GCI-SR-001',
      legalName: 'Sterling Capital Partners LP',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2017-08-15',
      clientType: 'Partnership',
      jurisdiction: 'Cayman Islands',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-24',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.8,
      riskRatingDate: '2025-10-18',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-24'
    }
  },
  {
    id: '312-2025-SALES-002',
    clientId: 'GCI-SR-002',
    gci: 'GCI-SR-002',
    coperId: 'CPR-SR-002',
    clientName: 'Meridian Wealth Advisors',
    caseType: '312 Review',
    status: 'In Sales Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Amanda Torres',
    centralTeamContact: 'Jennifer Wu',
    createdDate: '2025-10-18',
    dueDate: '2025-11-01',
    lastActivity: '2025-10-26',
    alertCount: 6,
    transactionCount: 234,
    totalAmount: 12300000,
    description: '312 review in sales review - Sales Owner reviewing relationship context.',
    lineOfBusiness: 'ML',
    is312Case: true,
    clientData: {
      clientId: 'GCI-SR-002',
      gciNumber: 'GCI-SR-002',
      legalName: 'Meridian Wealth Advisors LLC',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2018-03-22',
      clientType: 'LLC',
      jurisdiction: 'United States',
      dataSource: 'CP',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.1,
      riskRatingDate: '2025-10-16',
      model312Score: 7.8,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    }
  },
  {
    id: 'CAM-2025-SALES-003',
    clientId: 'GCI-SR-003',
    gci: 'GCI-SR-003',
    clientName: 'Quantum Investment Group',
    caseType: 'CAM Review',
    status: 'Pending Sales Review',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'David Park',
    centralTeamContact: 'Lisa Brown',
    createdDate: '2025-10-22',
    dueDate: '2025-11-05',
    lastActivity: '2025-10-25',
    alertCount: 3,
    transactionCount: 142,
    totalAmount: 5600000,
    description: 'CAM review awaiting sales feedback on recent business changes.',
    lineOfBusiness: 'GB/GM',
    is312Case: false,
    clientData: {
      clientId: 'GCI-SR-003',
      gciNumber: 'GCI-SR-003',
      legalName: 'Quantum Investment Group Inc',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2019-11-08',
      clientType: 'Corporate',
      jurisdiction: 'Delaware',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 6.2,
      riskRatingDate: '2025-10-20',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-25'
    }
  },
  {
    id: '312-2025-SALES-004',
    clientId: 'GCI-SR-004',
    gci: 'GCI-SR-004',
    coperId: 'CPR-SR-004',
    clientName: 'Apex Global Ventures',
    caseType: '312 Review',
    status: 'In Sales Review',
    riskLevel: 'Critical',
    priority: 'Urgent',
    assignedTo: 'David Park',
    centralTeamContact: 'Michael Chen',
    createdDate: '2025-10-15',
    dueDate: '2025-10-28',
    lastActivity: '2025-10-26',
    alertCount: 9,
    transactionCount: 312,
    totalAmount: 18900000,
    description: '312 review - critical priority. Sales reviewing complex offshore structure.',
    lineOfBusiness: 'GB/GM',
    is312Case: true,
    clientData: {
      clientId: 'GCI-SR-004',
      gciNumber: 'GCI-SR-004',
      legalName: 'Apex Global Ventures SA',
      salesOwner: 'David Park',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2016-02-14',
      clientType: 'Corporate',
      jurisdiction: 'Switzerland',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 9.1,
      riskRatingDate: '2025-10-12',
      model312Score: 8.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    }
  },
  {
    id: 'CAM-2025-SALES-005',
    clientId: 'GCI-SR-005',
    gci: 'GCI-SR-005',
    coperId: 'CPR-SR-005',
    clientName: 'Riverside Financial Holdings',
    caseType: 'CAM Review',
    status: 'Sales Review Complete',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Kevin Rogers',
    centralTeamContact: 'Kevin Rogers',
    createdDate: '2025-10-16',
    dueDate: '2025-10-30',
    lastActivity: '2025-10-25',
    alertCount: 4,
    transactionCount: 98,
    totalAmount: 4200000,
    description: 'CAM review - Sales review complete, returned to analyst for final disposition.',
    lineOfBusiness: 'PB',
    is312Case: false,
    salesReviewComments: 'Client relationship is solid. Recent trading activity is aligned with business expansion plans. No concerns from relationship perspective.',
    clientData: {
      clientId: 'GCI-SR-005',
      gciNumber: 'GCI-SR-005',
      legalName: 'Riverside Financial Holdings Ltd',
      salesOwner: 'Patricia Lee (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2018-09-20',
      clientType: 'Corporate',
      jurisdiction: 'United Kingdom',
      dataSource: 'CMT',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 5.8,
      riskRatingDate: '2025-10-14',
      model312Score: 0,
      model312Flag: false,
      lastMonitoringDate: '2025-10-25'
    }
  },
  {
    id: '312-2025-SALES-006',
    clientId: 'GCI-SR-006',
    gci: 'GCI-SR-006',
    clientName: 'Pacific Rim Trading Corp',
    caseType: '312 Review',
    status: 'Pending Sales Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Amanda Torres',
    centralTeamContact: 'Jennifer Wu',
    createdDate: '2025-10-24',
    dueDate: '2025-11-07',
    lastActivity: '2025-10-26',
    alertCount: 7,
    transactionCount: 189,
    totalAmount: 9800000,
    description: '312 review pending sales feedback - unusual cross-border transaction patterns.',
    lineOfBusiness: 'ML',
    is312Case: true,
    clientData: {
      clientId: 'GCI-SR-006',
      gciNumber: 'GCI-SR-006',
      legalName: 'Pacific Rim Trading Corporation',
      salesOwner: 'Amanda Torres (FA)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2017-07-12',
      clientType: 'Corporate',
      jurisdiction: 'Hong Kong',
      dataSource: 'CP',
      lastUpdated: '2025-10-26',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.9,
      riskRatingDate: '2025-10-22',
      model312Score: 7.6,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    }
  },
];

// Activity logs - Include case flow activities
export const mockActivities: Activity[] = [
  ...caseFlowActivities,
  {
    id: 'ACT-001',
    caseId: '312-2025-001',
    type: 'Comment',
    description: 'Reviewed offshore transactions - patterns consistent with trade finance',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T14:30:00'
  },
  {
    id: 'ACT-002',
    caseId: '312-2025-001',
    type: 'Status Change',
    description: 'Changed status from New to In Progress',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T09:15:00'
  },
  {
    id: 'ACT-003',
    caseId: 'CAM-2025-001',
    type: 'Comment',
    description: 'SAR filing history reviewed - previous structuring concerns noted',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T11:45:00'
  },
  {
    id: 'ACT-004',
    caseId: '312-2025-005',
    type: 'Escalation',
    description: 'Case escalated to management - PEP involvement requires approval',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T10:20:00'
  },
  {
    id: 'ACT-005',
    caseId: 'CAM-2025-005',
    type: 'Escalation',
    description: 'Escalated for manager review due to PEP complexity',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T10:22:00'
  },
  {
    id: 'ACT-006',
    caseId: '312-2025-002',
    type: 'Comment',
    description: 'Contacted Sales Owner for business context - awaiting response',
    user: 'Michael Chen',
    timestamp: '2025-10-25T15:30:00'
  },
  {
    id: 'ACT-007',
    caseId: 'CAM-2025-002',
    type: 'Status Change',
    description: 'Moved to Under Review after initial assessment',
    user: 'Michael Chen',
    timestamp: '2025-10-26T08:45:00'
  },
  {
    id: 'ACT-008',
    caseId: '312-2025-004',
    type: 'Comment',
    description: 'Complex trust structure reviewed - multiple beneficiaries identified',
    user: 'Carlos Rivera',
    timestamp: '2025-10-26T13:15:00'
  },
  {
    id: 'ACT-009',
    caseId: 'CAM-2025-007',
    type: 'Comment',
    description: 'Reviewed cryptocurrency exposure - within acceptable risk tolerance',
    user: 'Jennifer Wu',
    timestamp: '2025-10-26T16:20:00'
  },
  {
    id: 'ACT-010',
    caseId: 'CAM-2025-009',
    type: 'Comment',
    description: 'Cross-border wire activity analyzed - consistent with stated occupation',
    user: 'Lisa Brown',
    timestamp: '2025-10-26T12:30:00'
  },
  {
    id: 'ACT-011',
    caseId: '312-2025-010',
    type: 'Comment',
    description: 'Awaiting sales owner feedback on trust structure and beneficial owners',
    user: 'David Park',
    timestamp: '2025-10-25T14:00:00'
  },
  {
    id: 'ACT-012',
    caseId: '312-2025-011',
    type: 'Comment',
    description: 'Provided client background and investment strategy documentation',
    user: 'Amanda Torres',
    timestamp: '2025-10-26T11:00:00'
  },
];

// Alerts
export const mockAlerts: Alert[] = [
  {
    id: 'ALT-001',
    caseId: '312-2025-001',
    type: '312 Model Alert',
    severity: 'High',
    description: '312 risk model triggered - high score for offshore activity',
    date: '2025-10-15',
    status: 'Acknowledged'
  },
  {
    id: 'ALT-002',
    caseId: 'CAM-2025-001',
    type: 'Structuring',
    severity: 'Critical',
    description: 'Multiple deposits just below $10,000 reporting threshold',
    date: '2025-10-14',
    status: 'Open'
  },
  {
    id: 'ALT-003',
    caseId: 'CAM-2025-001',
    type: 'Large Transaction',
    severity: 'High',
    description: 'Wire transfer of $2.4M to offshore entity',
    date: '2025-10-13',
    status: 'Acknowledged'
  },
  {
    id: 'ALT-004',
    caseId: '312-2025-005',
    type: 'PEP Alert',
    severity: 'Critical',
    description: 'Politically exposed person identified in beneficial ownership',
    date: '2025-10-08',
    status: 'Open'
  },
  {
    id: 'ALT-005',
    caseId: 'CAM-2025-005',
    type: 'Sanctions Screening',
    severity: 'High',
    description: 'Name match requiring enhanced screening',
    date: '2025-10-08',
    status: 'Acknowledged'
  },
  {
    id: 'ALT-006',
    caseId: 'CAM-2025-002',
    type: 'Third Party Payment',
    severity: 'Medium',
    description: 'Payments from unrelated third parties detected',
    date: '2025-10-18',
    status: 'Open'
  },
  {
    id: 'ALT-007',
    caseId: 'CAM-2025-007',
    type: 'Concentration Risk',
    severity: 'Medium',
    description: 'High concentration in alternative investments',
    date: '2025-10-16',
    status: 'Acknowledged'
  },
  {
    id: 'ALT-008',
    caseId: 'CAM-2025-011',
    type: 'Market Manipulation',
    severity: 'High',
    description: 'Unusual trading pattern in low-volume securities',
    date: '2025-10-17',
    status: 'Open'
  },
];

// Population data
export const mockPopulations: Population[] = [
  {
    id: 'POP-312-001',
    name: '312 Population - GB/GM High Risk',
    criteria: 'GB/GM High Risk with DGA Due Date OR Elevated/Standard with Family Anniversary within 180 days',
    clientCount: 34,
    riskScore: 8.2,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-312-002',
    name: '312 Population - PB/ML High Risk with PVT',
    criteria: 'PB or ML High Risk with refresh within 180 days and PVT from CRA',
    clientCount: 28,
    riskScore: 8.5,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-312-003',
    name: '312 Population - Manual Identification',
    criteria: 'Clients manually identified for 312 review',
    clientCount: 12,
    riskScore: 7.9,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-CAM-001',
    name: 'CAM Population - High Risk Active Clients',
    criteria: 'All High Risk Active clients (312 flag not required for CAM)',
    clientCount: 156,
    riskScore: 7.8,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-CAM-002',
    name: 'CAM Population - SAR Filers (Last 12 Months)',
    criteria: 'Clients with SAR filing in past 12 months requiring ongoing monitoring',
    clientCount: 45,
    riskScore: 8.9,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-CAM-003',
    name: 'CAM Population - 312 Full Review Clients',
    criteria: 'Clients with 312 case NOT auto-closed (Full Review)',
    clientCount: 67,
    riskScore: 8.1,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-EMP-001',
    name: 'Employee/Affiliate Accounts',
    criteria: 'All employee and affiliate accounts requiring monitoring',
    clientCount: 23,
    riskScore: 6.5,
    lastRun: '2025-10-26',
    status: 'Active'
  },
];

// Reports
export const mockReports: Report[] = [
  {
    id: 'REP-001',
    name: 'October 2025 - 312 Case Summary',
    type: 'Case Statistics',
    generatedBy: 'Sarah Mitchell',
    generatedDate: '2025-10-26',
    status: 'Completed',
    format: 'PDF'
  },
  {
    id: 'REP-002',
    name: 'October 2025 - CAM Case Summary',
    type: 'Case Statistics',
    generatedBy: 'Sarah Mitchell',
    generatedDate: '2025-10-26',
    status: 'Completed',
    format: 'PDF'
  },
  {
    id: 'REP-003',
    name: 'Q3 2025 - Population Analysis',
    type: 'Population Statistics',
    generatedBy: 'Robert Anderson',
    generatedDate: '2025-10-01',
    status: 'Completed',
    format: 'Excel'
  },
  {
    id: 'REP-004',
    name: 'SAR Filing Activity - October 2025',
    type: 'Regulatory',
    generatedBy: 'Sarah Mitchell',
    generatedDate: '2025-10-26',
    status: 'Processing',
    format: 'PDF'
  },
  {
    id: 'REP-005',
    name: 'Case Creation Logic Audit - Q4 2025',
    type: 'Process Audit',
    generatedBy: 'Robert Anderson',
    generatedDate: '2025-10-25',
    status: 'Completed',
    format: 'Excel'
  },
  {
    id: 'REP-006',
    name: 'High-Risk Client Portfolio Review',
    type: 'Risk Analysis',
    generatedBy: 'Sarah Mitchell',
    generatedDate: '2025-10-24',
    status: 'Completed',
    format: 'PDF'
  },
  {
    id: 'REP-007',
    name: 'LOB Distribution Analysis - October 2025',
    type: 'Case Statistics',
    generatedBy: 'Michael Chen',
    generatedDate: '2025-10-23',
    status: 'Completed',
    format: 'Excel'
  },
  {
    id: 'REP-008',
    name: 'Employee Account Monitoring Summary',
    type: 'Special Population',
    generatedBy: 'Carlos Rivera',
    generatedDate: '2025-10-22',
    status: 'Completed',
    format: 'PDF'
  },
];

// Notifications
export const mockNotifications = [
  {
    id: 'NOT-001',
    userId: 'U001', // Sarah Mitchell
    type: 'case_assigned',
    title: 'New Case Assigned',
    message: 'Case CAM-2025-005 (Riverside Capital Partners) has been assigned to you',
    time: '2 hours ago',
    read: false,
    priority: 'high',
    caseId: 'CAM-2025-005'
  },
  {
    id: 'NOT-002',
    userId: 'U001',
    type: 'deadline',
    title: 'Case Due Tomorrow',
    message: '312-2025-004 (Quantum Family Trust) is due tomorrow',
    time: '5 hours ago',
    read: false,
    priority: 'urgent',
    caseId: '312-2025-004'
  },
  {
    id: 'NOT-003',
    userId: 'U001',
    type: 'case_escalated',
    title: 'Case Escalated',
    message: 'You escalated 312-2025-005 to management for review',
    time: '1 day ago',
    read: true,
    priority: 'high',
    caseId: '312-2025-005'
  },
  {
    id: 'NOT-004',
    userId: 'U003', // Michael Chen
    type: 'case_assigned',
    title: 'New Case Assigned',
    message: 'Case 312-2025-002 (Apex Global Trading) has been assigned to you',
    time: '1 hour ago',
    read: false,
    priority: 'high',
    caseId: '312-2025-002'
  },
  {
    id: 'NOT-005',
    userId: 'U003',
    type: 'deadline',
    title: 'Case Due in 3 Days',
    message: 'CAM-2025-002 (Pacific Rim Ventures) is due on 2025-11-02',
    time: '3 hours ago',
    read: false,
    priority: 'medium',
    caseId: 'CAM-2025-002'
  },
  {
    id: 'NOT-006',
    userId: 'U004', // Jennifer Wu
    type: 'case_assigned',
    title: 'New Case Assigned',
    message: 'Case CAM-2025-007 (Sterling Investment Portfolio) has been assigned to you',
    time: '30 minutes ago',
    read: false,
    priority: 'high',
    caseId: 'CAM-2025-007'
  },
  {
    id: 'NOT-007',
    userId: 'U004',
    type: 'sales_feedback_requested',
    title: 'Sales Owner Feedback Needed',
    message: 'Sales Owner requested feedback on CAM-2025-010',
    time: '4 hours ago',
    read: false,
    priority: 'medium',
    caseId: 'CAM-2025-010'
  },
  {
    id: 'NOT-008',
    userId: 'U005', // Lisa Brown
    type: 'case_assigned',
    title: 'New Case Assigned',
    message: 'Case CAM-2025-009 (Martinez Family Account) has been assigned to you',
    time: '2 hours ago',
    read: false,
    priority: 'high',
    caseId: 'CAM-2025-009'
  },
  {
    id: 'NOT-009',
    userId: 'U006', // Kevin Rogers
    type: 'case_assigned',
    title: 'Employee Case Assigned',
    message: 'Employee case CAM-2025-013 requires your attention',
    time: '1 hour ago',
    read: false,
    priority: 'high',
    caseId: 'CAM-2025-013'
  },
  {
    id: 'NOT-010',
    userId: 'U008', // David Park (Sales Owner)
    type: 'feedback_request',
    title: 'Case Review Feedback Requested',
    message: 'Central Team requests your feedback on 312-2025-010',
    time: '3 hours ago',
    read: false,
    priority: 'urgent',
    caseId: '312-2025-010'
  },
  {
    id: 'NOT-011',
    userId: 'U009', // Amanda Torres (Sales Owner)
    type: 'case_assigned',
    title: 'Case Feedback Required',
    message: 'Your input is needed on 312-2025-011 (Horizon Wealth Management)',
    time: '5 hours ago',
    read: false,
    priority: 'high',
    caseId: '312-2025-011'
  },
  {
    id: 'NOT-012',
    userId: 'U002', // Carlos Rivera
    type: 'deadline',
    title: 'Urgent: Case Due Today',
    message: '312-2025-004 (Quantum Family Trust) is due today',
    time: '30 minutes ago',
    read: false,
    priority: 'urgent',
    caseId: '312-2025-004'
  },
  {
    id: 'NOT-013',
    userId: 'U007', // Robert Anderson (View Only)
    type: 'report_ready',
    title: 'Report Generated',
    message: 'Q3 2025 Population Analysis report is ready for review',
    time: '1 day ago',
    read: true,
    priority: 'low',
    reportId: 'REP-003'
  },
];
