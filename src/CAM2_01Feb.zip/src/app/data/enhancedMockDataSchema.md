# Enhanced Mock Data Schema Documentation

## Overview
This document provides comprehensive schema documentation for the `enhancedMockData.ts` file, which contains mock case and client data for the CAM/312 Case Management System.

---

## Table of Contents
1. [TypeScript Interfaces](#typescript-interfaces)
2. [Database Schema (Oracle SQL)](#database-schema-oracle-sql)
3. [Field Definitions & Descriptions](#field-definitions--descriptions)
4. [Data Relationships](#data-relationships)
5. [Sample Data Structure](#sample-data-structure)

---

## TypeScript Interfaces

### Core Enums/Types

```typescript
// Case Status values
export type CaseStatus = 
  | 'Unassigned' 
  | 'In Progress' 
  | 'Pending Sales Review' 
  | 'In Sales Review' 
  | 'Sales Review Complete' 
  | 'Complete' 
  | 'Defect Remediation' 
  | 'Under Review' 
  | 'Escalated' 
  | 'Closed' 
  | 'Rejected';

// Risk Level values
export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';

// Priority values
export type Priority = 'Low' | 'Medium' | 'High' | 'Urgent';

// Line of Business values
export type LineOfBusiness = 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI';

// Model Outcome values
export type ModelOutcome = 
  | 'No additional CAM escalation required' 
  | 'CAM Case Escalated' 
  | 'Pending Review';

// Case Disposition values
export type CaseDisposition = 
  | 'No additional CAM escalation required' 
  | 'CAM Case Escalated' 
  | 'TRMS Filed' 
  | 'Client Closed' 
  | 'Escalated to Compliance' 
  | 'Pending';

// Data Source values
export type DataSource = 'Cesium' | 'WCC' | 'CMT' | 'GWIM Hub' | 'PRDS' | 'CP';
```

### Main Case Interface

```typescript
export interface Case {
  // Core Identification
  id: string;                        // Case ID (e.g., '312-2025-001', 'CAM-2025-001')
  clientId: string;                  // Client ID
  gci: string;                       // Global Client Identifier
  mpId?: string;                     // Master Party ID
  partyId?: string;                  // Party ID
  coperId?: string;                  // CoPer ID (not all clients have this)
  clientName: string;                // Client Legal/Business Name
  
  // Case Information
  caseType: string;                  // '312 Review', 'CAM Review', etc.
  status: CaseStatus;                // Current case status
  riskLevel: RiskLevel;              // Risk assessment level
  priority: Priority;                // Case priority
  
  // Assignment & Dates
  assignedTo: string;                // Currently assigned analyst/user
  centralTeamContact?: string;       // Original analyst (for sales owner view)
  createdDate: string;               // Case creation date (YYYY-MM-DD)
  dueDate: string;                   // SLA due date (YYYY-MM-DD)
  lastActivity: string;              // Last activity timestamp (YYYY-MM-DD)
  completionDate?: string;           // Case completion date
  originalCompletionDate?: string;   // Preserved when reopened for remediation
  
  // Indicators
  isBACEmployee?: boolean;           // BAC Employee Indicator
  isBACAffiliate?: boolean;          // BAC Affiliate Indicator
  isRegO?: boolean;                  // Reg O Indicator
  isManuallyTriggered?: boolean;     // Manually Triggered (ad-hoc)
  is312Case?: boolean;               // True if 312 case, false if CAM only
  
  // Metrics
  alertCount: number;                // Number of alerts
  transactionCount: number;          // Number of transactions
  totalAmount: number;               // Total transaction amount
  
  // Description & Business Context
  description: string;               // Case description
  lineOfBusiness?: LineOfBusiness;   // LOB assignment
  
  // Case Flow Fields
  autoClosed?: boolean;              // Auto-closure flag
  modelOutcome?: ModelOutcome;       // Model decision outcome
  derivedDisposition?: CaseDisposition; // Final case disposition
  defectRemediationFlag?: boolean;   // Defect remediation indicator
  salesReviewComments?: string;      // Comments from sales review
  
  // Enhanced Entity Information
  entityName?: string;               // Entity name (for organizations)
  firstName?: string;                // First name (for individuals)
  middleName?: string;               // Middle name (for individuals)
  lastName?: string;                 // Last name (for individuals)
  naicsCode?: string;                // NAICS industry code
  naicsDescription?: string;         // NAICS industry description
  
  // Additional Metadata
  refreshDueDates?: string[];        // Array of refresh due dates
  lastRefreshCompletionDate?: string; // Last refresh completion date
  clientOwners?: string[];           // Array of client owners
  amlAttributes?: string[];          // AML Attributes / CBA codes
  
  // Nested Objects (See below for detailed schemas)
  clientData?: ClientData;           // Client master data
  monitoringData?: MonitoringData;   // Risk monitoring data
  trmsCase?: TRMSCase;               // TRMS case details
  alertData?: AlertData;             // Alert summary data
  sarData?: SARData;                 // SAR filing data
  case312Data?: Case312Data;         // 312 case-specific data
  case312Response?: Case312Response; // 312 analyst response
  camCaseData?: CAMCaseData;         // CAM case-specific data
  camCaseResponse?: CAMCaseResponse; // CAM analyst response
  monitoringDashboard?: MonitoringDashboard; // Monitoring dashboard data
  caseProcessorComments?: CaseProcessorComment[]; // Processor comments
  salesOwnerResponse?: SalesOwnerResponse; // Sales owner response
  gfcSearchAnalytics?: any;          // GFC Search Analytics data
}
```

### ClientData Interface

```typescript
export interface ClientData {
  clientId: string;                  // Client ID
  gciNumber: string;                 // Global Client Identifier
  legalName: string;                 // Legal name of client
  businessName?: string;             // Business/DBA name
  salesOwner: string;                // Sales owner name/ID
  lineOfBusiness: LineOfBusiness;    // Client's LOB
  accountOpenDate: string;           // Account opening date (YYYY-MM-DD)
  clientType: string;                // 'Corporation', 'LLC', 'Trust', 'Individual', etc.
  jurisdiction: string;              // Legal jurisdiction
  dataSource: DataSource;            // Source system
  lastUpdated: string;               // Last data update timestamp
  isEmployee?: boolean;              // Employee flag
}
```

### MonitoringData Interface

```typescript
export interface MonitoringData {
  dynamicRiskRating: number;         // ORRCA dynamic risk rating
  riskRatingDate: string;            // Risk rating date (YYYY-MM-DD)
  model312Score?: number;            // 312 model score
  model312Flag: boolean;             // 312 model flag indicator
  fluMonitoringStatus?: string;      // FLU monitoring status
  fluCaseId?: string;                // FLU case ID
  lastMonitoringDate: string;        // Last monitoring date (YYYY-MM-DD)
}
```

### TRMSCase Interface

```typescript
export interface TRMSCase {
  caseId: string;                    // TRMS case ID
  caseType: string;                  // TRMS case type
  openDate: string;                  // Case open date (YYYY-MM-DD)
  status: string;                    // Current status
  priority: string;                  // Case priority
  dueDate: string;                   // Due date (YYYY-MM-DD)
}
```

### AlertData Interface

```typescript
export interface AlertData {
  sanctionsAlerts: number;           // Count of sanctions alerts
  fraudAlerts: number;               // Count of fraud alerts
  paymentAlerts: number;             // Count of payment alerts
  moneyLaunderingAlerts: number;     // Count of AML alerts
  totalAlerts: number;               // Total alert count
}
```

### SARData Interface

```typescript
export interface SARData {
  sarFiled: boolean;                 // SAR filed indicator
  sarId?: string;                    // SAR ID
  sarFilingDate?: string;            // SAR filing date (YYYY-MM-DD)
  sarType?: string;                  // SAR type/category
  sarAmount?: number;                // SAR amount
}
```

### Case312Data Interface

```typescript
export interface Case312Data {
  dueDate: string;                   // 312 case due date (YYYY-MM-DD)
  aging: number;                     // Days since case creation
  status: string;                    // 312 case status
  disposition?: string;              // 312 case disposition
  completedDate?: string;            // Completion date (YYYY-MM-DD)
  modelResult: string;               // Model result code
  modelResultDescription: string;    // Model result description
  
  // Expected Activity Volume (LOB-specific fields via ddqFields)
  expectedActivityVolume: {
    electronicTransfers?: number;    // Electronic transfer volume
    cashChecks?: number;             // Cash/check volume
    ddqFields?: Record<string, number>; // DDQ field values (LOB-specific)
  };
  
  // Expected Activity Value (LOB-specific fields via ddqFields)
  expectedActivityValue: {
    electronicTransfers?: number;    // Electronic transfer value
    cashChecks?: number;             // Cash/check value
    ddqFields?: Record<string, number>; // DDQ field values (LOB-specific)
  };
  
  expectedCrossBorderActivity?: string; // Expected cross-border countries/activities
  purposeOfRelationship?: string;    // Purpose of relationship (GB/GM only)
  purposeOfAccount?: string;         // Purpose of account (ML/PB only)
  purposeOfAccountDetails?: Case312Account[]; // Account grid details (ML/PB only)
  sourceOfFunds?: string;            // Source of funds (ML/PB only)
}
```

### Case312Account Interface

```typescript
export interface Case312Account {
  accountNumber: string;             // Account number
  accountName: string;               // Account name
  sourceOfFunds: string;             // Source of funds for this account
}
```

### Case312Response Interface

```typescript
export interface Case312Response {
  // Question 1: Expected Value and Volume of Money Movement
  question1_disposition?: 'need_trms' | 'not_unusual_other' | 'not_unusual_market_volatility';
  question1_commentary?: string;
  
  // Question 2: Cross Border Money Movement Review
  question2_disposition?: 'need_trms' | 'not_unusual';
  question2_commentary?: string;
  
  // Question 3: Purpose of Relationship/Account
  question3_option?: 'all_aligned' | 'need_trms' | 'activity_differed';
  question3_comments?: string;       // Required if 'activity_differed'
  
  // Question 4: Source of Funds (ML only)
  question4_disposition?: 'need_trms' | 'not_unusual';
  question4_commentary?: string;
  
  // Case Action
  caseAction?: 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales';
  trmsNumber?: string;               // Required if caseAction = 'complete_trms_filed'
  salesOwner?: string;               // Required if caseAction = 'send_to_sales'
  salesComments?: string;            // Optional for send_to_sales
  
  // Submission Metadata
  submittedBy?: string;              // User who submitted
  submittedDate?: string;            // Submission timestamp
  isSubmitted?: boolean;             // Submission flag
}
```

### CAMCaseData Interface

```typescript
export interface CAMCaseData {
  dueDate: string;                   // CAM case due date (YYYY-MM-DD)
  aging: number;                     // Days since case creation
  status: string;                    // CAM case status
  disposition?: string;              // CAM case disposition
  completedDate?: string;            // Completion date (YYYY-MM-DD)
  triggers: string[];                // Array of trigger descriptions
}
```

### CAMCaseResponse Interface

```typescript
export interface CAMCaseResponse {
  question1: boolean | null;         // Question 1 response
  question1_1_attestations?: string[]; // Attestation checkboxes
  question1_2_trms?: string;         // TRMS filed indicator
  question1_3_trmsNumber?: string;   // TRMS number if filed
  question2_confirmation?: boolean;  // Question 2 confirmation
  question3_action?: 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales';
  question3_trms?: string;           // TRMS indicator
  question3_salesOwner?: string;     // Sales owner (if send to sales)
  question3_comments?: string;       // Comments
  question3_confirmation?: boolean;  // Confirmation checkbox
  
  // Submission Metadata
  submittedBy?: string;              // User who submitted
  submittedDate?: string;            // Submission timestamp
  isSubmitted?: boolean;             // Submission flag
}
```

### MonitoringDashboard Interface

```typescript
export interface MonitoringDashboard {
  trmsFLU: TRMSRecord[];             // TRMS FLU records
  trmsOther: TRMSRecord[];           // Other TRMS records
  secondLineCases: SecondLineCase[]; // Second line cases
  fraudCases: FraudCase[];           // Fraud cases
  sanctionDetails: SanctionDetail[]; // Sanction details
  alert312Details: Alert312Detail[]; // 312 alert details
  lobMonitoringControls: LOBMonitoringControl[]; // LOB monitoring controls
}
```

### TRMSRecord Interface

```typescript
export interface TRMSRecord {
  id: string;                        // TRMS record ID
  type: string;                      // Record type
  monitoringProcess: string;         // Monitoring process
  descriptionReason: string;         // Description/reason
  impactType: string;                // Impact type
  narrative: string;                 // Narrative text
  date: string;                      // Record date (YYYY-MM-DD)
  submitterLOB: string;              // Submitter LOB
  submitterName: string;             // Submitter name
}
```

### SecondLineCase Interface

```typescript
export interface SecondLineCase {
  caseId: string;                    // Case ID
  caseType: string;                  // Case type
  caseStatus: string;                // Case status
  caseDescription: string;           // Case description
  caseReason: string;                // Case reason
  narrative: string;                 // Narrative
  date: string;                      // Case date (YYYY-MM-DD)
  lob: string;                       // Line of business
  linkedTRMS?: string;               // Linked TRMS ID
  sarYN: boolean;                    // SAR filed indicator
  partyInSAR?: string;               // Party in SAR
}
```

### FraudCase Interface

```typescript
export interface FraudCase {
  caseId: string;                    // Fraud case ID
  caseStatus: string;                // Case status
  narrative: string;                 // Narrative
  date: string;                      // Case date (YYYY-MM-DD)
  lob: string;                       // Line of business
  sarYN: boolean;                    // SAR filed indicator
  partyInSAR?: string;               // Party in SAR
}
```

### SanctionDetail Interface

```typescript
export interface SanctionDetail {
  caseId: string;                    // Sanction case ID
  product: string;                   // Product type
  alertDate: string;                 // Alert date (YYYY-MM-DD)
  alertDescription: string;          // Alert description
  narrative?: string;                // Narrative
  blockReject: boolean;              // Block/reject indicator
  blockRejectReason?: string;        // Block/reject reason
  lob: string;                       // Line of business
  outcome: string;                   // Outcome
}
```

### Alert312Detail Interface

```typescript
export interface Alert312Detail {
  lob312: string;                    // LOB for 312 alert
  alertDate: string;                 // Alert date (YYYY-MM-DD)
  alertDescription: string;          // Alert description
}
```

### LOBMonitoringControl Interface

```typescript
export interface LOBMonitoringControl {
  lob: string;                       // Line of business
  activityName: string;              // Activity name
  activityDescription: string;       // Activity description
  outcome: string;                   // Outcome
}
```

### CaseProcessorComment Interface

```typescript
export interface CaseProcessorComment {
  caseType: '312' | 'CAM';           // Case type
  processorName: string;             // Processor name
  comment: string;                   // Comment text
  date: string;                      // Comment date (YYYY-MM-DD)
}
```

### SalesOwnerResponse Interface

```typescript
export interface SalesOwnerResponse {
  comments: string;                  // Sales owner comments
  submittedBy?: string;              // User who submitted
  submittedDate?: string;            // Submission timestamp
  isSubmitted?: boolean;             // Submission flag
}
```

### User Interface

```typescript
export interface User {
  id: string;                        // User ID
  name: string;                      // User full name
  email: string;                     // User email
  role: UserRole;                    // User role
  avatar?: string;                   // Avatar URL
  hasM_I_Entitlement?: boolean;      // M&I entitlement for defect remediation
}
```

---

## Database Schema (Oracle SQL)

### Main Case Table: CAM_312_CASES

```sql
CREATE TABLE CAM_312_CASES (
  -- Core Identification
  CASE_ID VARCHAR2(50) PRIMARY KEY,
  CLIENT_ID VARCHAR2(50) NOT NULL,
  GCI VARCHAR2(50) NOT NULL,
  MP_ID VARCHAR2(50),
  PARTY_ID VARCHAR2(50),
  COPER_ID VARCHAR2(50),
  CLIENT_NAME VARCHAR2(255) NOT NULL,
  
  -- Case Information
  CASE_TYPE VARCHAR2(50) NOT NULL,
  STATUS VARCHAR2(50) NOT NULL,
  RISK_LEVEL VARCHAR2(20) NOT NULL CHECK (RISK_LEVEL IN ('Low', 'Medium', 'High', 'Critical')),
  PRIORITY VARCHAR2(20) NOT NULL CHECK (PRIORITY IN ('Low', 'Medium', 'High', 'Urgent')),
  
  -- Assignment & Dates
  ASSIGNED_TO VARCHAR2(100) NOT NULL,
  CENTRAL_TEAM_CONTACT VARCHAR2(100),
  CREATED_DATE DATE NOT NULL,
  DUE_DATE DATE NOT NULL,
  LAST_ACTIVITY DATE NOT NULL,
  COMPLETION_DATE DATE,
  ORIGINAL_COMPLETION_DATE DATE,
  
  -- Indicators
  IS_BAC_EMPLOYEE CHAR(1) DEFAULT 'N' CHECK (IS_BAC_EMPLOYEE IN ('Y', 'N')),
  IS_BAC_AFFILIATE CHAR(1) DEFAULT 'N' CHECK (IS_BAC_AFFILIATE IN ('Y', 'N')),
  IS_REG_O CHAR(1) DEFAULT 'N' CHECK (IS_REG_O IN ('Y', 'N')),
  IS_MANUALLY_TRIGGERED CHAR(1) DEFAULT 'N' CHECK (IS_MANUALLY_TRIGGERED IN ('Y', 'N')),
  IS_312_CASE CHAR(1) DEFAULT 'Y' CHECK (IS_312_CASE IN ('Y', 'N')),
  
  -- Metrics
  ALERT_COUNT NUMBER(10) DEFAULT 0,
  TRANSACTION_COUNT NUMBER(10) DEFAULT 0,
  TOTAL_AMOUNT NUMBER(20, 2) DEFAULT 0,
  
  -- Description & Business Context
  DESCRIPTION VARCHAR2(1000),
  LINE_OF_BUSINESS VARCHAR2(20) CHECK (LINE_OF_BUSINESS IN ('GB/GM', 'PB', 'ML', 'Consumer', 'CI')),
  
  -- Case Flow Fields
  AUTO_CLOSED CHAR(1) DEFAULT 'N' CHECK (AUTO_CLOSED IN ('Y', 'N')),
  MODEL_OUTCOME VARCHAR2(100),
  DERIVED_DISPOSITION VARCHAR2(100),
  DEFECT_REMEDIATION_FLAG CHAR(1) DEFAULT 'N' CHECK (DEFECT_REMEDIATION_FLAG IN ('Y', 'N')),
  SALES_REVIEW_COMMENTS VARCHAR2(4000),
  
  -- Enhanced Entity Information
  ENTITY_NAME VARCHAR2(255),
  FIRST_NAME VARCHAR2(100),
  MIDDLE_NAME VARCHAR2(100),
  LAST_NAME VARCHAR2(100),
  NAICS_CODE VARCHAR2(10),
  NAICS_DESCRIPTION VARCHAR2(255),
  LAST_REFRESH_COMPLETION_DATE DATE,
  
  -- Audit Fields
  CREATED_BY VARCHAR2(100) DEFAULT USER,
  CREATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UPDATED_BY VARCHAR2(100) DEFAULT USER,
  UPDATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT FK_CLIENT FOREIGN KEY (CLIENT_ID) REFERENCES CAM_PARTY_MASTER(CLIENT_ID)
);

-- Indexes for performance
CREATE INDEX IDX_CASE_STATUS ON CAM_312_CASES(STATUS);
CREATE INDEX IDX_CASE_ASSIGNED ON CAM_312_CASES(ASSIGNED_TO);
CREATE INDEX IDX_CASE_CLIENT ON CAM_312_CASES(CLIENT_ID);
CREATE INDEX IDX_CASE_GCI ON CAM_312_CASES(GCI);
CREATE INDEX IDX_CASE_LOB ON CAM_312_CASES(LINE_OF_BUSINESS);
CREATE INDEX IDX_CASE_CREATED ON CAM_312_CASES(CREATED_DATE);
CREATE INDEX IDX_CASE_DUE ON CAM_312_CASES(DUE_DATE);
```

### Client Master Table: CAM_PARTY_MASTER

```sql
CREATE TABLE CAM_PARTY_MASTER (
  CLIENT_ID VARCHAR2(50) PRIMARY KEY,
  GCI_NUMBER VARCHAR2(50) NOT NULL UNIQUE,
  LEGAL_NAME VARCHAR2(255) NOT NULL,
  BUSINESS_NAME VARCHAR2(255),
  SALES_OWNER VARCHAR2(100) NOT NULL,
  LINE_OF_BUSINESS VARCHAR2(20) NOT NULL CHECK (LINE_OF_BUSINESS IN ('GB/GM', 'PB', 'ML', 'Consumer', 'CI')),
  ACCOUNT_OPEN_DATE DATE NOT NULL,
  CLIENT_TYPE VARCHAR2(50) NOT NULL,
  JURISDICTION VARCHAR2(100) NOT NULL,
  DATA_SOURCE VARCHAR2(20) NOT NULL CHECK (DATA_SOURCE IN ('Cesium', 'WCC', 'CMT', 'GWIM Hub', 'PRDS', 'CP')),
  LAST_UPDATED DATE NOT NULL,
  IS_EMPLOYEE CHAR(1) DEFAULT 'N' CHECK (IS_EMPLOYEE IN ('Y', 'N')),
  
  -- Audit Fields
  CREATED_BY VARCHAR2(100) DEFAULT USER,
  CREATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UPDATED_BY VARCHAR2(100) DEFAULT USER,
  UPDATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IDX_PARTY_GCI ON CAM_PARTY_MASTER(GCI_NUMBER);
CREATE INDEX IDX_PARTY_LOB ON CAM_PARTY_MASTER(LINE_OF_BUSINESS);
```

### Monitoring Data Table: CAM_MONITORING_DATA

```sql
CREATE TABLE CAM_MONITORING_DATA (
  MONITORING_ID VARCHAR2(50) PRIMARY KEY,
  CLIENT_ID VARCHAR2(50) NOT NULL,
  DYNAMIC_RISK_RATING NUMBER(5, 2) NOT NULL,
  RISK_RATING_DATE DATE NOT NULL,
  MODEL_312_SCORE NUMBER(5, 2),
  MODEL_312_FLAG CHAR(1) DEFAULT 'N' CHECK (MODEL_312_FLAG IN ('Y', 'N')),
  FLU_MONITORING_STATUS VARCHAR2(50),
  FLU_CASE_ID VARCHAR2(50),
  LAST_MONITORING_DATE DATE NOT NULL,
  
  -- Audit Fields
  CREATED_BY VARCHAR2(100) DEFAULT USER,
  CREATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UPDATED_BY VARCHAR2(100) DEFAULT USER,
  UPDATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT FK_MONITORING_CLIENT FOREIGN KEY (CLIENT_ID) REFERENCES CAM_PARTY_MASTER(CLIENT_ID)
);

CREATE INDEX IDX_MONITORING_CLIENT ON CAM_MONITORING_DATA(CLIENT_ID);
```

### Alert Data Table: CAM_ALERT_DATA

```sql
CREATE TABLE CAM_ALERT_DATA (
  ALERT_ID VARCHAR2(50) PRIMARY KEY,
  CASE_ID VARCHAR2(50) NOT NULL,
  SANCTIONS_ALERTS NUMBER(10) DEFAULT 0,
  FRAUD_ALERTS NUMBER(10) DEFAULT 0,
  PAYMENT_ALERTS NUMBER(10) DEFAULT 0,
  MONEY_LAUNDERING_ALERTS NUMBER(10) DEFAULT 0,
  TOTAL_ALERTS NUMBER(10) DEFAULT 0,
  
  -- Audit Fields
  CREATED_BY VARCHAR2(100) DEFAULT USER,
  CREATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT FK_ALERT_CASE FOREIGN KEY (CASE_ID) REFERENCES CAM_312_CASES(CASE_ID)
);

CREATE INDEX IDX_ALERT_CASE ON CAM_ALERT_DATA(CASE_ID);
```

### SAR Data Table: CAM_SAR_DATA

```sql
CREATE TABLE CAM_SAR_DATA (
  SAR_ID VARCHAR2(50) PRIMARY KEY,
  CASE_ID VARCHAR2(50) NOT NULL,
  SAR_FILED CHAR(1) DEFAULT 'N' CHECK (SAR_FILED IN ('Y', 'N')),
  SAR_FILING_DATE DATE,
  SAR_TYPE VARCHAR2(100),
  SAR_AMOUNT NUMBER(20, 2),
  
  -- Audit Fields
  CREATED_BY VARCHAR2(100) DEFAULT USER,
  CREATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT FK_SAR_CASE FOREIGN KEY (CASE_ID) REFERENCES CAM_312_CASES(CASE_ID)
);

CREATE INDEX IDX_SAR_CASE ON CAM_SAR_DATA(CASE_ID);
```

### Case Processor Comments Table: CAM_PROCESSOR_COMMENTS

```sql
CREATE TABLE CAM_PROCESSOR_COMMENTS (
  COMMENT_ID VARCHAR2(50) PRIMARY KEY,
  CASE_ID VARCHAR2(50) NOT NULL,
  CASE_TYPE VARCHAR2(10) NOT NULL CHECK (CASE_TYPE IN ('312', 'CAM')),
  PROCESSOR_NAME VARCHAR2(100) NOT NULL,
  COMMENT_TEXT VARCHAR2(4000) NOT NULL,
  COMMENT_DATE DATE NOT NULL,
  
  -- Audit Fields
  CREATED_BY VARCHAR2(100) DEFAULT USER,
  CREATED_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  CONSTRAINT FK_COMMENT_CASE FOREIGN KEY (CASE_ID) REFERENCES CAM_312_CASES(CASE_ID)
);

CREATE INDEX IDX_COMMENT_CASE ON CAM_PROCESSOR_COMMENTS(CASE_ID);
```

---

## Field Definitions & Descriptions

### Core Case Fields

| Field Name | Data Type | Description | Required | Constraints |
|------------|-----------|-------------|----------|-------------|
| id | String | Unique case identifier (e.g., '312-2025-001') | Yes | Primary Key |
| clientId | String | Client identifier | Yes | Foreign Key |
| gci | String | Global Client Identifier | Yes | - |
| mpId | String | Master Party ID | No | - |
| partyId | String | Party ID | No | - |
| coperId | String | CoPer ID (not all clients have this) | No | - |
| clientName | String | Client legal/business name | Yes | Max 255 chars |
| caseType | String | Type of case ('312 Review', 'CAM Review') | Yes | - |
| status | CaseStatus | Current case status | Yes | Enum values |
| riskLevel | RiskLevel | Risk assessment level | Yes | Low/Medium/High/Critical |
| priority | Priority | Case priority | Yes | Low/Medium/High/Urgent |
| assignedTo | String | Currently assigned user | Yes | - |
| centralTeamContact | String | Original analyst (sales owner view) | No | - |
| createdDate | String | Case creation date | Yes | YYYY-MM-DD |
| dueDate | String | SLA due date | Yes | YYYY-MM-DD |
| lastActivity | String | Last activity timestamp | Yes | YYYY-MM-DD |
| completionDate | String | Case completion date | No | YYYY-MM-DD |
| originalCompletionDate | String | Original completion (for remediation) | No | YYYY-MM-DD |

### Indicator Fields

| Field Name | Data Type | Description | Default |
|------------|-----------|-------------|---------|
| isBACEmployee | Boolean | BAC Employee indicator | false |
| isBACAffiliate | Boolean | BAC Affiliate indicator | false |
| isRegO | Boolean | Regulation O indicator | false |
| isManuallyTriggered | Boolean | Manually triggered case | false |
| is312Case | Boolean | 312 case vs CAM only | true |
| autoClosed | Boolean | Auto-closure flag | false |
| defectRemediationFlag | Boolean | Defect remediation indicator | false |

### Metrics Fields

| Field Name | Data Type | Description | Default |
|------------|-----------|-------------|---------|
| alertCount | Number | Total number of alerts | 0 |
| transactionCount | Number | Total number of transactions | 0 |
| totalAmount | Number | Total transaction amount | 0 |

### LOB-Specific Fields

For **GB/GM** cases:
- `purposeOfRelationship` - Purpose of the banking relationship

For **ML/PB** cases:
- `purposeOfAccount` - Purpose of account description
- `purposeOfAccountDetails` - Array of account details with source of funds
- `sourceOfFunds` - General source of funds

---

## Data Relationships

```
CAM_PARTY_MASTER (1) ──────< (M) CAM_312_CASES
         │
         │
         └──────< (M) CAM_MONITORING_DATA

CAM_312_CASES (1) ──────< (M) CAM_ALERT_DATA
         │
         ├──────< (M) CAM_SAR_DATA
         │
         ├──────< (M) CAM_PROCESSOR_COMMENTS
         │
         └──────< (M) CAM_ASSIGNMENT_HISTORY
```

---

## Sample Data Structure

### Complete Case Example (JSON)

```json
{
  "id": "312-2025-099",
  "clientId": "GCI-999111",
  "gci": "GCI-999111",
  "mpId": "MP-45789",
  "partyId": "PTY-88901",
  "coperId": "CPR-QWE456",
  "clientName": "Completed Case Example 1",
  "caseType": "312 Review",
  "status": "Complete",
  "riskLevel": "High",
  "priority": "High",
  "assignedTo": "Sarah Mitchell",
  "centralTeamContact": "Sarah Mitchell",
  "createdDate": "2025-09-15",
  "dueDate": "2025-09-29",
  "lastActivity": "2025-10-01",
  "completionDate": "2025-10-01",
  "alertCount": 5,
  "transactionCount": 145,
  "totalAmount": 8500000,
  "description": "Completed 312 case - satisfactory review completed",
  "is312Case": true,
  "lineOfBusiness": "GB/GM",
  "modelOutcome": "No CAM Case",
  "derivedDisposition": "No Suspicious Activity",
  "isBACEmployee": false,
  "isBACAffiliate": false,
  "isRegO": false,
  "isManuallyTriggered": false,
  "clientData": {
    "clientId": "GCI-999111",
    "gciNumber": "GCI-999111",
    "legalName": "Completed Case Example 1 Corp",
    "salesOwner": "David Park (RM)",
    "lineOfBusiness": "GB/GM",
    "accountOpenDate": "2020-03-15",
    "clientType": "Corporation",
    "jurisdiction": "United States",
    "dataSource": "CMT",
    "lastUpdated": "2025-10-01",
    "isEmployee": false
  }
}
```

---

## Notes

1. **Date Format**: All dates use ISO 8601 format (YYYY-MM-DD)
2. **Nullable Fields**: Fields marked with `?` in TypeScript are optional and can be null/undefined
3. **Enums**: Use exact string values as defined in the type definitions
4. **LOB-Specific Logic**: Some fields are only applicable to specific Lines of Business
5. **Nested Objects**: Many complex data structures are stored as nested objects rather than flattened fields

---

## Version History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2025-01-29 | System | Initial schema documentation |

---

## Related Documentation

- `/src/app/data/dataDictionary.ts` - Comprehensive data dictionary
- `/src/app/data/case312DataDictionary.ts` - 312 case-specific fields
- `/src/app/data/populationDataDictionary.ts` - Population trigger fields
- `/documentation/oracle_schema.sql` - Full Oracle database schema
- `/documentation/data_dictionary.csv` - CSV export of data dictionary
