import { Case, Activity, Alert, User, Population, Report } from '../types';

export const mockUsers: User[] = [
  { id: 'U001', name: 'Sarah Mitchell', email: 'sarah.mitchell@bank.com', role: 'Analyst' },
  { id: 'U002', name: 'James Chen', email: 'james.chen@bank.com', role: 'Analyst' },
  { id: 'U003', name: 'Maria Rodriguez', email: 'maria.rodriguez@bank.com', role: 'Manager' },
  { id: 'U004', name: 'David Kim', email: 'david.kim@bank.com', role: 'Administrator' },
  { id: 'U005', name: 'Emily Watson', email: 'emily.watson@bank.com', role: 'Analyst' },
];

export const mockCases: Case[] = [
  {
    id: 'CAM-2025-001',
    clientId: 'CLI-5847',
    clientName: 'Apex Trading Corporation',
    caseType: 'Unusual Transaction Pattern',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-20',
    dueDate: '2025-10-27',
    lastActivity: '2025-10-26',
    alertCount: 5,
    transactionCount: 47,
    totalAmount: 2450000,
    description: 'Multiple large cash deposits followed by immediate wire transfers to offshore accounts.',
    clientData: {
      clientId: 'CLI-5847',
      gciNumber: 'GCI-849271',
      legalName: 'Apex Trading Corporation Limited',
      salesOwner: 'Michael Chen',
      lineOfBusiness: 'Global Banking',
      accountOpenDate: '2018-03-15',
      clientType: 'Corporate',
      jurisdiction: 'Cayman Islands',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-26'
    },
    monitoringData: {
      dynamicRiskRating: 8.5,
      riskRatingDate: '2025-10-25',
      model312Score: 7.8,
      model312Flag: true,
      lastMonitoringDate: '2025-10-26'
    },
    trmsCase: {
      caseId: 'TRMS-2025-4523',
      caseType: 'Enhanced Due Diligence',
      openDate: '2025-10-19',
      status: 'Open',
      priority: 'High',
      dueDate: '2025-10-27'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 1,
      paymentAlerts: 2,
      moneyLaunderingAlerts: 2,
      totalAlerts: 5
    },
    sarData: {
      sarFiled: false
    }
  },
  {
    id: 'CAM-2025-002',
    clientId: 'CLI-3291',
    clientName: 'Global Import Export Ltd',
    caseType: 'Structuring Activity',
    status: 'Under Review',
    riskLevel: 'Critical',
    priority: 'Urgent',
    assignedTo: 'James Chen',
    createdDate: '2025-10-18',
    dueDate: '2025-10-25',
    lastActivity: '2025-10-25',
    alertCount: 8,
    transactionCount: 132,
    totalAmount: 980000,
    description: 'Pattern of transactions just below reporting threshold over 30-day period.',
    clientData: {
      clientId: 'CLI-3291',
      gciNumber: 'GCI-329104',
      legalName: 'Global Import Export Limited',
      businessName: 'GIEX Trading',
      salesOwner: 'Jennifer Wong',
      lineOfBusiness: 'Global Markets',
      accountOpenDate: '2019-11-22',
      clientType: 'SME',
      jurisdiction: 'Hong Kong',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-26'
    },
    monitoringData: {
      dynamicRiskRating: 9.2,
      riskRatingDate: '2025-10-24',
      model312Score: 8.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    },
    trmsCase: {
      caseId: 'TRMS-2025-4489',
      caseType: 'Structuring Investigation',
      openDate: '2025-10-18',
      status: 'Under Review',
      priority: 'Urgent',
      dueDate: '2025-10-25'
    },
    alertData: {
      sanctionsAlerts: 0,
      fraudAlerts: 0,
      paymentAlerts: 5,
      moneyLaunderingAlerts: 3,
      totalAlerts: 8
    },
    sarData: {
      sarFiled: true,
      sarId: 'SAR-2025-0892',
      sarFilingDate: '2025-10-24',
      sarType: 'Structuring',
      sarAmount: 980000
    }
  },
  {
    id: 'CAM-2025-003',
    clientId: 'CLI-7629',
    clientName: 'Sunrise Investments LLC',
    caseType: 'Rapid Movement of Funds',
    status: 'New',
    riskLevel: 'Medium',
    priority: 'High',
    assignedTo: 'Emily Watson',
    createdDate: '2025-10-24',
    dueDate: '2025-10-31',
    lastActivity: '2025-10-24',
    alertCount: 3,
    transactionCount: 28,
    totalAmount: 560000,
    description: 'Funds received and immediately transferred to multiple accounts within 24 hours.'
  },
  {
    id: 'CAM-2025-004',
    clientId: 'CLI-8841',
    clientName: 'Pacific Consulting Group',
    caseType: 'Geographic Risk',
    status: 'Escalated',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-15',
    dueDate: '2025-10-22',
    lastActivity: '2025-10-26',
    alertCount: 12,
    transactionCount: 89,
    totalAmount: 3200000,
    description: 'Transactions with entities in high-risk jurisdictions without clear business purpose.'
  },
  {
    id: 'CAM-2025-005',
    clientId: 'CLI-2156',
    clientName: 'Metro Real Estate Holdings',
    caseType: 'PEP Monitoring',
    status: 'In Progress',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'James Chen',
    createdDate: '2025-10-22',
    dueDate: '2025-10-29',
    lastActivity: '2025-10-26',
    alertCount: 2,
    transactionCount: 15,
    totalAmount: 1800000,
    description: 'Politically exposed person with recent changes in transaction patterns.'
  },
  {
    id: 'CAM-2025-006',
    clientId: 'CLI-9374',
    clientName: 'Northern Manufacturing Inc',
    caseType: 'Account Activity Change',
    status: 'Closed',
    riskLevel: 'Low',
    priority: 'Low',
    assignedTo: 'Emily Watson',
    createdDate: '2025-10-10',
    dueDate: '2025-10-17',
    lastActivity: '2025-10-19',
    alertCount: 1,
    transactionCount: 8,
    totalAmount: 125000,
    description: 'Sudden increase in account activity - validated as legitimate business expansion.'
  },
  {
    id: 'CAM-2025-007',
    clientId: 'CLI-4523',
    clientName: 'Digital Solutions Corp',
    caseType: 'Third Party Payments',
    status: 'New',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-25',
    dueDate: '2025-11-01',
    lastActivity: '2025-10-25',
    alertCount: 4,
    transactionCount: 34,
    totalAmount: 720000,
    description: 'Multiple payments received from unrelated third parties.'
  },
  {
    id: 'CAM-2025-008',
    clientId: 'CLI-6782',
    clientName: 'Coastal Trading Partners',
    caseType: 'Cash Intensive Business',
    status: 'Under Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'James Chen',
    createdDate: '2025-10-19',
    dueDate: '2025-10-26',
    lastActivity: '2025-10-25',
    alertCount: 6,
    transactionCount: 156,
    totalAmount: 1950000,
    description: 'High volume of cash deposits inconsistent with stated business type.'
  },
];

export const mockActivities: Activity[] = [
  {
    id: 'ACT-001',
    caseId: 'CAM-2025-001',
    type: 'Comment',
    description: 'Added investigation notes regarding offshore account holders',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T09:15:00'
  },
  {
    id: 'ACT-002',
    caseId: 'CAM-2025-001',
    type: 'Status Change',
    description: 'Changed status from New to In Progress',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T08:30:00'
  },
  {
    id: 'ACT-003',
    caseId: 'CAM-2025-002',
    type: 'Assignment',
    description: 'Case assigned to James Chen',
    user: 'Maria Rodriguez',
    timestamp: '2025-10-25T14:20:00'
  },
  {
    id: 'ACT-004',
    caseId: 'CAM-2025-004',
    type: 'Escalation',
    description: 'Case escalated to management for review',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T11:45:00'
  },
];

export const mockAlerts: Alert[] = [
  {
    id: 'ALT-001',
    caseId: 'CAM-2025-001',
    type: 'Large Transaction',
    severity: 'High',
    description: 'Wire transfer of $450,000 to offshore account',
    date: '2025-10-24',
    status: 'Acknowledged'
  },
  {
    id: 'ALT-002',
    caseId: 'CAM-2025-001',
    type: 'Velocity',
    severity: 'Medium',
    description: 'Transaction volume exceeded threshold by 300%',
    date: '2025-10-23',
    status: 'Acknowledged'
  },
  {
    id: 'ALT-003',
    caseId: 'CAM-2025-002',
    type: 'Structuring',
    severity: 'Critical',
    description: 'Multiple deposits of $9,800 detected',
    date: '2025-10-22',
    status: 'Open'
  },
];

export const mockPopulations: Population[] = [
  {
    id: 'POP-001',
    name: 'High-Risk Geographic Exposure',
    criteria: 'Clients with >$100k transactions to FATF high-risk jurisdictions',
    clientCount: 47,
    riskScore: 8.2,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-002',
    name: 'Cash-Intensive Businesses',
    criteria: 'Businesses with >70% cash deposits over 90 days',
    clientCount: 123,
    riskScore: 6.5,
    lastRun: '2025-10-25',
    status: 'Active'
  },
  {
    id: 'POP-003',
    name: 'Rapid Account Turnover',
    criteria: 'Accounts opened <6 months with >$500k throughput',
    clientCount: 34,
    riskScore: 7.8,
    lastRun: '2025-10-26',
    status: 'Active'
  },
  {
    id: 'POP-004',
    name: 'PEP - Enhanced Due Diligence',
    criteria: 'All politically exposed persons requiring annual review',
    clientCount: 89,
    riskScore: 5.9,
    lastRun: '2025-10-24',
    status: 'Active'
  },
  {
    id: 'POP-005',
    name: 'Dormant Account Reactivation',
    criteria: 'Accounts inactive >12 months with sudden large deposits',
    clientCount: 12,
    riskScore: 7.1,
    lastRun: '2025-10-23',
    status: 'Pending'
  },
];

export const mockReports: Report[] = [
  {
    id: 'REP-001',
    name: 'Monthly Case Summary - October 2025',
    type: 'Case Statistics',
    generatedBy: 'Maria Rodriguez',
    generatedDate: '2025-10-26',
    status: 'Completed',
    format: 'PDF'
  },
  {
    id: 'REP-002',
    name: 'High-Risk Client Report',
    type: 'Risk Analysis',
    generatedBy: 'David Kim',
    generatedDate: '2025-10-25',
    status: 'Completed',
    format: 'Excel'
  },
  {
    id: 'REP-003',
    name: 'SAR Filing Activity Report',
    type: 'Regulatory',
    generatedBy: 'Maria Rodriguez',
    generatedDate: '2025-10-26',
    status: 'Processing',
    format: 'PDF'
  },
];
