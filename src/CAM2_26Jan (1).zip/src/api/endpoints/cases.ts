/**
 * Case Management API Endpoints
 * Handles 312 and CAM case operations
 */

import { apiClient, ApiResponse, PaginatedResponse } from '../client';
import {
  Case312,
  CaseCAM,
  CreateCase312Request,
  CreateCaseCAMRequest,
  UpdateCaseStatusRequest,
  AssignCaseRequest,
  CompleteCaseRequest,
  WorklistFilterParams,
  WorklistItem,
  CaseDetailResponse,
} from '../types';

/**
 * Case API Endpoints
 */
export const casesApi = {
  // ============================================================================
  // 312 Case Operations
  // ============================================================================

  /**
   * Get all 312 cases with filtering and pagination
   */
  get312Cases: async (params?: WorklistFilterParams): Promise<ApiResponse<PaginatedResponse<Case312>>> => {
    return apiClient.get<PaginatedResponse<Case312>>('/cases/312', params);
  },

  /**
   * Get a specific 312 case by ID
   */
  get312CaseById: async (caseId: string): Promise<ApiResponse<CaseDetailResponse>> => {
    return apiClient.get<CaseDetailResponse>(`/cases/312/${caseId}`);
  },

  /**
   * Create a new 312 case
   */
  create312Case: async (data: CreateCase312Request): Promise<ApiResponse<Case312>> => {
    return apiClient.post<Case312>('/cases/312', data);
  },

  /**
   * Update 312 case status
   */
  update312Status: async (
    caseId: string,
    data: UpdateCaseStatusRequest
  ): Promise<ApiResponse<Case312>> => {
    return apiClient.patch<Case312>(`/cases/312/${caseId}/status`, data);
  },

  /**
   * Assign 312 case to analyst
   */
  assign312Case: async (caseId: string, data: AssignCaseRequest): Promise<ApiResponse<Case312>> => {
    return apiClient.post<Case312>(`/cases/312/${caseId}/assign`, data);
  },

  /**
   * Complete 312 case
   */
  complete312Case: async (
    caseId: string,
    data: CompleteCaseRequest
  ): Promise<ApiResponse<Case312>> => {
    return apiClient.post<Case312>(`/cases/312/${caseId}/complete`, data);
  },

  /**
   * Cancel 312 case
   */
  cancel312Case: async (caseId: string, reason: string): Promise<ApiResponse<Case312>> => {
    return apiClient.post<Case312>(`/cases/312/${caseId}/cancel`, { reason });
  },

  // ============================================================================
  // CAM Case Operations
  // ============================================================================

  /**
   * Get all CAM cases with filtering and pagination
   */
  getCAMCases: async (params?: WorklistFilterParams): Promise<ApiResponse<PaginatedResponse<CaseCAM>>> => {
    return apiClient.get<PaginatedResponse<CaseCAM>>('/cases/cam', params);
  },

  /**
   * Get a specific CAM case by ID
   */
  getCAMCaseById: async (caseId: string): Promise<ApiResponse<CaseDetailResponse>> => {
    return apiClient.get<CaseDetailResponse>(`/cases/cam/${caseId}`);
  },

  /**
   * Create a new CAM case
   */
  createCAMCase: async (data: CreateCaseCAMRequest): Promise<ApiResponse<CaseCAM>> => {
    return apiClient.post<CaseCAM>('/cases/cam', data);
  },

  /**
   * Update CAM case status
   */
  updateCAMStatus: async (
    caseId: string,
    data: UpdateCaseStatusRequest
  ): Promise<ApiResponse<CaseCAM>> => {
    return apiClient.patch<CaseCAM>(`/cases/cam/${caseId}/status`, data);
  },

  /**
   * Assign CAM case to analyst
   */
  assignCAMCase: async (caseId: string, data: AssignCaseRequest): Promise<ApiResponse<CaseCAM>> => {
    return apiClient.post<CaseCAM>(`/cases/cam/${caseId}/assign`, data);
  },

  /**
   * Complete CAM case
   */
  completeCAMCase: async (
    caseId: string,
    data: CompleteCaseRequest
  ): Promise<ApiResponse<CaseCAM>> => {
    return apiClient.post<CaseCAM>(`/cases/cam/${caseId}/complete`, data);
  },

  /**
   * Cancel CAM case
   */
  cancelCAMCase: async (caseId: string, reason: string): Promise<ApiResponse<CaseCAM>> => {
    return apiClient.post<CaseCAM>(`/cases/cam/${caseId}/cancel`, { reason });
  },

  // ============================================================================
  // Combined Worklist Operations
  // ============================================================================

  /**
   * Get worklist (both 312 and CAM cases) with filtering
   */
  getWorklist: async (params?: WorklistFilterParams): Promise<ApiResponse<PaginatedResponse<WorklistItem>>> => {
    return apiClient.get<PaginatedResponse<WorklistItem>>('/cases/worklist', params);
  },

  /**
   * Get my assigned cases
   */
  getMyAssignedCases: async (userId: string): Promise<ApiResponse<WorklistItem[]>> => {
    return apiClient.get<WorklistItem[]>(`/cases/assigned/${userId}`);
  },

  /**
   * Get cases by party ID
   */
  getCasesByParty: async (partyId: string): Promise<ApiResponse<WorklistItem[]>> => {
    return apiClient.get<WorklistItem[]>(`/cases/party/${partyId}`);
  },

  /**
   * Get case statistics
   */
  getCaseStats: async (params?: { dateFrom?: string; dateTo?: string }): Promise<ApiResponse<any>> => {
    return apiClient.get<any>('/cases/stats', params);
  },

  /**
   * Bulk assign cases
   */
  bulkAssignCases: async (data: {
    case_ids: string[];
    assigned_to: string;
    assigned_by: string;
  }): Promise<ApiResponse<{ success: number; failed: number }>> => {
    return apiClient.post<{ success: number; failed: number }>('/cases/bulk-assign', data);
  },

  /**
   * Search cases
   */
  searchCases: async (query: string, filters?: WorklistFilterParams): Promise<ApiResponse<WorklistItem[]>> => {
    return apiClient.get<WorklistItem[]>('/cases/search', { query, ...filters });
  },

  /**
   * Get case timeline/activity log
   */
  getCaseTimeline: async (caseId: string): Promise<ApiResponse<any[]>> => {
    return apiClient.get<any[]>(`/cases/${caseId}/timeline`);
  },

  /**
   * Add comment to case
   */
  addCaseComment: async (
    caseId: string,
    data: { comment: string; user: string }
  ): Promise<ApiResponse<any>> => {
    return apiClient.post<any>(`/cases/${caseId}/comments`, data);
  },

  /**
   * Get case comments
   */
  getCaseComments: async (caseId: string): Promise<ApiResponse<any[]>> => {
    return apiClient.get<any[]>(`/cases/${caseId}/comments`);
  },

  /**
   * Link GFC cases to CAM case
   */
  linkGFCCases: async (
    camCaseId: string,
    data: { gfc_case_ids: string[] }
  ): Promise<ApiResponse<any>> => {
    return apiClient.post<any>(`/cases/cam/${camCaseId}/link-gfc`, data);
  },

  /**
   * Export cases to CSV/Excel
   */
  exportCases: async (params?: WorklistFilterParams): Promise<ApiResponse<{ download_url: string }>> => {
    return apiClient.get<{ download_url: string }>('/cases/export', params);
  },
};
