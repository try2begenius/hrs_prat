/**
 * Party/Client API Endpoints
 * Handles party master data operations
 */

import { apiClient, ApiResponse, PaginatedResponse } from '../client';
import { Party } from '../types';

/**
 * Party API Endpoints
 */
export const partiesApi = {
  // ============================================================================
  // Party Operations
  // ============================================================================

  /**
   * Get all parties with filtering and pagination
   */
  getParties: async (params?: {
    lob?: string;
    risk_rating?: string;
    has_312_flag?: 'Y' | 'N';
    active_status?: 'Y' | 'N';
    search?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ApiResponse<PaginatedResponse<Party>>> => {
    return apiClient.get<PaginatedResponse<Party>>('/parties', params);
  },

  /**
   * Get a specific party by ID
   */
  getPartyById: async (partyId: string): Promise<ApiResponse<Party>> => {
    return apiClient.get<Party>(`/parties/${partyId}`);
  },

  /**
   * Get party by client ID
   */
  getPartyByClientId: async (clientId: string): Promise<ApiResponse<Party>> => {
    return apiClient.get<Party>(`/parties/client/${clientId}`);
  },

  /**
   * Create a new party
   */
  createParty: async (data: Omit<Party, 'party_id' | 'created_date'>): Promise<ApiResponse<Party>> => {
    return apiClient.post<Party>('/parties', data);
  },

  /**
   * Update party information
   */
  updateParty: async (partyId: string, data: Partial<Party>): Promise<ApiResponse<Party>> => {
    return apiClient.put<Party>(`/parties/${partyId}`, data);
  },

  /**
   * Update party risk rating
   */
  updateRiskRating: async (
    partyId: string,
    data: {
      risk_rating: 'High' | 'Elevated' | 'Standard' | 'Low';
      effective_date: string;
      updated_by: string;
      reason?: string;
    }
  ): Promise<ApiResponse<Party>> => {
    return apiClient.patch<Party>(`/parties/${partyId}/risk-rating`, data);
  },

  /**
   * Update party refresh due date
   */
  updateRefreshDate: async (
    partyId: string,
    data: {
      refresh_due_date: string;
      updated_by: string;
      reason?: string;
    }
  ): Promise<ApiResponse<Party>> => {
    return apiClient.patch<Party>(`/parties/${partyId}/refresh-date`, data);
  },

  /**
   * Deactivate party
   */
  deactivateParty: async (
    partyId: string,
    data: {
      deactivated_by: string;
      reason: string;
    }
  ): Promise<ApiResponse<Party>> => {
    return apiClient.post<Party>(`/parties/${partyId}/deactivate`, data);
  },

  /**
   * Reactivate party
   */
  reactivateParty: async (
    partyId: string,
    data: {
      reactivated_by: string;
      reason: string;
    }
  ): Promise<ApiResponse<Party>> => {
    return apiClient.post<Party>(`/parties/${partyId}/reactivate`, data);
  },

  // ============================================================================
  // Party-Related Data
  // ============================================================================

  /**
   * Get party's case history
   */
  getPartyCaseHistory: async (partyId: string): Promise<ApiResponse<any[]>> => {
    return apiClient.get<any[]>(`/parties/${partyId}/cases`);
  },

  /**
   * Get party's GFC cases
   */
  getPartyGFCCases: async (partyId: string, params?: {
    is_in_scope?: 'Y' | 'N';
    case_status?: string;
    date_from?: string;
    date_to?: string;
  }): Promise<ApiResponse<any[]>> => {
    return apiClient.get<any[]>(`/parties/${partyId}/gfc-cases`, params);
  },

  /**
   * Get party's population trigger history
   */
  getPartyTriggerHistory: async (partyId: string): Promise<ApiResponse<any[]>> => {
    return apiClient.get<any[]>(`/parties/${partyId}/triggers`);
  },

  /**
   * Get party refresh schedule
   */
  getPartyRefreshSchedule: async (partyId: string): Promise<ApiResponse<{
    next_refresh_date: string;
    days_until_refresh: number;
    trigger_date: string;
    lob_rule: string;
  }>> => {
    return apiClient.get(`/parties/${partyId}/refresh-schedule`);
  },

  // ============================================================================
  // Bulk Operations
  // ============================================================================

  /**
   * Bulk update parties
   */
  bulkUpdateParties: async (data: {
    party_ids: string[];
    updates: Partial<Party>;
    updated_by: string;
  }): Promise<ApiResponse<{
    success_count: number;
    failed_count: number;
    errors: any[];
  }>> => {
    return apiClient.post('/parties/bulk-update', data);
  },

  /**
   * Import parties from file
   */
  importParties: async (data: {
    file_data: any;
    imported_by: string;
  }): Promise<ApiResponse<{
    imported_count: number;
    updated_count: number;
    failed_count: number;
    errors: any[];
  }>> => {
    return apiClient.post('/parties/import', data);
  },

  /**
   * Export parties to CSV/Excel
   */
  exportParties: async (params?: any): Promise<ApiResponse<{ download_url: string }>> => {
    return apiClient.get<{ download_url: string }>('/parties/export', params);
  },

  // ============================================================================
  // Search & Reporting
  // ============================================================================

  /**
   * Search parties
   */
  searchParties: async (query: string, filters?: any): Promise<ApiResponse<Party[]>> => {
    return apiClient.get<Party[]>('/parties/search', { query, ...filters });
  },

  /**
   * Get party statistics
   */
  getPartyStats: async (params?: {
    lob?: string;
    date_from?: string;
    date_to?: string;
  }): Promise<ApiResponse<{
    total_parties: number;
    by_lob: Record<string, number>;
    by_risk_rating: Record<string, number>;
    active_parties: number;
    with_312_flag: number;
    upcoming_refreshes: number;
  }>> => {
    return apiClient.get('/parties/stats', params);
  },
};
