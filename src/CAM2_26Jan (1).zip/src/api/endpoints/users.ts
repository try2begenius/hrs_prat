/**
 * User & Authentication API Endpoints
 * Handles user management, authentication, and role-based access
 */

import { apiClient, ApiResponse } from '../client';

export interface User {
  user_id: string;
  username: string;
  email: string;
  full_name: string;
  role: 'Analyst' | 'Sales Owner' | 'Administrator' | 'Manager';
  lob?: string;
  active: boolean;
  permissions: string[];
  created_date: string;
  last_login?: string;
}

export interface AuthResponse {
  success: boolean;
  token?: string;
  user?: User;
  expires_at?: string;
}

/**
 * User & Authentication API Endpoints
 */
export const usersApi = {
  // ============================================================================
  // Authentication
  // ============================================================================

  /**
   * User login
   */
  login: async (data: {
    username: string;
    password: string;
  }): Promise<ApiResponse<AuthResponse>> => {
    return apiClient.post<AuthResponse>('/auth/login', data);
  },

  /**
   * User logout
   */
  logout: async (): Promise<ApiResponse<{ success: boolean }>> => {
    return apiClient.post<{ success: boolean }>('/auth/logout');
  },

  /**
   * Refresh authentication token
   */
  refreshToken: async (): Promise<ApiResponse<AuthResponse>> => {
    return apiClient.post<AuthResponse>('/auth/refresh');
  },

  /**
   * Validate session
   */
  validateSession: async (): Promise<ApiResponse<{ valid: boolean; user?: User }>> => {
    return apiClient.get('/auth/validate');
  },

  // ============================================================================
  // User Profile
  // ============================================================================

  /**
   * Get current user profile
   */
  getCurrentUser: async (): Promise<ApiResponse<User>> => {
    return apiClient.get<User>('/users/me');
  },

  /**
   * Update current user profile
   */
  updateProfile: async (data: Partial<User>): Promise<ApiResponse<User>> => {
    return apiClient.put<User>('/users/me', data);
  },

  /**
   * Change password
   */
  changePassword: async (data: {
    current_password: string;
    new_password: string;
  }): Promise<ApiResponse<{ success: boolean }>> => {
    return apiClient.post('/users/me/change-password', data);
  },

  // ============================================================================
  // User Management
  // ============================================================================

  /**
   * Get all users
   */
  getUsers: async (params?: {
    role?: string;
    lob?: string;
    active?: boolean;
    search?: string;
  }): Promise<ApiResponse<User[]>> => {
    return apiClient.get<User[]>('/users', params);
  },

  /**
   * Get user by ID
   */
  getUserById: async (userId: string): Promise<ApiResponse<User>> => {
    return apiClient.get<User>(`/users/${userId}`);
  },

  /**
   * Create new user
   */
  createUser: async (data: Omit<User, 'user_id' | 'created_date'>): Promise<ApiResponse<User>> => {
    return apiClient.post<User>('/users', data);
  },

  /**
   * Update user
   */
  updateUser: async (userId: string, data: Partial<User>): Promise<ApiResponse<User>> => {
    return apiClient.put<User>(`/users/${userId}`, data);
  },

  /**
   * Deactivate user
   */
  deactivateUser: async (userId: string): Promise<ApiResponse<User>> => {
    return apiClient.post<User>(`/users/${userId}/deactivate`);
  },

  /**
   * Reactivate user
   */
  reactivateUser: async (userId: string): Promise<ApiResponse<User>> => {
    return apiClient.post<User>(`/users/${userId}/reactivate`);
  },

  // ============================================================================
  // Role & Permissions
  // ============================================================================

  /**
   * Get user permissions
   */
  getUserPermissions: async (userId: string): Promise<ApiResponse<{
    role: string;
    permissions: string[];
    entitlements: Record<string, boolean>;
  }>> => {
    return apiClient.get(`/users/${userId}/permissions`);
  },

  /**
   * Update user role
   */
  updateUserRole: async (
    userId: string,
    data: {
      role: string;
      updated_by: string;
      reason?: string;
    }
  ): Promise<ApiResponse<User>> => {
    return apiClient.post<User>(`/users/${userId}/role`, data);
  },

  /**
   * Get available roles
   */
  getRoles: async (): Promise<ApiResponse<Array<{
    role_name: string;
    description: string;
    permissions: string[];
  }>>> => {
    return apiClient.get('/users/roles');
  },

  // ============================================================================
  // User Workload
  // ============================================================================

  /**
   * Get user workload summary
   */
  getUserWorkload: async (userId: string): Promise<ApiResponse<{
    user_id: string;
    assigned_cases_count: number;
    cases_by_type: Record<string, number>;
    cases_by_status: Record<string, number>;
    cases_due_today: number;
    cases_overdue: number;
    avg_case_age_days: number;
  }>> => {
    return apiClient.get(`/users/${userId}/workload`);
  },

  /**
   * Get team workload distribution
   */
  getTeamWorkload: async (params?: {
    role?: string;
    lob?: string;
  }): Promise<ApiResponse<Array<{
    user_id: string;
    full_name: string;
    assigned_cases: number;
    capacity_utilization: number;
  }>>> => {
    return apiClient.get('/users/team-workload', params);
  },

  /**
   * Get available analysts for assignment
   */
  getAvailableAnalysts: async (params?: {
    lob?: string;
    case_type?: string;
  }): Promise<ApiResponse<Array<{
    user_id: string;
    full_name: string;
    current_workload: number;
    available_capacity: number;
  }>>> => {
    return apiClient.get('/users/available-analysts', params);
  },

  // ============================================================================
  // User Activity
  // ============================================================================

  /**
   * Get user activity log
   */
  getUserActivity: async (
    userId: string,
    params?: {
      date_from?: string;
      date_to?: string;
      action_type?: string;
    }
  ): Promise<ApiResponse<Array<{
    activity_id: string;
    action_type: string;
    description: string;
    timestamp: string;
    case_id?: string;
  }>>> => {
    return apiClient.get(`/users/${userId}/activity`, params);
  },

  /**
   * Get user performance metrics
   */
  getUserPerformance: async (
    userId: string,
    params?: {
      date_from?: string;
      date_to?: string;
    }
  ): Promise<ApiResponse<{
    cases_completed: number;
    avg_completion_time_days: number;
    cases_auto_closed: number;
    cases_manually_reviewed: number;
    sla_compliance_rate: number;
  }>> => {
    return apiClient.get(`/users/${userId}/performance`, params);
  },

  // ============================================================================
  // Notifications & Preferences
  // ============================================================================

  /**
   * Get user notification preferences
   */
  getNotificationPreferences: async (userId: string): Promise<ApiResponse<{
    email_assignments: boolean;
    email_escalations: boolean;
    email_deadlines: boolean;
    email_comments: boolean;
    email_status_changes: boolean;
    digest_daily: boolean;
    digest_weekly: boolean;
  }>> => {
    return apiClient.get(`/users/${userId}/notification-preferences`);
  },

  /**
   * Update notification preferences
   */
  updateNotificationPreferences: async (
    userId: string,
    preferences: Record<string, boolean>
  ): Promise<ApiResponse<any>> => {
    return apiClient.put(`/users/${userId}/notification-preferences`, preferences);
  },
};
