# 312 CAM Workflow Demonstration Cases

## Overview

This document describes the comprehensive mock data implemented to demonstrate the **312 CAM Case Review Workflow** as specified in **AC 5.1 (Functional): Workflow for 312 CAM case reviews**.

## Workflow Summary

### Case Flow Logic

Based on the specification requirements, cases follow this flow:

1. **Auto-Closed Cases**
   - Status: `Complete`
   - Model Outcome: `"312 Activity in line with expected activity"`
   - Flag: `autoClosed: true`
   - Never enter the workbasket for manual review

2. **Non-Auto-Closed Cases** follow this progression:
   ```
   Unassigned (pending) 
   → In Progress 
   → Pending Sales Review (optional)
   → In Sales Review (optional)
   → Sales Review Complete (if sales review path)
   → Complete
   ```

3. **Completed Cases** can be reopened:
   - Status: `Defect Remediation`
   - Triggered by M&I quality review findings
   - Original completion date preserved
   - Return to `Complete` status after remediation

4. **Disposition Options**:
   - No additional CAM escalation required
   - TRMS Filed (escalated to investigation)
   - Client Closed (relationship terminated)

## Status Flow Table

| Current Status | Next Status | Actor |
|----------------|-------------|-------|
| Unassigned (pending) | In Progress | Central Team Analyst or Manager |
| In Progress | Pending Sales Review Complete | Central Team Analyst |
| Pending Sales Review | In Sales Review | Central Team Analyst (routes case) |
| In Sales Review | Sales Review Complete | Sales Owner (submits response) |
| Sales Review Complete | Complete | Central Team Analyst (final disposition) |
| In Progress | Complete | Central Team Analyst (self-disposition) |
| Complete | Defect Remediation | Central Team Analyst with M&I entitlement |
| Defect Remediation | Complete | Central Team Analyst with M&I entitlement |

## Demo Case IDs and Scenarios

### Case #1: 312-2025-AUTO-100 - Auto-Closed Case
**Scenario**: Activity in line with expected patterns
- **Status**: Complete (Auto-Closed)
- **Client**: Reliable Logistics Corp
- **Disposition**: No additional CAM escalation required
- **Key Features**:
  - `autoClosed: true`
  - Model outcome: "312 Activity in line with expected activity"
  - Low risk score (2.5)
  - Completed immediately upon creation
  - No analyst assignment required

### Case #2: 312-2025-UNASSIGN-200 - Unassigned
**Scenario**: Awaiting assignment in workbasket
- **Status**: Unassigned
- **Client**: Global Tech Solutions Inc
- **Key Features**:
  - Triggered by DGA due date
  - In workbasket pending Central Team Manager assignment
  - Medium risk requiring analyst review
  - No processor assigned yet

### Case #3: 312-2025-PROG-300 - In Progress
**Scenario**: Analyst actively reviewing
- **Status**: In Progress
- **Client**: Premier Trading Partners LLC
- **Assigned To**: Michael Chen
- **Key Features**:
  - High risk requiring detailed analysis
  - Contains monitoring dashboard data
  - TRMS FLU monitoring activity present
  - Alert 312 details included
  - Demonstrates active case work

### Case #4: 312-2025-PSR-400 - Pending Sales Review
**Scenario**: Routed to sales, awaiting sales owner to open
- **Status**: Pending Sales Review
- **Client**: Apex Capital Ventures
- **Central Team Contact**: Jennifer Wu
- **Key Features**:
  - High risk case requiring sales context
  - Contains processor comments explaining why sales review needed
  - Sales owner: David Park
  - Sales Owner Response structure ready (not yet submitted)

### Case #5: 312-2025-ISR-500 - In Sales Review
**Scenario**: Sales owner actively reviewing
- **Status**: In Sales Review
- **Client**: Meridian Holdings Group
- **Sales Owner**: David Park
- **Key Features**:
  - Sales owner has opened the case
  - Draft response in progress (not submitted)
  - Contains detailed processor questions
  - Demonstrates sales owner interface

### Case #6: 312-2025-SRC-600 - Sales Review Complete
**Scenario**: Sales feedback received, analyst completing disposition
- **Status**: Sales Review Complete
- **Client**: Sterling Investment Partners
- **Key Features**:
  - Complete sales owner response submitted
  - Detailed business context provided
  - Analyst ready to make final disposition
  - Shows full sales review workflow completion

### Case #7: 312-2025-COMP-700 - Complete (Self-Disposition)
**Scenario**: Analyst completed without sales review
- **Status**: Complete
- **Client**: Northeast Distribution LLC
- **Disposition**: No additional CAM escalation required
- **Key Features**:
  - Analyst self-dispositioned (no sales review needed)
  - Contains complete 312 response data
  - Disposition rationale documented
  - Shows standard completion path

### Case #8: 312-2025-ESC-800 - Complete (TRMS Filed)
**Scenario**: Escalated to investigation
- **Status**: Complete
- **Client**: Offshore Financial Services Ltd
- **Disposition**: TRMS Filed
- **Key Features**:
  - Critical risk level
  - Suspicious activity identified
  - TRMS case created (TRMS-2025-8234)
  - CAM case data shows escalation
  - Demonstrates escalation workflow

### Case #9: 312-2025-ESC-900 - Complete (Client Closed)
**Scenario**: Relationship terminated
- **Status**: Complete
- **Client**: High Risk Trading Corp
- **Disposition**: Client Closed
- **Key Features**:
  - Unacceptable risk profile
  - Client relationship terminated
  - SAR filed prior to exit
  - Exit date documented
  - Shows most severe outcome

### Case #10: 312-2025-REM-1000 - Defect Remediation
**Scenario**: Reopened for quality review remediation
- **Status**: Defect Remediation
- **Client**: Pacific Rim Imports Inc
- **Key Features**:
  - Originally completed on 2025-10-08
  - `originalCompletionDate` preserved
  - `defectRemediationFlag: true`
  - M&I quality review identified missing documentation
  - Shows remediation workflow

## Data Structure Components

Each case includes:

### Core Case Data
- Case IDs, client identifiers (GCI, MP ID, Party ID, CoPer ID)
- Status, risk level, priority
- Assignment information
- Dates (created, due, last activity, completion)
- Workbasket indicators (BAC Employee, BAC Affiliate, Reg O)

### Client Data
- Legal name, business name
- Sales owner
- Line of business
- Client type, jurisdiction
- Data source integration
- Account opening date

### Monitoring Data
- Dynamic risk rating (ORRCA)
- 312 Model score
- 312 Model flag
- Risk rating dates

### Case 312 Data
- Status, due date
- Model result and description
- Disposition
- Source of funds
- Purpose of relationship/account
- Expected activity (volume and value)
- Broken out by FLU SOR (Electronic Transfers, Cash/Checks)
- DDQ fields (Domestic Wires, International Wires, ACH)

### Monitoring Dashboard (where applicable)
- TRMS FLU monitoring
- TRMS other cases
- Second line care cases
- Fraud cases
- Sanctions details
- Alert 312 details
- LOB monitoring controls

### Case Processor Comments
- Structured comments from analysts
- Questions and context for sales owners
- Case type identification (312 vs CAM)

### Sales Owner Response
- Submission status
- Comments/feedback
- Submitted by and date

### Case Responses
- Analyst review notes
- Disposition and rationale
- Completion details

### Escalation Data (where applicable)
- TRMS case details
- SAR information
- Exit dates

## Usage in Application

These cases are automatically loaded when you:

1. **View the Workbasket**: Unassigned and In Progress cases appear
2. **Access Individual Worklist**: Cases assigned to logged-in user
3. **Sales Owner Worklist**: Cases in sales review states
4. **Open Case Details**: Full 312/CAM data displays
5. **Test Workflows**: Complete flow from creation to disposition

## Testing Scenarios

### To Test Auto-Close Logic
- Open case `312-2025-AUTO-100`
- Verify "Auto-Closed" badge displays
- Check that case shows "312 Activity in line with expected activity"

### To Test Sales Review Workflow
1. **Pending Sales Review**: `312-2025-PSR-400`
2. **In Sales Review**: `312-2025-ISR-500`
3. **Sales Review Complete**: `312-2025-SRC-600`

### To Test Escalation Paths
- **TRMS Filed**: `312-2025-ESC-800`
- **Client Closed**: `312-2025-ESC-900`

### To Test Defect Remediation
- Open case `312-2025-REM-1000`
- Verify original completion date preserved
- Check remediation flag indicators

## Key Flags and Indicators

### Auto-Close Detection
```typescript
case.autoClosed === true
case.status === 'Complete'
case.modelOutcome === 'No additional CAM escalation required'
```

### Defect Remediation Detection
```typescript
case.status === 'Defect Remediation'
case.defectRemediationFlag === true
case.originalCompletionDate !== undefined
```

### Sales Review Detection
```typescript
['Pending Sales Review', 'In Sales Review', 'Sales Review Complete'].includes(case.status)
```

### Escalation Detection
```typescript
case.derivedDisposition === 'TRMS Filed' || case.derivedDisposition === 'Client Closed'
```

## Privacy and Data Filtering

The Sales Owner Review section implements privacy filtering to prevent "tipping off":

- **Visible to Sales**: Summary statistics, activity descriptions, case context
- **Hidden from Sales**: Detailed transaction data, SAR information, specific metrics
- **Privacy notice**: Displayed in Sales Owner section

## Line of Business Restrictions

Sales review is only available for:
- GB/GM (Global Banking/Global Markets)
- PB (Private Banking)
- ML (Merrill Lynch)

Sales review is NOT available for:
- Consumer
- CI (Corporate & Institutional)

Test cases included for all LOBs to verify restrictions.

## File Location

Mock data is located in:
- `/data/312CamWorkflowMockData.ts` - Comprehensive workflow demonstration cases
- `/data/enhancedMockData.ts` - Integrated into main mock data export

## Next Steps

To see these cases in action:

1. Navigate to **Workbasket** - View unassigned cases
2. Navigate to **Individual Worklist** - View assigned cases
3. Select a user persona (Central Team Analyst, Manager, or Sales Owner)
4. Click on any case ID to open full case details
5. Explore the 312 Case and CAM Case sections
6. For Sales Owner: Access Sales Owner Worklist to see sales review cases

---

**Last Updated**: November 1, 2025
**Version**: 1.0
**Specification Reference**: AC 5.1 (Functional) - Workflow for 312 CAM case reviews
