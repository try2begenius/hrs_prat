# 312 CAM Workflow Testing Guide

## Quick Start - How to Test the Workflow

Follow these steps to test all 10 workflow scenarios demonstrating the complete 312 CAM case review process.

---

## Prerequisites

1. Launch the application
2. You should see the main navigation with: Dashboard, Workbasket, Individual Worklist, etc.

---

## Testing Scenario 1: Auto-Closed Case

**Case ID**: `312-2025-AUTO-100`  
**Client**: Reliable Logistics Corp  
**What to Test**: Auto-close logic and display

### Steps:
1. **Navigate to Workbasket** (or Individual Worklist)
2. Look for case **312-2025-AUTO-100** in the case list
3. **Click on the case** to open Case Details

### What to Verify:
✅ Case status shows "Complete"  
✅ An "Auto-Closed" badge is displayed  
✅ Risk level shows "Low"  
✅ Assigned to: "System" (not a user)  
✅ In the **312 Case** section:
   - Status shows "Auto-Closed"
   - Model Result: "Low Risk"
   - Model Result Description: "312 Activity in line with expected activity"
   - Disposition: "No additional CAM escalation required"
✅ Expected Activity fields are populated  
✅ No CAM case section (because it was auto-closed)  
✅ No Sales Owner Review section needed

---

## Testing Scenario 2: Unassigned Case

**Case ID**: `312-2025-UNASSIGN-200`  
**Client**: Global Tech Solutions Inc  
**What to Test**: Workbasket assignment workflow

### Steps:
1. **Navigate to Workbasket**
2. Find case **312-2025-UNASSIGN-200**
3. **Click on the case** to open Case Details

### What to Verify:
✅ Status: "Unassigned"  
✅ Shows in workbasket (available for assignment)  
✅ Risk Level: "Medium"  
✅ Priority: "Medium"  
✅ In the **312 Case** section:
   - Status: "Pending"
   - Model Result: "Medium Risk"
   - Model Result Description mentions "activity patterns warrant analyst review"
   - Expected activity volume and value fields populated

### To Test Assignment:
1. **Select a Central Team Manager persona** (Sarah Mitchell or Carlos Rivera)
2. Click "Assign to Me" or assign to an analyst
3. Verify case moves from "Unassigned" to "In Progress"
4. Case should now appear in that analyst's Individual Worklist

---

## Testing Scenario 3: In Progress - Active Review

**Case ID**: `312-2025-PROG-300`  
**Client**: Premier Trading Partners LLC  
**What to Test**: Active case under review by analyst

### Steps:
1. **Select Central Team Analyst persona**: Michael Chen
2. **Navigate to Individual Worklist**
3. Find case **312-2025-PROG-300**
4. **Click on the case** to open Case Details

### What to Verify:
✅ Status: "In Progress"  
✅ Assigned to: "Michael Chen"  
✅ Risk Level: "High"  
✅ Priority: "High"  
✅ In the **312 Case** section:
   - Status: "In Progress"
   - Model Result: "High Risk"
   - Complete expected activity data
✅ **Monitoring Dashboard** section shows:
   - TRMS FLU monitoring entries
   - Alert 312 details
   - LOB monitoring controls
✅ Case Response section available for analyst input
✅ Option to route to Sales Review (if needed)

---

## Testing Scenario 4: Pending Sales Review

**Case ID**: `312-2025-PSR-400`  
**Client**: Apex Capital Ventures  
**What to Test**: Case routed to sales, awaiting sales owner

### Steps:
1. **Select Central Team Analyst persona**: Jennifer Wu
2. **Navigate to Individual Worklist** or **Workbasket**
3. Find case **312-2025-PSR-400**
4. **Click on the case**

### What to Verify:
✅ Status: "Pending Sales Review"  
✅ Central Team Contact: "Jennifer Wu"  
✅ Line of Business: "PB" (Private Banking - allows sales review)  
✅ In the **Sales Owner Review** section:
   - Shows "This section is only active when case is sent to Sales"
   - Case Processor Comments are visible
   - Shows comment from Jennifer Wu requesting sales context
   - Sales Owner Response section shows "not submitted" state

### To Test Sales Owner View:
1. **Switch to Sales Owner persona**: David Park
2. **Navigate to Sales Owner Worklist**
3. Find case **312-2025-PSR-400**
4. Verify it shows as "Pending Sales Review" (not yet opened by sales)

---

## Testing Scenario 5: In Sales Review

**Case ID**: `312-2025-ISR-500`  
**Client**: Meridian Holdings Group  
**What to Test**: Sales owner actively reviewing case

### Steps:
1. **Select Sales Owner persona**: David Park
2. **Navigate to Sales Owner Worklist**
3. Find case **312-2025-ISR-500**
4. **Click on the case**

### What to Verify:
✅ Status: "In Sales Review"  
✅ Sales Owner can see **Sales Owner Review** section  
✅ **Case Details** section shows:
   - Case ID, Client Name, Status, Line of Business
✅ **312 Case** section shows (privacy-filtered):
   - Due Date, Model Result
   - Expected activity (volume/value)
   - Source of funds, Purpose of account
   - Privacy notice: "Detailed transaction data not displayed to prevent tipping off"
✅ **Case Processor Comments** section shows:
   - Comment from Michael Chen with questions
✅ **Sales Owner Response** section:
   - Text area for comments (editable)
   - Character count (0/4000)
   - Draft response may be partially filled
   - Action buttons: Cancel, Save Draft, Return to AML Processor

### To Test Sales Response:
1. Type in the comments field
2. Click "Save Draft" - verify save confirmation
3. Click "Return to AML Processor" - case status changes to "Sales Review Complete"

---

## Testing Scenario 6: Sales Review Complete

**Case ID**: `312-2025-SRC-600`  
**Client**: Sterling Investment Partners  
**What to Test**: Sales feedback received, analyst reviewing

### Steps:
1. **Select Central Team Analyst persona**: Jennifer Wu
2. **Navigate to Individual Worklist**
3. Find case **312-2025-SRC-600**
4. **Click on the case**

### What to Verify:
✅ Status: "Sales Review Complete"  
✅ In **Sales Owner Review** section:
   - Sales Owner Response shows as "Submitted"
   - Shows submitted by "David Park" with date
   - Full sales owner comments visible to analyst
   - Response includes business context (acquisition details)
   - Response is read-only (locked with green badge)
✅ Analyst can now complete final disposition based on sales feedback
✅ **312 Case Response** section available for final disposition

### To Test Disposition:
1. Review sales owner comments
2. Fill in disposition in 312 Case section
3. Mark case as Complete with appropriate disposition

---

## Testing Scenario 7: Complete - No Escalation

**Case ID**: `312-2025-COMP-700`  
**Client**: Northeast Distribution LLC  
**What to Test**: Self-dispositioned completion (no sales review)

### Steps:
1. Navigate to **Workbasket** or **Individual Worklist**
2. Find case **312-2025-COMP-700**
3. **Click on the case**

### What to Verify:
✅ Status: "Complete"  
✅ Completion Date: "2025-10-25"  
✅ Model Outcome: "No additional CAM escalation required"  
✅ Disposition: "No additional CAM escalation required"  
✅ In **312 Case** section:
   - Status: "Complete"
   - Disposition clearly shown
✅ **Case 312 Response** section shows:
   - Analyst review notes
   - Disposition and rationale
   - Completed by: "Michael Chen"
✅ Case went directly from "In Progress" to "Complete" (no sales review)

---

## Testing Scenario 8: Complete - TRMS Filed

**Case ID**: `312-2025-ESC-800`  
**Client**: Offshore Financial Services Ltd  
**What to Test**: Escalation to TRMS investigation

### Steps:
1. Navigate to **Workbasket** or search for case **312-2025-ESC-800**
2. **Click on the case**

### What to Verify:
✅ Status: "Complete"  
✅ Risk Level: "Critical"  
✅ Disposition: "TRMS Filed"  
✅ In **312 Case** section:
   - Model Result: "Critical Risk"
   - Status: "Complete"
   - Disposition: "TRMS Filed"
✅ **Case 312 Response** shows:
   - Detailed analyst review identifying red flags
   - Multiple suspicious indicators listed
   - Disposition rationale for TRMS filing
✅ **TRMS Case** details visible:
   - TRMS Case ID: "TRMS-2025-8234"
   - Case Type: "Enhanced Due Diligence - AML"
   - Status: "Open"
   - Due Date shown
✅ **CAM Case Data** section shows:
   - Triggers identified
   - SAR recommendation: "Yes"

---

## Testing Scenario 9: Complete - Client Closed

**Case ID**: `312-2025-ESC-900`  
**Client**: High Risk Trading Corp  
**What to Test**: Relationship termination outcome

### Steps:
1. Navigate to **Workbasket** or search for case **312-2025-ESC-900**
2. **Click on the case**

### What to Verify:
✅ Status: "Complete"  
✅ Risk Level: "Critical"  
✅ Disposition: "Client Closed"  
✅ In **312 Case** section:
   - Model Result: "Critical Risk"
   - Disposition: "Client Closed"
✅ **Case 312 Response** shows:
   - Investigation findings
   - Risk profile exceeds acceptable thresholds
   - Unable to verify business model
   - Disposition: "Client Closed"
✅ **CAM Case Data** section shows:
   - Exit date: "2025-10-20"
   - Triggers: Reputational Risk, Sanctions Concerns, etc.
✅ **SAR Data** visible:
   - SAR Filed: Yes
   - SAR ID: "SAR-2025-4567"
   - SAR Filing Date: "2025-10-18"
   - SAR Amount: $67,200,000

---

## Testing Scenario 10: Defect Remediation

**Case ID**: `312-2025-REM-1000`  
**Client**: Pacific Rim Imports Inc  
**What to Test**: Case reopened for M&I quality review

### Steps:
1. **Select Central Team Analyst persona** with M&I entitlement: Michael Chen or Jennifer Wu
2. Navigate to **Individual Worklist**
3. Find case **312-2025-REM-1000**
4. **Click on the case**

### What to Verify:
✅ Status: "Defect Remediation"  
✅ Defect Remediation badge/flag displayed  
✅ **Original Completion Date**: "2025-10-08" (preserved)  
✅ Case was reopened after completion  
✅ In **312 Case** section:
   - Status: "Defect Remediation"
   - Original disposition maintained
✅ **Case 312 Response** shows:
   - Original review completion
   - Remediation Notes explaining why reopened
   - M&I quality review findings
   - Additional documentation obtained

### To Test Remediation Completion:
1. Review remediation notes
2. Verify additional documentation
3. Update case with remediation findings
4. Mark as Complete again (returns to Complete status)

---

## Quick Navigation Reference

| Test Scenario | Case ID | Where to Find It | Persona to Use |
|--------------|---------|------------------|----------------|
| Auto-Closed | 312-2025-AUTO-100 | Workbasket | Any |
| Unassigned | 312-2025-UNASSIGN-200 | Workbasket | Central Team Manager |
| In Progress | 312-2025-PROG-300 | Individual Worklist | Michael Chen (Analyst) |
| Pending Sales Review | 312-2025-PSR-400 | Individual Worklist or Sales Owner Worklist | Jennifer Wu (Analyst) or David Park (Sales) |
| In Sales Review | 312-2025-ISR-500 | Sales Owner Worklist | David Park (Sales Owner) |
| Sales Review Complete | 312-2025-SRC-600 | Individual Worklist | Jennifer Wu (Analyst) |
| Complete - No Escalation | 312-2025-COMP-700 | Workbasket | Any |
| Complete - TRMS Filed | 312-2025-ESC-800 | Workbasket | Any |
| Complete - Client Closed | 312-2025-ESC-900 | Workbasket | Any |
| Defect Remediation | 312-2025-REM-1000 | Individual Worklist | Jennifer Wu (Analyst with M&I) |

---

## Persona Quick Switch Guide

To switch personas for testing:

### Available Personas:

**Central Team Managers:**
- Sarah Mitchell
- Carlos Rivera

**Central Team Analysts:**
- Michael Chen (has M&I entitlement)
- Jennifer Wu (has M&I entitlement)
- Lisa Brown
- Kevin Rogers

**Sales Owners:**
- David Park
- Amanda Torres

**View Only:**
- Robert Anderson

### How to Switch:
1. Look for user/persona selector in the app header
2. Select the desired persona from the dropdown
3. Navigation will update to show appropriate options for that role

---

## Testing the Complete Workflow End-to-End

To test the full workflow from start to finish:

### Path 1: Auto-Close Path
1. Start with `312-2025-AUTO-100`
2. Verify immediate completion with no analyst review

### Path 2: Standard Path (No Sales Review)
1. `312-2025-UNASSIGN-200` (Unassigned)
2. Assign to analyst
3. `312-2025-PROG-300` (In Progress)
4. Complete review
5. `312-2025-COMP-700` (Complete - No Escalation)

### Path 3: Sales Review Path
1. `312-2025-PSR-400` (Pending Sales Review)
2. Switch to Sales Owner
3. `312-2025-ISR-500` (In Sales Review)
4. Submit sales response
5. Switch back to Analyst
6. `312-2025-SRC-600` (Sales Review Complete)
7. Final disposition

### Path 4: Escalation Paths
1. `312-2025-ESC-800` (TRMS Filed)
2. `312-2025-ESC-900` (Client Closed)

### Path 5: Remediation Path
1. `312-2025-COMP-700` (Complete)
2. Reopen for remediation
3. `312-2025-REM-1000` (Defect Remediation)
4. Complete remediation
5. Return to Complete

---

## Expected Data in Each Case

### All Cases Include:
- ✅ Client Data (GCI, legal name, sales owner, LOB, etc.)
- ✅ Monitoring Data (risk ratings, 312 scores)
- ✅ 312 Case Data (model results, expected activity)

### Additional Data by Scenario:
- **In Progress**: TRMS monitoring, alerts, LOB controls
- **Sales Review Cases**: Processor comments, sales responses
- **Complete - TRMS Filed**: TRMS case details, SAR info
- **Complete - Client Closed**: Exit data, SAR filing
- **Defect Remediation**: Original completion date, remediation notes

---

## Common Verification Points

For every case, verify:
1. ✅ Case banner shows correct status
2. ✅ Client details populated
3. ✅ Risk level and priority displayed
4. ✅ Assignment information correct
5. ✅ 312 Case section shows appropriate data
6. ✅ Sections visible match persona permissions
7. ✅ Sales Owner Review only visible when appropriate
8. ✅ Privacy filtering applies for sales owners
9. ✅ Workflow actions match case status
10. ✅ Historical data preserved (completion dates, etc.)

---

## Troubleshooting

**Case not appearing?**
- Check you're using the correct persona
- Verify you're in the right worklist (Workbasket vs Individual vs Sales Owner)
- Search by case ID directly

**Data missing?**
- Check persona permissions (some data restricted by role)
- Verify case status (some sections only visible in certain states)
- Confirm LOB restrictions (sales review not available for Consumer/CI)

**Can't perform action?**
- Verify user role has appropriate entitlements
- Check case status allows that action
- Confirm case is assigned to you (for Individual Worklist actions)

---

## Success Criteria

You've successfully tested the workflow if you can:

✅ View all 10 case scenarios  
✅ See appropriate data for each status  
✅ Switch between personas and see correct permissions  
✅ Understand the progression from Unassigned → Complete  
✅ See sales review workflow (Pending → In Review → Complete)  
✅ Verify escalation outcomes (TRMS, Client Closed)  
✅ Confirm defect remediation preserves original data  
✅ See privacy filtering for sales owners  
✅ Observe auto-close vs manual review differences  

---

## Next Steps

After completing this testing:

1. **Explore additional features**:
   - Email notifications
   - AKRIT Data Extract
   - Delinquency Reports
   - Population Identification

2. **Test edge cases**:
   - LOB restrictions (Consumer/CI cannot route to sales)
   - Permission restrictions (View Only cannot edit)
   - M&I entitlement requirements

3. **Review documentation**:
   - `312_CAM_WORKFLOW_DEMO.md` - Detailed specification reference
   - `COMPLETE_CASE_UI_GUIDE.md` - Full UI documentation
   - `START_HERE.md` - Overall platform guide

---

**Questions or Issues?**

Refer to:
- `312_CAM_WORKFLOW_DEMO.md` for detailed scenario descriptions
- `DATA_VISIBILITY_MATRIX.md` for role-based permissions
- `OFFICIAL_CASE_WORKFLOW.md` for workflow logic

**Last Updated**: November 1, 2025  
**Version**: 1.0
