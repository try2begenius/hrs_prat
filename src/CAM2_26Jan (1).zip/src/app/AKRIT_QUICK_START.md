# AKRIT Data Extract - Quick Start Guide

## 🚀 How to Export Case Data in 3 Steps

### Step 1: Navigate to AKRIT Extract
1. Click **"Reports"** in the sidebar
2. Click **"AKRIT Extract"** tab

### Step 2: Set Your Filters (Optional)
- **Date Range**: Select from/to dates (or leave blank for all)
- **Export Format**: Choose CSV (recommended) or Excel
- **Case Types**: Select 312 Review and/or CAM Review
- **Line of Business**: Select specific LOBs (or leave all unchecked for all)
- **Additional Filters**: Filter by 312 flag or Employee flag

### Step 3: Export
1. Review the **preview box** showing number of cases
2. Click **"Export X Cases to AKRIT"** button
3. File downloads automatically as `AKRIT_Extract_YYYY-MM-DD.csv`

---

## 📊 What's in the Export?

### 7 Required Fields:

| # | Field | Example |
|---|-------|---------|
| 1 | Case ID | `312-2025-001` |
| 2 | Client ID | `CLI-892341` |
| 3 | GCI | `GCI-892341` |
| 4 | CoPer ID | `CPR-89234` |
| 5 | Line of Business | `GB/GM` |
| 6 | 312 Client Flag | `Yes` / `No` |
| 7 | BAC Affiliate/Employee Flag | `Yes` / `No` |

---

## 🎯 Common Export Scenarios

### Scenario 1: Monthly Quality Review
**Goal**: Export all cases from October 2025

**Steps**:
1. Set **From Date**: October 1, 2025
2. Set **To Date**: October 31, 2025
3. Leave other filters at default
4. Click **Export**

**Result**: All cases created in October

---

### Scenario 2: 312 Cases Only
**Goal**: Export only 312-flagged cases for audit

**Steps**:
1. Check **"312 Client Flag = Yes only"**
2. Select **"312 Review"** case type
3. Click **Export**

**Result**: All 312 review cases with 312 flag

---

### Scenario 3: Private Bank Cases
**Goal**: Export only Private Bank LOB cases

**Steps**:
1. Check **"PB - Private Bank"** under LOB filters
2. Leave other filters unchecked
3. Click **Export**

**Result**: All PB cases

---

### Scenario 4: Employee Cases
**Goal**: Export employee/affiliate cases only

**Steps**:
1. Check **"BAC Affiliate/Employee Flag = Yes only"**
2. Click **Export**

**Result**: All employee cases

---

## 🔄 Reset Filters

Click **"Reset Filters"** button to clear all selections and start over.

---

## ⚠️ Troubleshooting

**Problem**: "0 cases will be exported"  
**Solution**: Your filters are too restrictive. Click "Reset Filters" and try broader criteria.

**Problem**: File won't open in Excel  
**Solution**: 
1. Open Excel first
2. Go to File → Open
3. Select "All Files" type
4. Choose the CSV file

**Problem**: Export button is disabled  
**Solution**: No cases match your filters. Adjust filter criteria.

---

## 📁 File Format

### CSV Sample:
```csv
Case ID,Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag
312-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
312-2025-002,CLI-445122,GCI-445122,N/A,PB,Yes,No
CAM-2025-001,CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No
```

---

## 🔒 Data Security

**Classification**: Confidential - Internal Use Only

**Do**:
- ✅ Store on secure internal systems
- ✅ Delete after quality review
- ✅ Use for authorized purposes only

**Don't**:
- ❌ Email to personal accounts
- ❌ Upload to public cloud storage
- ❌ Share with unauthorized users

---

## 📞 Support

**Technical Issues**: IT Support Team  
**Data Questions**: AML Operations Team  
**AKRIT Import Issues**: Quality Review Team

---

## 📖 Full Documentation

For complete details, see: **`/AKRIT_DATA_EXTRACT.md`**

---

**Last Updated**: October 27, 2025  
**Version**: 1.0
