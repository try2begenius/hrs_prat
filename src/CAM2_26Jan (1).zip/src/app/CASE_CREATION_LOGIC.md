# Case Creation Logic - AC 3.1, 3.2, 3.3 Implementation

## Overview
This document describes the comprehensive case creation logic implementation for CAM 312 and CAM cases, including auto-closure rules and combined case workflows.

## Acceptance Criteria Coverage

### AC 3.1: CAM 312 Case Creation Logic ✓
**Functional Requirement**: Create or auto-close CAM 312 cases based on specific criteria

#### CAM 312 Creation Rules

1. **High Risk Clients (PB/ML)**
   - **Trigger**: Client refresh is due within 180 calendar days
   - **Applies To**: Clients with High risk rating
   - **Action**: Create case for review

2. **Elevated/Standard Risk Clients (GB/GM)**
   - **Trigger**: Family refresh month minus 180 days
   - **Applies To**: GB/GM 312 clients with Elevated or Standard risk rating
   - **Action**: Create case (annual CAM 312 required)

3. **312 Model Alert Present**
   - **Condition**: Client has alert based on 312 model output
   - **Action**: Create case requiring **FULL REVIEW**
   - **Result**: Case assigned to analyst for manual disposition

4. **No 312 Model Alert**
   - **Condition**: No model alert detected
   - **Action**: **AUTO CLOSE** the case
   - **Auto-Close Specifications**:
     - Required data points automatically populated
     - Disposition set to: "312 Activity in line with expected activity"
     - Status set to: "Complete"
     - Case remains visible to consuming apps for refresh completion enablement

### AC 3.2: CAM Case Creation Logic ✓
**Functional Requirement**: Determine when CAM case requires full review or can be auto-closed

#### CAM Case Creation Triggers

**Logic Structure**: `(Trigger 1 OR Trigger 2 OR Trigger 3) AND Trigger 4`

##### Primary Triggers (Any ONE triggers case creation):

1. **312 Case Not Auto-Closed**
   - Client had a 312 case that was NOT auto-closed
   - Data Source: CAM 312 case history

2. **Case Volume Threshold**
   - Client has >XX cases in Complete status in Search Analytics
   - Timeframe: Based on case open date within last 12 months
   - Data Source: GFC Search Analytics tool

3. **SAR Case Filed**
   - Client has SAR case in Complete status
   - Timeframe: Based on SAR open date within last 12 months
   - Data Source: GFC Search Analytics tool

##### Additional Requirement (MUST be met):

4. **No Recent CAM Review**
   - No CAM case was reviewed and dispositioned in last 12 months
   - Prevents duplicate reviews of recently reviewed clients

#### CAM Auto-Close Condition
- **When**: NONE of the above trigger conditions are met
- **Action**: Auto-close the case
- **Auto-Close Specifications**:
  - Populated with necessary data
  - Status set to: "Complete"
  - Visible to all consuming applications

### AC 3.3: Combined Case Creation ✓
**Functional Requirement**: Coordinate simultaneous creation of 312 and CAM cases

#### Trigger Timing by Line of Business

| LOB | Trigger Event | Condition |
|-----|--------------|-----------|
| Private Bank | Client refresh due within 180 days | High risk rating |
| Merrill Lynch | Client refresh due within 180 days | High risk rating |
| Global Banking | DGA due date | Per GB/GM logic |
| Global Markets | DGA due date | Per GB/GM logic |
| Consumer Investments | At time of refresh completion | Refresh event |
| Consumer | At time of refresh completion | Refresh event |

#### Combined Creation Scenarios

##### Scenario 1: Both CAM 312 and CAM Required
- **312 Status**: Case Opened
- **CAM Status**: Case Opened
- **312 UI**: Full 312 section displayed and expandable
- **CAM UI**: Full CAM section displayed
- **Notes**: Both cases created and visible to analyst

##### Scenario 2: CAM Required, 312 Not in Scope
- **312 Status**: Not Applicable
- **CAM Status**: Case Opened
- **312 UI**: "Not Applicable" displayed, section not expandable
- **CAM UI**: Full CAM section displayed
- **Notes**: Only CAM case workflow active

##### Scenario 3: CAM Triggered ONLY by 312 Model Alert
- **312 Status**: Case Opened
- **CAM Status**: Case Opened (Conditional)
- **312 UI**: Full 312 section displayed
- **CAM UI**: Visible but locked until 312 complete
- **Dependency Logic**:
  - If 312 disposition is "no action" → CAM can auto-close (trigger no longer valid)
  - If 312 disposition is "action required" → CAM continues to full review
  - CAM cannot be placed in terminal status until 312 is complete

##### Scenario 4: 312 Elevated/Standard Risk
- **312 Status**: Case Opened
- **CAM Status**: Not Applicable
- **312 UI**: Full 312 section displayed
- **CAM UI**: "Not Applicable" displayed
- **Notes**: Elevated/Standard risk 312 cases do not require corresponding CAM

#### Case Dependencies

##### Blocking Dependency
- **Rule**: CAM depends on 312 completion
- **When**: CAM is triggered only due to 312 model alert
- **Effect**: CAM cannot be placed in terminal status until 312 is complete
- **Status**: CAM created and visible as "pending"

##### Conditional Auto-Close
- **Rule**: CAM auto-closure based on 312 disposition
- **Condition**: If 312 disposition is "no action" AND CAM triggered only by 312 alert
- **Effect**: CAM can auto-close (original trigger no longer valid)

#### Monitoring Data Window
- **Period**: 12 months prior to case creation trigger date
- **Applies To**: All monitoring data displayed in CAM case UI
- **Data Sources**:
  - GFC Search Analytics
  - SAR System
  - TRMS
  - Alert Management
  - 312 Model outputs

## Workflow Paths

### Workflow 1: Both Cases Full Review
```
Trigger Event → 312 Model Alert: Yes → CAM Trigger: Yes → Both Cases Opened
├─ 312 Case: Full review required, analyst assigned
└─ CAM Case: Full review required, analyst assigned
```

### Workflow 2: CAM Only
```
Trigger Event → 312: Not in Scope → CAM Trigger: Yes → CAM Case Opened
├─ 312 Section: "Not Applicable" displayed, not expandable
└─ CAM Case: Full review required, analyst assigned
```

### Workflow 3: Both Auto-Closed
```
Trigger Event → 312 Model Alert: No → CAM Triggers: None → Both Auto-Closed
├─ 312 Case: Status: Complete, Disposition: "312 Activity in line with expected activity"
└─ CAM Case: Status: Complete, populated with necessary data
```

### Workflow 4: Conditional Auto-Close
```
Trigger Event → 312 Model Alert: Yes → CAM Only Trigger: 312 Alert → Both Cases Opened
├─ 312 Case Completed First
│  ├─ Path A: 312 disposition = "no action" → CAM can auto-close
│  └─ Path B: 312 disposition = "action required" → CAM continues to full review
└─ CAM Case: Created and visible but locked until 312 complete
```

## Decision Matrix

| 312 Model Alert | CAM Trigger Met | Client Risk Level | 312 Case Action | CAM Case Action |
|----------------|-----------------|-------------------|-----------------|-----------------|
| Yes | Yes | High | Full Review | Full Review |
| Yes | No | High | Full Review | Opens, waits for 312 |
| No | Yes | High | Auto-Close | Full Review |
| No | No | High | Auto-Close | Auto-Close |
| Yes | N/A | Elevated/Standard | Full Review | Not Applicable |
| No | N/A | Elevated/Standard | Auto-Close | Not Applicable |

## Key Features

### Auto-Closure Visibility
- **Requirement**: Auto-closed cases remain visible in the system
- **Purpose**: Enables consuming apps to check case completion status
- **Use Case**: FLU tools use 312 completion status to enable/disable refresh functionality
- **Data Availability**: All case data and dispositions available via API/integration

### Data Population for Auto-Closed Cases
- **312 Cases**: All required data points populated automatically
- **CAM Cases**: Necessary data elements populated
- **Status**: Both set to "Complete"
- **Timestamp**: Case creation and auto-closure timestamps recorded

### Simultaneous Creation
- **Timing**: CAM 312 and CAM cases triggered at the same time
- **Coordination**: Combined logic ensures proper dependencies
- **Visibility**: Both cases visible in UI with appropriate status indicators

## UI Implications

### 312 Section Display States
1. **Full Review Required**: Expandable section with all review fields
2. **Auto-Closed**: Read-only view showing auto-closure reason and data
3. **Not Applicable**: Collapsed section with "Not Applicable" label

### CAM Section Display States
1. **Full Review Required**: Expandable section with all review fields
2. **Locked/Pending 312**: Visible but locked, awaiting 312 completion
3. **Auto-Closed**: Read-only view showing auto-closure reason and data
4. **Not Applicable**: Collapsed section with "Not Applicable" label

## Integration Points

### Inbound Data Requirements
- Client risk ratings (ORRCA)
- 312 model alerts and scores
- Case history from GFC Search Analytics
- SAR filing data
- Refresh due dates from FLU systems
- DGA due dates (GB/GM)

### Outbound Data Provided
- 312 case completion status (enables FLU refresh)
- 312 case disposition
- CAM case completion status
- CAM case disposition
- Auto-closure flags for both case types

## Validation Rules

### Case Creation Validation
1. Client must be in active status (closed clients excluded)
2. Risk rating must be current (from ORRCA)
3. Refresh dates must be within valid ranges
4. Previous case history checked for duplicates

### Auto-Closure Validation
1. All required data points successfully populated
2. No manual intervention flags present
3. Disposition logic successfully applied
4. Status update confirmed

### Dependency Validation
1. 312 case status verified before CAM terminal status
2. 312 disposition checked for conditional CAM auto-close
3. Case linkage established and verified
4. UI display states synchronized

## Benefits

1. **Automation**: Reduces manual workload through intelligent auto-closure
2. **Consistency**: Standardized rules across all LOBs
3. **Efficiency**: Simultaneous case creation streamlines workflow
4. **Visibility**: Auto-closed cases remain accessible for audit and refresh enablement
5. **Risk-Based**: Focus analyst attention on cases requiring review
6. **Dependencies**: Smart handling of case relationships prevents premature closure
7. **Compliance**: Ensures proper case documentation and disposition
