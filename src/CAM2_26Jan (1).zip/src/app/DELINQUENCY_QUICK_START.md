# Delinquency Report - Quick Start Guide

## 🚨 What is the Delinquency Report?

A report that identifies **overdue cases** that remain in **open status** - critical for escalating to LOB AML leads.

---

## ⚠️ Delinquent Case = 

**Expired date** (refresh or case due date is past)  
+  
**Open status** (not Complete or Closed)

---

## 🚀 How to Generate in 3 Steps

### Step 1: Navigate
1. Click **"Reports"** in sidebar
2. Click **"Delinquency"** tab (⚠️ triangle icon)

### Step 2: Filter (Optional)
- **LOB**: Select specific business units
- **Days Overdue**: Set minimum threshold (e.g., 30+ days)
- **Flags**: Filter by 312 or Employee cases
- **Format**: Choose CSV (recommended) or Excel

### Step 3: Export
1. Review count in preview box
2. Click **"Export X Cases"** (red button)
3. File downloads: `Delinquency_Report_YYYY-MM-DD.csv`
4. Email to LOB AML leads

---

## 📊 What's in the Report?

### 13 Fields:

| # | Field | Example |
|---|-------|---------|
| 1 | Client ID | `CLI-892341` |
| 2 | GCI | `GCI-892341` |
| 3 | CoPer ID | `CPR-89234` |
| 4 | Line of Business | `GB/GM` |
| 5 | 312 Client Flag | `Yes` / `No` |
| 6 | Employee Flag | `Yes` / `No` |
| 7 | Refresh Due Date | `10/15/2025` |
| 8 | 312 Case Due Date | `10/20/2025` |
| 9 | CAM Case Due Date | `10/25/2025` |
| 10 | Central Team Member | `John Smith` |
| 11 | Sales Owner | `Jane Doe` |
| 12 | **Days Overdue** ⚠️ | `15` |
| 13 | Case Status | `In Progress` |

**Key**: Report is **sorted by Days Overdue** (most urgent first)

---

## 🎯 Common Scenarios

### Scenario 1: Weekly LOB Escalation
**Goal**: Send weekly report to all LOB leads

**Steps**:
1. Leave filters at default (all LOBs)
2. Export as CSV
3. Email to all LOB AML leads

**Result**: Comprehensive weekly escalation list

---

### Scenario 2: Critical Cases Only
**Goal**: Focus on severely overdue cases

**Steps**:
1. Set **Min Days Overdue**: 30+ days
2. Export
3. Review individually, escalate to management

**Result**: Top priority cases for immediate action

---

### Scenario 3: GB/GM Specific
**Goal**: Report only for Global Banking/Markets

**Steps**:
1. Check **"GB/GM"** LOB filter only
2. Export
3. Send to GB/GM AML lead

**Result**: Targeted LOB escalation

---

### Scenario 4: Employee Cases
**Goal**: Focus on employee/affiliate delinquencies

**Steps**:
1. Check **"Employee Flag = Yes only"**
2. Set **Min Days**: 7+ days
3. Export for special handling

**Result**: Employee cases for compliance review

---

## 📈 Severity Guide

| Days Overdue | Severity | Action |
|--------------|----------|--------|
| 1-6 | ⚠️ Warning | Monitor |
| 7-13 | 🟡 Elevated | Manager review |
| 14-29 | 🟠 High | Escalate |
| 30-59 | 🔴 Critical | Immediate action |
| 60+ | 🔴🔴 Severe | Executive escalation |

---

## 📁 Sample Export

```csv
Client ID,GCI,CoPer ID,LOB,312 Flag,Employee,Refresh Due,312 Due,CAM Due,Team Member,Sales Owner,Days Overdue,Status
CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No,10/15/2025,10/20/2025,10/25/2025,John Smith,Jane Doe,15,In Progress
CLI-445122,GCI-445122,N/A,PB,Yes,No,10/10/2025,N/A,10/18/2025,Sarah Johnson,Mike Brown,20,Pending Sales Review
```

---

## 🔄 Recommended Workflow

```
Weekly (Every Monday):
1. Generate Delinquency Report (all filters off)
2. Review total count
3. Email to LOB AML leads
4. Track top 10 most overdue

Daily (for 30+ day cases):
1. Filter to 30+ days overdue
2. Review new additions
3. Escalate immediately
4. Document actions

Monthly:
1. Run full report
2. Compare to previous month
3. Identify trends
4. Present to management
```

---

## ⚡ Quick Filters

**All Delinquent Cases**:
- No filters
- Export all

**Critical Priority** (most common):
- Min Days: 30+
- Export

**LOB-Specific**:
- Check one LOB
- Export

**312 Focus**:
- 312 Flag = Yes
- Min Days: 14+
- Export

**Employee Priority**:
- Employee Flag = Yes
- Min Days: 7+
- Export

---

## 📧 Email Template

**Subject**: Delinquency Report - [Date]

**Body**:
```
Attached is the delinquency report as of [Date].

Summary:
- Total Delinquent: [X] cases
- Critical (30+ days): [Y] cases
- LOBs Affected: [List]

Report is sorted by Days Overdue (most urgent first).

Please review and take action on critical cases.

Contact the Central Team Member for case details.
```

---

## ⚠️ Troubleshooting

**Problem**: No cases found  
**Solution**: Click "Reset Filters" - may be too restrictive

**Problem**: Too many cases  
**Solution**: Filter by "30+ days" to focus on worst

**Problem**: Missing Sales Owner  
**Solution**: Contact Central Team Member instead

---

## 🔒 Important Notes

✅ **Do**:
- Export weekly for routine monitoring
- Email to authorized LOB leads only
- Delete after escalation resolved
- Track which cases get resolved

❌ **Don't**:
- Email externally
- Share without encryption
- Ignore systemic patterns
- Just report without follow-up

---

## 📞 Quick Contacts

**Report Issues**: IT Support  
**Escalation Process**: AML Operations Manager  
**Data Questions**: CAM Platform Team

---

## 📖 Full Documentation

For complete details: **`/DELINQUENCY_REPORT_DOCUMENTATION.md`**

---

**Version**: 1.0  
**Last Updated**: October 27, 2025  
**Print**: Keep at desk for quick reference
