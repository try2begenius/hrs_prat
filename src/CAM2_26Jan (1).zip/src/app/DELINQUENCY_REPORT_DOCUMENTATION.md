# Delinquency Report - Complete Documentation

## 📋 Overview

The **Delinquency Report** is a critical escalation tool that identifies clients where refresh completion dates have expired or case due dates are overdue, while corresponding CAM cases remain in open status. This report enables LOB AML leads to quickly identify and escalate cases requiring immediate attention.

---

## 🎯 Purpose

**Primary Use Case**: Identify and escalate overdue cases to LOB AML leads  
**Target Audience**: AML Managers, LOB AML Leads, Compliance Officers  
**Escalation Need**: Cases with expired dates that remain open require action  
**File Format**: CSV or Excel  
**Access Level**: Manager, Administrator roles recommended

---

## 🚨 Delinquency Criteria

A case is flagged as **delinquent** if it meets **BOTH** of these conditions:

### Condition 1: Expired Date
**ONE OR MORE** of the following dates is past due:
- **Refresh Due Date** - DDQ refresh completion date has passed
- **Main Case Due Date** - Overall case due date is overdue
- **312 Case Due Date** - 312 review component is overdue
- **CAM Case Due Date** - CAM review component is overdue

### Condition 2: Open Status
Case status is **NOT** one of:
- Complete
- Closed

**Open Statuses Include**:
- Unassigned
- In Progress
- Pending Sales Review
- In Sales Review
- Sales Review Complete
- Under Review
- Escalated
- Defect Remediation

---

## 📊 Report Contents

The Delinquency Report contains **13 fields**:

| # | Field Name | Description | Source | Example |
|---|------------|-------------|--------|---------|
| 1 | **Client ID** | Internal client identifier | `case.clientId` | `CLI-892341` |
| 2 | **GCI** | Global Client Identifier | `case.gci` | `GCI-892341` |
| 3 | **CoPer ID** | CoPer system identifier | `case.coperId` | `CPR-89234` |
| 4 | **Line of Business** | Business unit/division | `case.lineOfBusiness` | `GB/GM` |
| 5 | **312 Client Flag** | 312 case indicator | `case.is312Case` | `Yes` / `No` |
| 6 | **BAC Affiliate/Employee Flag** | Employee/affiliate status | `case.clientData.isEmployee` | `Yes` / `No` |
| 7 | **Refresh Due Date** | Most overdue refresh date | `case.refreshDueDates` | `10/15/2025` |
| 8 | **312 Case Due Date** | 312 review due date | `case.case312Data.dueDate` | `10/20/2025` |
| 9 | **CAM Case Due Date** | CAM review due date | `case.camCaseData.dueDate` | `10/25/2025` |
| 10 | **Central Team Member** | Assigned analyst | `case.assignedTo` | `John Smith` |
| 11 | **Sales Owner** | Client sales owner | `case.clientData.salesOwner` | `Jane Doe` |
| 12 | **Days Overdue** ⚠️ | Days past earliest due date | Calculated | `15` |
| 13 | **Case Status** | Current case status | `case.status` | `In Progress` |

### Key Field Details

#### Days Overdue (Critical Metric)
- **Calculation**: Days elapsed since earliest overdue date
- **Logic**: Compares all due dates (refresh, case, 312, CAM) and uses the earliest one
- **Sorting**: Report is sorted by this field (most overdue first)
- **Range**: 1 to 90+ days typical

#### Refresh Due Date
- **Selection**: If multiple refresh dates exist, shows the earliest overdue date
- **Fallback**: If no overdue refresh, shows the earliest upcoming refresh
- **Display**: Shows as "N/A" if no refresh dates exist

---

## 🚀 How to Access

### Navigation Path

1. Log into CAM Platform
2. Click **"Reports"** in the sidebar
3. Click **"Delinquency"** tab (⚠️ triangle icon)

### User Requirements

- **Recommended Roles**: Manager, Administrator
- **Purpose**: Escalation and oversight
- **Access**: Available to all roles, but primarily for management

---

## 📝 Using the Delinquency Report

### Step-by-Step Guide

#### Step 1: Navigate to Report
1. Go to Reports page
2. Click "Delinquency" tab
3. View default delinquent case count

#### Step 2: Select Export Format
Choose between:
- **CSV (Recommended)** - Universal format for email sharing
- **Excel (.xlsx)** - Microsoft Excel format

**Recommendation**: Use CSV for email distribution to LOB leads

#### Step 3: Apply Filters (Optional)

**Filter by Line of Business**:
- ☐ GB/GM - Global Banking / Global Markets
- ☐ PB - Private Bank
- ☐ ML - Merrill Lynch
- ☐ Consumer - Consumer Banking
- ☐ CI - Corporate & Investment Banking

**Additional Filters**:
- ☐ 312 Client Flag = Yes only
- ☐ BAC Affiliate/Employee Flag = Yes only

**Minimum Days Overdue**:
- All overdue cases (default)
- 1+ days
- 3+ days
- 7+ days
- 14+ days
- 30+ days
- 60+ days
- 90+ days

#### Step 4: Review Preview
Preview box shows:
- **Number** of delinquent cases
- **LOB filter** applied
- **Days overdue** threshold
- **Flag filters** active
- **Export format**

#### Step 5: Export Report
1. Click **"Export X Cases"** button (red/destructive style)
2. File downloads automatically
3. Success toast confirms export

**File Name Format**: `Delinquency_Report_YYYY-MM-DD.csv`

#### Step 6: Reset Filters (Optional)
Click **"Reset Filters"** to clear all selections

---

## 📁 Export File Format

### CSV File Structure

```csv
Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag,Refresh Due Date,312 Case Due Date,CAM Case Due Date,Central Team Member,Sales Owner,Days Overdue,Case Status
CLI-892341,GCI-892341,CPR-89234,GB/GM,Yes,No,10/15/2025,10/20/2025,10/25/2025,John Smith,Jane Doe,15,In Progress
CLI-445122,GCI-445122,N/A,PB,Yes,No,10/10/2025,N/A,10/18/2025,Sarah Johnson,Mike Brown,20,Pending Sales Review
CLI-778934,GCI-778934,CPR-77893,ML,No,Yes,10/12/2025,N/A,10/19/2025,Tom Wilson,Alice Cooper,18,In Progress
```

### Field Descriptions

#### Client ID
- **Format**: `CLI-XXXXXX`
- **Fallback**: Shows "N/A" if not available
- **Always Present**: Yes

#### GCI (Global Client Identifier)
- **Format**: `GCI-XXXXXX`
- **Required**: Yes (every case has GCI)
- **Always Present**: Yes

#### CoPer ID
- **Format**: `CPR-XXXXX`
- **May Show**: "N/A" if client doesn't have CoPer ID
- **Not All Clients**: Have CoPer IDs

#### Line of Business
- **Valid Values**: `GB/GM`, `PB`, `ML`, `Consumer`, `CI`
- **May Show**: "N/A" if not specified
- **Used For**: LOB-specific escalation

#### 312 Client Flag
- **Values**: `Yes` or `No`
- **Logic**: Yes if case has 312 review component
- **Always Present**: Yes

#### BAC Affiliate/Employee Flag
- **Values**: `Yes` or `No`
- **Logic**: Yes if client is employee or affiliate
- **Special Handling**: Employee cases may have different escalation procedures

#### Refresh Due Date
- **Format**: MM/DD/YYYY
- **Shows**: Most overdue refresh date
- **May Show**: "N/A" if no refresh dates exist

#### 312 Case Due Date
- **Format**: MM/DD/YYYY
- **Shows**: "N/A" if case has no 312 component
- **Relevant**: Only for 312 cases

#### CAM Case Due Date
- **Format**: MM/DD/YYYY
- **Shows**: "N/A" if case has no CAM component
- **Relevant**: For CAM review cases

#### Central Team Member
- **Shows**: Name of assigned analyst
- **May Show**: "Unassigned" if not yet assigned
- **Contact**: Person to follow up with on case

#### Sales Owner
- **Shows**: Name of client sales owner
- **From**: Client data system
- **May Show**: "N/A" if not in system
- **Escalation**: Key stakeholder for client relationship

#### Days Overdue ⚠️
- **Type**: Numeric
- **Calculation**: Days since earliest overdue date
- **Range**: Typically 1-90+
- **Sorting**: Report sorted by this (highest first)
- **Critical**: Higher numbers = more urgent

#### Case Status
- **Shows**: Current case workflow status
- **Values**: In Progress, Pending Sales Review, etc.
- **Use**: Understand where case is stuck

---

## 🎯 Common Use Cases

### Use Case 1: Weekly LOB Escalation Report

**Objective**: Send weekly delinquency report to all LOB AML leads

**Steps**:
1. Leave all filters at default
2. Export as **CSV**
3. Email to all LOB AML leads
4. Request action on top 10 most overdue

**Result**: Comprehensive weekly escalation

---

### Use Case 2: Critical Cases (30+ Days Overdue)

**Objective**: Identify critically overdue cases

**Steps**:
1. Set **Minimum Days Overdue**: 30+ days
2. Export as **Excel**
3. Review individually
4. Escalate to management

**Result**: Focus on most urgent cases

---

### Use Case 3: GB/GM LOB Specific Report

**Objective**: Report only for Global Banking/Markets

**Steps**:
1. Check **"GB/GM"** LOB filter only
2. Leave days overdue at default
3. Export as **CSV**
4. Send to GB/GM AML lead

**Result**: Targeted LOB escalation

---

### Use Case 4: Employee Case Priority

**Objective**: Focus on employee/affiliate delinquencies

**Steps**:
1. Check **"BAC Affiliate/Employee Flag = Yes only"**
2. Set **Minimum Days Overdue**: 7+ days
3. Export
4. Special handling procedures

**Result**: Employee cases for compliance review

---

### Use Case 5: 312 Case Escalation

**Objective**: Regulatory focus on 312 delinquencies

**Steps**:
1. Check **"312 Client Flag = Yes only"**
2. Set **Minimum Days Overdue**: 14+ days
3. Export as **Excel**
4. Prepare for regulatory inquiry

**Result**: 312 compliance focus

---

## 🔍 Filtering Logic

### How Filters Combine

Filters use **AND logic** - all selected criteria must be met:

```
Base Delinquency Criteria
    AND
LOB Filter (if selected)
    AND
312 Flag Filter (if checked)
    AND
Employee Flag Filter (if checked)
    AND
Minimum Days Overdue Threshold
```

**Example**:
- LOB: GB/GM
- 312 Flag: Yes
- Min Days: 30+

**Result**: Only GB/GM cases with 312 flag that are 30+ days overdue

### Empty Filters

If a filter is not set:
- **LOB**: Include all LOBs
- **312 Flag**: Include both Yes and No
- **Employee Flag**: Include both Yes and No
- **Days Overdue**: Include all overdue cases (0+)

---

## 📈 Delinquency Metrics

### Severity Levels (by Days Overdue)

| Days Overdue | Severity | Action Required | Escalation Level |
|--------------|----------|-----------------|------------------|
| 1-6 days | ⚠️ **Warning** | Team review | Analyst |
| 7-13 days | 🟡 **Elevated** | Manager review | Manager |
| 14-29 days | 🟠 **High** | Management action | Senior Manager |
| 30-59 days | 🔴 **Critical** | Immediate escalation | Director |
| 60+ days | 🔴🔴 **Severe** | Executive escalation | VP/Compliance |

### Typical Distribution

Based on expected CAM Platform usage:

| Severity | % of Cases | Action |
|----------|------------|--------|
| 1-6 days | 40% | Monitor |
| 7-13 days | 30% | Review |
| 14-29 days | 20% | Escalate |
| 30+ days | 10% | Immediate Action |

---

## 📊 Report Analysis Tips

### Analyzing the Export

**Step 1: Sort by Days Overdue**
- Already sorted (highest first)
- Focus on top 10-20 cases

**Step 2: Group by LOB**
- Identify which LOBs have most delinquencies
- Target interventions

**Step 3: Identify Patterns**
- Same Central Team Members = capacity issue?
- Same Sales Owners = stakeholder engagement issue?
- Same LOB = process issue?

**Step 4: Track Trends**
- Export weekly
- Compare case counts
- Monitor improvement

---

## 🔄 Escalation Workflow

### Complete Escalation Process

```
1. Manager Exports Delinquency Report
   ↓
2. Review Cases by Days Overdue
   ↓
3. Categorize by Severity
   ↓
4. For Critical Cases (30+ days):
   ├─ Email LOB AML Lead directly
   ├─ CC Central Team Member
   └─ CC Sales Owner
   ↓
5. For High Cases (14-29 days):
   ├─ Email Central Team Member
   └─ Request update within 24 hours
   ↓
6. For Elevated Cases (7-13 days):
   ├─ Review with team in weekly meeting
   └─ Document impediments
   ↓
7. Track Resolution
   ↓
8. Re-run Report Next Week
   ↓
9. Measure Improvement
```

---

## 🔧 Troubleshooting

### Issue 1: No Delinquent Cases Found

**Problem**: Report shows 0 cases

**Possible Causes**:
- All cases are on time (good!)
- Filters too restrictive
- Data issue

**Solution**:
1. Click "Reset Filters"
2. Check if count increases
3. If still 0, check case data

---

### Issue 2: Too Many Cases

**Problem**: Hundreds of delinquent cases

**Possible Causes**:
- Systemic issue
- Unrealistic due dates
- Resource constraints

**Solution**:
1. Filter by **30+ days** to focus on worst
2. Escalate to leadership
3. Consider capacity planning

---

### Issue 3: Refresh Due Date Shows "N/A"

**Problem**: Many cases show N/A for refresh dates

**Explanation**: Not all cases have DDQ refresh requirements

**Solution**: This is expected - focus on cases with actual refresh dates

---

### Issue 4: Can't Determine Who to Escalate To

**Problem**: Missing Sales Owner or Central Team Member

**Solution**:
1. Check **Central Team Member** first (always populated)
2. If Sales Owner is N/A, escalate to Central Team Member
3. They can identify correct stakeholder

---

## 📧 Email Templates

### Template 1: Weekly LOB Escalation

**Subject**: Weekly Delinquency Report - [LOB] - [Date]

**Body**:
```
Dear [LOB AML Lead],

Attached is the weekly delinquency report for [LOB] as of [Date].

Summary:
- Total Delinquent Cases: [X]
- Critical (30+ days): [Y]
- High (14-29 days): [Z]

Please review the attached report and take action on cases marked as Critical.

The report is sorted by Days Overdue with the most urgent cases at the top.

Contact the Central Team Member listed for each case for additional details.

Thank you,
[Your Name]
CAM Platform Management
```

---

### Template 2: Critical Case Escalation

**Subject**: URGENT: Critical Delinquent Case - [Client Name/GCI]

**Body**:
```
URGENT ACTION REQUIRED

Case Details:
- Client: [Client Name]
- GCI: [GCI]
- Days Overdue: [X] days
- Case Status: [Status]
- Central Team Member: [Name]
- Sales Owner: [Name]

This case has been overdue for [X] days and requires immediate attention.

Please coordinate with the Central Team Member and Sales Owner to expedite resolution.

Attached delinquency report provides full details.

Regards,
[Your Name]
```

---

## 📊 Reporting Best Practices

### ✅ Do's

**Frequency**:
- ✅ Run weekly for routine monitoring
- ✅ Run daily for critical periods
- ✅ Run monthly for trend analysis

**Distribution**:
- ✅ Email to appropriate LOB leads
- ✅ CC relevant stakeholders
- ✅ Maintain distribution list

**Follow-up**:
- ✅ Track resolution of escalated cases
- ✅ Document responses
- ✅ Measure improvement

**Analysis**:
- ✅ Identify root causes
- ✅ Track trends over time
- ✅ Present to management

### ❌ Don'ts

**Distribution**:
- ❌ Don't send to unauthorized users
- ❌ Don't email externally
- ❌ Don't post on shared drives without encryption

**Frequency**:
- ❌ Don't over-report (causes fatigue)
- ❌ Don't under-report (misses issues)

**Action**:
- ❌ Don't just report - follow up
- ❌ Don't ignore systemic patterns
- ❌ Don't blame individuals

---

## 🔒 Security & Compliance

### Data Classification

**Level**: Confidential - Internal Management Use Only

**Contains**:
- Client identifiers
- Case status information
- Team member names
- Sales owner information
- Operational metrics

**Does NOT Contain**:
- PII (names, addresses, SSN)
- Transaction details
- Account numbers
- Sensitive financial data

### Handling Requirements

**Required**:
- ✅ Store on secure internal systems
- ✅ Encrypt before emailing
- ✅ Delete after escalation resolved
- ✅ Track distribution

**Prohibited**:
- ❌ Public cloud storage
- ❌ External email
- ❌ Printing (unless necessary)
- ❌ Unauthorized sharing

### Audit Trail

**System Logs** (Future Enhancement):
- User who generated report
- Date/time of export
- Number of cases exported
- Filters applied
- Recipients (if email integration added)

---

## 📐 Technical Details

### Delinquency Calculation Algorithm

```typescript
function isCaseDelinquent(case: Case): boolean {
  const today = new Date();
  
  // Check 1: Case must be in open status
  const openStatuses = ['Unassigned', 'In Progress', 'Pending Sales Review', ...];
  if (!openStatuses.includes(case.status)) {
    return false;
  }
  
  // Check 2: At least one date must be overdue
  const hasExpiredRefresh = case.refreshDueDates?.some(d => new Date(d) < today);
  const hasExpiredCaseDate = new Date(case.dueDate) < today;
  
  return hasExpiredRefresh || hasExpiredCaseDate;
}
```

### Days Overdue Calculation

```typescript
function calculateDaysOverdue(case: Case): number {
  const today = new Date();
  let earliestOverdueDate = null;
  
  // Check all possible overdue dates
  const dates = [
    ...case.refreshDueDates || [],
    case.dueDate,
    case.case312Data?.dueDate,
    case.camCaseData?.dueDate
  ].filter(d => d && new Date(d) < today);
  
  if (dates.length > 0) {
    earliestOverdueDate = dates.sort((a, b) => 
      new Date(a).getTime() - new Date(b).getTime()
    )[0];
    
    return Math.floor((today - new Date(earliestOverdueDate)) / (1000 * 60 * 60 * 24));
  }
  
  return 0;
}
```

---

## 🔮 Future Enhancements

### Planned Features

1. **Automated Weekly Email**
   - Schedule automatic exports
   - Email directly to LOB leads
   - No manual export needed

2. **Alert Thresholds**
   - Configure custom day thresholds
   - Email alerts when cases hit thresholds
   - Escalation automation

3. **Trend Dashboard**
   - Visualize delinquency trends
   - Track improvement over time
   - Identify problem areas

4. **Root Cause Tracking**
   - Document reasons for delays
   - Pattern analysis
   - Process improvements

5. **Action Tracking**
   - Log escalations
   - Track responses
   - Measure resolution time

6. **Custom Filters**
   - Filter by Central Team Member
   - Filter by date range
   - Filter by specific GCI list

---

## 📞 Support & Contacts

### For Questions

**Report Issues**: IT Support Team  
**Delinquency Questions**: AML Operations Manager  
**Escalation Process**: Compliance Leadership  
**Data Issues**: CAM Platform Team

### Stakeholders

**LOB AML Leads**: Primary recipients of report  
**Central Team**: Case processors, contact for details  
**Sales Owners**: Client relationship owners  
**Compliance**: Oversight and regulatory requirements

---

## 📚 Related Documentation

- **AKRIT Data Extract**: For quality review exports
- **Case Workflow**: Understanding case statuses
- **Email Notifications**: Automated case notifications
- **Roles & Entitlements**: Access control

---

## ✅ Quick Reference

### Essential Information

**Feature Name**: Delinquency Report  
**Location**: Reports → Delinquency Tab  
**Icon**: ⚠️ Alert Triangle  
**Purpose**: Escalate overdue cases to LOB AML leads  
**Report Fields**: 13 (11 required + Days Overdue + Status)  
**Access**: All roles (Manager/Admin recommended)  
**File Naming**: `Delinquency_Report_YYYY-MM-DD.csv`

### Quick Steps

1. Reports → Delinquency Tab
2. Apply filters (optional)
3. Review preview count
4. Click "Export X Cases"
5. File downloads
6. Email to LOB leads

### Common Filters

- **LOB**: Filter to specific business unit
- **Days Overdue**: 30+ for critical, 7+ for elevated
- **312 Only**: Regulatory focus
- **Employee Only**: Special handling

---

**Documentation Version**: 1.0  
**Last Updated**: October 27, 2025  
**Next Review**: January 2026  
**Owner**: CAM Platform Development Team
