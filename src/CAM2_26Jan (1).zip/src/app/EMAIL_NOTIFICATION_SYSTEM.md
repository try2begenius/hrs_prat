# Email Notification System Documentation

## Overview

The CAM Platform automatically sends email notifications to Sales Owners when cases require their attention or when cases are completed. The system supports two types of email notifications based on case status and action requirements.

---

## Email Trigger Logic

### When Emails Are Sent

Emails are automatically triggered when **ALL** of the following conditions are met:

1. **312 Review Action Status** is either:
   - `No Action`, OR
   - `Send to Sales`

2. **CAM Review Action Status** is either:
   - `No Action`, OR
   - `Send to Sales`

3. **Case Status** is either:
   - `Complete`, OR
   - `Pending Sales Review`

### Email Type Determination

The type of email sent is determined by the combination of statuses:

| 312 Action | CAM Action | Case Status | Email Type |
|------------|------------|-------------|------------|
| No Action | No Action | Complete | **No Action Required** |
| Send to Sales | Send to Sales | Pending Sales Review | **Action Required** |
| Send to Sales | No Action | Pending Sales Review | **Action Required** |
| No Action | Send to Sales | Pending Sales Review | **Action Required** |

---

## Email Type 1: No Action Required

### Purpose
Inform Sales Owner that the case has been completed and no further action is needed from them.

### When Sent
- Both 312 and CAM reviews result in "No Action"
- Case status is "Complete"
- No Sales Owner input is required

### Key Features
- ✅ Informational only - no response needed
- ✅ Includes case completion date
- ✅ Shows next refresh due date (if applicable)
- ✅ Link to view case details (optional)
- ✅ Clear "No Reply Necessary" messaging

### Email Content

**Subject Line:**
```
CAM Review Complete - No Action Required: [Client Name] ([Case ID])
```

**Key Sections:**
1. **Header**: Green checkmark with "CAM Review Complete" 
2. **Summary Box**: "No further action is required from you at this time"
3. **Case Details Table**:
   - Case ID
   - Client Name
   - GCI Number
   - Case Status (Complete)
   - Completion Date
   - Reviewed By (Processor name)
   - Next Refresh Due (optional)
4. **Review Outcome**: Lists statuses for 312, CAM, and Sales Owner Input
5. **View Case Details Button** (optional)
6. **Footer Note**: "No reply to this email is necessary"

### Sample Email Preview

```
✓ CAM Review Complete
No Action Required

Dear David Park,

This email confirms that the Client Activity Monitoring (CAM) review for 
GlobalTech Industries Corp has been completed by Sarah Mitchell.

📋 Summary: No further action is required from you at this time. 
This notification is for your information only.

CASE DETAILS
- Case ID: 312-2025-001
- Client Name: GlobalTech Industries Corp
- GCI Number: GCI-892341
- Case Status: Complete
- Completion Date: October 27, 2025
- Reviewed By: Sarah Mitchell
- Next Refresh Due: April 27, 2026

REVIEW OUTCOME
- 312 Review: No additional action required
- CAM Review: No additional action required
- Sales Owner Input: Not required

[View Case Details Button]

Note: No reply to this email is necessary. This is an automated notification 
for your records.
```

---

## Email Type 2: Action Required

### Purpose
Notify Sales Owner that their input is required to complete the case review.

### When Sent
- At least one review (312 or CAM) requires Sales Owner input
- Case status is "Pending Sales Review"
- Sales Owner must respond within 30 days

### Key Features
- ⚠️ Action Required - response needed
- ⚠️ 30-day response deadline
- ⚠️ Clear call-to-action button
- ⚠️ Timeline with key milestones
- ⚠️ Consequences of non-response explained

### Email Content

**Subject Line:**
```
ACTION REQUIRED: Sales Owner Input Needed - [Client Name] ([Case ID])
```

**Key Sections:**
1. **Header**: Red warning with "ACTION REQUIRED"
2. **Alert Box**: "You must respond within the next 30 days"
3. **Case Details Table**:
   - Case ID
   - Client Name
   - GCI Number
   - Case Status (Pending Sales Review)
   - Assigned Date
   - Response Due (30 days from assigned)
   - Assigned By (Processor name)
4. **Review Status**: Shows 312 and CAM action statuses
5. **What's Needed**: Description of required input
6. **Timeline**: 
   - Today: Review case details
   - Within 7 days: Provide feedback
   - Within 30 days: Submit review
7. **Open Case & Respond Button**
8. **Important Notice**: Consequences of missing deadline
9. **Next Steps**: Numbered action items

### Sample Email Preview

```
⚠️ ACTION REQUIRED
Sales Owner Input Needed

Dear David Park,

The case processor, Sarah Mitchell, has assigned a Client Activity Monitoring 
(CAM) case to you for GlobalTech Industries Corp. Your input is needed to 
complete the case review.

⏰ RESPONSE REQUIRED: You must respond within the next 30 days to avoid 
delays in resolving this CAM review.

CASE DETAILS
- Case ID: 312-2025-001
- Client Name: GlobalTech Industries Corp
- GCI Number: GCI-892341
- Case Status: Pending Sales Review
- Assigned Date: October 27, 2025
- Response Due: November 26, 2025
- Assigned By: Sarah Mitchell

REVIEW STATUS
- 312 Review: Send to Sales
- CAM Review: Send to Sales

WHAT'S NEEDED
The processor has identified unusual transaction patterns and requires your 
input regarding the business context for these activities. Please review the 
case details and provide insights into the client's business operations and 
the legitimacy of the flagged transactions.

📅 TIMELINE
- Today: Review case details and processor comments
- Within 7 days: Provide your business context and feedback
- Within 30 days: Submit your review to avoid escalation

[Open Case & Respond Button]

⚠️ Important: Failure to respond by November 26, 2025 may result in delays 
to the case resolution and potential escalation to management.

NEXT STEPS
1. Log into the CAM Platform using the button above
2. Review the case details and processor analysis
3. Provide your business context and client relationship insights
4. Submit your sales owner review
```

---

## Technical Implementation

### File Structure

```
/data/emailNotifications.ts          # Email templates and generation functions
/utils/emailTriggers.ts               # Trigger logic and integration
/components/EmailPreview.tsx          # UI component to view sent emails
/components/Notifications.tsx         # Updated with email tab
```

### Key Functions

#### 1. Email Generation

**File:** `/data/emailNotifications.ts`

```typescript
// Generate "No Action Required" email
generateNoActionEmail(params: {
  salesOwnerName: string;
  salesOwnerEmail: string;
  processorName: string;
  clientName: string;
  caseId: string;
  gci: string;
  completionDate: string;
  refreshDueDate?: string;
  dashboardLink?: string;
}): EmailNotification

// Generate "Action Required" email
generateActionRequiredEmail(params: {
  salesOwnerName: string;
  salesOwnerEmail: string;
  processorName: string;
  clientName: string;
  caseId: string;
  gci: string;
  assignedDate: string;
  dueDate: string;
  daysToRespond: number;
  action312Status: string;
  actionCAMStatus: string;
  requestDetails: string;
  dashboardLink?: string;
}): EmailNotification
```

#### 2. Email Trigger Logic

**File:** `/utils/emailTriggers.ts`

```typescript
// Determine if email should be sent
shouldTriggerEmail(
  action312Status: string,
  actionCAMStatus: string,
  caseStatus: string
): { shouldSend: boolean; emailType: 'no_action_required' | 'action_required' | null }

// Trigger email notification
triggerEmailNotification(params: EmailTriggerParams): EmailNotification | null

// Check and send email on case submission
checkAndSendEmailOnSubmit(
  caseData: Case,
  section: '312' | 'CAM',
  processorName: string,
  formData: any
): void
```

#### 3. Email Data Structure

```typescript
interface EmailNotification {
  id: string;                          // Unique email ID
  caseId: string;                      // Associated case ID
  recipientName: string;               // Sales Owner name
  recipientEmail: string;              // Sales Owner email
  senderName: string;                  // Processor or 'CAM Platform'
  senderEmail: string;                 // System email
  subject: string;                     // Email subject line
  type: 'no_action_required' | 'action_required';
  sentDate: string;                    // Date sent (YYYY-MM-DD)
  sentTime: string;                    // Time sent (HH:MM AM/PM)
  caseStatus: string;                  // Case status when sent
  action312Status: string;             // 312 action status
  actionCAMStatus: string;             // CAM action status
  dueDate?: string;                    // Response due date (action required only)
  htmlBody: string;                    // HTML email content
  plainTextBody: string;               // Plain text email content
}
```

---

## Integration with Case Workflow

### When to Trigger Emails

#### Scenario 1: Analyst Completes Both 312 and CAM with "No Action"

**Trigger Point:** When CAM case is submitted (after 312 is already submitted)

```typescript
// In Section312Case.tsx - handleSubmit()
if (isCAMAlsoComplete && both312AndCAMAreNoAction) {
  triggerEmailNotification({
    case: caseData,
    action312Status: 'No Action',
    actionCAMStatus: 'No Action',
    processorName: currentUser.name,
  });
}
```

**Result:** "No Action Required" email sent to Sales Owner

#### Scenario 2: Analyst Requests Sales Owner Input

**Trigger Point:** When analyst selects "Request Sales Owner Input" in Q4 (312) or Q2 (CAM)

```typescript
// In Section312Case.tsx or SectionCAMCase.tsx - handleSubmit()
if (formData.question4 === 'No SAR - Request Sales Owner Input') {
  triggerEmailNotification({
    case: caseData,
    action312Status: 'Send to Sales',
    actionCAMStatus: 'Send to Sales',
    processorName: currentUser.name,
    requestDetails: formData.salesOwnerRequestDetails,
  });
  
  // Update case status
  updateCaseStatus(caseId, 'Pending Sales Review');
}
```

**Result:** "Action Required" email sent to Sales Owner

### Case Status Updates

When email is sent, the case status should be updated:

| Email Type | New Case Status |
|------------|----------------|
| No Action Required | `Complete` |
| Action Required | `Pending Sales Review` |

---

## Viewing Sent Emails

### Notifications Page

Users can view sent emails in the **Notifications** page:

1. Click **"Notifications"** in the sidebar
2. Click **"Sent Emails"** tab
3. View list of all sent emails with:
   - Email type badge (Action Required / No Action Required)
   - Subject line
   - Recipient name
   - Sent date and time
   - Case ID
   - Status badges (312, CAM, Case)

### Email Preview

Click **"View Email"** to see full email content:

- **HTML View Tab**: Rendered email with styling
- **Plain Text Tab**: Plain text version
- **Email metadata**: Subject, recipient, sent date/time
- **Resend button**: (for testing/re-sending)

### Case Details Page

Sent emails can also be viewed from the Case Details page:

- Section showing "Email Notifications Sent"
- List of emails sent for this specific case
- Quick preview of email type and date

---

## Email Styling & Branding

### Design System

**Colors:**
- Primary Blue: `#0071CE` (Merrill Lynch blue)
- Destructive Red: `#E31837` (Action required)
- Success Green: `#15803d` (Complete status)
- Gold Accent: `#D4AF37` (Deadlines/warnings)

**Typography:**
- Font Family: `'Roboto', Arial, sans-serif`
- Headers: 24px, bold
- Body: 16px, line-height 1.6
- Small text: 14px

**Layout:**
- Max width: 600px (optimal for email clients)
- Padding: 20-30px
- Border radius: 6-8px
- Responsive design for mobile

### Email Structure

```
┌─────────────────────────────────────────┐
│ HEADER (Blue/Red gradient)              │
│ ✓ / ⚠️ Title                            │
│ Subtitle                                 │
├─────────────────────────────────────────┤
│ CONTENT (White background)               │
│                                          │
│ Greeting                                 │
│                                          │
│ ┌─────────────────────────────────────┐ │
│ │ ALERT/SUMMARY BOX                   │ │
│ └─────────────────────────────────────┘ │
│                                          │
│ ┌─────────────────────────────────────┐ │
│ │ CASE DETAILS TABLE                  │ │
│ │ • Case ID                           │ │
│ │ • Client Name                       │ │
│ │ • Status, Dates, etc.               │ │
│ └─────────────────────────────────────┘ │
│                                          │
│ Section content...                       │
│                                          │
│ ┌───────────────────────────────────┐   │
│ │      [ACTION BUTTON]              │   │
│ └───────────────────────────────────┘   │
│                                          │
│ Additional info...                       │
│                                          │
├─────────────────────────────────────────┤
│ FOOTER (Gray background)                 │
│ CAM Platform branding                    │
│ Bank of America | Merrill Lynch          │
└─────────────────────────────────────────┘
```

---

## Email Client Compatibility

The emails are designed to work across major email clients:

✅ **Supported Clients:**
- Outlook (Desktop & Web)
- Gmail (Desktop & Mobile)
- Apple Mail (Mac, iPhone, iPad)
- Yahoo Mail
- AOL Mail
- ProtonMail

**Features:**
- Inline CSS (no external stylesheets)
- Table-based layout (better compatibility)
- Alt text for images (accessibility)
- Plain text fallback included
- Mobile-responsive design

---

## Mock Data

### Sample Emails in System

The system includes 3 sample emails for testing:

1. **No Action Required** - David Park
   - Case: 312-2025-AUTO-001 (Standard Manufacturing)
   - Sent by: Sarah Mitchell
   - Status: Complete

2. **Action Required** - David Park
   - Case: 312-2025-SALES-001 (Meridian Capital Holdings)
   - Sent by: Michael Chen
   - Due: November 21, 2025

3. **Action Required** - Amanda Torres
   - Case: CAM-2025-015 (Pacific Technology Group)
   - Sent by: Jennifer Wu
   - Due: November 23, 2025

### Adding Mock Emails

To add more sample emails for testing:

```typescript
// In /data/emailNotifications.ts

mockSentEmails.push(
  generateActionRequiredEmail({
    salesOwnerName: 'David Park',
    salesOwnerEmail: 'david.park@bofa.com',
    processorName: 'Sarah Mitchell',
    clientName: 'Your Client Name',
    caseId: 'YOUR-CASE-ID',
    gci: 'GCI-123456',
    assignedDate: 'October 27, 2025',
    dueDate: 'November 26, 2025',
    daysToRespond: 30,
    action312Status: 'Send to Sales',
    actionCAMStatus: 'Send to Sales',
    requestDetails: 'Your request details here...',
    dashboardLink: 'https://cam.bofa.com/cases/YOUR-CASE-ID',
  })
);
```

---

## Testing the Email System

### Test Scenario 1: No Action Required Email

**Steps:**
1. Log in as **Sarah Mitchell** (Analyst)
2. Open case **312-2025-001**
3. Complete Section 3 (312 Case):
   - Q1: No
   - Q2: No
   - Q3: No
   - Q4: No SAR - Continue monitoring
4. Submit Section 3
5. Complete Section 4 (CAM Case):
   - Q1: No (or Yes with no escalation)
   - Q2: Continue Monitoring - No Action Required
   - Q3: Provide analysis
6. Submit Section 4
7. ✅ **Email sent** to David Park (Sales Owner)
8. Go to **Notifications** → **Sent Emails** tab
9. ✅ Verify email appears with "No Action Required" badge
10. Click **"View Email"** to see full content

### Test Scenario 2: Action Required Email

**Steps:**
1. Log in as **Sarah Mitchell** (Analyst)
2. Open a new case assigned to Sarah
3. Complete Section 3 (312 Case):
   - Q1-Q3: Answer as appropriate
   - Q4: **No SAR - Request Sales Owner Input**
   - Q4.1: Select Sales Owner (David Park)
4. Submit Section 3
5. Complete Section 4 (CAM Case):
   - Q2: **Request Sales Owner Input**
   - Q2.1: "Need clarification on transaction patterns"
   - Q3: Provide analysis
6. Submit Section 4
7. ✅ **Email sent** to David Park
8. ✅ **Case status** updates to "Pending Sales Review"
9. Go to **Notifications** → **Sent Emails** tab
10. ✅ Verify email appears with "Action Required" badge (red)
11. Click **"View Email"** to see full content
12. ✅ Verify due date shows 30 days from today

### Test Scenario 3: Sales Owner Views Email

**Steps:**
1. Log in as **David Park** (Sales Owner)
2. Go to **Notifications** → **Sent Emails** tab
3. ✅ See emails sent to David Park
4. Click **"View Email"** on an Action Required email
5. ✅ See full email content with:
   - Red "Action Required" header
   - 30-day deadline
   - Case details
   - "Open Case & Respond" button
6. Click button to navigate to case (optional)

### Test Scenario 4: Email Filtering

**Steps:**
1. Log in as **Sarah Mitchell** (Analyst)
2. Go to **Notifications** → **Sent Emails** tab
3. ✅ See ALL emails (analysts see emails they sent)
4. Log in as **David Park** (Sales Owner)
5. Go to **Notifications** → **Sent Emails** tab
6. ✅ See ONLY emails sent to David Park
7. ✅ Should NOT see emails sent to Amanda Torres

---

## Production Considerations

### API Integration

In production, replace the mock `sendEmail` function with actual API call:

```typescript
// In /utils/emailTriggers.ts

export const sendEmail = async (email: EmailNotification): Promise<boolean> => {
  try {
    const response = await fetch('/api/emails/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getAuthToken()}`,
      },
      body: JSON.stringify({
        to: email.recipientEmail,
        from: email.senderEmail,
        subject: email.subject,
        htmlBody: email.htmlBody,
        plainTextBody: email.plainTextBody,
        metadata: {
          caseId: email.caseId,
          type: email.type,
        },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to send email');
    }

    return true;
  } catch (error) {
    console.error('Email send error:', error);
    return false;
  }
};
```

### Database Storage

Sent emails should be persisted in the database:

```sql
CREATE TABLE email_notifications (
  id VARCHAR(255) PRIMARY KEY,
  case_id VARCHAR(255) NOT NULL,
  recipient_name VARCHAR(255) NOT NULL,
  recipient_email VARCHAR(255) NOT NULL,
  sender_name VARCHAR(255) NOT NULL,
  sender_email VARCHAR(255) NOT NULL,
  subject TEXT NOT NULL,
  type ENUM('no_action_required', 'action_required') NOT NULL,
  sent_date DATE NOT NULL,
  sent_time TIME NOT NULL,
  case_status VARCHAR(100) NOT NULL,
  action_312_status VARCHAR(100) NOT NULL,
  action_cam_status VARCHAR(100) NOT NULL,
  due_date DATE,
  html_body TEXT NOT NULL,
  plain_text_body TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_case_id (case_id),
  INDEX idx_recipient_email (recipient_email),
  INDEX idx_sent_date (sent_date)
);
```

### Email Service Provider

Recommended email services for production:

1. **SendGrid** - Enterprise email delivery
2. **Amazon SES** - AWS Simple Email Service
3. **Mailgun** - Transactional email API
4. **Microsoft Exchange** - Internal corporate email

### Delivery Tracking

Implement email tracking:

```typescript
interface EmailTracking {
  emailId: string;
  status: 'queued' | 'sent' | 'delivered' | 'bounced' | 'failed';
  sentTimestamp: string;
  deliveredTimestamp?: string;
  openedTimestamp?: string;
  clickedTimestamp?: string;
  bounceReason?: string;
  errorMessage?: string;
}
```

### Compliance & Security

**Requirements:**
- ✅ Encryption in transit (TLS 1.2+)
- ✅ Audit trail of all sent emails
- ✅ Retention policy (7 years for financial services)
- ✅ Opt-out mechanism (if required)
- ✅ GDPR/privacy compliance
- ✅ No PII in email subject lines
- ✅ Secure links (HTTPS only)

---

## Customization Guide

### Modify Email Templates

**File:** `/data/emailNotifications.ts`

To change email styling:

```typescript
// In generateNoActionEmail() or generateActionRequiredEmail()

const htmlBody = `
<style>
  /* Modify these CSS variables */
  .header { 
    background: linear-gradient(135deg, #0071CE 0%, #005EA8 100%); 
  }
  .button { 
    background: #0071CE; 
  }
  /* Add more custom styles */
</style>
`;
```

### Add New Email Types

1. Create new email type in interface:

```typescript
type: 'no_action_required' | 'action_required' | 'reminder' | 'escalation'
```

2. Create generator function:

```typescript
export const generateReminderEmail = (params) => {
  // Email template here
};
```

3. Update trigger logic in `shouldTriggerEmail()`

### Modify Trigger Conditions

**File:** `/utils/emailTriggers.ts`

```typescript
export const shouldTriggerEmail = (
  action312Status: string,
  actionCAMStatus: string,
  caseStatus: string
): { shouldSend: boolean; emailType: EmailType } => {
  
  // Add custom logic here
  if (customCondition) {
    return { shouldSend: true, emailType: 'your_new_type' };
  }
  
  // ... existing logic
};
```

---

## Troubleshooting

### Email Not Sending

**Check:**
1. ✅ Both 312 and CAM sections submitted?
2. ✅ Action statuses are 'No Action' or 'Send to Sales'?
3. ✅ Case status is 'Complete' or 'Pending Sales Review'?
4. ✅ Sales Owner is assigned to the case?
5. ✅ Console logs show email trigger?

### Email Not Appearing in List

**Check:**
1. ✅ Correct user logged in?
2. ✅ Email added to `mockSentEmails` array?
3. ✅ Filter logic in `EmailPreview` component?
4. ✅ Browser console for errors?

### Formatting Issues

**Check:**
1. ✅ HTML is valid (no unclosed tags)?
2. ✅ Inline CSS used (not external)?
3. ✅ Table-based layout (email clients don't support flexbox/grid)?
4. ✅ Test in multiple email clients?

---

## Future Enhancements

### Planned Features

1. **Email Reminders**
   - Send reminder after 7 days if no response
   - Send final reminder after 21 days
   - Escalate to manager after 30 days

2. **Email Templates**
   - Admin interface to edit templates
   - Support for multiple languages
   - Custom branding per LOB

3. **Delivery Confirmation**
   - Track email delivery status
   - Notification if email bounces
   - Resend failed emails

4. **Email Preferences**
   - User can choose email frequency
   - Opt for daily digest vs. immediate
   - HTML vs. plain text preference

5. **Analytics Dashboard**
   - Email open rates
   - Click-through rates
   - Average response time
   - Bounce rate tracking

---

## Support & Contact

For questions or issues with the email notification system:

- **Technical Issues**: Contact IT Support
- **Template Changes**: Contact UX/Design Team
- **Business Logic**: Contact AML Compliance Team
- **Integration Issues**: Contact Platform Development Team

---

**Document Version:** 1.0  
**Last Updated:** October 27, 2025  
**Author:** CAM Platform Team
