# Individual User Worklist

## Overview

Each individual user has a personal worklist that displays all cases assigned to their login ID, regardless of stage or status. This provides users with a focused view of their active workload and case history.

---

## Navigation

**Menu Location**: Sidebar → "My Cases"  
**Icon**: Briefcase (💼)  
**Access**: All users with worklist viewing permission

---

## Worklist Structure

### Data Columns

The individual worklist displays 11 columns:

| # | Column | Field | Description | Sortable |
|---|--------|-------|-------------|----------|
| 1 | **Case Number** | `id` | Unique case identifier (hyperlink to case details) | ✅ Yes |
| 2 | **Client Name** | `clientName` | Legal or business name of the client | ✅ Yes |
| 3 | **GCI** | `gci` | Global Client Identifier | ❌ No |
| 4 | **Client ID** | `clientId` | Internal client identifier | ❌ No |
| 5 | **CoPer ID** | `coperId` | Corporate Person ID (optional) | ❌ No |
| 6 | **Case Status** | `status` | Current workflow status | ✅ Yes |
| 7 | **Created Date** | `createdDate` | Date the case was created | ✅ Yes |
| 8 | **Due Date** | `dueDate` | Target completion date | ✅ Yes |
| 9 | **Assignee** | `assignedTo` | Person assigned (always current user) | ❌ No |
| 10 | **LOB(s)** | `lineOfBusiness` | Line of Business | ✅ Yes |
| 11 | **Risk Rating** | `riskLevel` | Risk assessment level | ✅ Yes |

**Note**: The **312 Case (Y/N)** indicator is NOT included in the individual worklist columns (only in the combined workbasket).

---

## Filtering Logic

### Primary Filter: Assigned to Current User

**Core Logic**:
```typescript
const myAssignedCases = mockCases.filter(c => {
  // MUST be assigned to the current user
  if (c.assignedTo !== currentUser.name) return false;
  
  // Still apply entitlement filters
  if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
  if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
  if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
  
  return true;
});
```

### Included Cases

**All cases assigned to user, regardless of**:
- ✅ **Status** - Includes all statuses (In Progress, Pending Sales Review, Complete, etc.)
- ✅ **Stage** - All workflow stages included
- ✅ **Date** - Historical and current cases
- ✅ **LOB** - All Lines of Business
- ✅ **Completion** - Both open and completed cases

**Example Statuses Included**:
- In Progress
- Pending Sales Review
- In Sales Review
- Sales Review Complete
- Complete
- Defect Remediation
- Closed

---

## Quick Stats Dashboard

Four summary cards appear above the worklist:

### 1. Total Cases
- **Metric**: Total count of all assigned cases
- **Icon**: User icon
- **Description**: "Assigned to you"

### 2. In Progress
- **Metric**: Count of cases with status = "In Progress"
- **Icon**: Clock icon
- **Description**: "Currently working"

### 3. Past Due
- **Metric**: Count of cases where due date < today
- **Icon**: Red clock icon
- **Color**: Red text for count
- **Description**: "Requires attention"

### 4. Completed
- **Metric**: Count of cases with status = "Complete"
- **Icon**: Green clock icon
- **Color**: Green text for count
- **Description**: "Ready to close"

---

## Filtering Capabilities

### 1. Search Filter
- **Fields Searched**:
  - Case Number
  - Client Name
  - GCI
  - Client ID
  - CoPer ID
- **Type**: Text input with search icon
- **Behavior**: Real-time filtering

### 2. Status Filter
**Dropdown Options**:
- All Statuses
- In Progress
- Pending Sales Review
- In Sales Review
- Sales Review Complete
- Complete
- Defect Remediation

**Note**: "Unassigned" is not included since all cases in this view are assigned to the user.

### 3. Risk Level Filter
**Dropdown Options**:
- All Risk Levels
- Critical
- High
- Medium
- Low

### 4. LOB Filter
**Dropdown Options**:
- All LOBs
- GB/GM
- Private Bank
- Merrill Lynch
- Consumer
- CI

---

## Sorting Capabilities

### Sortable Columns (7 total)

| Column | Sort Logic |
|--------|-----------|
| Case Number | Alphanumeric |
| Client Name | Alphabetical |
| Case Status | Alphabetical |
| Created Date | Chronological (default: newest first) |
| Due Date | Chronological |
| LOB | Alphabetical |
| Risk Rating | Severity (Critical → High → Medium → Low) |

### Three-State Sorting
1. **First Click**: Ascending (↑)
2. **Second Click**: Descending (↓)
3. **Third Click**: Clear sort (return to default)

**Default Sort**: Created Date (Descending) - newest cases first

---

## Visual Indicators

### Past Due Cases
**Row Background**: Light red (`bg-red-50`)  
**Due Date Styling**:
- Red text color (`text-red-600`)
- Bold font weight
- Clock icon (🕒) prefix

### Assignee Display
Always shows current user's name with user icon:
```tsx
<div className="flex items-center gap-2">
  <User className="h-3 w-3 text-muted-foreground" />
  {caseItem.assignedTo}
</div>
```

### CoPer ID Handling
- If present: Display in monospace font, muted color
- If absent: Display "N/A" in gray text

---

## Empty States

### No Cases Assigned
```
No cases assigned to you

Cases will appear here when assigned by a manager 
or when you self-assign from the worklist.
```

### No Matching Filters
```
No cases match your filters
```

---

## User Experience Flows

### Flow 1: User Views Personal Workload

1. User clicks "My Cases" in sidebar
2. Individual worklist loads with all assigned cases
3. Quick stats show: Total (8), In Progress (5), Past Due (2), Complete (1)
4. User sees 8 cases in table
5. User can filter/sort to find specific cases

### Flow 2: User Filters to Past Due Cases

1. User on "My Cases" page
2. Past Due quick stat shows "2" in red
3. User clicks Status filter → selects specific status
4. OR sorts by Due Date ascending to see oldest first
5. Past due cases highlighted with red background

### Flow 3: User Works on Case from Personal List

1. User views "My Cases"
2. Clicks case number hyperlink "312-2025-001"
3. Case details page opens
4. User completes case work
5. Returns to "My Cases" (status now updated)

### Flow 4: Sales Owner Reviews Cases

1. Sales Owner logs in
2. Clicks "My Cases"
3. Sees only cases assigned to them (sales review cases)
4. Filters to "Pending Sales Review" or "In Sales Review"
5. Opens case to provide feedback

---

## Comparison: Individual Worklist vs. Combined Workbasket

| Feature | Individual Worklist | Combined Workbasket |
|---------|-------------------|---------------------|
| **Filter** | Only user's assigned cases | All accessible cases (any assignee) |
| **Purpose** | Personal workload management | Team-wide case management |
| **Columns** | 11 columns (no 312 indicator) | 12 columns (includes 312 Y/N) |
| **Quick Filters** | Search + 3 dropdowns | Search + 4 quick buttons + 4 dropdowns |
| **Bulk Actions** | None | Manager bulk assignment |
| **Self-Assignment** | Not applicable (already assigned) | Available for unassigned cases |
| **Stats Cards** | 4 cards (Total, In Progress, Past Due, Complete) | None |
| **Unassigned View** | Not available | Available via quick filter |

---

## Access Control

### Who Can Access Individual Worklist?

| Role | Can Access? | Cases Shown |
|------|------------|-------------|
| **Central Team Analyst** | ✅ Yes | Own assigned cases |
| **Central Team Manager** | ✅ Yes | Own assigned cases |
| **Sales Owner** | ✅ Yes | Own assigned cases (sales review) |
| **View Only** | ✅ Yes | Own assigned cases (if any) |

**Permission Required**: `permissions.viewWorklist = true`

---

## Data Visibility Rules

### Included Cases
```typescript
// User can see a case in Individual Worklist if:
1. Case is assigned to user.name
AND
2. User has entitlement for case type (312/CAM)
AND
3. If employee case, user has employee case access
```

### Excluded Cases
- ❌ Cases assigned to other users
- ❌ Unassigned cases
- ❌ Cases user lacks entitlements for
- ❌ Employee cases (without special access)

---

## Implementation Details

### Component
**File**: `/components/IndividualWorklist.tsx`

### Key State
```typescript
const [searchTerm, setSearchTerm] = useState('');
const [statusFilter, setStatusFilter] = useState<string>('all');
const [riskFilter, setRiskFilter] = useState<string>('all');
const [lobFilter, setLobFilter] = useState<string>('all');
const [sortField, setSortField] = useState<SortField>('createdDate');
const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
```

### Core Filter
```typescript
const myAssignedCases = mockCases.filter(c => {
  if (c.assignedTo !== currentUser.name) return false;
  if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
  if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
  if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
  return true;
});
```

### Quick Stats Calculation
```typescript
const statusCounts = useMemo(() => {
  const counts: Record<string, number> = {};
  myAssignedCases.forEach(c => {
    counts[c.status] = (counts[c.status] || 0) + 1;
  });
  return counts;
}, [myAssignedCases]);

const pastDueCount = myAssignedCases.filter(c => {
  const dueDate = new Date(c.dueDate);
  dueDate.setHours(0, 0, 0, 0);
  return dueDate < today;
}).length;
```

---

## Export Functionality

**Button**: "Export My Cases"  
**Location**: Top right of worklist  
**Format**: Excel (.xlsx)  
**Included Data**: All visible columns for filtered cases  
**Filename**: `My_Cases_{UserName}_{Date}.xlsx`

---

## Acceptance Criteria

### ✅ Filtering
- [x] Shows only cases assigned to logged-in user
- [x] Includes cases regardless of status
- [x] Includes cases regardless of stage
- [x] All LOBs included
- [x] Historical and current cases included

### ✅ Columns
- [x] Case Number (hyperlink)
- [x] Client Name
- [x] GCI
- [x] Client ID
- [x] CoPer ID (with N/A handling)
- [x] Case Status
- [x] Created Date
- [x] Due Date
- [x] Assignee (always current user)
- [x] LOB(s)
- [x] Risk Rating
- [x] 312 Case indicator NOT included

### ✅ Quick Stats
- [x] Total cases count
- [x] In Progress count
- [x] Past Due count (red)
- [x] Complete count (green)

### ✅ Filtering & Sorting
- [x] Search across identifiers
- [x] Status dropdown filter
- [x] Risk level dropdown filter
- [x] LOB dropdown filter
- [x] 7 sortable columns
- [x] Three-state sorting

### ✅ Visual Indicators
- [x] Past due rows with red background
- [x] Past due dates in red with clock icon
- [x] User icon next to assignee
- [x] N/A for missing CoPer IDs

### ✅ Empty States
- [x] No cases assigned message
- [x] No matching filters message

---

## Use Cases

### Analyst Daily Workflow
1. Start day on "My Cases" to see workload
2. Check Past Due count (top priority)
3. Sort by Due Date to see what's urgent
4. Work through In Progress cases
5. Track progress via Complete count

### Sales Owner Review Process
1. Navigate to "My Cases"
2. See only cases requiring sales feedback
3. Filter to "Pending Sales Review" status
4. Review each case and provide input
5. Return cases to analysts

### Manager Checking Personal Cases
1. Manager has dual role: assigns others' cases + works own cases
2. Uses "Case Worklist" for team management
3. Uses "My Cases" for personal assigned work
4. Can see status of cases they're personally working

### Analyst Looking for Specific Client
1. Opens "My Cases"
2. Searches for client name or GCI
3. Finds historical cases for context
4. Reviews previous case outcomes
5. Opens current case with full history

---

## Performance Considerations

### Filtering Performance
- Uses `useMemo` for filtered/sorted results
- Prevents recalculation on every render
- Efficient for 100+ assigned cases

### Stats Calculation
- Quick stats use `useMemo` with dependency on assigned cases
- Only recalculates when case list changes
- O(n) complexity for counts

### Sorting
- In-memory sorting for user's cases only
- Typical user has 5-20 cases (very fast)
- Supports 1000+ cases without performance impact

---

## Related Files

- `/components/IndividualWorklist.tsx` - Main component
- `/App.tsx` - Navigation integration
- `/types/index.ts` - Case interface
- `/data/enhancedMockData.ts` - Mock case data
- `/data/rolesEntitlementsMockData.ts` - User access data

---

## Future Enhancements

### Potential Additions
- [ ] **Quick Actions**: Complete, Route to Sales, etc. directly from worklist
- [ ] **Bulk Actions**: Mark multiple cases complete
- [ ] **Custom Views**: Save filter/sort preferences
- [ ] **Time Tracking**: Hours spent per case
- [ ] **Workload Metrics**: Cases per day, average completion time
- [ ] **Case Notes Preview**: Show latest note in table
- [ ] **Priority Reordering**: Drag-and-drop to set personal priority

---

**Document Version**: 1.0  
**Last Updated**: October 26, 2025  
**Status**: Implementation Complete
