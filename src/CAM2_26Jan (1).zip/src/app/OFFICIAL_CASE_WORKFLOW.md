# Official CAM 312 Case Review Workflow

## Overview
This document describes the official case workflow for 312 CAM case reviews based on the approved requirements.

---

## Case Flow Logic

### 1. Auto-Closed Cases

**Status**: Complete (Direct)  
**Model Outcome**: '312 Activity in line with expected activity'  
**Flag**: `autoClosed = true`

**Description**:
- System automatically determines case can be closed without manual review
- Case bypasses manual workflow entirely
- Placed directly into 'Complete' status
- Auto-close flag indicates no manual intervention occurred

**Example**:
```typescript
{
  id: '312-2025-AUTO-001',
  status: 'Complete',
  autoClosed: true,
  modelOutcome: '312 Activity in line with expected activity',
  completionDate: '2025-10-26'
}
```

---

### 2. Manual Review Cases (Not Auto-Closed)

#### Step 1: Unassigned (Workbasket)

**Status**: Unassigned  
**Description**: Case pending assignment or initiation  
**Actions**:
- **Central Team Manager**: Can assign case to specific analyst
- **Central Team Analyst**: Can select case directly from workbasket

**Example**:
```typescript
{
  id: '312-2025-001',
  status: 'Unassigned',
  assignedTo: null,
  autoClosed: false
}
```

---

#### Step 2: In Progress

**Status**: In Progress  
**Actor**: Central Team Analyst  
**Description**: Case actively being worked by analyst

**Analyst Can**:
1. **Self-Solve/Disposition**: Complete the case if central team can determine outcome
   - Action: Mark case complete
   - Next Status: **Complete**
   
2. **Route to Sales**: Send case to sales owner for additional context
   - Action: Route to sales owner
   - Next Status: **Pending Sales Review**

**Example Self-Solve**:
```typescript
// Analyst completes case
{
  status: 'In Progress' → 'Complete',
  autoClosed: false,
  derivedDisposition: 'No Action Required',
  modelOutcome: '312 Activity in line with expected activity',
  actor: 'Central Team Analyst'
}
```

**Example Route to Sales**:
```typescript
// Analyst routes to sales
{
  status: 'In Progress' → 'Pending Sales Review',
  assignedTo: 'David Park (Sales Owner)',
  actor: 'Central Team Analyst'
}
```

---

#### Step 3: Pending Sales Review

**Status**: Pending Sales Review  
**Actor**: Sales Owner (to open case)  
**Description**: Case routed to sales owner, awaiting sales owner to open

**Sales Owner Action**:
- Opens the case for review
- Next Status: **In Sales Review**

**Example**:
```typescript
{
  status: 'Pending Sales Review',
  assignedTo: 'David Park',
  salesOwner: 'David Park',
  // Sales owner will open case → In Sales Review
}
```

---

#### Step 4: In Sales Review

**Status**: In Sales Review  
**Actor**: Sales Owner  
**Description**: Sales owner actively reviewing case and providing input

**Sales Owner Actions**:
1. Review client relationship context
2. Add comments about transactions and client business
3. Provide feedback to analyst
4. Route case back to central team

**Next Status**: Sales Review Complete  
**Required**: Sales owner must provide comments

**Example**:
```typescript
{
  status: 'In Sales Review',
  assignedTo: 'David Park',
  salesReviewComments: 'Client transactions align with known business expansion...',
  // Sales owner completes review → Sales Review Complete
}
```

---

#### Step 5: Sales Review Complete

**Status**: Sales Review Complete  
**Actor**: Central Team Analyst (original analyst)  
**Description**: Sales feedback received, case returned to analyst's worklist

**Analyst Action**:
- Review sales owner's comments and feedback
- Make final disposition decision
- Submit case to mark as complete

**Next Status**: Complete

**Example**:
```typescript
{
  status: 'Sales Review Complete',
  assignedTo: 'Michael Chen', // Original analyst
  salesReviewComments: 'Sales context provided',
  // Analyst makes final disposition → Complete
}
```

---

#### Step 6: Complete

**Status**: Complete (Terminal)  
**Actor**: Central Team Analyst  
**Description**: Case dispositioned and submitted

**Data Captured**:
- **Flag**: `autoClosed = false` (indicates manual review)
- **Derived Disposition**: 
  - "312 Activity Escalated" (if TRMS filed or client closed)
  - "312 Activity in line with expected activity" (if no action required)
- **Model Outcome**: Final outcome determination
- **Completion Date**: Date case was completed

**Escalation Indicators**:
```typescript
// Case was escalated
{
  status: 'Complete',
  autoClosed: false,
  derivedDisposition: '312 Activity Escalated',
  modelOutcome: '312 Activity Escalated',
  escalationReason: 'TRMS Filed',
  completionDate: '2025-10-26'
}

// Case was not escalated
{
  status: 'Complete',
  autoClosed: false,
  derivedDisposition: 'No Action Required',
  modelOutcome: '312 Activity in line with expected activity',
  completionDate: '2025-10-26'
}
```

---

### 3. Defect Remediation (Post-Completion)

#### Step 7: Reopening for Remediation

**Status**: Complete → Defect Remediation  
**Actor**: Credentialed individuals (M&I entitlement)  
**Description**: Case reopened due to M&I or quality review findings

**Trigger**:
- M&I quality review identifies missing documentation or defects
- Credentialed individual (with M&I entitlement) reopens case

**Action**:
- Reopen case in edit mode
- Status changes to 'Defect Remediation'
- **Original completion date is maintained for reporting**

**Example**:
```typescript
{
  status: 'Complete' → 'Defect Remediation',
  defectRemediationFlag: true,
  originalCompletionDate: '2025-09-28', // PRESERVED
  remediationDate: '2025-10-15',
  actor: 'Michael Chen (M&I Entitled Analyst)'
}
```

---

#### Step 8: Remediation Complete

**Status**: Defect Remediation → Complete  
**Actor**: M&I Credentialed Analyst  
**Description**: Defects corrected, case re-submitted

**Important**:
- Original completion date is **maintained for reporting purposes**
- New completion date recorded for remediation tracking
- Case returns to 'Complete' status

**Example**:
```typescript
{
  status: 'Defect Remediation' → 'Complete',
  defectRemediationFlag: true,
  originalCompletionDate: '2025-09-28', // Used for SLA reporting
  completionDate: '2025-10-26', // Remediation completion
  remediationCycleTime: 18, // Days from reopen to re-complete
  actor: 'Jennifer Wu (M&I Entitled Analyst)'
}
```

---

## Complete Workflow Diagrams

### Workflow 1: Auto-Closed Case
```
┌──────────────────────┐
│   CASE CREATED       │
│                      │
│ Model Score: Low     │
│ Auto-Close Logic: ✓  │
└──────────────────────┘
          │
          │ System Auto-Closes
          ▼
┌──────────────────────┐
│     COMPLETE         │
│                      │
│ Auto-Closed: true    │
│ Model Outcome:       │
│ "312 Activity in     │
│  line with expected  │
│  activity"           │
└──────────────────────┘
```

---

### Workflow 2: Manual Review - Self-Solved
```
┌──────────────────────┐
│    UNASSIGNED        │
│   (Workbasket)       │
└──────────────────────┘
          │
          │ Manager Assigns OR
          │ Analyst Self-Selects
          ▼
┌──────────────────────┐
│    IN PROGRESS       │
│                      │
│ Actor: Analyst       │
└──────────────────────┘
          │
          │ Analyst Reviews
          │ Can Determine Outcome
          ▼
┌──────────────────────┐
│     COMPLETE         │
│                      │
│ Auto-Closed: false   │
│ Derived Disposition: │
│ Set by Analyst       │
└──────────────────────┘
```

---

### Workflow 3: Sales Review Flow
```
┌──────────────────────┐
│    UNASSIGNED        │
│   (Workbasket)       │
└──────────────────────┘
          │
          │ Analyst Self-Selects
          ▼
┌──────────────────────┐
│    IN PROGRESS       │
│                      │
│ Actor: Analyst       │
└──────────────────────┘
          │
          │ Analyst Routes
          │ to Sales Owner
          ▼
┌──────────────────────┐
│ PENDING SALES REVIEW │
│                      │
│ Assigned: Sales Owner│
└──────────────────────┘
          │
          │ Sales Owner Opens Case
          ▼
┌──────────────────────┐
│  IN SALES REVIEW     │
│                      │
│ Actor: Sales Owner   │
└──────────────────────┘
          │
          │ Sales Owner Provides
          │ Comments & Routes Back
          ▼
┌──────────────────────┐
│ SALES REVIEW         │
│   COMPLETE           │
│                      │
│ Assigned: Analyst    │
│ (Original)           │
└──────────────────────┘
          │
          │ Analyst Reviews
          │ Sales Feedback &
          │ Dispositions
          ▼
┌──────────────────────┐
│     COMPLETE         │
│                      │
│ Auto-Closed: false   │
│ Derived Disposition: │
│ Set by Analyst       │
└──────────────────────┘
```

---

### Workflow 4: Defect Remediation
```
┌──────────────────────┐
│     COMPLETE         │
│                      │
│ Completion Date:     │
│ 2025-09-28           │
└──────────────────────┘
          │
          │ M&I Quality Review
          │ Identifies Defect
          ▼
┌──────────────────────┐
│ DEFECT REMEDIATION   │
│                      │
│ Actor: M&I Analyst   │
│ Original Date:       │
│ 2025-09-28           │
│ (PRESERVED)          │
└──────────────────────┘
          │
          │ M&I Analyst
          │ Corrects Defects
          ▼
┌──────────────────────┐
│     COMPLETE         │
│                      │
│ Original Date:       │
│ 2025-09-28 ← For SLA │
│ Remediation Date:    │
│ 2025-10-26           │
└──────────────────────┘
```

---

## Status Transition Matrix

| From Status | To Status | Actor | Requirements |
|------------|-----------|-------|--------------|
| System | Unassigned | System | Case creation (not auto-closed) |
| System | Complete | System | Auto-close logic met |
| Unassigned | In Progress | Central Team Manager | Assignment to analyst |
| Unassigned | In Progress | Central Team Analyst | Self-select from workbasket |
| In Progress | Complete | Central Team Analyst | Self-solve disposition |
| In Progress | Pending Sales Review | Central Team Analyst | Route to sales owner |
| Pending Sales Review | In Sales Review | Sales Owner | Open case for review |
| In Sales Review | Sales Review Complete | Sales Owner | Provide comments |
| Sales Review Complete | Complete | Central Team Analyst | Final disposition |
| Complete | Defect Remediation | M&I Credentialed User | Quality review finding |
| Defect Remediation | Complete | M&I Credentialed User | Remediation complete |

---

## Actor Roles and Permissions

### Central Team Manager
**Can**:
- View all cases
- Assign cases from Unassigned workbasket to analysts
- View completed cases

**Cannot**:
- Disposition cases (analysts do this)
- Work cases directly (assigns to analysts)
- Reopen cases for remediation (requires M&I entitlement)

---

### Central Team Analyst
**Can**:
- Self-select cases from Unassigned workbasket
- Work In Progress cases
- Self-solve/disposition cases → Complete
- Route cases to Sales Owner → Pending Sales Review
- Disposition cases after Sales Review Complete → Complete

**Cannot**:
- Reopen completed cases (requires M&I entitlement)

---

### Central Team Analyst with M&I Entitlement
**All Central Team Analyst permissions PLUS**:
- Reopen Complete cases → Defect Remediation
- Work Defect Remediation cases
- Re-complete remediation cases → Complete

**M&I Entitled Users** (from mock data):
- Michael Chen (`hasM_I_Entitlement: true`)
- Jennifer Wu (`hasM_I_Entitlement: true`)

---

### Sales Owner
**Can**:
- Open cases in Pending Sales Review → In Sales Review
- Add comments to cases In Sales Review
- Complete sales review → Sales Review Complete

**Cannot**:
- Self-select cases from workbasket
- Disposition cases
- Complete cases (only provide feedback)

---

### View Only
**Can**:
- View all cases and data

**Cannot**:
- Modify any cases
- Change case status
- Add comments

---

## Data Fields

### Auto-Closed Cases
```typescript
{
  autoClosed: true,
  modelOutcome: '312 Activity in line with expected activity',
  status: 'Complete',
  completionDate: string,
  // No derivedDisposition (not manually reviewed)
}
```

### Manual Cases
```typescript
{
  autoClosed: false,
  derivedDisposition: '312 Activity Escalated' | '312 Activity in line with expected activity',
  modelOutcome: string,
  status: CaseStatus,
  // Derived disposition indicates escalation
  // '312 Activity Escalated' if TRMS filed or client closed
}
```

### Remediation Cases
```typescript
{
  defectRemediationFlag: true,
  originalCompletionDate: string, // PRESERVED for SLA reporting
  completionDate: string, // Latest completion (remediation)
  remediationDate: string, // When reopened
  status: 'Complete',
}
```

---

## Mock Data Examples

### Example 1: Auto-Closed Case
```typescript
{
  id: '312-2025-AUTO-001',
  clientName: 'Standard Manufacturing Inc',
  status: 'Complete',
  autoClosed: true,
  modelOutcome: '312 Activity in line with expected activity',
  completionDate: '2025-10-26',
  model312Score: 3.2, // Low risk score
}
```

---

### Example 2: Unassigned Case
```typescript
{
  id: '312-2025-UNASSIGN-001',
  clientName: 'GlobalTech Industries',
  status: 'Unassigned',
  assignedTo: null,
  autoClosed: false,
  createdDate: '2025-10-26',
  // Waiting for manager to assign OR analyst to self-select
}
```

---

### Example 3: In Progress - Self-Solved
```typescript
{
  id: '312-2025-001',
  clientName: 'Acme Corporation',
  status: 'In Progress',
  assignedTo: 'Michael Chen',
  autoClosed: false,
  // Analyst will disposition → Complete
}
```

---

### Example 4: Pending Sales Review
```typescript
{
  id: '312-2025-SALES-001',
  clientName: 'Meridian Capital Holdings',
  status: 'Pending Sales Review',
  assignedTo: 'David Park', // Sales Owner
  autoClosed: false,
  routedBy: 'Michael Chen', // Analyst who routed
  // Waiting for David Park (sales owner) to open case
}
```

---

### Example 5: In Sales Review
```typescript
{
  id: '312-2025-SALES-002',
  clientName: 'Pinnacle Investment Group',
  status: 'In Sales Review',
  assignedTo: 'David Park', // Sales Owner
  autoClosed: false,
  salesReviewComments: 'Reviewing client relationship context...',
  // Sales owner will complete review → Sales Review Complete
}
```

---

### Example 6: Sales Review Complete
```typescript
{
  id: '312-2025-SALES-003',
  clientName: 'Apex Strategic Partners',
  status: 'Sales Review Complete',
  assignedTo: 'Michael Chen', // Original analyst
  autoClosed: false,
  salesReviewComments: 'Transactions align with client business expansion into Asian markets...',
  // Analyst will review feedback and disposition → Complete
}
```

---

### Example 7: Complete - Not Escalated
```typescript
{
  id: '312-2025-COMP-001',
  clientName: 'Summit Enterprises',
  status: 'Complete',
  assignedTo: 'Lisa Brown',
  autoClosed: false,
  derivedDisposition: 'No Action Required',
  modelOutcome: '312 Activity in line with expected activity',
  completionDate: '2025-10-24',
}
```

---

### Example 8: Complete - Escalated
```typescript
{
  id: '312-2025-ESC-001',
  clientName: 'Questionable Trading Corp',
  status: 'Complete',
  assignedTo: 'Sarah Mitchell',
  autoClosed: false,
  derivedDisposition: 'Client Closed',
  modelOutcome: '312 Activity Escalated',
  escalationReason: 'Client relationship terminated due to unacceptable risk',
  completionDate: '2025-10-21',
}
```

---

### Example 9: Defect Remediation
```typescript
{
  id: '312-2025-REM-001',
  clientName: 'Global Enterprise Solutions',
  status: 'Defect Remediation',
  assignedTo: 'Jennifer Wu', // M&I entitled analyst
  autoClosed: false,
  defectRemediationFlag: true,
  originalCompletionDate: '2025-09-28', // PRESERVED
  remediationDate: '2025-10-15', // When reopened
  remediationReason: 'Missing transaction documentation identified in M&I quality review',
}
```

---

## Activity Log Examples

### Auto-Close Flow
```
2025-10-26 08:00 - Case created (System)
2025-10-26 08:00 - Auto-close logic triggered (System)
2025-10-26 08:00 - Status → Complete (System)
2025-10-26 08:00 - Model outcome: 312 Activity in line with expected activity
```

---

### Manual Review Flow (Self-Solved)
```
2025-10-26 09:00 - Case created → Unassigned (System)
2025-10-26 09:15 - Self-selected from workbasket (Michael Chen - Analyst)
2025-10-26 09:15 - Status → In Progress (Michael Chen)
2025-10-26 10:00 - Reviewed client data (Michael Chen)
2025-10-26 14:30 - Reviewed ORRCA rating (Michael Chen)
2025-10-27 11:00 - Disposition: No Action Required (Michael Chen)
2025-10-27 11:05 - Status → Complete (Michael Chen - Analyst)
```

---

### Sales Review Flow
```
2025-10-20 08:00 - Case created → Unassigned (System)
2025-10-20 08:30 - Self-selected from workbasket (Jennifer Wu - Analyst)
2025-10-20 08:30 - Status → In Progress (Jennifer Wu)
2025-10-22 14:00 - Routed to sales owner (Jennifer Wu - Analyst)
2025-10-22 14:00 - Status → Pending Sales Review (Jennifer Wu)
2025-10-22 14:00 - Assigned to David Park (Sales Owner)
2025-10-26 09:00 - Sales owner opened case (David Park - Sales Owner)
2025-10-26 09:00 - Status → In Sales Review (David Park)
2025-10-26 15:00 - Sales feedback provided (David Park - Sales Owner)
2025-10-26 15:00 - Status → Sales Review Complete (David Park)
2025-10-26 15:00 - Returned to Jennifer Wu's worklist
2025-10-27 10:00 - Reviewed sales feedback (Jennifer Wu - Analyst)
2025-10-27 10:30 - Final disposition: No Action Required (Jennifer Wu)
2025-10-27 10:30 - Status → Complete (Jennifer Wu - Analyst)
```

---

### Defect Remediation Flow
```
2025-09-28 14:35 - Case completed (Jennifer Wu - Analyst)
2025-10-15 10:00 - M&I quality review conducted (Michael Chen - M&I Analyst)
2025-10-15 10:00 - Missing documentation identified
2025-10-15 10:30 - Case reopened for remediation (Michael Chen - M&I Analyst)
2025-10-15 10:30 - Status → Defect Remediation (Michael Chen)
2025-10-15 10:30 - Original completion date preserved: 2025-09-28
2025-10-15 10:35 - Reassigned to Jennifer Wu (M&I Analyst)
2025-10-26 14:00 - Additional documentation added (Jennifer Wu)
2025-10-26 15:00 - Remediation complete (Jennifer Wu - M&I Analyst)
2025-10-26 15:00 - Status → Complete (Jennifer Wu)
2025-10-26 15:00 - Original date: 2025-09-28, Remediation date: 2025-10-26
```

---

## Validation Rules

### Rule 1: Auto-Close Validation
```typescript
if (autoClosed === true) {
  // Must have specific model outcome
  assert(modelOutcome === '312 Activity in line with expected activity');
  // Must be in Complete status
  assert(status === 'Complete');
  // Cannot have derived disposition (not manually reviewed)
  assert(derivedDisposition === undefined);
}
```

---

### Rule 2: Manual Case Completion
```typescript
if (autoClosed === false && status === 'Complete') {
  // Must have derived disposition
  assert(derivedDisposition !== undefined);
  // Must have model outcome
  assert(modelOutcome !== undefined);
  // Must have completion date
  assert(completionDate !== undefined);
}
```

---

### Rule 3: Sales Review Requirements
```typescript
if (status === 'Sales Review Complete') {
  // Must have sales comments
  assert(salesReviewComments !== undefined && salesReviewComments.length > 0);
  // Must be assigned back to original analyst
  assert(assignedTo === originalAnalyst);
}
```

---

### Rule 4: Defect Remediation
```typescript
if (defectRemediationFlag === true) {
  // Must preserve original completion date
  assert(originalCompletionDate !== undefined);
  // Original date must be before remediation date
  assert(new Date(originalCompletionDate) < new Date(remediationDate));
  // Must be worked by M&I credentialed user
  assert(user.hasM_I_Entitlement === true);
}
```

---

### Rule 5: Escalation Indicators
```typescript
if (derivedDisposition === '312 Activity Escalated') {
  // Must indicate why escalated
  assert(
    escalationReason === 'TRMS Filed' || 
    escalationReason === 'Client Closed' ||
    // other valid escalation reasons
  );
  // Model outcome should match
  assert(modelOutcome === '312 Activity Escalated');
}
```

---

## Reporting Considerations

### SLA Metrics
For **Defect Remediation cases**, use the **original completion date** for SLA reporting:
```typescript
// CORRECT
const slaDate = case.defectRemediationFlag 
  ? case.originalCompletionDate  // Use this
  : case.completionDate;

// INCORRECT
const slaDate = case.completionDate; // Don't use remediation date for SLA
```

### Case Completion Metrics
```typescript
// Total completed cases
const totalCompleted = cases.filter(c => c.status === 'Complete').length;

// Auto-closed cases
const autoClosed = cases.filter(c => c.autoClosed === true).length;

// Manually reviewed cases
const manualReview = cases.filter(c => c.autoClosed === false && c.status === 'Complete').length;

// Escalated cases
const escalated = cases.filter(c => c.derivedDisposition === '312 Activity Escalated').length;

// Remediation cases
const remediated = cases.filter(c => c.defectRemediationFlag === true).length;

// Auto-close rate
const autoCloseRate = (autoClosed / totalCompleted) * 100;

// Escalation rate (of manual reviews)
const escalationRate = (escalated / manualReview) * 100;

// Remediation rate
const remediationRate = (remediated / totalCompleted) * 100;
```

---

## Summary

### Key Workflow Points
1. ✅ **Auto-closed cases** go directly to Complete with specific model outcome
2. ✅ **Manual cases** start Unassigned, move to In Progress, then either Complete or route to sales
3. ✅ **Sales review** requires sales owner to **open the case** (Pending → In Sales Review)
4. ✅ **Sales owner** provides feedback and routes back to analyst
5. ✅ **Analyst** makes final disposition after sales review
6. ✅ **M&I credentialed users** can reopen Complete cases for remediation
7. ✅ **Original completion date** is preserved during remediation for reporting

### Actor Summary
- **Central Team Manager**: Assigns cases
- **Central Team Analyst**: Works cases, dispositions, routes to sales
- **Sales Owner**: Opens cases in pending sales review, provides feedback
- **M&I Credentialed Analyst**: Can reopen and work remediation cases
- **View Only**: Read-only access

---

## Related Files
- `/data/caseFlowValidation.ts` - Status transition validation logic
- `/data/caseFlowScenarios.ts` - Mock case scenarios covering all workflows
- `/data/caseFlowActivities.ts` - Activity logs for each workflow
- `/data/enhancedMockData.ts` - Mock users with M&I entitlements
- `/types/index.ts` - TypeScript definitions including `hasM_I_Entitlement`
