# Roles & Entitlements Implementation

## Overview
The CAM Platform now features a comprehensive role-based access control (RBAC) system with dynamic user switching and permission-based UI filtering.

## User Switcher Location
- **Position**: Top right corner of the platform header
- **Features**: 
  - Dropdown selector showing all active users
  - Displays user avatar, name, and role
  - Instant context switching without page reload
  - Persists across all pages

## Role Types

### 1. Central Team Analyst
**Description**: Access to case dashboard and individual worklist. Ability to open cases, review all data and action cases.

**Permissions**:
- ✅ View Dashboard
- ✅ View Worklist
- ✅ Open Cases
- ✅ Review Data
- ✅ **Action Cases** (can edit and submit case sections 3 & 4)
- ❌ Assign/Reassign Cases
- ❌ Reopen Cases
- ❌ Abandon Cases
- ❌ Sales Feedback
- ❌ Return to Analyst

**Example Users**:
- Michael Chen (312 & CAM, GB/GM, PB)
- Jennifer Wu (312 & CAM, ML, Consumer, CI)
- Lisa Brown (CAM Only, Consumer, CI)
- Kevin Rogers (312 & CAM, ML, Consumer, Employee Cases)

### 2. Central Team Manager
**Description**: Access to case dashboard and individual worklist. Ability to open cases, review all data and action cases. Ability to assign/reassign cases to other analysts. Ability to reopen completed cases to make necessary remediation based on quality findings. Abandon cases.

**Permissions**:
- ✅ View Dashboard
- ✅ View Worklist
- ✅ Open Cases
- ✅ Review Data
- ✅ **Action Cases** (can edit and submit case sections 3 & 4)
- ✅ Assign/Reassign Cases
- ✅ Reopen Cases (Quality)
- ✅ Abandon Cases
- ❌ Sales Feedback
- ❌ Return to Analyst

**Example Users**:
- Sarah Mitchell (312 & CAM, GB/GM, PB, ML, Employee Cases, Manual Creation)
- Carlos Rivera (312 Only, PB, Employee Cases, Manual Creation)

### 3. View Only
**Description**: Ability to review cases, both closed and open, but no ability to action a case in any way.

**Permissions**:
- ✅ View Dashboard
- ✅ View Worklist
- ✅ Open Cases
- ✅ Review Data
- ❌ **Action Cases** (cannot edit case sections - read-only)
- ❌ Assign/Reassign Cases
- ❌ Reopen Cases
- ❌ Abandon Cases
- ❌ Sales Feedback
- ❌ Return to Analyst

**Example Users**:
- Robert Anderson (312 & CAM, All LOBs - Compliance Oversight)

### 4. Sales Owner
**Description**: Ability to review cases that have been sent to sales for feedback. Ability to send case back to the central team analyst to complete the disposition.

**Permissions**:
- ❌ View Dashboard (Restricted to worklist only)
- ✅ View Worklist
- ✅ Open Cases
- ✅ Review Data
- ❌ **Action Cases** (cannot edit case sections 3 & 4 - read-only)
- ❌ Assign/Reassign Cases
- ❌ Reopen Cases
- ❌ Abandon Cases
- ✅ Sales Feedback (can edit Section 5)
- ✅ Return to Analyst

**Example Users**:
- David Park (312, GB/GM only)
- Amanda Torres (312, ML only)

## Entitlements

### Case Type Access
- **312 Access**: View and work 312 population cases
- **CAM Access**: View and work general CAM cases

### LOB Access
Users can access cases only from their assigned Lines of Business:
- **GB/GM** (Global Banking/Global Markets)
- **PB** (Private Banking)
- **ML** (Merrill Lynch)
- **Consumer**
- **CI** (Consumer Investments)

**Rules**:
- Central Team: Can have multiple LOBs
- Sales Owners: Limited to ONE LOB for accountability

### Special Entitlements
- **Employee Cases**: Limited access to employee/affiliate cases
- **Manual Case Creation**: Ability to create ad-hoc cases

## Dynamic Filtering by Role

### Dashboard
- Shows only cases the user has access to based on:
  - Case type (312/CAM) access
  - LOB assignment
  - Employee case permissions
  - Sales Owner sees only their assigned cases
- Metrics update dynamically based on visible cases
- Subtitle shows user's entitlements

### Case Worklist
- Filters cases by user's entitlements before applying search/filters
- Sales Owners only see cases assigned to them
- Employee cases hidden unless user has permission

### Case Details - Enhanced Case UI (Sections 1-5)
- **Section 1 (Case Banner)**: Always visible to all roles
- **Section 2 (Case & Client Details)**: Always read-only for all roles
- **Section 3 (312 Case)**:
  - ✅ **Editable** for Analysts & Managers (actionCases = true)
  - ❌ **Read-Only** for View Only & Sales Owners (actionCases = false)
  - Shows amber warning banner: "View Only - You do not have permission to action this case"
  - All fields disabled when user lacks actionCases permission
  - Action buttons (Save/Submit) hidden when user lacks permission
- **Section 4 (CAM Case)**:
  - ✅ **Editable** for Analysts & Managers (actionCases = true)
  - ❌ **Read-Only** for View Only & Sales Owners (actionCases = false)
  - Shows amber warning banner when user lacks permission
  - All fields disabled when user lacks actionCases permission
  - Action buttons hidden when user lacks permission
- **Section 5 (Sales Owner Review)**:
  - ✅ **Editable** for Sales Owners only
  - ❌ **Read-Only** for AML Analysts & Managers
  - Privacy-filtered data shown to Sales Owners

### Classic Case Details (Old UI)
- Notes/Comments: Requires `actionCases`
- Status Update: Requires `actionCases`
- Reassign: Requires `reassignCases`
- Abandon: Requires `abandonCases` (Manager only)
- Return to Analyst: Sales Owner only
- Visual indicators (lock icons) show restricted actions

### Navigation Menu
- Menu items filtered by role permissions
- Administration section only visible to Managers
- Dashboard hidden for Sales Owners

## ARM (Access Request Management) Workflow

### Request Process
1. User submits access request via ARM
2. Manager reviews request
3. Manager approves/denies based on business need
4. System grants entitlements

### Tracking
- Request Date
- Approval Date
- Approving Manager
- Status (Active/Pending/Revoked)

## User Experience Features

### Visual Indicators
- Color-coded role badges
- Lock icons on disabled features
- Permission warnings in case details
- Entitlement badges in user selector

### Context Awareness
- Page resets to dashboard when switching users
- Permissions checked in real-time
- No access to features outside role scope

### Transparency
- Dashboard shows current user's access scope
- Clear messaging when features are restricted
- Roles & Entitlements page for full visibility

## Testing Different Roles - Enhanced Case UI

### Test Scenario 1: Analyst (Can Edit)
**User**: Switch to **Michael Chen** (Central Team Analyst)

**Steps**:
1. Go to "My Cases"
2. Click "View Details" on case `312-2025-001`
3. ✅ **Section 3 (312 Case)** should be fully editable
   - All radio buttons, dropdowns, inputs enabled
   - Save and Submit buttons visible
4. ✅ **Section 4 (CAM Case)** should be fully editable
   - All checkboxes, dropdowns, textareas enabled
   - Save and Submit buttons visible
5. ❌ **Section 5 (Sales Review)** should be read-only
   - Shows blue info banner for AML users

### Test Scenario 2: Manager (Can Edit)
**User**: Switch to **Sarah Mitchell** (Central Team Manager)

**Steps**:
1. Go to "My Cases"
2. Open any case
3. ✅ **Sections 3 & 4** fully editable (same as Analyst)
4. ✅ **Additional permissions**: Can reassign, abandon, reopen cases
5. ❌ **Section 5** read-only

### Test Scenario 3: View Only (Cannot Edit)
**User**: Switch to **Robert Anderson** (View Only)

**Steps**:
1. Go to "My Cases"
2. Open case `312-2025-001`
3. ❌ **Section 3 (312 Case)** should be READ-ONLY
   - Amber warning banner: "View Only - You do not have permission to action this case"
   - All radio buttons, dropdowns, inputs **disabled**
   - Save and Submit buttons **hidden**
4. ❌ **Section 4 (CAM Case)** should be READ-ONLY
   - Amber warning banner shown
   - All fields disabled
   - Action buttons hidden
5. ❌ **Section 5** read-only (AML view)

### Test Scenario 4: Sales Owner (Cannot Edit Sections 3 & 4)
**User**: Switch to **David Park** (Sales Owner)

**Steps**:
1. Go to "My Cases" (Sales Owner Worklist)
2. Find a case that was sent to sales
3. Open the case
4. ❌ **Section 3 (312 Case)** should be READ-ONLY
   - Amber warning banner shown
   - All fields disabled
   - No action buttons
5. ❌ **Section 4 (CAM Case)** should be READ-ONLY
   - All fields disabled
   - No action buttons
6. ✅ **Section 5 (Sales Review)** should be EDITABLE
   - Can enter comments
   - Can save draft and submit response

## Quick Test Checklist

Switch between these users to see different experiences:

1. ✅ **Sarah Mitchell (Manager)**: Full access to Sections 3 & 4, all features enabled
2. ✅ **Michael Chen (Analyst)**: Full access to Sections 3 & 4, cannot assign/reassign
3. ❌ **Robert Anderson (View Only)**: Can see everything, **cannot edit anything** (amber warning)
4. ❌ **David Park (Sales Owner)**: Only Section 5 editable, Sections 3 & 4 **read-only**
5. ✅ **Lisa Brown (Analyst)**: CAM only, Consumer/CI LOBs, can edit CAM cases

## Implementation Details

### Key Files
- `/data/rolesEntitlementsMockData.ts`: Role definitions, entitlements, users
- `/App.tsx`: User switcher, permission-based navigation
- `/components/Dashboard.tsx`: User-filtered metrics
- `/components/CaseWorklist.tsx`: Entitlement-based case filtering
- `/components/CaseDetails.tsx`: Permission-based action controls
- `/components/RolesEntitlements.tsx`: Full RBAC management interface

### Permission Helper
```typescript
getPermissionsForRole(role: RoleDefinition['type']): RoleDefinition['permissions']
```
Returns complete permission set for any role type.

## Security Considerations

- All filtering happens client-side (would be server-side in production)
- Permission checks at multiple levels
- No data exposure to unauthorized users
- Clear audit trail via ARM workflow
