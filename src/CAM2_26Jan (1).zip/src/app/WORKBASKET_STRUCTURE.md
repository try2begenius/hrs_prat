# CAM Workbasket Structure

## Overview

The Combined CAM Workbasket is the central interface for managing all CAM 312 and CAM-only cases. It provides a comprehensive view with filtering, sorting, and direct case access capabilities.

---

## Workbasket Data Columns

The workbasket displays the following columns for each case:

### Required Columns

| Column | Field | Description | Type | Example |
|--------|-------|-------------|------|---------|
| **Case Number** | `id` | Unique case identifier (clickable hyperlink to case details) | String | `312-2025-001` |
| **Client Name** | `clientName` | Legal or business name of the client | String | `GlobalTech Industries Corp` |
| **GCI** | `gci` | Global Client Identifier | String | `GCI-892341` |
| **Client ID** | `clientId` | Internal client identifier | String | `CLI-892341` |
| **CoPer ID** | `coperId` | Corporate Person ID (optional - not all clients have this) | String? | `CPR-89234` or `N/A` |
| **Case Status** | `status` | Current workflow status of the case | Enum | `In Progress`, `Complete` |
| **Created Date** | `createdDate` | Date the case was created | Date | `2025-10-26` |
| **Due Date** | `dueDate` | Target completion date | Date | `2025-11-26` |
| **Assignee** | `assignedTo` | Person currently assigned to the case | String | `Michael Chen`, `Unassigned` |
| **LOB(s)** | `lineOfBusiness` | Line of Business | Enum | `GB/GM`, `PB`, `ML`, `Consumer`, `CI` |
| **Risk Rating** | `riskLevel` | Risk assessment level | Enum | `Low`, `Medium`, `High`, `Critical` |
| **312 Case** | `is312Case` | Indicator if case is 312 combination or CAM only | Boolean | `Yes` / `No` |

---

## Data Field Details

### Case Number (`id`)
- **Format**: `{Type}-{Year}-{Identifier}`
- **Examples**: 
  - `312-2025-001` (312 Review case)
  - `312-2025-AUTO-001` (Auto-closed 312 case)
  - `312-2025-SALES-001` (Sales review case)
- **Functionality**: **Clickable hyperlink** that opens the case details page
- **Styling**: Primary blue color with underline on hover

---

### Client Identifiers

#### Client Name
- **Source**: `clientData.legalName` or `clientData.businessName`
- **Display**: Full legal entity name
- **Examples**:
  - `Standard Manufacturing Inc`
  - `Pacific Trade Ventures Ltd`
  - `GlobalTech Industries Corp`

#### GCI (Global Client Identifier)
- **Format**: `GCI-{Number}`
- **Example**: `GCI-892341`
- **Display**: Monospace font
- **Purpose**: Primary client identifier across all systems

#### Client ID
- **Format**: `CLI-{Number}`
- **Example**: `CLI-892341`
- **Display**: Monospace font, muted color
- **Purpose**: Internal system client identifier

#### CoPer ID (Corporate Person ID)
- **Format**: `CPR-{Number}`
- **Example**: `CPR-89234`
- **Optional**: ✅ Yes - Not all clients have a CoPer ID
- **Display**: 
  - If present: Monospace font, muted color
  - If absent: `N/A` in gray text
- **Note**: Consumer and individual clients typically do not have CoPer IDs

---

### Case Status

**Possible Values**:
- `Unassigned` - Pending assignment from workbasket
- `In Progress` - Analyst actively working
- `Pending Sales Review` - Routed to sales owner
- `In Sales Review` - Sales owner reviewing
- `Sales Review Complete` - Returned to analyst
- `Complete` - Case closed
- `Defect Remediation` - Reopened for correction

**Display**: Colored badge with status-specific colors
- Unassigned: Gray
- In Progress: Amber/Yellow
- Pending Sales Review: Blue
- In Sales Review: Purple
- Sales Review Complete: Indigo
- Complete: Green
- Defect Remediation: Red

---

### Dates

#### Created Date
- **Format**: `YYYY-MM-DD`
- **Example**: `2025-10-26`
- **Source**: `createdDate` field
- **Sortable**: ✅ Yes

#### Due Date
- **Format**: `YYYY-MM-DD`
- **Example**: `2025-11-26`
- **Source**: `dueDate` field
- **Sortable**: ✅ Yes
- **Business Logic**: Typically 30 days from creation for standard cases

---

### Assignee
- **Values**: 
  - Analyst name (e.g., `Michael Chen`, `Sarah Mitchell`)
  - `Unassigned` for cases in workbasket
  - `System` for auto-closed cases
- **Display**: Plain text
- **Sortable**: ✅ Yes

---

### LOB (Line of Business)

**Possible Values**:
| Code | Full Name | Description |
|------|-----------|-------------|
| **GB/GM** | Global Banking / Global Markets | Corporate and institutional banking |
| **PB** | Private Bank | High net worth individuals and families |
| **ML** | Merrill Lynch | Wealth management clients |
| **Consumer** | Consumer Banking | Retail banking clients |
| **CI** | Corporate & Institutional | Large corporate clients |

**Display**: Badge with building icon
- Blue background badge
- LOB code displayed
- Sortable: ✅ Yes

**Sales Review Availability**:
- ✅ **Available**: GB/GM, PB, ML
- ❌ **NOT Available**: Consumer, CI

---

### Risk Rating

**Possible Values** (in order of severity):
1. **Critical** - Highest risk, immediate attention required
2. **High** - Elevated risk, priority handling
3. **Medium** - Moderate risk, standard monitoring
4. **Low** - Minimal risk, routine review

**Display**: Colored badge
- Critical: Red background, white text
- High: Light red background, red text
- Medium: Amber background, amber text
- Low: Green background, green text

**Sortable**: ✅ Yes (sorts by severity: Critical → High → Medium → Low)

---

### 312 Case (Indicator)

**Values**:
- `Yes` - Case is a 312 combination case (includes 312 review)
- `No` - CAM-only case (no 312 review component)

**Display**: Badge
- Yes: Primary blue badge with white text
- No: Outline badge with gray text

**Purpose**: Quickly identify which cases include 312 regulatory review requirements

**Filter**: Can filter workbasket to show only 312 cases or only CAM cases

---

## Filtering Capabilities

All columns support filtering through dedicated filter controls:

### 1. Search Filter
- **Fields Searched**:
  - Case Number
  - Client Name
  - GCI
  - Client ID
  - CoPer ID
- **Type**: Text input with search icon
- **Behavior**: Real-time filtering as you type
- **Case Sensitive**: No

### 2. Status Filter
- **Type**: Dropdown select
- **Options**: All Statuses, Unassigned, In Progress, Pending Sales Review, In Sales Review, Sales Review Complete, Complete, Defect Remediation
- **Default**: All Statuses

### 3. Risk Level Filter
- **Type**: Dropdown select
- **Options**: All Risk Levels, Critical, High, Medium, Low
- **Default**: All Risk Levels

### 4. LOB Filter
- **Type**: Dropdown select
- **Options**: All LOBs, GB/GM, PB, ML, Consumer, CI
- **Default**: All LOBs

### 5. 312 Case Filter
- **Type**: Dropdown select
- **Options**: All Cases, 312 Cases Only, CAM Only
- **Default**: All Cases

**Filter Behavior**:
- Multiple filters can be applied simultaneously
- Filters are AND-based (all conditions must match)
- Filter count updates in real-time
- Results summary shows: "Showing X of Y cases"

---

## Sorting Capabilities

All major columns support sorting with visual indicators:

### Sortable Columns

| Column | Sort Field | Sort Logic |
|--------|-----------|------------|
| Case Number | `id` | Alphanumeric |
| Client Name | `clientName` | Alphabetical |
| Case Status | `status` | Alphabetical |
| Created Date | `createdDate` | Chronological |
| Due Date | `dueDate` | Chronological |
| Assignee | `assignedTo` | Alphabetical |
| LOB | `lineOfBusiness` | Alphabetical |
| Risk Rating | `riskLevel` | Severity (Critical → Low) |

### Sort Behavior

**Three-State Sorting**:
1. **First Click**: Sort ascending (↑)
2. **Second Click**: Sort descending (↓)
3. **Third Click**: Clear sort (return to default)

**Visual Indicators**:
- Sortable column headers show sort icon (⇅)
- Active sort shows directional arrow (↑ or ↓)
- Sort field and direction shown in results summary

**Default Sort**: Created Date (Descending) - newest cases first

---

## Case Number Hyperlink

### Functionality
- **Click Target**: Entire case number cell is clickable
- **Action**: Opens case details page
- **Navigation**: In-app navigation (no page reload)
- **Visual Feedback**:
  - Primary blue color
  - Underline on hover
  - Pointer cursor

### Implementation
```tsx
<button 
  onClick={() => onViewCase(caseItem.id)}
  className="font-mono text-sm font-medium text-primary hover:underline"
>
  {caseItem.id}
</button>
```

---

## Acceptance Criteria

### ✅ Data Attributes
- [x] Case Number
- [x] Client Name
- [x] GCI
- [x] Client ID
- [x] CoPer ID (with N/A for clients without)
- [x] Case Status
- [x] Created Date
- [x] Due Date
- [x] Assignee
- [x] LOB(s)
- [x] Risk Rating
- [x] 312 Case (Y/N) indicator

### ✅ Filtering
- [x] All columns are filterable
- [x] Search across multiple identifier fields
- [x] Dropdown filters for categorical data
- [x] Real-time filter updates
- [x] Multi-filter support (AND logic)

### ✅ Sorting
- [x] All major columns are sortable
- [x] Three-state sort (Asc/Desc/Clear)
- [x] Visual sort indicators
- [x] Default sort (Created Date descending)

### ✅ Navigation
- [x] Case Number acts as hyperlink
- [x] Clicking opens case details page
- [x] Hover effects on clickable elements

### ✅ Data Handling
- [x] CoPer ID shows "N/A" when not available
- [x] All data populated from integrated sources
- [x] Proper handling of optional fields

---

## User Experience

### Empty States

**No Cases Match Filters**:
```
  No cases match your filters
```

**Empty Workbasket**:
```
  No cases in workbasket
```

### Results Summary
Located at bottom of table:
```
Showing 12 cases • Sorted by createdDate (descending)
```

---

## Technical Implementation

### Component
- **File**: `/components/CaseWorklist.tsx`
- **Framework**: React with TypeScript
- **UI Library**: shadcn/ui (Table, Badge, Select, Input components)

### Data Structure
```typescript
interface Case {
  id: string;
  clientId: string;
  gci: string;
  coperId?: string; // Optional
  clientName: string;
  caseType: string;
  status: CaseStatus;
  riskLevel: RiskLevel;
  priority: Priority;
  assignedTo: string;
  createdDate: string;
  dueDate: string;
  lineOfBusiness?: LineOfBusiness;
  is312Case?: boolean;
  // ... additional fields
}
```

### Key Functions
- `handleSort(field)` - Three-state sort toggle
- `onViewCase(caseId)` - Navigate to case details
- `useMemo` - Optimize filtering and sorting performance

---

## Performance Considerations

- **Memoization**: Filtering and sorting use `useMemo` to prevent unnecessary recalculations
- **Lazy Rendering**: Large tables use virtualization for 1000+ cases
- **Debounced Search**: Search input debounced to reduce filter operations
- **Indexed Sorting**: Pre-calculated sort keys for large datasets

---

## Responsive Design

### Desktop (> 1024px)
- All columns visible
- Horizontal scroll if needed
- Full filter row

### Tablet (768px - 1024px)
- Horizontal scroll enabled
- All columns maintained
- Stacked filter row

### Mobile (< 768px)
- Priority columns only (Case Number, Client, Status)
- Expandable rows for details
- Simplified filters

---

## Access Control

Users see only cases they have permission to view based on:
- **LOB Access**: Filtered by user's LOB entitlements
- **Case Type Access**: 312 and/or CAM based on role
- **Employee Case Access**: Special entitlement required
- **Sales Owner**: See only assigned cases

---

## Export Functionality

**Export Button**: Downloads filtered case list
- **Format**: Excel (.xlsx)
- **Included Data**: All visible columns
- **Filters**: Exports filtered results
- **Filename**: `CAM_Workbasket_{Date}.xlsx`

---

## Related Files

- `/components/CaseWorklist.tsx` - Main workbasket component
- `/types/index.ts` - Case interface definition
- `/data/caseFlowScenarios.ts` - Mock case data
- `/data/caseFlowHelpers.ts` - Helper functions
- `/CORRECTED_CASE_WORKFLOW.md` - Case workflow documentation

---

## Example Cases

### Example 1: 312 Case with All Fields
```typescript
{
  id: '312-2025-001',
  clientId: 'CLI-892341',
  gci: 'GCI-892341',
  coperId: 'CPR-89234',
  clientName: 'GlobalTech Industries Corp',
  caseType: '312 Review',
  status: 'In Progress',
  riskLevel: 'High',
  assignedTo: 'Sarah Mitchell',
  createdDate: '2025-10-15',
  dueDate: '2025-11-15',
  lineOfBusiness: 'GB/GM',
  is312Case: true
}
```

### Example 2: Consumer Case (No CoPer ID, No Sales Review)
```typescript
{
  id: '312-2025-CONS-001',
  clientId: 'CLI-334455',
  gci: 'GCI-334455',
  coperId: undefined, // Will display as "N/A"
  clientName: 'Maria Rodriguez',
  caseType: '312 Review',
  status: 'In Progress',
  riskLevel: 'Medium',
  assignedTo: 'Lisa Brown',
  createdDate: '2025-10-23',
  dueDate: '2025-11-06',
  lineOfBusiness: 'Consumer',
  is312Case: true
}
```

### Example 3: CAM-Only Case
```typescript
{
  id: 'CAM-2025-045',
  clientId: 'CLI-665544',
  gci: 'GCI-665544',
  coperId: 'CPR-66554',
  clientName: 'Tech Ventures LLC',
  caseType: 'CAM Review',
  status: 'Complete',
  riskLevel: 'Low',
  assignedTo: 'Michael Chen',
  createdDate: '2025-10-10',
  dueDate: '2025-10-24',
  lineOfBusiness: 'GB/GM',
  is312Case: false // CAM only
}
```

---

**Document Version**: 1.0  
**Last Updated**: October 26, 2025  
**Status**: Implementation Complete
