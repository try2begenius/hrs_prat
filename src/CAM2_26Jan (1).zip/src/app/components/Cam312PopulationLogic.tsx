import {
  Box,
  Card,
  CardContent,
  Typography,
  List,
  ListItem,
  ListItemText,
  Divider,
  Chip,
} from '@mui/material';
import { CheckCircle } from '@mui/icons-material';

export function Cam312PopulationLogic() {
  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" fontWeight={600} color="primary" gutterBottom>
          CAM 312 Population Scope Logic
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Detailed criteria for identifying clients in the CAM 312 population
        </Typography>
      </Box>

      {/* Active Status Requirement */}
      <Card sx={{ mb: 3, borderLeft: 4, borderColor: 'warning.main' }}>
        <CardContent>
          <Typography variant="h6" fontWeight={600} gutterBottom>
            Prerequisite: Active Status
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Clients are in an active status, (closed clients should be removed from the scope logic)
          </Typography>
        </CardContent>
      </Card>

      {/* Global Banking and Markets Section */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            <Chip label="GB/GM" color="primary" />
            <Typography variant="h6" fontWeight={600}>
              Global Banking and Markets
            </Typography>
            <Typography variant="body2" color="text.secondary">
              (including Small Business Client Solutions)
            </Typography>
          </Box>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            A client is included in the 312 population if ANY of the following criteria are met:
          </Typography>

          <List>
            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="primary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      1. Client has a Risk Rating of: High, Elevated or Standard
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
            <Divider />

            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="primary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      2. Client Global DGA Due Date for high risk
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
            <Divider />

            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="primary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      3. Client family anniversary Date (within 170-180 days for non high risk and stringent only clients)
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
            <Divider />

            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="primary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      4. Small Business LOB clients will be triggered 95 days from the refresh anniversary month
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
            <Divider />

            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="primary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      5. Client has 312 Flag in AWARE
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
            <Divider />

            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="primary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      6. Client is manually identified as requiring a 312 review
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
          </List>
        </CardContent>
      </Card>

      {/* Private Bank or Merrill Lynch Section */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            <Chip label="PB" color="secondary" />
            <Chip label="ML" color="secondary" />
            <Typography variant="h6" fontWeight={600}>
              Private Bank or Merrill Lynch
            </Typography>
          </Box>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            A client is included in the 312 population if ALL of the following criteria are met:
          </Typography>

          <List>
            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="secondary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      1. Client refresh is due within 180 calendar days
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
            <Divider />

            <ListItem>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="secondary" fontSize="small" />
                    <Typography variant="body2" fontWeight={600}>
                      2. Client has 'PVT' code from CRA
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
          </List>
        </CardContent>
      </Card>

      {/* Implementation Notes */}
      <Card sx={{ bgcolor: 'info.lighter', border: '1px solid', borderColor: 'info.light' }}>
        <CardContent>
          <Typography variant="h6" fontWeight={600} gutterBottom color="info.dark">
            Implementation Notes
          </Typography>
          <List dense>
            <ListItem>
              <ListItemText
                primary={
                  <Typography variant="body2" color="info.dark">
                    • The logic evaluates clients daily based on current status and date calculations
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary={
                  <Typography variant="body2" color="info.dark">
                    • GB/GM uses OR logic - any single criterion triggers inclusion
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary={
                  <Typography variant="body2" color="info.dark">
                    • PB/ML uses AND logic - all criteria must be met for inclusion
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary={
                  <Typography variant="body2" color="info.dark">
                    • Status changes (Active → Closed) automatically remove clients from the population
                  </Typography>
                }
              />
            </ListItem>
          </List>
        </CardContent>
      </Card>
    </Box>
  );
}
