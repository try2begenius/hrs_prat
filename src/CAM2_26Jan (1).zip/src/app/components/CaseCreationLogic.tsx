import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Alert,
  AlertTitle,
  LinearProgress,
  Paper,
  Grid,
} from '@mui/material';
import {
  CheckCircle,
  Cancel,
  Warning,
  Description,
  PlayArrow,
  CalendarToday,
  Security,
  TrendingUp,
  Lock,
  Bolt,
  Storage,
} from '@mui/icons-material';
import { mockClientsForEvaluation, calculateStats, ClientForEvaluation } from '../data/caseCreationMockData';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

export function CaseCreationLogic() {
  const [clients] = useState<ClientForEvaluation[]>(mockClientsForEvaluation);
  const [selectedClient, setSelectedClient] = useState<ClientForEvaluation | null>(null);
  const [tabValue, setTabValue] = useState(0);
  const stats = calculateStats(clients);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const getDecisionChip = (decision?: string) => {
    switch (decision) {
      case 'Full Review':
        return (
          <Chip
            icon={<Warning sx={{ fontSize: 16 }} />}
            label="Full Review"
            color="error"
            size="small"
          />
        );
      case 'Auto-Close':
        return (
          <Chip
            icon={<CheckCircle sx={{ fontSize: 16 }} />}
            label="Auto-Close"
            color="success"
            size="small"
          />
        );
      case 'Not Applicable':
        return (
          <Chip
            icon={<Cancel sx={{ fontSize: 16 }} />}
            label="N/A"
            variant="outlined"
            size="small"
          />
        );
      case 'Pending 312':
        return (
          <Chip
            icon={<Lock sx={{ fontSize: 16 }} />}
            label="Pending 312"
            color="warning"
            size="small"
          />
        );
      default:
        return <Chip label="—" variant="outlined" size="small" />;
    }
  };

  const getRiskChip = (risk: string) => {
    const colorMap: Record<string, 'error' | 'warning' | 'default' | 'success'> = {
      'High': 'error',
      'Elevated': 'warning',
      'Standard': 'default',
      'Low': 'success'
    };
    return <Chip label={risk} color={colorMap[risk]} size="small" />;
  };

  const evaluate312Rules = (client: ClientForEvaluation) => {
    const rules = [];
    
    if (!client.has312Flag && !client.isManuallyUploaded) {
      return [{
        passed: false,
        rule: 'Client not in 312 population',
        result: 'Not Applicable'
      }];
    }

    if (client.isManuallyUploaded) {
      rules.push({
        passed: true,
        rule: 'Manually uploaded exception',
        result: 'Client manually added to 312 population for review'
      });
    }

    rules.push({
      passed: client.has312ModelAlert,
      rule: '312 Model Alert Check',
      result: client.has312ModelAlert 
        ? 'Alert Found → Create case for manual review' 
        : 'No Alert → Auto-close case'
    });

    return rules;
  };

  const evaluatePopulationTrigger = (client: ClientForEvaluation) => {
    const rules = [];
    
    if (client.isManuallyUploaded) {
      rules.push({
        passed: true,
        rule: 'Manual Upload by CAM Team',
        result: 'Client manually added to population - exception case'
      });
    } else if (client.lob === 'PB' || client.lob === 'ML' || client.lob === 'CI') {
      rules.push({
        passed: client.daysToRefresh <= 180 && client.riskRating === 'High',
        rule: `${client.lob} High Risk - Refresh within 180 days`,
        result: client.daysToRefresh <= 180 && client.riskRating === 'High' 
          ? `Triggered - ${client.daysToRefresh} days to refresh` 
          : `Not triggered - ${client.daysToRefresh} days (>180 or not High risk)`
      });
    } else if (client.lob === 'GB/GM') {
      rules.push({
        passed: !!client.globalDGADueDate,
        rule: 'GB/GM - Global DGA Due Date',
        result: client.globalDGADueDate 
          ? `Triggered - DGA Due: ${client.globalDGADueDate}` 
          : 'Not triggered - No DGA due date'
      });
    } else if (client.lob === 'Consumer') {
      rules.push({
        passed: client.daysToRefresh <= 120,
        rule: 'Consumer - Refresh within 120 days',
        result: client.daysToRefresh <= 120 
          ? `Triggered - ${client.daysToRefresh} days to refresh` 
          : `Not triggered - ${client.daysToRefresh} days (>120)`
      });
    } else if (client.lob === 'Small Business') {
      rules.push({
        passed: client.daysToRefresh <= 95,
        rule: 'Small Business - 95 days before refresh anniversary',
        result: client.daysToRefresh <= 95 
          ? `Triggered - ${client.daysToRefresh} days to anniversary (${client.refreshAnniversaryMonth})` 
          : `Not triggered - ${client.daysToRefresh} days (>95)`
      });
    }
    
    return rules;
  };

  const evaluateCAMRules = (client: ClientForEvaluation) => {
    const rules = [];
    
    const inScopeGFCCases = client.gfcSearchCases.filter(c => c.isInScope);
    const gfcCount = inScopeGFCCases.length;
    
    rules.push({
      passed: gfcCount >= 2,
      rule: 'GFC Search Cases (In-Scope)',
      result: `Found ${gfcCount} in-scope case(s) - ${gfcCount >= 2 ? 'PASSED: Meets threshold (≥2)' : 'FAILED: Below threshold (<2)'}`
    });

    if (client.priorCAMCaseLast12Months) {
      rules.push({
        passed: true,
        rule: 'Prior CAM Review (Last 12 Months)',
        result: `Found prior review: ${client.priorCAMCaseLast12Months.caseId} on ${client.priorCAMCaseLast12Months.reviewDate}`
      });

      const reviewedCaseIds = client.priorCAMCaseLast12Months.reviewedGFCCases;
      const newCases = inScopeGFCCases.filter(gfc => !reviewedCaseIds.includes(gfc.caseId));
      
      rules.push({
        passed: newCases.length > 0,
        rule: 'New Cases Since Last CAM Review',
        result: newCases.length > 0 
          ? `FAILED: ${newCases.length} new case(s) found → Full Review Required` 
          : `PASSED: All ${gfcCount} cases previously reviewed → Can Auto-Close`
      });
    } else {
      rules.push({
        passed: false,
        rule: 'Prior CAM Review (Last 12 Months)',
        result: 'No prior CAM review found in last 12 months'
      });
    }

    if (client.had312CaseNotAutoClosed) {
      rules.push({
        passed: true,
        rule: '312 Case Review Status',
        result: '312 case required manual review (not auto-closed)'
      });
    }

    return rules;
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h4" gutterBottom>
            Case Creation Engine
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Real-time evaluation of case creation logic
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<PlayArrow />}
          size="large"
        >
          Run Evaluation
        </Button>
      </Box>

      {/* Summary Statistics */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Clients Evaluated
                  </Typography>
                  <Typography variant="h3" sx={{ my: 1 }}>
                    {stats.totalEvaluated}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    In evaluation queue
                  </Typography>
                </Box>
                <Storage color="action" />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box sx={{ width: '100%' }}>
                  <Typography variant="caption" color="text.secondary">
                    312 Full Reviews
                  </Typography>
                  <Typography variant="h3" color="error.main" sx={{ my: 1 }}>
                    {stats.cam312FullReview}
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={(stats.cam312FullReview / stats.totalEvaluated) * 100}
                    color="error"
                    sx={{ height: 4, borderRadius: 2 }}
                  />
                </Box>
                <Warning color="error" />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box sx={{ width: '100%' }}>
                  <Typography variant="caption" color="text.secondary">
                    CAM Full Reviews
                  </Typography>
                  <Typography variant="h3" color="error.main" sx={{ my: 1 }}>
                    {stats.camFullReview}
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={(stats.camFullReview / stats.totalEvaluated) * 100}
                    color="error"
                    sx={{ height: 4, borderRadius: 2 }}
                  />
                </Box>
                <Warning color="error" />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Auto-Closed
                  </Typography>
                  <Typography variant="h3" color="success.main" sx={{ my: 1 }}>
                    {stats.cam312AutoClose + stats.camAutoClose}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {stats.cam312AutoClose} 312 | {stats.camAutoClose} CAM
                  </Typography>
                </Box>
                <CheckCircle color="success" />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Outcome Distribution */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                CAM 312 Case Outcomes
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Based on 312 model alerts
              </Typography>

              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Paper variant="outlined" sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Warning color="error" fontSize="small" />
                    <Typography variant="body2">Full Review Required</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body1" fontWeight={600}>{stats.cam312FullReview}</Typography>
                    <Chip
                      label={`${((stats.cam312FullReview / stats.totalEvaluated) * 100).toFixed(0)}%`}
                      color="error"
                      size="small"
                    />
                  </Box>
                </Paper>

                <Paper variant="outlined" sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="success" fontSize="small" />
                    <Typography variant="body2">Auto-Closed</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body1" fontWeight={600}>{stats.cam312AutoClose}</Typography>
                    <Chip
                      label={`${((stats.cam312AutoClose / stats.totalEvaluated) * 100).toFixed(0)}%`}
                      color="success"
                      size="small"
                    />
                  </Box>
                </Paper>

                <Paper variant="outlined" sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Cancel color="action" fontSize="small" />
                    <Typography variant="body2">Not Applicable</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body1" fontWeight={600}>{stats.cam312NotApplicable}</Typography>
                    <Chip
                      label={`${((stats.cam312NotApplicable / stats.totalEvaluated) * 100).toFixed(0)}%`}
                      variant="outlined"
                      size="small"
                    />
                  </Box>
                </Paper>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                CAM Case Outcomes
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Based on trigger conditions
              </Typography>

              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Paper variant="outlined" sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Warning color="error" fontSize="small" />
                    <Typography variant="body2">Full Review Required</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body1" fontWeight={600}>{stats.camFullReview}</Typography>
                    <Chip
                      label={`${((stats.camFullReview / stats.totalEvaluated) * 100).toFixed(0)}%`}
                      color="error"
                      size="small"
                    />
                  </Box>
                </Paper>

                <Paper variant="outlined" sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CheckCircle color="success" fontSize="small" />
                    <Typography variant="body2">Auto-Closed</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body1" fontWeight={600}>{stats.camAutoClose}</Typography>
                    <Chip
                      label={`${((stats.camAutoClose / stats.totalEvaluated) * 100).toFixed(0)}%`}
                      color="success"
                      size="small"
                    />
                  </Box>
                </Paper>

                <Paper variant="outlined" sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Lock color="warning" fontSize="small" />
                    <Typography variant="body2">Pending 312 Completion</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body1" fontWeight={600}>{stats.camPending312}</Typography>
                    <Chip
                      label={`${((stats.camPending312 / stats.totalEvaluated) * 100).toFixed(0)}%`}
                      color="warning"
                      size="small"
                    />
                  </Box>
                </Paper>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Tabs */}
      <Card>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={tabValue} onChange={handleTabChange}>
            <Tab label="Case Evaluation Results" />
            <Tab label="Rule Evaluation Details" />
          </Tabs>
        </Box>

        <TabPanel value={tabValue} index={0}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Client Case Creation Decisions
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Click a row to see detailed rule evaluation
            </Typography>

            <TableContainer sx={{ maxHeight: 600, border: '1px solid', borderColor: 'divider', borderRadius: 1, width: '100%' }}>
              <Table stickyHeader sx={{ minWidth: 1200 }}>
                <TableHead>
                  <TableRow>
                    <TableCell>Client Name</TableCell>
                    <TableCell>LOB</TableCell>
                    <TableCell>Risk</TableCell>
                    <TableCell>Days to Refresh</TableCell>
                    <TableCell>CAM 312 Decision</TableCell>
                    <TableCell>CAM Decision</TableCell>
                    <TableCell>Case IDs</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {clients.map((client) => (
                    <TableRow
                      key={client.id}
                      hover
                      onClick={() => {
                        setSelectedClient(client);
                        setTabValue(1);
                      }}
                      sx={{ cursor: 'pointer' }}
                    >
                      <TableCell>
                        <Typography variant="body2" fontWeight={500}>
                          {client.legalName}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip label={client.lob} variant="outlined" size="small" />
                      </TableCell>
                      <TableCell>{getRiskChip(client.riskRating)}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <CalendarToday sx={{ fontSize: 16, color: 'text.secondary' }} />
                          <Typography variant="body2">{client.daysToRefresh} days</Typography>
                        </Box>
                      </TableCell>
                      <TableCell>{getDecisionChip(client.cam312Decision)}</TableCell>
                      <TableCell>{getDecisionChip(client.camDecision)}</TableCell>
                      <TableCell>
                        <Typography variant="caption" color="text.secondary">
                          {client.cam312CaseId && <div>312: {client.cam312CaseId}</div>}
                          {client.camCaseId && <div>CAM: {client.camCaseId}</div>}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          {!selectedClient ? (
            <Alert severity="info">
              <AlertTitle>No Client Selected</AlertTitle>
              Select a client from the "Case Evaluation Results" tab to view detailed rule evaluation
            </Alert>
          ) : (
            <Box sx={{ p: 3 }}>
              {/* Client Overview */}
              <Card sx={{ mb: 3, borderLeft: 4, borderColor: 'primary.main' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                    <Box>
                      <Typography variant="h5" gutterBottom>
                        {selectedClient.legalName}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                        <Chip label={selectedClient.clientId} variant="outlined" size="small" />
                        <Chip label={selectedClient.lob} variant="outlined" size="small" />
                        {getRiskChip(selectedClient.riskRating)}
                      </Box>
                    </Box>
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => setSelectedClient(null)}
                    >
                      Clear Selection
                    </Button>
                  </Box>

                  <Grid container spacing={2}>
                    <Grid size={{ xs: 12, md: 4 }}>
                      <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
                        <Typography variant="caption" color="text.secondary">
                          Refresh Due Date
                        </Typography>
                        <Typography variant="body1" fontWeight={600}>
                          {selectedClient.refreshDueDate}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {selectedClient.daysToRefresh} days away
                        </Typography>
                      </Paper>
                    </Grid>
                    <Grid size={{ xs: 12, md: 4 }}>
                      <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
                        <Typography variant="caption" color="text.secondary">
                          312 Model Alert
                        </Typography>
                        <Typography variant="body1" fontWeight={600}>
                          {selectedClient.has312ModelAlert ? 'YES' : 'NO'}
                        </Typography>
                        {selectedClient.has312ModelAlert && (
                          <Typography variant="caption" color="error">
                            Alert detected
                          </Typography>
                        )}
                      </Paper>
                    </Grid>
                    <Grid size={{ xs: 12, md: 4 }}>
                      <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
                        <Typography variant="caption" color="text.secondary">
                          Cases (12 months)
                        </Typography>
                        <Typography variant="body1" fontWeight={600}>
                          {selectedClient.completedCasesLast12Months} completed
                        </Typography>
                        {selectedClient.hasSARLast12Months && (
                          <Typography variant="caption" color="error">
                            SAR filed
                          </Typography>
                        )}
                      </Paper>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>

              {/* 312 Rule Evaluation */}
              <Card sx={{ mb: 3, borderLeft: 4, borderColor: 'primary.main' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                        <Security color="primary" />
                        <Typography variant="h6">
                          CAM 312 Rule Evaluation
                        </Typography>
                      </Box>
                      <Typography variant="body2" color="text.secondary">
                        312 Model alert determines full review vs auto-close
                      </Typography>
                    </Box>
                    {getDecisionChip(selectedClient.cam312Decision)}
                  </Box>

                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    {evaluate312Rules(selectedClient).map((rule, index) => (
                      <Paper
                        key={index}
                        variant="outlined"
                        sx={{
                          p: 2,
                          display: 'flex',
                          gap: 1.5,
                          bgcolor: rule.passed ? 'success.lighter' : 'grey.50',
                          borderColor: rule.passed ? 'success.light' : 'divider',
                        }}
                      >
                        {rule.passed ? (
                          <CheckCircle color="success" />
                        ) : (
                          <Cancel color="action" />
                        )}
                        <Box sx={{ flex: 1 }}>
                          <Typography variant="body2" fontWeight={600}>
                            {rule.rule}
                          </Typography>
                          <Typography
                            variant="body2"
                            color={rule.passed ? 'success.dark' : 'text.secondary'}
                            sx={{ mt: 0.5 }}
                          >
                            {rule.result}
                          </Typography>
                        </Box>
                      </Paper>
                    ))}

                    {selectedClient.cam312Decision === 'Full Review' && (
                      <Alert severity="error" sx={{ mt: 1 }}>
                        <AlertTitle>Decision: Full Review Required</AlertTitle>
                        312 model alert detected. Case created for analyst review. Case ID: {selectedClient.cam312CaseId}
                      </Alert>
                    )}

                    {selectedClient.cam312Decision === 'Auto-Close' && (
                      <Alert severity="success" sx={{ mt: 1 }}>
                        <AlertTitle>Decision: Auto-Close</AlertTitle>
                        <Typography variant="body2">
                          No 312 model alert. Case auto-closed.
                        </Typography>
                        <Box sx={{ mt: 1 }}>
                          <Typography variant="body2"><strong>Status:</strong> Complete</Typography>
                          <Typography variant="body2"><strong>Auto-Complete Flag:</strong> Y</Typography>
                          <Typography variant="body2">
                            <strong>Model Output:</strong> "312 Activity in line with expected activity – No review required"
                          </Typography>
                          {selectedClient.cam312CaseId && (
                            <Typography variant="body2" sx={{ mt: 1 }}>Case ID: {selectedClient.cam312CaseId}</Typography>
                          )}
                        </Box>
                      </Alert>
                    )}

                    {selectedClient.cam312Decision === 'Not Applicable' && (
                      <Alert severity="info" sx={{ mt: 1 }}>
                        <AlertTitle>Decision: Not Applicable</AlertTitle>
                        Client not in 312 population scope
                      </Alert>
                    )}
                  </Box>
                </CardContent>
              </Card>

              {/* CAM Rule Evaluation - Similar structure */}
              <Card sx={{ borderLeft: 4, borderColor: 'error.main' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                        <Bolt color="error" />
                        <Typography variant="h6">
                          CAM Rule Evaluation
                        </Typography>
                      </Box>
                      <Typography variant="body2" color="text.secondary">
                        Logic: Check GFC cases (≥2) and review history for new cases
                      </Typography>
                    </Box>
                    {getDecisionChip(selectedClient.camDecision)}
                  </Box>

                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    {evaluateCAMRules(selectedClient).map((rule, index) => (
                      <Paper
                        key={index}
                        variant="outlined"
                        sx={{
                          p: 2,
                          display: 'flex',
                          gap: 1.5,
                          bgcolor: rule.passed
                            ? 'success.lighter'
                            : rule.result.includes('FAILED')
                            ? 'error.lighter'
                            : 'grey.50',
                          borderColor: rule.passed
                            ? 'success.light'
                            : rule.result.includes('FAILED')
                            ? 'error.light'
                            : 'divider',
                        }}
                      >
                        {rule.passed ? (
                          <CheckCircle color="success" />
                        ) : rule.result.includes('FAILED') ? (
                          <Cancel color="error" />
                        ) : (
                          <Cancel color="action" />
                        )}
                        <Box sx={{ flex: 1 }}>
                          <Typography variant="body2" fontWeight={600}>
                            {rule.rule}
                          </Typography>
                          <Typography
                            variant="body2"
                            color={
                              rule.passed
                                ? 'success.dark'
                                : rule.result.includes('FAILED')
                                ? 'error.dark'
                                : 'text.secondary'
                            }
                            sx={{ mt: 0.5 }}
                          >
                            {rule.result}
                          </Typography>
                        </Box>
                      </Paper>
                    ))}

                    {selectedClient.camDecision === 'Full Review' && (
                      <Alert severity="error" sx={{ mt: 1 }}>
                        <AlertTitle>Decision: Full Review Required</AlertTitle>
                        {!selectedClient.priorCAMCaseLast12Months ? 
                          `No prior CAM cases found and ${selectedClient.gfcSearchCases.filter(c => c.isInScope).length} in-scope GFC cases detected. Case created for manual review.` :
                          'New GFC cases detected since last CAM review. Case created for manual review.'}
                        {selectedClient.camCaseId && <> • Case ID: {selectedClient.camCaseId}</>}
                      </Alert>
                    )}

                    {selectedClient.camDecision === 'Auto-Close' && (
                      <Alert severity="success" sx={{ mt: 1 }}>
                        <AlertTitle>Decision: Auto-Close</AlertTitle>
                        <Typography variant="body2">
                          {selectedClient.gfcSearchCases.filter(c => c.isInScope).length < 2 ? 
                            'Less than 2 in-scope GFC cases. Case created but auto-closed.' :
                            'All GFC cases were previously reviewed. No new cases since last CAM. Case created but auto-closed.'}
                        </Typography>
                        <Box sx={{ mt: 1 }}>
                          <Typography variant="body2"><strong>Status:</strong> Complete</Typography>
                          <Typography variant="body2"><strong>Auto-Complete Flag:</strong> Y</Typography>
                          <Typography variant="body2"><strong>Note:</strong> Case populated with all available data</Typography>
                          {selectedClient.camCaseId && (
                            <Typography variant="body2" sx={{ mt: 1 }}>Case ID: {selectedClient.camCaseId}</Typography>
                          )}
                        </Box>
                      </Alert>
                    )}

                    {selectedClient.camDecision === 'Pending 312' && (
                      <Alert severity="warning" sx={{ mt: 1 }}>
                        <AlertTitle>Decision: Pending 312 Completion</AlertTitle>
                        CAM triggered ONLY by 312 alert. Case created but cannot be placed in terminal status until 312 is complete. 
                        If 312 disposition is "no action", CAM can auto-close.
                        {selectedClient.camCaseId && <> • Case ID: {selectedClient.camCaseId}</>}
                      </Alert>
                    )}
                  </Box>
                </CardContent>
              </Card>
            </Box>
          )}
        </TabPanel>
      </Card>
    </Box>
  );
}