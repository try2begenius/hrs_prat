import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Button,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Badge,
  Switch,
  Divider,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
} from '@mui/material';
import {
  NotificationsOutlined,
  SendOutlined,
  PersonAdd,
  AccessTime,
  TrendingUp,
  CheckCircleOutline,
  PersonOutline,
  AccessTimeOutlined,
  LabelOutlined,
  EmailOutlined,
  Close,
  Send as SendIcon,
} from '@mui/icons-material';
import { UserAccess } from '../data/rolesEntitlementsMockData';

interface NotificationsProps {
  currentUser: UserAccess;
}

interface Notification {
  id: string;
  title: string;
  description: string;
  time: string;
  caseId: string;
  isNew: boolean;
  priority: 'high' | 'urgent' | 'normal';
  icon: React.ReactNode;
  iconColor: string;
}

interface EmailSetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

interface DigestSetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

interface SentEmail {
  id: string;
  subject: string;
  caseId: string;
  clientName: string;
  timestamp: string;
  to: string;
  status: string;
  action312: string;
  actionCAM: string;
}

export function Notifications({ currentUser }: NotificationsProps) {
  const [tabValue, setTabValue] = useState(0);
  const [emailPreviewOpen, setEmailPreviewOpen] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<SentEmail | null>(null);
  const [emailViewTab, setEmailViewTab] = useState(0);
  
  const [notifications] = useState<Notification[]>([
    {
      id: '1',
      title: 'New Case Assigned',
      description: 'Case CAM-2025-005 (Riverside Capital Partners) has been assigned to you',
      time: '2 hours ago',
      caseId: 'CAM-2025-005',
      isNew: true,
      priority: 'high',
      icon: <PersonAdd fontSize="small" />,
      iconColor: '#0047AB',
    },
    {
      id: '2',
      title: 'Case Due Tomorrow',
      description: '312-2025-004 (Quantum Family Trust) is due tomorrow',
      time: '5 hours ago',
      caseId: '312-2025-004',
      isNew: true,
      priority: 'urgent',
      icon: <AccessTime fontSize="small" />,
      iconColor: '#ED6C02',
    },
    {
      id: '3',
      title: 'Case Escalated',
      description: 'You escalated 312-2025-005 to management for review',
      time: '1 day ago',
      caseId: '312-2025-005',
      isNew: false,
      priority: 'high',
      icon: <TrendingUp fontSize="small" />,
      iconColor: '#CC0000',
    },
  ]);

  const [sentEmails] = useState<SentEmail[]>([
    {
      id: '1',
      subject: 'Case Assignment',
      caseId: 'CASE-2026-001',
      clientName: 'Acme Corporation',
      timestamp: '2026-01-15 10:30 AM at',
      to: 'To:',
      status: '—',
      action312: '—',
      actionCAM: '—',
    },
    {
      id: '2',
      subject: 'CAM Review Request',
      caseId: 'CASE-2026-002',
      clientName: 'Global Tech Industries',
      timestamp: '2026-01-16 09:15 AM at',
      to: 'To:',
      status: '—',
      action312: '—',
      actionCAM: '—',
    },
    {
      id: '3',
      subject: 'Sales Review Required',
      caseId: 'CASE-2026-001',
      clientName: 'Acme Corporation',
      timestamp: '2026-01-15 02:45 PM at',
      to: 'To:',
      status: '—',
      action312: '—',
      actionCAM: '—',
    },
    {
      id: '4',
      subject: 'Case Status Update',
      caseId: 'CASE-2026-005',
      clientName: 'Metropolitan Holdings',
      timestamp: '2026-01-20 11:20 AM at',
      to: 'To:',
      status: '—',
      action312: '—',
      actionCAM: '—',
    },
    {
      id: '5',
      subject: 'Reminder: Case Due Soon',
      caseId: 'CASE-2026-001',
      clientName: 'Acme Corporation',
      timestamp: '2026-01-22 08:00 AM at',
      to: 'To:',
      status: '—',
      action312: '—',
      actionCAM: '—',
    },
    {
      id: '6',
      subject: 'Case Escalation Notice',
      caseId: 'CASE-2026-003',
      clientName: 'Pacific Ventures LLC',
      timestamp: '2026-01-18 03:30 PM at',
      to: 'To:',
      status: '—',
      action312: '—',
      actionCAM: '—',
    },
  ]);

  const [emailSettings, setEmailSettings] = useState<EmailSetting[]>([
    {
      id: 'assignments',
      label: 'Case Assignments',
      description: 'When assigned a new case',
      enabled: true,
    },
    {
      id: 'escalations',
      label: 'Escalations',
      description: 'When a case is escalated',
      enabled: true,
    },
    {
      id: 'deadlines',
      label: 'Deadlines',
      description: '24 hours before due date',
      enabled: true,
    },
    {
      id: 'comments',
      label: 'Comments',
      description: 'New comments on your cases',
      enabled: false,
    },
    {
      id: 'status',
      label: 'Status Changes',
      description: 'When case status updates',
      enabled: false,
    },
  ]);

  const [digestSettings, setDigestSettings] = useState<DigestSetting[]>([
    {
      id: 'daily',
      label: 'Daily Digest',
      description: 'Summary of all activity',
      enabled: true,
    },
    {
      id: 'weekly',
      label: 'Weekly Report',
      description: 'Weekly case statistics',
      enabled: true,
    },
  ]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleEmailSettingToggle = (id: string) => {
    setEmailSettings(prev =>
      prev.map(setting =>
        setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
      )
    );
  };

  const handleDigestSettingToggle = (id: string) => {
    setDigestSettings(prev =>
      prev.map(setting =>
        setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
      )
    );
  };

  const unreadCount = notifications.filter(n => n.isNew).length;

  const getPriorityChip = (priority: string) => {
    if (priority === 'urgent') {
      return (
        <Chip
          label="urgent"
          size="small"
          sx={{
            bgcolor: '#CC0000',
            color: 'white',
            fontWeight: 600,
            fontSize: '0.7rem',
            height: '20px',
          }}
        />
      );
    }
    if (priority === 'high') {
      return (
        <Chip
          label="high"
          size="small"
          variant="outlined"
          sx={{
            borderColor: '#0047AB',
            color: '#0047AB',
            fontWeight: 600,
            fontSize: '0.7rem',
            height: '20px',
          }}
        />
      );
    }
    return null;
  };

  const openEmailPreview = (email: SentEmail) => {
    setSelectedEmail(email);
    setEmailPreviewOpen(true);
  };

  const closeEmailPreview = () => {
    setSelectedEmail(null);
    setEmailPreviewOpen(false);
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 600, color: '#1A1A1A', mb: 0.5 }}>
            Notifications & Emails
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Viewing notifications for {currentUser.name} ({currentUser.role})
          </Typography>
        </Box>
        <Button
          variant="outlined"
          sx={{
            textTransform: 'none',
            borderColor: '#D0D5DD',
            color: '#344054',
            '&:hover': {
              borderColor: '#0047AB',
              bgcolor: 'transparent',
            },
          }}
        >
          Mark All as Read
        </Button>
      </Box>

      {/* Tabs */}
      <Box sx={{ mb: 3 }}>
        <Tabs
          value={tabValue}
          onChange={handleTabChange}
          sx={{
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 500,
              fontSize: '0.9rem',
              color: '#5F6368',
              '&.Mui-selected': {
                color: '#0047AB',
                fontWeight: 600,
              },
            },
            '& .MuiTabs-indicator': {
              backgroundColor: '#0047AB',
            },
          }}
        >
          <Tab
            icon={
              <Badge badgeContent={unreadCount} color="error" sx={{ mr: 1 }}>
                <NotificationsOutlined />
              </Badge>
            }
            iconPosition="start"
            label="Notifications"
          />
          <Tab
            icon={<SendOutlined />}
            iconPosition="start"
            label="Sent Emails"
          />
        </Tabs>
      </Box>

      {/* Content */}
      <Grid container spacing={3}>
        {/* Left Column - Notifications */}
        <Grid size={{ xs: 12, md: 7 }}>
          <Card sx={{ boxShadow: '0 1px 3px rgba(0,0,0,0.12)' }}>
            <CardContent>
              {tabValue === 0 && (
                <>
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="h6" sx={{ fontWeight: 600, color: '#0047AB', mb: 0.5 }}>
                      Recent Notifications
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
                    </Typography>
                  </Box>

                  <List sx={{ p: 0 }}>
                    {notifications.map((notification, index) => (
                      <Box key={notification.id}>
                        <ListItem
                          sx={{
                            px: 2,
                            py: 2,
                            bgcolor: notification.isNew ? '#F0F7FF' : 'transparent',
                            borderRadius: 1,
                            mb: 1,
                            alignItems: 'flex-start',
                            display: 'flex',
                            '&:hover': {
                              bgcolor: notification.isNew ? '#E3F2FD' : '#F5F7FA',
                            },
                          }}
                        >
                          <ListItemIcon sx={{ minWidth: 40, mt: 0.5 }}>
                            <Box
                              sx={{
                                width: 32,
                                height: 32,
                                borderRadius: '50%',
                                bgcolor: notification.iconColor + '15',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: notification.iconColor,
                              }}
                            >
                              {notification.icon}
                            </Box>
                          </ListItemIcon>
                          <Box sx={{ flex: 1, minWidth: 0 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                              <Typography variant="body1" sx={{ fontWeight: 600, color: '#1A1A1A' }}>
                                {notification.title}
                              </Typography>
                              {notification.isNew && (
                                <Chip
                                  label="New"
                                  size="small"
                                  sx={{
                                    bgcolor: '#0047AB',
                                    color: 'white',
                                    fontWeight: 600,
                                    fontSize: '0.7rem',
                                    height: '20px',
                                  }}
                                />
                              )}
                            </Box>
                            <Typography variant="body2" sx={{ color: '#5F6368', mb: 1 }}>
                              {notification.description}
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                              <Typography variant="caption" sx={{ color: '#98A2B3' }}>
                                {notification.time}
                              </Typography>
                              <Typography
                                variant="caption"
                                sx={{
                                  color: '#0047AB',
                                  cursor: 'pointer',
                                  '&:hover': { textDecoration: 'underline' },
                                }}
                              >
                                Case: {notification.caseId}
                              </Typography>
                            </Box>
                          </Box>
                          <Box sx={{ ml: 2 }}>{getPriorityChip(notification.priority)}</Box>
                        </ListItem>
                        {index < notifications.length - 1 && <Divider sx={{ my: 1 }} />}
                      </Box>
                    ))}
                  </List>
                </>
              )}

              {tabValue === 1 && (
                <>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <EmailOutlined sx={{ color: '#0047AB' }} />
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600, color: '#0047AB' }}>
                          Email Notifications
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          All sent email notifications
                        </Typography>
                      </Box>
                    </Box>
                    <Typography variant="body2" sx={{ color: '#0047AB', fontWeight: 600 }}>
                      {sentEmails.length} Emails
                    </Typography>
                  </Box>

                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {sentEmails.map((email) => (
                      <Card
                        key={email.id}
                        sx={{
                          border: '1px solid #E0E0E0',
                          boxShadow: 'none',
                          '&:hover': {
                            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                          },
                        }}
                      >
                        <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                          {/* Header Row */}
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                            <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1, flex: 1 }}>
                              <CheckCircleOutline sx={{ color: '#2E7D32', fontSize: 20, mt: 0.3 }} />
                              <Typography variant="body1" sx={{ color: '#0047AB', fontWeight: 500 }}>
                                {email.subject}: {email.caseId} - {email.clientName}
                              </Typography>
                            </Box>
                            <Chip
                              label="No Action Required"
                              size="small"
                              sx={{
                                bgcolor: '#E8F5E9',
                                color: '#2E7D32',
                                fontWeight: 600,
                                fontSize: '0.75rem',
                                border: '1px solid #A5D6A7',
                              }}
                            />
                          </Box>

                          {/* Meta Row */}
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 3, mb: 2, ml: 3.5 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <PersonOutline sx={{ fontSize: 16, color: '#5F6368' }} />
                              <Typography variant="caption" sx={{ color: '#5F6368' }}>
                                {email.to}
                              </Typography>
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <AccessTimeOutlined sx={{ fontSize: 16, color: '#5F6368' }} />
                              <Typography variant="caption" sx={{ color: '#5F6368' }}>
                                {email.timestamp}
                              </Typography>
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <LabelOutlined sx={{ fontSize: 16, color: '#5F6368' }} />
                              <Typography variant="caption" sx={{ color: '#5F6368' }}>
                                {email.caseId}
                              </Typography>
                            </Box>
                          </Box>

                          {/* Action Row */}
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Grid container spacing={2} sx={{ flex: 1 }}>
                              <Grid size={{ xs: 4 }}>
                                <Typography variant="caption" sx={{ color: '#5F6368', fontWeight: 600 }}>
                                  Status:
                                </Typography>
                                <Typography variant="body2" sx={{ color: '#98A2B3', mt: 0.5 }}>
                                  {email.status}
                                </Typography>
                              </Grid>
                              <Grid size={{ xs: 4 }}>
                                <Typography variant="caption" sx={{ color: '#5F6368', fontWeight: 600 }}>
                                  312 Action:
                                </Typography>
                                <Typography variant="body2" sx={{ color: '#98A2B3', mt: 0.5 }}>
                                  {email.action312}
                                </Typography>
                              </Grid>
                              <Grid size={{ xs: 4 }}>
                                <Typography variant="caption" sx={{ color: '#5F6368', fontWeight: 600 }}>
                                  CAM Action:
                                </Typography>
                                <Typography variant="body2" sx={{ color: '#98A2B3', mt: 0.5 }}>
                                  {email.actionCAM}
                                </Typography>
                              </Grid>
                            </Grid>
                            <Button
                              variant="outlined"
                              size="small"
                              startIcon={<EmailOutlined />}
                              sx={{
                                textTransform: 'none',
                                borderColor: '#0047AB',
                                color: '#0047AB',
                                fontWeight: 500,
                                ml: 2,
                                '&:hover': {
                                  borderColor: '#003380',
                                  bgcolor: '#F0F7FF',
                                },
                              }}
                              onClick={() => openEmailPreview(email)}
                            >
                              View Email
                            </Button>
                          </Box>
                        </CardContent>
                      </Card>
                    ))}
                  </Box>
                </>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Right Column - Settings */}
        <Grid size={{ xs: 12, md: 5 }}>
          {/* Email Settings */}
          <Card sx={{ boxShadow: '0 1px 3px rgba(0,0,0,0.12)', mb: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 600, color: '#0047AB', mb: 0.5 }}>
                Email Settings
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Configure email notifications
              </Typography>

              <List sx={{ p: 0 }}>
                {emailSettings.map((setting, index) => (
                  <Box key={setting.id}>
                    <ListItem
                      sx={{
                        px: 0,
                        py: 1.5,
                      }}
                      secondaryAction={
                        <Switch
                          edge="end"
                          checked={setting.enabled}
                          onChange={() => handleEmailSettingToggle(setting.id)}
                          sx={{
                            '& .MuiSwitch-switchBase.Mui-checked': {
                              color: '#0047AB',
                            },
                            '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                              backgroundColor: '#0047AB',
                            },
                          }}
                        />
                      }
                    >
                      <ListItemText
                        primary={
                          <Typography variant="body2" sx={{ fontWeight: 600, color: '#1A1A1A' }}>
                            {setting.label}
                          </Typography>
                        }
                        secondary={
                          <Typography variant="caption" sx={{ color: '#5F6368' }}>
                            {setting.description}
                          </Typography>
                        }
                      />
                    </ListItem>
                    {index < emailSettings.length - 1 && <Divider />}
                  </Box>
                ))}
              </List>
            </CardContent>
          </Card>

          {/* Digest Settings */}
          <Card sx={{ boxShadow: '0 1px 3px rgba(0,0,0,0.12)' }}>
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 600, color: '#0047AB', mb: 0.5 }}>
                Digest Settings
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Daily summary emails
              </Typography>

              <List sx={{ p: 0 }}>
                {digestSettings.map((setting, index) => (
                  <Box key={setting.id}>
                    <ListItem
                      sx={{
                        px: 0,
                        py: 1.5,
                      }}
                      secondaryAction={
                        <Switch
                          edge="end"
                          checked={setting.enabled}
                          onChange={() => handleDigestSettingToggle(setting.id)}
                          sx={{
                            '& .MuiSwitch-switchBase.Mui-checked': {
                              color: '#0047AB',
                            },
                            '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                              backgroundColor: '#0047AB',
                            },
                          }}
                        />
                      }
                    >
                      <ListItemText
                        primary={
                          <Typography variant="body2" sx={{ fontWeight: 600, color: '#1A1A1A' }}>
                            {setting.label}
                          </Typography>
                        }
                        secondary={
                          <Typography variant="caption" sx={{ color: '#5F6368' }}>
                            {setting.description}
                          </Typography>
                        }
                      />
                    </ListItem>
                    {index < digestSettings.length - 1 && <Divider />}
                  </Box>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Email Preview Dialog */}
      <Dialog
        open={emailPreviewOpen}
        onClose={closeEmailPreview}
        fullWidth
        maxWidth="md"
        PaperProps={{
          sx: {
            borderRadius: 2,
          },
        }}
      >
        <Box sx={{ p: 3 }}>
          {/* Header */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
            <Typography variant="h5" sx={{ fontWeight: 600, color: '#1A1A1A' }}>
              Email Preview
            </Typography>
            <IconButton
              onClick={closeEmailPreview}
              size="small"
              sx={{
                color: '#5F6368',
                '&:hover': {
                  bgcolor: '#F5F7FA',
                },
              }}
            >
              <Close />
            </IconButton>
          </Box>

          {selectedEmail && (
            <>
              {/* Subtitle */}
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Sent to (david.chen@bofa.com) on {selectedEmail.timestamp}
              </Typography>

              {/* Tabs */}
              <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
                <Tabs
                  value={emailViewTab}
                  onChange={(e, newValue) => setEmailViewTab(newValue)}
                  sx={{
                    '& .MuiTab-root': {
                      textTransform: 'none',
                      fontWeight: 500,
                      fontSize: '0.95rem',
                      color: '#5F6368',
                      '&.Mui-selected': {
                        color: '#0047AB',
                        fontWeight: 600,
                      },
                    },
                    '& .MuiTabs-indicator': {
                      backgroundColor: '#0047AB',
                    },
                  }}
                >
                  <Tab label="HTML View" />
                  <Tab label="Plain Text" />
                </Tabs>
              </Box>

              {/* Email Content */}
              <Box
                sx={{
                  border: '1px solid #E0E0E0',
                  borderRadius: 1,
                  minHeight: 500,
                  bgcolor: emailViewTab === 0 ? 'white' : '#F9FAFB',
                  p: 3,
                  mb: 3,
                }}
              >
                {emailViewTab === 0 ? (
                  <Box>
                    <Typography variant="body1" sx={{ color: '#1A1A1A', mb: 2 }}>
                      Dear Team,
                    </Typography>
                    <Typography variant="body1" sx={{ color: '#1A1A1A', mb: 2 }}>
                      This is an automated notification regarding case <strong>{selectedEmail.caseId}</strong> for client <strong>{selectedEmail.clientName}</strong>.
                    </Typography>
                    <Typography variant="body1" sx={{ color: '#1A1A1A', mb: 2 }}>
                      <strong>Subject:</strong> {selectedEmail.subject}
                    </Typography>
                    <Typography variant="body1" sx={{ color: '#1A1A1A', mb: 2 }}>
                      Please review the case details in the system and take appropriate action if needed.
                    </Typography>
                    <Typography variant="body1" sx={{ color: '#1A1A1A', mb: 2 }}>
                      If you have any questions or concerns, please contact the case management team.
                    </Typography>
                    <Typography variant="body1" sx={{ color: '#1A1A1A', mt: 3 }}>
                      Thank you,<br />
                      Case Management System
                    </Typography>
                  </Box>
                ) : (
                  <Box sx={{ fontFamily: 'monospace', fontSize: '0.9rem', color: '#1A1A1A' }}>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', mb: 1 }}>
                      Dear Team,
                    </Typography>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', mb: 1 }}>
                      This is an automated notification regarding case {selectedEmail.caseId} for client {selectedEmail.clientName}.
                    </Typography>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', mb: 1 }}>
                      Subject: {selectedEmail.subject}
                    </Typography>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', mb: 1 }}>
                      Please review the case details in the system and take appropriate action if needed.
                    </Typography>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', mb: 1 }}>
                      If you have any questions or concerns, please contact the case management team.
                    </Typography>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', mt: 2 }}>
                      Thank you,
                    </Typography>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
                      Case Management System
                    </Typography>
                  </Box>
                )}
              </Box>

              {/* Footer */}
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pt: 2, borderTop: '1px solid #E0E0E0' }}>
                <Typography variant="body2" sx={{ color: '#5F6368' }}>
                  <strong>Subject:</strong> {selectedEmail.subject}: {selectedEmail.caseId} - {selectedEmail.clientName}
                </Typography>
                <Button
                  variant="text"
                  startIcon={<SendIcon />}
                  sx={{
                    textTransform: 'none',
                    color: '#0047AB',
                    fontWeight: 600,
                    '&:hover': {
                      bgcolor: '#F0F7FF',
                    },
                  }}
                >
                  Resend Email
                </Button>
              </Box>
            </>
          )}
        </Box>
      </Dialog>
    </Box>
  );
}