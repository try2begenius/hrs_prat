import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  InputAdornment,
  MenuItem,
} from '@mui/material';
import { Search, FileDownload, Visibility, ArrowUpward, ArrowDownward, Business, AccountCircle, Schedule } from '@mui/icons-material';
import { mockCases } from '../data/enhancedMockData';
import { Case, UserAccess } from '../types';
import { useState } from 'react';

interface SalesOwnerWorklistProps {
  onViewCase: (caseId: string) => void;
  currentUser: UserAccess;
}

export function SalesOwnerWorklist({ onViewCase, currentUser }: SalesOwnerWorklistProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<string>('dueDate');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Filter cases for sales owner - only show cases assigned to them
  const salesCases = mockCases.filter(c =>
    c.assignedTo === currentUser.name &&
    (c.status === 'Pending Sales Review' || c.status === 'In Sales Review' || c.status === 'Sales Review Complete')
  );

  const filteredCases = salesCases.filter(c =>
    c.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          My Sales Reviews
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Cases requiring your sales context and feedback
        </Typography>
      </Box>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <TextField
              placeholder="Search by Case ID or Client Name"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              size="small"
              sx={{ flex: 1, minWidth: 300 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              select
              label="Sort By"
              value={sortField}
              onChange={(e) => setSortField(e.target.value)}
              size="small"
              sx={{ minWidth: 150 }}
            >
              <MenuItem value="dueDate">Due Date</MenuItem>
              <MenuItem value="clientName">Client Name</MenuItem>
              <MenuItem value="status">Status</MenuItem>
            </TextField>
            <Button variant="outlined" startIcon={<FileDownload />}>
              Export
            </Button>
          </Box>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">
              Sales Review Cases ({filteredCases.length})
            </Typography>
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Case ID</TableCell>
                  <TableCell>Client Name</TableCell>
                  <TableCell>LOB</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Due Date</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredCases.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} align="center">
                      <Typography variant="body2" color="text.secondary" sx={{ py: 4 }}>
                        No cases requiring sales review
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCases.map((caseItem) => (
                    <TableRow key={caseItem.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600} sx={{ fontFamily: 'monospace' }}>
                          {caseItem.id}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight={500}>
                          {caseItem.clientName}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip label={caseItem.clientData?.lineOfBusiness || 'N/A'} size="small" variant="outlined" />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={caseItem.status}
                          size="small"
                          color={
                            caseItem.status === 'Pending Sales Review' ? 'warning' :
                            caseItem.status === 'In Sales Review' ? 'info' : 'success'
                          }
                        />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <Schedule fontSize="small" color="action" />
                          <Typography variant="body2">{caseItem.dueDate}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell align="center">
                        <Button
                          size="small"
                          variant="contained"
                          startIcon={<Visibility />}
                          onClick={() => onViewCase(caseItem.id)}
                        >
                          Review
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Box>
  );
}
