import { ReactNode } from 'react';
import { ThemeProvider } from '@mui/material';
import { theme } from '@/styles/theme';

interface ThemeWrapperProps {
  children: ReactNode;
}

// This component wraps the MUI ThemeProvider to prevent Figma's data-* attributes
// from being passed down and causing prop-type warnings
export function ThemeWrapper({ children, ...rest }: ThemeWrapperProps & Record<string, any>) {
  // Explicitly only pass children to ThemeProvider
  // This filters out all Figma-specific data-fg-* attributes
  return (
    <ThemeProvider theme={theme}>
      {children}
    </ThemeProvider>
  );
}