import { Case } from '../types';

/**
 * 312 CAM Case Review Workflow Mock Data
 * Demonstrates complete workflow as per AC 5.1 (Functional): Workflow for 312 CAM case reviews
 * 
 * Case Flow Logic:
 * 1. Auto-closed cases: Status = Complete, model outcome = "312 Activity in line with expected activity"
 * 2. Not auto-closed cases flow through:
 *    - Unassigned (pending) → In Progress → Pending Sales Review → In Sales Review → 
 *    - Sales Review Complete → Complete
 * 3. Completed cases can be reopened for Defect Remediation
 * 4. Cases may have TRMS filed or client closed dispositions
 */

export const workflow312CamCases: Case[] = [
  // ============================================================================
  // AUTO-CLOSED CASE: 312 Activity in line with expected activity
  // ============================================================================
  {
    id: '312-2025-AUTO-100',
    clientId: 'GCI-AUTO-100',
    gci: 'GCI-AUTO-100',
    mpId: 'MP-10001',
    partyId: 'PTY-20001',
    coperId: 'CPR-30001',
    clientName: 'Reliable Logistics Corp',
    entityName: 'Reliable Logistics Corp',
    caseType: '312 Review',
    status: 'Complete',
    riskLevel: 'Low',
    priority: 'Low',
    assignedTo: 'System',
    createdDate: '2025-10-15',
    dueDate: '2025-11-15',
    lastActivity: '2025-10-15',
    completionDate: '2025-10-15',
    alertCount: 0,
    transactionCount: 67,
    totalAmount: 1240000,
    description: 'Auto-closed 312 review - activity aligns with expected DDQ and business profile',
    lineOfBusiness: 'GB/GM',
    is312Case: true,
    autoClosed: true,
    modelOutcome: 'No additional CAM escalation required',
    derivedDisposition: 'No additional CAM escalation required',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '484110',
    naicsDescription: 'General Freight Trucking, Local',
    refreshDueDates: ['2025-11-15'],
    lastRefreshCompletionDate: '2024-11-10',
    clientData: {
      clientId: 'GCI-AUTO-100',
      gciNumber: 'GCI-AUTO-100',
      legalName: 'Reliable Logistics Corporation',
      businessName: 'Reliable Logistics',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2018-06-15',
      clientType: 'Corporation',
      jurisdiction: 'Delaware',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-15',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 3.8,
      riskRatingDate: '2025-10-10',
      model312Score: 2.5,
      model312Flag: false,
      lastMonitoringDate: '2025-10-15'
    },
    case312Data: {
      status: 'Auto-Closed',
      dueDate: '2025-11-15',
      modelResult: 'Low Risk',
      modelResultDescription: '312 Activity in line with expected activity',
      disposition: 'No additional CAM escalation required',
      sourceOfFunds: 'Freight transportation and logistics services revenue',
      purposeOfRelationship: 'Operating account for business payments and receivables',
      expectedActivityVolume: {
        electronicTransfers: 45,
        cashChecks: 22,
        ddqFields: {
          'Domestic Wires': 30,
          'International Wires': 15,
          'ACH Transactions': 120
        }
      },
      expectedActivityValue: {
        electronicTransfers: 980000,
        cashChecks: 260000,
        ddqFields: {
          'Domestic Wires': 650000,
          'International Wires': 330000,
          'ACH Transactions': 240000
        }
      }
    }
  },

  // ============================================================================
  // UNASSIGNED - Pending Assignment in Workbasket
  // ============================================================================
  {
    id: '312-2025-UNASSIGN-200',
    clientId: 'GCI-200200',
    gci: 'GCI-200200',
    mpId: 'MP-10002',
    partyId: 'PTY-20002',
    coperId: 'CPR-30002',
    clientName: 'Global Tech Solutions Inc',
    entityName: 'Global Tech Solutions Inc',
    caseType: '312 Review',
    status: 'Unassigned',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Unassigned',
    createdDate: '2025-10-25',
    dueDate: '2025-11-25',
    lastActivity: '2025-10-25',
    alertCount: 4,
    transactionCount: 234,
    totalAmount: 5670000,
    description: '312 review triggered by DGA due date - awaiting assignment by Central Team Manager',
    lineOfBusiness: 'GB/GM',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'Pending Review',
    derivedDisposition: 'Pending',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '541512',
    naicsDescription: 'Computer Systems Design Services',
    refreshDueDates: ['2025-11-25'],
    lastRefreshCompletionDate: '2024-11-20',
    clientData: {
      clientId: 'GCI-200200',
      gciNumber: 'GCI-200200',
      legalName: 'Global Tech Solutions Incorporated',
      businessName: 'GlobalTech',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2019-04-12',
      clientType: 'Corporation',
      jurisdiction: 'California',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 6.4,
      riskRatingDate: '2025-10-20',
      model312Score: 5.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    },
    case312Data: {
      status: 'Pending',
      dueDate: '2025-11-25',
      modelResult: 'Medium Risk',
      modelResultDescription: 'Requires 312 review - activity patterns warrant analyst review',
      disposition: 'Pending',
      sourceOfFunds: 'Software development and IT consulting services',
      purposeOfRelationship: 'Business operating accounts for client payments and vendor transactions',
      expectedActivityVolume: {
        electronicTransfers: 180,
        cashChecks: 54,
        ddqFields: {
          'Domestic Wires': 120,
          'International Wires': 60,
          'ACH Transactions': 450
        }
      },
      expectedActivityValue: {
        electronicTransfers: 4200000,
        cashChecks: 1470000,
        ddqFields: {
          'Domestic Wires': 2800000,
          'International Wires': 1400000,
          'ACH Transactions': 850000
        }
      }
    }
  },

  // ============================================================================
  // IN PROGRESS - Central Team Analyst Actively Reviewing
  // ============================================================================
  {
    id: '312-2025-PROG-300',
    clientId: 'GCI-300300',
    gci: 'GCI-300300',
    mpId: 'MP-10003',
    partyId: 'PTY-20003',
    coperId: 'CPR-30003',
    clientName: 'Premier Trading Partners LLC',
    entityName: 'Premier Trading Partners LLC',
    caseType: '312 Review',
    status: 'In Progress',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Michael Chen',
    createdDate: '2025-10-18',
    dueDate: '2025-11-18',
    lastActivity: '2025-10-28',
    alertCount: 7,
    transactionCount: 412,
    totalAmount: 14500000,
    description: '312 review in progress - analyst reviewing transaction patterns and DDQ alignment',
    lineOfBusiness: 'GB/GM',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'Pending Review',
    derivedDisposition: 'Pending',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '425120',
    naicsDescription: 'Wholesale Trade Agents and Brokers',
    refreshDueDates: ['2025-11-18'],
    lastRefreshCompletionDate: '2024-11-15',
    clientData: {
      clientId: 'GCI-300300',
      gciNumber: 'GCI-300300',
      legalName: 'Premier Trading Partners Limited Liability Company',
      businessName: 'Premier Trading',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2017-09-22',
      clientType: 'LLC',
      jurisdiction: 'Delaware',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-28',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.8,
      riskRatingDate: '2025-10-18',
      model312Score: 7.2,
      model312Flag: true,
      lastMonitoringDate: '2025-10-28'
    },
    case312Data: {
      status: 'In Progress',
      dueDate: '2025-11-18',
      modelResult: 'High Risk',
      modelResultDescription: 'Significant deviation from expected activity - detailed review required',
      disposition: 'Pending',
      sourceOfFunds: 'International commodity trading and brokerage commissions',
      purposeOfRelationship: 'Transaction banking for commodity trading operations',
      expectedActivityVolume: {
        electronicTransfers: 320,
        cashChecks: 92,
        ddqFields: {
          'Domestic Wires': 180,
          'International Wires': 140,
          'ACH Transactions': 240
        }
      },
      expectedActivityValue: {
        electronicTransfers: 11200000,
        cashChecks: 3300000,
        ddqFields: {
          'Domestic Wires': 6500000,
          'International Wires': 4700000,
          'ACH Transactions': 1450000
        }
      }
    },
    monitoringDashboard: {
      trmsFLU: [
        {
          id: 'TRMS-FLU-8901',
          date: '2025-10-10',
          monitoringProcess: 'FLU Quarterly Review',
          descriptionReason: 'Increased wire transfer activity',
          impactType: 'Wire Transfer Pattern',
          narrative: 'Notable increase in international wire transfers to new beneficiaries',
          submitterLOB: 'GB/GM',
          submitterName: 'Michael Chen',
          type: 'Follow-up'
        }
      ],
      trmsOther: [],
      secondLineCases: [],
      fraudCases: [],
      sanctionDetails: [],
      alert312Details: [
        {
          alertId: 'ALT-312-5501',
          alertDate: '2025-10-15',
          alertDescription: 'Transaction volume exceeds expected DDQ parameters',
          alertType: 'Volume Anomaly'
        }
      ],
      lobMonitoringControls: [
        {
          lob: 'GBGM',
          activityName: 'GTMS Transaction Monitoring',
          activityDescription: 'Control process to automatically monitor for payments or transactions above credit limits/ balances and control via approvals or rejections to these payment / transaction',
          outcome: 'Number of Alerts: 5 Number of TRMS: 0'
        },
        {
          lob: 'PB',
          activityName: 'Admin Reviews (PB)',
          activityDescription: 'Attestation of account coding/set up to ensure alignment with client instructions',
          outcome: 'Last Date of Review: 11/15/25 Number of TRMS: 0'
        }
      ]
    }
  },

  // ============================================================================
  // PENDING SALES REVIEW - Routed to Sales, Awaiting Sales Owner to Open
  // ============================================================================
  {
    id: '312-2025-PSR-400',
    clientId: 'GCI-400400',
    gci: 'GCI-400400',
    mpId: 'MP-10004',
    partyId: 'PTY-20004',
    coperId: 'CPR-30004',
    clientName: 'Apex Capital Ventures',
    entityName: 'Apex Capital Ventures',
    caseType: '312 Review',
    status: 'Pending Sales Review',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Jennifer Wu',
    centralTeamContact: 'Jennifer Wu',
    createdDate: '2025-10-20',
    dueDate: '2025-11-20',
    lastActivity: '2025-10-27',
    alertCount: 8,
    transactionCount: 387,
    totalAmount: 18900000,
    description: '312 review routed to sales owner - awaiting input on client business context',
    lineOfBusiness: 'PB',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'Pending Review',
    derivedDisposition: 'Pending',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '523910',
    naicsDescription: 'Miscellaneous Intermediation',
    refreshDueDates: ['2025-11-20'],
    lastRefreshCompletionDate: '2024-11-18',
    clientData: {
      clientId: 'GCI-400400',
      gciNumber: 'GCI-400400',
      legalName: 'Apex Capital Ventures LP',
      businessName: 'Apex Capital',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2016-03-08',
      clientType: 'Limited Partnership',
      jurisdiction: 'New York',
      dataSource: 'CMT',
      lastUpdated: '2025-10-27',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 8.2,
      riskRatingDate: '2025-10-20',
      model312Score: 7.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-27'
    },
    case312Data: {
      status: 'Pending Sales Review',
      dueDate: '2025-11-20',
      modelResult: 'High Risk',
      modelResultDescription: 'Complex transaction patterns - sales context required',
      disposition: 'Pending',
      sourceOfFunds: 'Investment management and private equity operations',
      purposeOfRelationship: 'Capital deployment and investment transaction processing',
      purposeOfAccount: 'Private banking relationship for investment activities and portfolio management',
      expectedActivityVolume: {
        electronicTransfers: 280,
        cashChecks: 107,
        ddqFields: {
          'Domestic Wires': 200,
          'International Wires': 80,
          'ACH Transactions': 180
        }
      },
      expectedActivityValue: {
        electronicTransfers: 14500000,
        cashChecks: 4400000,
        ddqFields: {
          'Domestic Wires': 9800000,
          'International Wires': 4700000,
          'ACH Transactions': 2200000
        }
      }
    },
    caseProcessorComments: [
      {
        caseType: '312',
        processorName: 'Jennifer Wu',
        date: '2025-10-27',
        comment: 'Client shows significant increase in transaction volumes and international wire activity. Recent DDQ indicates expansion into new markets. Requesting sales owner context on business expansion plans and expected transaction patterns for next 12 months.'
      }
    ],
    salesOwnerResponse: {
      isSubmitted: false,
      comments: '',
      submittedBy: '',
      submittedDate: ''
    }
  },

  // ============================================================================
  // IN SALES REVIEW - Sales Owner Actively Reviewing
  // ============================================================================
  {
    id: '312-2025-ISR-500',
    clientId: 'GCI-500500',
    gci: 'GCI-500500',
    mpId: 'MP-10005',
    partyId: 'PTY-20005',
    coperId: 'CPR-30005',
    clientName: 'Meridian Holdings Group',
    entityName: 'Meridian Holdings Group',
    caseType: '312 Review',
    status: 'In Sales Review',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Michael Chen',
    centralTeamContact: 'Michael Chen',
    createdDate: '2025-10-22',
    dueDate: '2025-11-22',
    lastActivity: '2025-10-29',
    alertCount: 5,
    transactionCount: 298,
    totalAmount: 9800000,
    description: '312 review - sales owner reviewing and preparing response',
    lineOfBusiness: 'ML',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'Pending Review',
    derivedDisposition: 'Pending',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '551112',
    naicsDescription: 'Offices of Other Holding Companies',
    refreshDueDates: ['2025-11-22'],
    lastRefreshCompletionDate: '2024-11-20',
    clientData: {
      clientId: 'GCI-500500',
      gciNumber: 'GCI-500500',
      legalName: 'Meridian Holdings Group Inc',
      businessName: 'Meridian Holdings',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'ML',
      accountOpenDate: '2015-07-18',
      clientType: 'Corporation',
      jurisdiction: 'Delaware',
      dataSource: 'GWIM Hub',
      lastUpdated: '2025-10-29',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 6.8,
      riskRatingDate: '2025-10-22',
      model312Score: 6.4,
      model312Flag: true,
      lastMonitoringDate: '2025-10-29'
    },
    case312Data: {
      status: 'In Sales Review',
      dueDate: '2025-11-22',
      modelResult: 'Medium Risk',
      modelResultDescription: 'Transaction patterns require clarification on business purpose',
      disposition: 'Pending',
      sourceOfFunds: 'Holding company receipts from subsidiary operations',
      purposeOfAccount: 'Wealth management and liquidity management for high net worth individual',
      expectedActivityVolume: {
        electronicTransfers: 220,
        cashChecks: 78,
        ddqFields: {
          'Domestic Wires': 150,
          'International Wires': 70,
          'ACH Transactions': 320
        }
      },
      expectedActivityValue: {
        electronicTransfers: 7500000,
        cashChecks: 2300000,
        ddqFields: {
          'Domestic Wires': 5200000,
          'International Wires': 2300000,
          'ACH Transactions': 1450000
        }
      }
    },
    caseProcessorComments: [
      {
        caseType: '312',
        processorName: 'Michael Chen',
        date: '2025-10-29',
        comment: 'Client transaction activity shows pattern of large transfers between related entities. Please provide context on: 1) Recent restructuring activities, 2) Purpose of international transfers to Cayman Islands entities, 3) Expected timing of additional capital movements over next quarter.'
      }
    ],
    salesOwnerResponse: {
      isSubmitted: false,
      comments: 'Client is consolidating holdings from multiple subsidiaries as part of planned restructuring. International transfers relate to offshore investment vehicles established for tax efficiency. All activities are consistent with strategic plan reviewed in Q3 wealth advisory session.',
      submittedBy: '',
      submittedDate: ''
    }
  },

  // ============================================================================
  // SALES REVIEW COMPLETE - Returned to AML for Disposition
  // ============================================================================
  {
    id: '312-2025-SRC-600',
    clientId: 'GCI-600600',
    gci: 'GCI-600600',
    mpId: 'MP-10006',
    partyId: 'PTY-20006',
    coperId: 'CPR-30006',
    clientName: 'Sterling Investment Partners',
    entityName: 'Sterling Investment Partners',
    caseType: '312 Review',
    status: 'Sales Review Complete',
    riskLevel: 'High',
    priority: 'High',
    assignedTo: 'Jennifer Wu',
    centralTeamContact: 'Jennifer Wu',
    createdDate: '2025-10-15',
    dueDate: '2025-11-15',
    lastActivity: '2025-10-30',
    alertCount: 9,
    transactionCount: 445,
    totalAmount: 22400000,
    description: '312 review - sales owner feedback received, analyst completing final disposition',
    lineOfBusiness: 'PB',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'Pending Review',
    derivedDisposition: 'Pending',
    salesReviewComments: 'Client recently completed acquisition of European asset management firm. Large international wire transfers are related to acquisition financing and integration activities. Business expansion is consistent with strategic growth plan shared with private banking team. Recommend no escalation - transactions are expected and appropriate for client profile.',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '523920',
    naicsDescription: 'Portfolio Management',
    refreshDueDates: ['2025-11-15'],
    lastRefreshCompletionDate: '2024-11-12',
    clientData: {
      clientId: 'GCI-600600',
      gciNumber: 'GCI-600600',
      legalName: 'Sterling Investment Partners LLP',
      businessName: 'Sterling Investments',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2014-05-20',
      clientType: 'Limited Liability Partnership',
      jurisdiction: 'Delaware',
      dataSource: 'CMT',
      lastUpdated: '2025-10-30',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.9,
      riskRatingDate: '2025-10-15',
      model312Score: 7.5,
      model312Flag: true,
      lastMonitoringDate: '2025-10-30'
    },
    case312Data: {
      status: 'Sales Review Complete',
      dueDate: '2025-11-15',
      modelResult: 'High Risk',
      modelResultDescription: 'Large international transactions require business context verification',
      disposition: 'Pending',
      sourceOfFunds: 'Investment advisory fees and portfolio management income',
      purposeOfAccount: 'Operating account for investment management activities',
      expectedActivityVolume: {
        electronicTransfers: 340,
        cashChecks: 105,
        ddqFields: {
          'Domestic Wires': 220,
          'International Wires': 120,
          'ACH Transactions': 280
        }
      },
      expectedActivityValue: {
        electronicTransfers: 17200000,
        cashChecks: 5200000,
        ddqFields: {
          'Domestic Wires': 10500000,
          'International Wires': 6700000,
          'ACH Transactions': 3100000
        }
      }
    },
    caseProcessorComments: [
      {
        caseType: '312',
        processorName: 'Jennifer Wu',
        date: '2025-10-28',
        comment: 'Significant increase in international wire activity (€15.2M over 30 days) to European entities. Transactions represent 340% of expected volume. Requesting sales context on recent business developments and expected transaction profile.'
      }
    ],
    salesOwnerResponse: {
      isSubmitted: true,
      comments: 'Client recently completed acquisition of European asset management firm (Sterling Europe GmbH) in October 2025. Large international wire transfers are related to:\n\n1. Acquisition financing - €8.5M purchase price\n2. Working capital injection - €4.2M\n3. Integration costs - €2.5M\n\nAll transactions were reviewed and approved by Private Banking credit team. Business expansion is consistent with 3-year strategic growth plan shared with relationship team in June 2025. Client expects normalized transaction patterns to resume by December 2025.\n\nRecommendation: No additional escalation required - transactions are expected and appropriate for client business profile and strategic objectives.',
      submittedBy: 'David Park',
      submittedDate: '2025-10-30T14:23:00'
    }
  },

  // ============================================================================
  // COMPLETE - No Additional CAM Escalation Required (Self-Disposition)
  // ============================================================================
  {
    id: '312-2025-COMP-700',
    clientId: 'GCI-700700',
    gci: 'GCI-700700',
    mpId: 'MP-10007',
    partyId: 'PTY-20007',
    coperId: 'CPR-30007',
    clientName: 'Northeast Distribution LLC',
    entityName: 'Northeast Distribution LLC',
    caseType: '312 Review',
    status: 'Complete',
    riskLevel: 'Medium',
    priority: 'Medium',
    assignedTo: 'Michael Chen',
    createdDate: '2025-10-05',
    dueDate: '2025-11-05',
    lastActivity: '2025-10-25',
    completionDate: '2025-10-25',
    alertCount: 3,
    transactionCount: 178,
    totalAmount: 4800000,
    description: '312 review completed - activity aligns with updated DDQ, no escalation required',
    lineOfBusiness: 'GB/GM',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'No additional CAM escalation required',
    derivedDisposition: 'No additional CAM escalation required',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '424490',
    naicsDescription: 'Other Grocery and Related Products Merchant Wholesalers',
    refreshDueDates: ['2025-11-05'],
    lastRefreshCompletionDate: '2024-11-01',
    clientData: {
      clientId: 'GCI-700700',
      gciNumber: 'GCI-700700',
      legalName: 'Northeast Distribution Limited Liability Company',
      businessName: 'NE Distribution',
      salesOwner: 'Amanda Torres (RM)',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2017-02-14',
      clientType: 'LLC',
      jurisdiction: 'Massachusetts',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-25',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 5.4,
      riskRatingDate: '2025-10-05',
      model312Score: 5.1,
      model312Flag: true,
      lastMonitoringDate: '2025-10-25'
    },
    case312Data: {
      status: 'Complete',
      dueDate: '2025-11-05',
      modelResult: 'Medium Risk',
      modelResultDescription: 'Transaction patterns reviewed and found consistent with business model',
      disposition: 'No additional CAM escalation required',
      sourceOfFunds: 'Wholesale distribution sales revenue',
      purposeOfRelationship: 'Business operating accounts for wholesale distribution operations',
      expectedActivityVolume: {
        electronicTransfers: 140,
        cashChecks: 38,
        ddqFields: {
          'Domestic Wires': 100,
          'International Wires': 40,
          'ACH Transactions': 480
        }
      },
      expectedActivityValue: {
        electronicTransfers: 3600000,
        cashChecks: 1200000,
        ddqFields: {
          'Domestic Wires': 2400000,
          'International Wires': 1200000,
          'ACH Transactions': 980000
        }
      }
    },
    case312Response: {
      analystReview: 'Completed comprehensive review of transaction activity. Client activity shows seasonal increase consistent with Q4 holiday distribution cycle. All transactions align with updated DDQ provided in September 2025. No suspicious patterns identified.',
      disposition: 'No additional CAM escalation required',
      dispositionDate: '2025-10-25',
      dispositionRationale: 'Activity is consistent with client business model and updated expected activity profile. Seasonal variations are appropriate for wholesale distribution business.',
      completedBy: 'Michael Chen'
    }
  },

  // ============================================================================
  // COMPLETE - TRMS Filed (CAM Case Escalated)
  // ============================================================================
  {
    id: '312-2025-ESC-800',
    clientId: 'GCI-800800',
    gci: 'GCI-800800',
    mpId: 'MP-10008',
    partyId: 'PTY-20008',
    coperId: 'CPR-30008',
    clientName: 'Offshore Financial Services Ltd',
    entityName: 'Offshore Financial Services Ltd',
    caseType: '312 Review',
    status: 'Complete',
    riskLevel: 'Critical',
    priority: 'Urgent',
    assignedTo: 'Sarah Mitchell',
    createdDate: '2025-10-01',
    dueDate: '2025-11-01',
    lastActivity: '2025-10-22',
    completionDate: '2025-10-22',
    alertCount: 18,
    transactionCount: 678,
    totalAmount: 45800000,
    description: '312 review escalated to TRMS - suspicious structuring and layering patterns identified',
    lineOfBusiness: 'PB',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'CAM Case Escalated',
    derivedDisposition: 'TRMS Filed',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '523999',
    naicsDescription: 'Miscellaneous Financial Investment Activities',
    refreshDueDates: ['2025-11-01'],
    lastRefreshCompletionDate: '2024-10-28',
    clientData: {
      clientId: 'GCI-800800',
      gciNumber: 'GCI-800800',
      legalName: 'Offshore Financial Services Limited',
      businessName: 'OFS',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'PB',
      accountOpenDate: '2019-08-10',
      clientType: 'Corporation',
      jurisdiction: 'Cayman Islands',
      dataSource: 'CMT',
      lastUpdated: '2025-10-22',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 9.6,
      riskRatingDate: '2025-10-01',
      model312Score: 9.3,
      model312Flag: true,
      lastMonitoringDate: '2025-10-22'
    },
    case312Data: {
      status: 'Complete',
      dueDate: '2025-11-01',
      modelResult: 'Critical Risk',
      modelResultDescription: 'Significant red flags identified - immediate escalation required',
      disposition: 'TRMS Filed',
      sourceOfFunds: 'Investment advisory services (per DDQ)',
      purposeOfAccount: 'Investment transaction processing',
      expectedActivityVolume: {
        electronicTransfers: 180,
        cashChecks: 0,
        ddqFields: {
          'Domestic Wires': 80,
          'International Wires': 100,
          'ACH Transactions': 45
        }
      },
      expectedActivityValue: {
        electronicTransfers: 8500000,
        cashChecks: 0,
        ddqFields: {
          'Domestic Wires': 3500000,
          'International Wires': 5000000,
          'ACH Transactions': 450000
        }
      }
    },
    case312Response: {
      analystReview: 'Comprehensive review identified multiple red flags including: 1) Transaction volumes 540% above expected, 2) Systematic structuring below reporting thresholds, 3) Rapid movement of funds through multiple jurisdictions (layering), 4) Beneficiary names inconsistent with stated business purpose, 5) Client non-responsive to DDQ update requests.',
      disposition: 'TRMS Filed',
      dispositionDate: '2025-10-22',
      dispositionRationale: 'Pattern of activity is inconsistent with legitimate business operations and shows hallmarks of money laundering including structuring, layering, and integration. TRMS case filed for enhanced investigation.',
      completedBy: 'Sarah Mitchell'
    },
    trmsCase: {
      caseId: 'TRMS-2025-8234',
      caseType: 'Enhanced Due Diligence - AML',
      openDate: '2025-10-22',
      status: 'Open',
      priority: 'Critical',
      dueDate: '2025-11-22'
    },
    camCaseData: {
      status: 'Complete',
      disposition: 'TRMS Filed',
      dispositionDate: '2025-10-22',
      triggers: ['Unusual Transaction Pattern', 'Structuring Indicators', 'Layering Activity', 'Jurisdiction Risk'],
      sarRecommendation: 'Yes - SAR filing recommended based on investigation findings'
    }
  },

  // ============================================================================
  // COMPLETE - Client Closed (Relationship Terminated)
  // ============================================================================
  {
    id: '312-2025-ESC-900',
    clientId: 'GCI-900900',
    gci: 'GCI-900900',
    mpId: 'MP-10009',
    partyId: 'PTY-20009',
    coperId: 'CPR-30009',
    clientName: 'High Risk Trading Corp',
    entityName: 'High Risk Trading Corp',
    caseType: '312 Review',
    status: 'Complete',
    riskLevel: 'Critical',
    priority: 'Urgent',
    assignedTo: 'Carlos Rivera',
    createdDate: '2025-09-28',
    dueDate: '2025-10-28',
    lastActivity: '2025-10-20',
    completionDate: '2025-10-20',
    alertCount: 22,
    transactionCount: 892,
    totalAmount: 67200000,
    description: '312 review resulted in client relationship termination - unacceptable risk profile',
    lineOfBusiness: 'GB/GM',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'CAM Case Escalated',
    derivedDisposition: 'Client Closed',
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '425110',
    naicsDescription: 'Business to Business Electronic Markets',
    refreshDueDates: ['2025-10-28'],
    lastRefreshCompletionDate: '2024-10-25',
    clientData: {
      clientId: 'GCI-900900',
      gciNumber: 'GCI-900900',
      legalName: 'High Risk Trading Corporation',
      businessName: 'HRT Corp',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2020-11-05',
      clientType: 'Corporation',
      jurisdiction: 'Panama',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-20',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 9.9,
      riskRatingDate: '2025-09-28',
      model312Score: 9.7,
      model312Flag: true,
      lastMonitoringDate: '2025-10-20'
    },
    case312Data: {
      status: 'Complete',
      dueDate: '2025-10-28',
      modelResult: 'Critical Risk',
      modelResultDescription: 'Client risk profile exceeds acceptable thresholds',
      disposition: 'Client Closed',
      sourceOfFunds: 'E-commerce trading platform (per DDQ)',
      purposeOfRelationship: 'Payment processing and working capital',
      expectedActivityVolume: {
        electronicTransfers: 220,
        cashChecks: 15,
        ddqFields: {
          'Domestic Wires': 120,
          'International Wires': 100,
          'ACH Transactions': 380
        }
      },
      expectedActivityValue: {
        electronicTransfers: 12000000,
        cashChecks: 500000,
        ddqFields: {
          'Domestic Wires': 6000000,
          'International Wires': 6000000,
          'ACH Transactions': 2800000
        }
      }
    },
    case312Response: {
      analystReview: 'Investigation revealed: 1) Client business model changed significantly without notification, 2) Unable to verify legitimacy of stated business operations, 3) Transaction activity 560% above expected volumes, 4) Multiple adverse media hits related to sanctions evasion, 5) Client unresponsive to information requests, 6) Enhanced due diligence unable to resolve concerns.',
      disposition: 'Client Closed',
      dispositionDate: '2025-10-20',
      dispositionRationale: 'Client risk profile exceeds risk appetite. Unable to verify legitimate business purpose. Relationship terminated per enterprise-wide risk assessment. Exit process initiated.',
      completedBy: 'Carlos Rivera'
    },
    camCaseData: {
      status: 'Complete',
      disposition: 'Client Closed',
      dispositionDate: '2025-10-20',
      triggers: ['Reputational Risk', 'Sanctions Concerns', 'Unable to Verify Business Model', 'Non-Responsive Client'],
      sarRecommendation: 'Filed prior to exit',
      exitDate: '2025-10-20'
    },
    sarData: {
      sarFiled: true,
      sarId: 'SAR-2025-4567',
      sarFilingDate: '2025-10-18',
      sarType: 'Suspicious Activity - Money Laundering',
      sarAmount: 67200000
    }
  },

  // ============================================================================
  // DEFECT REMEDIATION - Case Reopened for M&I Quality Review
  // ============================================================================
  {
    id: '312-2025-REM-1000',
    clientId: 'GCI-101010',
    gci: 'GCI-101010',
    mpId: 'MP-10010',
    partyId: 'PTY-20010',
    coperId: 'CPR-30010',
    clientName: 'Pacific Rim Imports Inc',
    entityName: 'Pacific Rim Imports Inc',
    caseType: '312 Review',
    status: 'Defect Remediation',
    riskLevel: 'High',
    priority: 'Urgent',
    assignedTo: 'Jennifer Wu',
    createdDate: '2025-09-10',
    dueDate: '2025-10-10',
    lastActivity: '2025-10-30',
    originalCompletionDate: '2025-10-08',
    alertCount: 6,
    transactionCount: 334,
    totalAmount: 11400000,
    description: '312 review reopened - M&I identified missing documentation in original case file',
    lineOfBusiness: 'GB/GM',
    is312Case: true,
    autoClosed: false,
    modelOutcome: 'No additional CAM escalation required',
    derivedDisposition: 'No additional CAM escalation required',
    defectRemediationFlag: true,
    isBACEmployee: false,
    isBACAffiliate: false,
    isRegO: false,
    isManuallyTriggered: false,
    naicsCode: '423140',
    naicsDescription: 'Motor Vehicle Parts (Used) Merchant Wholesalers',
    refreshDueDates: ['2025-10-10'],
    lastRefreshCompletionDate: '2024-10-05',
    clientData: {
      clientId: 'GCI-101010',
      gciNumber: 'GCI-101010',
      legalName: 'Pacific Rim Imports Incorporated',
      businessName: 'PRI',
      salesOwner: 'David Park (RM)',
      lineOfBusiness: 'GB/GM',
      accountOpenDate: '2016-12-20',
      clientType: 'Corporation',
      jurisdiction: 'California',
      dataSource: 'Cesium',
      lastUpdated: '2025-10-30',
      isEmployee: false
    },
    monitoringData: {
      dynamicRiskRating: 7.2,
      riskRatingDate: '2025-09-10',
      model312Score: 6.9,
      model312Flag: true,
      lastMonitoringDate: '2025-10-30'
    },
    case312Data: {
      status: 'Defect Remediation',
      dueDate: '2025-10-10',
      modelResult: 'High Risk',
      modelResultDescription: 'Requires enhanced documentation and verification',
      disposition: 'No additional CAM escalation required',
      sourceOfFunds: 'Automotive parts import and distribution',
      purposeOfRelationship: 'International trade finance and payment processing',
      expectedActivityVolume: {
        electronicTransfers: 260,
        cashChecks: 74,
        ddqFields: {
          'Domestic Wires': 140,
          'International Wires': 120,
          'ACH Transactions': 420
        }
      },
      expectedActivityValue: {
        electronicTransfers: 8900000,
        cashChecks: 2500000,
        ddqFields: {
          'Domestic Wires': 4200000,
          'International Wires': 4700000,
          'ACH Transactions': 1850000
        }
      }
    },
    case312Response: {
      analystReview: 'Original review completed 10/8/2025. M&I quality review identified missing source of funds verification for international wire transfers. Reopened for remediation to obtain and document additional supporting evidence.',
      disposition: 'No additional CAM escalation required',
      dispositionDate: '2025-10-08',
      dispositionRationale: 'Activity is consistent with import business model. International transfers align with trade documentation.',
      completedBy: 'Jennifer Wu',
      remediationNotes: 'Obtained additional documentation: 1) Trade invoices for sample international transfers, 2) Updated source of funds attestation from client, 3) Verification of counterparty relationships. All documentation supports original disposition.'
    }
  }
];