import { Activity } from '../types';

/**
 * Case Flow Activity Examples
 * Demonstrating activities for each status transition
 */

export const caseFlowActivities: Activity[] = [
  // Auto-Closed Case Activities
  {
    id: 'ACT-AUTO-001',
    caseId: '312-2025-AUTO-001',
    type: 'Case Created',
    description: 'Case auto-created by system - 312 review triggered',
    user: 'System',
    timestamp: '2025-10-20T08:00:00'
  },
  {
    id: 'ACT-AUTO-002',
    caseId: '312-2025-AUTO-001',
    type: 'Auto-Closed',
    description: 'Case auto-closed - 312 activity in line with expected activity',
    user: 'System',
    timestamp: '2025-10-20T08:00:05'
  },

  // Unassigned Case Activities
  {
    id: 'ACT-UNASSIGN-001',
    caseId: '312-2025-UNASSIGN-001',
    type: 'Case Created',
    description: 'Case created and placed in workbasket - DGA due date trigger',
    user: 'System',
    timestamp: '2025-10-26T09:15:00'
  },

  // In Progress Case Activities
  {
    id: 'ACT-001-001',
    caseId: '312-2025-001',
    type: 'Case Created',
    description: 'Case created for 312 review - DGA due date approaching',
    user: 'System',
    timestamp: '2025-10-15T10:30:00'
  },
  {
    id: 'ACT-001-002',
    caseId: '312-2025-001',
    type: 'Case Assigned',
    description: 'Case assigned to Sarah Mitchell',
    user: 'System',
    timestamp: '2025-10-15T11:00:00'
  },
  {
    id: 'ACT-001-003',
    caseId: '312-2025-001',
    type: 'Status Changed',
    description: 'Status changed from Unassigned to In Progress',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-15T11:05:00'
  },
  {
    id: 'ACT-001-004',
    caseId: '312-2025-001',
    type: 'Comment Added',
    description: 'Initial review: Client shows structured transactions and offshore activity. Reviewing transaction patterns.',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-16T14:22:00'
  },
  {
    id: 'ACT-001-005',
    caseId: '312-2025-001',
    type: 'Data Accessed',
    description: 'Reviewed ORRCA risk rating (8.7) and 312 model score (8.5)',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-17T09:45:00'
  },
  {
    id: 'ACT-001-006',
    caseId: '312-2025-001',
    type: 'Comment Added',
    description: 'Need to review with sales owner for context on recent large transactions',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-26T10:15:00'
  },

  // Pending Sales Review Activities
  {
    id: 'ACT-SALES-001-001',
    caseId: '312-2025-SALES-001',
    type: 'Case Created',
    description: 'Case created for 312 review',
    user: 'System',
    timestamp: '2025-10-22T08:30:00'
  },
  {
    id: 'ACT-SALES-001-002',
    caseId: '312-2025-SALES-001',
    type: 'Case Assigned',
    description: 'Case assigned to Michael Chen',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-22T09:00:00'
  },
  {
    id: 'ACT-SALES-001-003',
    caseId: '312-2025-SALES-001',
    type: 'Status Changed',
    description: 'Status changed from Unassigned to In Progress',
    user: 'Michael Chen',
    timestamp: '2025-10-22T09:15:00'
  },
  {
    id: 'ACT-SALES-001-004',
    caseId: '312-2025-SALES-001',
    type: 'Comment Added',
    description: 'Identified unusual transaction patterns requiring sales owner input',
    user: 'Michael Chen',
    timestamp: '2025-10-24T11:30:00'
  },
  {
    id: 'ACT-SALES-001-005',
    caseId: '312-2025-SALES-001',
    type: 'Status Changed',
    description: 'Status changed from In Progress to Pending Sales Review - Routed to David Park',
    user: 'Michael Chen',
    timestamp: '2025-10-25T14:00:00'
  },

  // In Sales Review Activities
  {
    id: 'ACT-SALES-002-001',
    caseId: '312-2025-SALES-002',
    type: 'Case Created',
    description: 'Case created for 312 review',
    user: 'System',
    timestamp: '2025-10-20T07:45:00'
  },
  {
    id: 'ACT-SALES-002-002',
    caseId: '312-2025-SALES-002',
    type: 'Case Assigned',
    description: 'Case self-selected from workbasket',
    user: 'Jennifer Wu',
    timestamp: '2025-10-20T08:00:00'
  },
  {
    id: 'ACT-SALES-002-003',
    caseId: '312-2025-SALES-002',
    type: 'Status Changed',
    description: 'Status changed from Unassigned to In Progress',
    user: 'Jennifer Wu',
    timestamp: '2025-10-20T08:05:00'
  },
  {
    id: 'ACT-SALES-002-004',
    caseId: '312-2025-SALES-002',
    type: 'Status Changed',
    description: 'Status changed from In Progress to Pending Sales Review - Routed to David Park',
    user: 'Jennifer Wu',
    timestamp: '2025-10-23T15:30:00'
  },
  {
    id: 'ACT-SALES-002-005',
    caseId: '312-2025-SALES-002',
    type: 'Status Changed',
    description: 'Status changed from Pending Sales Review to In Sales Review - Sales owner opened case',
    user: 'David Park',
    timestamp: '2025-10-26T09:00:00'
  },
  {
    id: 'ACT-SALES-002-006',
    caseId: '312-2025-SALES-002',
    type: 'Comment Added',
    description: 'Reviewing client relationship and transaction context',
    user: 'David Park',
    timestamp: '2025-10-26T09:30:00'
  },

  // Sales Review Complete Activities
  {
    id: 'ACT-SALES-003-001',
    caseId: '312-2025-SALES-003',
    type: 'Case Created',
    description: 'Case created for 312 review',
    user: 'System',
    timestamp: '2025-10-18T08:00:00'
  },
  {
    id: 'ACT-SALES-003-002',
    caseId: '312-2025-SALES-003',
    type: 'Case Assigned',
    description: 'Case assigned to Michael Chen',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-18T08:30:00'
  },
  {
    id: 'ACT-SALES-003-003',
    caseId: '312-2025-SALES-003',
    type: 'Status Changed',
    description: 'Status changed from Unassigned to In Progress',
    user: 'Michael Chen',
    timestamp: '2025-10-18T09:00:00'
  },
  {
    id: 'ACT-SALES-003-004',
    caseId: '312-2025-SALES-003',
    type: 'Status Changed',
    description: 'Status changed from In Progress to Pending Sales Review',
    user: 'Michael Chen',
    timestamp: '2025-10-22T14:15:00'
  },
  {
    id: 'ACT-SALES-003-005',
    caseId: '312-2025-SALES-003',
    type: 'Status Changed',
    description: 'Status changed from Pending Sales Review to In Sales Review',
    user: 'David Park',
    timestamp: '2025-10-24T10:00:00'
  },
  {
    id: 'ACT-SALES-003-006',
    caseId: '312-2025-SALES-003',
    type: 'Sales Review',
    description: 'Sales feedback: Client is expanding operations into new markets. Transactions align with business strategy discussed in quarterly reviews. No concerns from relationship management perspective.',
    user: 'David Park',
    timestamp: '2025-10-25T16:30:00'
  },
  {
    id: 'ACT-SALES-003-007',
    caseId: '312-2025-SALES-003',
    type: 'Status Changed',
    description: 'Status changed from In Sales Review to Sales Review Complete - Returned to analyst',
    user: 'David Park',
    timestamp: '2025-10-25T16:35:00'
  },
  {
    id: 'ACT-SALES-003-008',
    caseId: '312-2025-SALES-003',
    type: 'Comment Added',
    description: 'Reviewing sales feedback for final disposition',
    user: 'Michael Chen',
    timestamp: '2025-10-26T09:00:00'
  },

  // Completed - No Action Required
  {
    id: 'ACT-COMP-001-001',
    caseId: '312-2025-COMP-001',
    type: 'Case Created',
    description: 'Case created for 312 review',
    user: 'System',
    timestamp: '2025-10-10T08:00:00'
  },
  {
    id: 'ACT-COMP-001-002',
    caseId: '312-2025-COMP-001',
    type: 'Case Assigned',
    description: 'Case assigned to Michael Chen',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-10T08:30:00'
  },
  {
    id: 'ACT-COMP-001-003',
    caseId: '312-2025-COMP-001',
    type: 'Status Changed',
    description: 'Status changed from Unassigned to In Progress',
    user: 'Michael Chen',
    timestamp: '2025-10-10T09:00:00'
  },
  {
    id: 'ACT-COMP-001-004',
    caseId: '312-2025-COMP-001',
    type: 'Comment Added',
    description: 'Reviewed client data, ORRCA rating, and transaction patterns',
    user: 'Michael Chen',
    timestamp: '2025-10-15T14:20:00'
  },
  {
    id: 'ACT-COMP-001-005',
    caseId: '312-2025-COMP-001',
    type: 'Comment Added',
    description: 'Activity consistent with expected business patterns. No anomalies identified.',
    user: 'Michael Chen',
    timestamp: '2025-10-24T10:45:00'
  },
  {
    id: 'ACT-COMP-001-006',
    caseId: '312-2025-COMP-001',
    type: 'Case Dispositioned',
    description: 'Disposition: No Action Required - 312 Activity in line with expected activity',
    user: 'Michael Chen',
    timestamp: '2025-10-24T11:00:00'
  },
  {
    id: 'ACT-COMP-001-007',
    caseId: '312-2025-COMP-001',
    type: 'Status Changed',
    description: 'Status changed from In Progress to Complete',
    user: 'Michael Chen',
    timestamp: '2025-10-24T11:05:00'
  },

  // Completed - TRMS Filed
  {
    id: 'ACT-ESC-001-001',
    caseId: '312-2025-ESC-001',
    type: 'Case Created',
    description: 'Case created for 312 review - High risk flags',
    user: 'System',
    timestamp: '2025-10-05T08:00:00'
  },
  {
    id: 'ACT-ESC-001-002',
    caseId: '312-2025-ESC-001',
    type: 'Case Assigned',
    description: 'Case assigned to Sarah Mitchell - Critical priority',
    user: 'System',
    timestamp: '2025-10-05T08:05:00'
  },
  {
    id: 'ACT-ESC-001-003',
    caseId: '312-2025-ESC-001',
    type: 'Status Changed',
    description: 'Status changed from Unassigned to In Progress',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-05T09:00:00'
  },
  {
    id: 'ACT-ESC-001-004',
    caseId: '312-2025-ESC-001',
    type: 'Alert Reviewed',
    description: 'Reviewed 15 alerts including structuring and high-risk jurisdiction flags',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-08T11:30:00'
  },
  {
    id: 'ACT-ESC-001-005',
    caseId: '312-2025-ESC-001',
    type: 'Comment Added',
    description: 'Identified suspicious structuring patterns consistent with money laundering typologies',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-15T14:45:00'
  },
  {
    id: 'ACT-ESC-001-006',
    caseId: '312-2025-ESC-001',
    type: 'Escalation',
    description: 'Case escalated - TRMS case filed: TRMS-2025-1234',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-19T10:00:00'
  },
  {
    id: 'ACT-ESC-001-007',
    caseId: '312-2025-ESC-001',
    type: 'Case Dispositioned',
    description: 'Disposition: TRMS Filed - 312 Activity Escalated',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-19T10:15:00'
  },
  {
    id: 'ACT-ESC-001-008',
    caseId: '312-2025-ESC-001',
    type: 'Status Changed',
    description: 'Status changed from In Progress to Complete',
    user: 'Sarah Mitchell',
    timestamp: '2025-10-19T10:20:00'
  },

  // Defect Remediation
  {
    id: 'ACT-REM-001-001',
    caseId: '312-2025-REM-001',
    type: 'Case Created',
    description: 'Case created for 312 review',
    user: 'System',
    timestamp: '2025-09-15T08:00:00'
  },
  {
    id: 'ACT-REM-001-002',
    caseId: '312-2025-REM-001',
    type: 'Case Assigned',
    description: 'Case self-selected from workbasket',
    user: 'Jennifer Wu',
    timestamp: '2025-09-15T09:00:00'
  },
  {
    id: 'ACT-REM-001-003',
    caseId: '312-2025-REM-001',
    type: 'Status Changed',
    description: 'Status changed from Unassigned to In Progress',
    user: 'Jennifer Wu',
    timestamp: '2025-09-15T09:05:00'
  },
  {
    id: 'ACT-REM-001-004',
    caseId: '312-2025-REM-001',
    type: 'Case Dispositioned',
    description: 'Disposition: No Action Required - 312 Activity in line with expected activity',
    user: 'Jennifer Wu',
    timestamp: '2025-09-28T14:30:00'
  },
  {
    id: 'ACT-REM-001-005',
    caseId: '312-2025-REM-001',
    type: 'Status Changed',
    description: 'Status changed from In Progress to Complete',
    user: 'Jennifer Wu',
    timestamp: '2025-09-28T14:35:00'
  },
  {
    id: 'ACT-REM-001-006',
    caseId: '312-2025-REM-001',
    type: 'Quality Review',
    description: 'M&I quality review identified missing documentation',
    user: 'Michael Chen',
    timestamp: '2025-10-15T10:00:00'
  },
  {
    id: 'ACT-REM-001-007',
    caseId: '312-2025-REM-001',
    type: 'Case Reopened',
    description: 'Case reopened for defect remediation by M&I entitled analyst - Additional documentation required',
    user: 'Michael Chen',
    timestamp: '2025-10-15T10:30:00'
  },
  {
    id: 'ACT-REM-001-008',
    caseId: '312-2025-REM-001',
    type: 'Status Changed',
    description: 'Status changed from Complete to Defect Remediation (Original completion: 2025-09-28)',
    user: 'System',
    timestamp: '2025-10-15T10:30:05'
  },
  {
    id: 'ACT-REM-001-009',
    caseId: '312-2025-REM-001',
    type: 'Case Reassigned',
    description: 'Case reassigned to Jennifer Wu (M&I entitled analyst) for remediation',
    user: 'Michael Chen',
    timestamp: '2025-10-15T10:35:00'
  },
  {
    id: 'ACT-REM-001-010',
    caseId: '312-2025-REM-001',
    type: 'Comment Added',
    description: 'Working on remediation - gathering additional documentation',
    user: 'Jennifer Wu',
    timestamp: '2025-10-26T09:00:00'
  }
];
