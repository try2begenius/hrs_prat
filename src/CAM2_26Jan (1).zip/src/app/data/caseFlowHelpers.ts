import { Case, LineOfBusiness } from '../types';

/**
 * Helper functions for case flow logic
 */

/**
 * Check if sales review is available for a given Line of Business
 * Sales review is NOT available for CI (Corporate & Institutional) and Consumer LOBs
 */
export function isSalesReviewAvailable(lineOfBusiness?: LineOfBusiness): boolean {
  if (!lineOfBusiness) return true; // Default to true if LOB not specified
  
  // Sales review NOT available for CI and Consumer
  const restrictedLOBs: LineOfBusiness[] = ['CI', 'Consumer'];
  return !restrictedLOBs.includes(lineOfBusiness);
}

/**
 * Check if a case can be routed to sales review
 */
export function canRouteToSalesReview(caseData: Case): boolean {
  // Must be in In Progress status
  if (caseData.status !== 'In Progress') return false;
  
  // Check if LOB allows sales review
  return isSalesReviewAvailable(caseData.lineOfBusiness);
}

/**
 * Get disposition text based on escalation status
 */
export function getDispositionText(escalated: boolean, trmsField?: boolean, clientClosed?: boolean): string {
  if (escalated) {
    if (trmsField) return 'CAM Case Escalated - TRMS Filed';
    if (clientClosed) return 'CAM Case Escalated - Client Closed';
    return 'CAM Case Escalated';
  }
  return 'No additional CAM escalation required';
}

/**
 * Get model outcome based on case disposition
 */
export function getModelOutcome(autoClosed: boolean, escalated: boolean): string {
  if (autoClosed) {
    return 'No additional CAM escalation required';
  }
  
  if (escalated) {
    return 'CAM Case Escalated';
  }
  
  return 'No additional CAM escalation required';
}

/**
 * Validate if a user can progress a case to a specific status
 */
export function canProgressCaseStatus(
  currentStatus: string,
  targetStatus: string,
  userRole: string,
  hasM_I_Entitlement: boolean = false
): { allowed: boolean; reason?: string } {
  // Unassigned → In Progress
  if (currentStatus === 'Unassigned' && targetStatus === 'In Progress') {
    if (userRole === 'Analyst' || userRole === 'Manager') {
      return { allowed: true };
    }
    return { allowed: false, reason: 'Only analysts and managers can start cases' };
  }
  
  // In Progress → Pending Sales Review
  if (currentStatus === 'In Progress' && targetStatus === 'Pending Sales Review') {
    if (userRole === 'Analyst') {
      return { allowed: true };
    }
    return { allowed: false, reason: 'Only analysts can route to sales review' };
  }
  
  // In Progress → Complete
  if (currentStatus === 'In Progress' && targetStatus === 'Complete') {
    if (userRole === 'Analyst') {
      return { allowed: true };
    }
    return { allowed: false, reason: 'Only analysts can complete cases' };
  }
  
  // Pending Sales Review → In Sales Review
  if (currentStatus === 'Pending Sales Review' && targetStatus === 'In Sales Review') {
    // Sales Owner opens the case
    // In real implementation, check if user is the assigned sales owner
    return { allowed: true };
  }
  
  // In Sales Review → Sales Review Complete
  if (currentStatus === 'In Sales Review' && targetStatus === 'Sales Review Complete') {
    // Sales Owner completes review
    return { allowed: true };
  }
  
  // Sales Review Complete → Complete
  if (currentStatus === 'Sales Review Complete' && targetStatus === 'Complete') {
    if (userRole === 'Analyst') {
      return { allowed: true };
    }
    return { allowed: false, reason: 'Only analysts can complete cases' };
  }
  
  // Complete → Defect Remediation
  if (currentStatus === 'Complete' && targetStatus === 'Defect Remediation') {
    if (hasM_I_Entitlement) {
      return { allowed: true };
    }
    return { allowed: false, reason: 'M&I entitlement required to reopen cases' };
  }
  
  // Defect Remediation → Complete
  if (currentStatus === 'Defect Remediation' && targetStatus === 'Complete') {
    if (hasM_I_Entitlement) {
      return { allowed: true };
    }
    return { allowed: false, reason: 'M&I entitlement required to complete remediation' };
  }
  
  return { allowed: false, reason: 'Invalid status transition' };
}

/**
 * Get available actions for a case based on current status and user permissions
 */
export function getAvailableActions(
  caseData: Case,
  userRole: string,
  hasM_I_Entitlement: boolean = false
): string[] {
  const actions: string[] = [];
  
  switch (caseData.status) {
    case 'Unassigned':
      if (userRole === 'Manager') {
        actions.push('Assign to Analyst');
      }
      if (userRole === 'Analyst') {
        actions.push('Start Case');
      }
      break;
      
    case 'In Progress':
      if (userRole === 'Analyst') {
        actions.push('Complete Case');
        if (isSalesReviewAvailable(caseData.lineOfBusiness)) {
          actions.push('Route to Sales');
        }
      }
      break;
      
    case 'Pending Sales Review':
      // Sales owner can open the case
      actions.push('Open Case');
      break;
      
    case 'In Sales Review':
      // Sales owner can complete review
      actions.push('Complete Review');
      break;
      
    case 'Sales Review Complete':
      if (userRole === 'Analyst') {
        actions.push('Complete Case');
      }
      break;
      
    case 'Complete':
      if (hasM_I_Entitlement) {
        actions.push('Reopen for Remediation');
      }
      break;
      
    case 'Defect Remediation':
      if (hasM_I_Entitlement) {
        actions.push('Complete Remediation');
      }
      break;
  }
  
  return actions;
}

/**
 * Format LOB for display
 */
export function formatLOB(lob?: LineOfBusiness): string {
  if (!lob) return 'Not specified';
  
  const lobMap: Record<LineOfBusiness, string> = {
    'GB/GM': 'Global Banking / Global Markets',
    'PB': 'Private Bank',
    'ML': 'Merrill Lynch',
    'Consumer': 'Consumer Banking',
    'CI': 'Corporate & Institutional'
  };
  
  return lobMap[lob] || lob;
}
