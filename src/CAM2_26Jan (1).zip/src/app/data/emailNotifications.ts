export interface EmailNotification {
  id: string;
  caseId: string;
  recipient: string;
  recipientEmail: string;
  recipientRole: string;
  subject: string;
  body: string;
  sentDate: string;
  sentBy: string;
  status: 'Sent' | 'Pending' | 'Failed';
  emailType: 'case_assignment' | 'review_request' | 'status_update' | 'reminder';
}

export const mockSentEmails: EmailNotification[] = [
  {
    id: 'EMAIL-001',
    caseId: 'CASE-2026-001',
    recipient: 'David Chen',
    recipientEmail: 'david.chen@bofa.com',
    recipientRole: 'Central Team Analyst',
    subject: 'Case Assignment: CASE-2026-001 - Acme Corporation',
    body: `Dear David,

You have been assigned to case CASE-2026-001 for Acme Corporation.

Case Details:
- Client: Acme Corporation
- Case Type: 312 Review
- Priority: High
- Due Date: January 29, 2026
- Risk Score: 85

Please review the case details in the CAM Platform and begin your analysis.

Best regards,
CAM Platform System`,
    sentDate: '2026-01-15 10:30 AM',
    sentBy: 'System',
    status: 'Sent',
    emailType: 'case_assignment'
  },
  {
    id: 'EMAIL-002',
    caseId: 'CASE-2026-002',
    recipient: 'Jennifer Torres',
    recipientEmail: 'jennifer.torres@bofa.com',
    recipientRole: 'CAM Analyst',
    subject: 'CAM Review Request: CASE-2026-002 - Global Tech Industries',
    body: `Dear Jennifer,

A CAM review is required for case CASE-2026-002.

Case Details:
- Client: Global Tech Industries
- Case Type: CAM Review
- Priority: Medium
- Due Date: January 30, 2026
- Risk Score: 72

Please access the CAM section in the case details to complete your review.

Best regards,
CAM Platform System`,
    sentDate: '2026-01-16 09:15 AM',
    sentBy: 'System',
    status: 'Sent',
    emailType: 'review_request'
  },
  {
    id: 'EMAIL-003',
    caseId: 'CASE-2026-001',
    recipient: 'Michael Roberts',
    recipientEmail: 'michael.roberts@bofa.com',
    recipientRole: 'Sales Owner',
    subject: 'Sales Review Required: CASE-2026-001 - Acme Corporation',
    body: `Dear Michael,

Your input is needed for case CASE-2026-001 involving your client Acme Corporation.

Case Details:
- Client: Acme Corporation
- Case Type: 312 Review
- Priority: High
- Due Date: January 29, 2026

Please review the flagged transactions and provide your sales perspective in the Sales Review section.

Best regards,
CAM Platform System`,
    sentDate: '2026-01-15 02:45 PM',
    sentBy: 'System',
    status: 'Sent',
    emailType: 'review_request'
  },
  {
    id: 'EMAIL-004',
    caseId: 'CASE-2026-005',
    recipient: 'David Chen',
    recipientEmail: 'david.chen@bofa.com',
    recipientRole: 'Central Team Analyst',
    subject: 'Case Status Update: CASE-2026-005 - Metropolitan Holdings',
    body: `Dear David,

The status of case CASE-2026-005 has been updated.

Previous Status: Pending Review
New Status: In Progress

The Section 312 review has been completed. Please proceed with the remaining case analysis.

Best regards,
CAM Platform System`,
    sentDate: '2026-01-20 11:20 AM',
    sentBy: 'System',
    status: 'Sent',
    emailType: 'status_update'
  },
  {
    id: 'EMAIL-005',
    caseId: 'CASE-2026-001',
    recipient: 'David Chen',
    recipientEmail: 'david.chen@bofa.com',
    recipientRole: 'Central Team Analyst',
    subject: 'Reminder: Case Due Soon - CASE-2026-001',
    body: `Dear David,

This is a reminder that case CASE-2026-001 is due in 3 days.

Case Details:
- Client: Acme Corporation
- Due Date: January 29, 2026
- Current Status: In Progress
- Priority: High

Please ensure the case is completed before the due date.

Best regards,
CAM Platform System`,
    sentDate: '2026-01-22 08:00 AM',
    sentBy: 'System',
    status: 'Sent',
    emailType: 'reminder'
  },
  {
    id: 'EMAIL-006',
    caseId: 'CASE-2026-006',
    recipient: 'Jennifer Torres',
    recipientEmail: 'jennifer.torres@bofa.com',
    recipientRole: 'CAM Analyst',
    subject: 'Case Assignment: CASE-2026-006 - Nexus Financial Group',
    body: `Dear Jennifer,

You have been assigned to case CASE-2026-006 for Nexus Financial Group.

Case Details:
- Client: Nexus Financial Group
- Case Type: 312 & CAM Review
- Priority: High
- Due Date: February 2, 2026
- Risk Score: 88

This case involves a politically exposed person (PEP) and requires enhanced due diligence.

Best regards,
CAM Platform System`,
    sentDate: '2026-01-19 01:30 PM',
    sentBy: 'System',
    status: 'Sent',
    emailType: 'case_assignment'
  }
];
