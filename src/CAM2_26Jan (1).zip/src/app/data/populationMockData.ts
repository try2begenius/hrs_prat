export interface ClientForPopulation {
  id: string;
  legalName: string;
  clientId: string;
  gciNumber: string;
  coPerId: string;
  lob: 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI';
  fluSystem: 'Cesium' | 'CMT' | 'CP' | 'WCC';
  employeeAffiliate: boolean;
  salesOwner: string;
  status: 'Active' | 'Closed';
  
  // Risk
  riskRating: 'High' | 'Elevated' | 'Standard' | 'Low';
  
  // 312 Criteria
  has312Flag: boolean;
  dgaDueDate?: string;
  familyAnniversaryDate?: string;
  daysToFamilyAnniversary?: number;
  refreshDueDate: string;
  daysToRefresh: number;
  hasPVT?: boolean;
  manuallyIdentified312?: boolean;
  
  // Population Results
  in312Population: boolean;
  inCAMPopulation: boolean;
  cam312Reason?: string;
  camReason?: string;
  exclusionReason?: string;
}

export const mockClientsForPopulation: ClientForPopulation[] = [
  // GB/GM High Risk - 312 Population (DGA Due Date)
  {
    id: 'POP-001',
    legalName: 'Transcontinental Holdings LLC',
    clientId: 'TH-992341',
    gciNumber: 'GCI-POP-001',
    coPerId: 'CP-001-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'Sarah Mitchell',
    status: 'Active',
    riskRating: 'High',
    has312Flag: true,
    dgaDueDate: '2025-03-15',
    refreshDueDate: '2025-03-15',
    daysToRefresh: 138,
    in312Population: true,
    inCAMPopulation: true,
    cam312Reason: 'GB/GM High Risk with DGA Due Date and 312 flag',
    camReason: 'High risk client in active status'
  },
  
  // GB/GM Elevated - 312 Population (Family Anniversary)
  {
    id: 'POP-002',
    legalName: 'Apex Global Trading Corp',
    clientId: 'AGT-445567',
    gciNumber: 'GCI-POP-002',
    coPerId: 'CP-002-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'Michael Chen',
    status: 'Active',
    riskRating: 'Elevated',
    has312Flag: true,
    familyAnniversaryDate: '2025-04-10',
    daysToFamilyAnniversary: 165,
    refreshDueDate: '2025-04-10',
    daysToRefresh: 165,
    in312Population: true,
    inCAMPopulation: false,
    cam312Reason: 'GB/GM Elevated Risk with Family Anniversary within 180 days',
    exclusionReason: 'Not High risk - CAM only includes High risk clients'
  },
  
  // GB/GM Standard - 312 Population (Family Anniversary)
  {
    id: 'POP-003',
    legalName: 'Consolidated Industries Group',
    clientId: 'CIG-778234',
    gciNumber: 'GCI-POP-003',
    coPerId: 'CP-003-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'David Park',
    status: 'Active',
    riskRating: 'Standard',
    has312Flag: true,
    familyAnniversaryDate: '2025-05-20',
    daysToFamilyAnniversary: 175,
    refreshDueDate: '2025-05-20',
    daysToRefresh: 175,
    in312Population: true,
    inCAMPopulation: false,
    cam312Reason: 'GB/GM Standard Risk with Family Anniversary within 180 days',
    exclusionReason: 'Not High risk - CAM only includes High risk clients'
  },
  
  // GB/GM - Manual 312 Identification
  {
    id: 'POP-004',
    legalName: 'Premier Financial Services',
    clientId: 'PFS-334123',
    gciNumber: 'GCI-POP-004',
    coPerId: 'CP-004-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'Jennifer Wu',
    status: 'Active',
    riskRating: 'High',
    has312Flag: true,
    manuallyIdentified312: true,
    refreshDueDate: '2025-07-15',
    daysToRefresh: 261,
    in312Population: true,
    inCAMPopulation: true,
    cam312Reason: 'Manually identified for 312 review',
    camReason: 'High risk client in active status'
  },
  
  // PB High Risk - 312 Population (Refresh within 180 days + PVT)
  {
    id: 'POP-005',
    legalName: 'Quantum Family Trust',
    clientId: 'QFT-556789',
    gciNumber: 'GCI-POP-005',
    coPerId: 'CP-005-2024',
    lob: 'PB',
    fluSystem: 'CMT',
    employeeAffiliate: false,
    salesOwner: 'Robert Anderson (RM)',
    status: 'Active',
    riskRating: 'High',
    has312Flag: true,
    hasPVT: true,
    refreshDueDate: '2025-03-30',
    daysToRefresh: 153,
    in312Population: true,
    inCAMPopulation: true,
    cam312Reason: 'PB High Risk with refresh within 180 days and PVT',
    camReason: 'High risk client in active status'
  },
  
  // ML High Risk - 312 Population (Refresh within 180 days + PVT)
  {
    id: 'POP-006',
    legalName: 'Sterling Investment Portfolio',
    clientId: 'SIP-889012',
    gciNumber: 'GCI-POP-006',
    coPerId: 'CP-006-2024',
    lob: 'ML',
    fluSystem: 'CP',
    employeeAffiliate: false,
    salesOwner: 'Amanda Torres (FA)',
    status: 'Active',
    riskRating: 'High',
    has312Flag: true,
    hasPVT: true,
    refreshDueDate: '2025-04-05',
    daysToRefresh: 159,
    in312Population: true,
    inCAMPopulation: true,
    cam312Reason: 'ML High Risk with refresh within 180 days and PVT',
    camReason: 'High risk client in active status'
  },
  
  // Consumer High Risk - CAM Only (No 312 flag)
  {
    id: 'POP-007',
    legalName: 'Martinez Family Account',
    clientId: 'MFA-112233',
    gciNumber: 'GCI-POP-007',
    coPerId: 'CP-007-2024',
    lob: 'Consumer',
    fluSystem: 'WCC',
    employeeAffiliate: false,
    salesOwner: 'Lisa Brown',
    status: 'Active',
    riskRating: 'High',
    has312Flag: false,
    refreshDueDate: '2025-02-28',
    daysToRefresh: 123,
    in312Population: false,
    inCAMPopulation: true,
    camReason: 'High risk client in active status',
    exclusionReason: 'No 312 flag - not in 312 population'
  },
  
  // CI High Risk - CAM Only (No 312 flag)
  {
    id: 'POP-008',
    legalName: 'Thompson Retirement Account',
    clientId: 'TRA-445566',
    gciNumber: 'GCI-POP-008',
    coPerId: 'CP-008-2024',
    lob: 'CI',
    fluSystem: 'WCC',
    employeeAffiliate: false,
    salesOwner: 'Kevin Rogers',
    status: 'Active',
    riskRating: 'High',
    has312Flag: false,
    refreshDueDate: '2025-03-10',
    daysToRefresh: 133,
    in312Population: false,
    inCAMPopulation: true,
    camReason: 'High risk client in active status',
    exclusionReason: 'No 312 flag - not in 312 population'
  },
  
  // Excluded - Closed Status
  {
    id: 'POP-009',
    legalName: 'Legacy Holdings Inc',
    clientId: 'LHI-778899',
    gciNumber: 'GCI-POP-009',
    coPerId: 'CP-009-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'Daniel Kim',
    status: 'Closed',
    riskRating: 'High',
    has312Flag: true,
    dgaDueDate: '2025-02-15',
    refreshDueDate: '2025-02-15',
    daysToRefresh: 110,
    in312Population: false,
    inCAMPopulation: false,
    exclusionReason: 'Client status is Closed - excluded from all populations'
  },
  
  // Excluded - PB High Risk but no PVT
  {
    id: 'POP-010',
    legalName: 'Riverside Capital Partners',
    clientId: 'RCP-223344',
    gciNumber: 'GCI-POP-010',
    coPerId: 'CP-010-2024',
    lob: 'PB',
    fluSystem: 'CMT',
    employeeAffiliate: false,
    salesOwner: 'Patricia Lee (RM)',
    status: 'Active',
    riskRating: 'High',
    has312Flag: true,
    hasPVT: false,
    refreshDueDate: '2025-03-25',
    daysToRefresh: 148,
    in312Population: false,
    inCAMPopulation: true,
    exclusionReason: 'PB client missing PVT from CRA - excluded from 312 population',
    camReason: 'High risk client in active status'
  },
  
  // Excluded - GB/GM High Risk but no DGA date
  {
    id: 'POP-011',
    legalName: 'Pacific Rim Ventures',
    clientId: 'PRV-556677',
    gciNumber: 'GCI-POP-011',
    coPerId: 'CP-011-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'Mark Thompson',
    status: 'Active',
    riskRating: 'High',
    has312Flag: true,
    refreshDueDate: '2025-08-15',
    daysToRefresh: 292,
    in312Population: false,
    inCAMPopulation: true,
    exclusionReason: 'GB/GM High Risk missing DGA Due Date - excluded from 312 population',
    camReason: 'High risk client in active status'
  },
  
  // Excluded - Family Anniversary beyond 180 days
  {
    id: 'POP-012',
    legalName: 'Global Commerce Solutions',
    clientId: 'GCS-889900',
    gciNumber: 'GCI-POP-012',
    coPerId: 'CP-012-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'Nicole Harris',
    status: 'Active',
    riskRating: 'Elevated',
    has312Flag: true,
    familyAnniversaryDate: '2025-11-15',
    daysToFamilyAnniversary: 384,
    refreshDueDate: '2025-11-15',
    daysToRefresh: 384,
    in312Population: false,
    inCAMPopulation: false,
    exclusionReason: 'Family Anniversary beyond 180 days (384 days) - excluded from 312 population'
  },
  
  // Employee/Affiliate - Still Included
  {
    id: 'POP-013',
    legalName: 'Johnson Employee Account',
    clientId: 'JEA-112255',
    gciNumber: 'GCI-POP-013',
    coPerId: 'CP-013-2024',
    lob: 'PB',
    fluSystem: 'CMT',
    employeeAffiliate: true,
    salesOwner: 'Carlos Rivera (RM)',
    status: 'Active',
    riskRating: 'High',
    has312Flag: true,
    hasPVT: true,
    refreshDueDate: '2025-02-20',
    daysToRefresh: 115,
    in312Population: true,
    inCAMPopulation: true,
    cam312Reason: 'PB High Risk with refresh within 180 days and PVT (Employee/Affiliate included)',
    camReason: 'High risk client in active status'
  },
  
  // Low Risk - Excluded from both
  {
    id: 'POP-014',
    legalName: 'Greenfield Investments',
    clientId: 'GFI-334455',
    gciNumber: 'GCI-POP-014',
    coPerId: 'CP-014-2024',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    employeeAffiliate: false,
    salesOwner: 'Emily Martinez',
    status: 'Active',
    riskRating: 'Low',
    has312Flag: true,
    familyAnniversaryDate: '2025-03-01',
    daysToFamilyAnniversary: 124,
    refreshDueDate: '2025-03-01',
    daysToRefresh: 124,
    in312Population: false,
    inCAMPopulation: false,
    exclusionReason: 'Low risk rating - 312 requires High/Elevated/Standard, CAM requires High only'
  }
];

export interface PopulationStats {
  totalClients: number;
  in312Population: number;
  inCAMPopulation: number;
  inBothPopulations: number;
  excluded: number;
  activeClients: number;
  closedClients: number;
  highRiskClients: number;
  byLOB: {
    lob: string;
    count: number;
    in312: number;
    inCAM: number;
  }[];
  byFLUSystem: {
    system: string;
    count: number;
  }[];
}

export const calculatePopulationStats = (clients: ClientForPopulation[]): PopulationStats => {
  const lobMap = new Map<string, { count: number; in312: number; inCAM: number }>();
  const fluMap = new Map<string, number>();
  
  clients.forEach(client => {
    // LOB stats
    const lobData = lobMap.get(client.lob) || { count: 0, in312: 0, inCAM: 0 };
    lobData.count++;
    if (client.in312Population) lobData.in312++;
    if (client.inCAMPopulation) lobData.inCAM++;
    lobMap.set(client.lob, lobData);
    
    // FLU system stats
    fluMap.set(client.fluSystem, (fluMap.get(client.fluSystem) || 0) + 1);
  });
  
  return {
    totalClients: clients.length,
    in312Population: clients.filter(c => c.in312Population).length,
    inCAMPopulation: clients.filter(c => c.inCAMPopulation).length,
    inBothPopulations: clients.filter(c => c.in312Population && c.inCAMPopulation).length,
    excluded: clients.filter(c => !c.in312Population && !c.inCAMPopulation).length,
    activeClients: clients.filter(c => c.status === 'Active').length,
    closedClients: clients.filter(c => c.status === 'Closed').length,
    highRiskClients: clients.filter(c => c.riskRating === 'High').length,
    byLOB: Array.from(lobMap.entries()).map(([lob, data]) => ({ lob, ...data })),
    byFLUSystem: Array.from(fluMap.entries()).map(([system, count]) => ({ system, count }))
  };
};
