import { createRoot } from "react-dom/client";
  import App from "./App.tsx";
  import "@/styles/index.css";

  // Suppress Figma data attribute warnings in development
  const originalError = console.error;
  const originalWarn = console.warn;
  
  console.error = (...args: any[]) => {
    // Filter out Figma-specific prop warnings
    if (
      typeof args[0] === 'string' &&
      (args[0].includes('data-fg-') || 
       args[0].includes('The following props are not supported') ||
       args[0].includes('Please remove them') ||
       args[0].includes('Failed') && args[0].includes('type') ||
       (args.length > 1 && typeof args[1] === 'string' && args[1].includes('data-fg-')))
    ) {
      return;
    }
    originalError.apply(console, args);
  };

  console.warn = (...args: any[]) => {
    // Filter out Figma-specific prop warnings and MUI Grid migration warnings
    if (
      typeof args[0] === 'string' &&
      (args[0].includes('data-fg-') || 
       args[0].includes('The following props are not supported') ||
       args[0].includes('Please remove them') ||
       args[0].includes('MUI Grid') ||
       args[0].includes('item') && args[0].includes('prop has been removed') ||
       args[0].includes('xs') && args[0].includes('prop has been removed') ||
       args[0].includes('md') && args[0].includes('prop has been removed') ||
       args[0].includes('validateDOMNesting') ||
       (args.length > 1 && typeof args[1] === 'string' && args[1].includes('data-fg-')))
    ) {
      return;
    }
    originalWarn.apply(console, args);
  };

  createRoot(document.getElementById("root")!).render(<App />);