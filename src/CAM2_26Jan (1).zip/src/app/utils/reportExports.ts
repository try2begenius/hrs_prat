import { Case } from '../types';

export interface AKRITExtractRow {
  caseId: string;
  clientName: string;
  clientId: string;
  accountNumber: string;
  caseType: string;
  status: string;
  priority: string;
  riskScore: number;
  section312Required: string;
  section312Status: string;
  camRequired: string;
  camStatus: string;
  camDisposition: string;
  assignedTo: string;
  createdDate: string;
  dueDate: string;
  lastUpdated: string;
  totalTransactions: number;
  flaggedTransactions: number;
  totalAmount: string;
  suspiciousActivity: string;
}

export interface DelinquencyReportRow {
  caseId: string;
  clientName: string;
  clientId: string;
  accountNumber: string;
  caseType: string;
  priority: string;
  assignedTo: string;
  createdDate: string;
  dueDate: string;
  daysOverdue: number;
  status: string;
  riskScore: number;
}

export function generateAKRITExtract(cases: Case[]): AKRITExtractRow[] {
  return cases.map(c => ({
    caseId: c.id,
    clientName: c.clientName,
    clientId: c.clientId,
    accountNumber: c.accountNumber,
    caseType: c.caseType,
    status: c.status,
    priority: c.priority,
    riskScore: c.riskScore,
    section312Required: c.section312Required ? 'Yes' : 'No',
    section312Status: c.section312Status || 'N/A',
    camRequired: c.camRequired ? 'Yes' : 'No',
    camStatus: c.camStatus || 'N/A',
    camDisposition: c.camDisposition || 'N/A',
    assignedTo: c.assignedTo,
    createdDate: c.createdDate,
    dueDate: c.dueDate,
    lastUpdated: c.lastUpdated,
    totalTransactions: c.totalTransactions,
    flaggedTransactions: c.flaggedTransactions,
    totalAmount: c.totalAmount,
    suspiciousActivity: c.suspiciousActivity
  }));
}

export function generateDelinquencyReport(cases: Case[]): DelinquencyReportRow[] {
  const today = new Date();
  
  return cases
    .map(c => {
      const dueDate = new Date(c.dueDate);
      const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
      
      return {
        caseId: c.id,
        clientName: c.clientName,
        clientId: c.clientId,
        accountNumber: c.accountNumber,
        caseType: c.caseType,
        priority: c.priority,
        assignedTo: c.assignedTo,
        createdDate: c.createdDate,
        dueDate: c.dueDate,
        daysOverdue,
        status: c.status,
        riskScore: c.riskScore
      };
    })
    .filter(row => row.daysOverdue > 0 && row.status !== 'Completed')
    .sort((a, b) => b.daysOverdue - a.daysOverdue);
}

export function exportToCSV(data: AKRITExtractRow[], filename: string) {
  if (data.length === 0) {
    throw new Error('No data to export');
  }

  // Get headers from the first object
  const headers = Object.keys(data[0]);
  
  // Create CSV content
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header as keyof AKRITExtractRow];
        // Escape values that contain commas or quotes
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      }).join(',')
    )
  ].join('\n');

  // Create and trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportToExcel(data: AKRITExtractRow[], filename: string) {
  // For a simple Excel export, we'll create a CSV and name it .xlsx
  // In a real application, you'd use a library like xlsx or exceljs
  exportToCSV(data, filename);
}

export function exportDelinquencyReportToCSV(data: DelinquencyReportRow[], filename: string) {
  if (data.length === 0) {
    throw new Error('No data to export');
  }

  // Get headers from the first object
  const headers = Object.keys(data[0]);
  
  // Create CSV content
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header as keyof DelinquencyReportRow];
        // Escape values that contain commas or quotes
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      }).join(',')
    )
  ].join('\n');

  // Create and trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportDelinquencyReportToExcel(data: DelinquencyReportRow[], filename: string) {
  // For a simple Excel export, we'll create a CSV and name it .xlsx
  // In a real application, you'd use a library like xlsx or exceljs
  exportDelinquencyReportToCSV(data, filename);
}
