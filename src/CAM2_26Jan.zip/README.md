
  # CAM2_26Jan

  This is a code bundle for CAM2_26Jan. The original project is available at https://www.figma.com/design/KQ2lxS5HhVsaoMQF1wrOwd/CAM2_26Jan.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  