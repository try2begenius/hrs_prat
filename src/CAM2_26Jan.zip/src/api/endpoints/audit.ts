/**
 * Audit Trail API Endpoints
 * Handles audit logging and history tracking
 */

import { apiClient, ApiResponse, PaginatedResponse } from '../client';
import { AuditTrailEntry, AssignmentHistory, ReviewHistory } from '../types';

/**
 * Audit API Endpoints
 */
export const auditApi = {
  // ============================================================================
  // Audit Trail Operations
  // ============================================================================

  /**
   * Get audit trail entries
   */
  getAuditTrail: async (params?: {
    table_name?: string;
    record_id?: string;
    action_type?: 'INSERT' | 'UPDATE' | 'DELETE';
    changed_by?: string;
    date_from?: string;
    date_to?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ApiResponse<PaginatedResponse<AuditTrailEntry>>> => {
    return apiClient.get<PaginatedResponse<AuditTrailEntry>>('/audit/trail', params);
  },

  /**
   * Get audit trail for specific record
   */
  getRecordAuditTrail: async (
    tableName: string,
    recordId: string
  ): Promise<ApiResponse<AuditTrailEntry[]>> => {
    return apiClient.get<AuditTrailEntry[]>(`/audit/trail/${tableName}/${recordId}`);
  },

  /**
   * Create audit entry (manual)
   */
  createAuditEntry: async (data: {
    table_name: string;
    record_id: string;
    action_type: 'INSERT' | 'UPDATE' | 'DELETE';
    changed_by: string;
    old_values?: Record<string, any>;
    new_values?: Record<string, any>;
    change_reason?: string;
  }): Promise<ApiResponse<AuditTrailEntry>> => {
    return apiClient.post<AuditTrailEntry>('/audit/trail', data);
  },

  // ============================================================================
  // Assignment History
  // ============================================================================

  /**
   * Get assignment history for a case
   */
  getAssignmentHistory: async (caseId: string): Promise<ApiResponse<AssignmentHistory[]>> => {
    return apiClient.get<AssignmentHistory[]>(`/audit/assignments/${caseId}`);
  },

  /**
   * Get current assignment for a case
   */
  getCurrentAssignment: async (caseId: string): Promise<ApiResponse<AssignmentHistory>> => {
    return apiClient.get<AssignmentHistory>(`/audit/assignments/${caseId}/current`);
  },

  /**
   * Get all assignments for a user
   */
  getUserAssignments: async (
    userId: string,
    params?: {
      case_type?: '312' | 'CAM';
      is_current?: 'Y' | 'N';
      date_from?: string;
      date_to?: string;
    }
  ): Promise<ApiResponse<AssignmentHistory[]>> => {
    return apiClient.get<AssignmentHistory[]>(`/audit/assignments/user/${userId}`, params);
  },

  /**
   * Create assignment history entry
   */
  createAssignment: async (data: {
    case_id: string;
    case_type: '312' | 'CAM';
    assigned_to: string;
    assigned_by: string;
    assignment_reason?: string;
  }): Promise<ApiResponse<AssignmentHistory>> => {
    return apiClient.post<AssignmentHistory>('/audit/assignments', data);
  },

  /**
   * End current assignment
   */
  endAssignment: async (
    assignmentId: number,
    data: {
      unassignment_date: string;
      reason?: string;
    }
  ): Promise<ApiResponse<AssignmentHistory>> => {
    return apiClient.patch<AssignmentHistory>(`/audit/assignments/${assignmentId}/end`, data);
  },

  // ============================================================================
  // Review History
  // ============================================================================

  /**
   * Get review history for a party
   */
  getPartyReviewHistory: async (partyId: string): Promise<ApiResponse<ReviewHistory[]>> => {
    return apiClient.get<ReviewHistory[]>(`/audit/reviews/party/${partyId}`);
  },

  /**
   * Get review history for a CAM case
   */
  getCaseReviewHistory: async (camCaseId: string): Promise<ApiResponse<ReviewHistory[]>> => {
    return apiClient.get<ReviewHistory[]>(`/audit/reviews/case/${camCaseId}`);
  },

  /**
   * Create review history entry
   */
  createReviewHistory: async (data: {
    cam_case_id: string;
    party_id: string;
    review_date: string;
    review_type: '312 Review' | 'CAM Review' | 'Combined Review';
    gfc_cases_reviewed: number;
    disposition_code?: string;
    disposition_summary?: string;
    reviewer_name: string;
  }): Promise<ApiResponse<ReviewHistory>> => {
    return apiClient.post<ReviewHistory>('/audit/reviews', data);
  },

  /**
   * Check if party had CAM review in last 12 months
   */
  checkRecentReview: async (partyId: string): Promise<ApiResponse<{
    had_cam_review_12m: boolean;
    last_review_date?: string;
    last_cam_case_id?: string;
  }>> => {
    return apiClient.get(`/audit/reviews/party/${partyId}/recent`);
  },

  // ============================================================================
  // Change History & Comparison
  // ============================================================================

  /**
   * Compare two versions of a record
   */
  compareVersions: async (data: {
    table_name: string;
    record_id: string;
    version_1_date: string;
    version_2_date: string;
  }): Promise<ApiResponse<{
    version_1: Record<string, any>;
    version_2: Record<string, any>;
    changes: Array<{
      field: string;
      old_value: any;
      new_value: any;
    }>;
  }>> => {
    return apiClient.post('/audit/compare', data);
  },

  /**
   * Get field change history
   */
  getFieldHistory: async (
    tableName: string,
    recordId: string,
    fieldName: string
  ): Promise<ApiResponse<Array<{
    changed_date: string;
    old_value: any;
    new_value: any;
    changed_by: string;
  }>>> => {
    return apiClient.get(`/audit/field-history/${tableName}/${recordId}/${fieldName}`);
  },

  // ============================================================================
  // Activity Tracking
  // ============================================================================

  /**
   * Get user activity log
   */
  getUserActivity: async (
    userId: string,
    params?: {
      date_from?: string;
      date_to?: string;
      activity_type?: string;
    }
  ): Promise<ApiResponse<Array<{
    activity_id: string;
    activity_type: string;
    description: string;
    timestamp: string;
    table_name?: string;
    record_id?: string;
    details?: Record<string, any>;
  }>>> => {
    return apiClient.get(`/audit/activity/user/${userId}`, params);
  },

  /**
   * Get system activity log
   */
  getSystemActivity: async (params?: {
    date_from?: string;
    date_to?: string;
    action_type?: string;
  }): Promise<ApiResponse<PaginatedResponse<any>>> => {
    return apiClient.get('/audit/activity/system', params);
  },

  /**
   * Log user action
   */
  logUserAction: async (data: {
    user_id: string;
    action_type: string;
    description: string;
    table_name?: string;
    record_id?: string;
    details?: Record<string, any>;
  }): Promise<ApiResponse<{ success: boolean }>> => {
    return apiClient.post('/audit/activity/log', data);
  },

  // ============================================================================
  // Compliance & Reporting
  // ============================================================================

  /**
   * Get compliance audit report
   */
  getComplianceReport: async (params: {
    date_from: string;
    date_to: string;
    report_type?: 'full' | 'summary';
  }): Promise<ApiResponse<{
    total_changes: number;
    by_table: Record<string, number>;
    by_user: Record<string, number>;
    critical_changes: number;
    failed_validations: number;
  }>> => {
    return apiClient.get('/audit/compliance-report', params);
  },

  /**
   * Export audit trail
   */
  exportAuditTrail: async (params: {
    date_from: string;
    date_to: string;
    format: 'csv' | 'excel' | 'pdf';
    table_name?: string;
  }): Promise<ApiResponse<{ download_url: string }>> => {
    return apiClient.get<{ download_url: string }>('/audit/export', params);
  },

  /**
   * Get audit statistics
   */
  getAuditStats: async (params?: {
    date_from?: string;
    date_to?: string;
  }): Promise<ApiResponse<{
    total_entries: number;
    by_action_type: Record<string, number>;
    by_table: Record<string, number>;
    most_active_users: Array<{
      user_id: string;
      full_name: string;
      action_count: number;
    }>;
  }>> => {
    return apiClient.get('/audit/stats', params);
  },
};
