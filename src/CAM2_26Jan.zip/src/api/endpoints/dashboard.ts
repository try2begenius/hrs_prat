/**
 * Dashboard & Reporting API Endpoints
 * Handles dashboard statistics, reports, and analytics
 */

import { apiClient, ApiResponse } from '../client';
import { DashboardStats } from '../types';

export interface ReportData {
  report_id: string;
  report_name: string;
  generated_date: string;
  generated_by: string;
  parameters: Record<string, any>;
  data: any;
}

/**
 * Dashboard & Reporting API Endpoints
 */
export const dashboardApi = {
  // ============================================================================
  // Dashboard Statistics
  // ============================================================================

  /**
   * Get dashboard overview statistics
   */
  getDashboardStats: async (params?: {
    user_id?: string;
    role?: string;
    date_from?: string;
    date_to?: string;
  }): Promise<ApiResponse<DashboardStats>> => {
    return apiClient.get<DashboardStats>('/dashboard/stats', params);
  },

  /**
   * Get case metrics
   */
  getCaseMetrics: async (params?: {
    date_from?: string;
    date_to?: string;
    lob?: string;
  }): Promise<ApiResponse<{
    total_cases_created: number;
    total_cases_completed: number;
    avg_completion_time: number;
    auto_close_rate: number;
    sla_compliance_rate: number;
    escalation_rate: number;
  }>> => {
    return apiClient.get('/dashboard/case-metrics', params);
  },

  /**
   * Get workload distribution
   */
  getWorkloadDistribution: async (): Promise<ApiResponse<{
    by_analyst: Array<{ analyst: string; count: number }>;
    by_lob: Array<{ lob: string; count: number }>;
    by_status: Array<{ status: string; count: number }>;
  }>> => {
    return apiClient.get('/dashboard/workload-distribution');
  },

  /**
   * Get SLA compliance data
   */
  getSLACompliance: async (params?: {
    date_from?: string;
    date_to?: string;
  }): Promise<ApiResponse<{
    total_cases: number;
    met_sla: number;
    missed_sla: number;
    compliance_rate: number;
    avg_days_to_complete: number;
    by_case_type: Record<string, {
      total: number;
      met_sla: number;
      compliance_rate: number;
    }>;
  }>> => {
    return apiClient.get('/dashboard/sla-compliance', params);
  },

  /**
   * Get trend analysis
   */
  getTrendAnalysis: async (params: {
    metric: 'cases_created' | 'cases_completed' | 'auto_closed' | 'avg_completion_time';
    date_from: string;
    date_to: string;
    granularity?: 'daily' | 'weekly' | 'monthly';
  }): Promise<ApiResponse<Array<{
    period: string;
    value: number;
  }>>> => {
    return apiClient.get('/dashboard/trends', params);
  },

  // ============================================================================
  // Reports
  // ============================================================================

  /**
   * Get available reports
   */
  getAvailableReports: async (): Promise<ApiResponse<Array<{
    report_id: string;
    report_name: string;
    description: string;
    category: string;
    parameters: Array<{
      name: string;
      type: string;
      required: boolean;
      default?: any;
    }>;
  }>>> => {
    return apiClient.get('/reports/available');
  },

  /**
   * Generate report
   */
  generateReport: async (data: {
    report_type: string;
    parameters: Record<string, any>;
    format?: 'json' | 'csv' | 'excel' | 'pdf';
  }): Promise<ApiResponse<ReportData>> => {
    return apiClient.post<ReportData>('/reports/generate', data);
  },

  /**
   * Get case volume report
   */
  getCaseVolumeReport: async (params: {
    date_from: string;
    date_to: string;
    group_by?: 'lob' | 'case_type' | 'status' | 'analyst';
  }): Promise<ApiResponse<any>> => {
    return apiClient.get('/reports/case-volume', params);
  },

  /**
   * Get analyst performance report
   */
  getAnalystPerformanceReport: async (params?: {
    date_from?: string;
    date_to?: string;
    analyst_id?: string;
  }): Promise<ApiResponse<Array<{
    analyst_id: string;
    analyst_name: string;
    cases_assigned: number;
    cases_completed: number;
    avg_completion_time: number;
    sla_compliance_rate: number;
    auto_close_rate: number;
  }>>> => {
    return apiClient.get('/reports/analyst-performance', params);
  },

  /**
   * Get auto-closure analysis report
   */
  getAutoClosureReport: async (params: {
    date_from: string;
    date_to: string;
  }): Promise<ApiResponse<{
    total_cases: number;
    auto_closed_312: number;
    auto_closed_cam: number;
    auto_close_rate_312: number;
    auto_close_rate_cam: number;
    by_lob: Record<string, {
      total: number;
      auto_closed: number;
      rate: number;
    }>;
  }>> => {
    return apiClient.get('/reports/auto-closure', params);
  },

  /**
   * Get population trigger report
   */
  getPopulationTriggerReport: async (params: {
    date_from: string;
    date_to: string;
    lob?: string;
  }): Promise<ApiResponse<{
    total_triggers: number;
    by_type: Record<string, number>;
    by_lob: Record<string, number>;
    manual_uploads: number;
    cases_created: number;
  }>> => {
    return apiClient.get('/reports/population-triggers', params);
  },

  /**
   * Get GFC activity report
   */
  getGFCActivityReport: async (params: {
    date_from: string;
    date_to: string;
  }): Promise<ApiResponse<{
    total_gfc_cases: number;
    by_type: Record<string, number>;
    sar_cases: number;
    linked_to_cam: number;
    unreviewed: number;
  }>> => {
    return apiClient.get('/reports/gfc-activity', params);
  },

  /**
   * Get LOB performance report
   */
  getLOBPerformanceReport: async (params?: {
    date_from?: string;
    date_to?: string;
  }): Promise<ApiResponse<Array<{
    lob: string;
    total_cases: number;
    auto_closed: number;
    avg_completion_time: number;
    sla_compliance_rate: number;
  }>>> => {
    return apiClient.get('/reports/lob-performance', params);
  },

  // ============================================================================
  // Export & Download
  // ============================================================================

  /**
   * Export dashboard data
   */
  exportDashboard: async (params: {
    format: 'csv' | 'excel' | 'pdf';
    sections: string[];
  }): Promise<ApiResponse<{ download_url: string }>> => {
    return apiClient.post<{ download_url: string }>('/dashboard/export', params);
  },

  /**
   * Schedule recurring report
   */
  scheduleReport: async (data: {
    report_type: string;
    parameters: Record<string, any>;
    frequency: 'daily' | 'weekly' | 'monthly';
    recipients: string[];
    format: 'csv' | 'excel' | 'pdf';
  }): Promise<ApiResponse<{ schedule_id: string }>> => {
    return apiClient.post<{ schedule_id: string }>('/reports/schedule', data);
  },

  /**
   * Get scheduled reports
   */
  getScheduledReports: async (): Promise<ApiResponse<Array<{
    schedule_id: string;
    report_type: string;
    frequency: string;
    next_run: string;
    active: boolean;
  }>>> => {
    return apiClient.get('/reports/scheduled');
  },

  /**
   * Cancel scheduled report
   */
  cancelScheduledReport: async (scheduleId: string): Promise<ApiResponse<{ success: boolean }>> => {
    return apiClient.delete(`/reports/scheduled/${scheduleId}`);
  },

  // ============================================================================
  // Real-time Updates
  // ============================================================================

  /**
   * Get real-time case updates
   */
  getRealtimeUpdates: async (params?: {
    since?: string;
  }): Promise<ApiResponse<Array<{
    update_type: string;
    case_id: string;
    timestamp: string;
    description: string;
  }>>> => {
    return apiClient.get('/dashboard/realtime-updates', params);
  },

  /**
   * Get alerts and notifications
   */
  getAlerts: async (): Promise<ApiResponse<Array<{
    alert_id: string;
    type: 'sla_breach' | 'high_priority' | 'escalation';
    severity: 'high' | 'medium' | 'low';
    message: string;
    case_id?: string;
    timestamp: string;
  }>>> => {
    return apiClient.get('/dashboard/alerts');
  },
};
