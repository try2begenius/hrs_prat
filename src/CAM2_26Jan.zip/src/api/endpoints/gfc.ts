/**
 * GFC (Generic Findings Cases) API Endpoints
 * Handles GFC case operations and linking to CAM cases
 */

import { apiClient, ApiResponse, PaginatedResponse } from '../client';
import { GFCCase } from '../types';

/**
 * GFC API Endpoints
 */
export const gfcApi = {
  // ============================================================================
  // GFC Case Operations
  // ============================================================================

  /**
   * Get all GFC cases with filtering
   */
  getGFCCases: async (params?: {
    party_id?: string;
    case_type?: string;
    case_status?: string;
    is_in_scope?: 'Y' | 'N';
    is_sar?: 'Y' | 'N';
    date_from?: string;
    date_to?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ApiResponse<PaginatedResponse<GFCCase>>> => {
    return apiClient.get<PaginatedResponse<GFCCase>>('/gfc-cases', params);
  },

  /**
   * Get a specific GFC case by ID
   */
  getGFCCaseById: async (gfcCaseId: string): Promise<ApiResponse<GFCCase>> => {
    return apiClient.get<GFCCase>(`/gfc-cases/${gfcCaseId}`);
  },

  /**
   * Create a new GFC case
   */
  createGFCCase: async (data: Omit<GFCCase, 'gfc_case_id' | 'created_date'>): Promise<ApiResponse<GFCCase>> => {
    return apiClient.post<GFCCase>('/gfc-cases', data);
  },

  /**
   * Update GFC case
   */
  updateGFCCase: async (gfcCaseId: string, data: Partial<GFCCase>): Promise<ApiResponse<GFCCase>> => {
    return apiClient.put<GFCCase>(`/gfc-cases/${gfcCaseId}`, data);
  },

  /**
   * Close GFC case
   */
  closeGFCCase: async (
    gfcCaseId: string,
    data: {
      disposition_code: string;
      closed_by: string;
      closed_date: string;
    }
  ): Promise<ApiResponse<GFCCase>> => {
    return apiClient.post<GFCCase>(`/gfc-cases/${gfcCaseId}/close`, data);
  },

  // ============================================================================
  // GFC-CAM Linking Operations
  // ============================================================================

  /**
   * Get GFC cases linked to a CAM case
   */
  getLinkedGFCCases: async (camCaseId: string): Promise<ApiResponse<{
    gfc_cases: GFCCase[];
    link_details: Array<{
      gfc_case_id: string;
      was_reviewed: 'Y' | 'N';
      reviewed_in_prior_cam: 'Y' | 'N';
      prior_cam_case_id?: string;
    }>;
  }>> => {
    return apiClient.get(`/gfc-cases/linked/${camCaseId}`);
  },

  /**
   * Link GFC cases to CAM case
   */
  linkGFCToCAM: async (
    camCaseId: string,
    data: {
      gfc_case_ids: string[];
      linked_by: string;
    }
  ): Promise<ApiResponse<{
    linked_count: number;
    links: any[];
  }>> => {
    return apiClient.post(`/gfc-cases/link/${camCaseId}`, data);
  },

  /**
   * Unlink GFC case from CAM case
   */
  unlinkGFCFromCAM: async (
    camCaseId: string,
    gfcCaseId: string
  ): Promise<ApiResponse<{ success: boolean }>> => {
    return apiClient.delete(`/gfc-cases/link/${camCaseId}/${gfcCaseId}`);
  },

  /**
   * Mark GFC case as reviewed in CAM case
   */
  markGFCAsReviewed: async (
    camCaseId: string,
    gfcCaseId: string,
    data: {
      reviewed_by: string;
      review_notes?: string;
    }
  ): Promise<ApiResponse<any>> => {
    return apiClient.post(`/gfc-cases/link/${camCaseId}/${gfcCaseId}/reviewed`, data);
  },

  /**
   * Get unreviewed GFC cases for a party
   */
  getUnreviewedGFCCases: async (partyId: string): Promise<ApiResponse<GFCCase[]>> => {
    return apiClient.get<GFCCase[]>(`/gfc-cases/party/${partyId}/unreviewed`);
  },

  /**
   * Get new GFC cases (not reviewed in any prior CAM)
   */
  getNewGFCCases: async (partyId: string, params?: {
    months_lookback?: number;
  }): Promise<ApiResponse<{
    new_gfc_count: number;
    gfc_cases: GFCCase[];
  }>> => {
    return apiClient.get(`/gfc-cases/party/${partyId}/new`, params);
  },

  // ============================================================================
  // GFC Analysis
  // ============================================================================

  /**
   * Get GFC case summary for a party
   */
  getGFCSummary: async (partyId: string, params?: {
    months_lookback?: number;
  }): Promise<ApiResponse<{
    total_count: number;
    open_count: number;
    closed_count: number;
    new_count: number;
    sar_count: number;
    by_case_type: Record<string, number>;
    recently_completed: number;
  }>> => {
    return apiClient.get(`/gfc-cases/party/${partyId}/summary`, params);
  },

  /**
   * Check if GFC cases trigger full CAM review
   */
  checkGFCTrigger: async (partyId: string): Promise<ApiResponse<{
    triggers_full_review: boolean;
    reasons: string[];
    new_gfc_count: number;
    has_sar: boolean;
    prior_312_not_auto_closed: boolean;
  }>> => {
    return apiClient.get(`/gfc-cases/party/${partyId}/trigger-check`);
  },

  // ============================================================================
  // GFC Case Type Management
  // ============================================================================

  /**
   * Get available GFC case types
   */
  getGFCCaseTypes: async (): Promise<ApiResponse<Array<{
    case_type: string;
    description: string;
    active: boolean;
  }>>> => {
    return apiClient.get('/gfc-cases/case-types');
  },

  // ============================================================================
  // Reporting
  // ============================================================================

  /**
   * Get GFC case statistics
   */
  getGFCStats: async (params?: {
    date_from?: string;
    date_to?: string;
    lob?: string;
  }): Promise<ApiResponse<{
    total_gfc_cases: number;
    by_type: Record<string, number>;
    by_status: Record<string, number>;
    sar_cases: number;
    open_cases: number;
    avg_resolution_days: number;
  }>> => {
    return apiClient.get('/gfc-cases/stats', params);
  },

  /**
   * Export GFC cases
   */
  exportGFCCases: async (params?: any): Promise<ApiResponse<{ download_url: string }>> => {
    return apiClient.get<{ download_url: string }>('/gfc-cases/export', params);
  },

  /**
   * Get GFC trend analysis
   */
  getGFCTrends: async (params: {
    date_from: string;
    date_to: string;
    granularity?: 'daily' | 'weekly' | 'monthly';
    party_id?: string;
    case_type?: string;
  }): Promise<ApiResponse<Array<{
    period: string;
    opened_count: number;
    closed_count: number;
    sar_count: number;
  }>>> => {
    return apiClient.get('/gfc-cases/trends', params);
  },
};
