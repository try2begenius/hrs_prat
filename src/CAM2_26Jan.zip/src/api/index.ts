/**
 * CAM Case Management System - API Layer
 * Centralized export of all API endpoints
 */

// Export API client and types
export { apiClient } from './client';
export type { ApiResponse, PaginatedResponse } from './client';

// Export all API endpoint modules
export { casesApi } from './endpoints/cases';
export { populationApi } from './endpoints/population';
export { partiesApi } from './endpoints/parties';
export { gfcApi } from './endpoints/gfc';
export { usersApi } from './endpoints/users';
export { dashboardApi } from './endpoints/dashboard';
export { auditApi } from './endpoints/audit';

// Export types
export type * from './types';
export type { User, AuthResponse } from './endpoints/users';
export type { ReportData } from './endpoints/dashboard';

/**
 * Unified API object for easy access to all endpoints
 */
export const api = {
  cases: casesApi,
  population: populationApi,
  parties: partiesApi,
  gfc: gfcApi,
  users: usersApi,
  dashboard: dashboardApi,
  audit: auditApi,
} as const;

/**
 * API Configuration
 */
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || '/api',
  TIMEOUT: 30000, // 30 seconds
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000, // 1 second
} as const;

/**
 * API Error Codes
 */
export enum ApiErrorCode {
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  NOT_FOUND = 'NOT_FOUND',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  SERVER_ERROR = 'SERVER_ERROR',
  NETWORK_ERROR = 'NETWORK_ERROR',
}

/**
 * Helper function to check if response was successful
 */
export function isSuccessful<T>(response: ApiResponse<T>): response is ApiResponse<T> & { success: true; data: T } {
  return response.success && response.data !== undefined;
}

/**
 * Helper function to handle API errors
 */
export function handleApiError(error: any): string {
  if (error?.response?.data?.message) {
    return error.response.data.message;
  }
  if (error?.message) {
    return error.message;
  }
  return 'An unexpected error occurred';
}
