# CAM Case Disposition - Quick Reference Card

## ✅ Validation Complete - November 1, 2025

---

## 📋 Questions Overview

### Question 1: Monitoring Activity Review
**Type**: Yes/No Dropdown  
**Required**: ✅ Yes  
**Text**: "After review of the monitoring activity over the last 12 months - are there any additional items that need to be raised as a result of this monitoring?"

---

#### If Answer = NO → Question 1.1

**Two Fixed Attestation Checkboxes** (BOTH Required):

1. ✅ "I have reviewed the alerts and escalations and believe no further escalation is required to be raised"

2. ✅ "No additional findings or knowledge of the client require an escalation outside of what has been already properly escalated"

**Visual**: Blue background box

---

#### If Answer = YES → Questions 1.2 & 1.3

**Q 1.2**: "If yes, please file a TRMS indicating unusual alert(s) or activity and document TRMS number"  
**Type**: Yes/No Dropdown  
**Required**: ✅ Yes

**Q 1.3**: TRMS Number  
**Type**: Text Input  
**Required**: ✅ If Q1.2 = Yes  
**Placeholder**: "Enter TRMS number"

---

### Question 2: Dashboard Confirmation
**Type**: Single Checkbox  
**Required**: ✅ Yes  
**Text**: "I confirm that I have reviewed the Monitoring Dashboard data and understand the client's activity."  
**Visual**: Amber background (emphasizes importance)

---

### Question 3: Case Action
**Type**: Dropdown  
**Required**: ✅ Yes  
**Options**:
1. Complete – No action
2. Complete – TRMS filed
3. Send to Sales

**Visual**: Blue background box

---

#### If "Complete – No action" Selected

**Attestation Checkbox** (Required):
- ✅ "I confirm that all data has been reviewed and the responses to the above questions are accurate"
- **Visual**: Blue attestation box with border

---

#### If "Complete – TRMS filed" Selected

**TRMS Number Field**:
- Type: Text Input
- Required: ✅ Yes
- Placeholder: "Enter TRMS number"

**Attestation Checkbox** (Required):
- ✅ "I confirm that all data has been reviewed and a TRMS has been raised accordingly"
- **Visual**: Green attestation box with border

---

#### If "Send to Sales" Selected

**Sales Owner Field**:
- Type: Dropdown
- Required: ✅ Yes
- Options: David Park, Amanda Torres, Patricia Lee (RM)

**Comments Field**:
- Type: Textarea
- Required: ✅ Yes
- Max Length: 4000 characters
- Character counter displayed

---

## 🔘 Action Buttons

### Save Button
- **Purpose**: Save responses (can edit later)
- **Validation**: All required fields checked
- **Warning**: Displays if missing required fields
- **Success**: "CAM Case responses saved successfully"

### Cancel Button
- **Purpose**: Return to case summary
- **Action**: Closes accordion, returns to summary view

### Submit Button
- **Purpose**: Final submission (cannot edit after)
- **Validation**: All required fields checked
- **Confirmation**: Two-stage process:
  1. Validation check (shows errors if incomplete)
  2. Submission confirmation: "Once you submit, you will be unable to make edits/changes to this section. Do you want to proceed?"
- **Success**: "CAM Case submitted successfully"
- **Result**: Section becomes read-only with green banner

---

## ✅ Required Fields Checklist

- [ ] Question 1 (Yes/No)
- [ ] If Q1 = No: Both Q1.1 attestations
- [ ] If Q1 = Yes: Q1.2 (TRMS filed?)
- [ ] If Q1.2 = Yes: Q1.3 (TRMS number)
- [ ] Question 2 confirmation checkbox
- [ ] Question 3 Case Action
- [ ] If "Complete – No action": Attestation checkbox
- [ ] If "Complete – TRMS filed": TRMS number + Attestation checkbox
- [ ] If "Send to Sales": Sales Owner + Comments

---

## 🎨 Visual Guide

### Color Coding
| Element | Color | Purpose |
|---------|-------|---------|
| Q1.1 Attestations | Blue | Standard attestation |
| Q2 Confirmation | Amber | Emphasizes importance |
| Q3 Case Action | Blue | Action selection |
| Complete – No action attestation | Blue | Matches Q1.1 style |
| Complete – TRMS attestation | Green | Distinguishes from No action |
| Submitted banner | Green | Success state |
| Permission warning | Amber | Alert state |

### Required Field Indicator
- All required fields show red asterisk: `*`
- Located immediately after field label

---

## 🚫 Validation Errors

| Error Message | Cause |
|---------------|-------|
| "Question 1 is required." | Q1 not answered |
| "Please check both attestations for Question 1.1" | Q1=No but not both attestations checked |
| "Please indicate if TRMS was filed for Question 1.2" | Q1=Yes but Q1.2 not answered |
| "Please provide TRMS number for Question 1.3" | Q1.2=Yes but no TRMS number |
| "Question 2 confirmation is required." | Q2 checkbox not checked |
| "Question 3 (Case Action) is required." | Q3 not selected |
| "Please provide TRMS number for Case Action." | Q3="Complete – TRMS filed" but no number |
| "Please confirm that all data has been reviewed..." | Complete action but attestation not checked |
| "Please select Sales Owner for Case Action." | Q3="Send to Sales" but no owner |
| "Comments are mandatory when sending to Sales." | Q3="Send to Sales" but no comments |

---

## 🔒 Permission & States

### Edit Mode (Can Edit = True)
- All fields enabled
- Action buttons visible
- Can save/submit

### Read-Only Mode
- **Triggered by**:
  - User lacks `actionCases` permission
  - Section already submitted
- **Characteristics**:
  - All fields disabled
  - No action buttons
  - Lock icon displayed
  - Banner shows reason/details

### Submitted State
- Section locked permanently
- Green banner: "This section has been submitted and is now read-only. Submitted by [Name] on [Date]"
- Lock badge in section header

---

## 🧪 Test Paths

### Path 1: No Action Required
1. Q1 = No
2. Check both Q1.1 attestations
3. Check Q2
4. Q3 = "Complete – No action"
5. Check Q3 attestation
6. Submit ✅

### Path 2: TRMS Filed
1. Q1 = Yes
2. Q1.2 = Yes
3. Enter Q1.3 TRMS number
4. Check Q2
5. Q3 = "Complete – TRMS filed"
6. Enter Q3 TRMS number
7. Check Q3 attestation
8. Submit ✅

### Path 3: Send to Sales
1. Q1 = No (or Yes with TRMS info)
2. Complete Q1 sub-questions
3. Check Q2
4. Q3 = "Send to Sales"
5. Select Sales Owner
6. Enter Comments
7. Submit ✅

---

## 📊 Data Structure

```typescript
CAMCaseResponse {
  question1: boolean | null;              // Q1 answer
  question1_1_attestations?: string[];    // Both attestations if Q1=No
  question1_2_trms?: string;             // "yes" or "no" if Q1=Yes
  question1_3_trmsNumber?: string;        // TRMS # if Q1.2=Yes
  question2_confirmation?: boolean;       // Q2 checkbox
  question3_action?: string;              // 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales'
  question3_trms?: string;               // TRMS # if TRMS filed
  question3_salesOwner?: string;         // Sales owner if send to sales
  question3_comments?: string;           // Comments if send to sales
  question3_confirmation?: boolean;      // Case action attestation
  submittedBy?: string;                  // Who submitted
  submittedDate?: string;                // When submitted
  isSubmitted?: boolean;                 // Submitted status
}
```

---

## 📁 Implementation Files

| File | Purpose |
|------|---------|
| `/components/case-sections/SectionCAMCase.tsx` | UI component |
| `/components/CaseDetailsEnhanced.tsx` | Parent component with validation |
| `/types/index.ts` | TypeScript interfaces |

---

## ✅ Compliance Status

**100% Compliant with Specification**

All requirements from specification Section 4.2.5 implemented:
- ✅ Question text matches exactly
- ✅ Fixed attestations (not dynamic)
- ✅ All conditional logic correct
- ✅ All validation rules enforced
- ✅ Case action attestations mandatory
- ✅ Save/Submit workflows complete
- ✅ Read-only state after submission

---

**Last Updated**: November 1, 2025  
**Status**: ✅ Ready for Production
