# Case Assignment Functionality

## Overview

The CAM platform supports flexible case assignment with both self-assignment by analysts and bulk assignment/reassignment by managers. All users can see all cases regardless of LOB, enabling better resource allocation and workload management.

---

## Worklist Filtering Shortcuts

Three quick filter buttons provide instant access to key case populations:

### 1. **Unassigned**
- **Filter**: All cases with assignee = "Unassigned"
- **Purpose**: Cases pending assignment or self-selection
- **Badge**: Shows count of unassigned cases
- **Styling**: Default button with counter badge

### 2. **In Progress**
- **Filter**: All cases with status = "In Progress"
- **Purpose**: Cases currently being worked by analysts
- **Badge**: Shows count of in-progress cases
- **Styling**: Default button with counter badge

### 3. **Past Due**
- **Filter**: All cases where due date < today
- **Purpose**: Overdue cases requiring immediate attention
- **Badge**: Shows count of past due cases
- **Styling**: Destructive (red) button with counter badge
- **Visual Indicator**: Past due rows have red background tint

---

## Case Visibility

### All Users See All Cases
**Important**: Per requirements, both individuals and managers can see all cases regardless of LOB.

**Filtering Logic**:
```typescript
// NO LOB filtering for visibility
const userAccessibleCases = mockCases.filter(c => {
  // Filter by case type access only
  if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
  if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
  
  // Filter employee cases
  if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
  
  // All users can see all LOBs
  return true;
});
```

**Benefits**:
- Better workload distribution
- Cross-LOB resource allocation
- Full transparency of case pipeline
- Managers can assign any case to any analyst

---

## Self-Assignment

### How It Works

**Trigger**: When a credentialed user (Analyst role) clicks a case number hyperlink

**Behavior**:
1. User clicks case number in worklist
2. If case is **Unassigned** AND user is **Analyst**:
   - Case is automatically assigned to the clicking user
   - Case status changes from "Unassigned" to "In Progress"
   - Toast notification: "Case assigned to you"
3. Case details page opens

**Code Flow**:
```typescript
const handleSelfAssign = (caseId: string) => {
  const caseItem = mockCases.find(c => c.id === caseId);
  
  if (caseItem && caseItem.assignedTo === 'Unassigned' && currentUser.role === 'Analyst') {
    onCaseAssigned?.(caseId, currentUser.name);
    toast.success('Case assigned to you', {
      description: `Case ${caseId} has been assigned to you.`
    });
  }
  
  onViewCase(caseId);
};
```

### Eligible Users
- **Central Team Analyst**: ✅ Can self-assign
- **Central Team Manager**: ❌ Cannot self-assign (use bulk assignment)
- **Sales Owner**: ❌ Cases assigned by analyst routing
- **View Only**: ❌ Cannot self-assign

### Self-Assignment Rules

| Current Status | User Role | Can Self-Assign? | Result |
|---------------|-----------|------------------|--------|
| Unassigned | Analyst | ✅ Yes | Assigned to user, status → In Progress |
| Unassigned | Manager | ❌ No | Opens case, no assignment |
| In Progress | Analyst | ❌ No | Opens case, no change |
| Any other | Any | ❌ No | Opens case, no change |

---

## Manager Bulk Assignment

### Capabilities

**Managers can**:
- Assign multiple cases at once
- Assign cases to any Central Team member
- Assign cases to Sales Owners
- Reassign cases between users
- Reassign from one analyst to another
- Reassign from one sales owner to another

### How It Works

#### Step 1: Select Cases
- Manager sees checkbox column in worklist
- Checkboxes available for:
  - ✅ Unassigned cases (always selectable)
  - ✅ Assigned cases (manager can reassign)
- "Select All" checkbox in header

#### Step 2: Bulk Assign Button
- Button appears when cases are selected
- Shows count: "Assign 5 Cases"
- Opens assignment dialog

#### Step 3: Choose Assignee
- Dropdown shows all available assignees:
  - Central Team Analysts
  - Central Team Managers
  - Sales Owners
- Each option shows: Name (Role)

#### Step 4: Confirm Assignment
- Click "Assign Cases" button
- Cases are updated
- Success toast: "5 case(s) assigned to Michael Chen"
- Selection cleared

### Bulk Assignment Dialog

```typescript
<Dialog open={bulkAssignDialogOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Assign Cases</DialogTitle>
      <DialogDescription>
        Assign {selectedCases.size} selected case(s) to a team member
      </DialogDescription>
    </DialogHeader>
    
    <Select value={selectedAssignee} onValueChange={setSelectedAssignee}>
      <SelectTrigger>
        <SelectValue placeholder="Select a team member..." />
      </SelectTrigger>
      <SelectContent>
        {availableAssignees.map(user => (
          <SelectItem key={user.id} value={user.name}>
            {user.name} ({user.role})
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
    
    <DialogFooter>
      <Button variant="outline" onClick={close}>Cancel</Button>
      <Button onClick={confirmBulkAssignment}>Assign Cases</Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

---

## Assignment Logic

### Case Status Transitions on Assignment

**From Unassigned → Assigned**:
```typescript
caseToUpdate.assignedTo = assignee;
if (caseToUpdate.status === 'Unassigned') {
  caseToUpdate.status = 'In Progress';
}
```

**Reassignment** (case already assigned):
```typescript
// Simply update assignee, status unchanged
caseToUpdate.assignedTo = newAssignee;
```

### Available Assignees

**Central Team Members**:
- All users with role = "Analyst"
- All users with role = "Manager"

**Sales Owners**:
- All users with role = "Sales Owner"
- Used for cases in sales review process

**Get Available Assignees**:
```typescript
const availableAssignees = mockUsers.filter(u => 
  u.role === 'Analyst' || 
  u.role === 'Manager' || 
  u.role === 'Sales Owner'
);
```

---

## User Interface Elements

### Quick Filter Bar

Located above the search/filter row:

```tsx
<div className="flex gap-2 border-b pb-4">
  <Button variant={quickFilter === 'all' ? 'default' : 'outline'}>
    <Users className="mr-2 h-4 w-4" />
    All Cases
    <Badge variant="secondary" className="ml-2">{totalCount}</Badge>
  </Button>
  
  <Button variant={quickFilter === 'unassigned' ? 'default' : 'outline'}>
    <AlertCircle className="mr-2 h-4 w-4" />
    Unassigned
    <Badge variant="secondary" className="ml-2">{unassignedCount}</Badge>
  </Button>
  
  <Button variant={quickFilter === 'inProgress' ? 'default' : 'outline'}>
    <Users className="mr-2 h-4 w-4" />
    In Progress
    <Badge variant="secondary" className="ml-2">{inProgressCount}</Badge>
  </Button>
  
  <Button variant={quickFilter === 'pastDue' ? 'default' : 'outline'}>
    <Clock className="mr-2 h-4 w-4" />
    Past Due
    <Badge variant="secondary" className="ml-2 bg-white/20">{pastDueCount}</Badge>
  </Button>
</div>
```

### Checkbox Column (Manager Only)

```tsx
{isManager && (
  <TableHead className="w-12">
    <Checkbox
      checked={allSelected}
      onCheckedChange={handleSelectAll}
    />
  </TableHead>
)}
```

### Assignee Display

**Unassigned Cases**:
```tsx
<Badge variant="outline" className="border-amber-300 text-amber-700 bg-amber-50">
  Unassigned
</Badge>
```

**Assigned Cases**:
```tsx
<span className="text-sm">{caseItem.assignedTo}</span>
```

### Past Due Visual Indicator

**Row Background**:
```tsx
<TableRow className={pastDue ? 'bg-red-50' : ''}>
```

**Due Date with Icon**:
```tsx
<div className={`flex items-center gap-1 ${pastDue ? 'text-red-600 font-medium' : ''}`}>
  {pastDue && <Clock className="h-3 w-3" />}
  {caseItem.dueDate}
</div>
```

---

## User Experience Flows

### Flow 1: Analyst Self-Assigns from Workbasket

1. Analyst views worklist
2. Clicks "Unassigned" quick filter (12 cases)
3. Clicks case number "312-2025-001"
4. ✅ Toast: "Case assigned to you - Case 312-2025-001 has been assigned to you"
5. Case details page opens
6. Case now shows as assigned in worklist

### Flow 2: Manager Bulk Assignment

1. Manager views worklist
2. Clicks "Unassigned" quick filter (12 cases)
3. Selects multiple cases using checkboxes
4. Clicks "Assign 5 Cases" button
5. Dialog opens: "Assign Cases - Assign 5 selected case(s) to a team member"
6. Selects "Michael Chen (Analyst)" from dropdown
7. Clicks "Assign Cases"
8. ✅ Toast: "5 case(s) assigned - Successfully assigned to Michael Chen"
9. Cases now show Michael Chen as assignee

### Flow 3: Manager Reassignment

1. Manager views worklist with "In Progress" filter
2. Sees cases assigned to Sarah Mitchell
3. Selects 3 cases currently assigned to Sarah
4. Clicks "Assign 3 Cases"
5. Selects "Carlos Rivera (Analyst)"
6. Confirms reassignment
7. ✅ Cases moved from Sarah to Carlos
8. Toast: "3 case(s) assigned - Successfully assigned to Carlos Rivera"

### Flow 4: Past Due Cases

1. User clicks "Past Due" quick filter
2. Sees 4 overdue cases with red background
3. Due dates shown in red with clock icon
4. Manager can bulk assign to available analysts

---

## Permissions Matrix

### Worklist View Permissions

| Role | See All Cases? | See All LOBs? | See Unassigned? | See In Progress? | See Past Due? |
|------|---------------|---------------|-----------------|------------------|---------------|
| **Central Team Analyst** | ✅ Yes (312/CAM by entitlement) | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |
| **Central Team Manager** | ✅ Yes (312/CAM by entitlement) | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |
| **Sales Owner** | ✅ Yes (assigned only) | ✅ Yes | ❌ No | ✅ Yes (own) | ✅ Yes (own) |
| **View Only** | ✅ Yes (312/CAM by entitlement) | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |

### Assignment Permissions

| Action | Analyst | Manager | Sales Owner | View Only |
|--------|---------|---------|-------------|-----------|
| **Self-Assign Unassigned Case** | ✅ Yes | ❌ No | ❌ No | ❌ No |
| **Bulk Select Cases** | ❌ No | ✅ Yes | ❌ No | ❌ No |
| **Bulk Assign Cases** | ❌ No | ✅ Yes | ❌ No | ❌ No |
| **Reassign Cases** | ❌ No | ✅ Yes | ❌ No | ❌ No |
| **Assign to Sales Owner** | ❌ No | ✅ Yes | ❌ No | ❌ No |
| **Assign to Central Team** | ❌ No | ✅ Yes | ❌ No | ❌ No |

---

## Past Due Calculation

**Logic**:
```typescript
const today = new Date();
today.setHours(0, 0, 0, 0);

const isPastDue = (dueDate: string) => {
  const due = new Date(dueDate);
  due.setHours(0, 0, 0, 0);
  return due < today;
};
```

**Filter**:
```typescript
if (quickFilter === 'pastDue') {
  const dueDate = new Date(caseItem.dueDate);
  dueDate.setHours(0, 0, 0, 0);
  if (dueDate >= today) return false; // Exclude non-past-due
}
```

---

## Toast Notifications

### Self-Assignment Success
```typescript
toast.success('Case assigned to you', {
  description: `Case ${caseId} has been assigned to you.`
});
```

### Bulk Assignment Success
```typescript
toast.success(`${selectedCases.size} case(s) assigned`, {
  description: `Successfully assigned to ${selectedAssignee}`
});
```

### Error: No Cases Selected
```typescript
toast.error('No cases selected', {
  description: 'Please select at least one case to assign.'
});
```

### Error: No Assignee Selected
```typescript
toast.error('No assignee selected', {
  description: 'Please select a user to assign the cases to.'
});
```

---

## Implementation Details

### State Management

```typescript
const [selectedCases, setSelectedCases] = useState<Set<string>>(new Set());
const [bulkAssignDialogOpen, setBulkAssignDialogOpen] = useState(false);
const [selectedAssignee, setSelectedAssignee] = useState<string>('');
const [quickFilter, setQuickFilter] = useState<QuickFilter>('all');
```

### Select All Logic

```typescript
const handleSelectAll = (checked: boolean) => {
  if (checked) {
    // For managers, select all visible cases
    // For analysts, only unassigned cases (but analysts don't have bulk select)
    const selectableCases = filteredAndSortedCases
      .filter(c => c.assignedTo === 'Unassigned' || isManager)
      .map(c => c.id);
    setSelectedCases(new Set(selectableCases));
  } else {
    setSelectedCases(new Set());
  }
};
```

### Individual Case Selection

```typescript
const handleSelectCase = (caseId: string, checked: boolean) => {
  const newSelected = new Set(selectedCases);
  if (checked) {
    newSelected.add(caseId);
  } else {
    newSelected.delete(caseId);
  }
  setSelectedCases(newSelected);
};
```

---

## Data Updates

### Case Assignment Handler

```typescript
const handleCaseAssigned = (caseId: string, assignee: string) => {
  // In a real app, this would call an API
  const caseToUpdate = mockCases.find(c => c.id === caseId);
  if (caseToUpdate) {
    caseToUpdate.assignedTo = assignee;
    
    // If case was unassigned, change status to In Progress
    if (caseToUpdate.status === 'Unassigned') {
      caseToUpdate.status = 'In Progress';
    }
  }
};
```

**Real Implementation**:
```typescript
// API call example
const assignCase = async (caseId: string, assignee: string) => {
  const response = await fetch('/api/cases/${caseId}/assign', {
    method: 'POST',
    body: JSON.stringify({ assignee }),
    headers: { 'Content-Type': 'application/json' }
  });
  
  if (!response.ok) throw new Error('Assignment failed');
  return response.json();
};
```

---

## Acceptance Criteria

### ✅ Worklist Filtering Shortcuts
- [x] Unassigned filter shows all cases with no assignee
- [x] In Progress filter shows all cases with status = "In Progress"
- [x] Past Due filter shows all cases where due date < today
- [x] Quick filters have count badges
- [x] Filters are mutually exclusive (radio button behavior)

### ✅ Case Visibility
- [x] All users can see all cases regardless of LOB
- [x] Filtering still applies for case type (312/CAM) entitlements
- [x] Employee case access still controlled by entitlement

### ✅ Self-Assignment
- [x] Analysts can click case number to self-assign unassigned cases
- [x] Case automatically assigns to clicking analyst
- [x] Status changes from Unassigned to In Progress
- [x] Toast notification confirms assignment
- [x] Case details page opens after assignment

### ✅ Manager Bulk Assignment
- [x] Managers see checkbox column
- [x] Checkboxes available for all cases (not just unassigned)
- [x] Select all checkbox in header
- [x] "Assign X Cases" button appears when cases selected
- [x] Assignment dialog shows all available team members
- [x] Can assign to Central Team members or Sales Owners
- [x] Reassignment between users supported
- [x] Success toast with count and assignee name

### ✅ Past Due Visual Indicators
- [x] Past due rows have red background tint
- [x] Due date shown in red with clock icon
- [x] Past Due quick filter button is red (destructive variant)

---

## Related Files

- `/components/CaseWorklist.tsx` - Main worklist with assignment features
- `/App.tsx` - Case assignment handler
- `/data/rolesEntitlementsMockData.ts` - User roles and permissions
- `/data/enhancedMockData.ts` - Mock case data
- `/types/index.ts` - Type definitions
- `/components/ui/dialog.tsx` - Assignment dialog
- `/components/ui/checkbox.tsx` - Bulk selection
- `/components/ui/sonner.tsx` - Toast notifications

---

**Document Version**: 1.0  
**Last Updated**: October 26, 2025  
**Status**: Implementation Complete
