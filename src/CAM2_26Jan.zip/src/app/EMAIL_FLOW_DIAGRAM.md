# Email Notification Flow Diagram

## Email Trigger Decision Tree

```
                        ┌─────────────────────────────────┐
                        │   Case Workflow In Progress     │
                        │   Analyst Working on Case       │
                        └─────────────┬───────────────────┘
                                      │
                                      ▼
                        ┌─────────────────────────────────┐
                        │   Section 3: 312 Case           │
                        │   Analyst Answers Q1-Q4         │
                        └─────────────┬───────────────────┘
                                      │
                                      ▼
                        ┌─────────────────────────────────┐
                        │   Section 4: CAM Case           │
                        │   Analyst Answers Q1-Q3         │
                        └─────────────┬───────────────────┘
                                      │
                                      ▼
                        ┌─────────────────────────────────┐
                        │   Both Sections Submitted?      │
                        └─────────────┬───────────────────┘
                                      │
                         ┌────────────┴────────────┐
                         │                         │
                        NO                        YES
                         │                         │
                         ▼                         ▼
                  ┌──────────────┐      ┌─────────────────────┐
                  │  Wait for    │      │  Check Email        │
                  │  Completion  │      │  Trigger Conditions │
                  └──────────────┘      └──────────┬──────────┘
                                                   │
                                                   ▼
                                        ┌──────────────────────────┐
                                        │ What are the Statuses?   │
                                        └──────────┬───────────────┘
                                                   │
                    ┌──────────────────────────────┼──────────────────────────────┐
                    │                              │                              │
                    ▼                              ▼                              ▼
        ┌───────────────────────┐    ┌────────────────────────┐    ┌──────────────────────┐
        │ 312: No Action        │    │ 312: Send to Sales     │    │ Other Combination    │
        │ CAM: No Action        │    │ CAM: Send to Sales     │    │ (Invalid)            │
        │ Case: Complete        │    │ Case: Pending Sales    │    └──────────┬───────────┘
        └───────────┬───────────┘    └────────────┬───────────┘               │
                    │                              │                           │
                    ▼                              ▼                           ▼
        ┌───────────────────────┐    ┌────────────────────────┐    ┌──────────────────────┐
        │ ✅ TRIGGER EMAIL      │    │ ⚠️ TRIGGER EMAIL       │    │ ❌ NO EMAIL SENT     │
        │ Type: No Action Req'd │    │ Type: Action Required  │    │ Wait for Valid Status│
        └───────────┬───────────┘    └────────────┬───────────┘    └──────────────────────┘
                    │                              │
                    ▼                              ▼
        ┌───────────────────────┐    ┌────────────────────────┐
        │ Generate Email        │    │ Generate Email         │
        │ • Blue Header         │    │ • Red Header           │
        │ • Checkmark Icon      │    │ • Warning Icon         │
        │ • No Reply Needed     │    │ • 30 Day Deadline      │
        │ • FYI Message         │    │ • Call to Action       │
        └───────────┬───────────┘    └────────────┬───────────┘
                    │                              │
                    └──────────────┬───────────────┘
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │ Send Email to Sales  │
                        │ Owner (Mock Send)    │
                        └──────────┬───────────┘
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │ Store Email in       │
                        │ mockSentEmails[]     │
                        └──────────┬───────────┘
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │ Show Toast           │
                        │ "Email Sent to..."   │
                        └──────────┬───────────┘
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │ Update Case Status   │
                        │ (if needed)          │
                        └──────────┬───────────┘
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │ Email Visible in     │
                        │ Notifications Page   │
                        └──────────────────────┘
```

---

## Email Type Selection Logic

```
                ┌──────────────────────────────────────┐
                │   Email Trigger Conditions Met       │
                └─────────────────┬────────────────────┘
                                  │
                                  ▼
                ┌──────────────────────────────────────┐
                │   Check Action Statuses              │
                └─────────────────┬────────────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
                    ▼                           ▼
        ┌────────────────────────┐  ┌────────────────────────┐
        │ Both "No Action"?      │  │ Any "Send to Sales"?   │
        └────────────┬───────────┘  └────────────┬───────────┘
                     │                            │
                    YES                          YES
                     │                            │
                     ▼                            ▼
        ┌────────────────────────┐  ┌────────────────────────┐
        │ Case Status =          │  │ Case Status =          │
        │ "Complete"?            │  │ "Pending Sales Review"?│
        └────────────┬───────────┘  └────────────┬───────────┘
                     │                            │
                    YES                          YES
                     │                            │
                     ▼                            ▼
        ┌────────────────────────┐  ┌────────────────────────┐
        │ ✅ NO ACTION REQUIRED  │  │ ⚠️ ACTION REQUIRED     │
        │                        │  │                        │
        │ • Green Badge          │  │ • Red Badge            │
        │ • Blue Header          │  │ • Red Header           │
        │ • Informational        │  │ • Urgent               │
        │ • No Response Needed   │  │ • Response Required    │
        │ • No Due Date          │  │ • 30-Day Deadline      │
        └────────────────────────┘  └────────────────────────┘
```

---

## User View Flow (Sales Owner)

```
                    ┌─────────────────────────────┐
                    │  Sales Owner Logs In        │
                    │  (e.g., David Park)         │
                    └───────────┬─────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │  Clicks "Notifications"     │
                    └───────────┬─────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │  Sees 2 Tabs:               │
                    │  • Notifications            │
                    │  • Sent Emails ← Click      │
                    └───────────┬─────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │  Email List Filtered to     │
                    │  Show ONLY Emails to        │
                    │  David Park                 │
                    └───────────┬─────────────────┘
                                │
                    ┌───────────┴────────────┐
                    │                        │
                    ▼                        ▼
        ┌──────────────────────┐  ┌──────────────────────┐
        │ Email 1:             │  │ Email 2:             │
        │ No Action Required   │  │ Action Required      │
        │                      │  │                      │
        │ • Green Badge        │  │ • Red Badge          │
        │ • Case: 312-...      │  │ • Case: 312-...      │
        │ • Sent: Oct 27       │  │ • Due: Nov 26        │
        └──────────┬───────────┘  └──────────┬───────────┘
                   │                         │
                   │                         │
                   └─────────┬───────────────┘
                             │
                             ▼
                  ┌────────────────────────┐
                  │ Clicks "View Email"    │
                  └────────────┬───────────┘
                               │
                               ▼
                  ┌────────────────────────┐
                  │ Modal Opens            │
                  │ • HTML View (default)  │
                  │ • Plain Text Tab       │
                  └────────────┬───────────┘
                               │
                ┌──────────────┴──────────────┐
                │                             │
                ▼                             ▼
    ┌───────────────────────┐   ┌───────────────────────┐
    │ HTML View             │   │ Plain Text View       │
    │ • Full Styling        │   │ • No Formatting       │
    │ • Colors & Icons      │   │ • Readable Text       │
    │ • Action Buttons      │   │ • Copy-Paste Ready    │
    │ • Responsive Layout   │   │ • Email Client Safe   │
    └───────────────────────┘   └───────────────────────┘
```

---

## User View Flow (Analyst/Manager)

```
                    ┌─────────────────────────────┐
                    │  Analyst Logs In            │
                    │  (e.g., Sarah Mitchell)     │
                    └───────────┬───���─────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │  Clicks "Notifications"     │
                    └───────────┬─────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │  Clicks "Sent Emails" Tab   │
                    └───────────┬─────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │  Email List Shows           │
                    │  ALL EMAILS (Not Filtered)  │
                    │  System-Wide View           │
                    └───────────┬─────────────────┘
                                │
                    ┌───────────┼────────────────────┐
                    │           │                    │
                    ▼           ▼                    ▼
        ┌─────────────────┐ ┌──────────────┐ ┌──────────────┐
        │ Emails Sent by  │ │ Emails Sent  │ │ Emails Sent  │
        │ Sarah Mitchell  │ │ by Other     │ │ to All Sales │
        │                 │ │ Analysts     │ │ Owners       │
        └─────────────────┘ └──────────────┘ └──────────────┘
                    │           │                    │
                    └───────────┼────────────────────┘
                                │
                                ▼
                    ┌─────────────────────────────┐
                    │  Full Audit Trail           │
                    │  • See who sent what        │
                    │  • See when sent            │
                    │  • See to whom              │
                    │  • Preview all emails       │
                    └─────────────────────────────┘
```

---

## Case Submission Flow with Email Trigger

```
    ┌────────────────────────────────────────────────────────┐
    │  ANALYST WORKFLOW                                      │
    └────────────────────────────────────────────────────────┘

    1. Open Case
       └─→ Case Details Page Opens

    2. Complete Section 3 (312 Case)
       ├─→ Q1: Is there additional 312 activity?
       ├─→ Q2: Is there additional high risk activity?
       ├─→ Q3: Does the activity warrant a SAR?
       └─→ Q4: What action should be taken?
               │
               ├─→ "No SAR - Continue monitoring" ────────┐
               │                                           │
               └─→ "No SAR - Request Sales Owner Input" ──┤
                                                           │
    3. Submit Section 3                                    │
       └─→ 312 Data Saved                                 │
                                                           │
    4. Complete Section 4 (CAM Case)                       │
       ├─→ Q1: Activity requiring review?                 │
       ├─→ Q2: What is your recommendation?               │
       │       │                                           │
       │       ├─→ "Continue Monitoring" ─────────────────┤
       │       │                                           │
       │       └─→ "Request Sales Owner Input" ───────────┤
       │                                                   │
       └─→ Q3: Provide analysis                           │
                                                           │
    5. Submit Section 4                                    │
       └─→ CAM Data Saved                                 │
                                                           │
           ┌───────────────────────────────────────────────┘
           │
           ▼
    ┌──────────────────────────────────────┐
    │  EMAIL TRIGGER SYSTEM CHECKS         │
    └──────────────────────────────────────┘
           │
           ├─→ Are both sections submitted? ───── NO ──→ Wait
           │                                             
           └─→ YES
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │  Check Status Combination            │
    └──────────────────────────────────────┘
           │
           ├─→ 312=No Action + CAM=No Action ──→ Generate "No Action Required" Email
           │                                              │
           │                                              ├─→ Blue header
           │                                              ├─→ Checkmark icon
           │                                              ├─→ Status: Complete
           │                                              └─→ No deadline
           │
           └─→ 312=Send to Sales OR CAM=Send to Sales ──→ Generate "Action Required" Email
                                                                  │
                                                                  ├─→ Red header
                                                                  ├─→ Warning icon
                                                                  ├─→ Status: Pending Sales Review
                                                                  └─→ Due: Today + 30 days

           ┌───────────────────────────────────────┐
           │  EMAIL SENT                           │
           └───────────────────────────────────────┘
                 │
                 ├─→ Add to mockSentEmails array
                 ├─→ Show toast notification
                 ├─→ Update case status (if needed)
                 └─→ Visible in Notifications → Sent Emails
```

---

## Email Content Structure

### No Action Required Email

```
┌─────────────────────────────────────────────────────────┐
│ ┌─────────────────────────────────────────────────────┐ │
│ │              HEADER (Blue Gradient)                 │ │
│ │                  ✓ CAM Review Complete              │ │
│ │                  No Action Required                 │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                           │
│   Dear [Sales Owner Name],                               │
│                                                           │
│   ┌─────────────────────────────────────────────────┐   │
│   │ 📋 SUMMARY (Blue background)                    │   │
│   │ No further action is required from you.         │   │
│   │ This notification is for your information only. │   │
│   └─────────────────────────────────────────────────┘   │
│                                                           │
│   ┌─────────────────────────────────────────────────┐   │
│   │ CASE DETAILS (Gray background)                  │   │
│   │ • Case ID: 312-2025-001                         │   │
│   │ • Client Name: GlobalTech Industries            │   │
│   │ • GCI Number: GCI-892341                        │   │
│   │ • Case Status: Complete ✅                      │   │
│   │ • Completion Date: October 27, 2025             │   │
│   │ • Reviewed By: Sarah Mitchell                   │   │
│   │ • Next Refresh Due: April 27, 2026              │   │
│   └─────────────────────────────────────────────────┘   │
│                                                           │
│   REVIEW OUTCOME                                          │
│   • 312 Review: No additional action required            │
│   • CAM Review: No additional action required            │
│   • Sales Owner Input: Not required                      │
│                                                           │
│   ┌───────────────────────────────────────┐              │
│   │      [View Case Details Button]       │              │
│   └───────────────────────────────────────┘              │
│                                                           │
│   ┌─────────────────────────────────────────────────┐   │
│   │ Note: No reply to this email is necessary.      │   │
│   │ This is an automated notification for records.  │   │
│   └─────────────────────────────────────────────────┘   │
│                                                           │
│ ┌─────────────────────────────────────────────────────┐ │
│ │              FOOTER (Gray background)               │ │
│ │         Client Activity Monitoring Platform         │ │
│ │           Bank of America | Merrill Lynch           │ │
│ └─────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

### Action Required Email

```
┌─────────────────────────────────────────────────────────┐
│ ┌─────────────────────────────────────────────────────┐ │
│ │              HEADER (Red Gradient)                  │ │
│ │                  ⚠️ ACTION REQUIRED                 │ │
│ │              Sales Owner Input Needed               │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                           │
│   Dear [Sales Owner Name],                               │
│                                                           │
│   ┌─────────────────────────────────────────────────┐   │
│   │ ⏰ RESPONSE REQUIRED (Red background)           │   │
│   │ You must respond within the next 30 days        │   │
│   │ to avoid delays in resolving this CAM review.   │   │
│   └─────────────────────────────────────────────────┘   │
│                                                           │
│   ┌─────────────────────────────────────────────────┐   │
│   │ CASE DETAILS (Gray background)                  │   │
│   │ • Case ID: 312-2025-001                         │   │
│   │ • Client Name: GlobalTech Industries            │   │
│   │ • GCI Number: GCI-892341                        │   │
│   │ • Case Status: Pending Sales Review ⚠️          │   │
│   │ • Assigned Date: October 27, 2025               │   │
│   │ • Response Due: November 26, 2025 🔴           │   │
│   │ • Assigned By: Sarah Mitchell                   │   │
│   └─────────────────────────────────────────────────┘   │
│                                                           │
│   REVIEW STATUS                                           │
│   • 312 Review: Send to Sales ⚠️                        │
│   • CAM Review: Send to Sales ⚠️                        │
│                                                           │
│   WHAT'S NEEDED                                           │
│   The processor requires your input regarding            │
│   business context for flagged transactions...           │
│                                                           │
│   ┌─────────────────────────────────────────────────┐   │
│   │ 📅 TIMELINE (Blue background)                   │   │
│   │ • Today: Review case details                    │   │
│   │ • Within 7 days: Provide feedback               │   │
│   │ • Within 30 days: Submit review                 │   │
│   └─────────────────────────────────────────────────┘   │
│                                                           │
│   ┌───────────────────────────────────────┐              │
│   │    [Open Case & Respond Button]       │              │
│   └───────────────────────────────────────┘              │
│                                                           │
│   ┌─────────────────────────────────────────────────┐   │
│   │ ⚠️ Important: Failure to respond may result in  │   │
│   │ delays and potential escalation to management.  │   │
│   └─────────────────────────────────────────────────┘   │
│                                                           │
│   NEXT STEPS                                              │
│   1. Log into the CAM Platform                           │
│   2. Review case details and processor analysis          │
│   3. Provide your business context                       │
│   4. Submit your sales owner review                      │
│                                                           │
│ ┌─────────────────────────────────────────────────────┐ │
│ │              FOOTER (Gray background)               │ │
│ │         Client Activity Monitoring Platform         │ │
│ │           Bank of America | Merrill Lynch           │ │
│ │  This email requires action. Please respond by due  │ │
│ │  date indicated above.                              │ │
│ └─────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

## Email Filtering Logic

```
                    ┌─────────────────────┐
                    │  User Opens         │
                    │  Sent Emails Tab    │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌──────────────────────┐
                    │  Check Current User  │
                    │  Role                │
                    └──────────┬───────────┘
                               │
                ┌──────────────┼──────────────┐
                │              │              │
                ▼              ▼              ▼
    ┌───────────────┐  ┌──────────────┐  ┌──────────────┐
    │ Sales Owner   │  │ Analyst      │  │ Manager/     │
    │               │  │              │  │ Administrator│
    └───────┬───────┘  └──────┬───────┘  └──────┬───────┘
            │                 │                  │
            ▼                 ▼                  ▼
    ┌───────────────┐  ┌──────────────┐  ┌──────────────┐
    │ Filter:       │  │ Show:        │  │ Show:        │
    │ recipientName │  │ ALL emails   │  │ ALL emails   │
    │ === userName  │  │ (system-wide)│  │ (system-wide)│
    └───────┬───────┘  └──────┬───────┘  └──────┬───────┘
            │                 │                  │
            ▼                 ▼                  ▼
    ┌───────────────┐  ┌──────────────┐  ┌──────────────┐
    │ David Park    │  │ Sarah sees:  │  │ Manager sees:│
    │ sees:         │  │ • Her emails │  │ • All emails │
    │ • 2 emails    │  │ • Others too │  │ • Full audit │
    │ (to David)    │  │ • 3 total    │  │ • 3 total    │
    └───────────────┘  └──────────────┘  └──────────────┘
```

---

## System Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                   CAM PLATFORM FRONTEND                      │
└──────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌───────────────┐    ┌────────────────┐    ┌──────────────┐
│ Case Details  │    │  Notifications │    │ Email Preview│
│ Component     │    │  Component     │    │ Component    │
│               │    │                │    │              │
│ • Section 3   │    │ • Bell icon    │    │ • HTML view  │
│ • Section 4   │    │ • 2 tabs       │    │ • Text view  │
│ • Submit btns │    │   - Notifs     │    │ • Modal      │
│               │    │   - Emails     │    │ • Filters    │
└───────┬───────┘    └────────┬───────┘    └──────┬───────┘
        │                     │                     │
        │ Calls               │ Displays            │ Displays
        ▼                     ▼                     ▼
┌──────────────────────────────────────────────────────────────┐
│                    UTILITY FUNCTIONS                          │
│                                                               │
│  /utils/emailTriggers.ts                                     │
│  ├─ triggerEmailNotification()                               │
│  ├─ checkAndSendEmailOnSubmit()                              │
│  └─ shouldTriggerEmail()                                     │
└──────────────────────┬───────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────┐
│                    DATA LAYER                                 │
│                                                               │
│  /data/emailNotifications.ts                                 │
│  ├─ generateNoActionEmail()                                  │
│  ├─ generateActionRequiredEmail()                            │
│  └─ mockSentEmails[] (database)                              │
└──────────────────────┬───────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────┐
│                EMAIL SERVICE (Future)                         │
│                                                               │
│  Production API                                               │
│  ├─ SendGrid / AWS SES / Exchange                            │
│  ├─ Send HTML + Plain Text                                   │
│  ├─ Track delivery status                                    │
│  └─ Store in database                                        │
└──────────────────────────────────────────────────────────────┘
```

---

**Diagram Version**: 1.0  
**Last Updated**: October 27, 2025  
**Platform**: CAM - Client Activity Monitoring
