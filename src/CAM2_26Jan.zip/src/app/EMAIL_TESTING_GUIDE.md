# Email Notification Testing Guide

## Quick Start - View Sample Emails

### Step 1: Access Notifications Page

1. Log in as **any user**
2. Click **"Notifications"** in the sidebar
3. Click **"Sent Emails"** tab

### Step 2: View Sample Emails

You'll see **3 pre-loaded sample emails**:

#### Email 1: No Action Required ✅
- **Recipient**: David Park
- **Case**: 312-2025-AUTO-001 (Standard Manufacturing Inc.)
- **Sent by**: Sarah Mitchell
- **Type**: Green badge "No Action Required"
- **Status**: Complete

#### Email 2: Action Required ⚠️
- **Recipient**: David Park
- **Case**: 312-2025-SALES-001 (Meridian Capital Holdings)
- **Sent by**: Michael Chen
- **Type**: Red badge "Action Required"
- **Due Date**: November 21, 2025

#### Email 3: Action Required ⚠️
- **Recipient**: Amanda Torres
- **Case**: CAM-2025-015 (Pacific Technology Group)
- **Sent by**: Jennifer Wu
- **Type**: Red badge "Action Required"
- **Due Date**: November 23, 2025

### Step 3: Preview Email Content

1. Click **"View Email"** button on any email
2. Modal opens with email preview
3. Toggle between **"HTML View"** and **"Plain Text"** tabs
4. Scroll through full email content
5. See professional Merrill Lynch styling

---

## Email Filtering by User Role

### As Sales Owner (David Park)

**What you see:**
- ✅ Emails sent TO David Park only
- ✅ Email #1 (No Action Required)
- ✅ Email #2 (Action Required)
- ❌ Email #3 NOT shown (sent to Amanda Torres)

**Test:**
1. Log in as **David Park**
2. Go to Notifications → Sent Emails
3. Should see **2 emails** (both for David Park)

### As Analyst/Manager (Sarah Mitchell)

**What you see:**
- ✅ ALL sent emails (system-wide view)
- ✅ Can see emails sent by all analysts
- ✅ Can see emails sent to all sales owners

**Test:**
1. Log in as **Sarah Mitchell**
2. Go to Notifications → Sent Emails
3. Should see **3 emails** (all sample emails)

### As Another Sales Owner (Amanda Torres)

**What you see:**
- ✅ Emails sent TO Amanda Torres only
- ✅ Email #3 (Action Required)
- ❌ Emails #1 and #2 NOT shown (sent to David Park)

**Test:**
1. Log in as **Amanda Torres**
2. Go to Notifications → Sent Emails
3. Should see **1 email** (for Amanda Torres)

---

## Email Preview Features

### HTML View Tab

**What you'll see:**
- ✅ Full color styling (Merrill Lynch theme)
- ✅ Gradient header (blue for "No Action", red for "Action Required")
- ✅ Formatted tables with case details
- ✅ Action buttons (styled links)
- ✅ Icons and badges
- ✅ Professional footer with branding

**Colors:**
- **Primary Blue**: `#0071CE` - Headers, buttons, links
- **Destructive Red**: `#E31837` - Action Required alerts
- **Success Green**: `#15803d` - Complete status badges
- **Gold**: `#D4AF37` - Deadline warnings

### Plain Text Tab

**What you'll see:**
- ✅ Same content as HTML view
- ✅ Plain text formatting (no HTML tags)
- ✅ Clear section headers with dashes
- ✅ Readable on any email client
- ✅ Copy-paste friendly

---

## Testing Email Types

### Type 1: No Action Required Email

**Key Elements to Verify:**

1. **Subject Line**:
   ```
   CAM Review Complete - No Action Required: [Client Name] ([Case ID])
   ```

2. **Header**:
   - ✅ Blue gradient background
   - ✅ White checkmark icon (✓)
   - ✅ "CAM Review Complete" title
   - ✅ "No Action Required" subtitle

3. **Summary Box**:
   - ✅ Light blue background
   - ✅ Text: "No further action is required from you at this time"
   - ✅ "This notification is for your information only"

4. **Case Details Table**:
   - ✅ Case ID
   - ✅ Client Name
   - ✅ GCI Number
   - ✅ Case Status: "Complete" (green badge)
   - ✅ Completion Date
   - ✅ Reviewed By (processor name)
   - ✅ Next Refresh Due (if applicable)

5. **Review Outcome**:
   - ✅ 312 Review: No additional action required
   - ✅ CAM Review: No additional action required
   - ✅ Sales Owner Input: Not required

6. **Footer Note**:
   - ✅ Gray background box
   - ✅ "No reply to this email is necessary"
   - ✅ "This is an automated notification for your records"

7. **Branding Footer**:
   - ✅ "Client Activity Monitoring Platform"
   - ✅ "Bank of America | Merrill Lynch"
   - ✅ "This is an automated message. Please do not reply to this email."

### Type 2: Action Required Email

**Key Elements to Verify:**

1. **Subject Line**:
   ```
   ACTION REQUIRED: Sales Owner Input Needed - [Client Name] ([Case ID])
   ```

2. **Header**:
   - ✅ Red gradient background
   - ✅ Warning icon (⚠️)
   - ✅ "ACTION REQUIRED" title
   - ✅ "Sales Owner Input Needed" subtitle

3. **Alert Box** (Red):
   - ✅ Red background
   - ✅ Clock icon (⏰)
   - ✅ Text: "You must respond within the next 30 days"
   - ✅ Clear urgency messaging

4. **Case Details Table**:
   - ✅ Case ID
   - ✅ Client Name
   - ✅ GCI Number
   - ✅ Case Status: "Pending Sales Review" (yellow badge)
   - ✅ Assigned Date
   - ✅ **Response Due** (red text, bold)
   - ✅ Assigned By (processor name)

5. **Review Status**:
   - ✅ 312 Review: "Send to Sales" (red badge)
   - ✅ CAM Review: "Send to Sales" (red badge)

6. **What's Needed Section**:
   - ✅ Clear description of required input
   - ✅ Details about flagged activities
   - ✅ Expected response from sales owner

7. **Timeline Box** (Blue background):
   - ✅ Calendar icon (📅)
   - ✅ Today: Review case details
   - ✅ Within 7 days: Provide feedback
   - ✅ Within 30 days: Submit review

8. **Call-to-Action Button**:
   - ✅ Large red button
   - ✅ Text: "Open Case & Respond"
   - ✅ Link to case dashboard

9. **Important Notice** (Gold border):
   - ✅ Warning icon
   - ✅ Consequences of missing deadline
   - ✅ "may result in delays and escalation"

10. **Next Steps** (Numbered list):
    - ✅ 1. Log into CAM Platform
    - ✅ 2. Review case details
    - ✅ 3. Provide business context
    - ✅ 4. Submit sales owner review

11. **Help Section**:
    - ✅ "Questions? Contact [processor name]"
    - ✅ Reply option mentioned

---

## Email Metadata Verification

### For Each Email, Verify:

1. **Email ID**: Unique identifier (e.g., `EMAIL-312-2025-001-1730000000000`)
2. **Case ID**: Matches associated case
3. **Recipient**: Correct sales owner name
4. **Recipient Email**: Valid email format
5. **Sender**: Processor name or "CAM Platform"
6. **Sender Email**: `cam-noreply@bofa.com`
7. **Sent Date**: Current date in YYYY-MM-DD format
8. **Sent Time**: Current time in 12-hour format
9. **Type**: `no_action_required` or `action_required`
10. **Case Status**: `Complete` or `Pending Sales Review`
11. **312 Status**: `No Action` or `Send to Sales`
12. **CAM Status**: `No Action` or `Send to Sales`
13. **Due Date** (Action Required only): 30 days from sent date

---

## Mobile Responsiveness Testing

### Test on Different Screen Sizes

1. **Desktop (1920x1080)**:
   - ✅ Email preview modal is 4xl width
   - ✅ Content centered
   - ✅ All sections visible without scrolling header
   - ✅ Scroll area shows full content

2. **Tablet (768px)**:
   - ✅ Modal adapts to smaller width
   - ✅ Case details grid stacks vertically
   - ✅ Buttons remain full width
   - ✅ Text remains readable

3. **Mobile (375px)**:
   - ✅ Modal takes full screen
   - ✅ Tables scroll horizontally if needed
   - ✅ Action buttons stack vertically
   - ✅ Font sizes remain legible

### How to Test

1. Open email preview
2. Open browser DevTools (F12)
3. Click device toolbar icon
4. Select different device sizes
5. Verify layout adapts correctly

---

## Integration Testing

### Test Email Trigger from Case Submission

**Scenario A: Trigger "No Action Required" Email**

1. Log in as **Sarah Mitchell**
2. Go to **My Cases**
3. Open case **312-2025-001**
4. Complete **Section 3 (312 Case)**:
   - Q1: No
   - Q2: No
   - Q3: No
   - Q4: No SAR - Continue monitoring
   - Click **"Submit 312 Case"**
5. Complete **Section 4 (CAM Case)**:
   - Q1: No
   - Q2: Continue Monitoring - No Action Required
   - Q3: "Client activity aligns with business model. No concerns identified."
   - Click **"Submit CAM Case"**
6. ✅ **Toast notification appears**: "Email Sent - No action required notification sent to David Park"
7. Go to **Notifications** → **Sent Emails** tab
8. ✅ **New email appears** at top of list
9. ✅ Type: "No Action Required" (green badge)
10. ✅ Recipient: David Park
11. ✅ Case ID: 312-2025-001
12. Click **"View Email"**
13. ✅ Verify full content is correct

**Scenario B: Trigger "Action Required" Email**

1. Log in as **Sarah Mitchell**
2. Go to **My Cases**
3. Open a different case (e.g., 312-2025-002)
4. Complete **Section 3 (312 Case)**:
   - Q1-Q3: Answer as appropriate
   - Q4: **No SAR - Request Sales Owner Input**
   - Q4.1: Select **David Park**
   - Click **"Submit 312 Case"**
5. Complete **Section 4 (CAM Case)**:
   - Q2: **Request Sales Owner Input**
   - Q2.1: "Need clarification on offshore wire transfers"
   - Q3: "Unusual pattern of transactions requires business context from relationship manager"
   - Click **"Submit CAM Case"**
6. ✅ **Toast notification appears**: "Email Sent - Action required notification sent to David Park"
7. ✅ **Case status updates** to "Pending Sales Review"
8. Go to **Notifications** → **Sent Emails** tab
9. ✅ **New email appears** at top of list
10. ✅ Type: "Action Required" (red badge)
11. ✅ Due Date shown in card
12. Click **"View Email"**
13. ✅ Verify:
    - Red header
    - 30-day deadline
    - Request details included
    - Call-to-action button present

---

## Common Issues & Solutions

### Issue 1: Email Not Showing

**Problem**: Email doesn't appear in Sent Emails list after case submission

**Check:**
- ✅ Did you submit BOTH Section 3 and Section 4?
- ✅ Is the case status "Complete" or "Pending Sales Review"?
- ✅ Are 312 and CAM statuses "No Action" or "Send to Sales"?
- ✅ Does the case have a sales owner assigned?
- ✅ Check browser console (F12) for errors

**Solution:**
- Verify trigger conditions in console
- Check `mockSentEmails` array in browser DevTools
- Refresh the page

### Issue 2: Wrong User Sees Email

**Problem**: Sales Owner sees emails for different sales owner

**Check:**
- ✅ Filter logic in `EmailPreview.tsx`
- ✅ Current user role and name
- ✅ Email recipient name matches current user

**Solution:**
- Verify `currentUser.name === email.recipientName`
- Check role-based filtering logic

### Issue 3: Email Formatting Broken

**Problem**: HTML view shows broken layout or missing styles

**Check:**
- ✅ All HTML tags properly closed
- ✅ Inline CSS present (no external stylesheets)
- ✅ Valid HTML structure
- ✅ No JavaScript in email (email clients block it)

**Solution:**
- Validate HTML with W3C validator
- Use table-based layout (not flexbox/grid)
- Keep all CSS inline

### Issue 4: Modal Won't Open

**Problem**: Clicking "View Email" doesn't open modal

**Check:**
- ✅ Dialog component imported correctly
- ✅ No console errors
- ✅ `selectedEmail` state updating

**Solution:**
- Check Dialog trigger and content
- Verify state management
- Clear browser cache

---

## Performance Testing

### Load Testing

Test with many emails:

1. Add 50+ sample emails to `mockSentEmails`
2. Navigate to Sent Emails tab
3. ✅ Page loads within 2 seconds
4. ✅ Scrolling is smooth
5. ✅ Filters work quickly

### Email Size Testing

Test with large email content:

1. Create email with 10,000+ words
2. Open email preview
3. ✅ Scroll area works correctly
4. ✅ No layout breaking
5. ✅ Browser doesn't freeze

---

## Accessibility Testing

### Keyboard Navigation

1. Tab through email list
2. ✅ Each card is focusable
3. ✅ "View Email" button accessible via keyboard
4. ✅ Modal can be opened with Enter/Space
5. ✅ Modal can be closed with Escape
6. ✅ Tab order is logical

### Screen Reader Testing

1. Use screen reader (NVDA, JAWS, VoiceOver)
2. ✅ Email type announced correctly
3. ✅ Recipient name read
4. ✅ Date/time read
5. ✅ Case ID read
6. ✅ Button labels descriptive

### Color Contrast

1. Check color contrast ratios:
   - ✅ Text on white: 4.5:1 minimum
   - ✅ Buttons: 3:1 minimum
   - ✅ Status badges: readable

---

## Regression Testing Checklist

After any code changes, verify:

- [ ] Sample emails still appear in list
- [ ] Email filtering by user works
- [ ] HTML view renders correctly
- [ ] Plain text view shows content
- [ ] Modal opens/closes properly
- [ ] Tabs switch between HTML/Text
- [ ] Resend button present (even if non-functional)
- [ ] Case details accurate
- [ ] Sent date/time formatted correctly
- [ ] Status badges correct colors
- [ ] No console errors
- [ ] Responsive on all screen sizes
- [ ] Toast notifications appear on case submit
- [ ] Email triggers when conditions met

---

## Test Data Reference

### Sample Email Recipients

| Name | Role | Email | Cases |
|------|------|-------|-------|
| David Park | Sales Owner | david.park@bofa.com | 2 emails |
| Amanda Torres | Sales Owner | amanda.torres@bofa.com | 1 email |

### Sample Email Senders

| Name | Role | Cases Sent |
|------|------|------------|
| Sarah Mitchell | Manager | 1 email |
| Michael Chen | Analyst | 1 email |
| Jennifer Wu | Analyst | 1 email |

### Sample Cases

| Case ID | Client | Type | Status |
|---------|--------|------|--------|
| 312-2025-AUTO-001 | Standard Manufacturing | Complete | No Action |
| 312-2025-SALES-001 | Meridian Capital | Pending Sales | Action Req |
| CAM-2025-015 | Pacific Technology | Pending Sales | Action Req |

---

## Success Criteria

All tests pass if:

✅ All 3 sample emails appear in Notifications → Sent Emails  
✅ Emails filter correctly by user role  
✅ HTML view renders with proper styling  
✅ Plain text view shows readable content  
✅ Modal opens and closes smoothly  
✅ Tabs switch between HTML and Text  
✅ No console errors  
✅ Responsive on desktop, tablet, mobile  
✅ Accessible via keyboard  
✅ Toast appears when email triggered  
✅ New emails appear after case submission  

---

## Next Steps After Testing

1. **Report Issues**: Document any bugs found
2. **Request Changes**: Submit UI/UX improvement requests
3. **Production Setup**: Configure actual email service (SendGrid, etc.)
4. **Database Integration**: Store emails in database instead of mock array
5. **Audit Logging**: Add comprehensive email send logging
6. **Analytics**: Track email delivery and open rates

---

**Testing Guide Version:** 1.0  
**Last Updated:** October 27, 2025  
**Platform:** CAM - Client Activity Monitoring
