# Role Access Visual Matrix - Case Details UI

## Quick Reference: Who Can Edit What?

```
┌─────────────────────────────────────────────────────────────────┐
│                    CASE DETAILS SECTIONS                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Section 1: Case Banner              [All Roles: VIEW ONLY]    │
│  ├─ Case ID, Client, Status, etc.                              │
│  └─ Always visible, never editable                             │
│                                                                 │
│  Section 2: Case & Client Details    [All Roles: VIEW ONLY]    │
│  ├─ Entity/Individual Names                                    │
│  ├─ 312 Attributes (blue box)                                  │
│  ├─ CAM Attributes (emerald box)                               │
│  └─ General Case Information                                   │
│                                                                 │
│  Section 3: 312 Case                                           │
│  ├─ Read-Only Data (all can see)                               │
│  └─ Interactive Questions:                                     │
│      ✅ Analyst: CAN EDIT                                      │
│      ✅ Manager: CAN EDIT                                      │
│      ❌ View Only: READ ONLY (amber warning)                   │
│      ❌ Sales Owner: READ ONLY (amber warning)                 │
│                                                                 │
│  Section 4: CAM Case                                           │
│  ├─ Monitoring Dashboard (all can see)                         │
│  └─ Disposition Questions:                                     │
│      ✅ Analyst: CAN EDIT                                      │
│      ✅ Manager: CAN EDIT                                      │
│      ❌ View Only: READ ONLY (amber warning)                   │
│      ❌ Sales Owner: READ ONLY (amber warning)                 │
│                                                                 │
│  Section 5: Sales Owner Review                                 │
│  ├─ Case Processor Comments (all can see)                      │
│  └─ Sales Response Form:                                       │
│      ❌ Analyst: READ ONLY (AML Processor View)                │
│      ❌ Manager: READ ONLY (AML Processor View)                │
│      ❌ View Only: READ ONLY                                   │
│      ✅ Sales Owner: CAN EDIT                                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Detailed Role Comparison

### Central Team Analyst (Michael Chen, Jennifer Wu)

```
┌─────────────────────────────────────────────────────────────────┐
│  CENTRAL TEAM ANALYST VIEW                                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Section 1: ✅ Always Visible                                   │
│  Section 2: ✅ Always Visible (read-only)                       │
│                                                                 │
│  Section 3: 312 Case                                           │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ 📖 Read-Only Data                                        │  │
│  │  • 312 Due Date: 2025-11-15                             │  │
│  │  • Model Result: High Risk                               │  │
│  │  • Expected Activity tables                              │  │
│  │  • Source of Funds                                       │  │
│  │                                                          │  │
│  │ ✏️ EDITABLE Questions (enabled fields)                   │  │
│  │  ○ Q1: Change to expectations? [Radio: Yes/No]          │  │
│  │  ○ Q2: Change to expectations? [Radio + Textarea]       │  │
│  │  ○ Q3: Further activity not aligned? [Dropdown]         │  │
│  │  ○ Q4: Source of Funds (ML only) [Radio + Textarea]     │  │
│  │  ○ Case Action: [Dropdown ▼]                            │  │
│  │     • Complete – No action                               │  │
│  │     • Complete – TRMS filed                              │  │
│  │     • Send to Sales                                      │  │
│  │                                                          │  │
│  │  [Cancel]  [Save]  [Submit]  ← Buttons VISIBLE          │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│  Section 4: CAM Case                                           │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ 📊 Monitoring Dashboard (7 tabs, read-only)             │  │
│  │  • TRMS FLU/FLD, Other, Second Line, Fraud, etc.        │  │
│  │                                                          │  │
│  │ ✏️ EDITABLE Disposition Questions (enabled fields)       │  │
│  │  ○ Q1: Triggers addressed? [Radio + Attestations]       │  │
│  │  ○ Q2: Documentation complete? [Checkbox]               │  │
│  │  ○ Q3: CAM disposition [Dropdown]                       │  │
│  │                                                          │  │
│  │  [Cancel]  [Save]  [Submit]  ← Buttons VISIBLE          │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│  Section 5: Sales Owner Review                                 │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ 👁️ AML Processor View (read-only)                        │  │
│  │  • Can see processor comments                            │  │
│  │  • Can see sales owner response (if submitted)           │  │
│  │  • Cannot edit sales response                            │  │
│  │                                                          │  │
│  │  [No action buttons shown]                               │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

Permission Summary:
✅ actionCases: true        → CAN edit Sections 3 & 4
❌ assignCases: false       → Cannot assign/reassign
❌ reopenCases: false       → Cannot reopen completed
❌ salesFeedback: false     → Cannot edit Section 5
```

---

### Central Team Manager (Sarah Mitchell)

```
┌─────────────────────────────────────────────────────────────────┐
│  CENTRAL TEAM MANAGER VIEW                                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  SAME AS ANALYST FOR SECTIONS 1-5                              │
│  ✅ Can edit Sections 3 & 4                                     │
│  ❌ Cannot edit Section 5 (Sales Owner only)                    │
│                                                                 │
│  ADDITIONAL CAPABILITIES (outside case details):               │
│  ✅ Can assign/reassign cases from worklist                     │
│  ✅ Can reopen completed cases → Defect Remediation            │
│  ✅ Can abandon cases                                           │
│  ✅ Access to Roles & Entitlements admin page                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

Permission Summary:
✅ actionCases: true        → CAN edit Sections 3 & 4
✅ assignCases: true        → CAN assign/reassign
✅ reopenCases: true        → CAN reopen completed
✅ abandonCases: true       → CAN abandon cases
❌ salesFeedback: false     → Cannot edit Section 5
```

---

### View Only (Robert Anderson)

```
┌─────────────────────────────────────────────────────────────────┐
│  VIEW ONLY ROLE                                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Section 1: ✅ Always Visible                                   │
│  Section 2: ✅ Always Visible (read-only)                       │
│                                                                 │
│  Section 3: 312 Case                                           │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ ⚠️ AMBER WARNING BANNER                                  │  │
│  │ "View Only - You do not have permission to action       │  │
│  │  this case. All fields are read-only."                  │  │
│  │                                                          │  │
│  │ 📖 All Data Visible (but greyed out)                     │  │
│  │  • Model Result: High Risk                               │  │
│  │  • Expected Activity tables                              │  │
│  │  • Questions (disabled fields, greyed out)               │  │
│  │    ○ Q1: [Radio disabled]                                │  │
│  │    ○ Q2: [Textarea disabled]                             │  │
│  │    ○ Q3: [Dropdown disabled]                             │  │
│  │    ○ Q4: [Textarea disabled]                             │  │
│  │    ○ Case Action: [Dropdown disabled]                    │  │
│  │                                                          │  │
│  │  [No action buttons]  ← Buttons HIDDEN                   │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│  Section 4: CAM Case                                           │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ ⚠️ AMBER WARNING BANNER (same as Section 3)              │  │
│  │                                                          │  │
│  │ 📊 Monitoring Dashboard (can navigate tabs)              │  │
│  │ 📖 Questions (all disabled, greyed out)                  │  │
│  │                                                          │  │
│  │  [No action buttons]  ← Buttons HIDDEN                   │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│  Section 5: Sales Review - Read-only                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

Permission Summary:
❌ actionCases: false       → CANNOT edit anything
✅ reviewData: true         → CAN see all data
❌ assignCases: false       → Cannot assign/reassign
❌ salesFeedback: false     → Cannot edit Section 5
```

---

### Sales Owner (David Park, Amanda Torres)

```
┌─────────────────────────────────────────────────────────────────┐
│  SALES OWNER VIEW                                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Section 1: ✅ Visible                                          │
│  Section 2: ✅ Visible (read-only)                              │
│                                                                 │
│  Section 3: 312 Case                                           │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ ⚠️ AMBER WARNING BANNER                                  │  │
│  │ "Sales Owner View - Sections 3 & 4 are read-only."      │  │
│  │                                                          │  │
│  │ 📖 PRIVACY-FILTERED DATA                                 │  │
│  │  • Expected Activity: Counts only (no $)                 │  │
│  │  • Model Result: High Risk (summary only)                │  │
│  │  • NO transaction details                                │  │
│  │  • NO monitoring alerts                                  │  │
│  │  • All fields disabled (greyed out)                      │  │
│  │                                                          │  │
│  │  [No action buttons]                                     │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│  Section 4: CAM Case                                           │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ 📖 PRIVACY-FILTERED SUMMARY                              │  │
│  │  • CAM Trigger counts (aggregated)                       │  │
│  │  • NO detailed monitoring data                           │  │
│  │  • NO TRMS case details                                  │  │
│  │  • All fields disabled                                   │  │
│  │                                                          │  │
│  │  [No action buttons]                                     │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
│  Section 5: Sales Owner Review                                 │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ ✏️ EDITABLE SECTION (Sales Owner Access)                 │  │
│  │                                                          │  │
│  │ 📖 Case Processor Comments (read-only)                   │  │
│  │  • "Please provide business context for..."             │  │
│  │  • "What is the source of recent activity spike?"       │  │
│  │                                                          │  │
│  │ ✏️ Sales Owner Response (EDITABLE)                       │  │
│  │  [Textarea: 4000 char limit]                             │  │
│  │  │ This client's activity is related to seasonal      │ │  │
│  │  │ commodity trading. The increase is expected and    │ │  │
│  │  │ aligns with their business model...                │ │  │
│  │  └─────────────────────────────────────────────────────┘│  │
│  │                                                          │  │
│  │  Character count: 234 / 4000                             │  │
│  │                                                          │  │
│  │  [Save Draft]  [Return to AML Processor]  ← VISIBLE     │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

Permission Summary:
❌ actionCases: false       → CANNOT edit Sections 3 & 4
✅ salesFeedback: true      → CAN edit Section 5
✅ returnToAnalyst: true    → CAN return case to analyst
❌ viewDashboard: false     → No dashboard access (worklist only)

Privacy Protection:
- Sections 3 & 4: Filtered data to prevent "tipping off"
- Section 5: Full access to provide business context
```

---

## Field-Level Edit Matrix

| Section | Field Type | Analyst | Manager | View Only | Sales Owner |
|---------|-----------|---------|---------|-----------|-------------|
| **Section 1** | Case Banner | ❌ Read | ❌ Read | ❌ Read | ❌ Read |
| **Section 2** | All Fields | ❌ Read | ❌ Read | ❌ Read | ❌ Read |
| **Section 3** | Read-only data | ❌ Read | ❌ Read | ❌ Read | ❌ Read (filtered) |
| **Section 3** | Question 1 | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 3** | Question 2 | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 3** | Question 3 | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 3** | Question 4 | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 3** | Case Action | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 4** | Dashboard tabs | ❌ Read | ❌ Read | ❌ Read | ❌ Hidden |
| **Section 4** | Question 1 | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 4** | Question 2 | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 4** | Question 3 | ✅ Edit | ✅ Edit | ❌ Read | ❌ Read |
| **Section 5** | Processor comments | ❌ Read | ❌ Read | ❌ Read | ❌ Read |
| **Section 5** | Sales response | ❌ Read | ❌ Read | ❌ Read | ✅ Edit |

---

## Action Button Visibility

| Section | Button | Analyst | Manager | View Only | Sales Owner |
|---------|--------|---------|---------|-----------|-------------|
| **Section 3** | Cancel | ✅ Show | ✅ Show | ❌ Hide | ❌ Hide |
| **Section 3** | Save | ✅ Show | ✅ Show | ❌ Hide | ❌ Hide |
| **Section 3** | Submit | ✅ Show | ✅ Show | ❌ Hide | ❌ Hide |
| **Section 4** | Cancel | ✅ Show | ✅ Show | ❌ Hide | ❌ Hide |
| **Section 4** | Save | ✅ Show | ✅ Show | ❌ Hide | ❌ Hide |
| **Section 4** | Submit | ✅ Show | ✅ Show | ❌ Hide | ❌ Hide |
| **Section 5** | Save Draft | ❌ Hide | ❌ Hide | ❌ Hide | ✅ Show |
| **Section 5** | Return to AML | ❌ Hide | ❌ Hide | ❌ Hide | ✅ Show |

**Note**: After submission, all action buttons hide for everyone (section is locked)

---

## Warning Banner Display

| Section | Analyst | Manager | View Only | Sales Owner |
|---------|---------|---------|-----------|-------------|
| **Section 3** | No banner | No banner | ⚠️ "View Only - no permission to action" | ⚠️ "Sales Owner View - read-only" |
| **Section 4** | No banner | No banner | ⚠️ "View Only - no permission to action" | ⚠️ "Sales Owner View - read-only" |
| **Section 5** | 👁️ "AML Processor View" | 👁️ "AML Processor View" | 👁️ Read-only | ✏️ "Sales Owner Access" |

---

## Submitted/Locked State (All Roles)

When a section is submitted, ALL roles see the same locked state:

```
┌─────────────────────────────────────────────────────────────┐
│  Section 3: 312 Case                [🔒 Submitted]          │
├─────────────────────────────────────────────────────────────┤
│  ✅ Submitted by Michael Chen on 2025-10-28                 │
│                                                             │
│  All data is now read-only (locked)                         │
│  ○ Q1: Yes - Business Model Change                          │
│  ○ Q2: Yes - "Client expanded operations to..."            │
│  ○ Q3: No further review needed                             │
│  ○ Q4: Yes - "Source of funds verified..."                  │
│  ○ Case Action: Complete – No action required               │
│                                                             │
│  [No buttons shown - section is locked]                     │
└─────────────────────────────────────────────────────────────┘
```

**Key**: Once submitted, even Analysts and Managers cannot edit unless:
- Manager reopens case (Defect Remediation)
- Original completion date is preserved

---

## Quick Decision Tree: Can I Edit This Section?

```
Start: User opens case
  │
  ├─ Section 1 (Banner)?
  │   └─→ NO (always read-only for everyone)
  │
  ├─ Section 2 (Case Details)?
  │   └─→ NO (always read-only for everyone)
  │
  ├─ Section 3 (312 Case)?
  │   ├─ Is it already submitted? 
  │   │   └─→ YES → NO (locked for everyone)
  │   └─ Is it not submitted?
  │       ├─ Am I Analyst or Manager?
  │       │   └─→ YES → ✅ CAN EDIT
  │       └─ Am I View Only or Sales Owner?
  │           └─→ YES → NO (read-only)
  │
  ├─ Section 4 (CAM Case)?
  │   ├─ Is it already submitted?
  │   │   └─→ YES → NO (locked for everyone)
  │   └─ Is it not submitted?
  │       ├─ Am I Analyst or Manager?
  │       │   └─→ YES → ✅ CAN EDIT
  │       └─ Am I View Only or Sales Owner?
  │           └─→ YES → NO (read-only)
  │
  └─ Section 5 (Sales Review)?
      ├─ Is it already submitted?
      │   └─→ YES → NO (locked for everyone)
      └─ Is it not submitted?
          ├─ Am I Sales Owner?
          │   └─→ YES → ✅ CAN EDIT
          └─ Am I Analyst, Manager, or View Only?
              └─→ YES → NO (read-only)
```

---

## Summary Table: Edit Permissions

| Role | Sec 1 | Sec 2 | Sec 3 | Sec 4 | Sec 5 | Notes |
|------|-------|-------|-------|-------|-------|-------|
| **Analyst** | ❌ | ❌ | ✅ | ✅ | ❌ | Can action cases |
| **Manager** | ❌ | ❌ | ✅ | ✅ | ❌ | Same as Analyst + assign/reopen |
| **View Only** | ❌ | ❌ | ❌ | ❌ | ❌ | Can see everything, edit nothing |
| **Sales Owner** | ❌ | ❌ | ❌ | ❌ | ✅ | Sections 3&4 filtered, 5 editable |

**Legend**:
- ✅ = Can edit (fields enabled, buttons visible)
- ❌ = Cannot edit (read-only or not visible)

---

**Last Updated**: November 4, 2025  
**Version**: 1.0  
**Purpose**: Quick visual reference for role-based access control
