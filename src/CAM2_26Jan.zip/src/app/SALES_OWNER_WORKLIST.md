# Sales Owner Worklist

## Overview

Sales Owners have a dedicated worklist that displays all cases assigned to them for sales review, regardless of stage or status. This provides Sales Owners with visibility into cases requiring their business context, relationship feedback, or client insights to support the central team's case analysis.

---

## Navigation

**Menu Location**: Sidebar → "My Cases" (when logged in as Sales Owner)  
**Icon**: Briefcase (💼)  
**Access**: Sales Owner role users only  
**Auto-Detection**: System automatically shows Sales Owner worklist when user role = "Sales Owner"

---

## Worklist Structure

### Data Columns

The Sales Owner worklist displays 11 columns with **"Central Team Contact"** instead of "Assignee":

| # | Column | Field | Description | Sortable | Filterable |
|---|--------|-------|-------------|----------|------------|
| 1 | **Case Number** | `id` | Unique case identifier (hyperlink to case details) | ✅ Yes | ❌ No |
| 2 | **Client Name** | `clientName` | Legal or business name of the client | ✅ Yes | ❌ No |
| 3 | **GCI** | `gci` | Global Client Identifier | ❌ No | ✅ Yes (search) |
| 4 | **Client ID** | `clientId` | Internal client identifier | ❌ No | ✅ Yes (search) |
| 5 | **CoPer ID** | `coperId` | Corporate Person ID (optional) | ❌ No | ✅ Yes (search) |
| 6 | **Case Status** | `status` | Current workflow status | ✅ Yes | ✅ Yes |
| 7 | **Created Date** | `createdDate` | Date the case was created | ✅ Yes | ❌ No |
| 8 | **Due Date** | `dueDate` | Target completion date | ✅ Yes | ❌ No |
| 9 | **Central Team Contact** | `centralTeamContact` | Original analyst who sent case for review | ✅ Yes | ✅ Yes |
| 10 | **LOB(s)** | `lineOfBusiness` | Line of Business | ✅ Yes | ✅ Yes |
| 11 | **Risk Rating** | `riskLevel` | Risk assessment level | ✅ Yes | ✅ Yes |

### Key Difference: Central Team Contact vs. Assignee

**Individual Worklist (Analysts)**:
- Shows **"Assignee"** column
- Always displays current user (since they own the case)

**Sales Owner Worklist**:
- Shows **"Central Team Contact"** column
- Displays the name of the Central Team Analyst who routed the case for sales review
- Helps Sales Owner know who to contact for questions or when returning the case

---

## Filtering Logic

### Primary Filter: Assigned to Current Sales Owner

**Core Logic**:
```typescript
const mySalesAssignedCases = mockCases.filter(c => {
  // MUST be assigned to the current Sales Owner
  if (c.assignedTo !== currentUser.name) return false;
  
  // Still apply entitlement filters
  if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
  if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
  if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
  
  return true;
});
```

### Included Cases

**All cases assigned to Sales Owner, regardless of**:
- ✅ **Status** - Pending Sales Review, In Sales Review, Sales Review Complete, etc.
- ✅ **Stage** - All workflow stages included
- ✅ **Date** - Historical and current cases
- ✅ **LOB** - All Lines of Business
- ✅ **Completion** - Both open and completed sales reviews

**Typical Statuses for Sales Owners**:
- Pending Sales Review (waiting for Sales Owner to open)
- In Sales Review (actively being reviewed by Sales Owner)
- Sales Review Complete (Sales Owner completed, returned to analyst)

---

## Quick Stats Dashboard

Four summary cards tailored for Sales Owners:

### 1. Total Cases
- **Metric**: Total count of all sales review cases assigned
- **Icon**: User circle icon
- **Description**: "For sales review"
- **Purpose**: Overall workload visibility

### 2. Pending Review
- **Metric**: Count of cases with status = "Pending Sales Review"
- **Icon**: Clock icon (gray)
- **Description**: "Awaiting your review"
- **Purpose**: Cases waiting to be opened by Sales Owner

### 3. In Review
- **Metric**: Count of cases with status = "In Sales Review"
- **Icon**: Clock icon (blue)
- **Color**: Blue text for count
- **Description**: "Currently reviewing"
- **Purpose**: Cases actively being worked by Sales Owner

### 4. Past Due
- **Metric**: Count of cases where due date < today
- **Icon**: Clock icon (red)
- **Color**: Red text for count
- **Description**: "Requires attention"
- **Purpose**: Overdue cases needing immediate feedback

---

## Filtering Capabilities

### 1. Search Filter
- **Fields Searched**:
  - Case Number
  - Client Name
  - GCI
  - Client ID
  - CoPer ID
- **Type**: Text input with search icon
- **Behavior**: Real-time filtering
- **Use Case**: Quick lookup of specific client cases

### 2. Status Filter
**Dropdown Options** (Sales-specific):
- All Statuses
- Pending Sales Review
- In Sales Review
- Sales Review Complete

**Note**: Only sales review workflow statuses shown (not general case statuses)

### 3. Risk Level Filter
**Dropdown Options**:
- All Risk Levels
- Critical (highest priority)
- High
- Medium
- Low

**Use Case**: Prioritize high-risk cases first

### 4. LOB Filter
**Dropdown Options**:
- All LOBs
- GB/GM
- Private Bank
- Merrill Lynch
- Consumer
- CI

**Use Case**: Filter to specific business lines

### 5. Central Team Contact Filter
**Dropdown Options**:
- All Contacts
- (Dynamically populated list of Central Team Analysts)

**Examples**:
- Michael Chen
- Jennifer Wu
- Lisa Brown
- Kevin Rogers

**Use Case**: 
- See all cases from a specific analyst
- Coordinate with specific team members
- Track follow-ups with particular analysts

---

## Sorting Capabilities

### Sortable Columns (8 total)

| Column | Sort Logic | Default |
|--------|-----------|---------|
| Case Number | Alphanumeric | - |
| Client Name | Alphabetical | - |
| Case Status | Alphabetical | - |
| Created Date | Chronological | ⭐ Newest first |
| Due Date | Chronological | - |
| Central Team Contact | Alphabetical | - |
| LOB | Alphabetical | - |
| Risk Rating | Severity (Critical → High → Medium → Low) | - |

### Three-State Sorting
1. **First Click**: Ascending (↑)
2. **Second Click**: Descending (↓)
3. **Third Click**: Clear sort (return to default)

**Default Sort**: Created Date (Descending) - newest cases first

---

## Visual Indicators

### Past Due Cases
**Row Background**: Light red (`bg-red-50`)  
**Due Date Styling**:
- Red text color (`text-red-600`)
- Bold font weight
- Clock icon (🕒) prefix
- Indicates urgent need for sales feedback

### Central Team Contact Display
Always shows with user icon:
```tsx
<div className="flex items-center gap-2">
  <UserCircle className="h-3 w-3 text-muted-foreground" />
  {caseItem.centralTeamContact || <span className="text-gray-400">Not Set</span>}
</div>
```

### CoPer ID Handling
- If present: Display in monospace font, muted color
- If absent: Display "N/A" in gray text

### Status Badge Colors
- **Pending Sales Review**: Blue badge
- **In Sales Review**: Purple badge
- **Sales Review Complete**: Indigo badge

---

## Empty States

### No Cases Assigned for Sales Review
```
No cases assigned for sales review

Cases will appear here when central team analysts 
route them for your feedback.
```

### No Matching Filters
```
No cases match your filters
```

---

## User Experience Flows

### Flow 1: Sales Owner Reviews New Cases

1. Sales Owner logs in
2. Clicks "My Cases" in sidebar
3. Quick stats show: Total (6), Pending Review (3), In Review (2), Past Due (1)
4. Sales Owner sees 6 cases in worklist
5. Filters to "Pending Sales Review"
6. Sees 3 cases waiting for review
7. Clicks case number hyperlink
8. Opens case details page
9. Reviews case and provides feedback
10. Status changes to "In Sales Review" (then "Sales Review Complete" when done)

### Flow 2: Sales Owner Prioritizes by Risk

1. Sales Owner on "My Cases" page
2. Clicks Risk Rating column header to sort
3. Sees Critical and High risk cases first
4. Opens highest priority case
5. Provides urgent feedback to central team analyst

### Flow 3: Sales Owner Filters by Analyst

1. Sales Owner views worklist
2. Clicks "Central Team Contact" filter
3. Selects "Michael Chen"
4. Sees all cases sent by Michael Chen
5. Can coordinate responses with specific analyst
6. Contacts Michael for clarification if needed

### Flow 4: Sales Owner Handles Past Due

1. Sales Owner sees Past Due stat shows "1" in red
2. Sorts by Due Date ascending to see oldest first
3. Past due row highlighted in red
4. Opens case immediately
5. Provides expedited feedback

### Flow 5: Sales Owner Reviews Specific LOB

1. Sales Owner responsible for multiple LOBs
2. Filters to "ML" (Merrill Lynch)
3. Sees only ML cases
4. Reviews cases specific to that business line
5. Provides LOB-specific context

---

## Comparison: Three Worklist Views

| Feature | Combined Workbasket | Individual Worklist | Sales Owner Worklist |
|---------|-------------------|---------------------|----------------------|
| **Filter** | All accessible cases | User's assigned cases | Sales Owner's assigned cases |
| **Purpose** | Team management | Personal workload | Sales review workload |
| **Columns** | 12 (includes 312 Y/N) | 11 (no 312 indicator) | 11 (Central Team Contact) |
| **Key Column** | Assignee | Assignee (always user) | Central Team Contact |
| **Quick Stats** | None | 4 cards (general) | 4 cards (sales-specific) |
| **Status Filter** | All statuses | All statuses | Sales review statuses only |
| **Bulk Actions** | Manager bulk assign | None | None |
| **Self-Assignment** | Available | Not applicable | Not applicable |
| **Central Team Contact Filter** | ❌ No | ❌ No | ✅ Yes |

---

## Access Control

### Who Can Access Sales Owner Worklist?

| Role | Can Access? | Cases Shown |
|------|------------|-------------|
| **Central Team Analyst** | ❌ No | Uses Individual Worklist |
| **Central Team Manager** | ❌ No | Uses Individual Worklist |
| **Sales Owner** | ✅ Yes | Own sales review cases |
| **View Only** | ❌ No | Uses Individual Worklist |

**Auto-Detection Logic**:
```typescript
{currentPage === 'my-cases' && (
  currentUser.role === 'Sales Owner' ? (
    <SalesOwnerWorklist />
  ) : (
    <IndividualWorklist />
  )
)}
```

---

## Data Visibility Rules

### Included Cases
```typescript
// Sales Owner can see a case if:
1. Case is assigned to salesOwner.name
AND
2. User has entitlement for case type (312/CAM)
AND
3. If employee case, user has employee case access
```

### Excluded Cases
- ❌ Cases assigned to other Sales Owners
- ❌ Cases not routed for sales review
- ❌ Cases user lacks entitlements for
- ❌ Employee cases (without special access)

---

## Central Team Contact Field

### Purpose
Tracks the **original Central Team Analyst** who:
- Created or was assigned the case
- Performed initial analysis
- Routed the case to the Sales Owner for feedback
- Will receive the case back after sales review

### Data Flow
```
1. Case created → assignedTo = "Central Team Analyst"
                  centralTeamContact = NULL

2. Analyst routes to sales → assignedTo = "Sales Owner"
                              centralTeamContact = "Central Team Analyst Name"

3. Sales review complete → assignedTo = "Central Team Analyst"
                            centralTeamContact = "Central Team Analyst Name" (preserved)
```

### Display Logic
```typescript
<TableCell className="text-sm">
  <div className="flex items-center gap-2">
    <UserCircle className="h-3 w-3 text-muted-foreground" />
    {caseItem.centralTeamContact || <span className="text-gray-400">Not Set</span>}
  </div>
</TableCell>
```

### Value Examples
- "Michael Chen"
- "Jennifer Wu"
- "Lisa Brown"
- "Kevin Rogers"
- "Not Set" (if routing data is missing)

---

## Implementation Details

### Component
**File**: `/components/SalesOwnerWorklist.tsx`

### Key State
```typescript
const [searchTerm, setSearchTerm] = useState('');
const [statusFilter, setStatusFilter] = useState<string>('all');
const [riskFilter, setRiskFilter] = useState<string>('all');
const [lobFilter, setLobFilter] = useState<string>('all');
const [contactFilter, setContactFilter] = useState<string>('all');
const [sortField, setSortField] = useState<SortField>('createdDate');
const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
```

### Core Filter
```typescript
const mySalesAssignedCases = mockCases.filter(c => {
  if (c.assignedTo !== currentUser.name) return false;
  if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
  if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
  if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
  return true;
});
```

### Quick Stats Calculation
```typescript
const statusCounts = useMemo(() => {
  const counts: Record<string, number> = {};
  mySalesAssignedCases.forEach(c => {
    counts[c.status] = (counts[c.status] || 0) + 1;
  });
  return counts;
}, [mySalesAssignedCases]);

const pastDueCount = mySalesAssignedCases.filter(c => {
  const dueDate = new Date(c.dueDate);
  dueDate.setHours(0, 0, 0, 0);
  return dueDate < today;
}).length;
```

### Central Team Contacts List
```typescript
const centralTeamContacts = useMemo(() => {
  const contacts = new Set<string>();
  mySalesAssignedCases.forEach(c => {
    if (c.centralTeamContact) {
      contacts.add(c.centralTeamContact);
    }
  });
  return Array.from(contacts).sort();
}, [mySalesAssignedCases]);
```

---

## Export Functionality

**Button**: "Export My Cases"  
**Location**: Top right of worklist  
**Format**: Excel (.xlsx)  
**Included Data**: All visible columns including Central Team Contact  
**Filename**: `Sales_Review_Cases_{UserName}_{Date}.xlsx`

---

## Acceptance Criteria

### ✅ Filtering
- [x] Shows only cases assigned to logged-in Sales Owner
- [x] Includes cases regardless of status
- [x] Includes cases regardless of stage
- [x] All LOBs included
- [x] Historical and current sales review cases included

### ✅ Columns
- [x] Case Number (hyperlink to case details)
- [x] Client Name
- [x] GCI
- [x] Client ID
- [x] CoPer ID (with N/A handling)
- [x] Case Status
- [x] Created Date
- [x] Due Date
- [x] Central Team Contact (NOT Assignee)
- [x] LOB(s)
- [x] Risk Rating

### ✅ Quick Stats
- [x] Total cases count
- [x] Pending Review count
- [x] In Review count (blue)
- [x] Past Due count (red)

### ✅ Filtering & Sorting
- [x] Search across identifiers
- [x] Sales-specific status dropdown
- [x] Risk level dropdown filter
- [x] LOB dropdown filter
- [x] Central Team Contact dropdown filter (unique)
- [x] 8 sortable columns
- [x] Three-state sorting

### ✅ Visual Indicators
- [x] Past due rows with red background
- [x] Past due dates in red with clock icon
- [x] User circle icon next to Central Team Contact
- [x] "Not Set" for missing Central Team Contact
- [x] N/A for missing CoPer IDs

### ✅ Empty States
- [x] No cases assigned message (sales-specific)
- [x] No matching filters message

### ✅ Auto-Detection
- [x] Automatically shows Sales Owner Worklist when user role = "Sales Owner"
- [x] Shows Individual Worklist for all other roles

---

## Use Cases

### Sales Owner Daily Workflow
1. Start day on "My Cases"
2. Review quick stats for pending and in-review counts
3. Check Past Due count for urgent items
4. Open pending cases to provide business context
5. Complete reviews and return to central team

### Relationship Manager Providing Context
1. Sales Owner sees case requiring relationship insights
2. Opens case from worklist
3. Reviews client history and relationship notes
4. Provides comments on client's business activities
5. Marks review complete, returns to central team analyst

### Multi-LOB Sales Owner
1. Sales Owner covers multiple lines of business
2. Filters worklist to specific LOB (e.g., "ML")
3. Reviews ML-specific cases first
4. Switches to another LOB filter
5. Manages workload by business line

### Coordinating with Specific Analyst
1. Sales Owner sees multiple cases from "Michael Chen"
2. Filters by Central Team Contact = "Michael Chen"
3. Reviews all of Michael's cases together
4. Contacts Michael with coordinated feedback
5. Efficient communication with central team

### Prioritizing High-Risk Cases
1. Sales Owner sorts by Risk Rating
2. Sees Critical and High risk cases at top
3. Provides urgent feedback on high-risk clients
4. Ensures timely review of most important cases

---

## Integration with Case Workflow

### Case Routing to Sales
**When Analyst routes case**:
```typescript
// Status changes
status: 'In Progress' → 'Pending Sales Review'

// Assignment changes
assignedTo: 'Analyst Name' → 'Sales Owner Name'
centralTeamContact: NULL → 'Analyst Name' (preserved)
```

### Sales Owner Opens Case
```typescript
// Status changes
status: 'Pending Sales Review' → 'In Sales Review'

// Assignment unchanged
assignedTo: 'Sales Owner Name' (unchanged)
centralTeamContact: 'Analyst Name' (preserved)
```

### Sales Review Complete
```typescript
// Status changes
status: 'In Sales Review' → 'Sales Review Complete'

// salesReviewComments added
salesReviewComments: "Client relationship context..." (required)

// Assignment back to analyst
assignedTo: 'Sales Owner Name' → 'Analyst Name' (from centralTeamContact)
centralTeamContact: 'Analyst Name' (preserved for history)
```

---

## Performance Considerations

### Filtering Performance
- Uses `useMemo` for filtered/sorted results
- Prevents recalculation on every render
- Efficient for 50+ sales review cases

### Contact List Generation
- Dynamically generates unique list of Central Team Contacts
- Uses Set for deduplication
- Sorted alphabetically for dropdown

### Stats Calculation
- Quick stats use `useMemo` with dependency on assigned cases
- Only recalculates when case list changes
- O(n) complexity for counts

---

## Related Files

- `/components/SalesOwnerWorklist.tsx` - Main component
- `/components/IndividualWorklist.tsx` - Analyst/Manager version
- `/App.tsx` - Auto-detection logic
- `/types/index.ts` - Case interface with centralTeamContact
- `/data/enhancedMockData.ts` - Sales review case examples
- `/data/rolesEntitlementsMockData.ts` - Sales Owner users

---

## Mock Data Examples

### Sample Sales Review Cases
```typescript
{
  id: 'CAM-2025-SALES-001',
  clientName: 'Sterling Capital Partners',
  status: 'Pending Sales Review',
  assignedTo: 'David Park', // Sales Owner
  centralTeamContact: 'Michael Chen', // Original analyst
  ...
}

{
  id: '312-2025-SALES-002',
  clientName: 'Meridian Wealth Advisors',
  status: 'In Sales Review',
  assignedTo: 'Amanda Torres', // Sales Owner
  centralTeamContact: 'Jennifer Wu', // Original analyst
  ...
}
```

---

## Future Enhancements

### Potential Additions
- [ ] **Quick Actions**: Complete Review, Add Comments directly from worklist
- [ ] **Response Time Tracking**: Average time to provide sales feedback
- [ ] **Client Relationship Score**: Display relationship strength indicator
- [ ] **Previous Reviews**: Show history of prior sales reviews for client
- [ ] **Collaboration Notes**: Direct messaging with Central Team Contact
- [ ] **Mobile Optimization**: Responsive design for on-the-go reviews
- [ ] **Email Notifications**: Alert when new cases routed for review
- [ ] **Bulk Feedback**: Provide feedback on multiple cases at once

---

**Document Version**: 1.0  
**Last Updated**: October 26, 2025  
**Status**: Implementation Complete
