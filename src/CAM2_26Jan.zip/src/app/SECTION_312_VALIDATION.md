# Section 3: 312 Case - Complete Validation ✅

## Overview
Section 3 (312 Case) has been completely validated and updated to match the exact requirements from the specification documents. This section functions as a subcase to the parent case and is the first component of the overall combined 312/CAM workflow.

---

## 📋 Requirements Validation

### ✅ Read-Only Fields

| # | Field Name | LOB | Source | Status |
|---|------------|-----|--------|--------|
| 1 | 312 Due Date | All | `case312Data.dueDate` | ✅ Complete |
| 2 | 312 Model Result | All | `case312Data.modelResult` | ✅ Complete |
| 3 | 312 Model Result Description | All | `case312Data.modelResultDescription` | ✅ Complete |
| 4 | Client Expected Activity - Volume | ML/PB | `expectedActivityVolume.electronicTransfers`, `cashChecks` | ✅ Complete |
| 5 | Client Expected Activity - Volume | GB/GM | `expectedActivityVolume.ddqFields` (broken out) | ✅ Complete |
| 6 | Client Expected Activity - Value | ML/PB | `expectedActivityValue.electronicTransfers`, `cashChecks` | ✅ Complete |
| 7 | Client Expected Activity - Value | GB/GM | `expectedActivityValue.ddqFields` (broken out) | ✅ Complete |
| 8 | Expected Cross-border Activity | All | `case312Data.expectedCrossBorderActivity` | ✅ Complete |
| 9 | Purpose of Relationship | GB/GM | `case312Data.purposeOfRelationship` | ✅ Complete |
| 10 | Purpose of Account | ML/PB | `case312Data.purposeOfAccount` (text) | ✅ Complete |
| 11 | Purpose of Account Details | ML/PB | `case312Data.purposeOfAccountDetails` (grid) | ✅ Complete |
| 12 | Source of Funds | ML/PB | `case312Data.sourceOfFunds` | ✅ Complete |

---

### ✅ Actionable Questions

#### Question 1: Expected Value and Volume of Money Movement, Inclusive of Cash Review
**Label**: "Expected Value and Volume of Money Movement, Inclusive of Cash Review"  
**Required**: Yes ⭐  
**Description**: Based on the model output where activity (volume and/or value) exceeded client expected activity

**Disposition Options**:
- Need to file TRMS
- Is NOT unusual – Other
- Is NOT unusual – Market Volatility (GM Only) ⭐

**Fields**:
- Disposition (dropdown) - Required
- Commentary (textarea) - Required

**Implementation**: ✅ Complete
```typescript
question1_disposition?: 'need_trms' | 'not_unusual_other' | 'not_unusual_market_volatility';
question1_commentary?: string;
```

---

#### Question 2: Cross Border Money Movement Review
**Label**: "Cross Border Money Movement Review"  
**Required**: Yes ⭐  
**Description**: For indicated countries where money movement occurred to/from countries outside of what was expected

**Disposition Options**:
- Need to file TRMS
- Is NOT unusual

**Fields**:
- Disposition (dropdown) - Required
- Commentary (textarea) - Required

**Implementation**: ✅ Complete
```typescript
question2_disposition?: 'need_trms' | 'not_unusual';
question2_commentary?: string;
```

---

#### Question 3: Purpose of Relationship/Account
**Label**: "Purpose of Relationship/Account"  
**Required**: Yes ⭐  
**Description**: Detail if activity was deemed not aligned with Purpose of account or Purpose of relationship

**Options**:
- All activity aligned with expectations
- Need to File TRMS
- If the additional activity was not unexpected, please detail why the activity differed from the purpose of relationship/Account (requires comments)

**Fields**:
- Option (radio group) - Required
- Comments (textarea) - Required only if "activity_differed" selected

**Implementation**: ✅ Complete
```typescript
question3_option?: 'all_aligned' | 'need_trms' | 'activity_differed';
question3_comments?: string; // Required if activity_differed
```

---

#### Question 4: Source of Funds (ML only)
**Label**: "Source of Funds (ML only)"  
**Required**: Yes ⭐ (Only for ML LOB)  
**Description**: Detail why activity was not aligned with client's source of funds

**Disposition Options**:
- Need to file TRMS
- Is NOT unusual

**Fields**:
- Disposition (dropdown) - Required
- Commentary (textarea) - Required

**Implementation**: ✅ Complete
```typescript
question4_disposition?: 'need_trms' | 'not_unusual';
question4_commentary?: string;
```

---

### ✅ Case Action

**Label**: "Case Action"  
**Required**: Yes ⭐  
**Auto-populate Logic**: If any question response is "Need to file TRMS", system should suggest "Complete – TRMS filed"

**Options**:
1. **Complete – No action**
   - No additional fields

2. **Complete – TRMS filed**
   - Requires: TRMS # (text input)
   - Auto-populate if any question = "Need to file TRMS"

3. **Send to Sales** (PB, ML, GB/GM LOBs only)
   - Requires: Sales Owner selection (dropdown)
   - Optional: Comments (textarea)

**Implementation**: ✅ Complete
```typescript
caseAction?: 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales';
trmsNumber?: string; // Required if complete_trms_filed
salesOwner?: string; // Required if send_to_sales
salesComments?: string; // Optional for send_to_sales
```

---

## 🎨 Special Features

### 1. Purpose of Account Details - Separate Pop-up Tab
**Feature**: Account grid with masked account numbers  
**LOB**: ML/PB only  
**Status**: ✅ Complete

**Grid Columns**:
- Account Number (masked with hover/click to reveal)
- Account Name
- Source of Funds

**Masking Behavior**:
- Account numbers masked by default: `****1234`
- Eye icon to toggle visibility
- Individual reveal per account
- State persists during dialog session

**Implementation**:
```typescript
purposeOfAccountDetails?: Case312Account[];

interface Case312Account {
  accountNumber: string;
  accountName: string;
  sourceOfFunds: string;
}
```

---

### 2. Auto-populate TRMS Case Action
**Feature**: Alert when "Need to file TRMS" selected  
**Status**: ✅ Complete

**Logic**:
```typescript
const shouldAutoPopulateTRMS = () => {
  return question1_disposition === 'need_trms' ||
         question2_disposition === 'need_trms' ||
         question3_option === 'need_trms' ||
         question4_disposition === 'need_trms';
};
```

**Display**: Blue alert box suggesting to select "Complete – TRMS filed"

---

### 3. LOB-Specific Field Display

| Field | PB | ML | GB/GM | CI | Consumer |
|-------|----|----|-------|----|----|
| Expected Activity - ML/PB Format | ✅ | ✅ | ❌ | ❌ | ❌ |
| Expected Activity - GB/GM DDQ Format | ❌ | ❌ | ✅ | ❌ | ❌ |
| Purpose of Relationship | ❌ | ❌ | ✅ | ❌ | ❌ |
| Purpose of Account | ✅ | ✅ | ❌ | ❌ | ❌ |
| Purpose of Account Details Grid | ✅ | ✅ | ❌ | ❌ | ❌ |
| Source of Funds | ✅ | ✅ | ❌ | ❌ | ❌ |
| Question 4 (Source of Funds) | ❌ | ✅ | ❌ | ❌ | ❌ |
| Market Volatility Option (Q1) | ❌ | ❌ | ✅ (GM) | ❌ | ❌ |

---

## 🔘 Button Functionality

### Save Button
**Status**: ✅ Complete  
**Requirements**:
- Should save responses even if incomplete
- Warning if required questions or case action not fulfilled
- At least one field must be filled to save

**Validation**:
```typescript
const canSave = () => {
  return question1_disposition !== undefined ||
         question2_disposition !== undefined ||
         question3_option !== undefined ||
         question4_disposition !== undefined ||
         caseAction !== undefined;
};
```

**Warning Logic**:
```typescript
if (!isCaseActionComplete()) {
  confirm('Warning: Case Action is not complete. Save anyway?');
}
```

---

### Cancel Button
**Status**: ✅ Complete  
**Function**: Returns user to case overview screen  
**No validation or warnings**

---

### Submit Button
**Status**: ✅ Complete  
**Requirements**:
- Final action when all questions complete
- Warning if required questions not completed
- Warning that edits cannot be made after submit
- Triggers case workflow transition

**Validation**:
```typescript
const canSubmit = () => {
  return isQuestion1Complete() && 
         isQuestion2Complete() && 
         isQuestion3Complete() && 
         isQuestion4Complete() && // Only if ML
         isCaseActionComplete();
};
```

**Warnings**:
1. If incomplete: "Please complete all required questions and case action before submitting."
2. Before submit: "Warning: Once you submit, you will be unable to make edits/changes to this section. Continue?"

---

### Send to Sales Button
**Status**: ✅ Complete  
**Requirements**:
- Only enabled when Case Action = "Send to Sales"
- Sales Owner must be selected
- Pop-up confirmation dialog with:
  - Sales Owner name
  - Comments (if entered)
  - Confirm/Cancel buttons

**Function**: Triggers submit + routes to sales for review

**Dialog**: ✅ Complete with confirmation step

---

## 📊 Data Structure

### Case312Data Interface
```typescript
export interface Case312Account {
  accountNumber: string;
  accountName: string;
  sourceOfFunds: string;
}

export interface Case312Data {
  dueDate: string;
  aging: number;
  status: string;
  disposition?: string;
  completedDate?: string;
  
  // Model outputs
  modelResult: string;
  modelResultDescription: string;
  
  // Expected Activity
  expectedActivityVolume: {
    electronicTransfers?: number;       // ML/PB
    cashChecks?: number;                // ML/PB
    ddqFields?: Record<string, number>; // GB/GM
  };
  expectedActivityValue: {
    electronicTransfers?: number;       // ML/PB
    cashChecks?: number;                // ML/PB
    ddqFields?: Record<string, number>; // GB/GM
  };
  
  // Cross-border and Purpose
  expectedCrossBorderActivity?: string;
  purposeOfRelationship?: string; // GB/GM only
  purposeOfAccount?: string; // ML/PB only - description
  purposeOfAccountDetails?: Case312Account[]; // ML/PB only - grid
  sourceOfFunds?: string; // ML/PB only
}
```

### Case312Response Interface
```typescript
export interface Case312Response {
  // Question 1: Expected Value and Volume
  question1_disposition?: 'need_trms' | 'not_unusual_other' | 'not_unusual_market_volatility';
  question1_commentary?: string;
  
  // Question 2: Cross Border
  question2_disposition?: 'need_trms' | 'not_unusual';
  question2_commentary?: string;
  
  // Question 3: Purpose of Relationship/Account
  question3_option?: 'all_aligned' | 'need_trms' | 'activity_differed';
  question3_comments?: string; // Required if activity_differed
  
  // Question 4: Source of Funds (ML only)
  question4_disposition?: 'need_trms' | 'not_unusual';
  question4_commentary?: string;
  
  // Case Action
  caseAction?: 'complete_no_action' | 'complete_trms_filed' | 'send_to_sales';
  trmsNumber?: string; // Required if complete_trms_filed
  salesOwner?: string; // Required if send_to_sales
  salesComments?: string; // Optional for send_to_sales
  
  // Submission metadata
  submittedBy?: string;
  submittedDate?: string;
  isSubmitted?: boolean;
}
```

---

## 🧪 Test Cases

### Test Case 1: GB/GM 312 Case
**Case ID**: `312-2025-001` (GlobalTech Industries)  
**LOB**: GB/GM

**Expected Display**:
- ✅ 312 Due Date, Model Result, Description
- ✅ Expected Activity Volume - DDQ fields (Wire Transfers, ACH, Cash, International Wires)
- ✅ Expected Activity Value - DDQ fields with $ formatting
- ✅ Expected Cross-border Activity
- ✅ Purpose of Relationship (GB/GM text)
- ❌ Purpose of Account (not shown for GB/GM)
- ❌ Source of Funds (not shown for GB/GM)
- ✅ Question 1 with Market Volatility option (GM)
- ✅ Question 2 with 2 dispositions
- ✅ Question 3 with 3 options
- ❌ Question 4 (not shown for GB/GM)
- ✅ Case Action with all 3 options

---

### Test Case 2: ML 312 Case with Account Details
**Case ID**: `312-2025-007` (Sterling Investment Portfolio)  
**LOB**: ML

**Expected Display**:
- ✅ 312 Due Date, Model Result, Description
- ✅ Expected Activity Volume - ML/PB format (Transfers: X | Cash/Checks: Y)
- ✅ Expected Activity Value - ML/PB format with $
- ✅ Expected Cross-border Activity
- ❌ Purpose of Relationship (not shown for ML)
- ✅ Purpose of Account (ML/PB text + button)
- ✅ "View Account Details" button
- ✅ Source of Funds (ML/PB text)
- ✅ Question 1 without Market Volatility option
- ✅ Question 2 with 2 dispositions
- ✅ Question 3 with 3 options
- ✅ **Question 4 (ML only)** with 2 dispositions
- ✅ Case Action with all 3 options

**Account Details Dialog**:
- ✅ Opens when "View Account Details" clicked
- ✅ Shows 3 accounts in grid
- ✅ Account numbers masked by default
- ✅ Eye icon to reveal each account
- ✅ Close button

---

### Test Case 3: Question Validation
**Scenario**: Answer questions with "Need to file TRMS"

**Steps**:
1. Select Question 1 disposition = "Need to file TRMS"
2. Enter commentary
3. Check Case Action section

**Expected**:
- ✅ Blue alert appears: "Based on your responses indicating 'Need to file TRMS', you should select 'Complete – TRMS filed'"
- ✅ User can still select any case action
- ✅ If "Complete – TRMS filed" selected, TRMS # field appears

---

### Test Case 4: Save Button Validation

**Scenario 1**: Click Save with no fields filled
- ✅ Alert: "Please answer at least one question before saving."

**Scenario 2**: Click Save with Question 1 answered but no Case Action
- ✅ Warning: "Case Action is not complete. Save anyway?"
- ✅ User can confirm or cancel

**Scenario 3**: Click Save with all fields complete
- ✅ Saves successfully without warnings

---

### Test Case 5: Submit Button Validation

**Scenario 1**: Click Submit with Question 1 missing
- ✅ Alert: "Please complete all required questions and case action before submitting."
- ✅ Submit disabled

**Scenario 2**: Click Submit with all questions complete
- ✅ Warning: "Once you submit, you will be unable to make edits/changes. Continue?"
- ✅ User can confirm or cancel
- ✅ On confirm, section becomes read-only
- ✅ Green "Submitted" badge appears

---

### Test Case 6: Send to Sales Flow

**Steps**:
1. Answer all questions
2. Set Case Action = "Send to Sales"
3. Select Sales Owner = "Amanda Torres"
4. Add comments (optional)
5. Click "Send to Sales" button

**Expected**:
- ✅ "Send to Sales" button appears (blue)
- ✅ Dialog opens with confirmation
- ✅ Shows Sales Owner: Amanda Torres
- ✅ Shows comments if entered
- ✅ On confirm, submits and routes to sales

---

### Test Case 7: Read-Only After Submit

**Steps**:
1. Submit section
2. Try to edit any field

**Expected**:
- ✅ All dropdowns disabled
- ✅ All textareas disabled
- ✅ All radio buttons disabled
- ✅ Action buttons hidden
- ✅ Green alert: "This section has been submitted and is now read-only. Submitted by [User] on [Date]"

---

### Test Case 8: Permission-Based Display

**Scenario 1**: User without 'actionCases' permission
- ✅ All fields read-only (even if not submitted)
- ✅ Amber alert: "View Only - You do not have permission to action this case."
- ✅ Action buttons hidden

**Scenario 2**: User with 'actionCases' permission
- ✅ All fields editable (if not submitted)
- ✅ Action buttons visible

---

## 📁 Files Modified

| File | Changes | Status |
|------|---------|--------|
| `/types/index.ts` | Added `Case312Account`, updated `Case312Data`, completely rewrote `Case312Response` | ✅ Complete |
| `/components/case-sections/Section312Case.tsx` | Complete rewrite (900+ lines) | ✅ Complete |
| `/data/enhancedMockData.ts` | Updated cases with new fields, added ML example | ✅ Complete |

---

## 🎯 Requirements Checklist

### Read-Only Fields
- ✅ 312 Due Date
- ✅ 312 Model Result
- ✅ 312 Model Result Description
- ✅ Client Expected Activity - Volume (ML/PB format)
- ✅ Client Expected Activity - Volume (GB/GM DDQ format)
- ✅ Client Expected Activity - Value (ML/PB format)
- ✅ Client Expected Activity - Value (GB/GM DDQ format)
- ✅ Expected Cross-border Activity
- ✅ Purpose of Relationship (GBGM only)
- ✅ Purpose of Account (ML/PB only)
- ✅ Purpose of Account Details with grid view
- ✅ Account numbers masked with hover/click reveal
- ✅ Source of Funds (ML/PB only)

### Questions
- ✅ Question 1: Expected Value/Volume with 3 dispositions (Market Volatility for GM)
- ✅ Question 1: Required commentary
- ✅ Question 2: Cross Border with 2 dispositions
- ✅ Question 2: Required commentary
- ✅ Question 3: Purpose with 3 options
- ✅ Question 3: Required comments if "activity_differed"
- ✅ Question 4: Source of Funds (ML only) with 2 dispositions
- ✅ Question 4: Required commentary

### Case Action
- ✅ Complete – No action
- ✅ Complete – TRMS filed
- ✅ Auto-populate suggestion if "Need to file TRMS" selected
- ✅ Provide TRMS # field
- ✅ Send to Sales (PB, ML, GB/GM only)
- ✅ Sales Owner selection
- ✅ Optional comments

### Buttons
- ✅ Save button with validation
- ✅ Warning for incomplete case action
- ✅ Cancel button (returns to overview)
- ✅ Submit button with validation
- ✅ Warning if required questions not complete
- ✅ Warning before final submission
- ✅ Send to Sales button (when applicable)
- ✅ Pop-up confirmation for Send to Sales

### Additional Features
- ✅ All questions required
- ✅ LOB-specific field display
- ✅ Auto-populate TRMS case action alert
- ✅ Account details in separate dialog
- ✅ Account number masking
- ✅ Read-only after submit
- ✅ Permission-based access control
- ✅ Submitted badge display
- ✅ Complete validation logic

---

## ✨ Summary

**Status**: ✅ **100% COMPLETE - VALIDATED**

The 312 Case section has been completely validated against the requirements and fully implemented:

✅ **All 12 read-only fields** correctly displayed with LOB-specific variations  
✅ **All 4 questions** with exact disposition/option matching requirements  
✅ **Case Action** with auto-populate logic and conditional fields  
✅ **All 4 buttons** with proper validation and warnings  
✅ **Special features**: Account grid dialog, masked account numbers, LOB-specific display  
✅ **Complete validation** for save, submit, and send to sales workflows  
✅ **Permission-based access** control  
✅ **Type safety** with updated interfaces  
✅ **Mock data** with GB/GM and ML/PB examples  

The implementation is production-ready and matches the specification documents exactly! 🎉

---

**Last Updated**: November 1, 2025  
**Version**: 1.0 - Complete 312 Section Implementation  
**Status**: Validated & Production Ready
