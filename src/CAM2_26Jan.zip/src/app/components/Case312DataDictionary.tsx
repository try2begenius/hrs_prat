import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Alert,
} from '@mui/material';
import {
  Description,
} from '@mui/icons-material';
import { case312Fields } from '@/app/data/case312DataDictionary';

export function Case312DataDictionary() {
  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" fontWeight={600} color="primary" gutterBottom>
          312 Case - Data Dictionary
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Comprehensive documentation of all 312 Case data fields and their formats
        </Typography>
      </Box>

      {/* Overview Alert */}
      <Alert severity="info" sx={{ mb: 3 }}>
        <Typography variant="body2" fontWeight={600} gutterBottom>
          About This Data Dictionary
        </Typography>
        <Typography variant="body2">
          This document defines all data elements used in the 312 Case section, including field names, 
          data formats, and LOB-specific requirements. Use this as a reference for data mapping and integration development.
        </Typography>
      </Alert>

      {/* 312 Case Fields */}
      <Card>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
            <Description color="primary" />
            <Typography variant="h6" fontWeight={600}>
              312 Case Data Fields
            </Typography>
          </Box>

          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: 'primary.lighter' }}>
                  <TableCell sx={{ width: '40%' }}><strong>Field Name</strong></TableCell>
                  <TableCell sx={{ width: '20%' }}><strong>Format</strong></TableCell>
                  <TableCell sx={{ width: '30%' }}><strong>Description</strong></TableCell>
                  <TableCell sx={{ width: '10%' }}><strong>LOB Specific</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {case312Fields.map((field, idx) => (
                  <TableRow key={idx} hover>
                    <TableCell>
                      <Typography variant="body2" fontWeight={500}>
                        {field.fieldName}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip 
                        label={field.format} 
                        size="small" 
                        color={
                          field.format === 'Banner Label' || field.format === 'Banner/Label' ? 'primary' :
                          field.format === 'Array' ? 'secondary' :
                          field.format === 'Boolean' ? 'success' :
                          field.format === 'Range' ? 'warning' :
                          'info'
                        }
                        variant="outlined" 
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="text.secondary">
                        {field.description || '-'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      {field.lobSpecific ? (
                        <Chip
                          label={field.lobSpecific}
                          size="small"
                          color="error"
                          variant="filled"
                        />
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          All
                        </Typography>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* LOB Legend */}
      <Card sx={{ mt: 3, border: '2px solid', borderColor: 'primary.main' }}>
        <CardContent>
          <Typography variant="h6" fontWeight={600} gutterBottom>
            Line of Business (LOB) Legend
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2, mt: 2 }}>
            <Box sx={{ bgcolor: 'error.lighter', p: 2, borderRadius: 1 }}>
              <Typography variant="body2" fontWeight={600} color="error.main" gutterBottom>
                ML/PB
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Merrill Lynch / Private Banking
              </Typography>
            </Box>
            <Box sx={{ bgcolor: 'warning.lighter', p: 2, borderRadius: 1 }}>
              <Typography variant="body2" fontWeight={600} color="warning.main" gutterBottom>
                GB/GM
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Global Banking / Global Markets
              </Typography>
            </Box>
            <Box sx={{ bgcolor: 'success.lighter', p: 2, borderRadius: 1 }}>
              <Typography variant="body2" fontWeight={600} color="success.main" gutterBottom>
                All LOBs
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Fields applicable to all lines of business
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
