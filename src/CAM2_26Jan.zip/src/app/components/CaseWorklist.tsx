import { useState, useMemo } from 'react';
import { mockCases } from '../data/enhancedMockData';
import { Case, CaseStatus, RiskLevel, LineOfBusiness } from '../types';
import { UserAccess, mockUsers } from '../data/rolesEntitlementsMockData';
import { toast } from 'sonner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { 
  Search, 
  Download, 
  Eye, 
  User, 
  Users, 
  Building2, 
  Clock, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  UserPlus,
  AlertCircle,
  Filter,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight
} from 'lucide-react';

interface CaseWorklistProps {
  onViewCase: (caseId: string) => void;
  currentUser: UserAccess;
  onCaseAssigned?: (caseId: string, assignee: string) => void;
}

type SortField = 'id' | 'clientName' | 'status' | 'createdDate' | 'dueDate' | 'assignedTo' | 'riskLevel' | 'lineOfBusiness';
type SortDirection = 'asc' | 'desc' | null;
type QuickFilter = 'all' | 'unassigned' | 'inProgress' | 'pastDue' | 'manuallyTriggered';

export function CaseWorklist({ onViewCase, currentUser, onCaseAssigned }: CaseWorklistProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [quickFilter, setQuickFilter] = useState<QuickFilter>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [lobFilter, setLobFilter] = useState<string>('all');
  const [is312Filter, setIs312Filter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('createdDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedCases, setSelectedCases] = useState<Set<string>>(new Set());
  const [bulkAssignDialogOpen, setBulkAssignDialogOpen] = useState(false);
  const [selectedAssignee, setSelectedAssignee] = useState<string>('');
  const [editCaseDialogOpen, setEditCaseDialogOpen] = useState(false);
  
  // Pagination state
  const [pageSize, setPageSize] = useState<number>(1000);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const isManager = currentUser.role === 'Manager' || currentUser.role === 'Central Team Manager';

  // Get permissions for current user
  const permissions = useMemo(() => {
    if (isManager) {
      return {
        reopenCases: true,
        assignCases: true,
        reassignCases: true
      };
    }
    return {
      reopenCases: false,
      assignCases: false,
      reassignCases: false
    };
  }, [isManager]);

  // All users can see all cases regardless of LOB (per requirements)
  // But we still filter by case type access and employee case access
  const userAccessibleCases = mockCases.filter(c => {
    // Filter by case type access
    if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
    if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
    
    // Filter employee cases - check clientData.isEmployee
    if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
    
    return true;
  });

  // Get today's date for past due calculation
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Apply quick filters, search filters, and sorting
  const filteredAndSortedCases = useMemo(() => {
    let filtered = userAccessibleCases.filter(caseItem => {
      // Quick filters
      if (quickFilter === 'unassigned' && caseItem.assignedTo !== 'Unassigned') return false;
      if (quickFilter === 'inProgress' && caseItem.status !== 'In Progress') return false;
      if (quickFilter === 'pastDue') {
        const dueDate = new Date(caseItem.dueDate);
        dueDate.setHours(0, 0, 0, 0);
        if (dueDate >= today) return false;
      }
      if (quickFilter === 'manuallyTriggered' && !caseItem.isManuallyTriggered) return false;

      // Search filter
      const matchesSearch = 
        caseItem.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.gci?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.mpId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.partyId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.clientId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.coperId?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || caseItem.status === statusFilter;
      const matchesRisk = riskFilter === 'all' || caseItem.riskLevel === riskFilter;
      const matchesLOB = lobFilter === 'all' || caseItem.lineOfBusiness === lobFilter;
      const matches312 = is312Filter === 'all' || 
        (is312Filter === 'yes' && caseItem.is312Case) ||
        (is312Filter === 'no' && !caseItem.is312Case);

      return matchesSearch && matchesStatus && matchesRisk && matchesLOB && matches312;
    });

    // Sort cases
    if (sortField && sortDirection) {
      filtered.sort((a, b) => {
        let aVal: any;
        let bVal: any;

        switch (sortField) {
          case 'id':
            aVal = a.id;
            bVal = b.id;
            break;
          case 'clientName':
            aVal = a.clientName;
            bVal = b.clientName;
            break;
          case 'status':
            aVal = a.status;
            bVal = b.status;
            break;
          case 'createdDate':
            aVal = new Date(a.createdDate);
            bVal = new Date(b.createdDate);
            break;
          case 'dueDate':
            aVal = new Date(a.dueDate);
            bVal = new Date(b.dueDate);
            break;
          case 'assignedTo':
            aVal = a.assignedTo;
            bVal = b.assignedTo;
            break;
          case 'riskLevel':
            const riskOrder = { 'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
            aVal = riskOrder[a.riskLevel];
            bVal = riskOrder[b.riskLevel];
            break;
          case 'lineOfBusiness':
            aVal = a.lineOfBusiness || '';
            bVal = b.lineOfBusiness || '';
            break;
          default:
            return 0;
        }

        if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [userAccessibleCases, searchTerm, quickFilter, statusFilter, riskFilter, lobFilter, is312Filter, sortField, sortDirection, today]);

  // Pagination calculations
  const totalPages = Math.ceil(filteredAndSortedCases.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedCases = filteredAndSortedCases.slice(startIndex, endIndex);

  // Reset to page 1 when filters change
  const resetPagination = () => {
    setCurrentPage(1);
  };

  // Handlers for pagination
  const handlePageSizeChange = (newSize: string) => {
    setPageSize(Number(newSize));
    setCurrentPage(1);
  };

  const handleFirstPage = () => setCurrentPage(1);
  const handlePrevPage = () => setCurrentPage((prev) => Math.max(1, prev - 1));
  const handleNextPage = () => setCurrentPage((prev) => Math.min(totalPages, prev + 1));
  const handleLastPage = () => setCurrentPage(totalPages);

  // Get counts for quick filter badges
  const unassignedCount = userAccessibleCases.filter(c => c.assignedTo === 'Unassigned').length;
  const inProgressCount = userAccessibleCases.filter(c => c.status === 'In Progress').length;
  const pastDueCount = userAccessibleCases.filter(c => {
    const dueDate = new Date(c.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    return dueDate < today;
  }).length;
  const manuallyTriggeredCount = userAccessibleCases.filter(c => c.isManuallyTriggered).length;

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else if (sortDirection === 'desc') {
        setSortDirection(null);
        setSortField('createdDate');
      } else {
        setSortDirection('asc');
      }
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const selectableCases = filteredAndSortedCases
        .filter(c => c.assignedTo === 'Unassigned' || isManager)
        .map(c => c.id);
      setSelectedCases(new Set(selectableCases));
    } else {
      setSelectedCases(new Set());
    }
  };

  const handleSelectCase = (caseId: string, checked: boolean) => {
    const newSelected = new Set(selectedCases);
    if (checked) {
      newSelected.add(caseId);
    } else {
      newSelected.delete(caseId);
    }
    setSelectedCases(newSelected);
  };

  const handleBulkAssign = () => {
    if (selectedCases.size === 0) {
      toast.error('No cases selected', {
        description: 'Please select at least one case to assign.'
      });
      return;
    }
    setBulkAssignDialogOpen(true);
  };

  const confirmBulkAssignment = () => {
    if (!selectedAssignee) {
      toast.error('No assignee selected', {
        description: 'Please select a user to assign the cases to.'
      });
      return;
    }

    const selectedUser = mockUsers.find(u => u.name === selectedAssignee);
    selectedCases.forEach(caseId => {
      onCaseAssigned?.(caseId, selectedAssignee);
    });

    toast.success(`${selectedCases.size} case(s) assigned`, {
      description: `Successfully assigned to ${selectedAssignee}`
    });

    setSelectedCases(new Set());
    setBulkAssignDialogOpen(false);
    setSelectedAssignee('');
  };

  const handleSelfAssign = (caseId: string) => {
    // This will be called when user clicks case number
    // If case is unassigned and user is an analyst, auto-assign
    const caseItem = mockCases.find(c => c.id === caseId);
    if (caseItem && caseItem.assignedTo === 'Unassigned' && (currentUser.role === 'Analyst' || currentUser.role === 'Central Team Analyst')) {
      onCaseAssigned?.(caseId, currentUser.name);
      toast.success('Case assigned to you', {
        description: `Case ${caseId} has been assigned to you.`
      });
    }
    onViewCase(caseId);
  };

  // Check if selected cases include complete cases that can be edited
  const selectedCasesDetails = useMemo(() => {
    return filteredAndSortedCases.filter(c => selectedCases.has(c.id));
  }, [filteredAndSortedCases, selectedCases]);

  const completeCasesSelected = useMemo(() => {
    return selectedCasesDetails.filter(c => c.status === 'Complete');
  }, [selectedCasesDetails]);

  const hasCompleteCases = completeCasesSelected.length > 0;

  // Handle reopening cases for remediation
  const handleReopenForRemediation = () => {
    if (completeCasesSelected.length === 0) {
      toast.error('No complete cases selected');
      return;
    }

    // Update cases to Defect Remediation status
    completeCasesSelected.forEach(caseItem => {
      const caseToUpdate = mockCases.find(c => c.id === caseItem.id);
      if (caseToUpdate && caseToUpdate.status === 'Complete') {
        caseToUpdate.status = 'Defect Remediation';
        caseToUpdate.defectRemediationFlag = true;
        if (caseToUpdate.completionDate && !caseToUpdate.originalCompletionDate) {
          caseToUpdate.originalCompletionDate = caseToUpdate.completionDate;
        }
        caseToUpdate.completionDate = undefined;
      }
    });

    toast.success(`${completeCasesSelected.length} case(s) reopened for remediation`, {
      description: 'Cases have been moved to Defect Remediation status'
    });

    setSelectedCases(new Set());
    setEditCaseDialogOpen(false);
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-3 w-3 opacity-50" />;
    if (sortDirection === 'asc') return <ArrowUp className="h-3 w-3" />;
    if (sortDirection === 'desc') return <ArrowDown className="h-3 w-3" />;
    return <ArrowUpDown className="h-3 w-3 opacity-50" />;
  };

  const getRiskBadgeVariant = (risk: RiskLevel) => {
    switch (risk) {
      case 'Critical': return 'destructive';
      case 'High': return 'default';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
    }
  };

  const getStatusColor = (status: CaseStatus) => {
    switch (status) {
      case 'Unassigned': return 'bg-gray-100 text-gray-800';
      case 'In Progress': return 'bg-amber-100 text-amber-800';
      case 'Pending Sales Review': return 'bg-blue-100 text-blue-800';
      case 'In Sales Review': return 'bg-purple-100 text-purple-800';
      case 'Sales Review Complete': return 'bg-indigo-100 text-indigo-800';
      case 'Complete': return 'bg-green-100 text-green-800';
      case 'Defect Remediation': return 'bg-red-100 text-red-800';
      case 'Under Review': return 'bg-purple-100 text-purple-800';
      case 'Escalated': return 'bg-destructive/10 text-destructive';
      case 'Closed': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-gray-100 text-gray-800';
    }
  };

  const formatLOB = (lob?: LineOfBusiness) => {
    if (!lob) return '-';
    const lobMap: Record<LineOfBusiness, string> = {
      'GB/GM': 'GB/GM',
      'PB': 'PB',
      'ML': 'ML',
      'Consumer': 'Consumer',
      'CI': 'CI'
    };
    return lobMap[lob] || lob;
  };

  const isPastDue = (dueDate: string) => {
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    return due < today;
  };

  // Get available assignees (Central Team members and Sales Owners)
  const availableAssignees = mockUsers.filter(u => 
    u.role === 'Analyst' || u.role === 'Manager' || u.role === 'Sales Owner'
  );

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex items-center justify-between flex-shrink-0">
        <div>
          <p className="text-muted-foreground">Combined CAM case workbasket with filtering and assignment</p>
        </div>
        <div className="flex gap-2">
          {selectedCases.size > 0 && (
            <>
              {isManager && hasCompleteCases && permissions.reopenCases && (
                <Button 
                  onClick={() => setEditCaseDialogOpen(true)}
                  variant="outline"
                  className="border-primary text-primary hover:bg-primary/10"
                >
                  <Eye className="mr-2 h-4 w-4" />
                  Edit Case{completeCasesSelected.length > 1 ? 's' : ''} ({completeCasesSelected.length})
                </Button>
              )}
              {isManager && (
                <Button onClick={handleBulkAssign} className="bg-primary">
                  <UserPlus className="mr-2 h-4 w-4" />
                  Assign {selectedCases.size} Case{selectedCases.size !== 1 ? 's' : ''}
                </Button>
              )}
            </>
          )}
          <Button variant="outline" onClick={() => {
            toast.success('Export functionality', {
              description: `Exporting ${selectedCases.size > 0 ? selectedCases.size + ' selected' : filteredAndSortedCases.length} case(s) to CSV`
            });
          }}>
            <Download className="mr-2 h-4 w-4" />
            Export {selectedCases.size > 0 ? `${selectedCases.size} Selected` : 'Cases'}
          </Button>
        </div>
      </div>

      <Card className="card-elevated">
        <CardHeader className="border-b bg-muted/30">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Combined CAM Workbasket</CardTitle>
              <CardDescription className="mt-1">
                <span className="font-medium text-primary">{filteredAndSortedCases.length}</span> of {userAccessibleCases.length} cases
                {isManager && <span className="ml-2 text-xs">(Manager: Can assign/reassign all cases)</span>}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Quick Filter Shortcuts */}
          <div className="flex gap-2 border-b pb-4">
            <Button
              variant={quickFilter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setQuickFilter('all')}
              className={quickFilter === 'all' ? 'bg-primary' : ''}
            >
              <Users className="mr-2 h-4 w-4" />
              All Cases
              <Badge variant="secondary" className="ml-2 bg-white/20 text-current">
                {userAccessibleCases.length}
              </Badge>
            </Button>
            <Button
              variant={quickFilter === 'unassigned' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setQuickFilter('unassigned')}
              className={quickFilter === 'unassigned' ? 'bg-primary' : ''}
            >
              <AlertCircle className="mr-2 h-4 w-4" />
              Unassigned
              <Badge variant="secondary" className="ml-2 bg-white/20 text-current">
                {unassignedCount}
              </Badge>
            </Button>
            <Button
              variant={quickFilter === 'inProgress' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setQuickFilter('inProgress')}
              className={quickFilter === 'inProgress' ? 'bg-primary' : ''}
            >
              <Users className="mr-2 h-4 w-4" />
              In Progress
              <Badge variant="secondary" className="ml-2 bg-white/20 text-current">
                {inProgressCount}
              </Badge>
            </Button>
            <Button
              variant={quickFilter === 'pastDue' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setQuickFilter('pastDue')}
              className={quickFilter === 'pastDue' ? 'bg-destructive' : ''}
            >
              <Clock className="mr-2 h-4 w-4" />
              Past Due
              <Badge variant="secondary" className="ml-2 bg-white/20 text-current">
                {pastDueCount}
              </Badge>
            </Button>
            <Button
              variant={quickFilter === 'manuallyTriggered' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setQuickFilter('manuallyTriggered')}
              className={quickFilter === 'manuallyTriggered' ? 'bg-primary' : ''}
            >
              <Building2 className="mr-2 h-4 w-4" />
              Manually Triggered
              <Badge variant="secondary" className="ml-2 bg-white/20 text-current">
                {manuallyTriggeredCount}
              </Badge>
            </Button>
          </div>

          {/* Standard Filters */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search case, client, GCI, MP ID, Party ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="Unassigned">Unassigned</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Pending Sales Review">Pending Sales Review</SelectItem>
                <SelectItem value="In Sales Review">In Sales Review</SelectItem>
                <SelectItem value="Sales Review Complete">Sales Review Complete</SelectItem>
                <SelectItem value="Complete">Complete</SelectItem>
                <SelectItem value="Defect Remediation">Defect Remediation</SelectItem>
              </SelectContent>
            </Select>

            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Risk Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select value={lobFilter} onValueChange={setLobFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All LOBs" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All LOBs</SelectItem>
                <SelectItem value="GB/GM">GB/GM</SelectItem>
                <SelectItem value="PB">Private Bank</SelectItem>
                <SelectItem value="ML">Merrill Lynch</SelectItem>
                <SelectItem value="Consumer">Consumer</SelectItem>
                <SelectItem value="CI">CI</SelectItem>
              </SelectContent>
            </Select>

            <Select value={is312Filter} onValueChange={setIs312Filter}>
              <SelectTrigger>
                <SelectValue placeholder="312 Case?" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cases</SelectItem>
                <SelectItem value="yes">312 Cases Only</SelectItem>
                <SelectItem value="no">CAM Only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Cases Table */}
          <div className="rounded-md border overflow-hidden flex flex-col" style={{ height: 'calc(100vh - 480px)' }}>
            <div className="overflow-auto flex-1 relative">
              <table className="w-full caption-bottom text-sm">
                <thead className="sticky top-0 z-10 bg-background">
                  <tr className="border-b">
                    {isManager && (
                      <th className="h-10 px-2 text-left align-middle font-medium w-12 bg-background">
                        <Checkbox
                          checked={selectedCases.size > 0 && selectedCases.size === filteredAndSortedCases.length}
                          onCheckedChange={handleSelectAll}
                        />
                      </th>
                    )}
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[140px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('id')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Case Number
                        <SortIcon field="id" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[180px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('clientName')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Client Name
                        <SortIcon field="clientName" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[120px] bg-background">GCI</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[100px] bg-background">MP ID</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[100px] bg-background">Party ID</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[100px] bg-background">CoPer ID</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[140px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('status')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Case Status
                        <SortIcon field="status" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[120px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('createdDate')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Created Date
                        <SortIcon field="createdDate" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[120px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('dueDate')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Due Date
                        <SortIcon field="dueDate" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[140px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('assignedTo')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Assignee
                        <SortIcon field="assignedTo" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[100px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('lineOfBusiness')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        LOB
                        <SortIcon field="lineOfBusiness" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[100px] bg-background">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('riskLevel')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Risk Rating
                        <SortIcon field="riskLevel" />
                      </Button>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[90px] bg-background">BAC Employee</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[90px] bg-background">BAC Affiliate</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[90px] bg-background">Reg O</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[90px] bg-background">312 Case</th>
                    <th className="h-10 px-2 text-left align-middle font-semibold min-w-[100px] bg-background">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedCases.map((caseItem) => {
                    const canSelect = caseItem.assignedTo === 'Unassigned' || isManager;
                    const isSelected = selectedCases.has(caseItem.id);
                    const pastDue = isPastDue(caseItem.dueDate);

                    return (
                      <tr 
                        key={caseItem.id} 
                        className={`hover:bg-muted/30 transition-colors border-b ${pastDue ? 'bg-red-50' : ''}`}
                      >
                        {isManager && (
                          <td className="p-2 align-middle">
                            <Checkbox
                              checked={isSelected}
                              onCheckedChange={(checked) => handleSelectCase(caseItem.id, checked as boolean)}
                              disabled={!canSelect}
                            />
                          </td>
                        )}
                        <td className="p-2 align-middle">
                          <button 
                            onClick={() => handleSelfAssign(caseItem.id)}
                            className="font-mono text-sm font-medium text-primary hover:underline hover:text-primary/80 transition-colors text-left"
                          >
                            {caseItem.id}
                          </button>
                        </td>
                        <td className="p-2 align-middle">
                          <div className="font-medium">{caseItem.clientName}</div>
                        </td>
                        <td className="p-2 align-middle font-mono text-sm">{caseItem.gci || '-'}</td>
                        <td className="p-2 align-middle font-mono text-sm text-muted-foreground">{caseItem.mpId || <span className="text-gray-400">N/A</span>}</td>
                        <td className="p-2 align-middle font-mono text-sm text-muted-foreground">{caseItem.partyId || <span className="text-gray-400">N/A</span>}</td>
                        <td className="p-2 align-middle font-mono text-sm text-muted-foreground">
                          {caseItem.coperId || <span className="text-gray-400">N/A</span>}
                        </td>
                        <td className="p-2 align-middle">
                          <Badge className={getStatusColor(caseItem.status) + ' border-0'} variant="outline">
                            {caseItem.status}
                          </Badge>
                        </td>
                        <td className="p-2 align-middle text-sm">{caseItem.createdDate}</td>
                        <td className="p-2 align-middle text-sm">
                          <div className={`flex items-center gap-1 ${pastDue ? 'text-red-600 font-medium' : ''}`}>
                            {pastDue && <Clock className="h-3 w-3" />}
                            {caseItem.dueDate}
                          </div>
                        </td>
                        <td className="p-2 align-middle text-sm">
                          {caseItem.assignedTo === 'Unassigned' ? (
                            <Badge variant="outline" className="border-amber-300 text-amber-700 bg-amber-50">
                              Unassigned
                            </Badge>
                          ) : (
                            caseItem.assignedTo
                          )}
                        </td>
                        <td className="p-2 align-middle">
                          <Badge variant="outline" className="border-blue-200 text-blue-800 bg-blue-50">
                            <Building2 className="h-3 w-3 mr-1" />
                            {formatLOB(caseItem.lineOfBusiness)}
                          </Badge>
                        </td>
                        <td className="p-2 align-middle">
                          <Badge 
                            variant={getRiskBadgeVariant(caseItem.riskLevel)}
                            className={
                              caseItem.riskLevel === 'Critical' ? 'bg-red-600 text-white' : 
                              caseItem.riskLevel === 'High' ? 'bg-red-100 text-red-800 border-red-200' :
                              caseItem.riskLevel === 'Medium' ? 'bg-amber-100 text-amber-800 border-amber-200' :
                              'bg-green-100 text-green-800 border-green-200'
                            }
                          >
                            {caseItem.riskLevel}
                          </Badge>
                        </td>
                        <td className="p-2 align-middle text-center">
                          {caseItem.isBACEmployee || caseItem.clientData?.isEmployee ? (
                            <Badge variant="default" className="bg-purple-600 text-white">Y</Badge>
                          ) : (
                            <span className="text-gray-400 text-sm">N</span>
                          )}
                        </td>
                        <td className="p-2 align-middle text-center">
                          {caseItem.isBACAffiliate ? (
                            <Badge variant="default" className="bg-indigo-600 text-white">Y</Badge>
                          ) : (
                            <span className="text-gray-400 text-sm">N</span>
                          )}
                        </td>
                        <td className="p-2 align-middle text-center">
                          {caseItem.isRegO ? (
                            <Badge variant="default" className="bg-orange-600 text-white">Y</Badge>
                          ) : (
                            <span className="text-gray-400 text-sm">N</span>
                          )}
                        </td>
                        <td className="p-2 align-middle">
                          <Badge 
                            variant={caseItem.is312Case ? 'default' : 'outline'}
                            className={caseItem.is312Case ? 'bg-primary text-white' : 'border-gray-300 text-gray-600'}
                          >
                            {caseItem.is312Case ? 'Yes' : 'No'}
                          </Badge>
                        </td>
                        <td className="p-2 align-middle">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleSelfAssign(caseItem.id)}
                            className="hover:bg-primary/10 hover:text-primary"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Pagination Footer */}
            {filteredAndSortedCases.length > 0 && (
              <div className="border-t bg-muted/20 px-4 py-3 flex items-center justify-between">
                {/* Left: Page Size Selector */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Page Size:</span>
                  <Select value={String(pageSize)} onValueChange={handlePageSizeChange}>
                    <SelectTrigger className="w-[100px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1000">1000</SelectItem>
                      <SelectItem value="5000">5000</SelectItem>
                      <SelectItem value="10000">10000</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Middle: Page Navigation */}
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleFirstPage}
                    disabled={currentPage === 1}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronsLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground px-3">
                    Page {currentPage} of {totalPages || 1}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleNextPage}
                    disabled={currentPage >= totalPages}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLastPage}
                    disabled={currentPage >= totalPages}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronsRight className="h-4 w-4" />
                  </Button>
                </div>

                {/* Right: Page Info */}
                <div className="text-sm text-muted-foreground">
                  Showing {startIndex + 1}-{Math.min(endIndex, filteredAndSortedCases.length)} of {filteredAndSortedCases.length} cases
                </div>
              </div>
            )}
          </div>

          {filteredAndSortedCases.length === 0 && (
            <div className="py-12 text-center text-muted-foreground">
              No cases match your filters
            </div>
          )}

          {/* Results summary */}
          {filteredAndSortedCases.length > 0 && (
            <div className="text-sm text-muted-foreground">
              Showing {filteredAndSortedCases.length} case{filteredAndSortedCases.length !== 1 ? 's' : ''}
              {sortField && sortDirection && (
                <span> • Sorted by {sortField} ({sortDirection === 'asc' ? 'ascending' : 'descending'})</span>
              )}
              {selectedCases.size > 0 && (
                <span className="ml-2 text-primary font-medium">• {selectedCases.size} selected</span>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bulk Assignment Dialog */}
      <Dialog open={bulkAssignDialogOpen} onOpenChange={setBulkAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Cases</DialogTitle>
            <DialogDescription>
              Assign {selectedCases.size} selected case{selectedCases.size !== 1 ? 's' : ''} to a team member
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Assign to:</label>
              <Select value={selectedAssignee} onValueChange={setSelectedAssignee}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a team member..." />
                </SelectTrigger>
                <SelectContent>
                  {availableAssignees.map(user => (
                    <SelectItem key={user.id} value={user.name}>
                      {user.name} ({user.role})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="text-sm text-muted-foreground">
              You can assign and reassign cases to any Central Team member or Sales Owner.
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkAssignDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={confirmBulkAssignment} className="bg-primary">
              Assign Cases
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Case Dialog for Managers - Reopen for Remediation */}
      <Dialog open={editCaseDialogOpen} onOpenChange={setEditCaseDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Complete Cases - Quality Remediation</DialogTitle>
            <DialogDescription>
              Reopen {completeCasesSelected.length} complete case{completeCasesSelected.length !== 1 ? 's' : ''} for defect remediation
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="rounded-md border bg-muted/30 p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
                <div className="space-y-2">
                  <p className="text-sm font-medium">Quality Remediation Action</p>
                  <p className="text-sm text-muted-foreground">
                    This action will reopen the selected complete cases and change their status to <span className="font-semibold text-red-600">Defect Remediation</span>. 
                    The cases will need to be re-reviewed and re-dispositioned by an analyst.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Selected Complete Cases:</label>
              <div className="rounded-md border max-h-[200px] overflow-y-auto">
                <table className="w-full caption-bottom text-sm">
                  <thead className="bg-muted/50">
                    <tr className="border-b">
                      <th className="h-10 px-2 text-left align-middle font-semibold">Case Number</th>
                      <th className="h-10 px-2 text-left align-middle font-semibold">Client Name</th>
                      <th className="h-10 px-2 text-left align-middle font-semibold">Status</th>
                      <th className="h-10 px-2 text-left align-middle font-semibold">Completed Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {completeCasesSelected.map((caseItem) => (
                      <tr key={caseItem.id} className="border-b hover:bg-muted/50 transition-colors">
                        <td className="p-2 align-middle font-mono text-sm">{caseItem.id}</td>
                        <td className="p-2 align-middle text-sm">{caseItem.clientName}</td>
                        <td className="p-2 align-middle">
                          <Badge className="bg-green-100 text-green-800 border-0">
                            {caseItem.status}
                          </Badge>
                        </td>
                        <td className="p-2 align-middle text-sm">{caseItem.completionDate || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="text-sm text-muted-foreground bg-blue-50 border border-blue-200 rounded-md p-3">
              <p className="font-medium text-blue-900 mb-1">Manager Permission Required</p>
              <p className="text-blue-800">
                Only Central Team Managers can reopen complete cases for quality remediation. 
                The original completion date will be preserved for audit purposes.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditCaseDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleReopenForRemediation} className="bg-red-600 hover:bg-red-700 text-white">
              Reopen for Remediation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}