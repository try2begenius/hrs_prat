import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  InputAdornment,
  Grid,
  Alert,
  AlertTitle
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchIcon from '@mui/icons-material/Search';
import { dataDictionary, searchFields, type DataDictionaryField } from '@/app/data/dataDictionary';

export function DataDictionaryViewer() {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSections, setExpandedSections] = useState<string[]>([]);

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(event.target.value);
  };

  const handleAccordionChange = (section: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpandedSections(prev => 
      isExpanded 
        ? [...prev, section]
        : prev.filter(s => s !== section)
    );
  };

  const searchResults = searchQuery.trim() ? searchFields(searchQuery) : [];
  const showSearchResults = searchQuery.trim().length > 0;

  const renderFieldRow = (field: DataDictionaryField) => (
    <TableRow key={field.fieldName} hover>
      <TableCell>
        <Typography variant="body2" fontWeight="600">
          {field.displayName}
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'monospace' }}>
          {field.fieldName}
        </Typography>
      </TableCell>
      <TableCell>
        <Chip 
          label={field.dataType} 
          size="small" 
          variant="outlined"
          sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}
        />
      </TableCell>
      <TableCell>
        <Chip 
          label={field.source} 
          size="small" 
          color="primary"
          variant="outlined"
        />
      </TableCell>
      <TableCell align="center">
        <Chip 
          label={field.required ? 'Required' : 'Optional'} 
          size="small" 
          color={field.required ? 'error' : 'default'}
          variant={field.required ? 'filled' : 'outlined'}
        />
      </TableCell>
      <TableCell>
        <Typography variant="body2">
          {field.description}
        </Typography>
        {field.validValues && (
          <Box sx={{ mt: 1 }}>
            <Typography variant="caption" color="text.secondary" fontWeight="600">
              Valid Values:
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
              {field.validValues.map((value, idx) => (
                <Chip 
                  key={idx} 
                  label={value} 
                  size="small" 
                  variant="outlined"
                  sx={{ fontSize: '0.7rem' }}
                />
              ))}
            </Box>
          </Box>
        )}
        {field.businessRules && (
          <Alert severity="info" sx={{ mt: 1, py: 0 }}>
            <Typography variant="caption">
              <strong>Business Rule:</strong> {field.businessRules}
            </Typography>
          </Alert>
        )}
        {field.exampleValue && (
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block', fontStyle: 'italic' }}>
            Example: {field.exampleValue}
          </Typography>
        )}
      </TableCell>
    </TableRow>
  );

  return (
    <Box sx={{ p: 3 }}>
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h4" gutterBottom>
            Data Dictionary
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            Comprehensive field definitions, data sources, and business rules for the 312/CAM Case Management System
          </Typography>

          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search fields by name, description, or source..."
            value={searchQuery}
            onChange={handleSearchChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            sx={{ mt: 2 }}
          />
        </CardContent>
      </Card>

      {showSearchResults ? (
        <Card>
          <CardContent>
            <Alert severity="info" sx={{ mb: 2 }}>
              <AlertTitle>Search Results</AlertTitle>
              Found {searchResults.length} field{searchResults.length !== 1 ? 's' : ''} matching "{searchQuery}"
            </Alert>

            {searchResults.length > 0 ? (
              <TableContainer component={Paper} variant="outlined">
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 'bold', width: '15%' }}>Field Name</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', width: '10%' }}>Data Type</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', width: '12%' }}>Source</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', width: '8%' }} align="center">Required</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', width: '55%' }}>Description & Details</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {searchResults.map(field => renderFieldRow(field))}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : (
              <Alert severity="warning">
                No fields found matching your search criteria.
              </Alert>
            )}
          </CardContent>
        </Card>
      ) : (
        <Grid container spacing={2}>
          {dataDictionary.map((section, idx) => (
            <Grid size={{ xs: 12 }} key={idx}>
              <Accordion 
                expanded={expandedSections.includes(section.section)}
                onChange={handleAccordionChange(section.section)}
              >
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                    <Typography variant="h6">
                      {section.section}
                    </Typography>
                    <Chip 
                      label={`${section.fields.length} fields`} 
                      size="small" 
                      color="primary"
                      variant="outlined"
                    />
                  </Box>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    {section.description}
                  </Typography>

                  <TableContainer component={Paper} variant="outlined">
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 'bold', width: '15%' }}>Field Name</TableCell>
                          <TableCell sx={{ fontWeight: 'bold', width: '10%' }}>Data Type</TableCell>
                          <TableCell sx={{ fontWeight: 'bold', width: '12%' }}>Source</TableCell>
                          <TableCell sx={{ fontWeight: 'bold', width: '8%' }} align="center">Required</TableCell>
                          <TableCell sx={{ fontWeight: 'bold', width: '55%' }}>Description & Details</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {section.fields.map(field => renderFieldRow(field))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </AccordionDetails>
              </Accordion>
            </Grid>
          ))}
        </Grid>
      )}

      <Card sx={{ mt: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Legend
          </Typography>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 6 }}>
              <Typography variant="subtitle2" gutterBottom>
                Data Sources
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Typography variant="body2">• <strong>Cesium:</strong> Client Master Data Repository</Typography>
                <Typography variant="body2">• <strong>WCC:</strong> World Client Connect</Typography>
                <Typography variant="body2">• <strong>CMT:</strong> Client Management Tool</Typography>
                <Typography variant="body2">• <strong>GWIM Hub:</strong> Global Wealth & Investment Management Hub</Typography>
                <Typography variant="body2">• <strong>PRDS:</strong> Product Reference Data Store</Typography>
                <Typography variant="body2">• <strong>ORRCA:</strong> Operational Risk Rating & Classification Application</Typography>
                <Typography variant="body2">• <strong>CP:</strong> Compliance Platform</Typography>
                <Typography variant="body2">• <strong>DDQ:</strong> Due Diligence Questionnaire</Typography>
              </Box>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Typography variant="subtitle2" gutterBottom>
                Field Status
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Chip label="Required" size="small" color="error" />
                  <Typography variant="body2">Field must have a value</Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Chip label="Optional" size="small" variant="outlined" />
                  <Typography variant="body2">Field may be empty or null</Typography>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
}