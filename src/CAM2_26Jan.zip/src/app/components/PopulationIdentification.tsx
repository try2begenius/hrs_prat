import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Chip,
  LinearProgress,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import {
  PlayArrow,
  CheckCircle,
  ErrorOutline,
  CreditCard,
  Storage,
  CalendarToday,
} from '@mui/icons-material';
import { useState } from 'react';
import { ClientCriteriaDetailView } from './ClientCriteriaDetailView';

// Mock data
const populationStats = {
  totalClients: { active: 13, closed: 1, total: 14 },
  pop312: 7,
  popCAM: 9,
  bothPopulations: { total: 5, excluded: 3 },
};

const lobData = [
  {
    lob: 'GB/GM',
    total: 8,
    count312: 4,
    countCAM: 3,
    excluded: 4,
  },
  {
    lob: 'PB',
    total: 3,
    count312: 2,
    countCAM: 1,
    excluded: 0,
  },
  {
    lob: 'ML',
    total: 1,
    count312: 1,
    countCAM: 1,
    excluded: 0,
  },
  {
    lob: 'Consumer',
    total: 1,
    count312: 0,
    countCAM: 1,
    excluded: 0,
  },
  {
    lob: 'CI',
    total: 1,
    count312: 0,
    countCAM: 1,
    excluded: 0,
  },
];

const fluSystems = [
  { name: 'Cesium', count: 8, percentage: 57 },
  { name: 'CMT', count: 3, percentage: 21 },
  { name: 'CP', count: 1, percentage: 7 },
  { name: 'WCC', count: 2, percentage: 14 },
];

// Client Population Decisions data
const clientDecisions = [
  {
    clientName: 'Transcontinental Holdings LLC',
    clientId: 'TH-992341',
    gciNumber: 'GCI-POP-001',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'High',
    status: 'Active',
    population: 'Both',
    daysToRefresh: 138,
    salesOwner: 'Sarah Mitchell',
    refreshDueDate: '2025-03-15',
    has312Flag: true,
  },
  {
    clientName: 'Apex Global Trading Corp',
    clientId: 'AGT-445567',
    gciNumber: 'GCI-POP-002',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'Elevated',
    status: 'Active',
    population: '312',
    daysToRefresh: 165,
    salesOwner: 'Michael Chen',
    refreshDueDate: '2025-04-10',
    has312Flag: true,
  },
  {
    clientName: 'Consolidated Industries Group',
    clientId: 'CIG-778234',
    gciNumber: 'GCI-POP-003',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'Standard',
    status: 'Active',
    population: '312',
    daysToRefresh: 175,
    salesOwner: 'David Park',
    refreshDueDate: '2025-05-20',
    has312Flag: true,
  },
  {
    clientName: 'Premier Financial Services',
    clientId: 'PFS-223344',
    gciNumber: 'GCI-POP-004',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'High',
    status: 'Active',
    population: 'Both',
    daysToRefresh: 261,
    salesOwner: 'Jennifer Wu',
    refreshDueDate: '2025-08-15',
    has312Flag: true,
  },
  {
    clientName: 'Quantum Family Trust',
    clientId: 'QFT-556789',
    gciNumber: 'GCI-POP-005',
    lob: 'PB',
    fluSystem: 'CMT',
    risk: 'High',
    status: 'Active',
    population: 'Both',
    daysToRefresh: 153,
    salesOwner: 'Robert Lee',
    refreshDueDate: '2025-03-30',
    has312Flag: true,
  },
  {
    clientName: 'Sterling Investment Portfolio',
    clientId: 'SIP-889012',
    gciNumber: 'GCI-POP-006',
    lob: 'ML',
    fluSystem: 'CP',
    risk: 'High',
    status: 'Active',
    population: 'Both',
    daysToRefresh: 159,
    salesOwner: 'Amanda Foster',
    refreshDueDate: '2025-04-05',
    has312Flag: true,
  },
  {
    clientName: 'Martinez Family Account',
    clientId: 'MFA-334455',
    gciNumber: 'GCI-POP-007',
    lob: 'Consumer',
    fluSystem: 'WCC',
    risk: 'High',
    status: 'Active',
    population: 'CAM',
    daysToRefresh: 123,
    salesOwner: 'Carlos Martinez',
    refreshDueDate: '2025-02-28',
    has312Flag: false,
  },
  {
    clientName: 'Thompson Retirement Account',
    clientId: 'TRA-667788',
    gciNumber: 'GCI-POP-008',
    lob: 'CI',
    fluSystem: 'WCC',
    risk: 'High',
    status: 'Active',
    population: 'CAM',
    daysToRefresh: 133,
    salesOwner: 'Lisa Thompson',
    refreshDueDate: '2025-03-10',
    has312Flag: false,
  },
  {
    clientName: 'Legacy Holdings Inc',
    clientId: 'LHI-998877',
    gciNumber: 'GCI-POP-009',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'High',
    status: 'Closed',
    population: 'Excluded',
    daysToRefresh: 110,
    salesOwner: 'John Davis',
    refreshDueDate: '2025-02-15',
    has312Flag: true,
  },
  {
    clientName: 'Riverside Capital Partners',
    clientId: 'RCP-112233',
    gciNumber: 'GCI-POP-010',
    lob: 'PB',
    fluSystem: 'CMT',
    risk: 'High',
    status: 'Active',
    population: 'CAM',
    daysToRefresh: 148,
    salesOwner: 'Patricia Wong',
    refreshDueDate: '2025-03-25',
    has312Flag: false,
  },
  {
    clientName: 'Pacific Rim Ventures',
    clientId: 'PRV-445566',
    gciNumber: 'GCI-POP-011',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'High',
    status: 'Active',
    population: 'CAM',
    daysToRefresh: 292,
    salesOwner: 'Kevin Chang',
    refreshDueDate: '2025-08-15',
    has312Flag: false,
  },
  {
    clientName: 'Global Commerce Solutions',
    clientId: 'GCS-778899',
    gciNumber: 'GCI-POP-012',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'Elevated',
    status: 'Active',
    population: 'Excluded',
    daysToRefresh: 384,
    salesOwner: 'Michelle Brown',
    refreshDueDate: '2025-11-15',
    has312Flag: true,
  },
  {
    clientName: 'Johnson Employee Account',
    clientId: 'JEA-221144',
    gciNumber: 'GCI-POP-013',
    lob: 'PB',
    fluSystem: 'CMT',
    risk: 'High',
    status: 'Active',
    population: 'Both',
    daysToRefresh: 115,
    salesOwner: 'James Johnson',
    refreshDueDate: '2025-02-20',
    has312Flag: true,
  },
  {
    clientName: 'Greenfield Investments',
    clientId: 'GFI-553366',
    gciNumber: 'GCI-POP-014',
    lob: 'GB/GM',
    fluSystem: 'Cesium',
    risk: 'Low',
    status: 'Active',
    population: 'Excluded',
    daysToRefresh: 124,
    salesOwner: 'Emily Green',
    refreshDueDate: '2025-03-01',
    has312Flag: false,
  },
];

export function PopulationIdentification() {
  const [tabValue, setTabValue] = useState(0);
  const [selectedClient, setSelectedClient] = useState<typeof clientDecisions[0] | null>(null);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
    setSelectedClient(null); // Clear selection when switching tabs
  };

  const handleClientClick = (client: typeof clientDecisions[0]) => {
    setSelectedClient(client);
  };

  const handleClearSelection = () => {
    setSelectedClient(null);
  };

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <Box sx={{ overflowY: 'auto', flex: 1, pr: 1 }}>
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
          <Box>
            <Typography variant="h5" fontWeight={600} color="primary" gutterBottom>
              Population Identification Engine
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Real-time evaluation of CAM 312 and CAM population criteria
            </Typography>
          </Box>
          <Button variant="contained" startIcon={<PlayArrow />}>
            Run Identification
          </Button>
        </Box>

        {/* Summary Statistics Cards */}
        <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap' }}>
          {/* Total Clients */}
          <Card sx={{ flex: '1 1 calc(25% - 12px)', minWidth: '220px' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="body2" color="text.secondary" fontWeight={600}>
                  Total Clients
                </Typography>
                <CreditCard sx={{ color: 'text.secondary', fontSize: 20 }} />
              </Box>
              <Typography variant="h3" fontWeight={700} sx={{ mb: 0.5 }}>
                {populationStats.totalClients.total}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {populationStats.totalClients.active} active, {populationStats.totalClients.closed} closed
              </Typography>
            </CardContent>
          </Card>

          {/* 312 Population */}
          <Card sx={{ flex: '1 1 calc(25% - 12px)', minWidth: '220px' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="body2" color="text.secondary" fontWeight={600}>
                  312 Population
                </Typography>
                <ErrorOutline sx={{ color: 'info.main', fontSize: 20 }} />
              </Box>
              <Typography variant="h3" fontWeight={700} color="info.main">
                {populationStats.pop312}
              </Typography>
              <Box sx={{ mt: 1 }}>
                <LinearProgress
                  variant="determinate"
                  value={(populationStats.pop312 / populationStats.totalClients.total) * 100}
                  sx={{ height: 4, borderRadius: 2 }}
                />
              </Box>
            </CardContent>
          </Card>

          {/* CAM Population */}
          <Card sx={{ flex: '1 1 calc(25% - 12px)', minWidth: '220px' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="body2" color="text.secondary" fontWeight={600}>
                  CAM Population
                </Typography>
                <ErrorOutline sx={{ color: 'error.main', fontSize: 20 }} />
              </Box>
              <Typography variant="h3" fontWeight={700} color="error.main">
                {populationStats.popCAM}
              </Typography>
              <Box sx={{ mt: 1 }}>
                <LinearProgress
                  variant="determinate"
                  value={(populationStats.popCAM / populationStats.totalClients.total) * 100}
                  sx={{ height: 4, borderRadius: 2 }}
                  color="error"
                />
              </Box>
            </CardContent>
          </Card>

          {/* Both Populations */}
          <Card sx={{ flex: '1 1 calc(25% - 12px)', minWidth: '220px' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="body2" color="text.secondary" fontWeight={600}>
                  Both Populations
                </Typography>
                <CheckCircle sx={{ color: 'success.main', fontSize: 20 }} />
              </Box>
              <Typography variant="h3" fontWeight={700} color="success.main" sx={{ mb: 0.5 }}>
                {populationStats.bothPopulations.total}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {populationStats.bothPopulations.excluded} excluded
              </Typography>
            </CardContent>
          </Card>
        </Box>

        {/* Main Content Row */}
        <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap' }}>
          {/* Population by Line of Business */}
          <Card sx={{ flex: '1 1 500px', minWidth: '300px' }}>
            <CardContent>
              <Typography variant="h6" fontWeight={600} gutterBottom>
                Population by Line of Business
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Client distribution across LOBs
              </Typography>

              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {lobData.map((item) => (
                  <Box key={item.lob}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                      <Typography variant="body2" fontWeight={600} color="primary">
                        {item.lob}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {item.total} clients
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Box
                        sx={{
                          flex: 1,
                          bgcolor: '#e3f2fd',
                          borderRadius: 1,
                          p: 1.5,
                          textAlign: 'center',
                        }}
                      >
                        <Typography variant="h6" color="primary" fontWeight={700}>
                          {item.count312}
                        </Typography>
                        <Typography variant="caption" color="primary">
                          312
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          flex: 1,
                          bgcolor: '#fce4ec',
                          borderRadius: 1,
                          p: 1.5,
                          textAlign: 'center',
                        }}
                      >
                        <Typography variant="h6" color="error.main" fontWeight={700}>
                          {item.countCAM}
                        </Typography>
                        <Typography variant="caption" color="error.main">
                          CAM
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          flex: 1,
                          bgcolor: '#eceff1',
                          borderRadius: 1,
                          p: 1.5,
                          textAlign: 'center',
                        }}
                      >
                        <Typography variant="h6" color="text.secondary" fontWeight={700}>
                          {item.excluded}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Excluded
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>

          {/* FLU System Distribution */}
          <Card sx={{ flex: '1 1 300px', minWidth: '300px' }}>
            <CardContent>
              <Typography variant="h6" fontWeight={600} gutterBottom>
                FLU System Distribution
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Clients by source FLU system
              </Typography>

              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                {fluSystems.map((item) => (
                  <Box
                    key={item.name}
                    sx={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      p: 1.5,
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 1,
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Storage sx={{ color: 'primary.main', fontSize: 20 }} />
                      <Typography variant="body2" fontWeight={600}>
                        {item.name}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      <Typography variant="body2" fontWeight={700}>
                        {item.count}
                      </Typography>
                      <Chip
                        label={`${item.percentage}%`}
                        size="small"
                        sx={{
                          minWidth: 60,
                          bgcolor: 'background.default',
                          fontWeight: 600,
                        }}
                      />
                    </Box>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Box>

        {/* Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: '#f5f5f5' }}>
          <Tabs value={tabValue} onChange={handleTabChange} aria-label="population tabs">
            <Tab label="Population Evaluation Results" />
            <Tab label="Criteria Evaluation Details" />
          </Tabs>
        </Box>

        {/* Tab Content */}
        <Card sx={{ mt: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0 }}>
          <CardContent>
            {tabValue === 0 && (
              <Box>
                <Typography variant="h6" fontWeight={600} gutterBottom>
                  Client Population Decisions
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  Click a row to see detailed criteria evaluation in the "Criteria Evaluation Details" tab
                </Typography>

                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell><strong>Client Name</strong></TableCell>
                        <TableCell><strong>LOB</strong></TableCell>
                        <TableCell><strong>FLU System</strong></TableCell>
                        <TableCell><strong>Risk</strong></TableCell>
                        <TableCell><strong>Status</strong></TableCell>
                        <TableCell><strong>Population(s)</strong></TableCell>
                        <TableCell><strong>Days to Refresh</strong></TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {clientDecisions.map((row, index) => (
                        <TableRow 
                          key={index} 
                          hover 
                          sx={{ 
                            cursor: 'pointer',
                            bgcolor: selectedClient?.clientId === row.clientId ? 'primary.lighter' : 'inherit'
                          }} 
                          onClick={() => {
                            handleClientClick(row);
                            setTabValue(1); // Switch to details tab
                          }}
                        >
                          <TableCell>{row.clientName}</TableCell>
                          <TableCell>
                            <Chip label={row.lob} size="small" variant="outlined" color="primary" />
                          </TableCell>
                          <TableCell>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <Storage fontSize="small" sx={{ color: 'text.secondary' }} />
                              <Typography variant="body2">{row.fluSystem}</Typography>
                            </Box>
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={row.risk}
                              size="small"
                              color={
                                row.risk === 'High'
                                  ? 'error'
                                  : row.risk === 'Elevated'
                                  ? 'warning'
                                  : row.risk === 'Standard'
                                  ? 'info'
                                  : 'default'
                              }
                            />
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={row.status}
                              size="small"
                              color={row.status === 'Active' ? 'primary' : 'default'}
                            />
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={row.population}
                              size="small"
                              icon={
                                row.population === 'Both' ? (
                                  <CheckCircle fontSize="small" />
                                ) : row.population === 'Excluded' ? (
                                  <ErrorOutline fontSize="small" />
                                ) : undefined
                              }
                              color={
                                row.population === 'Both'
                                  ? 'success'
                                  : row.population === '312'
                                  ? 'info'
                                  : row.population === 'CAM'
                                  ? 'error'
                                  : 'default'
                              }
                            />
                          </TableCell>
                          <TableCell>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                              <CalendarToday fontSize="small" sx={{ color: 'text.secondary' }} />
                              <Typography variant="body2">{row.daysToRefresh} days</Typography>
                            </Box>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            )}

            {tabValue === 1 && (
              <Box>
                {selectedClient ? (
                  <ClientCriteriaDetailView client={selectedClient} onClear={handleClearSelection} />
                ) : (
                  <Box>
                    <Typography variant="h6" fontWeight={600} gutterBottom>
                      Criteria Evaluation Details
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                      Select a client from the "Population Evaluation Results" tab to see detailed criteria evaluation
                    </Typography>
                  </Box>
                )}
              </Box>
            )}
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
}