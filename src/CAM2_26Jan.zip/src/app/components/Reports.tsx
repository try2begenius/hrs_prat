import { Box, Card, CardContent, Typography, Button, Chip, Grid, TextField, MenuItem } from '@mui/material';
import { FileDownload, Add, CalendarToday, TrendingUp, BarChart, PieChart as PieChartIcon } from '@mui/icons-material';
import { UserAccess } from '../data/rolesEntitlementsMockData';

interface ReportsProps {
  currentUser: UserAccess;
}

export function Reports({ currentUser }: ReportsProps) {
  const reportTemplates = [
    {
      id: 1,
      name: 'Case Status Summary',
      description: 'Overview of all cases by status and LOB',
      icon: <BarChart />,
      frequency: 'Daily',
    },
    {
      id: 2,
      name: 'Risk Distribution Report',
      description: 'Analysis of cases by risk level',
      icon: <PieChartIcon />,
      frequency: 'Weekly',
    },
    {
      id: 3,
      name: 'Performance Metrics',
      description: 'Case resolution times and SLA compliance',
      icon: <TrendingUp />,
      frequency: 'Monthly',
    },
  ];

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" gutterBottom>
            Reports & Analytics
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Generate and schedule reports for compliance and analysis
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<Add />}>
          Create Report
        </Button>
      </Box>

      {/* Filters */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="subtitle2" gutterBottom>
            Report Filters
          </Typography>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField
                fullWidth
                select
                label="Time Period"
                defaultValue="30days"
                size="small"
              >
                <MenuItem value="7days">Last 7 Days</MenuItem>
                <MenuItem value="30days">Last 30 Days</MenuItem>
                <MenuItem value="90days">Last 90 Days</MenuItem>
                <MenuItem value="year">This Year</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField
                fullWidth
                select
                label="LOB"
                defaultValue="all"
                size="small"
              >
                <MenuItem value="all">All LOBs</MenuItem>
                {currentUser.entitlements.lobs.map(lob => (
                  <MenuItem key={lob} value={lob}>{lob}</MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <TextField
                fullWidth
                select
                label="Case Type"
                defaultValue="all"
                size="small"
              >
                <MenuItem value="all">All Types</MenuItem>
                {currentUser.entitlements.has312Access && <MenuItem value="312">312 Review</MenuItem>}
                {currentUser.entitlements.hasCAMAccess && <MenuItem value="cam">CAM Review</MenuItem>}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, md: 3 }}>
              <Button variant="contained" fullWidth>
                Apply Filters
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Report Templates */}
      <Typography variant="h6" gutterBottom>
        Report Templates
      </Typography>
      <Grid container spacing={3}>
        {reportTemplates.map((report) => (
          <Grid size={{ xs: 12, md: 4 }} key={report.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2, mb: 2 }}>
                  <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: 'primary.lighter' }}>
                    {report.icon}
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      {report.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {report.description}
                    </Typography>
                  </Box>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
                  <Chip label={report.frequency} size="small" variant="outlined" />
                  <Button size="small" startIcon={<FileDownload />}>
                    Generate
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Recent Reports */}
      <Card sx={{ mt: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Recent Reports
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            {[1, 2, 3].map((i) => (
              <Box
                key={i}
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  p: 2,
                  border: 1,
                  borderColor: 'divider',
                  borderRadius: 1,
                }}
              >
                <Box>
                  <Typography variant="body2" fontWeight={600}>
                    Case Status Summary - October 2025
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Generated on 10/26/2025 at 10:30 AM
                  </Typography>
                </Box>
                <Button size="small" startIcon={<FileDownload />}>
                  Download
                </Button>
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}