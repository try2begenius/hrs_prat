import {
  Box,
  Card,
  CardContent,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Alert,
  LinearProgress,
  Divider,
  Typography,
  Paper,
} from '@mui/material';
import { 
  Storage, 
  CheckCircle, 
  Warning, 
  Refresh, 
  Settings, 
  TrendingUp 
} from '@mui/icons-material';
import { SystemIntegration, IntegrationStatus, CAMIntegrationCategory } from '../types';
import { useState } from 'react';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

const systemIntegrations: SystemIntegration[] = [
  {
    id: 'INT-001',
    name: 'Cesium',
    type: 'Client Data',
    description: 'Global Banking and Global Markets client data',
    status: 'Connected',
    lastSync: '2025-10-26T10:30:00',
    recordCount: 45230,
    errorCount: 0,
    dataAttributes: ['Legal Name', 'Client ID', 'GCI Number', 'Sales Owner', 'Account Open Date'],
    linesOfBusiness: ['GB/GM']
  },
  {
    id: 'INT-002',
    name: 'AWAREWCC',
    type: 'Client Data',
    description: 'Consumer banking client data warehouse',
    status: 'Connected',
    lastSync: '2025-10-26T10:25:00',
    recordCount: 128456,
    errorCount: 3,
    dataAttributes: ['Client ID', 'Legal Name', 'Account Details', 'Product Holdings'],
    linesOfBusiness: ['Consumer']
  },
  {
    id: 'INT-003',
    name: 'CMT',
    type: 'Client Data',
    description: 'Private Banking client management tool',
    status: 'Syncing',
    lastSync: '2025-10-26T10:15:00',
    recordCount: 34780,
    errorCount: 0,
    dataAttributes: ['Client Profile', 'Relationship Manager', 'Net Worth'],
    linesOfBusiness: ['PB']
  },
  {
    id: 'INT-009',
    name: 'FLU Data Sources',
    type: 'Monitoring Data',
    description: 'Foreign Location Usage monitoring data',
    status: 'Error',
    lastSync: '2025-10-26T08:45:00',
    recordCount: 23456,
    errorCount: 45,
    dataAttributes: ['FLU Cases', 'Geographic Risk', 'Transaction Location'],
    linesOfBusiness: []
  },
];

export function SystemIntegrations() {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const getStatusChip = (status: IntegrationStatus) => {
    const statusConfig = {
      Connected: { color: 'success' as const, icon: <CheckCircle fontSize="small" /> },
      Syncing: { color: 'info' as const, icon: <Refresh fontSize="small" /> },
      Error: { color: 'error' as const, icon: <Warning fontSize="small" /> },
      Disconnected: { color: 'default' as const, icon: null }
    };

    const config = statusConfig[status];
    return (
      <Chip
        icon={config.icon || undefined}
        label={status}
        color={config.color}
        size="small"
      />
    );
  };

  const connectedCount = systemIntegrations.filter(i => i.status === 'Connected').length;
  const errorCount = systemIntegrations.filter(i => i.status === 'Error').length;

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          System Integrations
        </Typography>
        <Typography variant="body2" color="text.secondary">
          External system connections and data synchronization status
        </Typography>
      </Box>

      {/* Summary Cards */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(4, 1fr)' }, gap: 3, mb: 3 }}>
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Total Systems
                </Typography>
                <Typography variant="h3" sx={{ my: 1 }}>
                  {systemIntegrations.length}
                </Typography>
              </Box>
              <Storage color="action" />
            </Box>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Connected
                </Typography>
                <Typography variant="h3" color="success.main" sx={{ my: 1 }}>
                  {connectedCount}
                </Typography>
              </Box>
              <CheckCircle color="success" />
            </Box>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Errors
                </Typography>
                <Typography variant="h3" color="error.main" sx={{ my: 1 }}>
                  {errorCount}
                </Typography>
              </Box>
              <Warning color="error" />
            </Box>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Sync Health
                </Typography>
                <Typography variant="h3" color="success.main" sx={{ my: 1 }}>
                  95%
                </Typography>
              </Box>
              <TrendingUp color="success" />
            </Box>
          </CardContent>
        </Card>
      </Box>

      {errorCount > 0 && (
        <Alert severity="error" sx={{ mb: 3 }}>
          <Typography variant="body2" fontWeight={600}>
            {errorCount} System{errorCount > 1 ? 's' : ''} Requiring Attention
          </Typography>
          <Typography variant="body2">
            FLU Data Sources is experiencing connectivity issues. IT has been notified.
          </Typography>
        </Alert>
      )}

      <Card>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={tabValue} onChange={handleTabChange}>
            <Tab label="All Integrations" />
            <Tab label="Client Data" />
            <Tab label="Monitoring Data" />
            <Tab label="Risk Data" />
          </Tabs>
        </Box>

        <TabPanel value={tabValue} index={0}>
          <CardContent>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>System Name</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Last Sync</TableCell>
                    <TableCell align="right">Records</TableCell>
                    <TableCell align="right">Errors</TableCell>
                    <TableCell align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {systemIntegrations.map((integration) => (
                    <TableRow key={integration.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600}>
                          {integration.name}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {integration.description}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip label={integration.type} variant="outlined" size="small" />
                      </TableCell>
                      <TableCell>{getStatusChip(integration.status)}</TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {new Date(integration.lastSync).toLocaleString()}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" fontWeight={500}>
                          {integration.recordCount.toLocaleString()}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography
                          variant="body2"
                          color={integration.errorCount > 0 ? 'error' : 'text.secondary'}
                          fontWeight={integration.errorCount > 0 ? 600 : 400}
                        >
                          {integration.errorCount}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Button variant="outlined" size="small" startIcon={<Refresh />}>
                          Sync
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <CardContent>
            <Typography variant="body2" color="text.secondary">
              Showing Client Data integrations only...
            </Typography>
            <TableContainer sx={{ mt: 2 }}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>System Name</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>LOBs</TableCell>
                    <TableCell align="right">Records</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {systemIntegrations.filter(i => i.type === 'Client Data').map((integration) => (
                    <TableRow key={integration.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600}>
                          {integration.name}
                        </Typography>
                      </TableCell>
                      <TableCell>{getStatusChip(integration.status)}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                          {integration.linesOfBusiness?.map(lob => (
                            <Chip key={lob} label={lob} size="small" variant="outlined" />
                          ))}
                        </Box>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" fontWeight={500}>
                          {integration.recordCount.toLocaleString()}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </TabPanel>

        <TabPanel value={tabValue} index={2}>
          <CardContent>
            <Typography variant="body2">Monitoring Data integrations...</Typography>
          </CardContent>
        </TabPanel>

        <TabPanel value={tabValue} index={3}>
          <CardContent>
            <Typography variant="body2">Risk Data integrations...</Typography>
          </CardContent>
        </TabPanel>
      </Card>
    </Box>
  );
}
