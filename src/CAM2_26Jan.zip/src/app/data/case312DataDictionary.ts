/**
 * 312 Case - Data Dictionary
 * 
 * Comprehensive documentation of all 312 Case data fields and formats
 */

export interface Case312Field {
  fieldName: string;
  format: string;
  description?: string;
  lobSpecific?: string;
}

export const case312Fields: Case312Field[] = [
  {
    fieldName: '312 Case',
    format: 'Banner/Label',
    description: 'Section header for 312 Case information',
  },
  {
    fieldName: '312 Due Date',
    format: 'MM/DD/YYYY',
    description: 'Date when the 312 case review is due',
  },
  {
    fieldName: '312 Model Result',
    format: 'Boolean',
    description: 'Indicates whether the model flagged this case',
  },
  {
    fieldName: '312 Model Result Description',
    format: 'Boolean',
    description: 'Description of the model result',
  },
  {
    fieldName: 'Client Expected Activity - Vol (312 Clients)',
    format: 'Range',
    description: 'Expected volume range for client activity (e.g., 100-499)',
  },
  {
    fieldName: 'ML/PB Electronic',
    format: 'numeric',
    description: 'Electronic transaction volume for ML/PB clients',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'ML/PB Cash/Checks',
    format: 'numeric',
    description: 'Cash and check transaction volume for ML/PB clients',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'GB/GM - DDQ Fields',
    format: 'numeric',
    description: 'DDQ-related fields for GB/GM clients',
    lobSpecific: 'GB/GM',
  },
  {
    fieldName: 'Client Expected Activity - Value (312 Clients)',
    format: 'Range',
    description: 'Expected value range for client activity (e.g., 10,000-50,000)',
  },
  {
    fieldName: 'ML/PB Electronic',
    format: 'numeric',
    description: 'Electronic transaction value for ML/PB clients',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'ML/PB Cash/Checks',
    format: 'numeric',
    description: 'Cash and check transaction value for ML/PB clients',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'GB/GM - DDQ Fields',
    format: 'numeric',
    description: 'DDQ-related value fields for GB/GM clients',
    lobSpecific: 'GB/GM',
  },
  {
    fieldName: 'Purpose of Relationship (GB/GM only)',
    format: 'Alphanumeric',
    description: 'Describes the purpose of the business relationship',
    lobSpecific: 'GB/GM',
  },
  {
    fieldName: 'Purpose of Account',
    format: 'Alphanumeric',
    description: 'Describes the purpose of the account',
  },
  {
    fieldName: 'Account Number',
    format: 'numeric',
    description: 'Client account number (masked by default)',
  },
  {
    fieldName: 'Account Name',
    format: 'Alphanumeric',
    description: 'Name associated with the account',
  },
  {
    fieldName: 'Source of Funds',
    format: 'Alphanumeric',
    description: 'Identifies the source of funds for the account',
  },
  {
    fieldName: 'Source of Funds (ML/PB only)',
    format: 'Alphanumeric',
    description: 'ML/PB specific source of funds information',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'Case Disposition',
    format: 'Banner Label',
    description: 'Overall disposition status for the case',
  },
  {
    fieldName: 'Expected Value and Volume of Money Movement, Including Cash',
    format: 'Banner Label',
    description: 'Question 1 section header',
  },
  {
    fieldName: 'Based on the model output where activity (volume and/or value) exceeded client expected activity, please detail why the activity was above client expectations in the commentary box and select from the following dispositions:',
    format: 'Banner Label',
    description: 'Question 1 instructions',
  },
  {
    fieldName: 'Response',
    format: 'Array',
    description: 'Question 1 response including disposition and commentary',
  },
  {
    fieldName: 'Purpose of Relationship/Account',
    format: 'Banner Label',
    description: 'Question 3 section header',
  },
  {
    fieldName: 'Please detail if the activity that was deemed not aligned with Purpose of account or Purpose of relationship was/was not aligned with expectations or not.',
    format: 'Banner Label',
    description: 'Question 3 instructions',
  },
  {
    fieldName: 'Response',
    format: 'Array',
    description: 'Question 3 response options (all aligned, need TRMS, or activity differed)',
  },
  {
    fieldName: 'Source of Funds - ML and PB only',
    format: 'Banner Label',
    description: 'Question 4 section header (ML/PB only)',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'Please detail why the activity was not aligned with the client\'s source of funds and select from the following dispositions:',
    format: 'Banner Label',
    description: 'Question 4 instructions',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'Response',
    format: 'Array',
    description: 'Question 4 response including disposition and commentary',
    lobSpecific: 'ML/PB',
  },
  {
    fieldName: 'Case Action',
    format: 'Banner Label',
    description: 'Final case action section header',
  },
  {
    fieldName: 'TRMS Number',
    format: 'Alphanumeric',
    description: 'Transaction Monitoring System reference number when TRMS is filed',
  },
  {
    fieldName: 'Comments (used when case is sent to sales)',
    format: 'Freeform',
    description: 'Optional comments when routing case to sales owner',
  },
];
