export interface ClientForEvaluation {
  id: string;
  clientId: string;
  legalName: string;
  lob: 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI' | 'Small Business';
  riskRating: 'High' | 'Elevated' | 'Standard' | 'Low';
  has312Flag: boolean;
  has312ModelAlert: boolean;
  isManuallyUploaded?: boolean; // Exception: manually added to population
  cam312Decision?: 'Full Review' | 'Auto-Close' | 'Not Applicable';
  cam312Status?: 'Complete' | 'In Progress' | 'Unassigned';
  cam312AutoCompleteFlag?: 'Y' | 'N';
  cam312ModelOutput?: string;
  camDecision?: 'Full Review' | 'Auto-Close' | 'Pending 312' | 'Not Applicable';
  camStatus?: 'Complete' | 'In Progress' | 'Unassigned';
  camAutoCompleteFlag?: 'Y' | 'N';
  cam312CaseId?: string;
  camCaseId?: string;
  createdDate?: string;
  // Population Identification Fields
  partyId: string;
  daysToRefresh: number;
  refreshDueDate: string;
  refreshAnniversaryMonth?: string; // For Small Business
  dgaDueDate?: string; // For GB/GM
  globalDGADueDate?: string; // For GB/GM Global DGA
  familyAnniversaryDate?: string;
  populationTrigger?: 'Refresh 180 Days' | 'Refresh 120 Days' | 'Refresh 95 Days' | 'DGA Due Date' | 'Manual Upload';
  // CAM trigger fields - GFC cases
  gfcSearchCases: GFCCase[];
  priorCAMCaseLast12Months?: PriorCAMCase;
  had312CaseNotAutoClosed: boolean;
  completedCasesLast12Months: number;
  hasSARLast12Months: boolean;
  hadCAMReviewLast12Months: boolean;
}

export interface GFCCase {
  caseId: string;
  caseType: string;
  openedDate: string;
  closedDate?: string;
  status: 'Open' | 'Closed';
  isInScope: boolean;
}

export interface PriorCAMCase {
  caseId: string;
  reviewDate: string;
  reviewedGFCCases: string[]; // Array of GFC case IDs that were reviewed
}

export const mockClientsForEvaluation: ClientForEvaluation[] = [
  // Scenario 1: GB/GM - Global DGA Due Date → Full Review
  {
    id: '1',
    clientId: 'GB-10234',
    legalName: 'Horizon Capital Partners Ltd',
    lob: 'GB/GM',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-001',
    camCaseId: 'CAM-2026-001',
    createdDate: '2026-01-15',
    partyId: 'P12345',
    populationTrigger: 'DGA Due Date',
    globalDGADueDate: '2026-02-15',
    gfcSearchCases: [
      { caseId: 'GFC-2025-101', caseType: 'Transaction Monitoring', openedDate: '2025-11-10', closedDate: '2025-12-15', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2026-001', caseType: 'Sanctions Screening', openedDate: '2026-01-05', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 30,
    refreshDueDate: '2026-02-15',
    dgaDueDate: '2026-02-15',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 2: PB - High Risk, 180 days → Auto-Close (no model alert)
  {
    id: '2',
    clientId: 'PB-20451',
    legalName: 'Westfield Family Trust',
    lob: 'PB',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: false,
    cam312Decision: 'Auto-Close',
    cam312Status: 'Complete',
    cam312AutoCompleteFlag: 'Y',
    cam312ModelOutput: '312 Activity in line with expected activity – No review required',
    camDecision: 'Auto-Close',
    camStatus: 'Complete',
    camAutoCompleteFlag: 'Y',
    cam312CaseId: 'CAM312-2026-002',
    camCaseId: 'CAM-2026-002',
    createdDate: '2026-01-16',
    partyId: 'P67890',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2026-002', caseType: 'Name Screening', openedDate: '2026-01-11', closedDate: '2026-01-15', status: 'Closed', isInScope: true }
    ],
    daysToRefresh: 165,
    refreshDueDate: '2026-07-01',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 3: Consumer - 120 days → Full Review (new cases)
  {
    id: '3',
    clientId: 'CN-10567',
    legalName: 'Sterling Consumer Banking',
    lob: 'Consumer',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-003',
    camCaseId: 'CAM-2026-003',
    createdDate: '2026-01-17',
    partyId: 'P11223',
    populationTrigger: 'Refresh 120 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2025-050', caseType: 'Transaction Monitoring', openedDate: '2025-09-01', closedDate: '2025-10-01', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2025-075', caseType: 'Sanctions Screening', openedDate: '2025-11-15', closedDate: '2025-12-20', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2026-003', caseType: 'Transaction Monitoring', openedDate: '2026-01-10', status: 'Open', isInScope: true }
    ],
    priorCAMCaseLast12Months: {
      caseId: 'CAM-2025-055',
      reviewDate: '2025-10-15',
      reviewedGFCCases: ['GFC-2025-050']
    },
    daysToRefresh: 100,
    refreshDueDate: '2026-04-27',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 3,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: true
  },
  // Scenario 4: ML - High Risk, 180 days, NO new cases → Auto-Close
  {
    id: '4',
    clientId: 'ML-30234',
    legalName: 'Global Trade Solutions Inc',
    lob: 'ML',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Auto-Close',
    camStatus: 'Complete',
    camAutoCompleteFlag: 'Y',
    cam312CaseId: 'CAM312-2026-004',
    camCaseId: 'CAM-2026-004',
    createdDate: '2026-01-18',
    partyId: 'P45678',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2025-080', caseType: 'Transaction Monitoring', openedDate: '2025-10-01', closedDate: '2025-11-01', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2025-090', caseType: 'Sanctions Screening', openedDate: '2025-11-05', closedDate: '2025-12-05', status: 'Closed', isInScope: true }
    ],
    priorCAMCaseLast12Months: {
      caseId: 'CAM-2025-080',
      reviewDate: '2025-12-20',
      reviewedGFCCases: ['GFC-2025-080', 'GFC-2025-090']
    },
    daysToRefresh: 150,
    refreshDueDate: '2026-06-18',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: true
  },
  // Scenario 5: CI - High Risk, 180 days → Auto-Close (no GFC cases)
  {
    id: '5',
    clientId: 'CI-10789',
    legalName: 'Oakmont Commercial Industries',
    lob: 'CI',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: false,
    cam312Decision: 'Auto-Close',
    cam312Status: 'Complete',
    cam312AutoCompleteFlag: 'Y',
    cam312ModelOutput: '312 Activity in line with expected activity – No review required',
    camDecision: 'Auto-Close',
    camStatus: 'Complete',
    camAutoCompleteFlag: 'Y',
    cam312CaseId: 'CAM312-2026-005',
    camCaseId: 'CAM-2026-005',
    createdDate: '2026-01-19',
    partyId: 'P90123',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [],
    daysToRefresh: 170,
    refreshDueDate: '2026-07-08',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 0,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 6: Small Business - 95 days before refresh anniversary → Auto-Close
  {
    id: '6',
    clientId: 'SB-20678',
    legalName: 'Anderson Private Enterprises',
    lob: 'Small Business',
    riskRating: 'Standard',
    has312Flag: false,
    has312ModelAlert: false,
    cam312Decision: 'Not Applicable',
    camDecision: 'Auto-Close',
    camStatus: 'Complete',
    camAutoCompleteFlag: 'Y',
    camCaseId: 'CAM-2026-006',
    createdDate: '2026-01-20',
    partyId: 'P34567',
    populationTrigger: 'Refresh 95 Days',
    refreshAnniversaryMonth: 'April',
    gfcSearchCases: [
      { caseId: 'GFC-2026-006', caseType: 'Name Screening', openedDate: '2026-01-15', closedDate: '2026-01-19', status: 'Closed', isInScope: true }
    ],
    daysToRefresh: 80,
    refreshDueDate: '2026-04-10',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 7: Manually Uploaded Exception → Full Review
  {
    id: '7',
    clientId: 'GB-10890',
    legalName: 'Pacific Rim Enterprises',
    lob: 'GB/GM',
    riskRating: 'High',
    has312Flag: false,
    has312ModelAlert: true,
    isManuallyUploaded: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-007',
    camCaseId: 'CAM-2026-007',
    createdDate: '2026-01-20',
    partyId: 'P56789',
    populationTrigger: 'Manual Upload',
    gfcSearchCases: [
      { caseId: 'GFC-2026-007', caseType: 'Transaction Monitoring', openedDate: '2026-01-12', status: 'Open', isInScope: true },
      { caseId: 'GFC-2026-007B', caseType: 'Sanctions Screening', openedDate: '2026-01-14', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 200,
    refreshDueDate: '2026-08-08',
    globalDGADueDate: '2026-09-20',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 8: ML - High Risk, 180 days → Full Review (>=2 GFC cases)
  {
    id: '8',
    clientId: 'ML-30456',
    legalName: 'Silverstone Capital Management',
    lob: 'ML',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-008',
    camCaseId: 'CAM-2026-008',
    createdDate: '2026-01-21',
    partyId: 'P78901',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2025-095', caseType: 'Transaction Monitoring', openedDate: '2025-12-01', closedDate: '2025-12-30', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2026-008', caseType: 'Sanctions Screening', openedDate: '2026-01-16', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 160,
    refreshDueDate: '2026-07-01',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 9: GB/GM - Global DGA Due Date → Full Review
  {
    id: '9',
    clientId: 'GB-11001',
    legalName: 'Meridian Strategic Advisors',
    lob: 'GB/GM',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-009',
    camCaseId: 'CAM-2026-009',
    createdDate: '2026-01-22',
    partyId: 'P23456',
    populationTrigger: 'DGA Due Date',
    globalDGADueDate: '2026-02-22',
    gfcSearchCases: [
      { caseId: 'GFC-2025-099', caseType: 'Transaction Monitoring', openedDate: '2025-12-10', closedDate: '2025-12-28', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2026-009', caseType: 'Name Screening', openedDate: '2026-01-17', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 30,
    refreshDueDate: '2026-02-22',
    dgaDueDate: '2026-02-22',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 10: PB - High Risk, 180 days → Full Review (<2 GFC but model alert)
  {
    id: '10',
    clientId: 'PB-20890',
    legalName: 'Thompson Family Office',
    lob: 'PB',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: false,
    cam312Decision: 'Auto-Close',
    cam312Status: 'Complete',
    cam312AutoCompleteFlag: 'Y',
    cam312ModelOutput: '312 Activity in line with expected activity – No review required',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-010',
    camCaseId: 'CAM-2026-010',
    createdDate: '2026-01-22',
    partyId: 'P89012',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2026-010', caseType: 'Name Screening', openedDate: '2026-01-18', closedDate: '2026-01-22', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2026-010B', caseType: 'Transaction Monitoring', openedDate: '2026-01-20', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 175,
    refreshDueDate: '2026-07-16',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 11: ML - Elevated Risk with 312 alert → 312 Full Review, CAM N/A (Requirement 5)
  {
    id: '11',
    clientId: 'ML-30789',
    legalName: 'Elevated Risk Trading Corp',
    lob: 'ML',
    riskRating: 'Elevated',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Not Applicable',
    cam312CaseId: 'CAM312-2026-011',
    createdDate: '2026-01-23',
    partyId: 'P98765',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2026-011', caseType: 'Transaction Monitoring', openedDate: '2026-01-19', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 170,
    refreshDueDate: '2026-07-12',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 12: CI - Standard Risk with 312 alert → 312 Full Review, CAM N/A (Requirement 5)
  {
    id: '12',
    clientId: 'CI-10999',
    legalName: 'Standard Risk Industries LLC',
    lob: 'CI',
    riskRating: 'Standard',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Not Applicable',
    cam312CaseId: 'CAM312-2026-012',
    createdDate: '2026-01-23',
    partyId: 'P54321',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2026-012', caseType: 'Sanctions Screening', openedDate: '2026-01-20', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 165,
    refreshDueDate: '2026-07-08',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 13: Consumer - High Risk, 120 days → Auto-Close (previously reviewed GFC cases)
  {
    id: '13',
    clientId: 'CN-10890',
    legalName: 'Metropolitan Consumer Finance',
    lob: 'Consumer',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: false,
    cam312Decision: 'Auto-Close',
    cam312Status: 'Complete',
    cam312AutoCompleteFlag: 'Y',
    cam312ModelOutput: '312 Activity in line with expected activity – No review required',
    camDecision: 'Auto-Close',
    camStatus: 'Complete',
    camAutoCompleteFlag: 'Y',
    cam312CaseId: 'CAM312-2026-013',
    camCaseId: 'CAM-2026-013',
    createdDate: '2026-01-23',
    partyId: 'P11111',
    populationTrigger: 'Refresh 120 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2025-110', caseType: 'Transaction Monitoring', openedDate: '2025-10-15', closedDate: '2025-11-20', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2025-111', caseType: 'Name Screening', openedDate: '2025-11-25', closedDate: '2025-12-05', status: 'Closed', isInScope: true }
    ],
    priorCAMCaseLast12Months: {
      caseId: 'CAM-2025-100',
      reviewDate: '2025-12-10',
      reviewedGFCCases: ['GFC-2025-110', 'GFC-2025-111']
    },
    daysToRefresh: 95,
    refreshDueDate: '2026-04-28',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: true
  },
  // Scenario 14: PB - High Risk with SAR filing → Full Review
  {
    id: '14',
    clientId: 'PB-21234',
    legalName: 'Continental Wealth Management',
    lob: 'PB',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-014',
    camCaseId: 'CAM-2026-014',
    createdDate: '2026-01-23',
    partyId: 'P22222',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2025-120', caseType: 'SAR', openedDate: '2025-08-15', closedDate: '2025-09-30', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2025-121', caseType: 'Transaction Monitoring', openedDate: '2025-12-10', status: 'Open', isInScope: true },
      { caseId: 'GFC-2026-014', caseType: 'Sanctions Screening', openedDate: '2026-01-15', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 155,
    refreshDueDate: '2026-06-27',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 3,
    hasSARLast12Months: true,
    hadCAMReviewLast12Months: false
  },
  // Scenario 15: GB/GM - Low Risk, Manual Upload → Full Review
  {
    id: '15',
    clientId: 'GB-11250',
    legalName: 'Nexus International Holdings',
    lob: 'GB/GM',
    riskRating: 'Low',
    has312Flag: false,
    has312ModelAlert: false,
    isManuallyUploaded: true,
    cam312Decision: 'Not Applicable',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    camCaseId: 'CAM-2026-015',
    createdDate: '2026-01-23',
    partyId: 'P33333',
    populationTrigger: 'Manual Upload',
    gfcSearchCases: [
      { caseId: 'GFC-2026-015', caseType: 'Transaction Monitoring', openedDate: '2026-01-18', status: 'Open', isInScope: true },
      { caseId: 'GFC-2026-015B', caseType: 'Negative News', openedDate: '2026-01-20', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 250,
    refreshDueDate: '2026-09-29',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 16: Small Business - Standard Risk, 95 days → Auto-Close
  {
    id: '16',
    clientId: 'SB-20999',
    legalName: 'Riverside Local Trading Co',
    lob: 'Small Business',
    riskRating: 'Standard',
    has312Flag: false,
    has312ModelAlert: false,
    cam312Decision: 'Not Applicable',
    camDecision: 'Auto-Close',
    camStatus: 'Complete',
    camAutoCompleteFlag: 'Y',
    camCaseId: 'CAM-2026-016',
    createdDate: '2026-01-23',
    partyId: 'P44444',
    populationTrigger: 'Refresh 95 Days',
    refreshAnniversaryMonth: 'May',
    gfcSearchCases: [],
    daysToRefresh: 85,
    refreshDueDate: '2026-04-18',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 0,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 17: CI - High Risk, Pending 312 scenario
  {
    id: '17',
    clientId: 'CI-11120',
    legalName: 'Aurora Manufacturing Partners',
    lob: 'CI',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Pending 312',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-017',
    camCaseId: 'CAM-2026-017',
    createdDate: '2026-01-23',
    partyId: 'P55555',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2026-017', caseType: 'Transaction Monitoring', openedDate: '2026-01-19', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 145,
    refreshDueDate: '2026-06-17',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 18: Consumer - High Risk, Multiple open GFC cases → Full Review
  {
    id: '18',
    clientId: 'CN-11050',
    legalName: 'Citywide Banking Services',
    lob: 'Consumer',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-018',
    camCaseId: 'CAM-2026-018',
    createdDate: '2026-01-23',
    partyId: 'P66666',
    populationTrigger: 'Refresh 120 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2025-130', caseType: 'Transaction Monitoring', openedDate: '2025-11-01', status: 'Open', isInScope: true },
      { caseId: 'GFC-2025-131', caseType: 'Sanctions Screening', openedDate: '2025-12-15', status: 'Open', isInScope: true },
      { caseId: 'GFC-2026-018', caseType: 'Name Screening', openedDate: '2026-01-10', status: 'Open', isInScope: true },
      { caseId: 'GFC-2026-018B', caseType: 'Transaction Monitoring', openedDate: '2026-01-20', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 110,
    refreshDueDate: '2026-05-13',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 4,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  },
  // Scenario 19: ML - High Risk, Manual Upload with SAR → Full Review
  {
    id: '19',
    clientId: 'ML-31234',
    legalName: 'Apex Global Trading LLC',
    lob: 'ML',
    riskRating: 'High',
    has312Flag: true,
    has312ModelAlert: true,
    isManuallyUploaded: true,
    cam312Decision: 'Full Review',
    cam312Status: 'In Progress',
    cam312AutoCompleteFlag: 'N',
    camDecision: 'Full Review',
    camStatus: 'In Progress',
    camAutoCompleteFlag: 'N',
    cam312CaseId: 'CAM312-2026-019',
    camCaseId: 'CAM-2026-019',
    createdDate: '2026-01-23',
    partyId: 'P77777',
    populationTrigger: 'Manual Upload',
    gfcSearchCases: [
      { caseId: 'GFC-2025-140', caseType: 'SAR', openedDate: '2025-07-10', closedDate: '2025-08-25', status: 'Closed', isInScope: true },
      { caseId: 'GFC-2026-019', caseType: 'Transaction Monitoring', openedDate: '2026-01-12', status: 'Open', isInScope: true },
      { caseId: 'GFC-2026-019B', caseType: 'Sanctions Screening', openedDate: '2026-01-18', status: 'Open', isInScope: true }
    ],
    daysToRefresh: 190,
    refreshDueDate: '2026-08-01',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 3,
    hasSARLast12Months: true,
    hadCAMReviewLast12Months: false
  },
  // Scenario 20: PB - Elevated Risk, no 312 alert → 312 Auto-Close, CAM N/A
  {
    id: '20',
    clientId: 'PB-21567',
    legalName: 'Heritage Private Advisors',
    lob: 'PB',
    riskRating: 'Elevated',
    has312Flag: true,
    has312ModelAlert: false,
    cam312Decision: 'Auto-Close',
    cam312Status: 'Complete',
    cam312AutoCompleteFlag: 'Y',
    cam312ModelOutput: '312 Activity in line with expected activity – No review required',
    camDecision: 'Not Applicable',
    cam312CaseId: 'CAM312-2026-020',
    createdDate: '2026-01-23',
    partyId: 'P88888',
    populationTrigger: 'Refresh 180 Days',
    gfcSearchCases: [
      { caseId: 'GFC-2026-020', caseType: 'Name Screening', openedDate: '2026-01-16', closedDate: '2026-01-21', status: 'Closed', isInScope: true }
    ],
    daysToRefresh: 178,
    refreshDueDate: '2026-07-20',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false
  }
];

export function calculateStats(clients: ClientForEvaluation[]) {
  const totalEvaluated = clients.length;
  
  // CAM 312 decisions
  const cam312FullReview = clients.filter(c => c.cam312Decision === 'Full Review').length;
  const cam312AutoClose = clients.filter(c => c.cam312Decision === 'Auto-Close').length;
  const cam312NotApplicable = clients.filter(c => c.cam312Decision === 'Not Applicable').length;
  
  // CAM decisions
  const camFullReview = clients.filter(c => c.camDecision === 'Full Review').length;
  const camAutoClose = clients.filter(c => c.camDecision === 'Auto-Close').length;
  const camPending312 = clients.filter(c => c.camDecision === 'Pending 312').length;
  
  return {
    totalEvaluated,
    cam312FullReview,
    cam312AutoClose,
    cam312NotApplicable,
    camFullReview,
    camAutoClose,
    camPending312
  };
}