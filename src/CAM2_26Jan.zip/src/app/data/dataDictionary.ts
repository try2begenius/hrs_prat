/**
 * Data Dictionary for 312/CAM Case Management System
 * 
 * This file contains comprehensive field definitions, data sources, 
 * and business rules for all case-related data elements.
 */

export interface DataDictionaryField {
  fieldName: string;
  displayName: string;
  dataType: string;
  source: string;
  required: boolean;
  description: string;
  validValues?: string[];
  businessRules?: string;
  exampleValue?: string;
}

export interface DataDictionarySection {
  section: string;
  description: string;
  fields: DataDictionaryField[];
}

/**
 * Complete Data Dictionary
 */
export const dataDictionary: DataDictionarySection[] = [
  // ============================================================================
  // CASE AND CLIENT DETAILS
  // ============================================================================
  {
    section: "Case and Client Details",
    description: "Core case identification and client information pulled from multiple enterprise systems",
    fields: [
      {
        fieldName: "id",
        displayName: "Case ID",
        dataType: "String",
        source: "System Generated",
        required: true,
        description: "Unique identifier for the 312/CAM case",
        businessRules: "Format: [Type]-[Year]-[Sequence] (e.g., 312-2025-ISR-100)",
        exampleValue: "312-2025-ISR-100"
      },
      {
        fieldName: "caseType",
        displayName: "Case Type",
        dataType: "String",
        source: "Case Creation Workflow",
        required: true,
        description: "Type of compliance case",
        validValues: ["312 Only", "CAM Only", "312 + CAM Combined"],
        exampleValue: "312 + CAM Combined"
      },
      {
        fieldName: "status",
        displayName: "Case Status",
        dataType: "String",
        source: "Workflow Engine",
        required: true,
        description: "Current workflow status of the case",
        validValues: [
          "Unassigned",
          "In Progress", 
          "Pending Sales Review",
          "In Sales Review",
          "Sales Review Complete",
          "Complete",
          "Defect Remediation",
          "Auto-Closed"
        ],
        businessRules: "Status transitions are controlled by workflow rules and user roles",
        exampleValue: "In Sales Review"
      },
      {
        fieldName: "gci",
        displayName: "GCI Number",
        dataType: "String",
        source: "Cesium / Client Master",
        required: true,
        description: "Global Client Identifier - unique identifier for the client across all Bank of America systems",
        businessRules: "Primary key for client identification; used for cross-system data retrieval",
        exampleValue: "GCI-100100"
      },
      {
        fieldName: "clientId",
        displayName: "Client ID",
        dataType: "String",
        source: "Legacy Systems",
        required: true,
        description: "Legacy client identifier maintained for backwards compatibility",
        exampleValue: "GCI-100100"
      },
      {
        fieldName: "mpId",
        displayName: "MP ID",
        dataType: "String",
        source: "WCC (World Client Connect)",
        required: false,
        description: "Master Party ID - enterprise-wide party identifier used in WCC",
        businessRules: "Not all clients have MP ID; primarily used for GWIM clients",
        exampleValue: "MP-450123"
      },
      {
        fieldName: "partyId",
        displayName: "Party ID",
        dataType: "String",
        source: "CMT (Client Management Tool)",
        required: false,
        description: "Party identifier from Client Management Tool",
        exampleValue: "PTY-789456"
      },
      {
        fieldName: "coperId",
        displayName: "CoPer ID",
        dataType: "String",
        source: "GWIM Hub",
        required: false,
        description: "Corporate/Personal identifier used in GWIM systems",
        businessRules: "Only applicable for GWIM clients (GB/GM, PB, ML, CI)",
        exampleValue: "COPER-123789"
      },
      {
        fieldName: "clientName",
        displayName: "Client Name",
        dataType: "String",
        source: "Cesium",
        required: true,
        description: "Legal name of the client entity or individual",
        exampleValue: "Acme Corporation"
      },
      {
        fieldName: "entityName",
        displayName: "Entity Name",
        dataType: "String",
        source: "Cesium",
        required: false,
        description: "Business entity name (for corporate clients)",
        businessRules: "Populated for corporate/business entities; null for individuals",
        exampleValue: "Acme Technologies LLC"
      },
      {
        fieldName: "firstName",
        displayName: "First Name",
        dataType: "String",
        source: "Cesium",
        required: false,
        description: "First name of individual client",
        businessRules: "Populated for individual clients only",
        exampleValue: "John"
      },
      {
        fieldName: "middleName",
        displayName: "Middle Name",
        dataType: "String",
        source: "Cesium",
        required: false,
        description: "Middle name of individual client",
        exampleValue: "Michael"
      },
      {
        fieldName: "lastName",
        displayName: "Last Name",
        dataType: "String",
        source: "Cesium",
        required: false,
        description: "Last name of individual client",
        businessRules: "Populated for individual clients only",
        exampleValue: "Smith"
      },
      {
        fieldName: "lineOfBusiness",
        displayName: "Line of Business (LOB)",
        dataType: "String",
        source: "Cesium / WCC",
        required: true,
        description: "Business line responsible for client relationship",
        validValues: ["GB/GM", "PB", "ML", "CI", "Consumer", "Small Business"],
        businessRules: "Determines applicable workflows, triggers, and sales review requirements",
        exampleValue: "GB/GM"
      },
      {
        fieldName: "salesOwner",
        displayName: "Sales Owner",
        dataType: "String",
        source: "WCC / CMT",
        required: true,
        description: "Name of the relationship manager or sales owner for the client",
        businessRules: "Used for case routing when sales review is required",
        exampleValue: "David Chen"
      },
      {
        fieldName: "clientOwners",
        displayName: "Client Owners",
        dataType: "Array<String>",
        source: "WCC / CMT",
        required: false,
        description: "List of all relationship managers associated with the client",
        businessRules: "May include multiple owners for complex relationships",
        exampleValue: "['David Chen', 'Sarah Johnson']"
      },
      {
        fieldName: "assignedTo",
        displayName: "Assigned Analyst",
        dataType: "String",
        source: "Workflow Assignment",
        required: false,
        description: "Central team analyst currently assigned to the case",
        businessRules: "Null for unassigned cases; updated through assignment workflow",
        exampleValue: "Jennifer Martinez"
      },
      {
        fieldName: "centralTeamContact",
        displayName: "Central Team Contact",
        dataType: "String",
        source: "Workflow History",
        required: false,
        description: "Original analyst who routed case to sales owner",
        businessRules: "Preserved for reference when case is in sales review",
        exampleValue: "Jennifer Martinez"
      },
      {
        fieldName: "naicsCode",
        displayName: "NAICS Code",
        dataType: "String",
        source: "Cesium",
        required: false,
        description: "North American Industry Classification System code",
        businessRules: "6-digit code identifying client's primary business activity",
        exampleValue: "541511"
      },
      {
        fieldName: "naicsDescription",
        displayName: "NAICS Description",
        dataType: "String",
        source: "Cesium",
        required: false,
        description: "Business description associated with NAICS code",
        exampleValue: "Custom Computer Programming Services"
      },
      {
        fieldName: "jurisdiction",
        displayName: "Jurisdiction",
        dataType: "String",
        source: "Cesium / GWIM Hub",
        required: false,
        description: "Country or region of client incorporation or residence",
        exampleValue: "Cayman Islands"
      },
      {
        fieldName: "accountOpenDate",
        displayName: "Account Open Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "PRDS (Product Reference Data Store)",
        required: false,
        description: "Date when the client relationship was established",
        exampleValue: "2018-03-15"
      },
      {
        fieldName: "createdDate",
        displayName: "Case Created Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "System Generated",
        required: true,
        description: "Date when the case was created in the system",
        exampleValue: "2025-10-25"
      },
      {
        fieldName: "dueDate",
        displayName: "Case Due Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "Calculated",
        required: true,
        description: "Target completion date for the case",
        businessRules: "Calculated based on creation date and LOB-specific SLA (typically 30 days)",
        exampleValue: "2025-11-24"
      },
      {
        fieldName: "lastActivity",
        displayName: "Last Activity Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "System Generated",
        required: true,
        description: "Most recent date of any activity on the case",
        exampleValue: "2025-10-26"
      },
      {
        fieldName: "completionDate",
        displayName: "Completion Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "Workflow",
        required: false,
        description: "Date when the case was completed",
        businessRules: "Set when case status changes to 'Complete' or 'Auto-Closed'",
        exampleValue: "2025-11-15"
      },
      {
        fieldName: "isBACEmployee",
        displayName: "BAC Employee Indicator",
        dataType: "Boolean",
        source: "CP (Compliance Platform)",
        required: false,
        description: "Indicates if client is a Bank of America employee",
        businessRules: "Triggers enhanced monitoring requirements",
        exampleValue: "false"
      },
      {
        fieldName: "isBACAffiliate",
        displayName: "BAC Affiliate Indicator",
        dataType: "Boolean",
        source: "CP (Compliance Platform)",
        required: false,
        description: "Indicates if client is affiliated with Bank of America",
        businessRules: "Triggers additional conflict of interest reviews",
        exampleValue: "false"
      },
      {
        fieldName: "isRegO",
        displayName: "Regulation O Indicator",
        dataType: "Boolean",
        source: "CP (Compliance Platform)",
        required: false,
        description: "Indicates if client is subject to Regulation O (insider lending restrictions)",
        businessRules: "Requires executive officer/director relationship disclosure",
        exampleValue: "false"
      },
      {
        fieldName: "isManuallyTriggered",
        displayName: "Manually Triggered",
        dataType: "Boolean",
        source: "Case Creation",
        required: false,
        description: "Indicates if case was created through ad-hoc manual process vs. automated trigger",
        exampleValue: "false"
      },
      {
        fieldName: "amlAttributes",
        displayName: "AML Attributes / CBA Codes",
        dataType: "Array<String>",
        source: "ORRCA / AML Systems",
        required: false,
        description: "Customer Business Activity codes and AML-related attributes",
        businessRules: "Used for risk segmentation and enhanced due diligence triggers",
        exampleValue: "['CBA-502: Money Services Business', 'High-Risk Jurisdiction']"
      },
      {
        fieldName: "riskLevel",
        displayName: "Risk Level",
        dataType: "String",
        source: "ORRCA",
        required: false,
        description: "Overall risk classification for the case",
        validValues: ["Low", "Medium", "High", "Critical"],
        exampleValue: "High"
      },
      {
        fieldName: "priority",
        displayName: "Priority",
        dataType: "String",
        source: "Calculated",
        required: false,
        description: "Case priority based on risk, aging, and business rules",
        validValues: ["Low", "Medium", "High", "Urgent"],
        exampleValue: "High"
      }
    ]
  },

  // ============================================================================
  // 312 CASE
  // ============================================================================
  {
    section: "312 Case",
    description: "Section 312 of the USA PATRIOT Act - Enhanced Due Diligence for correspondent and private banking accounts",
    fields: [
      {
        fieldName: "case312Data.dueDate",
        displayName: "312 Due Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "Calculated",
        required: true,
        description: "Due date for 312 case completion",
        businessRules: "Based on LOB-specific refresh cycles and trigger dates",
        exampleValue: "2025-11-24"
      },
      {
        fieldName: "case312Data.aging",
        displayName: "312 Aging",
        dataType: "Number",
        source: "Calculated",
        required: true,
        description: "Number of days since case creation",
        businessRules: "Calculated as: Current Date - Created Date",
        exampleValue: "32"
      },
      {
        fieldName: "case312Data.status",
        displayName: "312 Status",
        dataType: "String",
        source: "Workflow",
        required: true,
        description: "Current status of 312 review portion",
        validValues: ["Open", "In Progress", "Pending Sales Review", "Complete", "Auto-Closed"],
        exampleValue: "In Progress"
      },
      {
        fieldName: "case312Data.disposition",
        displayName: "312 Disposition",
        dataType: "String",
        source: "Analyst Response",
        required: false,
        description: "Final disposition of 312 review",
        validValues: ["Complete - No Action", "Complete - TRMS Filed", "Sent to Sales"],
        exampleValue: "Sent to Sales"
      },
      {
        fieldName: "case312Data.modelResult",
        displayName: "312 Model Result",
        dataType: "String",
        source: "312 Predictive Model",
        required: true,
        description: "Result from 312 machine learning model",
        validValues: ["Anniversary", "High-Risk", "Cross-Border Activity", "Volume Anomaly", "Manual Review"],
        exampleValue: "High-Risk"
      },
      {
        fieldName: "case312Data.modelResultDescription",
        displayName: "Model Result Description",
        dataType: "String",
        source: "312 Predictive Model",
        required: true,
        description: "Detailed explanation of model result",
        exampleValue: "Client triggered high-risk review due to elevated dynamic risk rating and offshore jurisdiction"
      },
      {
        fieldName: "refreshDueDates",
        displayName: "Refresh Due Dates",
        dataType: "Array<Date>",
        source: "ORRCA / LOB Systems",
        required: false,
        description: "Upcoming refresh due dates for the client",
        businessRules: "LOB-specific: PB/ML/CI=180 days (high-risk), GB/GM=Global DGA dates, Consumer=120 days, Small Business=95 days",
        exampleValue: "['2025-12-15', '2026-06-15']"
      },
      {
        fieldName: "lastRefreshCompletionDate",
        displayName: "Last Refresh Completion Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "Historical Case Data",
        required: false,
        description: "Date when the most recent 312 refresh was completed",
        exampleValue: "2025-06-15"
      },
      {
        fieldName: "case312Data.expectedActivityVolume",
        displayName: "Expected Activity Volume",
        dataType: "Object",
        source: "DDQ (Due Diligence Questionnaire)",
        required: true,
        description: "Expected transaction volumes by category",
        businessRules: "Captured during client onboarding/refresh; used for anomaly detection",
        exampleValue: "{ electronicTransfers: 50, cashChecks: 10 }"
      },
      {
        fieldName: "case312Data.expectedActivityValue",
        displayName: "Expected Activity Value",
        dataType: "Object",
        source: "DDQ",
        required: true,
        description: "Expected transaction dollar values by category",
        businessRules: "Used to compare actual vs. expected activity patterns",
        exampleValue: "{ electronicTransfers: 2500000, cashChecks: 50000 }"
      },
      {
        fieldName: "case312Data.expectedCrossBorderActivity",
        displayName: "Expected Cross-Border Activity",
        dataType: "String",
        source: "DDQ",
        required: false,
        description: "Expected international transactions and jurisdictions",
        exampleValue: "Regular wire transfers to UK, Germany, and Japan for international consulting services"
      },
      {
        fieldName: "case312Data.purposeOfRelationship",
        displayName: "Purpose of Relationship",
        dataType: "String",
        source: "DDQ / KYC",
        required: false,
        description: "Business purpose for banking relationship (GB/GM only)",
        businessRules: "Required for GB/GM LOB; describes overall relationship purpose",
        exampleValue: "Treasury management and trade finance services for international manufacturing operations"
      },
      {
        fieldName: "case312Data.purposeOfAccount",
        displayName: "Purpose of Account",
        dataType: "String",
        source: "DDQ / KYC",
        required: false,
        description: "General purpose description for accounts (ML/PB only)",
        businessRules: "High-level description; detailed grid provided in purposeOfAccountDetails",
        exampleValue: "Investment management and wealth planning services"
      },
      {
        fieldName: "case312Data.purposeOfAccountDetails",
        displayName: "Purpose of Account Details",
        dataType: "Array<Case312Account>",
        source: "DDQ / KYC",
        required: false,
        description: "Detailed account-level purpose and source of funds (ML/PB only)",
        businessRules: "Grid format with account number, account name, and source of funds for each account",
        exampleValue: "[{ accountNumber: '****1234', accountName: 'Investment Portfolio', sourceOfFunds: 'Executive compensation and stock options' }]"
      },
      {
        fieldName: "case312Data.sourceOfFunds",
        displayName: "Source of Funds",
        dataType: "String",
        source: "DDQ / KYC",
        required: false,
        description: "General source of funds description (ML/PB only)",
        exampleValue: "Employment income, investment returns, and inheritance"
      },
      {
        fieldName: "case312Response.question1_disposition",
        displayName: "Q1: Money Movement Disposition",
        dataType: "String",
        source: "Analyst Response",
        required: true,
        description: "Disposition for expected value and volume of money movement review",
        validValues: ["need_trms", "not_unusual_other", "not_unusual_market_volatility"],
        exampleValue: "not_unusual_other"
      },
      {
        fieldName: "case312Response.question1_commentary",
        displayName: "Q1: Money Movement Commentary",
        dataType: "String (Text Area)",
        source: "Analyst Response",
        required: true,
        description: "Analyst's detailed commentary on money movement patterns",
        exampleValue: "Reviewed 12-month transaction history. Volume increase of 15% aligns with new subsidiary expansion mentioned in annual report."
      },
      {
        fieldName: "case312Response.question2_disposition",
        displayName: "Q2: Cross-Border Disposition",
        dataType: "String",
        source: "Analyst Response",
        required: true,
        description: "Disposition for cross-border money movement review",
        validValues: ["need_trms", "not_unusual"],
        exampleValue: "not_unusual"
      },
      {
        fieldName: "case312Response.question2_commentary",
        displayName: "Q2: Cross-Border Commentary",
        dataType: "String (Text Area)",
        source: "Analyst Response",
        required: true,
        description: "Analyst's commentary on cross-border activity",
        exampleValue: "Cross-border wire transfers to Cayman Islands subsidiary are consistent with business model and previously disclosed activities."
      },
      {
        fieldName: "case312Response.question3_option",
        displayName: "Q3: Purpose of Relationship/Account",
        dataType: "String",
        source: "Analyst Response",
        required: true,
        description: "Assessment of alignment between purpose and actual activity",
        validValues: ["all_aligned", "need_trms", "activity_differed"],
        exampleValue: "all_aligned"
      },
      {
        fieldName: "case312Response.question3_comments",
        displayName: "Q3: Purpose Comments",
        dataType: "String (Text Area)",
        source: "Analyst Response",
        required: false,
        description: "Comments explaining activity differences (required if activity_differed selected)",
        businessRules: "Mandatory when question3_option = 'activity_differed'",
        exampleValue: "Activity patterns align with stated business purpose of technology consulting services."
      },
      {
        fieldName: "case312Response.question4_disposition",
        displayName: "Q4: Source of Funds Disposition",
        dataType: "String",
        source: "Analyst Response",
        required: false,
        description: "Disposition for source of funds review (ML/PB only)",
        validValues: ["need_trms", "not_unusual"],
        businessRules: "Only applicable for ML and PB line of business",
        exampleValue: "not_unusual"
      },
      {
        fieldName: "case312Response.question4_commentary",
        displayName: "Q4: Source of Funds Commentary",
        dataType: "String (Text Area)",
        source: "Analyst Response",
        required: false,
        description: "Analyst's commentary on source of funds",
        businessRules: "Required when question4_disposition is provided (ML/PB only)",
        exampleValue: "Source of funds verified through employment records and tax documentation on file."
      },
      {
        fieldName: "case312Response.caseAction",
        displayName: "312 Case Action",
        dataType: "String",
        source: "Analyst Response",
        required: true,
        description: "Final action taken on 312 case",
        validValues: ["complete_no_action", "complete_trms_filed", "send_to_sales"],
        businessRules: "Determines next workflow step",
        exampleValue: "send_to_sales"
      },
      {
        fieldName: "case312Response.trmsNumber",
        displayName: "TRMS Number",
        dataType: "String",
        source: "TRMS System",
        required: false,
        description: "Transaction Reporting and Monitoring System case number",
        businessRules: "Required when caseAction = 'complete_trms_filed'",
        exampleValue: "TRMS-2025-45678"
      },
      {
        fieldName: "case312Response.salesOwner",
        displayName: "Sales Owner (312 Response)",
        dataType: "String",
        source: "Analyst Selection",
        required: false,
        description: "Sales owner selected for routing",
        businessRules: "Required when caseAction = 'send_to_sales'; pre-populated from client data",
        exampleValue: "David Chen"
      },
      {
        fieldName: "case312Response.salesComments",
        displayName: "Comments to Sales Owner",
        dataType: "String (Text Area)",
        source: "Analyst Response",
        required: false,
        description: "Comments and questions for sales owner",
        businessRules: "Optional when routing to sales; provides context for sales review",
        exampleValue: "David - Please review increased wire activity to Cayman Islands and confirm alignment with business expansion plans."
      }
    ]
  },

  // ============================================================================
  // CAM CASE
  // ============================================================================
  {
    section: "CAM Case",
    description: "Continuous Activity Monitoring - ongoing monitoring of client activity and alerts",
    fields: [
      {
        fieldName: "camCaseData.dueDate",
        displayName: "CAM Due Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "Calculated",
        required: true,
        description: "Due date for CAM case completion",
        businessRules: "Typically 30 days from case creation",
        exampleValue: "2025-11-24"
      },
      {
        fieldName: "camCaseData.aging",
        displayName: "CAM Aging",
        dataType: "Number",
        source: "Calculated",
        required: true,
        description: "Number of days since CAM case creation",
        exampleValue: "32"
      },
      {
        fieldName: "camCaseData.status",
        displayName: "CAM Status",
        dataType: "String",
        source: "Workflow",
        required: true,
        description: "Current status of CAM review",
        validValues: ["Open", "In Progress", "Pending Sales Review", "Complete", "Auto-Closed"],
        exampleValue: "In Progress"
      },
      {
        fieldName: "camCaseData.disposition",
        displayName: "CAM Disposition",
        dataType: "String",
        source: "Analyst Response",
        required: false,
        description: "Final disposition of CAM case",
        validValues: ["No additional CAM escalation required", "CAM Case Escalated", "TRMS Filed", "Sent to Sales"],
        exampleValue: "No additional CAM escalation required"
      },
      {
        fieldName: "camCaseData.triggers",
        displayName: "CAM Triggers",
        dataType: "Array<String>",
        source: "Monitoring Systems",
        required: true,
        description: "Events that triggered CAM case creation",
        validValues: [
          "TRMS from FLU/FLD",
          "TRMS from Other Process",
          "Second Line Case",
          "Fraud Case",
          "Sanctions Alert",
          "312 Alert"
        ],
        exampleValue: "['TRMS from FLU/FLD', 'Sanctions Alert']"
      },
      {
        fieldName: "monitoringDashboard.trmsFLU",
        displayName: "TRMS from FLU/FLD",
        dataType: "Array<TRMSRecord>",
        source: "FLU (Front Line Unit) / FLD Systems",
        required: false,
        description: "Transaction monitoring cases from front-line detection processes",
        businessRules: "Includes TRMS filed by FLU teams for suspicious activity",
        exampleValue: "[{ id: 'TRMS-2025-12345', type: 'Structuring', date: '2025-09-15' }]"
      },
      {
        fieldName: "monitoringDashboard.trmsOther",
        displayName: "TRMS from Other Process",
        dataType: "Array<TRMSRecord>",
        source: "Various TRMS Sources",
        required: false,
        description: "Transaction monitoring cases from other processes (non-FLU/FLD)",
        businessRules: "Includes TRMS from second line, special investigations, etc.",
        exampleValue: "[{ id: 'TRMS-2025-23456', type: 'Trade Finance Review', date: '2025-08-20' }]"
      },
      {
        fieldName: "monitoringDashboard.secondLineCases",
        displayName: "Second Line Cases",
        dataType: "Array<SecondLineCase>",
        source: "Second Line Defense Systems",
        required: false,
        description: "Cases from second line of defense monitoring (Quality Assurance, Testing)",
        businessRules: "Independent validation and quality review cases",
        exampleValue: "[{ caseId: '2L-2025-789', caseType: 'QA Review', date: '2025-09-10' }]"
      },
      {
        fieldName: "monitoringDashboard.fraudCases",
        displayName: "Fraud Cases",
        dataType: "Array<FraudCase>",
        source: "Fraud Detection Systems",
        required: false,
        description: "Fraud investigation cases associated with the client",
        exampleValue: "[{ caseId: 'FRD-2025-334', narrative: 'Phishing attempt', date: '2025-08-15' }]"
      },
      {
        fieldName: "monitoringDashboard.sanctionDetails",
        displayName: "Sanctions Alerts",
        dataType: "Array<SanctionDetail>",
        source: "Sanctions Screening Systems (OFAC, etc.)",
        required: false,
        description: "OFAC and other sanctions screening alerts",
        businessRules: "Includes both blocked transactions and false positives",
        exampleValue: "[{ caseId: 'SANC-2025-892', alertDescription: 'Name match to OFAC SDN', outcome: 'False Positive' }]"
      },
      {
        fieldName: "monitoringDashboard.alert312Details",
        displayName: "312 Alerts",
        dataType: "Array<Alert312Detail>",
        source: "312 Monitoring Process",
        required: false,
        description: "312-specific alerts and triggers that generated this case",
        exampleValue: "[{ lob312: 'GB/GM', alertDate: '2025-10-20', alertDescription: 'High-risk client review' }]"
      },
      {
        fieldName: "monitoringDashboard.lobMonitoringControls",
        displayName: "LOB Monitoring Controls",
        dataType: "Array<LOBMonitoringControl>",
        source: "LOB-Specific Monitoring Systems",
        required: false,
        description: "Line of Business specific monitoring activities and controls",
        businessRules: "Different LOBs have different monitoring processes (e.g., PB Admin Reviews, MLCI Trade Oversight)",
        exampleValue: "[{ lob: 'PB', activityName: 'Admin Reviews', outcome: 'Last Review: 12/3/25' }]"
      },
      {
        fieldName: "camCaseResponse.question1",
        displayName: "Q1: Attestations Complete",
        dataType: "Boolean",
        source: "Analyst Response",
        required: true,
        description: "Confirmation that analyst has reviewed all monitoring dashboard items",
        businessRules: "Must be true to proceed; ensures all CAM data has been reviewed",
        exampleValue: "true"
      },
      {
        fieldName: "camCaseResponse.question1_1_attestations",
        displayName: "Q1.1: Selected Attestations",
        dataType: "Array<String>",
        source: "Analyst Response",
        required: false,
        description: "Specific monitoring items reviewed by analyst",
        validValues: [
          "TRMS from FLU/FLD",
          "TRMS from Other Process",
          "Second Line Cases",
          "Fraud Cases",
          "Sanctions Details",
          "312 Alerts",
          "LOB Monitoring Controls"
        ],
        businessRules: "Required if question1 = true; multi-select checkboxes",
        exampleValue: "['TRMS from FLU/FLD', 'Sanctions Details', 'LOB Monitoring Controls']"
      },
      {
        fieldName: "camCaseResponse.question1_2_trms",
        displayName: "Q1.2: New TRMS Required",
        dataType: "String",
        source: "Analyst Response",
        required: false,
        description: "Indication if new TRMS needs to be filed based on review",
        validValues: ["Yes", "No"],
        businessRules: "If 'Yes', TRMS number must be provided in question1_3_trmsNumber",
        exampleValue: "No"
      },
      {
        fieldName: "camCaseResponse.question1_3_trmsNumber",
        displayName: "Q1.3: TRMS Number",
        dataType: "String",
        source: "Analyst Input / TRMS System",
        required: false,
        description: "TRMS case number if new TRMS was filed",
        businessRules: "Required if question1_2_trms = 'Yes'",
        exampleValue: "TRMS-2025-98765"
      },
      {
        fieldName: "camCaseResponse.question2_confirmation",
        displayName: "Q2: No Escalation Required",
        dataType: "Boolean",
        source: "Analyst Response",
        required: true,
        description: "Confirmation that no additional CAM escalation is needed",
        businessRules: "If false, case must be escalated or sent to sales",
        exampleValue: "true"
      },
      {
        fieldName: "camCaseResponse.question3_action",
        displayName: "Q3: Case Action",
        dataType: "String",
        source: "Analyst Response",
        required: true,
        description: "Final action for CAM case",
        validValues: ["complete_no_action", "complete_trms_filed", "send_to_sales"],
        exampleValue: "complete_no_action"
      },
      {
        fieldName: "camCaseResponse.question3_trms",
        displayName: "Q3: TRMS Filed",
        dataType: "String",
        source: "TRMS System",
        required: false,
        description: "TRMS number if filing TRMS as part of completion",
        businessRules: "Required if question3_action = 'complete_trms_filed'",
        exampleValue: "TRMS-2025-11111"
      },
      {
        fieldName: "camCaseResponse.question3_salesOwner",
        displayName: "Q3: Sales Owner",
        dataType: "String",
        source: "Analyst Selection",
        required: false,
        description: "Sales owner for routing if sending to sales",
        businessRules: "Required if question3_action = 'send_to_sales'",
        exampleValue: "David Chen"
      },
      {
        fieldName: "camCaseResponse.question3_comments",
        displayName: "Q3: Comments to Sales",
        dataType: "String (Text Area)",
        source: "Analyst Response",
        required: false,
        description: "Comments for sales owner when routing case",
        exampleValue: "Please review recent sanctions alerts and provide context on Cayman Islands transactions."
      },
      {
        fieldName: "camCaseResponse.question3_confirmation",
        displayName: "Q3: Action Confirmation",
        dataType: "Boolean",
        source: "Analyst Response",
        required: true,
        description: "Attestation checkbox confirming the selected action",
        businessRules: "Must be checked to submit CAM response",
        exampleValue: "true"
      },
      {
        fieldName: "caseProcessorComments",
        displayName: "Case Processor Comments",
        dataType: "Array<CaseProcessorComment>",
        source: "Analyst Input",
        required: false,
        description: "Comments from central team analyst to sales owner",
        businessRules: "Can include separate comments for 312 and CAM portions",
        exampleValue: "[{ caseType: '312', processorName: 'Jennifer Martinez', comment: 'Please review...', date: '2025-10-26' }]"
      }
    ]
  },

  // ============================================================================
  // SALES OWNER REVIEW
  // ============================================================================
  {
    section: "Sales Owner Review",
    description: "Sales owner perspective and response to cases requiring front-line input",
    fields: [
      {
        fieldName: "salesOwnerResponse.comments",
        displayName: "Sales Owner Comments",
        dataType: "String (Text Area)",
        source: "Sales Owner Input",
        required: true,
        description: "Sales owner's response to analyst questions and case review",
        businessRules: "Required to complete sales review; provides business context from relationship manager",
        exampleValue: "The increased wire activity to our Cayman subsidiary is related to the Q3 expansion project announced in July. The $2.5M transfer was for equipment procurement as documented in the board-approved capital plan. All activity aligns with the client's business strategy and previously disclosed operations."
      },
      {
        fieldName: "salesOwnerResponse.submittedBy",
        displayName: "Submitted By",
        dataType: "String",
        source: "System Captured",
        required: false,
        description: "Name of sales owner who submitted the response",
        businessRules: "Auto-populated from user session",
        exampleValue: "David Chen"
      },
      {
        fieldName: "salesOwnerResponse.submittedDate",
        displayName: "Submission Date",
        dataType: "DateTime",
        source: "System Generated",
        required: false,
        description: "Timestamp when sales owner submitted response",
        exampleValue: "2025-10-27T14:32:00Z"
      },
      {
        fieldName: "salesOwnerResponse.isSubmitted",
        displayName: "Response Submitted",
        dataType: "Boolean",
        source: "System Flag",
        required: false,
        description: "Flag indicating whether sales owner has submitted their response",
        businessRules: "Changes case status to 'Sales Review Complete' when true",
        exampleValue: "true"
      }
    ]
  },

  // ============================================================================
  // MONITORING DASHBOARD - DETAILED FIELD DEFINITIONS
  // ============================================================================
  {
    section: "Monitoring Dashboard - TRMS Records",
    description: "Transaction Reporting and Monitoring System case details",
    fields: [
      {
        fieldName: "TRMSRecord.id",
        displayName: "TRMS ID",
        dataType: "String",
        source: "TRMS System",
        required: true,
        description: "Unique identifier for TRMS case",
        exampleValue: "TRMS-2025-12345"
      },
      {
        fieldName: "TRMSRecord.type",
        displayName: "TRMS Type",
        dataType: "String",
        source: "TRMS System",
        required: true,
        description: "Classification of suspicious activity",
        validValues: ["Structuring", "Trade Finance", "Wire Transfer", "Cash Activity", "Other"],
        exampleValue: "Wire Transfer"
      },
      {
        fieldName: "TRMSRecord.monitoringProcess",
        displayName: "Monitoring Process",
        dataType: "String",
        source: "TRMS System",
        required: true,
        description: "Process that generated the TRMS",
        exampleValue: "FLU Automated Alert"
      },
      {
        fieldName: "TRMSRecord.descriptionReason",
        displayName: "Description/Reason",
        dataType: "String",
        source: "TRMS System",
        required: true,
        description: "Reason for TRMS filing",
        exampleValue: "Unusual pattern of wire transfers to high-risk jurisdiction"
      },
      {
        fieldName: "TRMSRecord.impactType",
        displayName: "Impact Type",
        dataType: "String",
        source: "TRMS System",
        required: true,
        description: "Classification of TRMS impact",
        validValues: ["Informational", "Action Required", "Escalation"],
        exampleValue: "Informational"
      },
      {
        fieldName: "TRMSRecord.narrative",
        displayName: "Narrative",
        dataType: "String (Text Area)",
        source: "TRMS System / Analyst",
        required: true,
        description: "Detailed narrative describing the suspicious activity and investigation",
        exampleValue: "Client executed series of wire transfers totaling $500K to newly established account in Cayman Islands..."
      },
      {
        fieldName: "TRMSRecord.date",
        displayName: "TRMS Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "TRMS System",
        required: true,
        description: "Date when TRMS was filed",
        exampleValue: "2025-09-15"
      },
      {
        fieldName: "TRMSRecord.submitterLOB",
        displayName: "Submitter LOB",
        dataType: "String",
        source: "TRMS System",
        required: true,
        description: "Line of business that submitted the TRMS",
        exampleValue: "GB/GM"
      },
      {
        fieldName: "TRMSRecord.submitterName",
        displayName: "Submitter Name",
        dataType: "String",
        source: "TRMS System",
        required: true,
        description: "Name of person who filed TRMS",
        exampleValue: "Michael Roberts"
      }
    ]
  },

  {
    section: "Monitoring Dashboard - Sanctions",
    description: "OFAC and sanctions screening alert details",
    fields: [
      {
        fieldName: "SanctionDetail.caseId",
        displayName: "Sanctions Case ID",
        dataType: "String",
        source: "Sanctions Screening System",
        required: true,
        description: "Unique identifier for sanctions alert",
        exampleValue: "SANC-2025-0892"
      },
      {
        fieldName: "SanctionDetail.product",
        displayName: "Product",
        dataType: "String",
        source: "Sanctions System",
        required: true,
        description: "Product or transaction type that triggered alert",
        validValues: ["Wire Transfer", "ACH", "Check", "Trade Finance", "Other"],
        exampleValue: "Wire Transfer"
      },
      {
        fieldName: "SanctionDetail.alertDate",
        displayName: "Alert Date",
        dataType: "Date (YYYY-MM-DD)",
        source: "Sanctions System",
        required: true,
        description: "Date when sanctions alert was generated",
        exampleValue: "2025-09-12"
      },
      {
        fieldName: "SanctionDetail.alertDescription",
        displayName: "Alert Description",
        dataType: "String",
        source: "Sanctions System",
        required: true,
        description: "Description of the sanctions match or alert",
        exampleValue: "Name match to OFAC SDN list on wire beneficiary"
      },
      {
        fieldName: "SanctionDetail.narrative",
        displayName: "Narrative",
        dataType: "String (Text Area)",
        source: "Sanctions Analyst",
        required: false,
        description: "Detailed investigation narrative explaining the alert and resolution",
        exampleValue: "Initial screening flagged beneficiary name as potential match. Enhanced review confirmed different entity with no connection to sanctioned party."
      },
      {
        fieldName: "SanctionDetail.blockReject",
        displayName: "Block/Reject",
        dataType: "Boolean",
        source: "Sanctions System",
        required: true,
        description: "Indicates if transaction was blocked or rejected",
        exampleValue: "true"
      },
      {
        fieldName: "SanctionDetail.blockRejectReason",
        displayName: "Block/Reject Reason",
        dataType: "String",
        source: "Sanctions Analyst",
        required: false,
        description: "Reason for blocking or rejecting the transaction",
        businessRules: "Typically populated when blockReject = true",
        exampleValue: "Temporary hold for enhanced review - False positive confirmed"
      },
      {
        fieldName: "SanctionDetail.lob",
        displayName: "LOB",
        dataType: "String",
        source: "Sanctions System",
        required: true,
        description: "Line of business associated with the alert",
        exampleValue: "GB/GM"
      },
      {
        fieldName: "SanctionDetail.outcome",
        displayName: "Outcome",
        dataType: "String",
        source: "Sanctions Analyst",
        required: true,
        description: "Final disposition of sanctions alert",
        validValues: ["False Positive - Cleared", "Blocked - Compliance Hold", "Cleared", "Escalated"],
        exampleValue: "False Positive - Cleared"
      }
    ]
  },

  {
    section: "Monitoring Dashboard - LOB Controls",
    description: "Line of Business specific monitoring activities and controls",
    fields: [
      {
        fieldName: "LOBMonitoringControl.lob",
        displayName: "LOB",
        dataType: "String",
        source: "LOB Monitoring Systems",
        required: true,
        description: "Line of business conducting the monitoring activity",
        validValues: ["All", "GB/GM", "PB", "ML", "CI", "Consumer", "Small Business"],
        exampleValue: "PB"
      },
      {
        fieldName: "LOBMonitoringControl.activityName",
        displayName: "Activity Name",
        dataType: "String",
        source: "LOB Monitoring Systems",
        required: true,
        description: "Name of the monitoring activity or control",
        exampleValue: "Admin Reviews (PB)"
      },
      {
        fieldName: "LOBMonitoringControl.activityDescription",
        displayName: "Activity Description",
        dataType: "String (Text Area)",
        source: "LOB Monitoring Systems",
        required: true,
        description: "Detailed description of the monitoring activity and its purpose",
        exampleValue: "Attestation of account coding/set up to ensure alignment with client instructions"
      },
      {
        fieldName: "LOBMonitoringControl.outcome",
        displayName: "Outcome",
        dataType: "String",
        source: "LOB Monitoring Systems",
        required: true,
        description: "Results or metrics from the monitoring activity",
        businessRules: "Format varies by activity type; may include counts, dates, or other metrics",
        exampleValue: "Last Date of Review: 12/3/25 Number of TRMS: 1"
      }
    ]
  }
];

/**
 * Helper function to get field definition by field name
 */
export function getFieldDefinition(fieldName: string): DataDictionaryField | undefined {
  for (const section of dataDictionary) {
    const field = section.fields.find(f => f.fieldName === fieldName);
    if (field) {
      return field;
    }
  }
  return undefined;
}

/**
 * Helper function to get all fields for a section
 */
export function getSectionFields(sectionName: string): DataDictionaryField[] {
  const section = dataDictionary.find(s => s.section === sectionName);
  return section ? section.fields : [];
}

/**
 * Helper function to get all section names
 */
export function getAllSections(): string[] {
  return dataDictionary.map(s => s.section);
}

/**
 * Helper function to search fields by keyword
 */
export function searchFields(keyword: string): DataDictionaryField[] {
  const results: DataDictionaryField[] = [];
  const searchTerm = keyword.toLowerCase();
  
  for (const section of dataDictionary) {
    for (const field of section.fields) {
      if (
        field.fieldName.toLowerCase().includes(searchTerm) ||
        field.displayName.toLowerCase().includes(searchTerm) ||
        field.description.toLowerCase().includes(searchTerm) ||
        field.source.toLowerCase().includes(searchTerm)
      ) {
        results.push(field);
      }
    }
  }
  
  return results;
}
