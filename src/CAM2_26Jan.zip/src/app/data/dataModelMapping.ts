/**
 * Data Model Mapping
 * 
 * Maps database columns to API fields to UI components
 */

export interface FieldMapping {
  uiField: string;
  uiDisplayName: string;
  apiField: string;
  databaseTable: string;
  databaseColumn: string;
  dataType: string;
  transformation?: string;
  calculation?: string;
  notes?: string;
}

export interface EntityRelationship {
  fromTable: string;
  fromColumn: string;
  toTable: string;
  toColumn: string;
  relationshipType: 'One-to-Many' | 'One-to-One' | 'Many-to-Many';
  description: string;
}

export const populationFieldMappings: FieldMapping[] = [
  {
    uiField: 'client_legal_name',
    uiDisplayName: 'Client Name',
    apiField: 'clientLegalName',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'LEGAL_NAME',
    dataType: 'String',
    transformation: 'Direct mapping',
    notes: 'Primary display identifier for client'
  },
  {
    uiField: 'client_id',
    uiDisplayName: 'Client ID',
    apiField: 'clientId',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'CLIENT_ID',
    dataType: 'String',
    transformation: 'Direct mapping',
    notes: 'Business key for client identification'
  },
  {
    uiField: 'gci_number',
    uiDisplayName: 'GCI Number',
    apiField: 'gciNumber',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'PARTY_ID',
    dataType: 'String',
    transformation: 'Direct mapping (internal ID exposed as GCI)',
    notes: 'Global Client Identifier for cross-system reconciliation'
  },
  {
    uiField: 'line_of_business',
    uiDisplayName: 'LOB',
    apiField: 'lineOfBusiness',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'LOB',
    dataType: 'Enum',
    transformation: 'Direct mapping',
    notes: 'Determines population criteria logic'
  },
  {
    uiField: 'risk_rating',
    uiDisplayName: 'Risk',
    apiField: 'riskRating',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'RISK_RATING',
    dataType: 'Enum',
    transformation: 'Direct mapping',
    notes: 'Current AML risk rating'
  },
  {
    uiField: 'client_status',
    uiDisplayName: 'Status',
    apiField: 'clientStatus',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'ACTIVE_STATUS',
    dataType: 'String',
    transformation: 'Y/N to Active/Closed',
    notes: 'Active status gates all population logic'
  },
  {
    uiField: 'has_312_flag',
    uiDisplayName: '312 Flag',
    apiField: 'has312Flag',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'HAS_312_FLAG',
    dataType: 'Boolean',
    transformation: 'Y/N to true/false',
    notes: 'AWARE system 312 flag indicator'
  },
  {
    uiField: 'refresh_due_date',
    uiDisplayName: 'Refresh Due Date',
    apiField: 'refreshDueDate',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'REFRESH_DUE_DATE',
    dataType: 'Date',
    transformation: 'Oracle DATE to ISO 8601 string',
    notes: 'Next scheduled risk rating refresh'
  },
  {
    uiField: 'days_to_refresh',
    uiDisplayName: 'Days to Refresh',
    apiField: 'daysToRefresh',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'REFRESH_DUE_DATE',
    dataType: 'Integer',
    calculation: 'REFRESH_DUE_DATE - SYSDATE',
    transformation: 'Calculated field',
    notes: 'Computed daily, key trigger for PB/ML/Consumer'
  },
  {
    uiField: 'dga_due_date',
    uiDisplayName: 'DGA Due Date',
    apiField: 'dgaDueDate',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'GLOBAL_DGA_DUE_DATE',
    dataType: 'Date',
    transformation: 'Oracle DATE to ISO 8601 string',
    notes: 'GB/GM High Risk trigger date'
  },
  {
    uiField: 'family_anniversary_date',
    uiDisplayName: 'Family Anniversary Date',
    apiField: 'familyAnniversaryDate',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'FAMILY_ANNIVERSARY_DATE',
    dataType: 'Date',
    transformation: 'Oracle DATE to ISO 8601 string',
    notes: 'GB/GM Elevated/Standard refresh trigger'
  },
  {
    uiField: 'population_312',
    uiDisplayName: 'In 312 Population',
    apiField: 'population312',
    databaseTable: 'Multiple',
    databaseColumn: 'Calculated',
    dataType: 'Boolean',
    calculation: 'LOB-specific business rules evaluation',
    notes: 'Computed based on LOB criteria'
  },
  {
    uiField: 'population_cam',
    uiDisplayName: 'In CAM Population',
    apiField: 'populationCam',
    databaseTable: 'CAM_PARTY_MASTER',
    databaseColumn: 'RISK_RATING + ACTIVE_STATUS',
    dataType: 'Boolean',
    calculation: 'RISK_RATING = "High" AND ACTIVE_STATUS = "Y"',
    notes: 'Simple High Risk + Active logic'
  },
  {
    uiField: 'population_result',
    uiDisplayName: 'Population(s)',
    apiField: 'populationResult',
    databaseTable: 'Derived',
    databaseColumn: 'Calculated',
    dataType: 'Enum',
    calculation: 'Based on population_312 and population_cam flags',
    notes: 'Display value: Both, 312, CAM, or Excluded'
  }
];

export const caseFieldMappings: FieldMapping[] = [
  {
    uiField: 'case_id',
    uiDisplayName: 'Case ID',
    apiField: 'caseId',
    databaseTable: 'CAM_312_CASES / CAM_CASES',
    databaseColumn: 'CAM_312_CASE_ID / CAM_CASE_ID',
    dataType: 'String',
    transformation: 'Direct mapping',
    notes: 'Unique case identifier'
  },
  {
    uiField: 'case_status',
    uiDisplayName: 'Case Status',
    apiField: 'caseStatus',
    databaseTable: 'CAM_312_CASES / CAM_CASES',
    databaseColumn: 'CASE_STATUS',
    dataType: 'Enum',
    transformation: 'Direct mapping',
    notes: 'Workflow status tracking'
  },
  {
    uiField: 'case_decision',
    uiDisplayName: 'Decision',
    apiField: 'decision',
    databaseTable: 'CAM_312_CASES / CAM_CASES',
    databaseColumn: 'DECISION',
    dataType: 'Enum',
    transformation: 'Direct mapping',
    notes: 'Case outcome/disposition'
  },
  {
    uiField: 'assigned_to',
    uiDisplayName: 'Assigned To',
    apiField: 'assignedTo',
    databaseTable: 'CAM_312_CASES / CAM_CASES',
    databaseColumn: 'ASSIGNED_TO',
    dataType: 'String',
    transformation: 'Direct mapping',
    notes: 'Current case owner'
  },
  {
    uiField: 'created_date',
    uiDisplayName: 'Created Date',
    apiField: 'createdDate',
    databaseTable: 'CAM_312_CASES / CAM_CASES',
    databaseColumn: 'CASE_CREATED_DATE',
    dataType: 'Date',
    transformation: 'Oracle DATE to ISO 8601 string',
    notes: 'Case creation timestamp'
  },
  {
    uiField: 'sla_due_date',
    uiDisplayName: 'SLA Due Date',
    apiField: 'slaDueDate',
    databaseTable: 'CAM_312_CASES / CAM_CASES',
    databaseColumn: 'SLA_DUE_DATE',
    dataType: 'Date',
    transformation: 'Oracle DATE to ISO 8601 string',
    notes: 'Service level agreement deadline'
  },
  {
    uiField: 'has_model_alert',
    uiDisplayName: 'Model Alert',
    apiField: 'hasModelAlert',
    databaseTable: 'CAM_312_CASES',
    databaseColumn: 'HAS_MODEL_ALERT',
    dataType: 'Boolean',
    transformation: 'Y/N to true/false',
    notes: '312 model alert flag'
  },
  {
    uiField: 'auto_complete_flag',
    uiDisplayName: 'Auto-Closed',
    apiField: 'autoCompleteFlag',
    databaseTable: 'CAM_312_CASES / CAM_CASES',
    databaseColumn: 'AUTO_COMPLETE_FLAG',
    dataType: 'Boolean',
    transformation: 'Y/N to true/false',
    notes: 'System auto-closure indicator'
  },
  {
    uiField: 'gfc_count_total',
    uiDisplayName: 'Total GFC Cases',
    apiField: 'gfcCountTotal',
    databaseTable: 'CAM_CASES',
    databaseColumn: 'GFC_COUNT_TOTAL',
    dataType: 'Integer',
    calculation: 'COUNT(*) FROM CAM_GFC_CASES WHERE OPENED_DATE >= SYSDATE - 365',
    notes: 'GFC cases in last 12 months'
  },
  {
    uiField: 'gfc_count_open',
    uiDisplayName: 'Open GFC Cases',
    apiField: 'gfcCountOpen',
    databaseTable: 'CAM_CASES',
    databaseColumn: 'GFC_COUNT_OPEN',
    dataType: 'Integer',
    calculation: 'COUNT(*) FROM CAM_GFC_CASES WHERE CASE_STATUS = "Open"',
    notes: 'Currently open GFC cases'
  },
  {
    uiField: 'has_sar_12m',
    uiDisplayName: 'SAR Filed',
    apiField: 'hasSar12m',
    databaseTable: 'CAM_CASES',
    databaseColumn: 'HAS_SAR_12M',
    dataType: 'Boolean',
    transformation: 'Y/N to true/false',
    calculation: 'EXISTS check on CAM_GFC_CASES.IS_SAR = Y',
    notes: 'SAR filing indicator'
  }
];

export const entityRelationships: EntityRelationship[] = [
  {
    fromTable: 'CAM_POPULATION_TRIGGER',
    fromColumn: 'PARTY_ID',
    toTable: 'CAM_PARTY_MASTER',
    toColumn: 'PARTY_ID',
    relationshipType: 'One-to-Many',
    description: 'Each party can have multiple triggers over time'
  },
  {
    fromTable: 'CAM_312_CASES',
    fromColumn: 'PARTY_ID',
    toTable: 'CAM_PARTY_MASTER',
    toColumn: 'PARTY_ID',
    relationshipType: 'One-to-Many',
    description: 'Each party can have multiple 312 cases'
  },
  {
    fromTable: 'CAM_312_CASES',
    fromColumn: 'TRIGGER_ID',
    toTable: 'CAM_POPULATION_TRIGGER',
    toColumn: 'TRIGGER_ID',
    relationshipType: 'One-to-One',
    description: 'Each 312 case is created from one trigger'
  },
  {
    fromTable: 'CAM_CASES',
    fromColumn: 'PARTY_ID',
    toTable: 'CAM_PARTY_MASTER',
    toColumn: 'PARTY_ID',
    relationshipType: 'One-to-Many',
    description: 'Each party can have multiple CAM cases'
  },
  {
    fromTable: 'CAM_CASES',
    fromColumn: 'TRIGGER_ID',
    toTable: 'CAM_POPULATION_TRIGGER',
    toColumn: 'TRIGGER_ID',
    relationshipType: 'One-to-One',
    description: 'Each CAM case is created from one trigger'
  },
  {
    fromTable: 'CAM_CASES',
    fromColumn: 'CAM_312_CASE_ID',
    toTable: 'CAM_312_CASES',
    toColumn: 'CAM_312_CASE_ID',
    relationshipType: 'One-to-One',
    description: 'CAM case links to associated 312 case'
  },
  {
    fromTable: 'CAM_GFC_CASES',
    fromColumn: 'PARTY_ID',
    toTable: 'CAM_PARTY_MASTER',
    toColumn: 'PARTY_ID',
    relationshipType: 'One-to-Many',
    description: 'Each party can have multiple GFC cases from monitoring systems'
  },
  {
    fromTable: 'CAM_CASE_GFC_LINK',
    fromColumn: 'CAM_CASE_ID',
    toTable: 'CAM_CASES',
    toColumn: 'CAM_CASE_ID',
    relationshipType: 'One-to-Many',
    description: 'Links CAM cases to reviewed GFC cases (junction table)'
  },
  {
    fromTable: 'CAM_CASE_GFC_LINK',
    fromColumn: 'GFC_CASE_ID',
    toTable: 'CAM_GFC_CASES',
    toColumn: 'GFC_CASE_ID',
    relationshipType: 'One-to-Many',
    description: 'Links GFC cases to CAM review (junction table)'
  }
];

export interface APIEndpointMapping {
  endpoint: string;
  method: string;
  purpose: string;
  primaryTable: string;
  relatedTables: string[];
  responseFields: string[];
  calculations: string[];
}

export const apiEndpointMappings: APIEndpointMapping[] = [
  {
    endpoint: '/api/population/summary',
    method: 'GET',
    purpose: 'Returns summary statistics for population identification',
    primaryTable: 'CAM_PARTY_MASTER',
    relatedTables: ['CAM_POPULATION_TRIGGER'],
    responseFields: ['totalClients', 'activeClients', 'closedClients', 'pop312Count', 'popCamCount', 'bothPopulationsCount'],
    calculations: [
      'COUNT(*) WHERE ACTIVE_STATUS = Y',
      'COUNT(*) WHERE ACTIVE_STATUS = N',
      'COUNT(*) WHERE [312 criteria logic]',
      'COUNT(*) WHERE RISK_RATING = High AND ACTIVE_STATUS = Y'
    ]
  },
  {
    endpoint: '/api/population/clients',
    method: 'GET',
    purpose: 'Returns detailed client list with population flags',
    primaryTable: 'CAM_PARTY_MASTER',
    relatedTables: ['CAM_POPULATION_TRIGGER', 'CAM_312_CASES', 'CAM_CASES'],
    responseFields: ['clientId', 'legalName', 'lob', 'riskRating', 'refreshDueDate', 'daysToRefresh', 'population312', 'populationCam'],
    calculations: [
      'REFRESH_DUE_DATE - SYSDATE as daysToRefresh',
      'LOB-specific 312 population criteria evaluation',
      'RISK_RATING = High AND ACTIVE_STATUS = Y as populationCam'
    ]
  },
  {
    endpoint: '/api/cases/312/worklist',
    method: 'GET',
    purpose: 'Returns 312 case worklist with filtering',
    primaryTable: 'CAM_312_CASES',
    relatedTables: ['CAM_PARTY_MASTER', 'CAM_POPULATION_TRIGGER'],
    responseFields: ['caseId', 'clientName', 'lob', 'status', 'decision', 'assignedTo', 'createdDate', 'slaDueDate', 'hasModelAlert'],
    calculations: [
      'JOIN to CAM_PARTY_MASTER for client details',
      'CASE_STATUS filtering based on role',
      'SLA breach calculation'
    ]
  },
  {
    endpoint: '/api/cases/cam/worklist',
    method: 'GET',
    purpose: 'Returns CAM case worklist with filtering',
    primaryTable: 'CAM_CASES',
    relatedTables: ['CAM_PARTY_MASTER', 'CAM_312_CASES', 'CAM_GFC_CASES'],
    responseFields: ['caseId', 'clientName', 'lob', 'status', 'decision', 'assignedTo', 'gfcCountTotal', 'gfcCountOpen', 'hasSar12m'],
    calculations: [
      'JOIN to CAM_PARTY_MASTER for client details',
      'Aggregate GFC counts from CAM_GFC_CASES',
      'SAR detection from GFC cases',
      'Auto-closure logic evaluation'
    ]
  },
  {
    endpoint: '/api/cases/312/{caseId}',
    method: 'GET',
    purpose: 'Returns detailed 312 case information',
    primaryTable: 'CAM_312_CASES',
    relatedTables: ['CAM_PARTY_MASTER', 'CAM_POPULATION_TRIGGER', 'CAM_REVIEW_HISTORY', 'CAM_ASSIGNMENT_HISTORY'],
    responseFields: ['All 312 case fields', 'client details', 'trigger details', 'review history', 'assignment history'],
    calculations: [
      'Full case detail with relationships',
      'Historical audit trail',
      'Model output interpretation'
    ]
  },
  {
    endpoint: '/api/cases/cam/{caseId}',
    method: 'GET',
    purpose: 'Returns detailed CAM case information with GFC cases',
    primaryTable: 'CAM_CASES',
    relatedTables: ['CAM_PARTY_MASTER', 'CAM_312_CASES', 'CAM_GFC_CASES', 'CAM_CASE_GFC_LINK', 'CAM_REVIEW_HISTORY'],
    responseFields: ['All CAM case fields', 'client details', 'related 312 case', 'GFC cases list', 'review history'],
    calculations: [
      'Full case detail with all relationships',
      'GFC case aggregations',
      'Auto-closure decision logic',
      'SAR and previous review flags'
    ]
  },
  {
    endpoint: '/api/cases/312',
    method: 'POST',
    purpose: 'Creates new 312 case from population trigger',
    primaryTable: 'CAM_312_CASES',
    relatedTables: ['CAM_PARTY_MASTER', 'CAM_POPULATION_TRIGGER', 'CAM_AUDIT_TRAIL'],
    responseFields: ['newCaseId', 'status', 'decision', 'hasModelAlert'],
    calculations: [
      'Generate CAM312-YYYY-### case ID',
      'Execute 312 model evaluation',
      'Determine auto-closure eligibility',
      'Create audit trail entry'
    ]
  },
  {
    endpoint: '/api/cases/cam',
    method: 'POST',
    purpose: 'Creates new CAM case from population trigger',
    primaryTable: 'CAM_CASES',
    relatedTables: ['CAM_PARTY_MASTER', 'CAM_POPULATION_TRIGGER', 'CAM_312_CASES', 'CAM_GFC_CASES', 'CAM_AUDIT_TRAIL'],
    responseFields: ['newCaseId', 'status', 'decision', 'gfcSummary', 'autoCompleteFlag'],
    calculations: [
      'Generate CAM-YYYY-### case ID',
      'Query GFC cases for last 12 months',
      'Check for prior 312 auto-closure',
      'Evaluate auto-closure criteria',
      'Create audit trail entry'
    ]
  }
];
