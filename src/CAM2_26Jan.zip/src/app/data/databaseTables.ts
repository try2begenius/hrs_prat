/**
 * CAM Case Management System - Database Tables
 * 
 * Documentation of all database tables, columns, and relationships
 */

export interface DatabaseColumn {
  columnName: string;
  dataType: string;
  nullable: boolean;
  defaultValue?: string;
  constraints?: string;
  description: string;
}

export interface DatabaseTable {
  tableName: string;
  purpose: string;
  primaryKey: string;
  rowCountEstimate: string;
  indexes: string[];
  columns: DatabaseColumn[];
}

export const databaseTables: DatabaseTable[] = [
  {
    tableName: 'CAM_PARTY_MASTER',
    purpose: 'Master table for client/party information including LOB, risk ratings, and refresh schedules',
    primaryKey: 'PARTY_ID',
    rowCountEstimate: '100,000+',
    indexes: ['IDX_PARTY_CLIENT_ID', 'IDX_PARTY_LOB', 'IDX_PARTY_RISK', 'IDX_PARTY_REFRESH_DUE'],
    columns: [
      { columnName: 'PARTY_ID', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'PK', description: 'Unique internal party identifier (e.g., P12345)' },
      { columnName: 'CLIENT_ID', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'UNIQUE', description: 'External client identifier (business key)' },
      { columnName: 'LEGAL_NAME', dataType: 'VARCHAR2(500)', nullable: false, description: 'Legal name of the client/entity' },
      { columnName: 'LOB', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'CHECK', description: 'Line of Business: GB/GM, PB, ML, Consumer, CI, Small Business' },
      { columnName: 'RISK_RATING', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'CHECK', description: 'Current risk rating: High, Elevated, Standard, Low' },
      { columnName: 'REFRESH_DUE_DATE', dataType: 'DATE', nullable: true, description: 'Date when next refresh is due' },
      { columnName: 'REFRESH_ANNIVERSARY_MONTH', dataType: 'VARCHAR2(20)', nullable: true, description: 'Anniversary month for refresh (Small Business LOB)' },
      { columnName: 'DGA_DUE_DATE', dataType: 'DATE', nullable: true, description: 'DGA (Due Diligence Assessment) due date' },
      { columnName: 'GLOBAL_DGA_DUE_DATE', dataType: 'DATE', nullable: true, description: 'Global DGA due date (GB/GM LOB)' },
      { columnName: 'FAMILY_ANNIVERSARY_DATE', dataType: 'DATE', nullable: true, description: 'Family anniversary date for refresh scheduling' },
      { columnName: 'HAS_312_FLAG', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Indicates if party is subject to 312 review (Y or N)' },
      { columnName: 'ACTIVE_STATUS', dataType: 'CHAR(1)', nullable: true, defaultValue: 'Y', constraints: 'CHECK', description: 'Active status of party record (Y or N)' },
      { columnName: 'CREATED_DATE', dataType: 'TIMESTAMP', nullable: true, defaultValue: 'CURRENT_TIMESTAMP', description: 'Record creation timestamp' },
      { columnName: 'CREATED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who created the record' },
      { columnName: 'MODIFIED_DATE', dataType: 'TIMESTAMP', nullable: true, description: 'Last modification timestamp' },
      { columnName: 'MODIFIED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who last modified the record' },
    ]
  },
  {
    tableName: 'CAM_POPULATION_TRIGGER',
    purpose: 'Tracks population identification triggers that initiate case creation based on LOB-specific rules',
    primaryKey: 'TRIGGER_ID',
    rowCountEstimate: '50,000+',
    indexes: ['IDX_POP_PARTY_ID', 'IDX_POP_TRIGGER_DATE', 'IDX_POP_STATUS'],
    columns: [
      { columnName: 'TRIGGER_ID', dataType: 'NUMBER', nullable: false, constraints: 'PK, IDENTITY', description: 'Auto-generated unique trigger identifier' },
      { columnName: 'PARTY_ID', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'FK', description: 'Reference to CAM_PARTY_MASTER' },
      { columnName: 'TRIGGER_TYPE', dataType: 'VARCHAR2(30)', nullable: false, constraints: 'CHECK', description: 'Type of trigger: Refresh 180 Days, Refresh 120 Days, Refresh 95 Days, DGA Due Date, Manual Upload' },
      { columnName: 'TRIGGER_DATE', dataType: 'DATE', nullable: false, description: 'Date when trigger was activated' },
      { columnName: 'DAYS_TO_REFRESH', dataType: 'NUMBER', nullable: true, description: 'Number of days until refresh due date at time of trigger' },
      { columnName: 'IS_MANUAL_UPLOAD', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Flag indicating manual exception by CAM team (Y or N)' },
      { columnName: 'MANUAL_UPLOAD_REASON', dataType: 'VARCHAR2(1000)', nullable: true, description: 'Explanation for manual upload exception' },
      { columnName: 'TRIGGERED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User or system process that triggered' },
      { columnName: 'TRIGGER_STATUS', dataType: 'VARCHAR2(20)', nullable: true, defaultValue: 'Active', constraints: 'CHECK', description: 'Status: Active, Processed, Cancelled' },
      { columnName: 'CASES_CREATED_FLAG', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Flag indicating if cases were created (Y or N)' },
      { columnName: 'CREATED_DATE', dataType: 'TIMESTAMP', nullable: true, defaultValue: 'CURRENT_TIMESTAMP', description: 'Record creation timestamp' },
      { columnName: 'CREATED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who created the record' },
    ]
  },
  {
    tableName: 'CAM_312_CASES',
    purpose: '312 review cases with model alert evaluation and auto-closure logic',
    primaryKey: 'CAM_312_CASE_ID',
    rowCountEstimate: '25,000+',
    indexes: ['IDX_312_PARTY_ID', 'IDX_312_STATUS', 'IDX_312_DECISION', 'IDX_312_CREATED_DATE', 'IDX_312_ASSIGNED_TO', 'IDX_312_SLA_DUE'],
    columns: [
      { columnName: 'CAM_312_CASE_ID', dataType: 'VARCHAR2(30)', nullable: false, constraints: 'PK', description: 'Unique 312 case identifier (e.g., CAM312-2026-001)' },
      { columnName: 'PARTY_ID', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'FK', description: 'Reference to CAM_PARTY_MASTER' },
      { columnName: 'TRIGGER_ID', dataType: 'NUMBER', nullable: true, constraints: 'FK', description: 'Reference to CAM_POPULATION_TRIGGER' },
      { columnName: 'CASE_STATUS', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'CHECK', description: 'Current status: Unassigned, In Progress, Complete, Closed, Cancelled' },
      { columnName: 'DECISION', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'CHECK', description: 'Case decision: Full Review, Auto-Close, Not Applicable' },
      { columnName: 'HAS_MODEL_ALERT', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Y if 312 model detected alert requiring manual review' },
      { columnName: 'AUTO_COMPLETE_FLAG', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Y if case was auto-closed without manual review' },
      { columnName: 'MODEL_OUTPUT', dataType: 'VARCHAR2(2000)', nullable: true, description: '312 model output message explaining decision' },
      { columnName: 'CASE_CREATED_DATE', dataType: 'DATE', nullable: false, description: 'Date case was created' },
      { columnName: 'CASE_ASSIGNED_DATE', dataType: 'DATE', nullable: true, description: 'Date case was assigned to analyst' },
      { columnName: 'CASE_COMPLETED_DATE', dataType: 'DATE', nullable: true, description: 'Date case was completed' },
      { columnName: 'ASSIGNED_TO', dataType: 'VARCHAR2(50)', nullable: true, description: 'User assigned to the case' },
      { columnName: 'COMPLETED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who completed the case' },
      { columnName: 'DISPOSITION_CODE', dataType: 'VARCHAR2(50)', nullable: true, description: 'Final disposition code' },
      { columnName: 'DISPOSITION_NOTES', dataType: 'CLOB', nullable: true, description: 'Detailed disposition notes' },
      { columnName: 'SLA_DUE_DATE', dataType: 'DATE', nullable: true, description: 'Service Level Agreement due date' },
      { columnName: 'PRIORITY', dataType: 'VARCHAR2(20)', nullable: true, constraints: 'CHECK', description: 'Priority: High, Medium, Low' },
      { columnName: 'CREATED_DATE', dataType: 'TIMESTAMP', nullable: true, defaultValue: 'CURRENT_TIMESTAMP', description: 'Record creation timestamp' },
      { columnName: 'CREATED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who created the record' },
      { columnName: 'MODIFIED_DATE', dataType: 'TIMESTAMP', nullable: true, description: 'Last modification timestamp' },
      { columnName: 'MODIFIED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who last modified the record' },
    ]
  },
  {
    tableName: 'CAM_CASES',
    purpose: 'CAM review cases with GFC case evaluation and auto-closure logic',
    primaryKey: 'CAM_CASE_ID',
    rowCountEstimate: '25,000+',
    indexes: ['IDX_CAM_PARTY_ID', 'IDX_CAM_312_CASE', 'IDX_CAM_STATUS', 'IDX_CAM_DECISION', 'IDX_CAM_CREATED_DATE', 'IDX_CAM_ASSIGNED_TO', 'IDX_CAM_SLA_DUE'],
    columns: [
      { columnName: 'CAM_CASE_ID', dataType: 'VARCHAR2(30)', nullable: false, constraints: 'PK', description: 'Unique CAM case identifier (e.g., CAM-2026-001)' },
      { columnName: 'PARTY_ID', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'FK', description: 'Reference to CAM_PARTY_MASTER' },
      { columnName: 'TRIGGER_ID', dataType: 'NUMBER', nullable: true, constraints: 'FK', description: 'Reference to CAM_POPULATION_TRIGGER' },
      { columnName: 'CAM_312_CASE_ID', dataType: 'VARCHAR2(30)', nullable: true, constraints: 'FK', description: 'Reference to related 312 case' },
      { columnName: 'CASE_STATUS', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'CHECK', description: 'Current status: Unassigned, In Progress, Complete, Closed, Cancelled' },
      { columnName: 'DECISION', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'CHECK', description: 'Case decision: Full Review, Auto-Close, Pending 312, Not Applicable' },
      { columnName: 'AUTO_COMPLETE_FLAG', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Y if case was auto-closed without manual review' },
      { columnName: 'GFC_COUNT_TOTAL', dataType: 'NUMBER', nullable: true, defaultValue: '0', description: 'Total count of GFC cases in last 12 months' },
      { columnName: 'GFC_COUNT_OPEN', dataType: 'NUMBER', nullable: true, defaultValue: '0', description: 'Count of open GFC cases' },
      { columnName: 'GFC_COUNT_NEW', dataType: 'NUMBER', nullable: true, defaultValue: '0', description: 'Count of new/unreviewed GFC cases in last 12 months' },
      { columnName: 'HAD_312_NOT_AUTO_CLOSED', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Flag if prior 312 case was not auto-closed (Y or N)' },
      { columnName: 'COMPLETED_CASES_12M', dataType: 'NUMBER', nullable: true, defaultValue: '0', description: 'Count of completed GFC cases in last 12 months' },
      { columnName: 'HAS_SAR_12M', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Flag if SAR filed in last 12 months (Y or N)' },
      { columnName: 'HAD_CAM_REVIEW_12M', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Flag if CAM review conducted in last 12 months (Y or N)' },
      { columnName: 'CASE_CREATED_DATE', dataType: 'DATE', nullable: false, description: 'Date case was created' },
      { columnName: 'CASE_ASSIGNED_DATE', dataType: 'DATE', nullable: true, description: 'Date case was assigned to analyst' },
      { columnName: 'CASE_COMPLETED_DATE', dataType: 'DATE', nullable: true, description: 'Date case was completed' },
      { columnName: 'ASSIGNED_TO', dataType: 'VARCHAR2(50)', nullable: true, description: 'User assigned to the case' },
      { columnName: 'COMPLETED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who completed the case' },
      { columnName: 'DISPOSITION_CODE', dataType: 'VARCHAR2(50)', nullable: true, description: 'Final disposition code' },
      { columnName: 'DISPOSITION_NOTES', dataType: 'CLOB', nullable: true, description: 'Detailed disposition notes' },
      { columnName: 'SLA_DUE_DATE', dataType: 'DATE', nullable: true, description: 'Service Level Agreement due date' },
      { columnName: 'PRIORITY', dataType: 'VARCHAR2(20)', nullable: true, constraints: 'CHECK', description: 'Priority: High, Medium, Low' },
      { columnName: 'CREATED_DATE', dataType: 'TIMESTAMP', nullable: true, defaultValue: 'CURRENT_TIMESTAMP', description: 'Record creation timestamp' },
      { columnName: 'CREATED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who created the record' },
      { columnName: 'MODIFIED_DATE', dataType: 'TIMESTAMP', nullable: true, description: 'Last modification timestamp' },
      { columnName: 'MODIFIED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who last modified the record' },
    ]
  },
  {
    tableName: 'CAM_GFC_CASES',
    purpose: 'Generic Findings Cases from various monitoring systems',
    primaryKey: 'GFC_CASE_ID',
    rowCountEstimate: '200,000+',
    indexes: ['IDX_GFC_PARTY_ID', 'IDX_GFC_STATUS', 'IDX_GFC_OPENED_DATE', 'IDX_GFC_TYPE', 'IDX_GFC_IS_SAR'],
    columns: [
      { columnName: 'GFC_CASE_ID', dataType: 'VARCHAR2(30)', nullable: false, constraints: 'PK', description: 'Unique GFC case identifier (e.g., GFC-2026-001)' },
      { columnName: 'PARTY_ID', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'FK', description: 'Reference to CAM_PARTY_MASTER' },
      { columnName: 'CASE_TYPE', dataType: 'VARCHAR2(50)', nullable: false, description: 'Type: Transaction Monitoring, Sanctions Screening, Name Screening, SAR, Negative News, etc.' },
      { columnName: 'OPENED_DATE', dataType: 'DATE', nullable: false, description: 'Date the GFC case was opened' },
      { columnName: 'CLOSED_DATE', dataType: 'DATE', nullable: true, description: 'Date the GFC case was closed (NULL if still open)' },
      { columnName: 'CASE_STATUS', dataType: 'VARCHAR2(20)', nullable: false, constraints: 'CHECK', description: 'Status: Open, Closed, Cancelled' },
      { columnName: 'IS_IN_SCOPE', dataType: 'CHAR(1)', nullable: true, defaultValue: 'Y', constraints: 'CHECK', description: 'Whether GFC case is in scope for CAM review (last 12 months)' },
      { columnName: 'IS_SAR', dataType: 'CHAR(1)', nullable: true, defaultValue: 'N', constraints: 'CHECK', description: 'Flag indicating if this is a Suspicious Activity Report' },
      { columnName: 'PRIORITY', dataType: 'VARCHAR2(20)', nullable: true, description: 'Priority level' },
      { columnName: 'DISPOSITION_CODE', dataType: 'VARCHAR2(50)', nullable: true, description: 'Final disposition code' },
      { columnName: 'CREATED_DATE', dataType: 'TIMESTAMP', nullable: true, defaultValue: 'CURRENT_TIMESTAMP', description: 'Record creation timestamp' },
      { columnName: 'CREATED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who created the record' },
      { columnName: 'MODIFIED_DATE', dataType: 'TIMESTAMP', nullable: true, description: 'Last modification timestamp' },
      { columnName: 'MODIFIED_BY', dataType: 'VARCHAR2(50)', nullable: true, description: 'User who last modified the record' },
    ]
  },
];
