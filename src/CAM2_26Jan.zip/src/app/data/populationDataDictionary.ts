/**
 * Population Identification - Data Dictionary
 * 
 * Comprehensive documentation of all data fields, sources, and business rules 
 * for the Population Identification Engine
 */

export interface DataField {
  fieldName: string;
  displayName: string;
  dataType: string;
  source: string;
  description: string;
  validValues?: string;
  businessRules?: string;
  required: boolean;
  example?: string;
}

export interface BusinessRuleSection {
  title: string;
  rules: string[];
}

export interface DataSourceSystem {
  name: string;
  description: string;
  color: 'primary' | 'secondary' | 'info' | 'warning' | 'error' | 'success';
}

/**
 * Summary Statistics Fields
 * High-level aggregated metrics for population identification
 */
export const summaryFields: DataField[] = [
  {
    fieldName: 'total_clients',
    displayName: 'Total Clients',
    dataType: 'Integer',
    source: 'Aggregated from FLU Systems',
    description: 'Total count of all clients in the population identification scope, including both active and closed clients',
    validValues: 'Any positive integer',
    businessRules: 'Sum of all unique client records across all FLU systems (Cesium, CMT, CP, WCC)',
    required: true,
    example: '14'
  },
  {
    fieldName: 'active_clients',
    displayName: 'Active Clients',
    dataType: 'Integer',
    source: 'Client Status from FLU Systems',
    description: 'Count of clients with Active status',
    validValues: 'Any non-negative integer',
    businessRules: 'Only clients with Client_Status = "Active" are counted',
    required: true,
    example: '13'
  },
  {
    fieldName: 'closed_clients',
    displayName: 'Closed Clients',
    dataType: 'Integer',
    source: 'Client Status from FLU Systems',
    description: 'Count of clients with Closed status',
    validValues: 'Any non-negative integer',
    businessRules: 'Only clients with Client_Status = "Closed" are counted. Closed clients are excluded from population scope',
    required: true,
    example: '1'
  },
  {
    fieldName: 'pop_312_count',
    displayName: '312 Population',
    dataType: 'Integer',
    source: 'Calculated from 312 Population Logic',
    description: 'Count of clients included in the CAM 312 population based on LOB-specific criteria',
    validValues: 'Any non-negative integer',
    businessRules: 'Clients meeting 312 criteria: GB/GM (Risk + Timing + 312 Flag) OR PB/ML (Refresh within 180 days + PVT code)',
    required: true,
    example: '7'
  },
  {
    fieldName: 'pop_cam_count',
    displayName: 'CAM Population',
    dataType: 'Integer',
    source: 'Calculated from CAM Population Logic',
    description: 'Count of clients included in the CAM population',
    validValues: 'Any non-negative integer',
    businessRules: 'Simple logic: High Risk + Active Status (all LOBs)',
    required: true,
    example: '9'
  },
  {
    fieldName: 'both_populations_count',
    displayName: 'Both Populations',
    dataType: 'Integer',
    source: 'Calculated intersection',
    description: 'Count of clients included in both 312 AND CAM populations',
    validValues: 'Any non-negative integer',
    businessRules: 'Clients meeting criteria for both 312 population AND CAM population',
    required: true,
    example: '5'
  }
];

/**
 * Client-Level Data Fields
 * Detailed attributes for individual client records
 */
export const clientFields: DataField[] = [
  {
    fieldName: 'client_legal_name',
    displayName: 'Client Name',
    dataType: 'String (255)',
    source: 'FLU Systems (Cesium, CMT, CP, WCC)',
    description: 'Legal name of the client entity',
    validValues: 'Any valid text string',
    businessRules: 'Primary identifier for client display. Must be unique per Client ID',
    required: true,
    example: 'Transcontinental Holdings LLC'
  },
  {
    fieldName: 'client_id',
    displayName: 'Client ID',
    dataType: 'String (20)',
    source: 'FLU Systems',
    description: 'Unique client identifier from the source FLU system',
    validValues: 'Alphanumeric format varies by LOB',
    businessRules: 'Primary key for client identification. Format: [PREFIX]-[NUMBER]',
    required: true,
    example: 'TH-992341'
  },
  {
    fieldName: 'gci_number',
    displayName: 'GCI Number',
    dataType: 'String (20)',
    source: 'Global Client Identifier System',
    description: 'Global Client Identifier - unique identifier across all Bank of America systems',
    validValues: 'Format: GCI-[IDENTIFIER]',
    businessRules: 'Must be unique across all LOBs and systems. Used for cross-system client reconciliation',
    required: true,
    example: 'GCI-POP-001'
  },
  {
    fieldName: 'coper_id',
    displayName: 'CoPer ID',
    dataType: 'String (20)',
    source: 'Customer Persistence System',
    description: 'Customer Persistence identifier for client relationship tracking',
    validValues: 'Format: CP-[ID]-[YEAR]',
    businessRules: 'Links client to relationship management and historical data',
    required: false,
    example: 'CP-001-2024'
  },
  {
    fieldName: 'line_of_business',
    displayName: 'LOB',
    dataType: 'Enumerated String',
    source: 'FLU Systems',
    description: 'Line of Business categorization for the client',
    validValues: 'GB/GM, PB, ML, Consumer, CI',
    businessRules: 'Determines which population criteria logic applies. GB/GM = Global Banking/Global Markets, PB = Private Bank, ML = Merrill Lynch, CI = Corporate & Institutional',
    required: true,
    example: 'GB/GM'
  },
  {
    fieldName: 'flu_system',
    displayName: 'FLU System',
    dataType: 'Enumerated String',
    source: 'System of Record',
    description: 'Front Line Unit system where client data originates',
    validValues: 'Cesium, CMT, CP, WCC',
    businessRules: 'Cesium (GB/GM), CMT (Private Banking), CP (Merrill Lynch), WCC (Consumer/CI). Determines data source and refresh patterns',
    required: true,
    example: 'Cesium'
  },
  {
    fieldName: 'risk_rating',
    displayName: 'Risk',
    dataType: 'Enumerated String',
    source: 'AWARE / Risk Rating System',
    description: 'Current AML risk rating of the client',
    validValues: 'High, Elevated, Standard, Low',
    businessRules: 'CAM population requires High risk. 312 population criteria vary by LOB. Risk rating must be current at time of evaluation',
    required: true,
    example: 'High'
  },
  {
    fieldName: 'client_status',
    displayName: 'Status',
    dataType: 'Enumerated String',
    source: 'FLU Systems',
    description: 'Current operational status of the client relationship',
    validValues: 'Active, Closed',
    businessRules: 'CRITICAL: Only Active clients are included in population scope. Closed clients are automatically excluded from both 312 and CAM populations',
    required: true,
    example: 'Active'
  },
  {
    fieldName: 'has_312_flag',
    displayName: '312 Flag',
    dataType: 'Boolean',
    source: 'AWARE',
    description: 'Indicates if client has been flagged for 312 monitoring in AWARE system',
    validValues: 'True (YES), False (NO)',
    businessRules: 'For GB/GM clients, this flag is one of the criteria for 312 population inclusion. May be set manually or automatically',
    required: true,
    example: 'True'
  },
  {
    fieldName: 'refresh_due_date',
    displayName: 'Refresh Due Date',
    dataType: 'Date (YYYY-MM-DD)',
    source: 'Risk Rating System',
    description: 'Scheduled date for next risk rating refresh/review',
    validValues: 'Valid future date',
    businessRules: 'Used to calculate Days_to_Refresh. PB/ML 312 criteria: must be within 180 days. GB/GM uses different timing rules by risk level',
    required: true,
    example: '2025-03-15'
  },
  {
    fieldName: 'days_to_refresh',
    displayName: 'Days to Refresh',
    dataType: 'Integer',
    source: 'Calculated field',
    description: 'Number of calendar days until the refresh due date',
    validValues: 'Any integer (can be negative if overdue)',
    businessRules: 'Calculated as: Refresh_Due_Date - Current_Date. Key trigger for PB/ML (≤180 days), Consumer (≤120 days), Small Business (≤95 days)',
    required: true,
    example: '138'
  },
  {
    fieldName: 'sales_owner',
    displayName: 'Sales Owner',
    dataType: 'String (100)',
    source: 'FLU Systems / CRM',
    description: 'Primary relationship manager or sales owner for the client',
    validValues: 'Valid employee name',
    businessRules: 'Determines case assignment when 312 cases are created. Must have appropriate entitlements for LOB access',
    required: true,
    example: 'Sarah Mitchell'
  },
  {
    fieldName: 'dga_due_date',
    displayName: 'DGA Due Date',
    dataType: 'Date (YYYY-MM-DD)',
    source: 'AWARE / Risk System',
    description: 'Global DGA (Deep Dive Assessment) due date - GB/GM High Risk only',
    validValues: 'Valid future date or NULL',
    businessRules: 'GB/GM High Risk clients: presence of DGA Due Date triggers 312 population inclusion. Only applicable to GB/GM LOB',
    required: false,
    example: '2025-03-15'
  },
  {
    fieldName: 'family_anniversary_date',
    displayName: 'Family Anniversary Date',
    dataType: 'Date (YYYY-MM-DD)',
    source: 'Client Hierarchy System',
    description: 'Anniversary date for client family/group review',
    validValues: 'Valid date or NULL',
    businessRules: 'GB/GM Elevated/Standard Risk: if within 180 days (170-180 day range), triggers 312 population inclusion',
    required: false,
    example: '2025-04-10'
  },
  {
    fieldName: 'has_pvt_code',
    displayName: 'PVT Code',
    dataType: 'Boolean',
    source: 'CRA (Customer Risk Assessment)',
    description: 'Indicates presence of PVT (Private) code from CRA system',
    validValues: 'True (Present), False (Not Present)',
    businessRules: 'PB/ML clients: Required criterion for 312 population (along with refresh within 180 days). Not applicable to other LOBs',
    required: false,
    example: 'True'
  },
  {
    fieldName: 'population_312',
    displayName: 'In 312 Population',
    dataType: 'Boolean',
    source: 'Calculated from 312 Logic',
    description: 'Result of 312 population criteria evaluation',
    validValues: 'True (Included), False (Excluded)',
    businessRules: 'True if client meets LOB-specific 312 criteria. See CAM 312 Population Logic documentation for detailed rules',
    required: true,
    example: 'True'
  },
  {
    fieldName: 'population_cam',
    displayName: 'In CAM Population',
    dataType: 'Boolean',
    source: 'Calculated from CAM Logic',
    description: 'Result of CAM population criteria evaluation',
    validValues: 'True (Included), False (Excluded)',
    businessRules: 'True if client has High Risk rating AND Active status (all LOBs)',
    required: true,
    example: 'True'
  },
  {
    fieldName: 'population_result',
    displayName: 'Population(s)',
    dataType: 'Enumerated String',
    source: 'Derived from population calculations',
    description: 'Summary of population inclusion results',
    validValues: 'Both, 312, CAM, Excluded',
    businessRules: 'Both = in both populations, 312 = only 312, CAM = only CAM, Excluded = in neither population',
    required: true,
    example: 'Both'
  }
];

/**
 * Business Rules Sections
 * Organized by logical groupings
 */
export const businessRulesSections: BusinessRuleSection[] = [
  {
    title: 'Active Status Requirement',
    rules: [
      'All population identification logic requires Client_Status = "Active"',
      'Closed clients are automatically excluded from both 312 and CAM populations',
      'Status changes from Active to Closed immediately remove clients from scope',
      'This is a prerequisite check performed before any other criteria evaluation'
    ]
  },
  {
    title: 'GB/GM 312 Population Criteria (OR Logic)',
    rules: [
      'Client meets ANY of the following: Risk Rating = High/Elevated/Standard',
      'Client has Global DGA Due Date (High Risk clients)',
      'Client Family Anniversary Date within 170-180 days (non-High Risk)',
      'Small Business LOB: triggered 95 days from refresh anniversary',
      'Client has 312 Flag in AWARE',
      'Client is manually identified for 312 review'
    ]
  },
  {
    title: 'PB/ML 312 Population Criteria (AND Logic)',
    rules: [
      'Client refresh is due within 180 calendar days (Days_to_Refresh ≤ 180)',
      'Client has PVT code from CRA (Has_PVT_Code = True)',
      'Both conditions must be met for inclusion'
    ]
  },
  {
    title: 'CAM Population Criteria (Simple Logic)',
    rules: [
      'Risk Rating = "High" (at time of case creation)',
      'Client Status = "Active"',
      'Applies to all LOBs with same logic'
    ]
  },
  {
    title: 'Timing-Based Triggers',
    rules: [
      'PB/ML/CI High Risk: 180-day refresh cycle for 312 population',
      'GB/GM: Global DGA due dates for High Risk clients',
      'Consumer: 120-day refresh cycle',
      'Small Business: 95 days before refresh anniversary',
      'GB/GM Family Anniversary: 170-180 day window for Elevated/Standard'
    ]
  },
  {
    title: 'Data Refresh and Currency',
    rules: [
      'Population identification runs daily',
      'Risk ratings must be current at time of evaluation',
      'Status changes are reflected in real-time',
      'Date calculations use current system date',
      'FLU system data synchronized nightly'
    ]
  }
];

/**
 * Data Source Systems
 * External systems that provide data to the Population Identification Engine
 */
export const dataSourceSystems: DataSourceSystem[] = [
  {
    name: 'Cesium',
    description: 'Global Banking / Global Markets client data, risk ratings, and relationship information',
    color: 'primary'
  },
  {
    name: 'CMT',
    description: 'Private Banking client management tool with wealth management data',
    color: 'secondary'
  },
  {
    name: 'CP (Client Platform)',
    description: 'Merrill Lynch client platform for investment and advisory relationships',
    color: 'info'
  },
  {
    name: 'WCC',
    description: 'Consumer and Corporate & Institutional banking client records',
    color: 'warning'
  },
  {
    name: 'AWARE',
    description: 'AML risk rating system, 312 flags, and compliance monitoring data',
    color: 'error'
  },
  {
    name: 'CRA',
    description: 'Customer Risk Assessment system providing PVT codes and risk indicators',
    color: 'success'
  }
];
