// Icon mapping utility for lucide-react to Material-UI icons migration
import {
  // Common icons
  CheckCircle as CheckCircleMUI,
  Cancel as CancelMUI,
  Warning as WarningMUI,
  Info as InfoMUI,
  Description as DescriptionMUI,
  PlayArrow as PlayArrowMUI,
  CalendarToday as CalendarTodayMUI,
  Security as SecurityMUI,
  TrendingUp as TrendingUpMUI,
  Lock as LockMUI,
  Bolt as BoltMUI,
  Storage as StorageMUI,
  ArrowForward as ArrowForwardMUI,
  ArrowDownward as ArrowDownwardMUI,
  People as PeopleMUI,
  ArrowUpward as ArrowUpwardMUI,
  ArrowBack as ArrowBackMUI,
  AttachMoney as AttachMoneyMUI,
  Activity as ActivityMUI,
  Message as MessageMUI,
  Schedule as ScheduleMUI,
  Person as PersonMUI,
  Business as BusinessMUI,
  AccountCircle as AccountCircleMUI,
  FilterList as FilterListMUI,
  Download as DownloadMUI,
  Add as AddMUI,
  Refresh as RefreshMUI,
  Settings as SettingsMUI,
  BarChart as BarChartMUI,
  PieChart as PieChartMUI,
  TableChart as TableChartMUI,
  FileDownload as FileDownloadMUI,
  RotateLeft as RotateLeftMUI,
  Database as DatabaseMUI,
  Notifications as NotificationsMUI,
  Email as EmailMUI,
  Send as SendMUI,
  Visibility as VisibilityMUI,
  VisibilityOff as VisibilityOffMUI,
  Save as SaveMUI,
  Close as CloseMUI,
  Shield as ShieldMUI,
  PersonAdd as PersonAddMUI,
  Search as SearchMUI,
  Key as KeyMUI,
  PersonOutline as PersonOutlineMUI,
  Block as BlockMUI,
  CheckCircleOutline as CheckCircleOutlineMUI,
} from '@mui/icons-material';

// Export convenient names matching lucide-react conventions
export const CheckCircle2 = CheckCircleMUI;
export const XCircle = CancelMUI;
export const AlertCircle = WarningMUI;
export const AlertTriangle = WarningMUI;
export const FileText = DescriptionMUI;
export const PlayCircle = PlayArrowMUI;
export const Calendar = CalendarTodayMUI;
export const Shield = SecurityMUI;
export const TrendingUp = TrendingUpMUI;
export const Lock = LockMUI;
export const Zap = BoltMUI;
export const Database = DatabaseMUI;
export const ArrowRight = ArrowForwardMUI;
export const ArrowDown = ArrowDownwardMUI;
export const Users = PeopleMUI;
export const ArrowUp = ArrowUpwardMUI;
export const ArrowLeft = ArrowBackMUI;
export const DollarSign = AttachMoneyMUI;
export const Activity = ActivityMUI;
export const MessageSquare = MessageMUI;
export const Clock = ScheduleMUI;
export const User = PersonMUI;
export const CheckCircle = CheckCircleMUI;
export const Building2 = BusinessMUI;
export const UserCircle = AccountCircleMUI;
export const Filter = FilterListMUI;
export const Download = DownloadMUI;
export const Plus = AddMUI;
export const RefreshCw = RefreshMUI;
export const Settings = SettingsMUI;
export const BarChart3 = BarChartMUI;
export const PieChart = PieChartMUI;
export const FileSpreadsheet = TableChartMUI;
export const FileDown = FileDownloadMUI;
export const RotateCcw = RotateLeftMUI;
export const Bell = NotificationsMUI;
export const Mail = EmailMUI;
export const Send = SendMUI;
export const Eye = VisibilityMUI;
export const EyeOff = VisibilityOffMUI;
export const Save = SaveMUI;
export const X = CloseMUI;
export const Info = InfoMUI;
export const UserPlus = PersonAddMUI;
export const Search = SearchMUI;
export const Key = KeyMUI;
export const UserCheck = PersonOutlineMUI;
export const Ban = BlockMUI;
export const CheckCircleOutline = CheckCircleOutlineMUI;

// Additional icon exports
export {
  CheckCircleMUI,
  CancelMUI,
  WarningMUI,
  InfoMUI,
  DescriptionMUI,
  PlayArrowMUI,
  CalendarTodayMUI,
  SecurityMUI,
  TrendingUpMUI,
  LockMUI,
  BoltMUI,
  StorageMUI,
  ArrowForwardMUI,
  ArrowDownwardMUI,
  PeopleMUI,
  ArrowUpwardMUI,
  ArrowBackMUI,
  AttachMoneyMUI,
  ActivityMUI,
  MessageMUI,
  ScheduleMUI,
  PersonMUI,
  BusinessMUI,
  AccountCircleMUI,
  FilterListMUI,
  DownloadMUI,
  AddMUI,
  RefreshMUI,
  SettingsMUI,
  BarChartMUI,
  PieChartMUI,
  TableChartMUI,
  FileDownloadMUI,
  RotateLeftMUI,
  DatabaseMUI,
  NotificationsMUI,
  EmailMUI,
  SendMUI,
  VisibilityMUI,
  VisibilityOffMUI,
  SaveMUI,
  CloseMUI,
  ShieldMUI,
  PersonAddMUI,
  SearchMUI,
  KeyMUI,
  PersonOutlineMUI,
  BlockMUI,
  CheckCircleOutlineMUI,
};
