import { createTheme } from '@mui/material/styles';

// Bank of America brand colors
export const theme = createTheme({
  palette: {
    primary: {
      main: '#0047AB', // Bank of America blue
      light: '#4A7BC8',
      dark: '#003380',
      contrastText: '#ffffff',
    },
    secondary: {
      main: '#CC0000', // Bank of America red
      light: '#E63946',
      dark: '#990000',
      contrastText: '#ffffff',
    },
    error: {
      main: '#D32F2F',
      light: '#EF5350',
      dark: '#C62828',
    },
    warning: {
      main: '#ED6C02',
      light: '#FF9800',
      dark: '#E65100',
    },
    info: {
      main: '#0288D1',
      light: '#03A9F4',
      dark: '#01579B',
    },
    success: {
      main: '#2E7D32',
      light: '#4CAF50',
      dark: '#1B5E20',
    },
    background: {
      default: '#F5F7FA',
      paper: '#FFFFFF',
    },
    text: {
      primary: '#1A1A1A',
      secondary: '#5F6368',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontSize: '2.5rem',
      fontWeight: 600,
    },
    h2: {
      fontSize: '2rem',
      fontWeight: 600,
    },
    h3: {
      fontSize: '1.75rem',
      fontWeight: 600,
    },
    h4: {
      fontSize: '1.5rem',
      fontWeight: 600,
    },
    h5: {
      fontSize: '1.25rem',
      fontWeight: 600,
    },
    h6: {
      fontSize: '1rem',
      fontWeight: 600,
    },
    body1: {
      fontSize: '1rem',
    },
    body2: {
      fontSize: '0.875rem',
    },
  },
  shape: {
    borderRadius: 4,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 500,
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 500,
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          boxShadow: '0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)',
        },
      },
    },
  },
});

// Extend theme with custom color shades
declare module '@mui/material/styles' {
  interface Palette {
    primary: Palette['primary'] & {
      lighter?: string;
    };
    secondary: Palette['secondary'] & {
      lighter?: string;
    };
    error: Palette['error'] & {
      lighter?: string;
    };
    warning: Palette['warning'] & {
      lighter?: string;
    };
    info: Palette['info'] & {
      lighter?: string;
    };
    success: Palette['success'] & {
      lighter?: string;
    };
  }
  interface PaletteOptions {
    primary?: PaletteOptions['primary'] & {
      lighter?: string;
    };
    secondary?: PaletteOptions['secondary'] & {
      lighter?: string;
    };
    error?: PaletteOptions['error'] & {
      lighter?: string;
    };
    warning?: PaletteOptions['warning'] & {
      lighter?: string;
    };
    info?: PaletteOptions['info'] & {
      lighter?: string;
    };
    success?: PaletteOptions['success'] & {
      lighter?: string;
    };
  }
}

// Add lighter shades to the theme
theme.palette.primary.lighter = '#E3F2FD';
theme.palette.secondary.lighter = '#FFEBEE';
theme.palette.error.lighter = '#FFEBEE';
theme.palette.warning.lighter = '#FFF3E0';
theme.palette.info.lighter = '#E1F5FE';
theme.palette.success.lighter = '#E8F5E9';