# AKRIT Data Extract - Testing Guide

## 🧪 Complete Testing Checklist

### Pre-Test Setup

**Login Credentials**: Any user role (Analyst, Manager, Administrator, Sales Owner)  
**Test Duration**: ~15 minutes  
**Browser**: Chrome, Firefox, or Edge recommended

---

## Test 1: Basic Navigation ✅

### Objective
Verify users can access the AKRIT Data Extract feature

### Steps
1. Log into CAM Platform
2. Click **"Reports"** in the left sidebar
3. Verify 4 tabs visible:
   - Generated Reports
   - AKRIT Extract
   - Templates
   - Analytics
4. Click **"AKRIT Extract"** tab

### Expected Results
- ✅ Tab opens without errors
- ✅ Two-column layout appears
- ✅ Left panel shows filters
- ✅ Right panel shows preview box
- ✅ "Export X Cases to AKRIT" button visible

### Pass Criteria
All UI elements load correctly, no console errors

---

## Test 2: Default State Validation ✅

### Objective
Verify default filter settings and case count

### Steps
1. Open AKRIT Extract tab
2. Check default filter states
3. Note the case count in preview box

### Expected Results
- ✅ **From Date**: Not set (blank)
- ✅ **To Date**: Not set (blank)
- ✅ **Export Format**: CSV selected (blue button)
- ✅ **312 Review**: Checked ✓
- ✅ **CAM Review**: Checked ✓
- ✅ **All LOBs**: Unchecked
- ✅ **312 Flag Filter**: Unchecked
- ✅ **Employee Flag Filter**: Unchecked
- ✅ **Case Count**: Shows total number of mock cases (e.g., "23 cases")
- ✅ **Preview shows**: "Both" for case types, "All" for LOBs, "All Dates"

### Pass Criteria
Default state matches expected values, case count > 0

---

## Test 3: Date Range Filter ✅

### Objective
Test date filtering functionality

### Steps
1. Click **"From Date"** calendar button
2. Select **October 1, 2025**
3. Click **"To Date"** calendar button
4. Select **October 31, 2025**
5. Observe case count update
6. Check preview box shows date range

### Expected Results
- ✅ Calendar picker opens on button click
- ✅ Selected dates display on buttons
- ✅ Case count updates (likely decreases)
- ✅ Preview shows: "10/1/2025 - 10/31/2025"
- ✅ Only cases within date range counted

### Pass Criteria
Dates set correctly, case count updates, preview reflects changes

---

## Test 4: Export Format Selection ✅

### Objective
Test format toggle between CSV and Excel

### Steps
1. Default format is CSV (blue button)
2. Click **"Excel (.xlsx)"** button
3. Verify Excel button turns blue
4. Click **"CSV (Recommended)"** button
5. Verify CSV button turns blue again

### Expected Results
- ✅ Only one button highlighted at a time
- ✅ Clicking button changes selection
- ✅ Preview shows correct format (CSV or EXCEL)
- ✅ Button states toggle correctly

### Pass Criteria
Format selection works, preview updates

---

## Test 5: Case Type Filtering ✅

### Objective
Test filtering by case type (312 vs CAM)

### Steps
1. **Test A**: Uncheck **"CAM Review Cases"**
   - Observe case count
   - Preview should show "312 Only"
2. **Test B**: Check CAM Review, uncheck **"312 Review Cases"**
   - Observe case count
   - Preview should show "CAM Only"
3. **Test C**: Check both
   - Preview should show "Both"
4. **Test D**: Uncheck both
   - Case count should be 0
   - Export button should be disabled

### Expected Results
- ✅ Case count adjusts based on selection
- ✅ Preview text updates correctly
- ✅ Export button disables when count = 0
- ✅ Error message appears: "No cases match the selected filters"

### Pass Criteria
All case type combinations work correctly

---

## Test 6: Line of Business Filtering ✅

### Objective
Test LOB checkbox filters

### Steps
1. Check **"GB/GM - Global Banking / Markets"** only
   - Note case count decrease
   - Preview shows "GB/GM"
2. Check **"PB - Private Bank"** also
   - Case count increases
   - Preview shows "GB/GM, PB"
3. Check multiple LOBs
   - Preview shows comma-separated list
4. Uncheck all LOBs
   - Preview shows "All"
   - Case count returns to original

### Expected Results
- ✅ Checking LOB reduces case count to only those LOBs
- ✅ Multiple LOBs combine with OR logic
- ✅ Preview accurately lists selected LOBs
- ✅ Unchecking all = include all LOBs

### Pass Criteria
LOB filtering works correctly, counts accurate

---

## Test 7: 312 Flag Filter ✅

### Objective
Test filtering by 312 Client Flag

### Steps
1. Check **"312 Client Flag = Yes only"**
2. Observe case count (should decrease)
3. Uncheck the filter
4. Case count should return to previous value

### Expected Results
- ✅ Checking filter reduces count
- ✅ Only cases with is312Case = true included
- ✅ Unchecking restores all cases
- ✅ Works in combination with other filters

### Pass Criteria
312 flag filter works correctly

---

## Test 8: Employee Flag Filter ✅

### Objective
Test filtering by Employee/Affiliate flag

### Steps
1. Check **"BAC Affiliate/Employee Flag = Yes only"**
2. Observe case count (should decrease significantly)
3. Uncheck the filter
4. Case count should return to previous value

### Expected Results
- ✅ Checking filter reduces count
- ✅ Only cases with clientData.isEmployee = true included
- ✅ Unchecking restores all cases
- ✅ Works in combination with other filters

### Pass Criteria
Employee flag filter works correctly

---

## Test 9: Combined Filters ✅

### Objective
Test multiple filters working together

### Steps
1. Set **From Date**: October 1, 2025
2. Set **To Date**: October 31, 2025
3. Check **"312 Review Cases"** only
4. Check **"GB/GM"** only
5. Check **"312 Client Flag = Yes only"**
6. Observe final case count
7. Verify preview shows all selections

### Expected Results
- ✅ Case count is cumulative (AND logic)
- ✅ All filters apply simultaneously
- ✅ Preview box shows:
  - Correct case count
  - Case Types: "312 Only"
  - LOBs: "GB/GM"
  - Date Range: "10/1/2025 - 10/31/2025"
  - Format: "CSV"

### Pass Criteria
All filters work together correctly using AND logic

---

## Test 10: Reset Filters ✅

### Objective
Test the Reset Filters functionality

### Steps
1. Set multiple filters:
   - Date range: Oct 1-31
   - Format: Excel
   - Uncheck CAM Review
   - Check PB LOB
   - Check 312 Flag
2. Click **"Reset Filters"** button
3. Verify all filters return to defaults

### Expected Results
- ✅ Toast notification appears: "Filters Reset"
- ✅ Date range clears (both dates blank)
- ✅ Format returns to CSV
- ✅ Both case types checked
- ✅ All LOBs unchecked
- ✅ All additional filters unchecked
- ✅ Case count returns to total

### Pass Criteria
All filters reset to defaults, toast appears

---

## Test 11: CSV Export ✅

### Objective
Test exporting data to CSV format

### Steps
1. Reset all filters
2. Ensure **CSV** format selected
3. Click **"Export X Cases to AKRIT"** button
4. Wait for download
5. Open downloaded file

### Expected Results
- ✅ Toast notification: "Export Complete - Successfully exported X cases..."
- ✅ File downloads with name: `AKRIT_Extract_2025-10-27.csv`
- ✅ File opens in Excel or text editor
- ✅ **Header row** contains:
  ```
  Case ID,Client ID,GCI,CoPer ID,Line of Business,312 Client Flag,BAC Affiliate/Employee Flag
  ```
- ✅ **Data rows** contain case data
- ✅ Number of rows = case count + 1 (header)
- ✅ All 7 fields present in each row
- ✅ No blank rows
- ✅ Commas properly escaped

### Pass Criteria
CSV file downloads and contains correct data

---

## Test 12: Excel Export ✅

### Objective
Test exporting data to Excel format

### Steps
1. Select **Excel (.xlsx)** format
2. Keep filters at default
3. Click **"Export X Cases to AKRIT"** button
4. Wait for download
5. Open downloaded file

### Expected Results
- ✅ Toast notification appears
- ✅ File downloads with name: `AKRIT_Extract_2025-10-27.xlsx`
- ✅ File opens in Excel
- ✅ Same 7 columns as CSV
- ✅ Data is tab-delimited
- ✅ All case data present

### Pass Criteria
Excel file downloads and contains correct data

---

## Test 13: Zero Cases Export ✅

### Objective
Test behavior when no cases match filters

### Steps
1. Set very restrictive filters:
   - Date: Future date range (2026)
   - Check only PB LOB
   - Check 312 Flag = Yes
   - Check Employee Flag = Yes
2. Observe preview box
3. Try to click export button

### Expected Results
- ✅ Preview shows: "**0** cases will be exported"
- ✅ Export button is **disabled** (grayed out)
- ✅ Red error text below button: "No cases match the selected filters"
- ✅ If button somehow clicked, toast error: "No cases to export"

### Pass Criteria
System prevents exporting zero cases, shows clear error

---

## Test 14: Data Validation ✅

### Objective
Verify exported data matches expected format

### Steps
1. Export all cases to CSV
2. Open file in Excel
3. Validate each field:

**Column 1 - Case ID**:
- ✅ Format: `312-2025-001` or `CAM-2025-001`
- ✅ No blank values
- ✅ All unique

**Column 2 - Client ID**:
- ✅ Format: `CLI-XXXXXX` or "N/A"
- ✅ Consistent with case data

**Column 3 - GCI**:
- ✅ Format: `GCI-XXXXXX`
- ✅ No blank values (required field)

**Column 4 - CoPer ID**:
- ✅ Format: `CPR-XXXXX` or "N/A"
- ✅ "N/A" allowed for clients without CoPer

**Column 5 - Line of Business**:
- ✅ Valid values: GB/GM, PB, ML, Consumer, CI, or N/A
- ✅ No invalid values

**Column 6 - 312 Client Flag**:
- ✅ Values: "Yes" or "No" only
- ✅ No blank values
- ✅ "Yes" for all 312 cases

**Column 7 - BAC Affiliate/Employee Flag**:
- ✅ Values: "Yes" or "No" only
- ✅ No blank values

### Pass Criteria
All data validates correctly, no invalid values

---

## Test 15: Filtered Export Validation ✅

### Objective
Verify filtered export contains only matching cases

### Steps
1. Set filter: **312 Client Flag = Yes only**
2. Note case count in preview
3. Export to CSV
4. Open file
5. Count rows (excluding header)
6. Verify all rows have "Yes" in Column 6

### Expected Results
- ✅ Row count = preview case count
- ✅ All rows have "Yes" in 312 Client Flag column
- ✅ No "No" values in Column 6

### Pass Criteria
Export matches filter criteria exactly

---

## Test 16: Date Range Export Validation ✅

### Objective
Verify date filtering works correctly

### Steps
1. Set **From Date**: October 15, 2025
2. Set **To Date**: October 20, 2025
3. Note case count
4. Export to CSV
5. Cross-reference case IDs with mock data
6. Verify all cases were created within date range

### Expected Results
- ✅ Only cases created between Oct 15-20 included
- ✅ Row count matches preview
- ✅ No cases outside date range

### Pass Criteria
Date filtering accurately excludes out-of-range cases

---

## Test 17: Large Export Performance ✅

### Objective
Test export performance with all cases

### Steps
1. Reset all filters
2. Ensure all cases selected (max count)
3. Start timer
4. Click Export
5. Measure time until download completes
6. Measure time to open file

### Expected Results
- ✅ Export starts within 500ms
- ✅ File downloads within 2 seconds
- ✅ Toast appears immediately
- ✅ File opens quickly in Excel
- ✅ No browser freezing

### Pass Criteria
Export completes in < 2 seconds for typical dataset

---

## Test 18: Multiple Exports ✅

### Objective
Test consecutive exports

### Steps
1. Export with Filter A (e.g., 312 only)
2. Change to Filter B (e.g., CAM only)
3. Export again
4. Check both files downloaded

### Expected Results
- ✅ Both files download successfully
- ✅ Files have different case counts
- ✅ Files contain different data
- ✅ No data corruption
- ✅ Unique filenames (different times)

### Pass Criteria
Multiple exports work without issues

---

## Test 19: Mobile Responsiveness ✅

### Objective
Test UI on mobile/tablet devices

### Steps
1. Open browser DevTools (F12)
2. Toggle device toolbar
3. Select iPhone or tablet size
4. Navigate to AKRIT Extract tab
5. Test all features

### Expected Results
- ✅ Layout adapts to smaller screen
- ✅ Filters stack vertically
- ✅ All buttons accessible
- ✅ Preview box readable
- ✅ Export button works
- ✅ Date pickers work on mobile

### Pass Criteria
Feature is fully functional on mobile devices

---

## Test 20: Cross-Browser Testing ✅

### Objective
Verify compatibility across browsers

### Browsers to Test
- Chrome
- Firefox
- Edge
- Safari (if available)

### Steps
1. Open CAM Platform in each browser
2. Navigate to AKRIT Extract
3. Test basic export functionality
4. Verify file downloads

### Expected Results
- ✅ UI renders correctly in all browsers
- ✅ Filters work in all browsers
- ✅ Exports download successfully
- ✅ No JavaScript errors in console

### Pass Criteria
Feature works in all major browsers

---

## 🐛 Common Issues & Solutions

### Issue 1: Case Count Doesn't Update
**Symptoms**: Changing filters doesn't change case count  
**Cause**: React state not updating  
**Solution**: Check browser console, refresh page

### Issue 2: Export Button Disabled
**Symptoms**: Can't click export even with cases  
**Cause**: filteredCaseCount = 0 due to filter logic  
**Solution**: Reset filters, adjust criteria

### Issue 3: File Won't Download
**Symptoms**: Click export but no download  
**Cause**: Browser blocking downloads  
**Solution**: Check browser download permissions, allow pop-ups

### Issue 4: CSV Opens with Weird Characters
**Symptoms**: Special characters show as �  
**Cause**: Encoding issue  
**Solution**: Open in Excel using Data → Import with UTF-8

### Issue 5: Excel File Won't Open
**Symptoms**: Excel shows error opening file  
**Cause**: File is TSV not true XLSX  
**Solution**: This is expected - file opens as tab-delimited text

---

## ✅ Test Summary Template

After completing all tests, fill out:

```
AKRIT DATA EXTRACT - TEST RESULTS

Date: _____________
Tester: _____________
Browser: _____________
Device: _____________

Test Results:
☐ Test 1: Navigation - PASS/FAIL
☐ Test 2: Default State - PASS/FAIL
☐ Test 3: Date Range - PASS/FAIL
☐ Test 4: Format Selection - PASS/FAIL
☐ Test 5: Case Type - PASS/FAIL
☐ Test 6: LOB Filter - PASS/FAIL
☐ Test 7: 312 Flag - PASS/FAIL
☐ Test 8: Employee Flag - PASS/FAIL
☐ Test 9: Combined Filters - PASS/FAIL
☐ Test 10: Reset Filters - PASS/FAIL
☐ Test 11: CSV Export - PASS/FAIL
☐ Test 12: Excel Export - PASS/FAIL
☐ Test 13: Zero Cases - PASS/FAIL
☐ Test 14: Data Validation - PASS/FAIL
☐ Test 15: Filtered Export - PASS/FAIL
☐ Test 16: Date Range Export - PASS/FAIL
☐ Test 17: Performance - PASS/FAIL
☐ Test 18: Multiple Exports - PASS/FAIL
☐ Test 19: Mobile - PASS/FAIL
☐ Test 20: Cross-Browser - PASS/FAIL

Issues Found:
1. ___________________________
2. ___________________________
3. ___________________________

Overall Status: PASS / FAIL / PARTIAL

Notes:
_________________________________
_________________________________
```

---

## 📊 Acceptance Criteria

### Must Pass (Critical)
- ✅ All 20 tests pass
- ✅ No console errors
- ✅ CSV export downloads correctly
- ✅ Exported data validates
- ✅ Filters work correctly
- ✅ Reset button works

### Should Pass (Important)
- ✅ Excel export works
- ✅ Mobile responsive
- ✅ Toast notifications appear
- ✅ Performance is acceptable
- ✅ Cross-browser compatible

### Nice to Have
- ✅ Smooth animations
- ✅ Helpful error messages
- ✅ Intuitive UI

---

## 🚀 Production Readiness Checklist

Before deploying to production:

- [ ] All 20 tests passed
- [ ] Tested with real production data
- [ ] Performance validated with 10,000+ cases
- [ ] Security review completed
- [ ] Data classification verified
- [ ] Audit logging implemented
- [ ] User documentation complete
- [ ] Training materials ready
- [ ] Support team briefed
- [ ] Rollback plan in place

---

**Testing Guide Version**: 1.0  
**Last Updated**: October 27, 2025  
**Next Review**: After first production use
