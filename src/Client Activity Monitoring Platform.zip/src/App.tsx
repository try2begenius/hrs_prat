import { useState } from 'react';
import { SidebarProvider, Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter } from "./components/ui/sidebar";
import { Avatar, AvatarFallback } from "./components/ui/avatar";
import { Badge } from "./components/ui/badge";
import { Button } from "./components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "./components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select";
import { Toaster } from './components/ui/sonner';
import { LayoutDashboard, FileText, Users, BarChart3, Bell, Settings, LogOut, ChevronDown, Shield, Workflow, KeyRound, UserCircle, Briefcase, GitBranch } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { CaseWorklist } from './components/CaseWorklist';
import { IndividualWorklist } from './components/IndividualWorklist';
import { SalesOwnerWorklist } from './components/SalesOwnerWorklist';
import { CaseDetails } from './components/CaseDetails';
import { CaseDetailsEnhanced } from './components/CaseDetailsEnhanced';
import { PopulationIdentification } from './components/PopulationIdentification';
import { CaseCreationLogic } from './components/CaseCreationLogic';
import { Reports } from './components/Reports';
import { Notifications } from './components/Notifications';
import { SystemIntegrations } from './components/SystemIntegrations';
import { RolesEntitlements } from './components/RolesEntitlements';
import { WorkflowDiagram } from './components/WorkflowDiagram';
import { mockUsers, UserAccess, getPermissionsForRole } from './data/rolesEntitlementsMockData';
import { mockCases } from './data/enhancedMockData';

type Page = 'dashboard' | 'my-cases' | 'worklist' | 'case-details' | 'populations' | 'case-creation' | 'reports' | 'notifications' | 'integrations' | 'roles' | 'workflow-diagram';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [selectedCaseId, setSelectedCaseId] = useState<string>('');
  const [currentUser, setCurrentUser] = useState<UserAccess>(mockUsers[0]); // Default to Sarah Mitchell (Manager)

  const permissions = getPermissionsForRole(currentUser.role);

  const handleViewCase = (caseId: string) => {
    setSelectedCaseId(caseId);
    setCurrentPage('case-details');
  };

  const handleBackToWorklist = () => {
    setCurrentPage('worklist');
    setSelectedCaseId('');
  };

  const handleUserChange = (userId: string) => {
    const user = mockUsers.find(u => u.id === userId);
    if (user) {
      setCurrentUser(user);
      // Reset to dashboard when switching users
      setCurrentPage('dashboard');
    }
  };

  const handleCaseAssigned = (caseId: string, assignee: string) => {
    // In a real app, this would call an API to update the case
    // For now, we'll just update the mock data in memory
    const caseToUpdate = mockCases.find(c => c.id === caseId);
    if (caseToUpdate) {
      caseToUpdate.assignedTo = assignee;
      // If case was unassigned, change status to In Progress
      if (caseToUpdate.status === 'Unassigned') {
        caseToUpdate.status = 'In Progress';
      }
    }
  };

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', value: 'dashboard' as Page, permission: permissions.viewDashboard },
    { icon: Briefcase, label: 'My Cases', value: 'my-cases' as Page, permission: permissions.viewWorklist },
    { icon: FileText, label: 'Case Worklist', value: 'worklist' as Page, permission: permissions.viewWorklist },
    { icon: Users, label: 'Population ID', value: 'populations' as Page, permission: permissions.viewDashboard },
    { icon: Workflow, label: 'Case Creation', value: 'case-creation' as Page, permission: permissions.viewDashboard },
    { icon: BarChart3, label: 'Reports', value: 'reports' as Page, permission: permissions.viewDashboard },
    { icon: Bell, label: 'Notifications', value: 'notifications' as Page, badge: 3, permission: true },
    { icon: GitBranch, label: 'Workflow Diagram', value: 'workflow-diagram' as Page, permission: true },
  ];

  const adminMenuItems = [
    { icon: Settings, label: 'Integrations', value: 'integrations' as Page, permission: currentUser.role === 'Central Team Manager' },
    { icon: KeyRound, label: 'Roles & Entitlements', value: 'roles' as Page, permission: currentUser.role === 'Central Team Manager' },
  ];

  // Filter menu items based on permissions
  const visibleMenuItems = menuItems.filter(item => item.permission);
  const visibleAdminItems = adminMenuItems.filter(item => item.permission);

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <Sidebar>
          {/* Bank of America Logo - Prominent white background area */}
          <div className="bg-white px-6 h-[70px] flex items-center border-b border-border">
            <img 
              src="https://www2.bac-assets.com//homepage/spa-assets/images/logo-bofa-flagscape-18ad22ccaf518c47d77b.svg" 
              alt="Bank of America" 
              className="h-10 w-auto"
            />
          </div>

          <SidebarHeader className="p-4">
            {/* CAM Platform Title */}
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-sidebar-foreground">CAM Platform</div>
                <div className="text-xs text-sidebar-foreground/60">AML Compliance</div>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Navigation</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {visibleMenuItems.map((item) => (
                    <SidebarMenuItem key={item.value}>
                      <SidebarMenuButton
                        onClick={() => setCurrentPage(item.value)}
                        isActive={currentPage === item.value}
                      >
                        <item.icon className="h-4 w-4" />
                        <span>{item.label}</span>
                        {item.badge && (
                          <Badge variant="default" className="ml-auto">
                            {item.badge}
                          </Badge>
                        )}
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {visibleAdminItems.length > 0 && (
              <SidebarGroup>
                <SidebarGroupLabel>Administration</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {visibleAdminItems.map((item) => (
                      <SidebarMenuItem key={item.value}>
                        <SidebarMenuButton
                          onClick={() => setCurrentPage(item.value)}
                          isActive={currentPage === item.value}
                        >
                          <item.icon className="h-4 w-4" />
                          <span>{item.label}</span>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            )}

            <SidebarGroup>
              <SidebarGroupLabel>Settings</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <Settings className="h-4 w-4" />
                      <span>Configuration</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-border p-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="w-full justify-start">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{currentUser.avatar}</AvatarFallback>
                  </Avatar>
                  <div className="ml-2 flex-1 text-left">
                    <div className="text-sm">{currentUser.name}</div>
                    <div className="text-xs text-muted-foreground">{currentUser.role}</div>
                  </div>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Profile Settings</DropdownMenuItem>
                <DropdownMenuItem>Preferences</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 overflow-auto bg-background">
          <div className="border-b border-border bg-card px-6 h-[70px] sticky top-0 z-10 backdrop-blur-sm bg-card/95">
            <div className="flex items-center justify-end max-w-7xl mx-auto h-full">
              <div className="flex items-center gap-4">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <div className="h-2 w-2 rounded-full bg-green-600 mr-2"></div>
                  All Systems Operational
                </Badge>
                
                {/* User Switcher */}
                <div className="flex items-center gap-3 border-l pl-4">
                  <UserCircle className="h-5 w-5 text-muted-foreground" />
                  <Select value={currentUser.id} onValueChange={handleUserChange}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback className="text-xs">{currentUser.avatar}</AvatarFallback>
                          </Avatar>
                          <span className="text-sm">{currentUser.name}</span>
                        </div>
                      </SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      {mockUsers.filter(u => u.status === 'Active').map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-xs">{user.avatar}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="text-sm font-medium">{user.name}</div>
                              <div className="text-xs text-muted-foreground">{user.role}</div>
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
          <div className="container mx-auto p-6 max-w-7xl">
            {currentPage === 'dashboard' && <Dashboard currentUser={currentUser} />}
            {currentPage === 'my-cases' && (
              currentUser.role === 'Sales Owner' ? (
                <SalesOwnerWorklist 
                  onViewCase={handleViewCase} 
                  currentUser={currentUser}
                />
              ) : (
                <IndividualWorklist 
                  onViewCase={handleViewCase} 
                  currentUser={currentUser}
                  onCaseAssigned={handleCaseAssigned}
                />
              )
            )}
            {currentPage === 'worklist' && (
              <CaseWorklist 
                onViewCase={handleViewCase} 
                currentUser={currentUser} 
                onCaseAssigned={handleCaseAssigned}
              />
            )}
            {currentPage === 'case-details' && (
              <CaseDetailsEnhanced caseId={selectedCaseId} onBack={handleBackToWorklist} currentUser={currentUser} />
            )}
            {currentPage === 'populations' && <PopulationIdentification />}
            {currentPage === 'case-creation' && <CaseCreationLogic />}
            {currentPage === 'reports' && <Reports currentUser={currentUser} />}
            {currentPage === 'notifications' && <Notifications currentUser={currentUser} />}
            {currentPage === 'integrations' && <SystemIntegrations />}
            {currentPage === 'roles' && <RolesEntitlements />}
            {currentPage === 'workflow-diagram' && <WorkflowDiagram />}
          </div>
          <Toaster />
        </main>
      </div>
    </SidebarProvider>
  );
}
