# CAM 312 Case Status Flow Diagram

## Complete Case Lifecycle Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CASE CREATION                                │
│                                                                      │
│  ┌──────────────┐                    ┌──────────────┐              │
│  │   System     │─────Auto Close────▶│   COMPLETE   │              │
│  │  Evaluates   │    (Low Risk)      │ (Auto-Closed)│              │
│  │              │                    └──────────────┘              │
│  └──────────────┘                                                   │
│         │                                                            │
│         │ Requires                                                   │
│         │ Manual Review                                              │
│         ▼                                                            │
│  ┌──────────────┐                                                   │
│  │  UNASSIGNED  │                                                   │
│  │ (Workbasket) │                                                   │
│  └──────────────┘                                                   │
└─────────────────────────────────────────────────────────────────────┘
         │
         │ Manager Assigns OR
         │ Analyst Self-Selects
         ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      CENTRAL TEAM REVIEW                             │
│                                                                      │
│  ┌──────────────┐                                                   │
│  │ IN PROGRESS  │                                                   │
│  │              │                                                   │
│  │ Analyst:     │                                                   │
│  │ - Reviews    │                                                   │
│  │ - Analyzes   │                                                   │
│  │ - Documents  │                                                   │
│  └──────────────┘                                                   │
│         │                                                            │
│         │                                                            │
│    ┌────┴────┐                                                      │
│    │         │                                                      │
│    │    Can Self-                                                   │
│    │  Disposition?                                                  │
│    │         │                                                      │
│  YES│        │NO (Need Sales Input)                                 │
│    │         │                                                      │
│    ▼         ▼                                                      │
└────┼─────────┼──────────────────────────────────────────────────────┘
     │         │
     │         └──────────┐
     │                    │
     │                    ▼
     │         ┌─────────────────────────────────────────────────────┐
     │         │              SALES REVIEW FLOW                       │
     │         │                                                      │
     │         │  ┌──────────────────┐                               │
     │         │  │ PENDING SALES    │                               │
     │         │  │     REVIEW       │                               │
     │         │  │                  │                               │
     │         │  │ Awaiting Sales   │                               │
     │         │  │ Owner to Open    │                               │
     │         │  └──────────────────┘                               │
     │         │           │                                          │
     │         │           │ Sales Opens                              │
     │         │           ▼                                          │
     │         │  ┌──────────────────┐                               │
     │         │  │  IN SALES        │                               │
     │         │  │    REVIEW        │                               │
     │         │  │                  │                               │
     │         │  │ Sales Owner:     │                               │
     │         │  │ - Reviews        │                               │
     │         │  │ - Provides       │                               │
     │         │  │   Feedback       │                               │
     │         │  └──────────────────┘                               │
     │         │           │                                          │
     │         │           │ Returns to Analyst                       │
     │         │           ▼                                          │
     │         │  ┌──────────────────┐                               │
     │         │  │ SALES REVIEW     │                               │
     │         │  │   COMPLETE       │                               │
     │         │  │                  │                               │
     │         │  │ Analyst Reviews  │                               │
     │         │  │ Sales Feedback   │                               │
     │         │  └──────────────────┘                               │
     │         │           │                                          │
     │         └───────────┼──────────────────────────────────────────┘
     │                     │
     │                     │ Both Paths
     │                     │ Lead to
     ▼                     ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        CASE COMPLETION                               │
│                                                                      │
│  ┌──────────────┐                                                   │
│  │   COMPLETE   │                                                   │
│  │              │                                                   │
│  │ Disposition: │                                                   │
│  │ - No Action  │                                                   │
│  │ - TRMS Filed │                                                   │
│  │ - Client     │                                                   │
│  │   Closed     │                                                   │
│  └──────────────┘                                                   │
│         │                                                            │
│         │ Quality Review                                             │
│         │ Finds Defect?                                              │
│         │                                                            │
│         ▼                                                            │
│  ┌──────────────┐                                                   │
│  │   DEFECT     │                                                   │
│  │ REMEDIATION  │                                                   │
│  │              │                                                   │
│  │ Analyst:     │                                                   │
│  │ - Corrects   │                                                   │
│  │ - Re-submits │                                                   │
│  └──────────────┘                                                   │
│         │                                                            │
│         │ Remediation                                                │
│         │ Complete                                                   │
│         ▼                                                            │
│  ┌──────────────┐                                                   │
│  │   COMPLETE   │                                                   │
│  │   (Final)    │                                                   │
│  │              │                                                   │
│  │ Original     │                                                   │
│  │ Date         │                                                   │
│  │ Preserved    │                                                   │
│  └──────────────┘                                                   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Actor-Based View

### Central Team Analyst Flow
```
[WORKBASKET] 
     │
     │ Self-Select
     ▼
[IN PROGRESS]
     │
     ├─────────────┐
     │             │
     │ Can         │ Need Sales
     │ Disposition │ Input
     │             │
     ▼             ▼
[COMPLETE]   [PENDING SALES]
                   │
                   ▼
             [SALES REVIEWING]
                   │
                   ▼
             [SALES COMPLETE]
                   │
                   ▼
              [COMPLETE]
```

### Sales Owner Flow
```
[PENDING SALES REVIEW]
     │
     │ Open Case
     ▼
[IN SALES REVIEW]
     │
     │ Provide Feedback
     │ and Return
     ▼
[SALES REVIEW COMPLETE]
     │
     │ (Returns to Analyst)
     ▼
```

### Manager Flow
```
[UNASSIGNED]
     │
     ├─────────┐
     │         │
     │ Assign  │ Auto-Close
     │         │
     ▼         ▼
[IN PROGRESS] [COMPLETE]
     │
     │ (Can work like Analyst)
     │
     ▼
[COMPLETE]
     │
     │ Quality Review
     │ Identifies Issue
     ▼
[DEFECT REMEDIATION]
     │
     │ Reassign to Analyst
     │ for Remediation
     ▼
[COMPLETE]
```

---

## Status Characteristics

| Status | Can Edit? | Next Actions | Duration | Actor |
|--------|-----------|--------------|----------|-------|
| **Unassigned** | No | Assign, Self-Select | Minimal | Manager, Analyst |
| **In Progress** | Yes | Review, Disposition, Route | Days-Weeks | Analyst |
| **Pending Sales Review** | No | Open Case | Hours-Days | Sales Owner |
| **In Sales Review** | Limited | Provide Feedback | Hours-Days | Sales Owner |
| **Sales Review Complete** | Yes | Final Disposition | Hours | Analyst |
| **Complete** | No | Reopen (if needed) | Permanent | View All |
| **Defect Remediation** | Yes | Correct, Re-submit | Days | Analyst |

---

## Color Coding (UI)

```
┌─────────────────────┬──────────────┬─────────────┐
│ Status              │ Color        │ Hex Code   │
├─────────────────────┼──────────────┼─────────────┤
│ Unassigned          │ Gray         │ #6B7280    │
│ In Progress         │ Amber        │ #F59E0B    │
│ Pending Sales       │ Blue         │ #3B82F6    │
│ In Sales Review     │ Purple       │ #8B5CF6    │
│ Sales Complete      │ Indigo       │ #6366F1    │
│ Complete            │ Green        │ #10B981    │
│ Defect Remediation  │ Red          │ #EF4444    │
└─────────────────────┴──────────────┴─────────────┘
```

---

## Time-Based Flow

### Typical Timeline (No Sales Review)
```
Day 0:  Case Created → Unassigned
Day 0:  Assigned → In Progress
Day 1-5: Analyst Review
Day 5:  Disposition → Complete

Total: 5 days
```

### Timeline with Sales Review
```
Day 0:  Case Created → Unassigned
Day 0:  Assigned → In Progress
Day 1-3: Analyst Review
Day 3:  Route to Sales → Pending Sales Review
Day 3:  Sales Opens → In Sales Review
Day 4:  Sales Feedback → Sales Review Complete
Day 4:  Analyst Reviews Feedback
Day 5:  Final Disposition → Complete

Total: 5 days
```

### Timeline with Remediation
```
Original:
Day 0-10: Normal Flow → Complete (Oct 1)

Remediation:
Day 45:   Quality Review Finds Issue
Day 45:   Reopen → Defect Remediation
Day 45-47: Analyst Corrects
Day 47:   Re-submit → Complete (Oct 17)

Reporting: Uses Oct 1 as completion date for SLA
```

---

## Decision Points

### Decision 1: Auto-Close or Manual Review?
```
IF (Risk Score < Threshold) 
   AND (Alert Count < Max) 
   AND (No High-Risk Flags)
THEN
   Auto-Close
ELSE
   Manual Review (Unassigned)
```

### Decision 2: Self-Disposition or Sales Review?
```
IF (Analyst Confident in Disposition)
   AND (No Unusual Patterns Requiring Sales Context)
THEN
   Self-Disposition → Complete
ELSE
   Route to Sales → Pending Sales Review
```

### Decision 3: Final Disposition
```
IF (Suspicious Activity)
   AND (Meets TRMS Criteria)
THEN
   Disposition = TRMS Filed
   Outcome = Escalated
ELSE IF (Unacceptable Risk)
THEN
   Disposition = Client Closed
   Outcome = Escalated
ELSE
   Disposition = No Action Required
   Outcome = In Line with Expected Activity
```

---

## Validation Gates

### Gate 1: Unassigned → In Progress
```
✓ Case must have assignee (manager assigned or analyst self-selected)
✓ User must have appropriate role (Analyst or Manager)
✓ User must have LOB access for case
```

### Gate 2: In Progress → Pending Sales Review
```
✓ Sales owner must be identified
✓ Case must have appropriate data for sales review
✓ User must be Analyst or Manager
```

### Gate 3: In Sales Review → Sales Review Complete
```
✓ Sales review comments must be provided
✓ User must be the assigned Sales Owner
```

### Gate 4: Any Status → Complete
```
✓ Derived disposition must be set
✓ Model outcome must be determined
✓ All required data must be reviewed
✓ Completion date auto-set
✓ User must be Analyst or Manager (not Sales)
```

### Gate 5: Complete → Defect Remediation
```
✓ User must be Manager or Administrator
✓ Defect reason must be documented
✓ Original completion date must be preserved
✓ Defect remediation flag must be set
```

### Gate 6: Defect Remediation → Complete
```
✓ All defects must be addressed
✓ Updated disposition and outcome (if changed)
✓ User must be Analyst or Manager
✓ Original completion date remains unchanged
✓ New completion date set for remediation
```

---

## Example Transitions

### Example 1: Smooth Flow (No Sales)
```
10/15 09:00 - System creates case → Unassigned
10/15 09:30 - Manager assigns to Michael Chen → In Progress
10/16 14:00 - Michael reviews client data
10/17 10:00 - Michael reviews ORRCA and alerts
10/18 15:00 - Michael determines No Action Required
10/18 15:05 - Michael dispositions case → Complete
```

### Example 2: Sales Review Flow
```
10/20 08:00 - System creates case → Unassigned
10/20 08:30 - Jennifer self-selects → In Progress
10/22 11:00 - Jennifer identifies unusual patterns
10/22 14:00 - Jennifer routes to David Park → Pending Sales Review
10/23 09:00 - David opens case → In Sales Review
10/23 15:30 - David provides context feedback
10/23 15:35 - David returns to Jennifer → Sales Review Complete
10/24 10:00 - Jennifer reviews sales feedback
10/24 10:30 - Jennifer dispositions (No Action) → Complete
```

### Example 3: Escalation Flow
```
10/05 08:00 - System creates HIGH risk case → Unassigned
10/05 08:05 - Auto-assigned to Sarah (Manager) → In Progress
10/08 11:00 - Sarah reviews 15 alerts
10/15 14:00 - Sarah identifies structuring patterns
10/19 10:00 - Sarah files TRMS-2025-1234
10/19 10:15 - Sarah dispositions (TRMS Filed) → Complete
```

### Example 4: Remediation Flow
```
09/15 08:00 - Case created → Unassigned
09/15-09/28 - Normal review process
09/28 14:35 - Jennifer completes case → Complete
...
10/15 10:00 - Sarah (Manager) quality review finds missing docs
10/15 10:30 - Sarah reopens case → Defect Remediation
10/15 10:35 - Sarah reassigns to Jennifer
10/26 09:00 - Jennifer working on remediation
10/26 15:00 - Jennifer re-submits → Complete
              (Original date 09/28 preserved)
```

---

## Integration Points

### System Integration Events
```
Case Creation
    ↓
Trigger Population Identification
    ↓
Pull from: Cesium, WCC, CMT, GWIM Hub, PRDS
    ↓
Pull from: ORRCA, 312 Model, FLU, TRMS
    ↓
Determine: Auto-Close or Manual Review
    ↓
If Manual → Unassigned (Workbasket)
If Auto → Complete (Auto-Closed)
```

### Data Access by Status
```
Unassigned:      Basic case data visible
In Progress:     Full data access for review
Pending Sales:   Sales owner gets notification
In Sales Review: Sales accesses client relationship data
Complete:        All data visible (read-only)
Remediation:     Full data access for correction
```

---

## Metrics and KPIs

### Status Duration Metrics
- Average time in Unassigned (target: < 4 hours)
- Average time in In Progress (target: < 5 days)
- Average time in Sales Review cycle (target: < 2 days)
- Average time in Defect Remediation (target: < 3 days)

### Flow Efficiency
- % Auto-closed (target: 30-40%)
- % Requiring sales review (benchmark)
- % Escalated (TRMS or Client Closed)
- % Requiring remediation (target: < 5%)

### Quality Metrics
- First-time completion rate
- Remediation rate by analyst
- Escalation accuracy rate
- Sales review value-add rate
