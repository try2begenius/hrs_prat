# CAM Platform Design System

## Overview
This design system establishes a professional, modern visual language for the Client Activity Monitoring (CAM) platform, inspired by best practices in financial compliance and AML dashboard design.

## Color Palette

### Primary Colors
- **Primary Blue**: `#2563EB` - Used for primary actions, links, and key UI elements
- **Background**: `#F8F9FC` - Light gray background for the main content area
- **Foreground**: `#1E293B` - Dark slate for primary text

### Semantic Colors
- **Success**: `#10B981` (Green) - Positive actions, completed cases
- **Warning**: `#F59E0B` (Amber) - In-progress items, pending actions
- **Destructive**: `#DC2626` (Red) - Critical alerts, high-risk items, errors
- **Info**: `#3B82F6` (Blue) - Informational messages

### Status Colors
- **New**: `#2563EB` (Blue)
- **In Progress**: `#F59E0B` (Amber)
- **Under Review**: `#8B5CF6` (Purple)
- **Escalated**: `#DC2626` (Red)
- **Closed**: `#10B981` (Green)

### Risk Level Colors
- **Critical**: Red background (`#DC2626`) with white text
- **High**: Red tint (`#FEE2E2` background, `#991B1B` text)
- **Medium**: Amber tint (`#FEF3C7` background, `#92400E` text)
- **Low**: Green tint (`#D1FAE5` background, `#065F46` text)

### Sidebar
- **Background**: `#1E293B` (Dark slate)
- **Foreground**: `#F8FAFC` (Off-white)
- **Accent**: `#334155` (Lighter slate for hover states)
- **Primary Highlight**: `#2563EB` (Blue for active items)

## Typography

### Font Stack
System font stack for optimal performance and native feel across platforms

### Hierarchy
- **h1**: 2xl size, medium weight - Main page titles
- **h2**: xl size, medium weight - Section headers
- **h3**: lg size, medium weight - Subsection headers
- **h4**: base size, medium weight - Component titles
- **Body**: base size, normal weight - Regular text
- **Small**: sm size - Secondary information
- **Micro**: xs size - Metadata, timestamps

## Components

### Cards
- **Base Card**: White background with subtle border
- **Elevated Card**: Added shadow with `card-elevated` class
- **Large Elevation**: Stronger shadow with `card-elevated-lg` class for hover states
- **Border Accent**: Left border (4px) in semantic colors for metric cards

### Badges

#### Status Badges
- Colored background with matching text
- Rounded corners
- Padding for visual breathing room

#### Risk Badges
- **Critical**: `bg-red-600 text-white` - Red with white text
- **High**: `bg-red-100 text-red-800 border-red-200` - Light red background
- **Medium**: `bg-amber-100 text-amber-800 border-amber-200` - Amber tint
- **Low**: `bg-green-100 text-green-800 border-green-200` - Green tint

### Tables
- **Header**: Muted background (`bg-muted/50`) with semibold text
- **Rows**: Hover effect with background transition
- **Borders**: Subtle border color (`#E2E8F0`)
- **Font**: Monospace for IDs and codes, regular for names

### Buttons
- **Primary**: Blue background with white text
- **Ghost**: Transparent background with subtle hover effect
- **Icon Buttons**: Consistent sizing with icon + label pattern

### Charts
- **Grid**: Light gray (`#E2E8F0`) for subtle visual structure
- **Axes**: Muted gray (`#64748B`) for non-intrusive labeling
- **Tooltips**: White background with border, rounded corners
- **Data Colors**: 
  - Primary series: `#2563EB` (Blue)
  - Secondary series: `#10B981` (Green)
  - Tertiary series: `#F59E0B` (Amber)
  - Additional: `#8B5CF6` (Purple), `#EC4899` (Pink)

## Layout

### Container
- Max width: `7xl` (80rem)
- Padding: 6 units (1.5rem)
- Responsive spacing that adapts to screen size

### Spacing
- **Section spacing**: 6 units vertical gap
- **Component spacing**: 4 units between related items
- **Content spacing**: 2-3 units for tight groupings

### Grid System
- **Metric Cards**: 1 column mobile → 2 tablet → 4 desktop
- **Charts**: 1 column mobile → 2 desktop
- **Forms**: Responsive columns based on field count

## Visual Effects

### Shadows
```css
/* Elevated card */
box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);

/* Large elevation */
box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
```

### Transitions
- **Hover states**: Smooth background and color transitions
- **Duration**: 150-300ms for responsive feel
- **Easing**: Default ease-out for natural motion

### Border Radius
- **Base**: `0.5rem` (8px)
- **Small**: `0.375rem` (6px) 
- **Large**: `0.75rem` (12px)
- **Icon containers**: `0.5rem` for consistent shape language

## Patterns

### Metric Cards
```tsx
<Card className="border-l-4 border-l-{color} card-elevated">
  <CardHeader>
    <div className="h-10 w-10 rounded-lg bg-{color}-100">
      <Icon className="text-{color}-600" />
    </div>
  </CardHeader>
  <CardContent>
    <div className="text-2xl text-{color}-600">{value}</div>
    <p className="text-xs text-muted-foreground">{description}</p>
  </CardContent>
</Card>
```

### Table Rows
```tsx
<TableRow className="hover:bg-muted/30 transition-colors">
  {/* Table cells */}
</TableRow>
```

### Status Indicators
```tsx
<Badge className="bg-{status-color}-100 text-{status-color}-800 border-0">
  {status}
</Badge>
```

## Accessibility

### Contrast Ratios
- All text meets WCAG AA standards (4.5:1 for normal text)
- Interactive elements have clear focus states
- Color is not the only means of conveying information

### Focus States
- Visible outline using `--ring` color
- Consistent across all interactive elements
- Enhanced visibility for keyboard navigation

### Semantic HTML
- Proper heading hierarchy
- ARIA labels where needed
- Semantic table structures

## Responsive Design

### Breakpoints
- **Mobile**: < 768px - Single column layouts
- **Tablet**: 768px - 1024px - 2 column layouts
- **Desktop**: > 1024px - Full multi-column layouts

### Mobile Optimizations
- Collapsible sidebar navigation
- Stacked metric cards
- Simplified table views
- Touch-friendly button sizes (min 44x44px)

## Icon System

### Library
Using Lucide React for consistent, professional icons

### Sizing
- **Small**: 3-4 units (12-16px) for inline icons
- **Medium**: 4-5 units (16-20px) for buttons
- **Large**: 5-6 units (20-24px) for headers and emphasis

### Colors
- **Default**: Muted foreground for subtle presence
- **Semantic**: Matching the context (blue for primary, red for destructive, etc.)

## Best Practices

1. **Consistency**: Use established patterns throughout the application
2. **Visual Hierarchy**: Clear distinction between primary and secondary content
3. **White Space**: Generous spacing for readability and focus
4. **Progressive Disclosure**: Show essential information first, details on demand
5. **Feedback**: Clear visual feedback for all user actions
6. **Performance**: Optimize for fast rendering and smooth animations

## Implementation Notes

### CSS Custom Properties
All colors and spacing values are defined as CSS custom properties in `styles/globals.css`, allowing for easy theme customization and maintenance.

### Utility Classes
Custom utility classes are defined using the `@utility` directive for reusable patterns:
- `card-elevated` - Subtle shadow for card elevation
- `card-elevated-lg` - Stronger shadow for hover states

Other styling patterns use standard Tailwind utilities for maximum flexibility.

### Component Library
Built on ShadCN UI components, ensuring accessibility and professional polish out of the box.
