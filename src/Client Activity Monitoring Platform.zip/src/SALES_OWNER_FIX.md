# Sales Owner Worklist Fix

## Problem
David Park (Sales Owner) was not seeing case `312-2025-001` or other cases in his Sales Owner Worklist.

## Root Cause
The `SalesOwnerWorklist.tsx` component was filtering cases incorrectly on **line 33**:

```typescript
// WRONG - This filters for cases assigned TO David Park as the analyst
if (c.assignedTo !== currentUser.name) return false;
```

**Issue**: `assignedTo` contains the AML analyst name (e.g., "Sarah Mitchell"), NOT the sales owner.

**Correct field**: Sales Owner is stored in `c.clientData.salesOwner`

## Solution Applied

### 1. Fixed Filtering Logic

**File**: `/components/SalesOwnerWorklist.tsx`

**Before** (line 31-33):
```typescript
const mySalesAssignedCases = mockCases.filter(c => {
  // Must be assigned to the current sales owner
  if (c.assignedTo !== currentUser.name) return false;
```

**After**:
```typescript
const mySalesAssignedCases = mockCases.filter(c => {
  // Must be the sales owner for this client
  if (c.clientData?.salesOwner !== currentUser.name) return false;
```

### 2. Added Missing `centralTeamContact` Field

The Sales Owner Worklist table displays a "Central Team Contact" column showing which AML analyst is handling each case. This field was missing from several cases.

**Files Modified**:
- `/data/enhancedMockData.ts` - Added to case `312-2025-001`
- `/data/caseFlowScenarios.ts` - Added to cases:
  - `312-2025-SALES-001` (Pending Sales Review)
  - `312-2025-SALES-002` (In Sales Review) - Also fixed assignedTo
  - `312-2025-SALES-003` (Sales Review Complete)

**Pattern**:
```typescript
{
  id: '312-2025-001',
  assignedTo: 'Sarah Mitchell',      // AML Analyst
  centralTeamContact: 'Sarah Mitchell', // Same as assignedTo
  clientData: {
    salesOwner: 'David Park',        // Sales Owner
    // ...
  }
}
```

## Cases Now Visible to David Park

When David Park logs in and views his "Sales Owner Worklist", he will see **19 cases** including:

### From enhancedMockData.ts:
1. **312-2025-001** - GlobalTech Industries Corp (In Progress) - Sarah Mitchell
2. **312-2025-002** - Apex Global Trading Corp (In Progress)
3. **312-2025-004** - Consolidated Industries Group (Unassigned)
4. **CAM-2025-001** - GlobalTech Industries Corp (In Progress)
5. **CAM-2025-003** - Meridian Export Group (Complete)
6. **312-2025-010** - Pinnacle Financial Group (Unassigned)
7. **CAM-2025-010** - Coastal Trading Partners (Complete)
8. **SR-2025-001** - Sterling Capital Partners (Pending Sales Review)
9. **SR-2025-003** - Quantum Investment Group (In Sales Review)
10. **SR-2025-004** - Apex Global Ventures (Sales Review Complete)

### From caseFlowScenarios.ts:
11. **312-2025-AUTO-001** - Standard Manufacturing (Auto-Closed)
12. **312-2025-002** - Pacific Trade Ventures (Unassigned)
13. **312-2025-SALES-001** - Meridian Capital Holdings (Pending Sales Review) - Michael Chen
14. **312-2025-SALES-002** - Pinnacle Investment Group (In Sales Review) - Jennifer Wu
15. **312-2025-SALES-003** - Apex Strategic Partners (Sales Review Complete) - Michael Chen
16. **312-2025-007** - United Manufacturing Corp (Complete)
17. **312-2025-008** - Offshore Holdings Ltd (Closed)
18. **312-2025-009** - Questionable Trading Corp (Rejected)
19. **312-2025-DEFECT-001** - Global Enterprise Solutions (Defect Remediation)

## Testing Steps

### Test 1: David Park Can See Cases

1. **Switch user** to **David Park**
2. Click **"Sales Owner Worklist"** in the sidebar
3. ✅ You should see **19 cases**
4. ✅ Case `312-2025-001` should be in the list
5. ✅ Client Name: GlobalTech Industries Corp
6. ✅ Status: In Progress
7. ✅ Central Team Contact: Sarah Mitchell

### Test 2: View Case Details

1. In the Sales Owner Worklist, find case `312-2025-001`
2. Click the **"View"** button (eye icon)
3. ✅ Case Details page opens
4. ✅ All 4 sections are visible (badges 1-4)
5. ✅ Sections 2-4 are read-only (David is not the assignee)
6. ✅ Section 5 (Sales Owner Review) is **EDITABLE** (purple badge)
7. ✅ You can fill out sales owner questions

### Test 3: Filter and Sort

1. In Sales Owner Worklist:
2. **Filter by Status**: Select "Pending Sales Review"
   - ✅ Should show cases `SR-2025-001`, `312-2025-SALES-001`
3. **Filter by Risk**: Select "High"
   - ✅ Should show high-risk cases only
4. **Sort by Due Date**: Click column header
   - ✅ Cases sort by due date ascending/descending
5. **Filter by Central Team Contact**: Select "Sarah Mitchell"
   - ✅ Shows only case `312-2025-001`

### Test 4: Search Functionality

1. In the search box, type: **"GlobalTech"**
2. ✅ Case `312-2025-001` appears
3. Type: **"312-2025-001"**
4. ✅ Case appears in results
5. Type: **"GCI-892341"**
6. ✅ Case appears (searches by GCI number)

### Test 5: Amanda Torres (Other Sales Owner)

1. **Switch user** to **Amanda Torres** (Sales Owner)
2. Go to **"Sales Owner Worklist"**
3. ✅ You should see **different cases** (not David Park's)
4. ✅ Case `312-2025-001` should **NOT** appear (not her client)

## Data Structure Reference

### Case Object - Sales Owner Fields

```typescript
{
  id: string;                   // Case ID
  assignedTo: string;           // AML Analyst handling the case
  centralTeamContact?: string;  // Same as assignedTo (for SO view)
  clientData: {
    salesOwner: string;         // Sales Owner name (filters SO worklist)
    // ...
  }
}
```

### Key Relationships

- **assignedTo**: AML Analyst who owns the case workflow
- **centralTeamContact**: Who the Sales Owner should contact (usually same as assignedTo)
- **clientData.salesOwner**: Which Sales Owner owns the client relationship

**Example**:
- Case `312-2025-001`
  - assignedTo: "Sarah Mitchell" (AML Analyst)
  - centralTeamContact: "Sarah Mitchell" (Point of contact)
  - clientData.salesOwner: "David Park" (Sales Owner)

**Meaning**: 
- Sarah Mitchell is reviewing the case from an AML perspective
- David Park owns the client relationship
- David Park can see this case in his Sales Owner Worklist
- Sarah Mitchell can see this case in her "My Cases" worklist

## Status Workflow Impact

### Sales Owner Involvement by Status

| Status | AML View | Sales Owner View | Who Can Edit |
|--------|----------|------------------|--------------|
| Unassigned | Assignable | Visible (read-only) | None |
| In Progress | Editable | Visible (read-only) | AML Analyst (Sections 3-4) |
| Pending Sales Review | Read-only | Actionable | Sales Owner (Section 5) |
| In Sales Review | Read-only | Editable | Sales Owner (Section 5) |
| Sales Review Complete | Editable | Read-only | AML Analyst (review SO feedback) |
| Complete | Read-only | Read-only | None |

### When Sales Owners Need to Act

Sales Owners should prioritize cases with these statuses:
1. **Pending Sales Review** - Case awaiting sales owner to open and review
2. **In Sales Review** - Case currently being reviewed by sales owner

These will appear in their worklist with clear status badges.

## Files Modified

1. `/components/SalesOwnerWorklist.tsx`
   - Line 31-33: Changed filter from `assignedTo` to `clientData.salesOwner`

2. `/data/enhancedMockData.ts`
   - Line 31: Added `centralTeamContact: 'Sarah Mitchell'` to case `312-2025-001`

3. `/data/caseFlowScenarios.ts`
   - Line 161: Added `centralTeamContact` to `312-2025-SALES-001`
   - Line 207-208: Changed `assignedTo` from David Park to Jennifer Wu, added `centralTeamContact`
   - Line 253: Added `centralTeamContact` to `312-2025-SALES-003`

## Additional Notes

### Why centralTeamContact?

When a Sales Owner is reviewing a case, they need to know:
- **Who is the AML analyst?** (So they can ask questions, discuss)
- **Who should they respond to?** (Where to send their review)

The `centralTeamContact` field provides this information and displays in the "Central Team Contact" column of the Sales Owner Worklist.

### Future Enhancement Considerations

If this were a production system, you might also add:
- **Email notifications** when case status changes to "Pending Sales Review"
- **Reminders** for overdue sales reviews
- **Escalation paths** if sales owner doesn't respond within SLA
- **Comment threads** for AML ↔ Sales Owner communication
- **History log** showing when case was sent to sales and when they responded

---

**Fix Applied**: October 27, 2025  
**Status**: ✅ Sales Owner Worklist now correctly filters by `clientData.salesOwner`  
**Testing**: Ready for David Park to view his cases
