# Testing Guide: Case UI Editable Functions

## Overview
This guide walks you through testing all interactive and editable features in the Case Details UI for case `312-2025-001`.

---

## 🎯 Quick Test Setup

### Step 1A: Access the Case as AML Analyst
1. **Refresh your browser** (to load the fix)
2. Switch to user: **Sarah Mitchell** (Central Team Manager)
3. Click **"My Cases"** in the sidebar
4. Find case **`312-2025-001`** - GlobalTech Industries Corp
5. Click **"View Details"**

### Step 1B: Access the Case as Sales Owner
1. **Refresh your browser** (to load the fix)
2. Switch to user: **David Park** (Sales Owner)
3. Click **"Sales Owner Worklist"** in the sidebar
4. Find case **`312-2025-001`** - GlobalTech Industries Corp
5. Click the **"View"** button (eye icon)

### Step 2: Verify All Sections Are Visible
You should see **4 numbered badges**:
- **Badge 1**: Case and Client Details (Section 2)
- **Badge 2**: 312 Case (Section 3)
- **Badge 3**: CAM Case (Section 4)
- **Badge 4**: Sales Owner Review (Section 5)

---

## 📋 Section-by-Section Testing

### ✅ SECTION 2: Case and Client Details (Badge 1)

**Type**: Read-only information display  
**Purpose**: Shows case metadata, client info, monitoring data

**What to Check**:
- [x] Expand the section by clicking the header
- [x] Verify you see:
  - Entity name, GCI, CoperID, Client ID
  - Line of Business: GB/GM
  - Risk Level: High
  - 312 Due Date, Aging, Status, Disposition
  - CAM Due Date, Aging, Status, Disposition
  - Dynamic Risk Rating: 8.7
  - 312 Model Score: 8.5
  - Sales Owner: David Park

**Expected**: All data displays correctly, no edit controls

---

### ✏️ SECTION 3: 312 Case (Badge 2)

**Type**: EDITABLE for assignee (Sarah Mitchell)  
**Purpose**: Analyst completes 312 review questions

#### Test Case 3A: View Initial State

1. Click **Badge 2** to expand
2. Verify you see:
   - 312 Model Results table (Risk Rating, Model Score, etc.)
   - Expected Activity section
   - Four review questions (Q1-Q4)

#### Test Case 3B: Edit Question 1

**Question 1**: "Is there additional 312 activity as compared to the model results?"

1. **Select "Yes"**:
   - ✅ Question 1.1 should appear: "Document 312 activity not reflected in model"
   - ✅ A text area should be visible
   - Type: "Additional wire transfers to offshore entities identified"
   
2. **Select "No"**:
   - ✅ Question 1.1 should disappear
   
3. **Select "Unable to Determine"**:
   - ✅ Question 1.1 should disappear

#### Test Case 3C: Edit Question 2

**Question 2**: "Is there additional high risk activity present?"

1. **Select "Yes"**:
   - ✅ Question 2.1 appears: "Document high risk activity"
   - Type: "Pattern of structured cash deposits noted"
   
2. **Select "No"** or **"Unable to Determine"**:
   - ✅ Question 2.1 disappears

#### Test Case 3D: Edit Question 3

**Question 3**: "Does the additional activity warrant a SAR?"

1. **Select "Yes"**:
   - ✅ Question 3.1 appears: "Document SAR rationale"
   - Type: "Transactions meet regulatory filing threshold"
   
2. Test other options (No/Unable to Determine)

#### Test Case 3E: Edit Question 4 (ML/PB LOB Only)

**Note**: This case is GB/GM LOB, so you'll see:

**Question 4**: "What action should be taken?"

1. **Select from dropdown**:
   - "File SAR - No further action"
   - "File SAR - Escalate to TRMS"
   - "No SAR - Continue monitoring"
   - "No SAR - Escalate to TRMS"
   - "No SAR - Request Sales Owner Input"

2. **If you select an option with "Escalate to TRMS"**:
   - ✅ TRMS dropdown appears
   - ✅ Select a TRMS option (Immediate Exit, Enhanced Monitoring, etc.)

3. **If you select "Request Sales Owner Input"**:
   - ✅ Sales Owner dropdown appears
   - ✅ Select David Park or Amanda Torres

**Note**: For ML/PB LOB cases, Question 4 would show different ML-specific questions

#### Test Case 3F: Save Functionality

1. Fill out some fields (don't complete everything)
2. Click **"Save Progress"** button (bottom left)
3. ✅ Toast notification should appear: "312 case progress saved"
4. ✅ Navigate away (click "My Cases")
5. ✅ Return to the case
6. ✅ Your saved data should still be there

#### Test Case 3G: Validation on Submit

1. Click **"Submit 312 Case"** button WITHOUT filling all required fields
2. ✅ Alert dialog should appear: "Please complete all required questions"
3. Click "OK"
4. Fill out ALL questions:
   - Q1: Select an answer
   - Q2: Select an answer  
   - Q3: Select an answer
   - Q4: Select an action
   - Fill any conditional follow-up questions
5. Click **"Submit 312 Case"** again
6. ✅ Confirmation dialog appears: "Are you sure you want to submit?"
7. Click **"Submit"**
8. ✅ Toast notification: "312 case submitted successfully"
9. ✅ Section should now show "Submitted" badge with lock icon
10. ✅ All fields become read-only (no more dropdowns/textareas)

#### Test Case 3H: Read-Only After Submit

1. After submitting, try to:
   - ✅ Click on answer fields - they should be plain text, not editable
   - ✅ Save and Submit buttons should be hidden or disabled
   - ✅ Green "Submitted" badge appears in section header

---

### ✏️ SECTION 4: CAM Case (Badge 3)

**Type**: EDITABLE for assignee (Sarah Mitchell)  
**Purpose**: Review CAM monitoring data and complete attestations

#### Test Case 4A: View Monitoring Dashboard Tabs

1. Click **Badge 3** to expand
2. Verify you see **7 tabs** at the top:
   - Tab 1: Acct Open/Mgmt Activity (default)
   - Tab 2: Client Interactions
   - Tab 3: Internal Referrals
   - Tab 4: OFAC/Sanctions
   - Tab 5: News/Media
   - Tab 6: Regulatory Actions
   - Tab 7: Transaction Activity

3. **Click through each tab**:
   - ✅ Each tab should display a table with data
   - ✅ Data should be relevant to the tab name
   - ✅ Check that columns match the data

#### Test Case 4B: Edit CAM Questions

Scroll below the monitoring tabs to the CAM Review Questions section.

**Question 1**: "Is there activity that requires additional review?"

1. **Select "Yes"**:
   - ✅ Question 1.1 appears: Attestation checkboxes
   - ✅ See 5+ attestation options:
     - "Reviewed transaction activity patterns"
     - "Analyzed client interactions and communications"
     - "Assessed OFAC/sanctions screening results"
     - "Evaluated news and media coverage"
     - "Reviewed regulatory filings and actions"
     - "Examined internal referrals and alerts"
     - "Consulted with sales owner regarding client activity"
   
2. **Check some attestations** (but not all):
   - ✅ Checkboxes should toggle on/off
   
3. **Check ALL attestations**:
   - ✅ Questions 1.2 and 1.3 appear:
     - 1.2: "Does this activity require escalation to TRMS?"
     - 1.3: "TRMS Number (if applicable)"

4. **Question 1.2 - Select "Yes"**:
   - ✅ Question 1.3 (TRMS Number) should be required
   - Type a number: "TRMS-2025-12345"

#### Test Case 4C: Question 2

**Question 2**: "What is your recommendation?"

1. **Select from dropdown**:
   - "Continue Monitoring - No Action Required"
   - "Request Sales Owner Input"
   - "Escalate to Manager Review"
   - "Escalate to TRMS"
   - "File SAR"

2. **If "Request Sales Owner Input" selected**:
   - ✅ Question 2.1 appears: "Please specify what information is needed"
   - Type: "Need clarification on source of large deposits"

#### Test Case 4D: Question 3

**Question 3**: "Provide your analysis and supporting rationale"

1. ✅ Large text area appears
2. Type a detailed analysis (minimum 50 characters)
3. Example: "Client activity patterns align with business model. Recent increase in transaction volume corresponds with documented business expansion into new markets. No unusual patterns detected."

#### Test Case 4E: Save CAM Progress

1. Fill out some fields
2. Click **"Save Progress"** (bottom left)
3. ✅ Toast: "CAM case progress saved"
4. Navigate away and return
5. ✅ Data persists

#### Test Case 4F: Submit CAM Case

1. Fill out ALL required fields:
   - Q1: Select "Yes" → Check all attestations → Complete TRMS fields
   - Q2: Select a recommendation
   - Q3: Provide analysis (min 50 characters)

2. Click **"Submit CAM Case"**
3. ✅ Validation checks:
   - If missing fields → Error alert
   - If analysis < 50 chars → Error alert
   
4. When valid, confirmation dialog appears
5. Click **"Submit"**
6. ✅ Toast: "CAM case submitted successfully"
7. ✅ Section shows "Submitted" badge
8. ✅ All fields become read-only

---

### 👁️ SECTION 5: Sales Owner Review (Badge 4)

**Type**: READ-ONLY for Sarah Mitchell (AML user)  
**Type**: EDITABLE for David Park (Sales Owner)

#### Test Case 5A: View as AML User (Sarah Mitchell)

1. While logged in as **Sarah Mitchell**
2. Click **Badge 4** to expand
3. ✅ You should see:
   - "View Only - AML Access" badge (gray)
   - Read-only view of Sales Owner questions
   - NO edit controls (no dropdowns, textareas)
   - NO Save/Submit buttons

4. ✅ Review the processor comments:
   - "312 Analyst Comment" section with Sarah's request
   - "CAM Analyst Comment" section (if CAM submitted)

#### Test Case 5B: View as Sales Owner (David Park)

1. **Switch user** to **David Park** (Sales Owner)
2. Go to **"My Cases"** sidebar
3. ✅ Case `312-2025-001` should appear (assigned Sales Owner)
4. Click **"View Details"**
5. ✅ All 4 sections are visible
6. ✅ Sections 2-4 are read-only for Sales Owner
7. Click **Badge 4** (Sales Owner Review)
8. ✅ You should see:
   - "Sales Owner Access" badge (purple)
   - EDITABLE fields (dropdowns, textareas)
   - Save and Submit buttons

#### Test Case 5C: Edit Sales Owner Response (as David Park)

**Question 1**: "Do you agree with the processor's assessment?"

1. **Select "Yes"**:
   - ✅ Question 1.1 appears: "Please provide any additional context"
   - Type: "Client activity is consistent with business operations"

2. **Select "No"**:
   - ✅ Question 1.1 appears: "Please explain your concerns"
   - Type: "Recent transactions are tied to new contract, not suspicious"

3. **Select "Partially Agree"**:
   - ✅ Question 1.1 text changes appropriately

#### Test Case 5D: Question 2 (Sales Owner)

**Question 2**: "What is your recommendation?"

1. **Select from dropdown**:
   - "Agree - Proceed as recommended"
   - "Agree with modifications"
   - "Disagree - Continue monitoring only"
   - "Disagree - Additional review needed"
   - "Request meeting to discuss"

2. **If "Agree with modifications" or "Request meeting"**:
   - ✅ Question 2.1 appears: "Please specify"
   - Type details

#### Test Case 5E: Question 3 (Sales Owner)

**Question 3**: "Provide your business context and rationale"

1. ✅ Large text area appears
2. Type comprehensive response (minimum 50 characters)
3. Example: "Client is a long-standing relationship with strong business fundamentals. Recent activity spike is due to merger completion. All transactions are documented and legitimate business operations."

#### Test Case 5F: Submit Sales Review (as David Park)

1. Complete all required fields
2. Click **"Submit Sales Owner Review"**
3. ✅ Validation checks required fields
4. ✅ Confirmation dialog appears
5. Click **"Submit"**
6. ✅ Toast: "Sales owner review submitted"
7. ✅ "Submitted" badge appears
8. ✅ Fields become read-only
9. ✅ Case status may update to "Sales Review Complete"

---

## 🔄 Workflow Testing

### Test Workflow 1: Complete 312 → CAM → Sales Review

**As Sarah Mitchell**:
1. ✅ Complete and submit Section 3 (312 Case)
2. ✅ Complete and submit Section 4 (CAM Case)
3. ✅ Case status updates to "Pending Sales Review"
4. ✅ Section 5 becomes available (was already visible, now has data)

**As David Park**:
5. ✅ View case in "My Cases"
6. ✅ Review Sections 3-4 (read-only)
7. ✅ Complete Section 5 (Sales Owner Review)
8. ✅ Submit Section 5
9. ✅ Case status updates to "Sales Review Complete"

**As Sarah Mitchell** (back):
10. ✅ View updated case
11. ✅ See David Park's responses in Section 5 (read-only)
12. ✅ All sections show "Submitted" badges

### Test Workflow 2: Save & Resume

1. **As Sarah Mitchell**:
   - Start filling Section 3
   - Fill only Q1 and Q2
   - Click **"Save Progress"**
   - Click **"Back to Worklist"**

2. **Navigate away**:
   - Click "Dashboard" or "Reports"
   - Spend some time elsewhere

3. **Return to case**:
   - Go to "My Cases"
   - Click "View Details" on `312-2025-001`
   - Expand Section 3
   - ✅ Your Q1 and Q2 answers are still there
   - ✅ Q3 and Q4 are empty (as expected)
   - Complete Q3 and Q4
   - Submit

### Test Workflow 3: Cancel Changes

1. **As Sarah Mitchell**:
   - Open Section 3
   - Make some changes to answers
   - Click **"Cancel"** button
   - ✅ Confirmation dialog: "Discard unsaved changes?"
   - Click **"Discard"**
   - ✅ Navigates back to worklist
   - ✅ Changes are NOT saved

2. **Return to case**:
   - ✅ Previous saved state is loaded (changes discarded)

---

## 🚨 Error Handling Testing

### Test Error 1: Submit Without Required Fields

**Section 3**:
1. Leave Q1 blank
2. Click "Submit 312 Case"
3. ✅ Alert: "Please complete all required questions"

**Section 4**:
1. Leave Q3 (analysis) blank
2. Click "Submit CAM Case"  
3. ✅ Alert: "Please complete all required fields"

### Test Error 2: Minimum Character Validation

**Section 4, Q3**:
1. Type only "Test" (4 characters)
2. Click "Submit CAM Case"
3. ✅ Alert: "Analysis must be at least 50 characters"

**Section 5, Q3**:
1. Type short text (< 50 characters)
2. Click "Submit Sales Owner Review"
3. ✅ Alert: "Rationale must be at least 50 characters"

### Test Error 3: Conditional Field Validation

**Section 3, Q1**:
1. Select "Yes"
2. Leave Question 1.1 text area blank
3. Try to submit
4. ✅ Error: "Please document 312 activity"

**Section 4**:
1. Select Q1.2 "Yes" (TRMS escalation)
2. Leave Q1.3 (TRMS Number) blank
3. Try to submit
4. ✅ Error: "TRMS number is required"

---

## 🔐 Access Control Testing

### Test Access 1: Assignee Can Edit

**As Sarah Mitchell** (assignee):
- ✅ Sections 3 & 4 are editable
- ✅ Save and Submit buttons visible
- ✅ Section 5 is read-only

### Test Access 2: Sales Owner Can Edit Section 5

**As David Park** (Sales Owner):
- ✅ Section 5 is editable
- ✅ Sections 2-4 are read-only
- ✅ Can see all processor comments

### Test Access 3: View-Only User

**Switch to Robert Anderson** (View Only role):
1. Go to "Case Worklist"
2. Find case `312-2025-001`
3. Click "View Details"
4. ✅ All sections are read-only
5. ✅ NO Save or Submit buttons
6. ✅ Dropdowns/checkboxes are disabled or shown as text

### Test Access 4: Different Analyst

**Switch to Michael Chen** (Central Team Analyst):
1. Go to "Case Worklist"
2. Case `312-2025-001` is assigned to Sarah Mitchell
3. Click "View Details"
4. ✅ All sections are read-only (not the assignee)
5. ✅ Cannot edit Sections 3-4

---

## 📊 Status Updates Testing

### Test Status Flow

**Initial State**:
- Status: "In Progress"

**After 312 Submit**:
1. Submit Section 3
2. ✅ Status may remain "In Progress" (waiting for CAM)

**After CAM Submit**:
1. Submit Section 4
2. ✅ Status updates to "Pending Sales Review"
3. ✅ Sales Owner (David Park) gets notification

**After Sales Submit**:
1. Switch to David Park
2. Submit Section 5
3. ✅ Status updates to "Sales Review Complete"

---

## 🎨 UI/UX Testing

### Visual Checks

1. **Badges**:
   - ✅ Numbered badges (1-4) appear correctly
   - ✅ "Submitted" badges show green with lock icon
   - ✅ "Sales Owner Access" badge shows purple with shield icon
   - ✅ "View Only" badge shows gray

2. **Form Controls**:
   - ✅ Dropdowns render correctly with all options
   - ✅ Radio buttons are mutually exclusive
   - ✅ Checkboxes can toggle independently
   - ✅ Text areas expand to fit content

3. **Conditional Rendering**:
   - ✅ Follow-up questions appear smoothly (no flicker)
   - ✅ Follow-up questions disappear when parent changes
   - ✅ No orphaned fields remain visible

4. **Responsive Design**:
   - ✅ Resize browser window
   - ✅ Grid layouts adjust (3 cols → 2 cols → 1 col)
   - ✅ Buttons stack on mobile
   - ✅ Tables scroll horizontally on narrow screens

5. **Toast Notifications**:
   - ✅ Appear in bottom-right corner
   - ✅ Auto-dismiss after ~3 seconds
   - ✅ Show appropriate icon (checkmark for success)
   - ✅ Readable text

---

## 🧪 Edge Cases

### Edge Case 1: Rapid Clicking

1. Fill out Section 3
2. Click "Submit" button **rapidly 5 times**
3. ✅ Only ONE submission should occur
4. ✅ No duplicate toasts
5. ✅ Button should disable after first click

### Edge Case 2: Browser Refresh

1. Fill out Section 3 partially
2. Click "Save Progress"
3. **Refresh browser (F5)**
4. ❌ Changes will be lost (no persistence in mock data)
5. ℹ️ This is expected behavior in demo mode

### Edge Case 3: Multiple Sections Open

1. Expand Section 2
2. Expand Section 3
3. Expand Section 4
4. Expand Section 5
5. ✅ All sections can be open simultaneously
6. ✅ Scrolling works correctly
7. ✅ No layout issues

### Edge Case 4: Empty Text Areas

1. In Section 3, Q1, select "Yes"
2. Leave text area blank (just spaces)
3. Try to submit
4. ✅ Should trim whitespace and reject
5. ✅ Error message appears

---

## ✅ Success Criteria

All tests pass if:

- ✅ All 4 sections are visible
- ✅ Sections 3-4 are editable for assignee
- ✅ Section 5 is editable for Sales Owner
- ✅ Conditional fields show/hide correctly
- ✅ Save functionality works
- ✅ Submit validation prevents incomplete submissions
- ✅ Submitted sections become read-only
- ✅ Toast notifications appear
- ✅ Access control works for different users
- ✅ No console errors
- ✅ UI is responsive and professional

---

## 🐛 Troubleshooting

**Problem**: Sections 3 or 4 still not visible
- **Solution**: Hard refresh browser (Ctrl+Shift+R / Cmd+Shift+R)

**Problem**: Changes don't save
- **Solution**: This is expected in demo mode (no backend)

**Problem**: Can't submit even with all fields filled
- **Solution**: Check console (F12) for validation errors

**Problem**: Section 5 not editable as Sales Owner
- **Solution**: Verify you're logged in as David Park (Sales Owner role)

**Problem**: Toast notifications don't appear
- **Solution**: Check if Toaster component is in App.tsx

---

## 📝 Report Issues

If you find any bugs or unexpected behavior, note:
1. Which user you're logged in as
2. Which section/question
3. What you clicked/typed
4. Expected vs actual behavior
5. Browser console errors (F12 → Console tab)

---

**Last Updated**: October 27, 2025  
**Version**: 2.0 (After fix for missing sections 3 & 4)
