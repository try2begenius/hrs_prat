import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from 'recharts';
import { AlertCircle, TrendingUp, Users, FileText, Clock, CheckCircle2 } from 'lucide-react';
import { mockCases } from '../data/enhancedMockData';
import { UserAccess } from '../data/rolesEntitlementsMockData';

interface DashboardProps {
  currentUser: UserAccess;
}

const trendData = [
  { month: 'May', cases: 45 },
  { month: 'Jun', cases: 52 },
  { month: 'Jul', cases: 48 },
  { month: 'Aug', cases: 61 },
  { month: 'Sep', cases: 58 },
  { month: 'Oct', cases: 67 },
];

export function Dashboard({ currentUser }: DashboardProps) {
  // Filter cases based on user's entitlements
  const filterCasesByUser = (cases: typeof mockCases) => {
    return cases.filter(c => {
      // Filter by case type access
      if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
      if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
      
      // Filter by LOB access - check clientData.lineOfBusiness
      const caseLOB = c.clientData?.lineOfBusiness;
      if (caseLOB && !currentUser.entitlements.lobs.includes(caseLOB)) return false;
      
      // Filter employee cases - check clientData.isEmployee
      if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
      
      // Sales Owner only sees cases assigned to them or needing sales feedback
      if (currentUser.role === 'Sales Owner' && c.assignedTo !== currentUser.name) return false;
      
      return true;
    });
  };

  const userCases = filterCasesByUser(mockCases);
  
  const statusData = [
    { name: 'Unassigned', value: userCases.filter(c => c.status === 'Unassigned').length, color: '#6B7280' },
    { name: 'In Progress', value: userCases.filter(c => c.status === 'In Progress').length, color: '#F59E0B' },
    { name: 'Pending Sales Review', value: userCases.filter(c => c.status === 'Pending Sales Review').length, color: '#3B82F6' },
    { name: 'In Sales Review', value: userCases.filter(c => c.status === 'In Sales Review').length, color: '#8B5CF6' },
    { name: 'Complete', value: userCases.filter(c => c.status === 'Complete').length, color: '#10B981' },
    { name: 'Defect Remediation', value: userCases.filter(c => c.status === 'Defect Remediation').length, color: '#EF4444' },
  ].filter(item => item.value > 0); // Only show statuses with cases

  const riskData = [
    { name: 'Critical', count: userCases.filter(c => c.riskLevel === 'Critical').length },
    { name: 'High', count: userCases.filter(c => c.riskLevel === 'High').length },
    { name: 'Medium', count: userCases.filter(c => c.riskLevel === 'Medium').length },
    { name: 'Low', count: userCases.filter(c => c.riskLevel === 'Low').length },
  ];

  const totalCases = userCases.length;
  const openCases = userCases.filter(c => c.status !== 'Closed').length;
  const highPriority = userCases.filter(c => c.priority === 'Urgent' || c.priority === 'High').length;
  const overdueCount = userCases.filter(c => {
    const dueDate = new Date(c.dueDate);
    const today = new Date();
    return dueDate < today && c.status !== 'Closed';
  }).length;

  return (
    <div className="space-y-6">
      <div>
        <h2>Dashboard Overview</h2>
        <p className="text-muted-foreground">
          {currentUser.role} View - {currentUser.entitlements.lobs.join(', ')} 
          {currentUser.entitlements.has312Access && currentUser.entitlements.hasCAMAccess && ' | 312 & CAM Access'}
          {currentUser.entitlements.has312Access && !currentUser.entitlements.hasCAMAccess && ' | 312 Access Only'}
          {!currentUser.entitlements.has312Access && currentUser.entitlements.hasCAMAccess && ' | CAM Access Only'}
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-blue-500 card-elevated">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Cases</CardTitle>
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-primary">{totalCases}</div>
            <p className="text-xs text-muted-foreground mt-1">
              <span className="text-green-600 font-medium">+12%</span> from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500 card-elevated">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Open Cases</CardTitle>
            <div className="h-10 w-10 rounded-lg bg-amber-100 flex items-center justify-center">
              <AlertCircle className="h-5 w-5 text-amber-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-amber-600">{openCases}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Requires attention
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500 card-elevated">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">High Priority</CardTitle>
            <div className="h-10 w-10 rounded-lg bg-red-100 flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-red-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-red-600">{highPriority}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Urgent and high priority
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500 card-elevated">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Overdue</CardTitle>
            <div className="h-10 w-10 rounded-lg bg-red-100 flex items-center justify-center">
              <Clock className="h-5 w-5 text-red-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-red-600">{overdueCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Past due date
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Additional Metrics Row */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="text-sm">Case Type Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">312 Reviews</span>
                <span className="text-sm font-medium text-primary">
                  {userCases.filter(c => c.caseType === '312 Review').length}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">CAM Reviews</span>
                <span className="text-sm font-medium text-primary">
                  {userCases.filter(c => c.caseType === 'CAM Review').length}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Other</span>
                <span className="text-sm font-medium text-primary">
                  {userCases.filter(c => c.caseType !== '312 Review' && c.caseType !== 'CAM Review').length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="text-sm">LOB Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {['GB/GM', 'PB', 'ML', 'Consumer', 'CI'].map(lob => {
                const lobCount = userCases.filter(c => c.clientData?.lineOfBusiness === lob).length;
                if (lobCount === 0) return null;
                return (
                  <div key={lob} className="flex items-center justify-between">
                    <span className="text-sm">{lob}</span>
                    <span className="text-sm font-medium text-primary">{lobCount}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="text-sm">Employee Cases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Total Employee</span>
                <span className="text-sm font-medium text-primary">
                  {userCases.filter(c => c.clientData?.isEmployee).length}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Open Employee</span>
                <span className="text-sm font-medium text-amber-600">
                  {userCases.filter(c => c.clientData?.isEmployee && c.status !== 'Closed').length}
                </span>
              </div>
              {!currentUser.entitlements.hasEmployeeCaseAccess && (
                <p className="text-xs text-muted-foreground mt-2">
                  * You don't have employee case access
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Cases by Status</CardTitle>
            <CardDescription>Current distribution of case statuses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Risk Level Distribution</CardTitle>
            <CardDescription>Cases categorized by risk severity</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={riskData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="name" stroke="#64748B" />
                <YAxis stroke="#64748B" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#ffffff', 
                    border: '1px solid #E2E8F0',
                    borderRadius: '0.5rem'
                  }}
                />
                <Bar dataKey="count" fill="#2563EB" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Trend Chart */}
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle>Case Volume Trend</CardTitle>
          <CardDescription>Monthly case creation over the past 6 months</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="month" stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#ffffff', 
                  border: '1px solid #E2E8F0',
                  borderRadius: '0.5rem'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="cases" 
                stroke="#2563EB" 
                strokeWidth={3}
                dot={{ fill: '#2563EB', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Recent High-Priority Cases */}
      <Card className="card-elevated">
        <CardHeader>
          <CardTitle>Recent High-Priority Cases</CardTitle>
          <CardDescription>Cases requiring immediate attention ({currentUser.role})</CardDescription>
        </CardHeader>
        <CardContent>
          {userCases.filter(c => (c.priority === 'Urgent' || c.priority === 'High') && c.status !== 'Closed').length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No high-priority cases</p>
            </div>
          ) : (
            <div className="space-y-4">
              {userCases
                .filter(c => (c.priority === 'Urgent' || c.priority === 'High') && c.status !== 'Closed')
                .slice(0, 5)
                .map(caseItem => (
                  <div key={caseItem.id} className="flex items-center justify-between border-b border-border pb-4 last:border-0 last:pb-0 hover:bg-accent/50 -mx-2 px-2 py-2 rounded-lg transition-colors">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-medium">{caseItem.id}</span>
                        <Badge 
                          variant={caseItem.riskLevel === 'Critical' ? 'destructive' : 'default'}
                          className={caseItem.riskLevel === 'Critical' ? 'bg-red-600 text-white' : 'bg-red-100 text-red-800 border-red-200'}
                        >
                          {caseItem.riskLevel}
                        </Badge>
                        <Badge variant="outline">{caseItem.status}</Badge>
                        {caseItem.clientData?.isEmployee && (
                          <Badge variant="secondary" className="bg-purple-100 text-purple-800">Employee</Badge>
                        )}
                      </div>
                      <p className="text-sm font-medium">{caseItem.clientName}</p>
                      <p className="text-xs text-muted-foreground">
                        {caseItem.caseType} • {caseItem.clientData?.lineOfBusiness}
                      </p>
                    </div>
                    <div className="text-right text-xs text-muted-foreground">
                      <div>Due: {caseItem.dueDate}</div>
                      <div>Assigned: {caseItem.assignedTo}</div>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
