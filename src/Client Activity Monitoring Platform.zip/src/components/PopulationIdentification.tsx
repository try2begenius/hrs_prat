import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { Progress } from "./ui/progress";
import { CheckCircle2, XCircle, AlertCircle, PlayCircle, Calendar, Shield, Users, Database, Filter, Zap, TrendingUp } from 'lucide-react';
import { mockClientsForPopulation, calculatePopulationStats, ClientForPopulation } from '../data/populationMockData';

export function PopulationIdentification() {
  const [clients] = useState<ClientForPopulation[]>(mockClientsForPopulation);
  const [selectedClient, setSelectedClient] = useState<ClientForPopulation | null>(null);
  const stats = calculatePopulationStats(clients);

  const getPopulationBadge = (in312: boolean, inCAM: boolean) => {
    if (in312 && inCAM) {
      return <Badge variant="default" className="gap-1"><CheckCircle2 className="h-3 w-3" />Both</Badge>;
    } else if (in312) {
      return <Badge variant="default" className="gap-1 bg-blue-100 text-blue-700 border-blue-200"><Shield className="h-3 w-3" />312</Badge>;
    } else if (inCAM) {
      return <Badge variant="destructive" className="gap-1"><AlertCircle className="h-3 w-3" />CAM</Badge>;
    } else {
      return <Badge variant="outline" className="gap-1"><XCircle className="h-3 w-3" />Excluded</Badge>;
    }
  };

  const getRiskBadge = (risk: string) => {
    const variants: Record<string, string> = {
      'High': 'destructive',
      'Elevated': 'default',
      'Standard': 'secondary',
      'Low': 'outline'
    };
    return <Badge variant={variants[risk] as any}>{risk}</Badge>;
  };

  const evaluate312Criteria = (client: ClientForPopulation) => {
    const criteria = [];
    
    // Base requirement
    criteria.push({
      met: client.status === 'Active',
      rule: 'Client is in Active status',
      result: client.status === 'Active' ? 'Active' : 'Closed - EXCLUDED',
      critical: true
    });

    // 312 Flag
    criteria.push({
      met: client.has312Flag,
      rule: 'Client has 312 Flag in AWARE',
      result: client.has312Flag ? 'Flag present' : 'No flag - EXCLUDED',
      critical: true
    });

    if (client.lob === 'GB/GM') {
      // Risk rating check
      const validRisk = ['High', 'Elevated', 'Standard'].includes(client.riskRating);
      criteria.push({
        met: validRisk,
        rule: 'Risk Rating: High, Elevated, or Standard',
        result: validRisk ? client.riskRating : `${client.riskRating} - EXCLUDED`,
        critical: true
      });

      if (client.riskRating === 'High') {
        criteria.push({
          met: !!client.dgaDueDate,
          rule: 'GB/GM High Risk - Has DGA Due Date',
          result: client.dgaDueDate ? `DGA: ${client.dgaDueDate}` : 'No DGA - EXCLUDED',
          critical: true
        });
      } else {
        criteria.push({
          met: !!client.familyAnniversaryDate && (client.daysToFamilyAnniversary || 0) <= 180,
          rule: 'GB/GM Non-High Risk - Family Anniversary within 180 days',
          result: client.familyAnniversaryDate ? 
            `${client.daysToFamilyAnniversary} days ${(client.daysToFamilyAnniversary || 0) <= 180 ? '✓' : '- EXCLUDED'}` : 
            'No anniversary date - EXCLUDED',
          critical: true
        });
      }

      // Manual identification
      criteria.push({
        met: !!client.manuallyIdentified312,
        rule: 'Manually identified for 312 review (Optional)',
        result: client.manuallyIdentified312 ? 'Manually flagged' : 'Not flagged',
        critical: false
      });
    }

    if (client.lob === 'PB' || client.lob === 'ML') {
      // Risk rating - must be High
      criteria.push({
        met: client.riskRating === 'High',
        rule: `${client.lob} - Risk Rating must be High`,
        result: client.riskRating === 'High' ? 'High' : `${client.riskRating} - EXCLUDED`,
        critical: true
      });

      // Refresh within 180 days
      criteria.push({
        met: client.daysToRefresh <= 180,
        rule: 'Client refresh due within 180 days',
        result: `${client.daysToRefresh} days ${client.daysToRefresh <= 180 ? '✓' : '- EXCLUDED'}`,
        critical: true
      });

      // PVT requirement
      criteria.push({
        met: !!client.hasPVT,
        rule: 'Client has PVT from CRA',
        result: client.hasPVT ? 'PVT present' : 'No PVT - EXCLUDED',
        critical: true
      });
    }

    return criteria;
  };

  const evaluateCAMCriteria = (client: ClientForPopulation) => {
    const criteria = [];
    
    // Base requirement
    criteria.push({
      met: client.status === 'Active',
      rule: 'Client is in Active status',
      result: client.status === 'Active' ? 'Active' : 'Closed - EXCLUDED',
      critical: true
    });

    // High risk requirement
    criteria.push({
      met: client.riskRating === 'High',
      rule: 'Risk Rating must be High (at time of case creation)',
      result: client.riskRating === 'High' ? 'High risk ✓' : `${client.riskRating} - EXCLUDED`,
      critical: true
    });

    return criteria;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2>Population Identification Engine</h2>
          <p className="text-muted-foreground">Real-time evaluation of CAM 312 and CAM population criteria</p>
        </div>
        <Button>
          <PlayCircle className="mr-2 h-4 w-4" />
          Run Identification
        </Button>
      </div>

      {/* Summary Statistics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Clients</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{stats.totalClients}</div>
            <p className="text-xs text-muted-foreground">
              {stats.activeClients} active, {stats.closedClients} closed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">312 Population</CardTitle>
            <Shield className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-blue-600">{stats.in312Population}</div>
            <Progress value={(stats.in312Population / stats.totalClients) * 100} className="h-1 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">CAM Population</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-red-600">{stats.inCAMPopulation}</div>
            <Progress value={(stats.inCAMPopulation / stats.totalClients) * 100} className="h-1 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Both Populations</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-600">{stats.inBothPopulations}</div>
            <p className="text-xs text-muted-foreground">
              {stats.excluded} excluded
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Distribution Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Population by Line of Business</CardTitle>
            <CardDescription>Client distribution across LOBs</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {stats.byLOB.map((lob) => (
              <div key={lob.lob} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">{lob.lob}</span>
                  <span className="text-muted-foreground">{lob.count} clients</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="p-2 bg-blue-50 border border-blue-200 rounded text-center">
                    <div className="text-blue-700 font-medium">{lob.in312}</div>
                    <div className="text-blue-600">312</div>
                  </div>
                  <div className="p-2 bg-red-50 border border-red-200 rounded text-center">
                    <div className="text-red-700 font-medium">{lob.inCAM}</div>
                    <div className="text-red-600">CAM</div>
                  </div>
                  <div className="p-2 bg-muted border rounded text-center">
                    <div className="font-medium">{lob.count - Math.max(lob.in312, lob.inCAM)}</div>
                    <div className="text-muted-foreground">Excluded</div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">FLU System Distribution</CardTitle>
            <CardDescription>Clients by source FLU system</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {stats.byFLUSystem.map((flu) => (
              <div key={flu.system} className="flex items-center justify-between p-3 border rounded-md">
                <div className="flex items-center gap-2">
                  <Database className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">{flu.system}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{flu.count}</span>
                  <Badge variant="outline">{((flu.count / stats.totalClients) * 100).toFixed(0)}%</Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="evaluation" className="space-y-4">
        <TabsList>
          <TabsTrigger value="evaluation">Population Evaluation Results</TabsTrigger>
          <TabsTrigger value="details">Criteria Evaluation Details</TabsTrigger>
        </TabsList>

        <TabsContent value="evaluation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Client Population Decisions</CardTitle>
              <CardDescription>Click a row to see detailed criteria evaluation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client Name</TableHead>
                      <TableHead>LOB</TableHead>
                      <TableHead>FLU System</TableHead>
                      <TableHead>Risk</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Population(s)</TableHead>
                      <TableHead>Days to Refresh</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {clients.map((client) => (
                      <TableRow 
                        key={client.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => setSelectedClient(client)}
                      >
                        <TableCell className="font-medium">{client.legalName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{client.lob}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Database className="h-3 w-3" />
                            {client.fluSystem}
                          </div>
                        </TableCell>
                        <TableCell>{getRiskBadge(client.riskRating)}</TableCell>
                        <TableCell>
                          <Badge variant={client.status === 'Active' ? 'default' : 'secondary'}>
                            {client.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{getPopulationBadge(client.in312Population, client.inCAMPopulation)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            {client.daysToRefresh} days
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="details" className="space-y-4">
          {!selectedClient ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Select a client from the "Population Evaluation Results" tab to view detailed criteria evaluation
              </AlertDescription>
            </Alert>
          ) : (
            <>
              {/* Client Overview */}
              <Card className="border-l-4 border-l-primary">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{selectedClient.legalName}</CardTitle>
                      <CardDescription className="mt-2 space-x-2">
                        <Badge variant="outline">{selectedClient.clientId}</Badge>
                        <Badge variant="outline">{selectedClient.lob}</Badge>
                        <Badge variant="outline">{selectedClient.fluSystem}</Badge>
                        {getRiskBadge(selectedClient.riskRating)}
                        {selectedClient.employeeAffiliate && (
                          <Badge variant="secondary">Employee/Affiliate</Badge>
                        )}
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => setSelectedClient(null)}>
                      Clear Selection
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3 md:grid-cols-4">
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">GCI Number</div>
                      <div className="font-medium">{selectedClient.gciNumber}</div>
                    </div>
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">Sales Owner</div>
                      <div className="font-medium text-sm">{selectedClient.salesOwner}</div>
                    </div>
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">Refresh Due Date</div>
                      <div className="font-medium">{selectedClient.refreshDueDate}</div>
                      <div className="text-xs text-muted-foreground">{selectedClient.daysToRefresh} days</div>
                    </div>
                    <div className="p-3 bg-muted rounded-md">
                      <div className="text-xs text-muted-foreground">312 Flag</div>
                      <div className="font-medium">{selectedClient.has312Flag ? 'YES' : 'NO'}</div>
                      {selectedClient.hasPVT !== undefined && (
                        <div className="text-xs text-muted-foreground">PVT: {selectedClient.hasPVT ? 'Yes' : 'No'}</div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* 312 Population Evaluation */}
              <Card className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Shield className="h-5 w-5 text-blue-600" />
                        CAM 312 Population Criteria Evaluation
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {selectedClient.lob === 'GB/GM' && 'GB/GM: Risk rating + timing criteria + 312 flag'}
                        {(selectedClient.lob === 'PB' || selectedClient.lob === 'ML') && `${selectedClient.lob}: High risk + 180 days + PVT + 312 flag`}
                        {selectedClient.lob !== 'GB/GM' && selectedClient.lob !== 'PB' && selectedClient.lob !== 'ML' && 'Not applicable for this LOB'}
                      </CardDescription>
                    </div>
                    {getPopulationBadge(selectedClient.in312Population, false)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {evaluate312Criteria(selectedClient).map((criterion, index) => (
                    <div key={index} className={`flex items-start gap-3 p-3 border rounded-md ${
                      criterion.met ? 'bg-green-50 border-green-200' : 
                      criterion.critical ? 'bg-red-50 border-red-200' : 'bg-muted'
                    }`}>
                      {criterion.met ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      ) : (
                        <XCircle className={`h-5 w-5 mt-0.5 flex-shrink-0 ${criterion.critical ? 'text-red-600' : 'text-muted-foreground'}`} />
                      )}
                      <div className="flex-1">
                        <div className="text-sm font-medium">{criterion.rule}</div>
                        <div className={`text-xs mt-1 ${
                          criterion.met ? 'text-green-700' : 
                          criterion.critical ? 'text-red-700' : 'text-muted-foreground'
                        }`}>
                          {criterion.result}
                        </div>
                      </div>
                      {!criterion.critical && (
                        <Badge variant="outline" className="text-xs">Optional</Badge>
                      )}
                    </div>
                  ))}

                  {selectedClient.in312Population && (
                    <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-200 rounded-md mt-3">
                      <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-blue-900">Decision: Included in 312 Population</div>
                        <div className="text-blue-700 mt-1">{selectedClient.cam312Reason}</div>
                      </div>
                    </div>
                  )}

                  {!selectedClient.in312Population && selectedClient.exclusionReason && (
                    <div className="flex items-start gap-2 p-3 bg-gray-50 border border-gray-200 rounded-md mt-3">
                      <XCircle className="h-4 w-4 text-gray-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">Decision: Excluded from 312 Population</div>
                        <div className="text-gray-700 mt-1">{selectedClient.exclusionReason}</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* CAM Population Evaluation */}
              <Card className="border-l-4 border-l-destructive">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Zap className="h-5 w-5 text-destructive" />
                        CAM Population Criteria Evaluation
                      </CardTitle>
                      <CardDescription className="mt-1">
                        Simple logic: High risk + Active status (all LOBs)
                      </CardDescription>
                    </div>
                    {getPopulationBadge(false, selectedClient.inCAMPopulation)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {evaluateCAMCriteria(selectedClient).map((criterion, index) => (
                    <div key={index} className={`flex items-start gap-3 p-3 border rounded-md ${
                      criterion.met ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                    }`}>
                      {criterion.met ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
                      )}
                      <div className="flex-1">
                        <div className="text-sm font-medium">{criterion.rule}</div>
                        <div className={`text-xs mt-1 ${criterion.met ? 'text-green-700' : 'text-red-700'}`}>
                          {criterion.result}
                        </div>
                      </div>
                    </div>
                  ))}

                  {selectedClient.inCAMPopulation && (
                    <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-md mt-3">
                      <CheckCircle2 className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-red-900">Decision: Included in CAM Population</div>
                        <div className="text-red-700 mt-1">{selectedClient.camReason}</div>
                      </div>
                    </div>
                  )}

                  {!selectedClient.inCAMPopulation && (
                    <div className="flex items-start gap-2 p-3 bg-gray-50 border border-gray-200 rounded-md mt-3">
                      <XCircle className="h-4 w-4 text-gray-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">Decision: Excluded from CAM Population</div>
                        <div className="text-gray-700 mt-1">
                          {selectedClient.riskRating !== 'High' && 'Client does not have High risk rating. '}
                          {selectedClient.status !== 'Active' && 'Client status is not Active. '}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Summary */}
              {selectedClient.in312Population && selectedClient.inCAMPopulation && (
                <Card className="border-l-4 border-l-gold">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-gold" />
                      Population Summary
                    </CardTitle>
                    <CardDescription>This client is included in both populations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Alert>
                      <CheckCircle2 className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Dual Population:</strong> This client will have both CAM 312 and CAM cases created. 
                        The CAM 312 case evaluates 312 model activity, while the CAM case performs comprehensive activity monitoring.
                        Both cases will be created simultaneously at the trigger timing.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
