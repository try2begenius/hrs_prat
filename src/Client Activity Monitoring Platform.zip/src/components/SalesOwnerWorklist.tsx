import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Search, Download, Eye, ArrowUpDown, ArrowUp, ArrowDown, Building2, UserCircle, Clock } from 'lucide-react';
import { mockCases } from '../data/enhancedMockData';
import { Case, CaseStatus, RiskLevel, LineOfBusiness } from '../types';
import { UserAccess } from '../data/rolesEntitlementsMockData';

interface SalesOwnerWorklistProps {
  onViewCase: (caseId: string) => void;
  currentUser: UserAccess;
}

type SortField = 'id' | 'clientName' | 'status' | 'createdDate' | 'dueDate' | 'centralTeamContact' | 'riskLevel' | 'lineOfBusiness';
type SortDirection = 'asc' | 'desc' | null;

export function SalesOwnerWorklist({ onViewCase, currentUser }: SalesOwnerWorklistProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [lobFilter, setLobFilter] = useState<string>('all');
  const [contactFilter, setContactFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('createdDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  // Filter to only cases where the current user is the Sales Owner
  const mySalesAssignedCases = mockCases.filter(c => {
    // Must be the sales owner for this client
    if (c.clientData?.salesOwner !== currentUser.name) return false;
    
    // Filter by case type access
    if (c.caseType === '312 Review' && !currentUser.entitlements.has312Access) return false;
    if (c.caseType === 'CAM Review' && !currentUser.entitlements.hasCAMAccess) return false;
    
    // Filter employee cases
    if (c.clientData?.isEmployee && !currentUser.entitlements.hasEmployeeCaseAccess) return false;
    
    return true;
  });

  // Get today's date for past due calculation
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Get unique central team contacts for filter
  const centralTeamContacts = useMemo(() => {
    const contacts = new Set<string>();
    mySalesAssignedCases.forEach(c => {
      if (c.centralTeamContact) {
        contacts.add(c.centralTeamContact);
      }
    });
    return Array.from(contacts).sort();
  }, [mySalesAssignedCases]);

  // Apply filters and sorting
  const filteredAndSortedCases = useMemo(() => {
    let filtered = mySalesAssignedCases.filter(caseItem => {
      // Search filter
      const matchesSearch = 
        caseItem.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.gci?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.clientId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        caseItem.coperId?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || caseItem.status === statusFilter;
      const matchesRisk = riskFilter === 'all' || caseItem.riskLevel === riskFilter;
      const matchesLOB = lobFilter === 'all' || caseItem.lineOfBusiness === lobFilter;
      const matchesContact = contactFilter === 'all' || caseItem.centralTeamContact === contactFilter;

      return matchesSearch && matchesStatus && matchesRisk && matchesLOB && matchesContact;
    });

    // Sort cases
    if (sortField && sortDirection) {
      filtered.sort((a, b) => {
        let aVal: any;
        let bVal: any;

        switch (sortField) {
          case 'id':
            aVal = a.id;
            bVal = b.id;
            break;
          case 'clientName':
            aVal = a.clientName;
            bVal = b.clientName;
            break;
          case 'status':
            aVal = a.status;
            bVal = b.status;
            break;
          case 'createdDate':
            aVal = new Date(a.createdDate);
            bVal = new Date(b.createdDate);
            break;
          case 'dueDate':
            aVal = new Date(a.dueDate);
            bVal = new Date(b.dueDate);
            break;
          case 'centralTeamContact':
            aVal = a.centralTeamContact || '';
            bVal = b.centralTeamContact || '';
            break;
          case 'riskLevel':
            const riskOrder = { 'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
            aVal = riskOrder[a.riskLevel];
            bVal = riskOrder[b.riskLevel];
            break;
          case 'lineOfBusiness':
            aVal = a.lineOfBusiness || '';
            bVal = b.lineOfBusiness || '';
            break;
          default:
            return 0;
        }

        if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [mySalesAssignedCases, searchTerm, statusFilter, riskFilter, lobFilter, contactFilter, sortField, sortDirection]);

  // Get status counts for quick stats
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    mySalesAssignedCases.forEach(c => {
      counts[c.status] = (counts[c.status] || 0) + 1;
    });
    return counts;
  }, [mySalesAssignedCases]);

  const pastDueCount = mySalesAssignedCases.filter(c => {
    const dueDate = new Date(c.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    return dueDate < today;
  }).length;

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else if (sortDirection === 'desc') {
        setSortDirection(null);
        setSortField('createdDate');
      } else {
        setSortDirection('asc');
      }
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-3 w-3 opacity-50" />;
    if (sortDirection === 'asc') return <ArrowUp className="h-3 w-3" />;
    if (sortDirection === 'desc') return <ArrowDown className="h-3 w-3" />;
    return <ArrowUpDown className="h-3 w-3 opacity-50" />;
  };

  const getRiskBadgeVariant = (risk: RiskLevel) => {
    switch (risk) {
      case 'Critical': return 'destructive';
      case 'High': return 'default';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
    }
  };

  const getStatusColor = (status: CaseStatus) => {
    switch (status) {
      case 'Unassigned': return 'bg-gray-100 text-gray-800';
      case 'In Progress': return 'bg-amber-100 text-amber-800';
      case 'Pending Sales Review': return 'bg-blue-100 text-blue-800';
      case 'In Sales Review': return 'bg-purple-100 text-purple-800';
      case 'Sales Review Complete': return 'bg-indigo-100 text-indigo-800';
      case 'Complete': return 'bg-green-100 text-green-800';
      case 'Defect Remediation': return 'bg-red-100 text-red-800';
      case 'Under Review': return 'bg-purple-100 text-purple-800';
      case 'Escalated': return 'bg-destructive/10 text-destructive';
      case 'Closed': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-gray-100 text-gray-800';
    }
  };

  const formatLOB = (lob?: LineOfBusiness) => {
    if (!lob) return '-';
    const lobMap: Record<LineOfBusiness, string> = {
      'GB/GM': 'GB/GM',
      'PB': 'PB',
      'ML': 'ML',
      'Consumer': 'Consumer',
      'CI': 'CI'
    };
    return lobMap[lob] || lob;
  };

  const isPastDue = (dueDate: string) => {
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    return due < today;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground">
            Sales review cases assigned to you - all stages and statuses
          </p>
        </div>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Export My Cases
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Cases</CardTitle>
            <UserCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mySalesAssignedCases.length}</div>
            <p className="text-xs text-muted-foreground">
              For sales review
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statusCounts['Pending Sales Review'] || 0}</div>
            <p className="text-xs text-muted-foreground">
              Awaiting your review
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Review</CardTitle>
            <Clock className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{statusCounts['In Sales Review'] || 0}</div>
            <p className="text-xs text-muted-foreground">
              Currently reviewing
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Past Due</CardTitle>
            <Clock className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{pastDueCount}</div>
            <p className="text-xs text-muted-foreground">
              Requires attention
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="card-elevated">
        <CardHeader className="border-b bg-muted/30">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Sales Review Cases</CardTitle>
              <CardDescription className="mt-1">
                <span className="font-medium text-primary">{filteredAndSortedCases.length}</span> of {mySalesAssignedCases.length} cases
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search case, client, GCI, CoPer..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="Pending Sales Review">Pending Sales Review</SelectItem>
                <SelectItem value="In Sales Review">In Sales Review</SelectItem>
                <SelectItem value="Sales Review Complete">Sales Review Complete</SelectItem>
              </SelectContent>
            </Select>

            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Risk Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select value={lobFilter} onValueChange={setLobFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All LOBs" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All LOBs</SelectItem>
                <SelectItem value="GB/GM">GB/GM</SelectItem>
                <SelectItem value="PB">Private Bank</SelectItem>
                <SelectItem value="ML">Merrill Lynch</SelectItem>
                <SelectItem value="Consumer">Consumer</SelectItem>
                <SelectItem value="CI">CI</SelectItem>
              </SelectContent>
            </Select>

            <Select value={contactFilter} onValueChange={setContactFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Contacts" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Contacts</SelectItem>
                {centralTeamContacts.map(contact => (
                  <SelectItem key={contact} value={contact}>
                    {contact}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Cases Table */}
          <div className="rounded-md border overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    <TableHead className="font-semibold min-w-[140px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('id')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Case Number
                        <SortIcon field="id" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[180px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('clientName')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Client Name
                        <SortIcon field="clientName" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[120px]">GCI</TableHead>
                    <TableHead className="font-semibold min-w-[100px]">Client ID</TableHead>
                    <TableHead className="font-semibold min-w-[100px]">CoPer ID</TableHead>
                    <TableHead className="font-semibold min-w-[140px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('status')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Case Status
                        <SortIcon field="status" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[120px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('createdDate')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Created Date
                        <SortIcon field="createdDate" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[120px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('dueDate')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Due Date
                        <SortIcon field="dueDate" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[160px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('centralTeamContact')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Central Team Contact
                        <SortIcon field="centralTeamContact" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[100px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('lineOfBusiness')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        LOB
                        <SortIcon field="lineOfBusiness" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[100px]">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleSort('riskLevel')}
                        className="h-8 px-2 hover:bg-muted/50"
                      >
                        Risk Rating
                        <SortIcon field="riskLevel" />
                      </Button>
                    </TableHead>
                    <TableHead className="font-semibold min-w-[100px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAndSortedCases.map((caseItem) => {
                    const pastDue = isPastDue(caseItem.dueDate);

                    return (
                      <TableRow 
                        key={caseItem.id} 
                        className={`hover:bg-muted/30 transition-colors ${pastDue ? 'bg-red-50' : ''}`}
                      >
                        <TableCell>
                          <button 
                            onClick={() => onViewCase(caseItem.id)}
                            className="font-mono text-sm font-medium text-primary hover:underline hover:text-primary/80 transition-colors text-left"
                          >
                            {caseItem.id}
                          </button>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{caseItem.clientName}</div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{caseItem.gci || '-'}</TableCell>
                        <TableCell className="font-mono text-sm text-muted-foreground">{caseItem.clientId || '-'}</TableCell>
                        <TableCell className="font-mono text-sm text-muted-foreground">
                          {caseItem.coperId || <span className="text-gray-400">N/A</span>}
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(caseItem.status) + ' border-0'} variant="outline">
                            {caseItem.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{caseItem.createdDate}</TableCell>
                        <TableCell className="text-sm">
                          <div className={`flex items-center gap-1 ${pastDue ? 'text-red-600 font-medium' : ''}`}>
                            {pastDue && <Clock className="h-3 w-3" />}
                            {caseItem.dueDate}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-2">
                            <UserCircle className="h-3 w-3 text-muted-foreground" />
                            {caseItem.centralTeamContact || <span className="text-gray-400">Not Set</span>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="border-blue-200 text-blue-800 bg-blue-50">
                            <Building2 className="h-3 w-3 mr-1" />
                            {formatLOB(caseItem.lineOfBusiness)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={getRiskBadgeVariant(caseItem.riskLevel)}
                            className={
                              caseItem.riskLevel === 'Critical' ? 'bg-red-600 text-white' : 
                              caseItem.riskLevel === 'High' ? 'bg-red-100 text-red-800 border-red-200' :
                              caseItem.riskLevel === 'Medium' ? 'bg-amber-100 text-amber-800 border-amber-200' :
                              'bg-green-100 text-green-800 border-green-200'
                            }
                          >
                            {caseItem.riskLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onViewCase(caseItem.id)}
                            className="hover:bg-primary/10 hover:text-primary"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>

          {filteredAndSortedCases.length === 0 && (
            <div className="py-12 text-center text-muted-foreground">
              {mySalesAssignedCases.length === 0 ? (
                <div>
                  <p className="text-lg">No cases assigned for sales review</p>
                  <p className="text-sm mt-2">Cases will appear here when central team analysts route them for your feedback.</p>
                </div>
              ) : (
                'No cases match your filters'
              )}
            </div>
          )}

          {/* Results summary */}
          {filteredAndSortedCases.length > 0 && (
            <div className="text-sm text-muted-foreground">
              Showing {filteredAndSortedCases.length} case{filteredAndSortedCases.length !== 1 ? 's' : ''}
              {sortField && sortDirection && (
                <span> • Sorted by {sortField} ({sortDirection === 'asc' ? 'ascending' : 'descending'})</span>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
