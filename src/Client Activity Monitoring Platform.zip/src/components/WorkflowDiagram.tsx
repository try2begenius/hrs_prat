import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { AlertCircle, CheckCircle2, Clock, XCircle, ArrowRight, ArrowDown, Users, FileText, TrendingUp, AlertTriangle } from 'lucide-react';

export function WorkflowDiagram() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-foreground mb-2">312 CAM Workflow Diagram</h1>
        <p className="text-muted-foreground">
          Visual representation of the complete case lifecycle from creation through closure
        </p>
      </div>

      <Tabs defaultValue="312-workflow" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="312-workflow">312 Case Flow</TabsTrigger>
          <TabsTrigger value="sales-review">Sales Review Flow</TabsTrigger>
          <TabsTrigger value="cam-escalation">CAM Escalation Flow</TabsTrigger>
        </TabsList>

        {/* 312 CASE WORKFLOW */}
        <TabsContent value="312-workflow" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>312 Case Workflow - Complete Lifecycle</CardTitle>
              <CardDescription>
                Shows all possible paths from case creation to completion
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {/* START */}
                <div className="flex flex-col items-center">
                  <div className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold text-center">
                    312 Population Identified
                  </div>
                  <ArrowDown className="h-6 w-6 text-muted-foreground my-2" />
                  <div className="bg-card border-2 border-primary px-6 py-3 rounded-lg font-semibold text-center">
                    Case Created
                  </div>
                </div>

                {/* DECISION POINT 1: AUTO-CLOSE CHECK */}
                <div className="flex items-start gap-4 justify-center">
                  <div className="flex-1 max-w-md">
                    <div className="bg-yellow-50 border-2 border-yellow-500 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertCircle className="h-5 w-5 text-yellow-700" />
                        <span className="font-semibold text-yellow-900">Decision Point</span>
                      </div>
                      <p className="text-sm text-yellow-800">
                        Model evaluates risk level and activity alignment
                      </p>
                    </div>
                  </div>
                </div>

                {/* TWO PATHS */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* LEFT PATH - AUTO CLOSE */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-green-700">
                      <CheckCircle2 className="h-5 w-5" />
                      <span className="font-semibold">Path 1: Auto-Close</span>
                    </div>
                    
                    <Card className="border-green-500 border-2 bg-green-50">
                      <CardContent className="pt-6">
                        <div className="space-y-3">
                          <Badge className="bg-green-600">Low Risk</Badge>
                          <p className="text-sm text-green-900">
                            Activity within expected parameters
                          </p>
                          <ArrowDown className="h-5 w-5 text-green-700 mx-auto" />
                          <div className="bg-green-100 p-3 rounded text-center">
                            <p className="font-semibold text-green-900">Status: Auto-Closed</p>
                            <p className="text-xs text-green-700 mt-1">Assigned to: System</p>
                          </div>
                          <ArrowDown className="h-5 w-5 text-green-700 mx-auto" />
                          <div className="bg-green-600 text-white p-3 rounded text-center font-semibold">
                            COMPLETE
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="bg-blue-50 border border-blue-200 rounded p-3">
                      <p className="text-xs font-semibold text-blue-900 mb-1">Test Case:</p>
                      <p className="text-xs text-blue-700">312-2025-AUTO-100</p>
                      <p className="text-xs text-blue-600">Client: Reliable Logistics Corp</p>
                    </div>
                  </div>

                  {/* RIGHT PATH - MANUAL REVIEW */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-blue-700">
                      <Clock className="h-5 w-5" />
                      <span className="font-semibold">Path 2: Manual Review</span>
                    </div>
                    
                    <Card className="border-blue-500 border-2 bg-blue-50">
                      <CardContent className="pt-6">
                        <div className="space-y-3">
                          <Badge className="bg-orange-600">Medium/High/Critical Risk</Badge>
                          <p className="text-sm text-blue-900">
                            Requires analyst review
                          </p>
                          
                          {/* Step 1 */}
                          <ArrowDown className="h-5 w-5 text-blue-700 mx-auto" />
                          <div className="bg-gray-100 p-3 rounded">
                            <p className="font-semibold text-gray-900">Status: Unassigned</p>
                            <p className="text-xs text-gray-600 mt-1">In Workbasket</p>
                          </div>

                          {/* Step 2 */}
                          <ArrowDown className="h-5 w-5 text-blue-700 mx-auto" />
                          <div className="bg-blue-100 p-3 rounded">
                            <p className="font-semibold text-blue-900">Manager Assigns Case</p>
                            <p className="text-xs text-blue-700 mt-1">To Central Team Analyst</p>
                          </div>

                          {/* Step 3 */}
                          <ArrowDown className="h-5 w-5 text-blue-700 mx-auto" />
                          <div className="bg-blue-200 p-3 rounded">
                            <p className="font-semibold text-blue-900">Status: In Progress</p>
                            <p className="text-xs text-blue-700 mt-1">Analyst reviews data</p>
                          </div>

                          {/* Decision Point 2 */}
                          <ArrowDown className="h-5 w-5 text-blue-700 mx-auto" />
                          <div className="bg-yellow-50 border border-yellow-400 p-3 rounded">
                            <p className="text-xs font-semibold text-yellow-900">Decision: Sales Input Needed?</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="bg-blue-50 border border-blue-200 rounded p-3">
                      <p className="text-xs font-semibold text-blue-900 mb-1">Test Cases:</p>
                      <p className="text-xs text-blue-700">312-2025-UNASSIGN-200 (Unassigned)</p>
                      <p className="text-xs text-blue-700">312-2025-PROG-300 (In Progress)</p>
                    </div>
                  </div>
                </div>

                {/* CONTINUATION - After Manual Review Decision */}
                <div className="border-t-2 pt-6">
                  <p className="text-center text-muted-foreground mb-4 italic">
                    After analyst reviews case (In Progress)...
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* NO SALES REVIEW PATH */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-purple-700">
                        <CheckCircle2 className="h-5 w-5" />
                        <span className="font-semibold">Path 2A: Direct Completion</span>
                      </div>
                      
                      <Card className="border-purple-500 border-2 bg-purple-50">
                        <CardContent className="pt-6">
                          <div className="space-y-3">
                            <div className="bg-purple-100 p-3 rounded">
                              <p className="text-sm text-purple-900">
                                Analyst has sufficient information
                              </p>
                              <p className="text-xs text-purple-700 mt-1">
                                No sales context needed
                              </p>
                            </div>
                            
                            <ArrowDown className="h-5 w-5 text-purple-700 mx-auto" />
                            
                            <div className="bg-purple-200 p-3 rounded">
                              <p className="font-semibold text-purple-900">Analyst Completes Disposition</p>
                              <ul className="text-xs text-purple-700 mt-2 space-y-1">
                                <li>• No additional CAM escalation</li>
                                <li>• OR: Route to CAM Review</li>
                                <li>• OR: TRMS Filed</li>
                                <li>• OR: Client Closed</li>
                              </ul>
                            </div>
                            
                            <ArrowDown className="h-5 w-5 text-purple-700 mx-auto" />
                            
                            <div className="bg-purple-600 text-white p-3 rounded text-center font-semibold">
                              Status: COMPLETE
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <div className="bg-purple-50 border border-purple-200 rounded p-3">
                        <p className="text-xs font-semibold text-purple-900 mb-1">Test Cases:</p>
                        <p className="text-xs text-purple-700">312-2025-COMP-700 (No Escalation)</p>
                        <p className="text-xs text-purple-700">312-2025-ESC-800 (TRMS Filed)</p>
                        <p className="text-xs text-purple-700">312-2025-ESC-900 (Client Closed)</p>
                      </div>
                    </div>

                    {/* SALES REVIEW PATH */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-orange-700">
                        <Users className="h-5 w-5" />
                        <span className="font-semibold">Path 2B: Sales Review</span>
                      </div>
                      
                      <Card className="border-orange-500 border-2 bg-orange-50">
                        <CardContent className="pt-6">
                          <div className="space-y-3">
                            <div className="bg-orange-100 p-3 rounded">
                              <p className="text-sm text-orange-900">
                                Sales context required
                              </p>
                              <p className="text-xs text-orange-700 mt-1">
                                Only for GB/GM, PB, ML LOBs
                              </p>
                            </div>
                            
                            <ArrowDown className="h-5 w-5 text-orange-700 mx-auto" />
                            
                            <div className="bg-orange-200 p-3 rounded">
                              <p className="font-semibold text-orange-900">Status: Pending Sales Review</p>
                              <p className="text-xs text-orange-700 mt-1">
                                Case sent to Sales Owner
                              </p>
                            </div>
                            
                            <ArrowDown className="h-5 w-5 text-orange-700 mx-auto" />
                            
                            <div className="bg-orange-300 p-3 rounded">
                              <p className="font-semibold text-orange-900">Status: In Sales Review</p>
                              <p className="text-xs text-orange-800 mt-1">
                                Sales Owner provides context
                              </p>
                            </div>
                            
                            <ArrowDown className="h-5 w-5 text-orange-700 mx-auto" />
                            
                            <div className="bg-orange-200 p-3 rounded">
                              <p className="font-semibold text-orange-900">Status: Sales Review Complete</p>
                              <p className="text-xs text-orange-700 mt-1">
                                Returns to Analyst
                              </p>
                            </div>
                            
                            <ArrowDown className="h-5 w-5 text-orange-700 mx-auto" />
                            
                            <div className="bg-orange-600 text-white p-3 rounded text-center font-semibold">
                              Analyst Completes → COMPLETE
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <div className="bg-orange-50 border border-orange-200 rounded p-3">
                        <p className="text-xs font-semibold text-orange-900 mb-1">Test Cases:</p>
                        <p className="text-xs text-orange-700">312-2025-PSR-400 (Pending Sales)</p>
                        <p className="text-xs text-orange-700">312-2025-ISR-500 (In Sales Review)</p>
                        <p className="text-xs text-orange-700">312-2025-SRC-600 (Sales Complete)</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* SPECIAL PATH - REMEDIATION */}
                <div className="border-t-2 pt-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-red-700">
                      <AlertTriangle className="h-5 w-5" />
                      <span className="font-semibold">Special Path: Defect Remediation</span>
                    </div>
                    
                    <Card className="border-red-500 border-2 bg-red-50">
                      <CardContent className="pt-6">
                        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center">
                          <div className="bg-green-100 p-3 rounded text-center">
                            <p className="text-sm font-semibold text-green-900">COMPLETE</p>
                            <p className="text-xs text-green-700">Case closed</p>
                          </div>
                          
                          <ArrowRight className="h-5 w-5 text-red-700 mx-auto hidden md:block" />
                          <ArrowDown className="h-5 w-5 text-red-700 mx-auto md:hidden" />
                          
                          <div className="bg-red-100 p-3 rounded text-center">
                            <p className="text-sm font-semibold text-red-900">M&I Review</p>
                            <p className="text-xs text-red-700">Quality issue found</p>
                          </div>
                          
                          <ArrowRight className="h-5 w-5 text-red-700 mx-auto hidden md:block" />
                          <ArrowDown className="h-5 w-5 text-red-700 mx-auto md:hidden" />
                          
                          <div className="bg-red-200 p-3 rounded text-center">
                            <p className="text-sm font-semibold text-red-900">Defect Remediation</p>
                            <p className="text-xs text-red-700">Case reopened</p>
                          </div>
                          
                          <ArrowRight className="h-5 w-5 text-red-700 mx-auto hidden md:block" />
                          <ArrowDown className="h-5 w-5 text-red-700 mx-auto md:hidden" />
                          
                          <div className="bg-green-100 p-3 rounded text-center">
                            <p className="text-sm font-semibold text-green-900">COMPLETE</p>
                            <p className="text-xs text-green-700">Remediation done</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="bg-red-50 border border-red-200 rounded p-3">
                      <p className="text-xs font-semibold text-red-900 mb-1">Test Case:</p>
                      <p className="text-xs text-red-700">312-2025-REM-1000 (Pacific Rim Imports)</p>
                      <p className="text-xs text-red-600 mt-1">Requires M&I entitlement to view</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SALES REVIEW WORKFLOW */}
        <TabsContent value="sales-review" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sales Owner Review Workflow</CardTitle>
              <CardDescription>
                Detailed flow of sales involvement in case review process
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Prerequisites */}
                <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Prerequisites for Sales Review</h3>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>✅ Case must be 312 Review type</li>
                    <li>✅ Line of Business: GB/GM, PB, or ML only</li>
                    <li>✅ Case must be "In Progress" status</li>
                    <li>❌ Consumer and CI LOBs cannot route to sales</li>
                  </ul>
                </div>

                {/* Flow Steps */}
                <div className="space-y-4">
                  {/* Step 1 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                        1
                      </div>
                    </div>
                    <Card className="flex-1 border-blue-300">
                      <CardContent className="pt-4">
                        <h4 className="font-semibold mb-2">Analyst Initiates Sales Review</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Central Team Analyst determines sales context is needed
                        </p>
                        <div className="bg-gray-50 p-3 rounded space-y-1">
                          <p className="text-sm"><span className="font-semibold">Action:</span> Click "Request Sales Review"</p>
                          <p className="text-sm"><span className="font-semibold">Required:</span> Case processor comments explaining questions</p>
                          <p className="text-sm"><span className="font-semibold">System:</span> Status changes to "Pending Sales Review"</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <ArrowDown className="h-6 w-6 text-muted-foreground mx-auto" />

                  {/* Step 2 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                        2
                      </div>
                    </div>
                    <Card className="flex-1 border-orange-300">
                      <CardContent className="pt-4">
                        <h4 className="font-semibold mb-2">Sales Owner Receives Case</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Case appears in Sales Owner Worklist
                        </p>
                        <div className="bg-orange-50 p-3 rounded space-y-1">
                          <p className="text-sm"><span className="font-semibold">Email:</span> Notification sent to Sales Owner</p>
                          <p className="text-sm"><span className="font-semibold">Status:</span> "Pending Sales Review" until opened</p>
                          <p className="text-sm"><span className="font-semibold">Visibility:</span> Privacy-filtered view (no transaction details)</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <ArrowDown className="h-6 w-6 text-muted-foreground mx-auto" />

                  {/* Step 3 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="bg-orange-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                        3
                      </div>
                    </div>
                    <Card className="flex-1 border-orange-400">
                      <CardContent className="pt-4">
                        <h4 className="font-semibold mb-2">Sales Owner Opens Case</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Status automatically changes when case is viewed
                        </p>
                        <div className="bg-orange-50 p-3 rounded space-y-1">
                          <p className="text-sm"><span className="font-semibold">Status:</span> Changes to "In Sales Review"</p>
                          <p className="text-sm"><span className="font-semibold">Can See:</span> Case details, 312 case info (filtered), processor comments</p>
                          <p className="text-sm"><span className="font-semibold">Cannot See:</span> Transaction details, monitoring alerts (privacy protection)</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <ArrowDown className="h-6 w-6 text-muted-foreground mx-auto" />

                  {/* Step 4 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="bg-orange-700 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                        4
                      </div>
                    </div>
                    <Card className="flex-1 border-orange-500">
                      <CardContent className="pt-4">
                        <h4 className="font-semibold mb-2">Sales Owner Provides Feedback</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Sales Owner adds business context and relationship information
                        </p>
                        <div className="bg-orange-50 p-3 rounded space-y-2">
                          <p className="text-sm"><span className="font-semibold">Options:</span></p>
                          <ul className="text-sm space-y-1 ml-4">
                            <li>• Save Draft (preserves work, status unchanged)</li>
                            <li>• Return to AML Processor (submits response, status changes)</li>
                          </ul>
                          <p className="text-sm"><span className="font-semibold">Character Limit:</span> 4000 characters</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <ArrowDown className="h-6 w-6 text-muted-foreground mx-auto" />

                  {/* Step 5 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="bg-green-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                        5
                      </div>
                    </div>
                    <Card className="flex-1 border-green-300">
                      <CardContent className="pt-4">
                        <h4 className="font-semibold mb-2">Returned to Analyst</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Case returns to Central Team Analyst with sales feedback
                        </p>
                        <div className="bg-green-50 p-3 rounded space-y-1">
                          <p className="text-sm"><span className="font-semibold">Status:</span> "Sales Review Complete"</p>
                          <p className="text-sm"><span className="font-semibold">Email:</span> Notification sent to Analyst</p>
                          <p className="text-sm"><span className="font-semibold">Sales Response:</span> Locked and visible to Analyst</p>
                          <p className="text-sm"><span className="font-semibold">Next Step:</span> Analyst completes disposition</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <ArrowDown className="h-6 w-6 text-muted-foreground mx-auto" />

                  {/* Step 6 */}
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center font-semibold">
                        6
                      </div>
                    </div>
                    <Card className="flex-1 border-primary">
                      <CardContent className="pt-4">
                        <h4 className="font-semibold mb-2">Analyst Completes Case</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Analyst reviews sales feedback and makes final disposition
                        </p>
                        <div className="bg-blue-50 p-3 rounded space-y-1">
                          <p className="text-sm"><span className="font-semibold">Status:</span> Changes to "Complete"</p>
                          <p className="text-sm"><span className="font-semibold">Disposition Options:</span> No escalation, TRMS Filed, Client Closed, etc.</p>
                          <p className="text-sm"><span className="font-semibold">Email:</span> Completion notification sent</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Test Cases Reference */}
                <div className="bg-gray-50 border-2 border-gray-300 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Test This Workflow</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="bg-white p-3 rounded border">
                      <p className="text-xs font-semibold text-gray-900">Step 1-2: Pending</p>
                      <p className="text-xs text-gray-700 mt-1">Case: 312-2025-PSR-400</p>
                      <p className="text-xs text-gray-600">User: Jennifer Wu</p>
                    </div>
                    <div className="bg-white p-3 rounded border">
                      <p className="text-xs font-semibold text-gray-900">Step 3-4: In Review</p>
                      <p className="text-xs text-gray-700 mt-1">Case: 312-2025-ISR-500</p>
                      <p className="text-xs text-gray-600">User: David Park</p>
                    </div>
                    <div className="bg-white p-3 rounded border">
                      <p className="text-xs font-semibold text-gray-900">Step 5-6: Complete</p>
                      <p className="text-xs text-gray-700 mt-1">Case: 312-2025-SRC-600</p>
                      <p className="text-xs text-gray-600">User: Jennifer Wu</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* CAM ESCALATION WORKFLOW */}
        <TabsContent value="cam-escalation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>CAM Case Escalation Workflow</CardTitle>
              <CardDescription>
                Escalation paths and outcomes for 312 cases requiring additional action
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Starting Point */}
                <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4 text-center">
                  <p className="font-semibold text-blue-900">312 Case Completed</p>
                  <p className="text-sm text-blue-700 mt-1">Analyst determines disposition</p>
                </div>

                {/* Four Outcome Paths */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Outcome 1: No Escalation */}
                  <Card className="border-green-500 border-2 bg-green-50">
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-700" />
                        <CardTitle className="text-lg">Outcome 1: No Escalation</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="bg-green-100 p-3 rounded">
                          <p className="text-sm font-semibold text-green-900">Disposition</p>
                          <p className="text-xs text-green-800 mt-1">
                            "No additional CAM escalation required"
                          </p>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <p className="font-semibold text-green-900">When Used:</p>
                          <ul className="text-xs text-green-800 space-y-1 ml-4">
                            <li>• Activity explained by DDQ/business model</li>
                            <li>• No red flags identified</li>
                            <li>• Risk within acceptable parameters</li>
                          </ul>
                        </div>
                        
                        <div className="bg-green-200 p-2 rounded">
                          <p className="text-xs font-semibold text-green-900">No CAM Case Created</p>
                        </div>

                        <div className="bg-white border border-green-300 p-2 rounded">
                          <p className="text-xs font-semibold">Test Case:</p>
                          <p className="text-xs text-green-700">312-2025-COMP-700</p>
                          <p className="text-xs text-green-600">Northeast Distribution LLC</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Outcome 2: CAM Review */}
                  <Card className="border-blue-500 border-2 bg-blue-50">
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-2">
                        <FileText className="h-5 w-5 text-blue-700" />
                        <CardTitle className="text-lg">Outcome 2: CAM Review</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="bg-blue-100 p-3 rounded">
                          <p className="text-sm font-semibold text-blue-900">Disposition</p>
                          <p className="text-xs text-blue-800 mt-1">
                            "Route to CAM Review"
                          </p>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <p className="font-semibold text-blue-900">When Used:</p>
                          <ul className="text-xs text-blue-800 space-y-1 ml-4">
                            <li>• Requires enhanced monitoring</li>
                            <li>• Pattern needs ongoing review</li>
                            <li>• Not urgent but warrants tracking</li>
                          </ul>
                        </div>
                        
                        <ArrowDown className="h-5 w-5 text-blue-700 mx-auto" />
                        
                        <div className="bg-blue-200 p-3 rounded">
                          <p className="text-xs font-semibold text-blue-900">CAM Case Created</p>
                          <p className="text-xs text-blue-700 mt-1">Separate case for ongoing monitoring</p>
                        </div>

                        <div className="bg-white border border-blue-300 p-2 rounded">
                          <p className="text-xs font-semibold">Test Case:</p>
                          <p className="text-xs text-blue-700">Available in case scenarios</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Outcome 3: TRMS Investigation */}
                  <Card className="border-red-500 border-2 bg-red-50">
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-5 w-5 text-red-700" />
                        <CardTitle className="text-lg">Outcome 3: TRMS Investigation</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="bg-red-100 p-3 rounded">
                          <p className="text-sm font-semibold text-red-900">Disposition</p>
                          <p className="text-xs text-red-800 mt-1">
                            "TRMS Filed"
                          </p>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <p className="font-semibold text-red-900">When Used:</p>
                          <ul className="text-xs text-red-800 space-y-1 ml-4">
                            <li>• Suspicious activity identified</li>
                            <li>• Potential AML/BSA violation</li>
                            <li>• May require SAR filing</li>
                            <li>• Enhanced due diligence needed</li>
                          </ul>
                        </div>
                        
                        <ArrowDown className="h-5 w-5 text-red-700 mx-auto" />
                        
                        <div className="bg-red-200 p-3 rounded space-y-2">
                          <p className="text-xs font-semibold text-red-900">TRMS Case Created</p>
                          <div className="bg-red-300 p-2 rounded">
                            <p className="text-xs text-red-900">Case Type: Enhanced Due Diligence - AML</p>
                          </div>
                          <p className="text-xs text-red-800">Investigation begins in TRMS system</p>
                        </div>

                        <div className="bg-white border border-red-300 p-2 rounded">
                          <p className="text-xs font-semibold">Test Case:</p>
                          <p className="text-xs text-red-700">312-2025-ESC-800</p>
                          <p className="text-xs text-red-600">Offshore Financial Services</p>
                          <p className="text-xs text-red-600 mt-1">TRMS ID: TRMS-2025-8234</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Outcome 4: Client Closed */}
                  <Card className="border-gray-700 border-2 bg-gray-50">
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-2">
                        <XCircle className="h-5 w-5 text-gray-700" />
                        <CardTitle className="text-lg">Outcome 4: Relationship Exit</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="bg-gray-100 p-3 rounded">
                          <p className="text-sm font-semibold text-gray-900">Disposition</p>
                          <p className="text-xs text-gray-800 mt-1">
                            "Client Closed"
                          </p>
                        </div>
                        
                        <div className="space-y-2 text-sm">
                          <p className="font-semibold text-gray-900">When Used:</p>
                          <ul className="text-xs text-gray-800 space-y-1 ml-4">
                            <li>• Risk profile unacceptable</li>
                            <li>• Cannot verify business model</li>
                            <li>• Sanctions concerns</li>
                            <li>• Reputational risk too high</li>
                          </ul>
                        </div>
                        
                        <ArrowDown className="h-5 w-5 text-gray-700 mx-auto" />
                        
                        <div className="bg-gray-200 p-3 rounded space-y-2">
                          <p className="text-xs font-semibold text-gray-900">Client Relationship Terminated</p>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div className="bg-gray-300 p-2 rounded">
                              <p className="font-semibold text-gray-900">Exit Date</p>
                              <p className="text-gray-800">Recorded</p>
                            </div>
                            <div className="bg-gray-300 p-2 rounded">
                              <p className="font-semibold text-gray-900">SAR Filed</p>
                              <p className="text-gray-800">If applicable</p>
                            </div>
                          </div>
                        </div>

                        <div className="bg-white border border-gray-400 p-2 rounded">
                          <p className="text-xs font-semibold">Test Case:</p>
                          <p className="text-xs text-gray-700">312-2025-ESC-900</p>
                          <p className="text-xs text-gray-600">High Risk Trading Corp</p>
                          <p className="text-xs text-gray-600 mt-1">SAR ID: SAR-2025-4567</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Decision Matrix */}
                <Card className="bg-gray-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Disposition Decision Matrix</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b-2 border-gray-300">
                            <th className="text-left p-2 font-semibold">Risk Finding</th>
                            <th className="text-left p-2 font-semibold">Recommended Disposition</th>
                            <th className="text-left p-2 font-semibold">Creates CAM Case?</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b border-gray-200">
                            <td className="p-2">Activity aligned with DDQ</td>
                            <td className="p-2 text-green-700 font-semibold">No Escalation</td>
                            <td className="p-2">No</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="p-2">Pattern warrants monitoring</td>
                            <td className="p-2 text-blue-700 font-semibold">Route to CAM Review</td>
                            <td className="p-2">Yes</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="p-2">Suspicious indicators present</td>
                            <td className="p-2 text-red-700 font-semibold">TRMS Filed</td>
                            <td className="p-2">Yes (TRMS Case)</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="p-2">Unacceptable risk profile</td>
                            <td className="p-2 text-gray-700 font-semibold">Client Closed</td>
                            <td className="p-2">No (Exit recorded)</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Legend */}
      <Card>
        <CardHeader>
          <CardTitle>Status Legend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <Badge className="bg-gray-500">Unassigned</Badge>
              <p className="text-xs text-muted-foreground">In workbasket, awaiting assignment</p>
            </div>
            <div className="space-y-1">
              <Badge className="bg-blue-500">In Progress</Badge>
              <p className="text-xs text-muted-foreground">Assigned to analyst for review</p>
            </div>
            <div className="space-y-1">
              <Badge className="bg-orange-500">Pending Sales Review</Badge>
              <p className="text-xs text-muted-foreground">Routed to sales, not yet opened</p>
            </div>
            <div className="space-y-1">
              <Badge className="bg-orange-600">In Sales Review</Badge>
              <p className="text-xs text-muted-foreground">Sales owner actively reviewing</p>
            </div>
            <div className="space-y-1">
              <Badge className="bg-orange-400">Sales Review Complete</Badge>
              <p className="text-xs text-muted-foreground">Returned to analyst with feedback</p>
            </div>
            <div className="space-y-1">
              <Badge className="bg-green-600">Complete</Badge>
              <p className="text-xs text-muted-foreground">Case closed with disposition</p>
            </div>
            <div className="space-y-1">
              <Badge className="bg-green-700">Auto-Closed</Badge>
              <p className="text-xs text-muted-foreground">System-closed, low risk</p>
            </div>
            <div className="space-y-1">
              <Badge className="bg-red-600">Defect Remediation</Badge>
              <p className="text-xs text-muted-foreground">Reopened for quality review</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
