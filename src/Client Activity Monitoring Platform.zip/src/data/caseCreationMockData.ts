export interface ClientForEvaluation {
  id: string;
  legalName: string;
  clientId: string;
  gciNumber: string;
  lob: 'GB/GM' | 'PB' | 'ML' | 'Consumer' | 'CI';
  riskRating: 'High' | 'Elevated' | 'Standard' | 'Low';
  refreshDueDate: string;
  daysToRefresh: number;
  status: 'Active' | 'Closed';
  
  // 312 Criteria
  has312Flag: boolean;
  has312ModelAlert: boolean;
  familyAnniversaryDate?: string;
  dgaDueDate?: string;
  hasPVT?: boolean;
  
  // CAM Criteria
  had312CaseNotAutoClosed: boolean;
  completedCasesLast12Months: number;
  hasSARLast12Months: boolean;
  hadCAMReviewLast12Months: boolean;
  
  // Results
  cam312Decision?: 'Full Review' | 'Auto-Close' | 'Not Applicable';
  camDecision?: 'Full Review' | 'Auto-Close' | 'Not Applicable' | 'Pending 312';
  cam312CaseId?: string;
  camCaseId?: string;
}

export const mockClientsForEvaluation: ClientForEvaluation[] = [
  {
    id: 'CLT-001',
    legalName: 'GlobalTech Industries Corp',
    clientId: 'GT-892341',
    gciNumber: 'GCI-001-2024',
    lob: 'GB/GM',
    riskRating: 'High',
    refreshDueDate: '2025-03-15',
    daysToRefresh: 138,
    status: 'Active',
    has312Flag: true,
    has312ModelAlert: true,
    dgaDueDate: '2025-03-15',
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 8,
    hasSARLast12Months: true,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Full Review',
    camDecision: 'Full Review',
    cam312CaseId: '312-2024-001',
    camCaseId: 'CAM-2024-001'
  },
  {
    id: 'CLT-002',
    legalName: 'Meridian Capital Partners',
    clientId: 'MCP-445122',
    gciNumber: 'GCI-002-2024',
    lob: 'PB',
    riskRating: 'High',
    refreshDueDate: '2025-04-20',
    daysToRefresh: 174,
    status: 'Active',
    has312Flag: true,
    has312ModelAlert: false,
    hasPVT: true,
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 2,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Auto-Close',
    camDecision: 'Auto-Close',
    cam312CaseId: '312-2024-002',
    camCaseId: 'CAM-2024-002'
  },
  {
    id: 'CLT-003',
    legalName: 'Evergreen Investment Holdings LLC',
    clientId: 'EIH-778934',
    gciNumber: 'GCI-003-2024',
    lob: 'ML',
    riskRating: 'High',
    refreshDueDate: '2025-02-28',
    daysToRefresh: 123,
    status: 'Active',
    has312Flag: true,
    has312ModelAlert: true,
    hasPVT: true,
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Full Review',
    camDecision: 'Pending 312',
    cam312CaseId: '312-2024-003',
    camCaseId: 'CAM-2024-003'
  },
  {
    id: 'CLT-004',
    legalName: 'Pacific Trading Group',
    clientId: 'PTG-223456',
    gciNumber: 'GCI-004-2024',
    lob: 'GB/GM',
    riskRating: 'Elevated',
    refreshDueDate: '2025-05-10',
    daysToRefresh: 195,
    status: 'Active',
    has312Flag: true,
    has312ModelAlert: false,
    familyAnniversaryDate: '2025-05-10',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 3,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Auto-Close',
    camDecision: 'Not Applicable',
    cam312CaseId: '312-2024-004',
    camCaseId: undefined
  },
  {
    id: 'CLT-005',
    legalName: 'Quantum Ventures Fund',
    clientId: 'QVF-556789',
    gciNumber: 'GCI-005-2024',
    lob: 'PB',
    riskRating: 'High',
    refreshDueDate: '2025-03-30',
    daysToRefresh: 153,
    status: 'Active',
    has312Flag: true,
    has312ModelAlert: true,
    hasPVT: true,
    had312CaseNotAutoClosed: true,
    completedCasesLast12Months: 12,
    hasSARLast12Months: true,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Full Review',
    camDecision: 'Full Review',
    cam312CaseId: '312-2024-005',
    camCaseId: 'CAM-2024-005'
  },
  {
    id: 'CLT-006',
    legalName: 'Sterling International Ltd',
    clientId: 'SIL-889012',
    gciNumber: 'GCI-006-2024',
    lob: 'ML',
    riskRating: 'High',
    refreshDueDate: '2025-04-05',
    daysToRefresh: 159,
    status: 'Active',
    has312Flag: true,
    has312ModelAlert: false,
    hasPVT: true,
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 5,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Auto-Close',
    camDecision: 'Full Review',
    cam312CaseId: '312-2024-006',
    camCaseId: 'CAM-2024-006'
  },
  {
    id: 'CLT-007',
    legalName: 'Atlas Global Enterprises',
    clientId: 'AGE-334567',
    gciNumber: 'GCI-007-2024',
    lob: 'GB/GM',
    riskRating: 'Standard',
    refreshDueDate: '2025-06-15',
    daysToRefresh: 231,
    status: 'Active',
    has312Flag: true,
    has312ModelAlert: true,
    familyAnniversaryDate: '2025-06-15',
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 1,
    hasSARLast12Months: false,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Full Review',
    camDecision: 'Not Applicable',
    cam312CaseId: '312-2024-007',
    camCaseId: undefined
  },
  {
    id: 'CLT-008',
    legalName: 'Apex Holdings Inc',
    clientId: 'APX-112233',
    gciNumber: 'GCI-008-2024',
    lob: 'Consumer',
    riskRating: 'High',
    refreshDueDate: '2025-01-15',
    daysToRefresh: 80,
    status: 'Active',
    has312Flag: false,
    has312ModelAlert: false,
    had312CaseNotAutoClosed: false,
    completedCasesLast12Months: 6,
    hasSARLast12Months: true,
    hadCAMReviewLast12Months: false,
    cam312Decision: 'Not Applicable',
    camDecision: 'Full Review',
    cam312CaseId: undefined,
    camCaseId: 'CAM-2024-008'
  }
];

export interface CaseCreationStats {
  totalEvaluated: number;
  cam312FullReview: number;
  cam312AutoClose: number;
  cam312NotApplicable: number;
  camFullReview: number;
  camAutoClose: number;
  camNotApplicable: number;
  camPending312: number;
}

export const calculateStats = (clients: ClientForEvaluation[]): CaseCreationStats => {
  return {
    totalEvaluated: clients.length,
    cam312FullReview: clients.filter(c => c.cam312Decision === 'Full Review').length,
    cam312AutoClose: clients.filter(c => c.cam312Decision === 'Auto-Close').length,
    cam312NotApplicable: clients.filter(c => c.cam312Decision === 'Not Applicable').length,
    camFullReview: clients.filter(c => c.camDecision === 'Full Review').length,
    camAutoClose: clients.filter(c => c.camDecision === 'Auto-Close').length,
    camNotApplicable: clients.filter(c => c.camDecision === 'Not Applicable').length,
    camPending312: clients.filter(c => c.camDecision === 'Pending 312').length
  };
};
