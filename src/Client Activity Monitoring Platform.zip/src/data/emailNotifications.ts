// Email Notification System for CAM Platform
// Handles automated email notifications to Sales Owners based on case status and action requirements

export interface EmailNotification {
  id: string;
  caseId: string;
  recipientName: string;
  recipientEmail: string;
  senderName: string;
  senderEmail: string;
  subject: string;
  type: 'no_action_required' | 'action_required';
  sentDate: string;
  sentTime: string;
  caseStatus: string;
  action312Status: string;
  actionCAMStatus: string;
  dueDate?: string;
  htmlBody: string;
  plainTextBody: string;
}

// Email template for "No Action Required"
export const generateNoActionEmail = (params: {
  salesOwnerName: string;
  salesOwnerEmail: string;
  processorName: string;
  clientName: string;
  caseId: string;
  gci: string;
  completionDate: string;
  refreshDueDate?: string;
  dashboardLink?: string;
}): EmailNotification => {
  const subject = `CAM Review Complete - No Action Required: ${params.clientName} (${params.caseId})`;
  
  const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: 'Roboto', Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #0071CE 0%, #005EA8 100%); color: white; padding: 30px 20px; text-align: center; border-radius: 8px 8px 0 0; }
    .header h1 { margin: 0; font-size: 24px; }
    .content { background: #ffffff; padding: 30px; border: 1px solid #e0e0e0; border-top: none; }
    .info-box { background: #f5f5f5; padding: 20px; border-radius: 6px; margin: 20px 0; border-left: 4px solid #0071CE; }
    .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e0e0e0; }
    .info-row:last-child { border-bottom: none; }
    .label { font-weight: 600; color: #666; }
    .value { color: #333; }
    .status-badge { display: inline-block; padding: 6px 12px; border-radius: 4px; font-size: 14px; font-weight: 600; }
    .status-complete { background: #dcfce7; color: #15803d; }
    .button { display: inline-block; padding: 12px 24px; background: #0071CE; color: white; text-decoration: none; border-radius: 6px; font-weight: 600; margin: 20px 0; }
    .button:hover { background: #005EA8; }
    .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; border-radius: 0 0 8px 8px; }
    .important { background: #e3f2fd; padding: 15px; border-radius: 6px; border-left: 4px solid #0071CE; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>✓ CAM Review Complete</h1>
      <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.95;">No Action Required</p>
    </div>
    
    <div class="content">
      <p>Dear ${params.salesOwnerName},</p>
      
      <p>This email confirms that the Client Activity Monitoring (CAM) review for <strong>${params.clientName}</strong> has been completed by ${params.processorName}.</p>
      
      <div class="important">
        <strong>📋 Summary:</strong> No further action is required from you at this time. This notification is for your information only.
      </div>
      
      <div class="info-box">
        <h3 style="margin-top: 0; color: #0071CE;">Case Details</h3>
        <div class="info-row">
          <span class="label">Case ID:</span>
          <span class="value">${params.caseId}</span>
        </div>
        <div class="info-row">
          <span class="label">Client Name:</span>
          <span class="value">${params.clientName}</span>
        </div>
        <div class="info-row">
          <span class="label">GCI Number:</span>
          <span class="value">${params.gci}</span>
        </div>
        <div class="info-row">
          <span class="label">Case Status:</span>
          <span class="value"><span class="status-badge status-complete">Complete</span></span>
        </div>
        <div class="info-row">
          <span class="label">Completion Date:</span>
          <span class="value">${params.completionDate}</span>
        </div>
        <div class="info-row">
          <span class="label">Reviewed By:</span>
          <span class="value">${params.processorName}</span>
        </div>
        ${params.refreshDueDate ? `
        <div class="info-row">
          <span class="label">Next Refresh Due:</span>
          <span class="value">${params.refreshDueDate}</span>
        </div>
        ` : ''}
      </div>
      
      <h3 style="color: #0071CE;">Review Outcome</h3>
      <p>The CAM review has been completed with the following determination:</p>
      <ul>
        <li><strong>312 Review:</strong> No additional action required</li>
        <li><strong>CAM Review:</strong> No additional action required</li>
        <li><strong>Sales Owner Input:</strong> Not required</li>
      </ul>
      
      ${params.dashboardLink ? `
      <div style="text-align: center; margin: 30px 0;">
        <a href="${params.dashboardLink}" class="button">View Case Details</a>
      </div>
      ` : ''}
      
      <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-top: 20px;">
        <p style="margin: 0; font-size: 14px; color: #666;">
          <strong>Note:</strong> No reply to this email is necessary. This is an automated notification for your records. If you have questions about this case, please contact ${params.processorName} directly.
        </p>
      </div>
    </div>
    
    <div class="footer">
      <p><strong>Client Activity Monitoring Platform</strong></p>
      <p>Bank of America | Merrill Lynch</p>
      <p style="font-size: 11px; color: #999; margin-top: 10px;">
        This is an automated message. Please do not reply to this email.
      </p>
    </div>
  </div>
</body>
</html>
  `;

  const plainTextBody = `
CAM REVIEW COMPLETE - NO ACTION REQUIRED

Dear ${params.salesOwnerName},

This email confirms that the Client Activity Monitoring (CAM) review for ${params.clientName} has been completed by ${params.processorName}.

SUMMARY: No further action is required from you at this time. This notification is for your information only.

CASE DETAILS:
- Case ID: ${params.caseId}
- Client Name: ${params.clientName}
- GCI Number: ${params.gci}
- Case Status: Complete
- Completion Date: ${params.completionDate}
- Reviewed By: ${params.processorName}
${params.refreshDueDate ? `- Next Refresh Due: ${params.refreshDueDate}` : ''}

REVIEW OUTCOME:
- 312 Review: No additional action required
- CAM Review: No additional action required
- Sales Owner Input: Not required

${params.dashboardLink ? `View Case Details: ${params.dashboardLink}` : ''}

NOTE: No reply to this email is necessary. This is an automated notification for your records. If you have questions about this case, please contact ${params.processorName} directly.

---
Client Activity Monitoring Platform
Bank of America | Merrill Lynch

This is an automated message. Please do not reply to this email.
  `;

  return {
    id: `EMAIL-${params.caseId}-${Date.now()}`,
    caseId: params.caseId,
    recipientName: params.salesOwnerName,
    recipientEmail: params.salesOwnerEmail,
    senderName: 'CAM Platform',
    senderEmail: 'cam-noreply@bofa.com',
    subject,
    type: 'no_action_required',
    sentDate: new Date().toISOString().split('T')[0],
    sentTime: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    caseStatus: 'Complete',
    action312Status: 'No Action',
    actionCAMStatus: 'No Action',
    htmlBody,
    plainTextBody,
  };
};

// Email template for "Action Required"
export const generateActionRequiredEmail = (params: {
  salesOwnerName: string;
  salesOwnerEmail: string;
  processorName: string;
  clientName: string;
  caseId: string;
  gci: string;
  assignedDate: string;
  dueDate: string;
  daysToRespond: number;
  action312Status: string;
  actionCAMStatus: string;
  requestDetails: string;
  dashboardLink?: string;
}): EmailNotification => {
  const subject = `ACTION REQUIRED: Sales Owner Input Needed - ${params.clientName} (${params.caseId})`;
  
  const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: 'Roboto', Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #E31837 0%, #C41230 100%); color: white; padding: 30px 20px; text-align: center; border-radius: 8px 8px 0 0; }
    .header h1 { margin: 0; font-size: 24px; }
    .content { background: #ffffff; padding: 30px; border: 1px solid #e0e0e0; border-top: none; }
    .alert-box { background: #fef2f2; padding: 20px; border-radius: 6px; margin: 20px 0; border-left: 4px solid #E31837; }
    .info-box { background: #f5f5f5; padding: 20px; border-radius: 6px; margin: 20px 0; border-left: 4px solid #0071CE; }
    .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e0e0e0; }
    .info-row:last-child { border-bottom: none; }
    .label { font-weight: 600; color: #666; }
    .value { color: #333; }
    .status-badge { display: inline-block; padding: 6px 12px; border-radius: 4px; font-size: 14px; font-weight: 600; }
    .status-action { background: #fee2e2; color: #991b1b; }
    .status-pending { background: #fef3c7; color: #92400e; }
    .button { display: inline-block; padding: 14px 28px; background: #E31837; color: white; text-decoration: none; border-radius: 6px; font-weight: 600; margin: 20px 0; font-size: 16px; }
    .button:hover { background: #C41230; }
    .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; border-radius: 0 0 8px 8px; }
    .deadline { background: #fff7ed; padding: 15px; border-radius: 6px; border-left: 4px solid #D4AF37; margin: 20px 0; }
    .timeline { background: #f0f9ff; padding: 20px; border-radius: 6px; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>⚠️ ACTION REQUIRED</h1>
      <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.95;">Sales Owner Input Needed</p>
    </div>
    
    <div class="content">
      <p>Dear ${params.salesOwnerName},</p>
      
      <p>The case processor, <strong>${params.processorName}</strong>, has assigned a Client Activity Monitoring (CAM) case to you for <strong>${params.clientName}</strong>. Your input is needed to complete the case review.</p>
      
      <div class="alert-box">
        <strong>⏰ RESPONSE REQUIRED:</strong> You must respond within the next <strong>${params.daysToRespond} days</strong> to avoid delays in resolving this CAM review.
      </div>
      
      <div class="info-box">
        <h3 style="margin-top: 0; color: #0071CE;">Case Details</h3>
        <div class="info-row">
          <span class="label">Case ID:</span>
          <span class="value">${params.caseId}</span>
        </div>
        <div class="info-row">
          <span class="label">Client Name:</span>
          <span class="value">${params.clientName}</span>
        </div>
        <div class="info-row">
          <span class="label">GCI Number:</span>
          <span class="value">${params.gci}</span>
        </div>
        <div class="info-row">
          <span class="label">Case Status:</span>
          <span class="value"><span class="status-badge status-pending">Pending Sales Review</span></span>
        </div>
        <div class="info-row">
          <span class="label">Assigned Date:</span>
          <span class="value">${params.assignedDate}</span>
        </div>
        <div class="info-row">
          <span class="label">Response Due:</span>
          <span class="value" style="color: #E31837; font-weight: 600;">${params.dueDate}</span>
        </div>
        <div class="info-row">
          <span class="label">Assigned By:</span>
          <span class="value">${params.processorName}</span>
        </div>
      </div>
      
      <h3 style="color: #E31837;">Review Status</h3>
      <div class="info-box">
        <div class="info-row">
          <span class="label">312 Review:</span>
          <span class="value"><span class="status-badge status-action">${params.action312Status}</span></span>
        </div>
        <div class="info-row">
          <span class="label">CAM Review:</span>
          <span class="value"><span class="status-badge status-action">${params.actionCAMStatus}</span></span>
        </div>
      </div>
      
      <h3 style="color: #0071CE;">What's Needed</h3>
      <p>${params.requestDetails}</p>
      
      <div class="timeline">
        <h4 style="margin-top: 0; color: #0071CE;">📅 Timeline</h4>
        <ul style="margin: 10px 0; padding-left: 20px;">
          <li><strong>Today:</strong> Review case details and processor comments</li>
          <li><strong>Within 7 days:</strong> Provide your business context and feedback</li>
          <li><strong>Within ${params.daysToRespond} days:</strong> Submit your review to avoid escalation</li>
        </ul>
      </div>
      
      ${params.dashboardLink ? `
      <div style="text-align: center; margin: 30px 0;">
        <a href="${params.dashboardLink}" class="button">Open Case & Respond</a>
      </div>
      ` : ''}
      
      <div class="deadline">
        <p style="margin: 0; font-size: 14px;">
          <strong>⚠️ Important:</strong> Failure to respond by <strong>${params.dueDate}</strong> may result in delays to the case resolution and potential escalation to management. If you need additional time or have questions, please contact ${params.processorName} as soon as possible.
        </p>
      </div>
      
      <h3 style="color: #0071CE;">Next Steps</h3>
      <ol>
        <li>Log into the CAM Platform using the button above</li>
        <li>Review the case details and processor analysis</li>
        <li>Provide your business context and client relationship insights</li>
        <li>Submit your sales owner review</li>
      </ol>
      
      <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-top: 20px;">
        <p style="margin: 0; font-size: 14px; color: #666;">
          <strong>Questions?</strong> Contact ${params.processorName} directly or reply to this email for assistance.
        </p>
      </div>
    </div>
    
    <div class="footer">
      <p><strong>Client Activity Monitoring Platform</strong></p>
      <p>Bank of America | Merrill Lynch</p>
      <p style="font-size: 11px; color: #999; margin-top: 10px;">
        This email requires action. Please respond by the due date indicated above.
      </p>
    </div>
  </div>
</body>
</html>
  `;

  const plainTextBody = `
ACTION REQUIRED: SALES OWNER INPUT NEEDED

Dear ${params.salesOwnerName},

The case processor, ${params.processorName}, has assigned a Client Activity Monitoring (CAM) case to you for ${params.clientName}. Your input is needed to complete the case review.

⚠️ RESPONSE REQUIRED: You must respond within the next ${params.daysToRespond} days to avoid delays in resolving this CAM review.

CASE DETAILS:
- Case ID: ${params.caseId}
- Client Name: ${params.clientName}
- GCI Number: ${params.gci}
- Case Status: Pending Sales Review
- Assigned Date: ${params.assignedDate}
- Response Due: ${params.dueDate}
- Assigned By: ${params.processorName}

REVIEW STATUS:
- 312 Review: ${params.action312Status}
- CAM Review: ${params.actionCAMStatus}

WHAT'S NEEDED:
${params.requestDetails}

TIMELINE:
- Today: Review case details and processor comments
- Within 7 days: Provide your business context and feedback
- Within ${params.daysToRespond} days: Submit your review to avoid escalation

${params.dashboardLink ? `OPEN CASE & RESPOND: ${params.dashboardLink}` : ''}

⚠️ IMPORTANT: Failure to respond by ${params.dueDate} may result in delays to the case resolution and potential escalation to management. If you need additional time or have questions, please contact ${params.processorName} as soon as possible.

NEXT STEPS:
1. Log into the CAM Platform
2. Review the case details and processor analysis
3. Provide your business context and client relationship insights
4. Submit your sales owner review

Questions? Contact ${params.processorName} directly or reply to this email for assistance.

---
Client Activity Monitoring Platform
Bank of America | Merrill Lynch

This email requires action. Please respond by the due date indicated above.
  `;

  return {
    id: `EMAIL-${params.caseId}-${Date.now()}`,
    caseId: params.caseId,
    recipientName: params.salesOwnerName,
    recipientEmail: params.salesOwnerEmail,
    senderName: params.processorName,
    senderEmail: 'cam-noreply@bofa.com',
    subject,
    type: 'action_required',
    sentDate: new Date().toISOString().split('T')[0],
    sentTime: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    caseStatus: 'Pending Sales Review',
    action312Status: params.action312Status,
    actionCAMStatus: params.actionCAMStatus,
    dueDate: params.dueDate,
    htmlBody,
    plainTextBody,
  };
};

// Mock sent emails database
export const mockSentEmails: EmailNotification[] = [
  generateNoActionEmail({
    salesOwnerName: 'David Park',
    salesOwnerEmail: 'david.park@bofa.com',
    processorName: 'Sarah Mitchell',
    clientName: 'Standard Manufacturing Inc.',
    caseId: '312-2025-AUTO-001',
    gci: 'GCI-AUTO-001',
    completionDate: 'October 20, 2025',
    refreshDueDate: 'April 20, 2026',
    dashboardLink: 'https://cam.bofa.com/cases/312-2025-AUTO-001',
  }),
  generateActionRequiredEmail({
    salesOwnerName: 'David Park',
    salesOwnerEmail: 'david.park@bofa.com',
    processorName: 'Michael Chen',
    clientName: 'Meridian Capital Holdings',
    caseId: '312-2025-SALES-001',
    gci: 'GCI-334455',
    assignedDate: 'October 22, 2025',
    dueDate: 'November 21, 2025',
    daysToRespond: 30,
    action312Status: 'Send to Sales',
    actionCAMStatus: 'Send to Sales',
    requestDetails: 'The processor has identified unusual transaction patterns and requires your input regarding the business context for these activities. Please review the case details and provide insights into the client\'s business operations and the legitimacy of the flagged transactions.',
    dashboardLink: 'https://cam.bofa.com/cases/312-2025-SALES-001',
  }),
  generateActionRequiredEmail({
    salesOwnerName: 'Amanda Torres',
    salesOwnerEmail: 'amanda.torres@bofa.com',
    processorName: 'Jennifer Wu',
    clientName: 'Pacific Technology Group',
    caseId: 'CAM-2025-015',
    gci: 'GCI-556789',
    assignedDate: 'October 24, 2025',
    dueDate: 'November 23, 2025',
    daysToRespond: 30,
    action312Status: 'No Action',
    actionCAMStatus: 'Send to Sales',
    requestDetails: 'The CAM review has identified increased wire transfer activity to offshore entities. Your business context is needed to understand whether this aligns with the client\'s expected business activities and documented purpose of the relationship.',
    dashboardLink: 'https://cam.bofa.com/cases/CAM-2025-015',
  }),
];

// Utility function to trigger email based on case status
export const shouldTriggerEmail = (
  action312Status: string,
  actionCAMStatus: string,
  caseStatus: string
): { shouldSend: boolean; emailType: 'no_action_required' | 'action_required' | null } => {
  // Both 312 and CAM must be in 'No Action' or 'Send to Sales' status
  const valid312Statuses = ['No Action', 'Send to Sales'];
  const validCAMStatuses = ['No Action', 'Send to Sales'];
  const validCaseStatuses = ['Complete', 'Pending Sales Review'];

  if (!valid312Statuses.includes(action312Status) || 
      !validCAMStatuses.includes(actionCAMStatus) ||
      !validCaseStatuses.includes(caseStatus)) {
    return { shouldSend: false, emailType: null };
  }

  // Determine email type
  if (action312Status === 'No Action' && actionCAMStatus === 'No Action' && caseStatus === 'Complete') {
    return { shouldSend: true, emailType: 'no_action_required' };
  }

  if ((action312Status === 'Send to Sales' || actionCAMStatus === 'Send to Sales') && 
      caseStatus === 'Pending Sales Review') {
    return { shouldSend: true, emailType: 'action_required' };
  }

  return { shouldSend: false, emailType: null };
};
