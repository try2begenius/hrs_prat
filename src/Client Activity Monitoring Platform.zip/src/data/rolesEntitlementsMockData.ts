export interface RoleDefinition {
  id: string;
  name: string;
  type: 'Central Team Analyst' | 'Central Team Manager' | 'View Only' | 'Sales Owner';
  description: string;
  permissions: {
    viewDashboard: boolean;
    viewWorklist: boolean;
    openCases: boolean;
    reviewData: boolean;
    actionCases: boolean;
    assignCases: boolean;
    reassignCases: boolean;
    reopenCases: boolean;
    abandonCases: boolean;
    salesFeedback: boolean;
    returnToAnalyst: boolean;
  };
}

export interface EntitlementDefinition {
  id: string;
  name: string;
  category: '312' | 'CAM' | 'LOB' | 'Employee Cases' | 'Manual Case Creation';
  description: string;
  restrictionLevel: 'Required' | 'Optional' | 'Limited';
}

export interface UserAccess {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: RoleDefinition['type'] | 'Manager' | 'Analyst'; // Added Manager and Analyst for compatibility
  entitlements: {
    has312Access: boolean;
    hasCAMAccess: boolean;
    lobs: string[];
    hasEmployeeCaseAccess: boolean;
    hasManualCaseCreation: boolean;
  };
  manager: string;
  accessRequestDate: string;
  accessApprovedDate: string;
  status: 'Active' | 'Pending' | 'Revoked';
}

export const getPermissionsForRole = (role: RoleDefinition['type']): RoleDefinition['permissions'] => {
  const roleDefiniton = roleDefinitions.find(r => r.type === role);
  return roleDefiniton?.permissions || {
    viewDashboard: false,
    viewWorklist: false,
    openCases: false,
    reviewData: false,
    actionCases: false,
    assignCases: false,
    reassignCases: false,
    reopenCases: false,
    abandonCases: false,
    salesFeedback: false,
    returnToAnalyst: false
  };
};

export const roleDefinitions: RoleDefinition[] = [
  {
    id: 'ROLE-001',
    name: 'Central Team Analyst',
    type: 'Central Team Analyst',
    description: 'Access to case dashboard and individual worklist. Ability to open cases, review all data and action cases.',
    permissions: {
      viewDashboard: true,
      viewWorklist: true,
      openCases: true,
      reviewData: true,
      actionCases: true,
      assignCases: false,
      reassignCases: false,
      reopenCases: false,
      abandonCases: false,
      salesFeedback: false,
      returnToAnalyst: false
    }
  },
  {
    id: 'ROLE-002',
    name: 'Central Team Manager',
    type: 'Central Team Manager',
    description: 'Access to case dashboard and individual worklist. Ability to open cases, review all data and action cases. Ability to assign/reassign cases to other analysts. Ability to reopen completed cases to make necessary remediation based on quality findings. Abandon cases.',
    permissions: {
      viewDashboard: true,
      viewWorklist: true,
      openCases: true,
      reviewData: true,
      actionCases: true,
      assignCases: true,
      reassignCases: true,
      reopenCases: true,
      abandonCases: true,
      salesFeedback: false,
      returnToAnalyst: false
    }
  },
  {
    id: 'ROLE-003',
    name: 'View Only',
    type: 'View Only',
    description: 'Ability to review cases, both closed and open, but no ability to action a case in any way.',
    permissions: {
      viewDashboard: true,
      viewWorklist: true,
      openCases: true,
      reviewData: true,
      actionCases: false,
      assignCases: false,
      reassignCases: false,
      reopenCases: false,
      abandonCases: false,
      salesFeedback: false,
      returnToAnalyst: false
    }
  },
  {
    id: 'ROLE-004',
    name: 'Sales Owner',
    type: 'Sales Owner',
    description: 'Ability to review cases sent to sales for feedback and return cases to central team analyst.',
    permissions: {
      viewDashboard: false,
      viewWorklist: true,
      openCases: true,
      reviewData: true,
      actionCases: false,
      assignCases: false,
      reassignCases: false,
      reopenCases: false,
      abandonCases: false,
      salesFeedback: true,
      returnToAnalyst: true
    }
  }
];

export const entitlementDefinitions: EntitlementDefinition[] = [
  {
    id: 'ENT-001',
    name: '312 Access',
    category: '312',
    description: 'Access to the 312 cases',
    restrictionLevel: 'Optional'
  },
  {
    id: 'ENT-002',
    name: 'CAM Access',
    category: 'CAM',
    description: 'Access to the CAM cases',
    restrictionLevel: 'Optional'
  },
  {
    id: 'ENT-003',
    name: 'GB/GM Access',
    category: 'LOB',
    description: 'Access to see and action cases on behalf of Global Banking and Global Markets LOB',
    restrictionLevel: 'Optional'
  },
  {
    id: 'ENT-004',
    name: 'PB Access',
    category: 'LOB',
    description: 'Access to see and action cases on behalf of Private Banking LOB',
    restrictionLevel: 'Optional'
  },
  {
    id: 'ENT-005',
    name: 'ML Access',
    category: 'LOB',
    description: 'Access to see and action cases on behalf of Merrill Lynch LOB',
    restrictionLevel: 'Optional'
  },
  {
    id: 'ENT-006',
    name: 'Consumer Access',
    category: 'LOB',
    description: 'Access to see and action cases on behalf of Consumer LOB',
    restrictionLevel: 'Optional'
  },
  {
    id: 'ENT-007',
    name: 'CI Access',
    category: 'LOB',
    description: 'Access to see and action cases on behalf of Consumer Investments LOB',
    restrictionLevel: 'Optional'
  },
  {
    id: 'ENT-008',
    name: 'Employee Cases Access',
    category: 'Employee Cases',
    description: 'Access to review cases specific to employees or affiliates - limited to certain users',
    restrictionLevel: 'Limited'
  },
  {
    id: 'ENT-009',
    name: 'Manual Case Creation',
    category: 'Manual Case Creation',
    description: 'Ability to request manual case creation ad-hoc based on business need',
    restrictionLevel: 'Limited'
  }
];

export const mockUsers: UserAccess[] = [
  {
    id: 'USR-001',
    name: 'Sarah Mitchell',
    email: 'sarah.mitchell@ml.com',
    avatar: 'SM',
    role: 'Central Team Manager',
    entitlements: {
      has312Access: true,
      hasCAMAccess: true,
      lobs: ['GB/GM', 'PB', 'ML'],
      hasEmployeeCaseAccess: true,
      hasManualCaseCreation: true
    },
    manager: 'Director - AML Operations',
    accessRequestDate: '2024-10-01',
    accessApprovedDate: '2024-10-02',
    status: 'Active'
  },
  {
    id: 'USR-002',
    name: 'Michael Chen',
    email: 'michael.chen@ml.com',
    avatar: 'MC',
    role: 'Central Team Analyst',
    entitlements: {
      has312Access: true,
      hasCAMAccess: true,
      lobs: ['GB/GM', 'PB'],
      hasEmployeeCaseAccess: false,
      hasManualCaseCreation: false
    },
    manager: 'Sarah Mitchell',
    accessRequestDate: '2024-10-05',
    accessApprovedDate: '2024-10-06',
    status: 'Active'
  },
  {
    id: 'USR-003',
    name: 'Jennifer Wu',
    email: 'jennifer.wu@ml.com',
    avatar: 'JW',
    role: 'Central Team Analyst',
    entitlements: {
      has312Access: true,
      hasCAMAccess: true,
      lobs: ['ML', 'Consumer', 'CI'],
      hasEmployeeCaseAccess: false,
      hasManualCaseCreation: false
    },
    manager: 'Sarah Mitchell',
    accessRequestDate: '2024-10-07',
    accessApprovedDate: '2024-10-08',
    status: 'Active'
  },
  {
    id: 'USR-004',
    name: 'David Park',
    email: 'david.park@ml.com',
    avatar: 'DP',
    role: 'Sales Owner',
    entitlements: {
      has312Access: true,
      hasCAMAccess: false,
      lobs: ['GB/GM'],
      hasEmployeeCaseAccess: false,
      hasManualCaseCreation: false
    },
    manager: 'VP - Global Banking',
    accessRequestDate: '2024-10-10',
    accessApprovedDate: '2024-10-11',
    status: 'Active'
  },
  {
    id: 'USR-005',
    name: 'Amanda Torres',
    email: 'amanda.torres@ml.com',
    avatar: 'AT',
    role: 'Sales Owner',
    entitlements: {
      has312Access: true,
      hasCAMAccess: false,
      lobs: ['ML'],
      hasEmployeeCaseAccess: false,
      hasManualCaseCreation: false
    },
    manager: 'VP - Merrill Lynch',
    accessRequestDate: '2024-10-12',
    accessApprovedDate: '2024-10-13',
    status: 'Active'
  },
  {
    id: 'USR-006',
    name: 'Robert Anderson',
    email: 'robert.anderson@ml.com',
    avatar: 'RA',
    role: 'View Only',
    entitlements: {
      has312Access: true,
      hasCAMAccess: true,
      lobs: ['GB/GM', 'PB', 'ML', 'Consumer', 'CI'],
      hasEmployeeCaseAccess: false,
      hasManualCaseCreation: false
    },
    manager: 'Chief Compliance Officer',
    accessRequestDate: '2024-10-15',
    accessApprovedDate: '2024-10-16',
    status: 'Active'
  },
  {
    id: 'USR-007',
    name: 'Lisa Brown',
    email: 'lisa.brown@ml.com',
    avatar: 'LB',
    role: 'Central Team Analyst',
    entitlements: {
      has312Access: false,
      hasCAMAccess: true,
      lobs: ['Consumer', 'CI'],
      hasEmployeeCaseAccess: false,
      hasManualCaseCreation: false
    },
    manager: 'Sarah Mitchell',
    accessRequestDate: '2024-10-18',
    accessApprovedDate: '2024-10-19',
    status: 'Active'
  },
  {
    id: 'USR-008',
    name: 'Carlos Rivera',
    email: 'carlos.rivera@ml.com',
    avatar: 'CR',
    role: 'Central Team Manager',
    entitlements: {
      has312Access: true,
      hasCAMAccess: false,
      lobs: ['PB'],
      hasEmployeeCaseAccess: true,
      hasManualCaseCreation: true
    },
    manager: 'Director - AML Operations',
    accessRequestDate: '2024-10-20',
    accessApprovedDate: '2024-10-21',
    status: 'Active'
  },
  {
    id: 'USR-009',
    name: 'Emily Martinez',
    email: 'emily.martinez@ml.com',
    avatar: 'EM',
    role: 'Central Team Analyst',
    entitlements: {
      has312Access: true,
      hasCAMAccess: true,
      lobs: ['GB/GM'],
      hasEmployeeCaseAccess: false,
      hasManualCaseCreation: false
    },
    manager: 'Sarah Mitchell',
    accessRequestDate: '2024-10-22',
    accessApprovedDate: '2024-10-22',
    status: 'Pending'
  },
  {
    id: 'USR-010',
    name: 'Kevin Rogers',
    email: 'kevin.rogers@ml.com',
    avatar: 'KR',
    role: 'Central Team Analyst',
    entitlements: {
      has312Access: true,
      hasCAMAccess: true,
      lobs: ['ML', 'Consumer'],
      hasEmployeeCaseAccess: true,
      hasManualCaseCreation: false
    },
    manager: 'Carlos Rivera',
    accessRequestDate: '2024-09-15',
    accessApprovedDate: '2024-09-20',
    status: 'Active'
  }
];

export interface AccessStats {
  totalUsers: number;
  activeUsers: number;
  pendingUsers: number;
  revokedUsers: number;
  byRole: {
    role: string;
    count: number;
  }[];
  byEntitlement: {
    entitlement: string;
    count: number;
  }[];
}

export const calculateAccessStats = (users: UserAccess[]): AccessStats => {
  const roleMap = new Map<string, number>();
  const entitlementMap = new Map<string, number>();

  users.forEach(user => {
    // Role stats
    roleMap.set(user.role, (roleMap.get(user.role) || 0) + 1);

    // Entitlement stats
    if (user.entitlements.has312Access) {
      entitlementMap.set('312 Access', (entitlementMap.get('312 Access') || 0) + 1);
    }
    if (user.entitlements.hasCAMAccess) {
      entitlementMap.set('CAM Access', (entitlementMap.get('CAM Access') || 0) + 1);
    }
    if (user.entitlements.hasEmployeeCaseAccess) {
      entitlementMap.set('Employee Cases', (entitlementMap.get('Employee Cases') || 0) + 1);
    }
    if (user.entitlements.hasManualCaseCreation) {
      entitlementMap.set('Manual Case Creation', (entitlementMap.get('Manual Case Creation') || 0) + 1);
    }
    user.entitlements.lobs.forEach(lob => {
      entitlementMap.set(`${lob} LOB`, (entitlementMap.get(`${lob} LOB`) || 0) + 1);
    });
  });

  return {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.status === 'Active').length,
    pendingUsers: users.filter(u => u.status === 'Pending').length,
    revokedUsers: users.filter(u => u.status === 'Revoked').length,
    byRole: Array.from(roleMap.entries()).map(([role, count]) => ({ role, count })),
    byEntitlement: Array.from(entitlementMap.entries()).map(([entitlement, count]) => ({ entitlement, count }))
  };
};
