// Email Trigger Utilities
// Handles automatic email sending based on case status changes

import { 
  EmailNotification, 
  generateNoActionEmail, 
  generateActionRequiredEmail,
  shouldTriggerEmail,
  mockSentEmails 
} from '../data/emailNotifications';
import { Case } from '../types';
import { toast } from 'sonner@2.0.3';

interface EmailTriggerParams {
  case: Case;
  action312Status: string;
  actionCAMStatus: string;
  processorName: string;
  requestDetails?: string;
}

// Calculate days until due date (default 30 days from today)
const calculateDueDate = (daysFromNow: number = 30): string => {
  const date = new Date();
  date.setDate(date.getDate() + daysFromNow);
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
};

// Get today's date formatted
const getTodayFormatted = (): string => {
  return new Date().toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
};

// Main function to trigger email when case status changes
export const triggerEmailNotification = (params: EmailTriggerParams): EmailNotification | null => {
  const { case: caseData, action312Status, actionCAMStatus, processorName, requestDetails } = params;

  // Check if email should be sent
  const { shouldSend, emailType } = shouldTriggerEmail(
    action312Status,
    actionCAMStatus,
    caseData.status
  );

  if (!shouldSend || !emailType) {
    console.log('Email trigger conditions not met', { 
      action312Status, 
      actionCAMStatus, 
      caseStatus: caseData.status 
    });
    return null;
  }

  // Get sales owner information
  const salesOwnerName = caseData.clientData?.salesOwner || 'Unknown';
  const salesOwnerEmail = getSalesOwnerEmail(salesOwnerName);

  let email: EmailNotification;

  if (emailType === 'no_action_required') {
    // Generate "No Action Required" email
    const nextRefreshDate = caseData.refreshDueDates && caseData.refreshDueDates.length > 0
      ? new Date(caseData.refreshDueDates[0]).toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })
      : undefined;

    email = generateNoActionEmail({
      salesOwnerName,
      salesOwnerEmail,
      processorName,
      clientName: caseData.clientName,
      caseId: caseData.id,
      gci: caseData.gci,
      completionDate: getTodayFormatted(),
      refreshDueDate: nextRefreshDate,
      dashboardLink: `https://cam.bofa.com/cases/${caseData.id}`,
    });

    // Add to mock sent emails
    mockSentEmails.push(email);

    // Show success toast
    toast.success('Email Sent', {
      description: `No action required notification sent to ${salesOwnerName}`,
      duration: 5000,
    });

  } else {
    // Generate "Action Required" email
    const daysToRespond = 30;
    const details = requestDetails || 
      'The processor has completed the 312/CAM review and requires your input as the Sales Owner. Please review the case details and provide your business context and feedback regarding the client\'s activities.';

    email = generateActionRequiredEmail({
      salesOwnerName,
      salesOwnerEmail,
      processorName,
      clientName: caseData.clientName,
      caseId: caseData.id,
      gci: caseData.gci,
      assignedDate: getTodayFormatted(),
      dueDate: calculateDueDate(daysToRespond),
      daysToRespond,
      action312Status,
      actionCAMStatus,
      requestDetails: details,
      dashboardLink: `https://cam.bofa.com/cases/${caseData.id}`,
    });

    // Add to mock sent emails
    mockSentEmails.push(email);

    // Show success toast
    toast.success('Email Sent', {
      description: `Action required notification sent to ${salesOwnerName}`,
      duration: 5000,
    });
  }

  console.log('Email notification triggered', {
    type: emailType,
    recipient: salesOwnerName,
    caseId: caseData.id,
  });

  return email;
};

// Helper function to get sales owner email
const getSalesOwnerEmail = (salesOwnerName: string): string => {
  const emailMap: { [key: string]: string } = {
    'David Park': 'david.park@bofa.com',
    'Amanda Torres': 'amanda.torres@bofa.com',
    'Robert Chen': 'robert.chen@bofa.com',
    'Lisa Rodriguez': 'lisa.rodriguez@bofa.com',
    'James Wilson': 'james.wilson@bofa.com',
  };

  return emailMap[salesOwnerName] || `${salesOwnerName.toLowerCase().replace(' ', '.')}@bofa.com`;
};

// Function to simulate sending email (in production, this would call an API)
export const sendEmail = async (email: EmailNotification): Promise<boolean> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));

  console.log('Sending email:', {
    to: email.recipientEmail,
    subject: email.subject,
    type: email.type,
    caseId: email.caseId,
  });

  // In production, this would call:
  // await fetch('/api/emails/send', { method: 'POST', body: JSON.stringify(email) });

  return true;
};

// Function to check and send emails when case sections are submitted
export const checkAndSendEmailOnSubmit = (
  caseData: Case,
  section: '312' | 'CAM',
  processorName: string,
  formData: any
): void => {
  // Only trigger email after both sections are submitted
  // This is a simplified check - in production you'd check actual submission status
  
  const is312Submitted = section === '312' || caseData.case312Data?.status === 'Complete';
  const isCAMSubmitted = section === 'CAM' || caseData.camCaseData?.status === 'Complete';

  if (!is312Submitted || !isCAMSubmitted) {
    console.log('Both sections not yet submitted, email will be sent after both are complete');
    return;
  }

  // Determine action statuses from form data or case data
  let action312Status = 'No Action';
  let actionCAMStatus = 'No Action';
  let requestDetails = '';

  // Extract 312 action status
  if (caseData.case312Data?.disposition) {
    action312Status = caseData.case312Data.disposition;
  }

  // Extract CAM action status  
  if (caseData.camCaseData?.disposition) {
    actionCAMStatus = caseData.camCaseData.disposition;
  }

  // Check if sales input is requested (from Q4 in 312 or Q2 in CAM)
  if (formData?.question4?.includes('Sales Owner') || 
      formData?.recommendation?.includes('Sales Owner')) {
    action312Status = 'Send to Sales';
    actionCAMStatus = 'Send to Sales';
    requestDetails = formData?.salesOwnerRequestDetails || 
      'The processor requires your input regarding client activity patterns and business context.';
  }

  // Trigger email notification
  triggerEmailNotification({
    case: caseData,
    action312Status,
    actionCAMStatus,
    processorName,
    requestDetails,
  });
};
