// Report Export Utilities for CAM Platform
// Handles data export for AKRIT quality review system and other reporting needs

import { Case } from '../types';

// AKRIT Extract Data Structure
export interface AKRITExtractRow {
  caseId: string;
  clientId: string;
  gci: string;
  coperId: string;
  lineOfBusiness: string;
  is312Client: string;
  isEmployeeAffiliate: string;
}

// Generate AKRIT extract data from cases
export const generateAKRITExtract = (cases: Case[]): AKRITExtractRow[] => {
  return cases.map(caseItem => ({
    caseId: caseItem.id,
    clientId: caseItem.clientId || caseItem.clientData?.clientId || 'N/A',
    gci: caseItem.gci,
    coperId: caseItem.coperId || 'N/A',
    lineOfBusiness: caseItem.lineOfBusiness || caseItem.clientData?.lineOfBusiness || 'N/A',
    is312Client: caseItem.is312Case ? 'Yes' : 'No',
    isEmployeeAffiliate: caseItem.clientData?.isEmployee ? 'Yes' : 'No',
  }));
};

// Export data to CSV format
export const exportToCSV = (data: AKRITExtractRow[], filename: string): void => {
  // Define headers
  const headers = [
    'Case ID',
    'Client ID',
    'GCI',
    'CoPer ID',
    'Line of Business',
    '312 Client Flag',
    'BAC Affiliate/Employee Flag'
  ];

  // Create CSV content
  const csvRows = [];
  
  // Add header row
  csvRows.push(headers.join(','));
  
  // Add data rows
  for (const row of data) {
    const values = [
      escapeCSVValue(row.caseId),
      escapeCSVValue(row.clientId),
      escapeCSVValue(row.gci),
      escapeCSVValue(row.coperId),
      escapeCSVValue(row.lineOfBusiness),
      escapeCSVValue(row.is312Client),
      escapeCSVValue(row.isEmployeeAffiliate),
    ];
    csvRows.push(values.join(','));
  }
  
  const csvContent = csvRows.join('\n');
  
  // Create blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadFile(blob, filename);
};

// Export data to Excel format (simplified - creates a CSV that Excel can open)
// In production, use a library like xlsx or exceljs for true .xlsx format
export const exportToExcel = (data: AKRITExtractRow[], filename: string): void => {
  // For this implementation, we'll create a tab-delimited file that Excel recognizes
  // In production, use a proper Excel library
  
  const headers = [
    'Case ID',
    'Client ID',
    'GCI',
    'CoPer ID',
    'Line of Business',
    '312 Client Flag',
    'BAC Affiliate/Employee Flag'
  ];

  const rows = [];
  
  // Add header row
  rows.push(headers.join('\t'));
  
  // Add data rows
  for (const row of data) {
    const values = [
      row.caseId,
      row.clientId,
      row.gci,
      row.coperId,
      row.lineOfBusiness,
      row.is312Client,
      row.isEmployeeAffiliate,
    ];
    rows.push(values.join('\t'));
  }
  
  const tsvContent = rows.join('\n');
  
  // Create blob and download
  const blob = new Blob([tsvContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  downloadFile(blob, filename);
};

// Helper function to escape CSV values
const escapeCSVValue = (value: string): string => {
  if (value === null || value === undefined) {
    return '';
  }
  
  // Convert to string
  const stringValue = String(value);
  
  // If value contains comma, quote, or newline, wrap in quotes and escape quotes
  if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
    return `"${stringValue.replace(/"/g, '""')}"`;
  }
  
  return stringValue;
};

// Helper function to trigger file download
const downloadFile = (blob: Blob, filename: string): void => {
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  // Clean up the URL object
  setTimeout(() => URL.revokeObjectURL(url), 100);
};

// Generate comprehensive case report (for other reporting needs)
export interface CaseReportRow extends AKRITExtractRow {
  clientName: string;
  caseType: string;
  status: string;
  riskLevel: string;
  assignedTo: string;
  createdDate: string;
  dueDate: string;
  salesOwner: string;
}

export const generateCaseReport = (cases: Case[]): CaseReportRow[] => {
  return cases.map(caseItem => ({
    // AKRIT fields
    caseId: caseItem.id,
    clientId: caseItem.clientId || caseItem.clientData?.clientId || 'N/A',
    gci: caseItem.gci,
    coperId: caseItem.coperId || 'N/A',
    lineOfBusiness: caseItem.lineOfBusiness || caseItem.clientData?.lineOfBusiness || 'N/A',
    is312Client: caseItem.is312Case ? 'Yes' : 'No',
    isEmployeeAffiliate: caseItem.clientData?.isEmployee ? 'Yes' : 'No',
    // Additional report fields
    clientName: caseItem.clientName,
    caseType: caseItem.caseType,
    status: caseItem.status,
    riskLevel: caseItem.riskLevel,
    assignedTo: caseItem.assignedTo,
    createdDate: caseItem.createdDate,
    dueDate: caseItem.dueDate,
    salesOwner: caseItem.clientData?.salesOwner || 'N/A',
  }));
};

// Export comprehensive report to CSV
export const exportComprehensiveReportToCSV = (cases: Case[], filename: string): void => {
  const data = generateCaseReport(cases);
  
  const headers = [
    'Case ID',
    'Client ID',
    'Client Name',
    'GCI',
    'CoPer ID',
    'Line of Business',
    'Case Type',
    'Status',
    'Risk Level',
    'Assigned To',
    'Sales Owner',
    'Created Date',
    'Due Date',
    '312 Client Flag',
    'Employee Flag'
  ];

  const csvRows = [];
  csvRows.push(headers.join(','));
  
  for (const row of data) {
    const values = [
      escapeCSVValue(row.caseId),
      escapeCSVValue(row.clientId),
      escapeCSVValue(row.clientName),
      escapeCSVValue(row.gci),
      escapeCSVValue(row.coperId),
      escapeCSVValue(row.lineOfBusiness),
      escapeCSVValue(row.caseType),
      escapeCSVValue(row.status),
      escapeCSVValue(row.riskLevel),
      escapeCSVValue(row.assignedTo),
      escapeCSVValue(row.salesOwner),
      escapeCSVValue(row.createdDate),
      escapeCSVValue(row.dueDate),
      escapeCSVValue(row.is312Client),
      escapeCSVValue(row.isEmployeeAffiliate),
    ];
    csvRows.push(values.join(','));
  }
  
  const csvContent = csvRows.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadFile(blob, filename);
};

// Generate statistics summary for reports
export interface ReportStatistics {
  totalCases: number;
  casesByType: { [key: string]: number };
  casesByStatus: { [key: string]: number };
  casesByRisk: { [key: string]: number };
  casesByLOB: { [key: string]: number };
  count312Cases: number;
  countEmployeeCases: number;
  avgDaysToCompletion: number;
  overdueCount: number;
}

export const generateReportStatistics = (cases: Case[]): ReportStatistics => {
  const stats: ReportStatistics = {
    totalCases: cases.length,
    casesByType: {},
    casesByStatus: {},
    casesByRisk: {},
    casesByLOB: {},
    count312Cases: 0,
    countEmployeeCases: 0,
    avgDaysToCompletion: 0,
    overdueCount: 0,
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let totalDaysToCompletion = 0;
  let completedCasesCount = 0;

  cases.forEach(caseItem => {
    // Count by type
    stats.casesByType[caseItem.caseType] = (stats.casesByType[caseItem.caseType] || 0) + 1;
    
    // Count by status
    stats.casesByStatus[caseItem.status] = (stats.casesByStatus[caseItem.status] || 0) + 1;
    
    // Count by risk
    stats.casesByRisk[caseItem.riskLevel] = (stats.casesByRisk[caseItem.riskLevel] || 0) + 1;
    
    // Count by LOB
    const lob = caseItem.lineOfBusiness || 'Unknown';
    stats.casesByLOB[lob] = (stats.casesByLOB[lob] || 0) + 1;
    
    // Count 312 cases
    if (caseItem.is312Case) {
      stats.count312Cases++;
    }
    
    // Count employee cases
    if (caseItem.clientData?.isEmployee) {
      stats.countEmployeeCases++;
    }
    
    // Calculate days to completion for completed cases
    if (caseItem.status === 'Complete' || caseItem.status === 'Closed') {
      const created = new Date(caseItem.createdDate);
      const completed = new Date(caseItem.lastActivity || caseItem.createdDate);
      const days = Math.floor((completed.getTime() - created.getTime()) / (1000 * 60 * 60 * 24));
      totalDaysToCompletion += days;
      completedCasesCount++;
    }
    
    // Count overdue cases
    const dueDate = new Date(caseItem.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    if (dueDate < today && caseItem.status !== 'Complete' && caseItem.status !== 'Closed') {
      stats.overdueCount++;
    }
  });

  // Calculate average days to completion
  if (completedCasesCount > 0) {
    stats.avgDaysToCompletion = Math.round(totalDaysToCompletion / completedCasesCount);
  }

  return stats;
};

// Export statistics to JSON
export const exportStatisticsToJSON = (cases: Case[], filename: string): void => {
  const stats = generateReportStatistics(cases);
  const jsonContent = JSON.stringify(stats, null, 2);
  const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
  downloadFile(blob, filename);
};

// ============================================================================
// DELINQUENCY REPORT FUNCTIONS
// ============================================================================

// Delinquency Report Data Structure
export interface DelinquencyReportRow {
  clientId: string;
  gci: string;
  coperId: string;
  lineOfBusiness: string;
  is312Client: string;
  isEmployeeAffiliate: string;
  refreshDueDate: string;
  case312DueDate: string;
  camCaseDueDate: string;
  centralTeamMember: string;
  salesOwner: string;
  daysOverdue: number;
  caseStatus: string;
}

// Helper function to determine if a case is delinquent
export const isCaseDelinquent = (caseItem: Case): boolean => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Check if case is in an open status (not Complete or Closed)
  const openStatuses = ['Unassigned', 'In Progress', 'Pending Sales Review', 'In Sales Review', 
                        'Sales Review Complete', 'Under Review', 'Escalated', 'Defect Remediation'];
  const isOpen = openStatuses.includes(caseItem.status);

  if (!isOpen) {
    return false; // Case is closed, not delinquent
  }

  // Check if any refresh due date has expired
  if (caseItem.refreshDueDates && caseItem.refreshDueDates.length > 0) {
    const hasExpiredRefresh = caseItem.refreshDueDates.some(dateStr => {
      const refreshDate = new Date(dateStr);
      refreshDate.setHours(0, 0, 0, 0);
      return refreshDate < today;
    });
    
    if (hasExpiredRefresh) {
      return true;
    }
  }

  // Also check main case due date
  const caseDueDate = new Date(caseItem.dueDate);
  caseDueDate.setHours(0, 0, 0, 0);
  if (caseDueDate < today) {
    return true;
  }

  return false;
};

// Get the most overdue refresh date
const getMostOverdueRefreshDate = (refreshDates: string[] | undefined): string => {
  if (!refreshDates || refreshDates.length === 0) {
    return 'N/A';
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Find the earliest date that is in the past
  const overdueDates = refreshDates
    .map(d => new Date(d))
    .filter(d => {
      d.setHours(0, 0, 0, 0);
      return d < today;
    })
    .sort((a, b) => a.getTime() - b.getTime());

  if (overdueDates.length > 0) {
    return overdueDates[0].toLocaleDateString();
  }

  // If no overdue dates, return the earliest upcoming date
  const sortedDates = refreshDates
    .map(d => new Date(d))
    .sort((a, b) => a.getTime() - b.getTime());

  return sortedDates.length > 0 ? sortedDates[0].toLocaleDateString() : 'N/A';
};

// Calculate days overdue (most overdue date)
const calculateDaysOverdue = (caseItem: Case): number => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let earliestOverdueDate: Date | null = null;

  // Check refresh due dates
  if (caseItem.refreshDueDates && caseItem.refreshDueDates.length > 0) {
    const overdueDates = caseItem.refreshDueDates
      .map(d => new Date(d))
      .filter(d => {
        d.setHours(0, 0, 0, 0);
        return d < today;
      });

    if (overdueDates.length > 0) {
      earliestOverdueDate = overdueDates.sort((a, b) => a.getTime() - b.getTime())[0];
    }
  }

  // Check main case due date
  const caseDueDate = new Date(caseItem.dueDate);
  caseDueDate.setHours(0, 0, 0, 0);
  if (caseDueDate < today) {
    if (!earliestOverdueDate || caseDueDate < earliestOverdueDate) {
      earliestOverdueDate = caseDueDate;
    }
  }

  if (earliestOverdueDate) {
    const diffTime = today.getTime() - earliestOverdueDate.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }

  return 0;
};

// Generate Delinquency Report data from cases
export const generateDelinquencyReport = (cases: Case[]): DelinquencyReportRow[] => {
  // Filter to only delinquent cases
  const delinquentCases = cases.filter(isCaseDelinquent);

  return delinquentCases.map(caseItem => ({
    clientId: caseItem.clientId || caseItem.clientData?.clientId || 'N/A',
    gci: caseItem.gci,
    coperId: caseItem.coperId || 'N/A',
    lineOfBusiness: caseItem.lineOfBusiness || caseItem.clientData?.lineOfBusiness || 'N/A',
    is312Client: caseItem.is312Case ? 'Yes' : 'No',
    isEmployeeAffiliate: caseItem.clientData?.isEmployee ? 'Yes' : 'No',
    refreshDueDate: getMostOverdueRefreshDate(caseItem.refreshDueDates),
    case312DueDate: caseItem.case312Data?.dueDate 
      ? new Date(caseItem.case312Data.dueDate).toLocaleDateString() 
      : 'N/A',
    camCaseDueDate: caseItem.camCaseData?.dueDate 
      ? new Date(caseItem.camCaseData.dueDate).toLocaleDateString() 
      : 'N/A',
    centralTeamMember: caseItem.assignedTo || 'Unassigned',
    salesOwner: caseItem.clientData?.salesOwner || 'N/A',
    daysOverdue: calculateDaysOverdue(caseItem),
    caseStatus: caseItem.status,
  }));
};

// Export Delinquency Report to CSV
export const exportDelinquencyReportToCSV = (data: DelinquencyReportRow[], filename: string): void => {
  const headers = [
    'Client ID',
    'GCI',
    'CoPer ID',
    'Line of Business',
    '312 Client Flag',
    'BAC Affiliate/Employee Flag',
    'Refresh Due Date',
    '312 Case Due Date',
    'CAM Case Due Date',
    'Central Team Member',
    'Sales Owner',
    'Days Overdue',
    'Case Status'
  ];

  const csvRows = [];
  csvRows.push(headers.join(','));

  for (const row of data) {
    const values = [
      escapeCSVValue(row.clientId),
      escapeCSVValue(row.gci),
      escapeCSVValue(row.coperId),
      escapeCSVValue(row.lineOfBusiness),
      escapeCSVValue(row.is312Client),
      escapeCSVValue(row.isEmployeeAffiliate),
      escapeCSVValue(row.refreshDueDate),
      escapeCSVValue(row.case312DueDate),
      escapeCSVValue(row.camCaseDueDate),
      escapeCSVValue(row.centralTeamMember),
      escapeCSVValue(row.salesOwner),
      escapeCSVValue(String(row.daysOverdue)),
      escapeCSVValue(row.caseStatus),
    ];
    csvRows.push(values.join(','));
  }

  const csvContent = csvRows.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadFile(blob, filename);
};

// Export Delinquency Report to Excel
export const exportDelinquencyReportToExcel = (data: DelinquencyReportRow[], filename: string): void => {
  const headers = [
    'Client ID',
    'GCI',
    'CoPer ID',
    'Line of Business',
    '312 Client Flag',
    'BAC Affiliate/Employee Flag',
    'Refresh Due Date',
    '312 Case Due Date',
    'CAM Case Due Date',
    'Central Team Member',
    'Sales Owner',
    'Days Overdue',
    'Case Status'
  ];

  const rows = [];
  rows.push(headers.join('\t'));

  for (const row of data) {
    const values = [
      row.clientId,
      row.gci,
      row.coperId,
      row.lineOfBusiness,
      row.is312Client,
      row.isEmployeeAffiliate,
      row.refreshDueDate,
      row.case312DueDate,
      row.camCaseDueDate,
      row.centralTeamMember,
      row.salesOwner,
      String(row.daysOverdue),
      row.caseStatus,
    ];
    rows.push(values.join('\t'));
  }

  const tsvContent = rows.join('\n');
  const blob = new Blob([tsvContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  downloadFile(blob, filename);
};
