//1
package com.bp.dealmigration.recon;

import java.util.HashSet;

import java.util.Set;

import java.lang.Math;

import java.text.DecimalFormat;

import com.olf.openjvs.*;

import com.olf.openjvs.enums.*;

public abstract class DealMigrationReconciliation implements DealMigrationReconciliationConstants {

protected int buId = 0;

protected int reconDate = 0;

protected int reconPeriod = 0;

protected int reconTranStatus = 0;

protected int reconHideDrilldownDetails = -1;

protected String reconDataFile = null;

protected String reconRunIds = null;

protected Table extraDataTable = null;

protected Table userSvpDataReconParameters = null;

protected DealMigrationReconciliationUtil util = null;

//2
//Public Methods

public abstract Table getReconDetails() throws Exception;

public void handleCellClick (Table callbackTable) throws OException {

String callbackName = callbackTable.scriptDataGetCallbackName();

if (callbackName.equals(CALLBACK_EXPAND_COLLAPSE)) {

int callbackRow = callbackTable.scriptDataGetCallbackRow();

int group = callbackTable.getInt(COL_GROUP, callbackRow);

if (group < 1)

return;

int numRows = callbackTable.getNumRows();

int callbackCol = callbackTable.scriptDataGetCallbackCol();

String callbackColName = callbackTable.getColName (callbackCol);

int expanded = callbackTable.getInt(COL_EXPANDED, callbackRow);

if (expanded > 0) { // currently is expanded, want to collapse

int row = callbackRow + 1;

while (row <= numRows) {

int tgroup = callbackTable.getInt(COL_GROUP, row);

if (tgroup < group) {

callbackTable.setRowHideStatus (row, HIDE);

if (tgroup > RPT_LEVEL_1_GROUP) {

callbackTable.setInt(COL_EXPANDED, row, NOT_EXPANDED); 
setCellSymbolPlus (callbackTable, callbackColName, row);

//3
}

} else

break;

row++;

}

callbackTable.setInt(COL_EXPANDED, callbackRow, NOT_EXPANDED);

setCellSymbolPlus (callbackTable, callbackColName, callbackRow);

} else { // currently is collapsed, want to expand


int row = callbackRow + 1;

while (row <= numRows) {

int tgroup = callbackTable.getInt(COL_GROUP, row);

if (tgroup < group) {

if (tgroup == (group-1)) {

callbackTable.setRowHideStatus (row, UNHIDE);

if (tgroup > RPT_LEVEL_1_GROUP) {

callbackTable.setInt(COL_EXPANDED, row, NOT_EXPANDED);

setCellSymbolPlus (callbackTable, callbackColName, row);

}

}

} else

break;

row++;

}

callbackTable.setInt(COL_EXPANDED, callbackRow, EXPANDED);

setCellSymbolMinus (callbackTable, callbackColName, callbackRow);
}
}
//4


int numRows = callbackTable.getNumRows();

for (int row=numRows; row>0; row--)

callbackTable.scriptDataSetRowSelectStatus (row, 0);

sendRefreshMessage(callbackTable);
}

public void handleCellDoubleClick(Table callbackTable) throws OException {

Table dataSourceForDrillDownTable = null;

try {

String callbackName = callbackTable.scriptDataGetCallbackName();

if (callbackName == null || !callbackName.equalsIgnoreCase (CALLBACK_DRILLDOWN)) return;

int rptCol = callbackTable.scriptDataGetCallbackCol();

int rptRow = callbackTable.scriptDataGetCallbackRow();

boolean detailsShown = false;

Table extraDrilldownTable = getExtraDrilldownTable(callbackTable);

if (extraDrilldownTable == null) {

OConsole.oprint("getExtraDrilldownTable() returned null\n");

return;
}

Table extraDataSourceTable = getExtraDataSourceTable (callbackTable);

if (extraDataSourceTable == null) {

OConsole.oprint("getExtraDataSourceTable() returned null\n");
//5
return;

}

int numGroups = extraDrilldownTable.getNumGroups();

if (numGroups != 4) {

extraDrilldownTable.clearGroupBy();

extraDrilldownTable.addGroupBy(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_ROW.toColName());

extraDrilldownTable.addGroupBy(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_COL.toColName());

extraDrilldownTable.addGroupBy(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_DS_TABLE_NAME.toColName());

extraDrilldownTable.addGroupBy(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_DS_ROW.toColName());

extraDrilldownTable.groupBy();
}
dataSourceForDrillDownTable = getDataSourceForDrillDownTable (extraDrilldownTable, extraDataSourceTable, rptCol, rptRow);

if (dataSourceForDrillDownTable == null){

OConsole.oprint("getDataSourceForDrillDownTable() returned null\n");

return;
}
detailsShown = true;

dataSourceForDrillDownTable.viewTable(1);

dataSourceForDrillDownTable.destroy();

int numRows = callbackTable.getNumRows();

for (int row=numRows; row>0; row--)
//6
callbackTable.scriptDataSetRowSelectStatus (row, 0);

sendRefreshMessage(callbackTable);

if (!detailsShown)

Ask.ok("No drill-down details available for this cell");

} catch (OException e) {

clearCache();

throw new OException(e.getLocalizedMessage());

} finally {

if (dataSourceForDrillDownTable != null)

dataSourceForDrillDownTable.destroy();

}

}

//Protected Methods

protected boolean doublesAreSame (double d1, double d2) throws OException {
return Math.abs(d1 - d2) < THRESHOLD;
}
protected String getChain(String chainNumber) throws OException {

int len = chainNumber.length();

if (len == 0) return "";

String ret = null;

if (len == 1) ret = "UG000" + chainNumber;
//7
else if (len == 2) ret = "UG00" + chainNumber;

else if (len == 3) ret = "UG0" + chainNumber;

else if (len == 4) ret = "UG" + chainNumber;

return ret;

}

protected Set<String> getOtpDealReferences (Table dataSourceOtpTable, String otpDealReferenceColName) throws OException {

Set<String>otpDealReferences = new HashSet<String>();

int numRow = dataSourceOtpTable.getNumRows();

for (int row=1; row<=numRow; row++) {

String dealReference = dataSourceOtpTable.getString (otpDealReferenceColName, row);

if (dealReference != null && !dealReference.isEmpty()) otpDealReferences.add(dealReference);

}

return otpDealReferences;

}

protected int getBppnaBU() throws OException {

if (buId == 0) {

buId = Ref.getValue(SHM_USR_TABLES_ENUM.PARTY_TABLE, ESCANDI_GAS_BU);

}

return buId;

}

protected int getReconDate() throws OException {

if (reconDate == 0) {

reconDate = OCalendar.today();

}

return reconDate;

}
//8
protected int getReconPeriod() throws OException {

if (reconPeriod == 0) {

reconPeriod = 5;

}

return reconPeriod;

}

protected int getReconTranStatus() throws OException {

if (reconTranStatus == 0) {

reconTranStatus = 2; // Validated status

}

return reconTranStatus;

}

protected int getReconHideDrilldownDetails() throws OException {

if (reconHideDrilldownDetails < 0) {

reconHideDrilldownDetails = Ref.getValue(SHM_USR_TABLES_ENUM.NO_YES_TABLE, YES);
}
return reconHideDrilldownDetails;
}

protected String getReconDataFile() throws OException {

if (reconDataFile == null) {

reconDataFile = "";

}

return reconDataFile;

}

protected void clearCache() throws OException {

if (userSvpDataReconParameters != null) userSvpDataReconParameters.destroy();

}
//9
protected DealMigrationReconciliationUtil getUtil() throws OException {

if (util == null) {

util = new DealMigrationReconciliationUtil();

}

return util;

}

protected String createSqlStringFromColumn (Table srcTable, String colName, Set<String> chainToExclude) throws OException {

COL_TYPE_ENUM colType = COL_TYPE_ENUM.fromInt(srcTable.getColType (colName));

if (colType != COL_TYPE_ENUM.COL_STRING || srcTable.getNumRows() < 1) return null;

Set<String> valueSet = new HashSet<String>();

int numRows = srcTable.getNumRows();

for (int row=1; row<=numRows; row++) {

String chain = srcTable.getString(ENUM_DS_EXPO_OTP_COL.INTERNAL_PORTFOLIO_v16.toColName(), row);

if (chainToExclude.contains (chain)) continue;

String value = srcTable.getString(colName, row);

if (value == null || value.isEmpty()) continue;

valueSet.add(value);
}

if (valueSet.isEmpty()) return null;

String ret = "";

for (String val: valueSet) {

ret +="'" + val + "', ";

}

return ret.replaceAll(", $", "");

}

protected Table getSvpDataReconParameters() throws OException {

if ( userSvpDataReconParameters == null) {

userSvpDataReconParameters = new Table (USER_SVP_DATA_RECON_PARAMETERS);
//10
 String sql = "\nSELECT * FROM "+ USER_SVP_DATA_RECON_PARAMETERS;

DBaseTable.execISql(userSvpDataReconParameters, sql);

if (userSvpDataReconParameters.getNumRows() < 1)

throw new OException (USER_SVP_DATA_RECON_PARAMETERS +" table is empty");

userSvpDataReconParameters.clearGroupBy();

userSvpDataReconParameters.addGroupBy("endurv16_type");

userSvpDataReconParameters.addGroupBy("endurv18_type"); 

userSvpDataReconParameters.addGroupBy("endurv16_value");

userSvpDataReconParameters.addGroupBy("endurv18_value");

userSvpDataReconParameters.groupBy();

}

return userSvpDataReconParameters;

}

protected Table createSimResultsTable (String simResultEnum, String simName, String scenarioName, int queryId) throws OException {

int resultId = SimResult.getResultIdFromEnum (simResultEnum);

if (resultId < 1){

throw new OException("Sim result " + simResultEnum +" does not exist in this database");
}
int origSystemDate = OCalendar.today();

Table args = createRevalArgs(queryId, simResultEnum, simName, scenarioName);

if (origSystemDate != getReconDate())

Util.setCurrentDate(getReconDate());

Table simResults = null;

try {

simResults = Sim.runRevalByParamFixed(args);

} catch (OException e) {

throw new OException (e.getLocalizedMessage());

} finally {
if (origSystemDate != getReconDate()) 
Util.setCurrentDate (origSystemDate);
}
//11
if (simResults == null) {
throw new OException("Failed to compute sim results");
}
//simResults.viewTable(1);

Table tGenResult = SimResult.getGenResults (simResults);

if (tGenResult == null) {

throw new OException("No Gen results in saved sim results");
}
int resultRow = tGenResult.unsortedFindInt("result_type", resultId);

if (resultRow < 1) {

throw new OException("No "+ simName +" results were computed");

}

Table genResults = tGenResult.getTable("result", resultRow);

if (genResults == null) {

throw new OException (simName + " result table is null");

}

Table ret = genResults.copyTable();

ret.deleteWhereValue("index", Ref.getValue(SHM_USR_TABLES_ENUM.INDEX_TABLE, DISC_INDEX));

return ret;
}

protected Table createRevalArgs(int queryId, String simResultEnum, String simName, String scenarioName) throws OException {

Table args = new Table("reval_args");

Table simDefTable = Sim.createSimDefTable();

Sim.addSimulation (simDefTable, simName);

// create the result list

Table resultList = Sim.createResultListForSim();

SimResult.addResultForSim (resultList, SimResultType.create(simResultEnum));

Sim.addScenario (simDefTable, simName, scenarioName, Ref.getValue(SHM_USR_TABLES_ENUM.CURRENCY_TABLE, "USD"));
//12

Sim.addResultListToScenario (simDefTable, simName, scenarioName, resultList);

// Create a reval_param table

Table revalParam = new Table();

Sim.createRevalTable(revalParam);

revalParam.setInt("QueryId", 1, queryId);

revalParam.setInt("SimRunId", 1, -1);

revalParam.setInt("SimDefId", 1, -1);

revalParam.setInt("RunType", 1, SIMULATION_RUN_TYPE.INTRA_DAY_SIM_TYPE.toInt());

revalParam.setTable("SimulationDef", 1, simDefTable);

revalParam.setInt("UseClose", 1, 0);

revalParam.setInt("PriorRunType", 1, SIMULATION_RUN_TYPE.EOD_SIM_TYPE.toInt());

// Add the reval table to the args

args.addCol("RevalParam", COL_TYPE_ENUM.COL_TABLE);

args.addRow();

args.setTable("RevalParam", 1, revalParam);

return args;
}

protected Table getDataSourceForDrillDownTable (Table extraDrilldownTable, Table extraDataSourceTable, int rptCol, int rptRow) throws OException {

int rptRowStart = 0, rptRowEnd = 0, rptColStart = 0, rptColEnd = 0;

if ((rptRowStart = extraDrilldownTable.findInt(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_ROW.toColName(), rptRow, SEARCH_ENUM.FIRST_IN_GROUP)) < 1)    return null;

rptRowEnd = extraDrilldownTable.findInt(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_ROW.toColName(), rptRow, SEARCH_ENUM.LAST_IN_GROUP);

if ((rptColStart = extraDrilldownTable.findIntRange (ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_COL.toColName(),
rptRowStart, rptRowEnd, rptCol, SEARCH_ENUM.FIRST_IN_GROUP)) < 1) return null; 
rptColEnd = extraDrilldownTable.findIntRange (ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_COL.toColName(), rptRowStart, rptRowEnd, rptCol, SEARCH_ENUM.LAST_IN_GROUP);
//13

String dataSourcetableName = extraDrilldownTable.getString(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_DS_TABLE_NAME.toColName(), rptColStart);

Table dataSourceTable = null;

for (int row=1; row<=extraDataSourceTable.getNumRows(); row++) {

dataSourceTable = extraDataSourceTable.getTable(1, row);

if (dataSourceTable != null && dataSourceTable.getNumRows() > 0) {

String dsTableName = dataSourceTable.getTableName();

if (dsTableName.equals(dataSourcetableName)) break;

}

}

if (dataSourceTable == null || dataSourceTable.getNumRows() < 1) return null;

Table t = dataSourceTable.cloneTable();

int dsRowStart = extraDrilldownTable.getInt(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_DS_ROW.toColName(), rptColStart);

int dsRowEnd = extraDrilldownTable.getInt(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_DS_ROW.toColName(), rptColEnd);

dataSourceTable.copyRowAddRange (dsRowStart, dsRowEnd, t);

t.setTableTitle (dataSourcetableName +" rows: " + dsRowStart + " - " + dsRowEnd);

return t;
}

protected Table getExtraDrilldownTable (Table t) throws OException {
Table extraDataTable = t.scriptDataGetExtraDataTable();

return (extraDataTable == null) ? null: extraDataTable.getTable (COL_EXTRA_DRILLDOWN, 1);
}

protected Table getExtraDataSourceTable (Table t) throws OException {
Table extraDataTable = t.scriptDataGetExtraDataTable();
return (extraDataTable == null) ? null: extraDataTable.getTable(COL_EXTRA_DATASOURCE, 1);
}
protected void createExtraDataTable (Table reportTable, Table dataSourceOtpTable, Table dataSourceEndurTable) throws OException {
//14


OConsole.message(" ---> Running createExtraDataTable()\n");

extraDataTable = new Table (TBL_EXTRA_DATA);

extraDataTable.addCol(COL_EXTRA_DATASOURCE, COL_TYPE_ENUM.COL_TABLE);

extraDataTable.addCol(COL_EXTRA_DRILLDOWN, COL_TYPE_ENUM.COL_TABLE);

extraDataTable.addRow();

Table extraDataSourceTable = new Table (TBL_EXTRA_DATASOURCE);

for (ENUM_EXTRA_DATASOURCE_COL e : ENUM_EXTRA_DATASOURCE_COL.values()) {

extraDataSourceTable.addCol(e.toColName(), e.toColType());
}

extraDataSourceTable.addNumRows(2);

extraDataSourceTable.setTable (1, 1, dataSourceOtpTable.copyTable());

extraDataSourceTable.setTable (1, 2, dataSourceEndurTable.copyTable());

Table extraDrilldownTable = new Table (TBL_EXTRA_DRILLDOWN);

for (ENUM_EXTRA_DRILLDOWN_COL e : ENUM_EXTRA_DRILLDOWN_COL.values()) {

extraDrilldownTable.addCol(e.toColName(), e.toColType());
}

extraDataTable.setTable (COL_EXTRA_DATASOURCE, 1, extraDataSourceTable);

extraDataTable.setTable (COL_EXTRA_DRILLDOWN, 1, extraDrilldownTable);

reportTable.scriptDataSetExtraData (extraDataTable);
}

protected void createExtraDataTable (Table reportTable, Table dataSourceTable) throws OException {

OConsole.message(" ---> Running createExtraDataTable()\n");

extraDataTable = new Table (TBL_EXTRA_DATA);

extraDataTable.addCol(COL_EXTRA_DATASOURCE, COL_TYPE_ENUM.COL_TABLE);

extraDataTable.addCol(COL_EXTRA_DRILLDOWN, COL_TYPE_ENUM.COL_TABLE);

extraDataTable.addRow();

Table extraDataSourceTable = new Table (TBL_EXTRA_DATASOURCE);

for (ENUM_EXTRA_DATASOURCE_COL e : ENUM_EXTRA_DATASOURCE_COL.values()) {
//15

extraDataSourceTable.addCol(e.toColName(), e.toColType());
}

int numDsRows = dataSourceTable.getNumRows();

for (int dsRow=1; dsRow<=numDsRows; dsRow++){

COL_TYPE_ENUM colType = COL_TYPE_ENUM.fromInt(dataSourceTable.getColType(1));

if (colType == COL_TYPE_ENUM.COL_TABLE) {
Table dsTable = dataSourceTable.getTable (1, dsRow);

int extraDsRow = extraDataSourceTable.addRow();

extraDataSourceTable.setTable (1, extraDsRow, dsTable.copyTable());
}
}

Table extraDrilldownTable = new Table(TBL_EXTRA_DRILLDOWN);

for (ENUM_EXTRA_DRILLDOWN_COL e : ENUM_EXTRA_DRILLDOWN_COL.values()) {
extraDrilldownTable.addCol(e.toColName(), e.toColType());
}
extraDataTable.setTable (COL_EXTRA_DATASOURCE, 1, extraDataSourceTable);

extraDataTable.setTable (COL_EXTRA_DRILLDOWN, 1, extraDrilldownTable);

reportTable.scriptDataSetExtraData (extraDataTable);
}

protected Table getExtraDrilldownTable(String extraDataTableName) throws OException {

if (extraDataTable == null || extraDataTable.getNumRows() < 1) {

throw new OException (extraDataTableName + " is empty or not initialized");

}

int extraDrilldownCol = extraDataTable.getColNum(COL_EXTRA_DRILLDOWN);

if (extraDrilldownCol < 1) {

 throw new OException (extraDataTableName + " is not properly initialized - missing column: " + COL_EXTRA_DRILLDOWN);
}
Table t = null;

t = extraDataTable.getTable (extraDrilldownCol, 1);

if (t == null || t.getNumCols() < 1) {

throw new OException (TBL_EXTRA_DRILLDOWN + " is not properly initialized");
//16

}

return t;
}

protected void addDrilldownDetail (String dataSourceTableName, String extraDataTableName, int dataSourceStartRow, int dataSourceEndRow, int reportCol, int reportRow) throws OException {

Table extraDrilldownTable = getExtraDrilldownTable(extraDataTableName);

for (int dsRow=dataSourceStartRow; dsRow<=dataSourceEndRow; dsRow++) {

int row = extraDrilldownTable.addRow();

extraDrilldownTable.setString(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_DS_TABLE_NAME.toColName(), row, dataSourceTableName);

extraDrilldownTable.setInt(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_DS_ROW.toColName(), row, dsRow);

extraDrilldownTable.setInt(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_COL.toColName(), row, reportCol); 

extraDrilldownTable.setInt(ENUM_EXTRA_DRILLDOWN_COL.EXTRA_DRILLDOWN_RPT_ROW.toColName(), row, reportRow);

}

}

protected String getDataSourceColNameFromTaField(String taFieldName, Table dataSourceTable) throws OException {

String dataSourceTableName = dataSourceTable.getTableName();

String ret = taFieldName;

if (dataSourceTableName.contains (OTP))

return ret.replaceAll(REGEX_TA_OTP_PREFIX, "");

if (dataSourceTableName.contains (ENDUR))

return ret.replaceAll(REGEX_TA_ENDUR_PREFIX, "");

return null;

}

protected void setReportCellValue (Table reportTable, int rptCol, int rptRow, Table dataSourceTable, String dataSourceColName, int dataSourceRow, String cellFormat) throws OException {
COL_TYPE_ENUM daColType = COL_TYPE_ENUM.fromInt(dataSourceTable.getColType (dataSourceColName));

switch (daColType) {
//17
case COL_INT:

int intValue = dataSourceTable.getInt(dataSourceColName, dataSourceRow);

reportTable.setCellInt(rptCol, rptRow, intValue, cellFormat);

break;

case COL_STRING:

String rawValue = dataSourceTable.getString(dataSourceColName, dataSourceRow);

String strValue = rawValue == null || rawValue.isEmpty() ? DATA_NOT_FOUND : rawValue;

if (strValue.equals(DATA_NOT_FOUND)) cellFormat = CELL_COLOR_FMT_WHEAT;

reportTable.setCellString(rptCol, rptRow, strValue, cellFormat);

break;

case COL_DOUBLE:

double dblValue = dataSourceTable.getDouble(dataSourceColName, dataSourceRow);

DecimalFormat df = new DecimalFormat("#.#####");

String formatedDouble = df.format(dblValue);

reportTable.setCellString (rptCol, rptRow, formatedDouble, cellFormat);

break;

case COL_DATE:

int dateValue = dataSourceTable.getDate(dataSourceColName, dataSourceRow);

reportTable.setCellDate(rptCol, rptRow, dateValue, cellFormat);

break;

case COL_DATE_TIME:

int dateTimeValue = dataSourceTable.getDate(dataSourceColName, dataSourceRow); 
reportTable.setCellDate(rptCol, rptRow, dateTimeValue, cellFormat);

break;

default: break;

}

}

protected boolean cellIsDataNotFound (Table tbl, int col, int row) throws OException {

TABLE_COL_CELL_TYPE_ENUM cellType = TABLE_COL_CELL_TYPE_ENUM.fromInt(tbl.getCellType(col, row));

if (cellType == TABLE_COL_CELL_TYPE_ENUM.CELL_TYPE_STRING) {

String cellStr = tbl.getCellString(col, row);
//18
return cellStr == null ? false : cellStr.equals(DATA_NOT_FOUND);

}

return false;

}

protected double getDoubleFromCell(Table tbl, int col, int row) throws OException {

TABLE_COL_CELL_TYPE_ENUM cellType = TABLE_COL_CELL_TYPE_ENUM.fromInt(tbl.getCellType(col, row));

double ret = 0.0;

switch (cellType) {

case CELL_TYPE_INT:

ret = tbl.getCellInt(col, row);

break;

case CELL_TYPE_DOUBLE:

ret = tbl.getCellDouble(col, row);;

break;

case CELL_TYPE_STRING:

ret = Str.strToDouble(tbl.getCellString(col, row));

break;

default:

break;

}

return ret;

}

protected String getSqlString(int queryId, String selectFieldsPhys, String selectFieldsFin) throws OException {

String sql = "\nSELECT DISTINCT"

+ selectFieldsPhys

+ "\nFROM"

+ "\n ab_tran ab,"

+ "\n instruments ins,"

+ "\n portfolio pf,"

+ "\n parameter pa,"
//19

+"\n  pwr_phys_param ppp,"

+ "\n pwr_locations ppl,"

+ "\n idx_def idx,"

+ "\n query_result qr"

+ "\nWHERE 1=1"

+ "\n AND ab.ins_type = ins.id_number"

+ "\n AND ab.internal_portfolio = pf.id_number"

+ "\n AND ab.ins_num = pa.ins_num"

+ "\n AND ab.ins_num = ppp.ins_num"

+ "\n AND ab.tran_num = qr.query_result"

+ "\n AND pa.proj_index = idx.index_id"

+ "\n AND (ppp.location_id = ppl.location_id OR ppp.location_id = 0)"

+ "\n AND ab.current_flag = 1"

+ "\n AND ab.tran_status = 2"

//+ "\n AND pa.param_seq_num > 0"

//+ "\n AND ppp.param_seq_num > 0"

+ "\n AND qr.unique_id = " + queryId

+ "\n AND ins.name IN ('" + PWR_ANSVC_PHYS + "','" + PWR_CI_PHYS_BLOCK + "', '" + PWR_CI_RETAIL + "', '" + PWR_CAP + "',

'"+ PWR_HR_PHYS + "','" + PWR_PHYS + "', '"+PWR_PHYS_CI_BLOCK+"','"+PWR_CI_CAP+"')"

+ "\n AND ab.deal_tracking_num IN (30001381,30001390,30001432,30001870,30001859,30001868,30001246,30001371,30001838,30001320,30001832,30001815,30001446,30001618,30001465,30001349,30001850,30001698,30001829,30001858,30001480,30001940,30001785,30001893,30001548,30001632,30001808,30001822,30001653,30001615,30001572,30001521,30001279,30001702,30001821,30001867,30001830,30001857,30001772,30001447,30001338,30001276,30001860,30001788,30001826,30001797,30001804,30001817,30001862,30001518,30001350,30001235 ,30001661,30001367,30001751)"
+ "\nUNION ALL"

+ "\nSELECT DISTINCT "

+ selectFieldsFin

+ "\nFROM"

+ "\n ab_tran ab,"

+ "\n instruments ins,"

+ "\n portfolio pf,"

+ "\n parameter pa,"

+ "\n idx_subgroup isg,"
//20
+ "\n idx_def idx,"

+"\n query_result qr"

+"\nWHERE 1=1"

+ "\n AND ab.ins_type = ins.id_number"

+ "\n AND ab.internal_portfolio = pf.id_number"

+ "\n AND ab.ins_num = pa.ins_num"

+ "\n AND ab.idx_subgroup = isg.id_number"

+ "\n AND ab.tran_num = qr.query_result"

+ "\n AND pa.proj_index = idx.index_id"

+ "\n AND ab.current_flag = 1"

+ "\n AND ab.tran_status = 2"

+ "\n AND ab.tran_type = 0"

+ "\n AND qr.unique_id = " + queryId

+ "\n AND ins.name IN ( '" + PWR_ANSVC_SWAP + "','" + PWR_CI_DAM_PTP + "','"+ PWR_CI_RETAIL_FIN + "', '"+ PWR_CI_VIRTUAL + "','"+ PWR_CAP_SWAP + "','"+ PWR_PT_VIRTUAL + "','" + PWR_SWAP_FTR + "')"    
+ "\n AND ab.deal_tracking_num IN (30000087,30000088,30000086,30000090,30000085,30000089)";

return sql;

}

protected String getSqlStringv16Export (int queryId, String selectFieldsPhys, String selectFieldsFin) throws OException {

String sql = "\nSELECT DISTINCT"

+ selectFieldsPhys

+ "\nFROM"

+ "\n ab_tran ab,"

+ "\n instruments ins,"

+ "\n portfolio pf,"

+ "\n parameter pa,"

+ "\n pwr_phys_param ppp,"

+ "\n pwr_locations ppl,"

+ "\n idx_def idx,"

+ "\n query_result qr"

+ "\nWHERE 1=1"

+ "\n AND ab.ins_type = ins.id_number"
//21

+ "\n AND ab.internal_portfolio = pf.id_number"

+ "\n AND ab.ins_num = pa.ins_num"

+ "\n AND ab.ins_num = ppp.ins_num"

+ "\n AND ab.tran_num = qr.query_result"

+ "\n AND pa.proj_index = idx.index_id"

+ "\n AND ppp.location_id = ppl.location_id"

+ "\n AND ab.current_flag = 1"

//+ "\n AND pa.param_seq_num > 0"

//+ "\n AND ppp.param_seq_num > 0"

+ "\n AND qr.unique_id = " + queryId

+ "\n AND ins.name IN ('" + PWR_ANSVC_PHYS + "', '" + PWR_CI_PHYS_BLOCK + "', '" + PWR_CI_RETAIL + "', '"+  PWR_CAP +"', '"+ PWR_HR_PHYS +"', '" + PWR_PHYS + "', '" + PWR_PHYS_CI_BLOCK+"', '" + PWR_CI_CAP+"')" 

+ "\nUNION ALL"

+ "\nSELECT DISTINCT "

+ selectFieldsFin

+ "\nFROM"

+ "\n ab_tran ab,"

+ "\n instruments ins,"

+ "\n portfolio pf,"

+ "\n parameter pa,"

+ "\n idx_subgroup isg,"

+ "\n idx_def idx,"

+ "\n query_result qr"

+ "\nWHERE 1=1"

+ "\n AND ab.ins_type = ins.id_number"

+ "\n AND ab.internal_portfolio = pf.id_number"

+ "\n AND ab.ins_num = pa.ins_num"

+ "\n AND ab.idx_subgroup = isg.id_number"

+ "\n AND ab.tran_num = qr.query_result"

+ "\n AND pa.proj_index = idx.index_id"

+ "\n AND ab.current_flag = 1"

+ "\n AND ab.tran_type = 0"

+ "\n AND qr.unique_id = " + queryId 
//22

+ "\n AND ins.name IN ( '"+ PWR_ANSVC_SWAP +"', '" + PWR_CI_DAM_PTP +"','" + PWR_CI_RETAIL_FIN +"', '" + PWR_CI_VIRTUAL + "', '" + PWR_CAP_SWAP + "', '" + PWR_PT_VIRTUAL + "', '" + PWR_SWAP_FTR + "')";

return sql;

}

//Private Methods

private void sendRefreshMessage (Table t) throws OException {

Table t2 = new Table();

Services.publishLocal (t2, t.getTableName());
}

private void setCellSymbolMinus (Table t, String colName, int row) throws OException {

String cellFormat = t.getCellFormat(colName, row);

cellFormat = cellFormat.replace(CELL_SYMBOL_PLUS, CELL_SYMBOL_MINUS);

t.setCellString(colName, row, t.getCellString(colName, row), cellFormat);
}

private void setCellSymbolPlus (Table t, String colName, int row) throws OException {

String cellFormat = t.getCellFormat(colName, row);

cellFormat = cellFormat.replace(CELL_SYMBOL_MINUS, CELL_SYMBOL_PLUS);

t.setCellString(colName, row, t.getCellString(colName, row), cellFormat);
}
}