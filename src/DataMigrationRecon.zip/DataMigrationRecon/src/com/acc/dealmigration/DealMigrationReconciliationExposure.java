// 1 1-34
package com.acc.dealmigration;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;
import com.olf.openjvs.*;
import com.olf.openjvs.enums.*;
public class DealMigrationReconciliationExposure extends DealMigrationReconciliation
implements DealMigrationReconciliationConstants {
private String simResultEnum = "USER_RESULT_APM_DELTA";
private String simName = "APM Delta";
private String scenarioName = "Power Retail Migration Recon Exposure v24";

private int queryId = 0;
private Table dataSourceEndurTable = null;
private Table dataSourceEndurV16Table = null;
private Table metricsTable = null;
private Set<String> otpDealReferences = null;
//Constructors 
public DealMigrationReconciliationExposure() throws OException {
}
public DealMigrationReconciliationExposure (String reconDataFile, int reconDate, int reconPeriod,

int reconTranStatus, int reconHideDrilldownDetails) throws OException {
this.reconDataFile = reconDataFile;
this.reconDate = reconDate;
this.reconPeriod = reconPeriod;
this.reconTranStatus = reconTranStatus;
this.reconHideDrilldownDetails = reconHideDrilldownDetails;
}

//Public Methods
public Table getReconDetails() throws Exception {
Table reconDetails = null;
try {
reconDetails = createReportTable();
//2 35-66
} catch (OException e) {
throw new OException(e.getLocalizedMessage());
} finally {
clearCache();
}
return reconDetails;
}

//Protected Methods
protected void clearCache() throws OException {
super.clearCache();
if (dataSourceEndurV16Table != null)
dataSourceEndurV16Table.destroy();
if (dataSourceEndurTable != null) 
dataSourceEndurTable.destroy();
if (metricsTable != null)
metricsTable.destroy();
if (queryId > 0)
Query.clear(queryId);
}

//Private Methods
private Table fetchApmDeltaResults() throws OException {
Table combinedPortfolioAPM = null;
Table tSimResult = null;
Table tGenResult = null;
Table tApmDeltaResult = null;
try {
int[] portfolioIds = { 20682,20674,20721,20699,20733, 20737, 20748, 20749 };// TODO: based on the run Id's get respective 
 if (dataSourceEndurTable == null) 
{ 
// distinct portfolio list //
for (int row = 0; row < 4; row++) {
//3 67-98
OConsole.message(" ---> Running getDataSourceEndurv24Table_NEW()\n");
// Fetching simulation results from blob //
tSimResult = SimResult.tableLoadSrun (portfolioIds[row], SIMULATION_RUN_TYPE.INTRA_DAY_SIM_TYPE.toInt(),getReconDate());

if (tSimResult == null) {
throw new OException("Failed to load saved sim results");
}
// Fetching General Results out of sim results //
tGenResult = SimResult.getGenResults (tSimResult);
if (tGenResult == null) {
throw new OException("No Gen results in saved sim results");
}
// Fetching APM delta results out of General results //
int resultId = SimResult.getResultIdFromEnum (simResultEnum);
int resultRow = tGenResult.unsortedFindInt("result_type", resultId);
if (resultRow < 1) {
throw new OException("No prior WAC result found in saved sim results");
}
tApmDeltaResult = tGenResult.getTable("result", resultRow);
if (tApmDeltaResult == null) {
throw new OException("ApmDelta result table is null");
}
if(combinedPortfolioAPM == null) {
combinedPortfolioAPM = tApmDeltaResult.cloneTable();
}
tApmDeltaResult.copyRowAddAll(combinedPortfolioAPM);
}
//4 99- 130
dataSourceEndurTable = combinedPortfolioAPM.copyTable();
}
return dataSourceEndurTable;
} catch (OException e) {
clearCache();
throw new OException(e.getLocalizedMessage());
} finally {
if (combinedPortfolioAPM != null) {
combinedPortfolioAPM.destroy();
}
if (tSimResult != null) {
tSimResult.destroy();
}
if (tGenResult != null) {
tGenResult.destroy();
}
if (tApmDeltaResult != null) {
tApmDeltaResult.destroy();
}
}
}

private int GetResultType(String result) throws OException {
Table resultTbl = Table.tableNew();
int resultType = 0;
try {
String sql = "select id_number from pfolio_result_type where name ='" + result + "'";
com.olf.openjvs.DBase.runSqlFillTable(sql, resultTbl);
resultType = resultTbl.getInt(1, 1);
} catch (OException ex) {

} finally {
if (resultTbl != null)
//5 131-162
resultTbl.destroy();
}
return resultType;
}

private Table getDataSourceEndurv18Table() throws OException {
if (dataSourceEndurTable == null) {
OConsole.message(" ---> Running getDataSourceEndurTable()\n");
Table deltaResultsTable = fetchApmDeltaResults();
Table enrichmentDataTable = createEnrichmentData();

// deltaResultsTable.viewTable();
// enrichmentDataTable.viewTable();

dataSourceEndurTable = deltaResultsTable.copyTable();
dataSourceEndurTable.addCol("blank_for_comparison", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.select(enrichmentDataTable,
"internal_portfolio, ins_type_name, projection_index, location, deal_reference", "deal_num EQ $deal_num AND deal_leg EQ $deal_leg");

int internalPortfolioColumn = dataSourceEndurTable.getColNum("internal_portfolio");
dataSourceEndurTable.deleteWhereString(internalPortfolioColumn,"");

if (deltaResultsTable != null)
deltaResultsTable.destroy();
if (enrichmentDataTable != null)
enrichmentDataTable.destroy();

dataSourceEndurTable.setTableName (TBL_EXPO_DATASOURCE_ENDURV24);

dataSourceEndurTable.insertCol (ENUM_DS_EXPO_ENDUR_COL.EXPO_MT.toColName(),
ENUM_DS_EXPO_ENDUR_COL.DELTA.toColName(), ENUM_DS_EXPO_ENDUR_COL.EXPO_MT.toColType());
//6 163 194
dataSourceEndurTable.addCol(ENUM_DS_EXPO_ENDUR_COL.SERIES_PERIOD_YYYYMM.toColName(),ENUM_DS_EXPO_ENDUR_COL.SERIES_PERIOD_YYYYMM.toColType());

// dataSourceEndurTable.viewTable();
int dateCol = dataSourceEndurTable.getColNum("date");
int seriesPeriodCol = dataSourceEndurTable
.getColNum(ENUM_DS_EXPO_ENDUR_COL.SERIES_PERIOD_YYYYMM.toColName());

int fvDeltaCol = dataSourceEndurTable.getColNum(ENUM_DS_EXPO_ENDUR_COL.FV_DELTA.toColName());
int expoMtCol = dataSourceEndurTable.getColNum (ENUM_DS_EXPO_ENDUR_COL.EXPO_MT.toColName());

int numRows = dataSourceEndurTable.getNumRows();
for (int row = 1; row <= numRows; row++) {
double expoMt = dataSourceEndurTable.getDouble(fvDeltaCol, row) / DELTA_SHIFT;
dataSourceEndurTable.setDouble (expoMtCol, row, expoMt);

int date = dataSourceEndurTable.getInt(dateCol, row);
int mth = OCalendar.getMonth(date);
int year = OCalendar.getYear(date);

String mthStr = mth < 10 ? "0" + Str.intToStr(mth) : Str.intToStr(mth);
String yrStr = Str.intToStr(year);
String seriesPeriod = "endurv24_" + yrStr + mthStr;
dataSourceEndurTable.setString(seriesPeriodCol, row, seriesPeriod);
}

int numCols = dataSourceEndurTable.getNumCols();
if (getReconHideDrilldownDetails() == Ref.getValue(SHM_USR_TABLES_ENUM.NO_YES_TABLE, YES)) {
for (int col = numCols; col > 0; col--) {
String colName = dataSourceEndurTable.getColName(col);
boolean foundColumn = false;
for (ENUM_DS_EXPO_ENDUR_COL e : ENUM_DS_EXPO_ENDUR_COL.values()) {
//7 195-225
if (e.toColName().equals(colName)) {
foundColumn = true;
break;
}
}
if (!foundColumn)
dataSourceEndurTable.setColHideStatus (col, HIDE);
}
}
dataSourceEndurTable.clearGroupBy();

dataSourceEndurTable.addGroupBy(ENUM_DS_EXPO_ENDUR_COL.INTERNAL_PORTFOLIO.toColName());
dataSourceEndurTable.addGroupBy(ENUM_DS_EXPO_ENDUR_COL.PROJECTION_INDEX.toColName());
dataSourceEndurTable.addGroupBy(ENUM_DS_EXPO_ENDUR_COL.LOCATION.toColName());
dataSourceEndurTable.addGroupBy(ENUM_DS_EXPO_ENDUR_COL.SERIES_PERIOD_YYYYMM.toColName());
dataSourceEndurTable.addGroupBy(ENUM_DS_EXPO_ENDUR_COL.DEAL_NUM.toColName());
dataSourceEndurTable.addGroupBy(ENUM_DS_EXPO_ENDUR_COL.DEAL_LEG.toColName());
dataSourceEndurTable.groupBy();
}
return dataSourceEndurTable;
}

private Table createEnrichmentData() throws OException {
String selectFieldsPhys = "\n pf.name internal_portfolio," + "\n ins.name ins_type_name,"
+ "\n idx.index_name projection_index," + "\n idx.index_id," + "\n ppl.location_name location,"
+ "\n ab.deal_tracking_num deal_num," + "\n ab.reference deal_reference,"
+ "\n pa.param_seq_num deal_leg";

String selectFieldsFin = "\n pf.name internal_portfolio," + "\n ins.name ins_type_name,"
+ "\n idx.index_name projection_index," + "\n idx.index_id," + "\n isg.name location,"
 + "\n ab.deal_tracking_num deal_num," + "\n ab.reference deal_reference,"
 + "\n pa.param_seq_num deal_leg";
//8 227-258
String sql = getSqlString(getQueryId(), selectFieldsPhys, selectFieldsFin);

Table ret = new Table("enrich_data_table");

try {

DBaseTable.execISql(ret, sql);

} catch (OException e) {



ret.destroy();

throw new OException("SQL query failed in populateEndurExpoColumns(). SQL = " + sql);
}

if (ret == null || ret.getNumRows() < 0) {

throw new OException("SQL query return empty table in populateEndurExpoColumns(). SQL = " + sql);
}
ret.deleteWhereValue("index_id", Ref.getValue(SHM_USR_TABLES_ENUM.INDEX_TABLE, DISC_INDEX));
return ret;
}
private int getQueryId() throws OException {
if (queryId == 0) {
OConsole.message(" ---> Running getQueryId()\n");
Table temp = new Table("temp");
String selectFields = "\n ab.tran_num, ab.reference, ins.name ins_type";
String sql = getSqlString(selectFields, selectFields);
try {
DBaseTable.execISql(temp, sql);
} catch (OException e) {
temp.destroy();
throw new OException("Query failed with SQL = "+ sql);
}

// temp.viewTable();

int numRows = temp.getNumRows();
if (numRows > 0) {
for (int row = numRows; row > 0; row--) {
//9 259- 290
String insType = temp.getString(3, row);
String dealReference = temp.getInt(2, row) + "";
if (!getOtpDealReferences().contains (dealReference))
temp.delRow(row);
}

// temp.viewTable();
temp.delCol("v16_deal_tracking_num");
temp.delCol("ins_type");
temp.makeTableUnique();
queryId = Query.tableQueryInsert (temp, 1);
temp.destroy();
} else {
temp.destroy();
throw new OException("No Emission deals found with SQL = " + sql);
}
}
return queryId;
}

private Set<String> getOtpDealReferences() throws OException {
if (otpDealReferences == null) {
otpDealReferences = getOtpDealReferences (getDataSourceEndurV16Table(), ENUM_DS_EXPO_OTP_COL.DEAL_NUM_v16.toColName());
}
return otpDealReferences;
}

private Table getMetricsTable() throws OException {
Table dsOtpCopy = null;
Table userSvpDataReconParameters = null;
try
//10 291-322
{
if (metricsTable == null) {
OConsole.message(" ---> Running getMetricsTable()\n");
metricsTable = new Table (EXPOSURE_RECON + " Metrics Table");

dsOtpCopy = getDataSourceEndurV16Table().copyTable();
metricsTable.select(dsOtpCopy, "DISTINCT, internal_portfolio_v16, projection_index_v16", "deal_num_v16 GT 0");
dsOtpCopy.destroy();

userSvpDataReconParameters = getSvpDataReconParameters();
int ipStart = userSvpDataReconParameters.findString("endurv16_type", "Internal Portfolio", SEARCH_ENUM.FIRST_IN_GROUP);
int ipEnd = userSvpDataReconParameters.findString("endurv16_type", "Internal Portfolio", SEARCH_ENUM.LAST_IN_GROUP);
int piStart = userSvpDataReconParameters.findString("endurv16_type", "Projection Index", SEARCH_ENUM.FIRST_IN_GROUP);
int piEnd = userSvpDataReconParameters.findString("endurv16_type", "Projection Index", SEARCH_ENUM.LAST_IN_GROUP);

int numRows = metricsTable.getNumRows();
for (int row = numRows; row > 0; row--) {
String chainNumber = metricsTable.getString(ENUM_DS_EXPO_OTP_COL.INTERNAL_PORTFOLIO_v16.toColName(), row);
int validChainRow = userSvpDataReconParameters.findStringRange("endurv16_value", ipStart, ipEnd, chainNumber, SEARCH_ENUM.FIRST_IN_GROUP);
if (validChainRow < 1)
metricsTable.delRow(row);
} 
metricsTable.addCol(ENUM_DS_EXPO_ENDUR_COL.INTERNAL_PORTFOLIO.toColName(),
ENUM_DS_EXPO_ENDUR_COL.INTERNAL_PORTFOLIO.toColType(), ENUM_DS_EXPO_ENDUR_COL.INTERNAL_PORTFOLIO.toColTitle());
//11 323-354
metricsTable.addCol(ENUM_DS_EXPO_ENDUR_COL.PROJECTION_INDEX.toColName(),
ENUM_DS_EXPO_ENDUR_COL.PROJECTION_INDEX.toColType(),
ENUM_DS_EXPO_ENDUR_COL.PROJECTION_INDEX.toColTitle());
metricsTable.addCol(ENUM_DS_EXPO_ENDUR_COL.LOCATION.toColName(),
ENUM_DS_EXPO_ENDUR_COL.LOCATION.toColType(), ENUM_DS_EXPO_ENDUR_COL.LOCATION.toColTitle());

metricsTable.delCol(ENUM_DS_EXPO_OTP_COL.INS_TYPE_v16.toColName());
metricsTable.makeTableUnique();

metricsTable.clearGroupBy();
metricsTable.addGroupBy(ENUM_DS_EXPO_OTP_COL.INTERNAL_PORTFOLIO_v16.toColName());
metricsTable.addGroupBy(ENUM_DS_EXPO_OTP_COL.PROJECTION_INDEX_v16.toColName());
metricsTable.groupBy();

numRows = metricsTable.getNumRows();
int numCols = metricsTable.getNumCols();
for (int col = 1; col <= numCols; col++) {
for (int row = 1; row <= numRows; row++) {
String value = metricsTable.getString(col, row);
String colName = metricsTable.getColName(col);
if (colName.equals(ENUM_DS_EXPO_OTP_COL.INTERNAL_PORTFOLIO_v16.toColName())) {
int cnRow = userSvpDataReconParameters.findStringRange("endurv16_value", ipStart, ipEnd, value,SEARCH_ENUM.FIRST_IN_GROUP);
String internalPortfolio = userSvpDataReconParameters.getString("endurv24_value", cnRow);
metricsTable.setString(ENUM_DS_EXPO_ENDUR_COL.INTERNAL_PORTFOLIO.toColName(), row,
internalPortfolio);
}
if (colName.equals(ENUM_DS_EXPO_OTP_COL.PROJECTION_INDEX_v16.toColName())) {
int egRow = userSvpDataReconParameters.findStringRange("endurv16_value", piStart, piEnd, value, SEARCH_ENUM.FIRST_IN_GROUP);
String index = userSvpDataReconParameters.getString("endurv24_value", egRow);
//12 355-387
metricsTable.setString(ENUM_DS_EXPO_ENDUR_COL.PROJECTION_INDEX.toColName(), row, index);
}
}
}
}
return metricsTable;
}
finally {
if (dsOtpCopy != null)
dsOtpCopy.destroy();
if (userSvpDataReconParameters != null)
userSvpDataReconParameters.destroy();
}
}

private String getSeriesPeriodMonth (String seriesPeriod) throws OException {
String monthStr = null;
ENUM_MONTH_YEAR_FORMAT format = getUtil().getDateFormat(seriesPeriod);
switch (format) {
case YY_MON:
monthStr = ENUM_MONTH.fromMon (seriesPeriod.substring(seriesPeriod.lastIndexOf("-") + 1)).toMm();
break;
case YYYY_MON:
monthStr = ENUM_MONTH.fromMon (seriesPeriod.substring(seriesPeriod.lastIndexOf("-") + 1)).toMm();
break;
case MON_YY:
monthStr = ENUM_MONTH.fromMon (seriesPeriod.substring(0, seriesPeriod.indexOf("-"))).toMm(); break;
case MON_YYYY:
monthStr = ENUM_MONTH.fromMon (seriesPeriod.substring(0, seriesPeriod.indexOf("-"))).toMm();
break;
}
//13 388-419
return monthStr;
}

private String getSeriesPeriodYear (String seriesPeriod) throws OException {
String yearStr = null;
ENUM_MONTH_YEAR_FORMAT format = getUtil().getDateFormat(seriesPeriod);

switch (format) {
case YY_MON:
yearStr = "20" + seriesPeriod.substring(0, seriesPeriod.indexOf("-"));
break;
case YYYY_MON:
yearStr = seriesPeriod.substring(0, seriesPeriod.indexOf("-"));
break;
case MON_YY:
yearStr = "20" + seriesPeriod.substring(seriesPeriod.lastIndexOf("-") + 1);
break;
case MON_YYYY:
yearStr = seriesPeriod.substring(seriesPeriod.lastIndexOf("-") + 1);
break;
}
return yearStr;
}

private Table getDataSourceEndurV16Table() throws OException {
if (dataSourceEndurV16Table == null) {
OConsole.message(" ---> Running getDataSourceEndurV16Table()\n");
dataSourceEndurV16Table = getUtil().readCsvIntoTable (getReconDataFile());
if (dataSourceEndurV16Table == null || dataSourceEndurV16Table.getNumRows() < 1) {
throw new OException (TBL_EXPO_DATASOURCE_ENDURV16 + " is empty");
}
dataSourceEndurV16Table.setTableName(TBL_EXPO_DATASOURCE_ENDURV16);
//14 421 -452
String colName = ENUM_DS_EXPO_OTP_COL.EXPO_MT_v16.toColName();
if (dataSourceEndurV16Table.getColNum(colName) > 0)
getUtil().convertCsvTableColumnType(dataSourceEndurV16Table, colName, COL_TYPE_ENUM.COL_DOUBLE);
int numRows = dataSourceEndurV16Table.getNumRows();
for (ENUM_DS_EXPO_OTP_COL e : ENUM_DS_EXPO_OTP_COL.values()) {
if (dataSourceEndurV16Table.getColNum(e.toColName()) < 1) {
throw new OException("Missing " + e.toColName() + " column data in "+ getReconDataFile());
}
}

int numCols = dataSourceEndurV16Table.getNumCols();
if (getReconHideDrilldownDetails() == Ref.getValue(SHM_USR_TABLES_ENUM.NO_YES_TABLE, YES)) {
for (int col = numCols; col > 0; col--) {
String colNm = dataSourceEndurV16Table.getColName(col);
boolean foundColumn = false;
for (ENUM_DS_EXPO_OTP_COL e : ENUM_DS_EXPO_OTP_COL.values()) {
if (e.toColName().equals(colNm)) {
foundColumn = true;
break;
}
}
if (!foundColumn)
dataSourceEndurV16Table.setColHideStatus (col, HIDE);
}
}

dataSourceEndurV16Table.clearGroupBy();
dataSourceEndurV16Table.addGroupBy(ENUM_DS_EXPO_OTP_COL.INTERNAL_PORTFOLIO_v16.toColName());
dataSourceEndurV16Table.addGroupBy(ENUM_DS_EXPO_OTP_COL.PROJECTION_INDEX_v16.toColName());
// dataSourceEndurV16Table.addGroupBy(ENUM_DS_EXPO_OTP_COL.CONTRACTUAL_GRADE.toColName());
dataSourceEndurV16Table.addGroupBy(ENUM_DS_EXPO_OTP_COL.SERIES_PERIOD_YYYYMM_v16.toColName());
dataSourceEndurV16Table.addGroupBy(ENUM_DS_EXPO_OTP_COL.DEAL_REFERENCE_v16.toColName());
//15 453- 483
dataSourceEndurV16Table.addGroupBy(ENUM_DS_EXPO_OTP_COL.DEAL_LEG_v16.toColName());
dataSourceEndurV16Table.groupBy();
}
return dataSourceEndurV16Table;
}

private Table createReportTable() throws OException {
Table reportTable = new Table (TBL_EXPO_RPT); 
reportTable.setTableTitle (reportTable.getTableName());

reportTable.addCol(ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v16.toColName(), ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v16.toColType(), ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v16.toColTitle());

reportTable.addCol(ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v24.toColName(), ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v24.toColType(), ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v24.toColTitle());

reportTable.addCol(ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v16.toColName(), ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v16.toColType(), ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v16.toColTitle());

reportTable.addCol (ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v24.toColName(), ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v24.toColType(), ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v24.toColTitle());

reportTable.addCol(ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v16.toColName(), ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v16.toColType(), ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v16.toColTitle());

reportTable.addCol(ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v24.toColName(), ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v24.toColType(), ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v24.toColTitle());
//16 485- 517
createExtraDataTable(reportTable, getDataSourceEndurV16Table(), getDataSourceEndurv18Table());
	addMonthColumns(reportTable);
	populateMetricsOtpColumns(reportTable);
	populateOtpExpoColumns(reportTable);
	populateEndurExpoColumns(reportTable);
	populateTotalColumns(reportTable);
	return reportTable;
}
private void populateTotalColumns(Table reportTable) throws OException {
	OConsole.message(" ---> Running populateTotalColumns()\n");
	int numRows = reportTable.getNumRows();
	int numCols = reportTable.getNumCols();
	for (int row = 1; row <= numRows; row++) {
		double otpTotal = 0.0;
		double endurTotal = 0.0;
		for (int col = 9; col <= numCols; col++) {
			String colName = reportTable.getColName(col);
			double expo = reportTable.getCellDouble(col, row);
			if (colName.contains("endurv16_"))
				otpTotal += expo;
			if (colName.contains("endurv24_"))
				endurTotal += expo;
		}
		String otpCellFormat = CELL_COLOR_FMT_PALEGREEN + getUtil().getRowNumberFormat(otpTotal);
		String endurCellFormat = CELL_COLOR_FMT_LIGHTBLUE + getUtil().getRowNumberFormat(endurTotal);
		reportTable.setCellDouble(ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v16.toColName(), row, otpTotal, otpCellFormat);
		reportTable.setCellDouble(ENUM_RPT_EXPO_COL.ENDUR_TOTAL_v24.toColName(), row, endurTotal, endurCellFormat);
	}
}
//17 519 - 550
private void populateEndurExpoColumns(Table reportTable) throws OException {
OConsole.message(" ---> Running populateEndurExpoColumns()\n");
Table dataSourceEndurTable = getDataSourceEndurv18Table();
// dataSourceEndurTable.viewTable();
int rptIntPfolioCol = reportTable.getColNum(ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v24.toColName());
int rptProjIdxCol = reportTable.getColNum(ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v24.toColName());

int dsIntPfolioCol = dataSourceEndurTable.getColNum(ENUM_DS_EXPO_ENDUR_COL.INTERNAL_PORTFOLIO.toColName());
int dsProjIdxCol = dataSourceEndurTable.getColNum(ENUM_DS_EXPO_ENDUR_COL.PROJECTION_INDEX.toColName());
int dsLocationCol = dataSourceEndurTable.getColNum (ENUM_DS_EXPO_ENDUR_COL.LOCATION.toColName());
int dsSeriesPeriodYyyyMmCol = dataSourceEndurTable
.getColNum(ENUM_DS_EXPO_ENDUR_COL.SERIES_PERIOD_YYYYMM.toColName());
int dsExpoMtCol =dataSourceEndurTable.getColNum(ENUM_DS_EXPO_ENDUR_COL.FV_DELTA.toColName());
int rptNumRows = reportTable.getNumRows();
int rptNumCols = reportTable.getNumCols();
for (int rptRow = 1; rptRow <= rptNumRows; rptRow++) {
String intPfolio = reportTable.getCellString(rptIntPfolioCol, rptRow);
if (intPfolio == null || intPfolio.isEmpty()) {
throw new OException("Internal Portfolio is empty in report row = " + rptRow);
}
int dsIntPfolioStartRow = 0, dsIntPfolioEndRow = 0;
if ((dsIntPfolioStartRow = dataSourceEndurTable.findString(dsIntPfolioCol, intPfolio,
SEARCH_ENUM.FIRST_IN_GROUP)) < 1)
continue;
dsIntPfolioEndRow = dataSourceEndurTable.findString(dsIntPfolioCol, intPfolio, SEARCH_ENUM.LAST_IN_GROUP);
String projIdx = reportTable.getCellString(rptProjIdxCol, rptRow);
if (projIdx == null || projIdx.isEmpty()) {
//TODO//throw new OException("Projection Index is empty in report row = "+ rptRow); 
continue;
//18 551-582
}
int dsProjIdxStartRow = 0, dsProjIdxEndRow = 0;
if ((dsProjIdxStartRow = dataSourceEndurTable.findStringRange (dsProjIdxCol, dsIntPfolioStartRow, dsIntPfolioEndRow, projIdx, SEARCH_ENUM.FIRST_IN_GROUP)) < 1)
continue;
dsProjIdxEndRow = dataSourceEndurTable.findStringRange (dsProjIdxCol, dsIntPfolioStartRow, dsIntPfolioEndRow, projIdx, SEARCH_ENUM.LAST_IN_GROUP);

for (int rptCol = 8; rptCol <= rptNumCols; rptCol++) {
String exposureMonth = reportTable.getColName (rptCol);
// report table's colName is equivalent to
// SeriesPeriodYYYYMM
int dsSeriesPeriodYyyyMmStartRow = 0, dsSeriesPeriodYyyyMmEndRow = 0;

if ((dsSeriesPeriodYyyyMmStartRow = dataSourceEndurTable.findStringRange (dsSeriesPeriodYyyyMmCol, dsProjIdxStartRow, dsProjIdxEndRow, exposureMonth, SEARCH_ENUM.FIRST_IN_GROUP)) < 1)
continue;
dsSeriesPeriodYyyyMmEndRow = dataSourceEndurTable.findStringRange (dsSeriesPeriodYyyyMmCol, dsProjIdxStartRow, dsProjIdxEndRow, exposureMonth, SEARCH_ENUM.LAST_IN_GROUP);
double sumMonthlyExposure = dataSourceEndurTable.sumRangeDouble(dsExpoMtCol,
dsSeriesPeriodYyyyMmStartRow, dsSeriesPeriodYyyyMmEndRow);

String cellFormat = CELL_COLOR_FMT_LIGHTBLUE + getUtil().getRowNumberFormat(sumMonthlyExposure) + ","
+ CELL_DBLCLICK_DRILLDOWN;
reportTable.setCellDouble (rptCol, rptRow, sumMonthlyExposure, cellFormat);
addDrilldownDetail (TBL_EXPO_DATASOURCE_ENDURV24, TBL_EXPO_EXTRA_DATA, dsSeriesPeriodYyyyMmStartRow, dsSeriesPeriodYyyyMmEndRow, rptCol, rptRow);
}
}
}
//19 585- 615
private void populateOtpExpoColumns(Table reportTable) throws OException {
OConsole.message(" ---> Running populateOtpExpoColumns()\n");
Table dataSourceOtpTable = getDataSourceEndurV16Table();

int rptChainNumberCol = reportTable.getColNum(ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v16.toColName());

int rptExposureGradeCol = reportTable.getColNum(ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v16.toColName());

// int rptContractualGradeCol =

// reportTable.getColNum(ENUM_RPT_EXPO_COL.OTP_CONTRACTUAL_GRADE.toColName());

int dsChainNumberCol = dataSourceOtpTable.getColNum(ENUM_DS_EXPO_OTP_COL.INTERNAL_PORTFOLIO_v16.toColName());
int dsExposureGradeCol = dataSourceOtpTable.getColNum(ENUM_DS_EXPO_OTP_COL.PROJECTION_INDEX_v16.toColName());
int dsSeriesPeriodYyyyMmCol = dataSourceOtpTable.getColNum(ENUM_DS_EXPO_OTP_COL.SERIES_PERIOD_YYYYMM_v16.toColName());
int dsExpoMtCol = dataSourceOtpTable.getColNum(ENUM_DS_EXPO_OTP_COL.EXPO_MT_v16.toColName());
int rptNumRows = reportTable.getNumRows();
int rptNumCols = reportTable.getNumCols();
for (int rptRow = 1; rptRow <= rptNumRows; rptRow++) {
String chainNumber = reportTable.getCellString(rptChainNumberCol, rptRow);
if (chainNumber == null || chainNumber.isEmpty()) {
throw new OException("Chain Number is empty in report row = " + rptRow);
}
int dsChainNumberStartRow = 0, dsChainNumberEndRow = 0;
if ((dsChainNumberStartRow = dataSourceOtpTable.findString(dsChainNumberCol, chainNumber, SEARCH_ENUM.FIRST_IN_GROUP)) < 1)
continue;
dsChainNumberEndRow = dataSourceOtpTable.findString(dsChainNumberCol, chainNumber,
SEARCH_ENUM.LAST_IN_GROUP);
String exposureGrade = reportTable.getCellString(rptExposureGradeCol, rptRow);
if (exposureGrade == null || exposureGrade.isEmpty()) {
throw new OException("Exposure Grade is empty in report row = "+ rptRow);
//20 616-647
}

int dsExposureGradeStartRow = 0, dsExposureGradeEndRow = 0;

if ((dsExposureGradeStartRow = dataSourceOtpTable.findStringRange (dsExposureGradeCol, dsChainNumberStartRow, dsChainNumberEndRow, exposureGrade, SEARCH_ENUM.FIRST_IN_GROUP)) < 1)

continue;

dsExposureGradeEndRow = dataSourceOtpTable.findStringRange (dsExposureGradeCol, dsChainNumberStartRow, dsChainNumberEndRow, exposureGrade, SEARCH_ENUM.LAST_IN_GROUP);

String contractualGrade = "TEST";

if (contractualGrade == null || contractualGrade.isEmpty()) {
 throw new OException("Contractual Grade is empty in report row = " + rptRow);
}
int dsContractualGradeStartRow = 0, dsContractualGradeEndRow = 0;
/*
* if ((dsContractualGradeStartRow =
* dataSourceOtpTable.findStringRange (dsContractualGradeCol,
* dsExposureGradeStartRow, dsExposureGradeEndRow, contractualGrade,
* SEARCH_ENUM.FIRST_IN_GROUP)) < 1) continue; dsContractualGradeEndRow =
* dataSourceOtpTable.findStringRange (dsContractualGradeCol,
* dsExposureGradeStartRow, dsExposureGradeEndRow, contractualGrade,
* SEARCH_ENUM.LAST_IN_GROUP);
*/
for (int rptCol = 7; rptCol <= rptNumCols; rptCol++) {
String exposureMonth = reportTable.getColName (rptCol); // report table's colName is equivalent to
// SeriesPeriodYYYYMM
int dsSeriesPeriodYyyyMmStartRow = 0, dsSeriesPeriodYyyyMmEndRow = 0;
if ((dsSeriesPeriodYyyyMmStartRow = dataSourceOtpTable.findStringRange (dsSeriesPeriodYyyyMmCol,
dsExposureGradeStartRow, dsExposureGradeEndRow, exposureMonth,
SEARCH_ENUM.FIRST_IN_GROUP)) < 1)
continue;
dsSeriesPeriodYyyyMmEndRow = dataSourceOtpTable.findStringRange(dsSeriesPeriodYyyyMmCol, dsExposureGradeStartRow, dsExposureGradeEndRow, exposureMonth, SEARCH_ENUM.LAST_IN_GROUP);
//21 649- 679
double sumMonthlyExposure = dataSourceOtpTable.sumRangeDouble(dsExpoMtCol, dsSeriesPeriodYyyyMmStartRow,dsSeriesPeriodYyyyMmEndRow);

String cellFormat = CELL_COLOR_FMT_PALEGREEN + getUtil().getRowNumberFormat(sumMonthlyExposure) + "," + CELL_DBLCLICK_DRILLDOWN;
reportTable.setCellDouble (rptCol, rptRow, sumMonthlyExposure, cellFormat);

addDrilldownDetail(TBL_EXPO_DATASOURCE_ENDURV16, TBL_EXPO_EXTRA_DATA, dsSeriesPeriodYyyyMmStartRow, dsSeriesPeriodYyyyMmEndRow, rptCol, rptRow);
}
}
}

private void populateMetricsOtpColumns (Table reportTable) throws OException {
OConsole.message(" ---> Running populateMetricsOtpColumns()\n");
Table metricsTable = getMetricsTable();
try {
if (metricsTable.getNumRows() < 1) {
metricsTable.destroy();
throw new OException (metricsTable.getTableName() + " is empty");
}
int numMetricsRows = metricsTable.getNumRows();
for (int row = 1; row <= numMetricsRows; row++) {
String chainNumber = metricsTable.getString(ENUM_DS_EXPO_OTP_COL.INTERNAL_PORTFOLIO_v16.toColName(), row);

String exposureGrade = metricsTable.getString(ENUM_DS_EXPO_OTP_COL.PROJECTION_INDEX_v16.toColName(), row);
String internalPortfolio = metricsTable.getString(ENUM_DS_EXPO_ENDUR_COL.INTERNAL_PORTFOLIO.toColName(), row);
String index = metricsTable.getString(ENUM_DS_EXPO_ENDUR_COL.PROJECTION_INDEX.toColName(), row);
String location = metricsTable.getString(ENUM_DS_EXPO_ENDUR_COL.LOCATION.toColName(), row);
int rptRow = reportTable.addRow();
//22 680-711
reportTable.setCellString(ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v16.toColName(), rptRow, chainNumber, ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v16.toCellFormat());

reportTable.setCellString(ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v16.toColName(), rptRow, exposureGrade, ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v16.toCellFormat());
reportTable.setCellString(ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v24.toColName(), rptRow, internalPortfolio, ENUM_RPT_EXPO_COL.ENDUR_INT_PFOLIO_v24.toCellFormat());
reportTable.setCellString(ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v24.toColName(), rptRow, index, ENUM_RPT_EXPO_COL.ENDUR_PROJ_INDEX_v24.toCellFormat());
} 
}
finally {
if (metricsTable != null)
metricsTable.destroy();
}
}
private void addMonthColumns (Table reportTable) throws OException {
OConsole.message(" ---> Running addMonthColumns()\n");
int reconEndDate = OCalendar.parseStringWithHolId (getReconPeriod() + "y", NYC_HOLIDAY, getReconDate());
int numMonths = getUtil().getNumberOfMonths (getReconDate(), reconEndDate);
int dt = getReconDate();
for (int mth = 1; mth <= numMonths; ++mth) {
String mmStr = OCalendar.getMonth(dt) < 10 ? "0" + Str.intToStr(OCalendar.getMonth(dt))
:Str.intToStr(OCalendar.getMonth(dt));
String yyyyStr = Str.intToStr(OCalendar.getYear(dt));
 
String mmmStr = OCalendar.getMonthStr(dt);
String otpColName = "endurv16_" + yyyyStr + mmStr;
String otpColTitle = "ENDURv16 "+ mmmStr + "-" + yyyyStr;
reportTable.addCol (otpColName, COL_TYPE_ENUM.COL_CELL, otpColTitle);
String endurColName = "endurv24_" + yyyyStr + mmStr;
//23 712- 743
String endurColTitle = "ENDURv24 " + mmmStr + "-" + yyyyStr;
reportTable.addCol(endurColName, COL_TYPE_ENUM.COL_CELL, endurColTitle);
dt = OCalendar.parseStringWithHolId(mth + "m", NYC_HOLIDAY, getReconDate());
}
}
private String getSqlString(String selectFieldsPhys, String selectFieldsFin) throws OException {
String sql = "\nSELECT DISTINCT" + "\n ab.tran_num," + "\n utr.legacy_deal_id v16_deal_tracking_num,"
+ "\n ins.name ins_type" + "\n FROM" + "\n ab_tran ab," + "\n instruments ins," + "\n portfolio pf,"
+ "\n parameter pa," + "\n pwr_phys_param ppp," + "\n pwr_locations ppl,"
+ "\n idx_def idx," + "\n user_tran_regulatory utr" + "\nWHERE 1=1"
+ "\n AND ab.ins_type = ins.id_number" + "\n AND ab.internal_portfolio = pf.id_number"
+ "\n AND ab.ins_num = pa.ins_num" + "\n AND ab.ins_num = ppp.ins_num"
+ "\n AND pa.proj_index = idx.index_id" + "\n AND (ppp.location_id = ppl.location_id OR ppp.location_id = 0)\n"
+ "\n AND ab.tran_num = utr.tran_num" + "\n AND ab.current_flag = 1" + "\n AND ab.tran_status = 2"
+ "\n AND ins.name IN ('" + PWR_ANSVC_PHYS + "', '" + PWR_CI_PHYS_BLOCK + "', '" 
+ PWR_CI_RETAIL +  "', '" + PWR_CAP +  "', '"  + PWR_HR_PHYS +  "', '"  + PWR_PHYS +  "', '"  + PWR_PHYS_CI_BLOCK
+ "','"+PWR_CI_CAP+"')"
+ "\n AND ab.DEAL_TRACKING_NUM IN ("
+ "\n SELECT endur_deal_num FROM user_audit_deal_migration_dtl WHERE run_id in (62) and status = 'SUCCESS' and endur_deal_num <> 0\n"
+ "\n)" + "\nUNION ALL" + "\nSELECT DISTINCT " + "\n ab.tran_num,"
+ "\n utr.legacy_deal_id v16_deal_tracking_num," + "\n ins.name ins_type" + "\nFROM" + "\n ab_tran ab,"
+"\n instruments ins," + "\n portfolio pf," + "\n parameter pa," + "\n idx_subgroup isg," 
+ "\n idx_def idx," + "\n user_tran_regulatory utr" + "\nWHERE 1=1"
+ "\n AND ab.ins_type = ins.id_number" + "\n AND ab.internal_portfolio = pf.id_number" 
+ "\n AND ab.ins_num = pa.ins_num" + "\n  AND ab.idx_subgroup = isg.id_number"
+ "\n AND pa.proj_index = idx.index_id" + "\n AND ab.tran_num = utr.tran_num"
+ "\n AND ab.current_flag = 1" + "\n AND ab.tran_status = 2" + "\n AND ab.tran_type = 0"
+ "\n AND ins.name IN ('" + PWR_ANSVC_SWAP+ "','" + PWR_CI_DAM_PTP +"','"+ PWR_CI_RETAIL_FIN + "','"
+ PWR_CI_VIRTUAL + "','" + PWR_CAP_SWAP + "','" + PWR_PT_VIRTUAL + "', '" + PWR_SWAP_FTR + "')"
+ "\n AND ab.DEAL_TRACKING_NUM IN ("
+ "\n SELECT endur_deal_num FROM user_audit_deal_migration_dtl WHERE run_id in (67) and status = 'SUCCESS' and endur_deal_num <> 0\n"
+ "\n )";
//24  744-747
return sql;
}
}
