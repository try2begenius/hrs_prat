//1 1-33
package com.acc.dealmigration;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.UUID;
import com.olf.openjvs.*;
import com.olf.openjvs.enums.*;

public class DealMigrationReconciliationMain implements IScript, DealMigrationReconciliationConstants {

private DealMigrationReconciliation svpDataRecon = null;
private DealMigrationReconciliationUtil util = null;

private String reconTypeStr = null;
private String reconDateStr = null;
private String reconPeriodStr = null;
private String reconTranStatusStr = null;
private String reconHideDrilldownDetailsStr = null;
private String attributeReconIds = null;

@Override
public void execute (IContainerContext context) throws OException {
try {
doExecute(context);
} catch (Exception e) {
try {
Writer stringWriter = new StringWriter();
PrintWriter printWriter = new PrintWriter(stringWriter);
e.printStackTrace(printWriter);
Ask.ok("Exception - \n\n" + stringWriter.toString());
}
//2 34-66
catch (Exception ex) {
}
} finally {
clearCache();
}
}

private void clearCache() throws OException {
getUtil().clearCache();
}

private DealMigrationReconciliationUtil getUtil() throws OException {
if (util == null) {
util = new DealMigrationReconciliationUtil();
}
return util;
}

private void doExecute (IContainerContext context) throws OException {
Table returnt = context.getReturnTable();
if (returnt == null) return;
SCRIPT_PANEL_CALLBACK_TYPE_ENUM callbackType = SCRIPT_PANEL_CALLBACK_TYPE_ENUM.fromInt(returnt.scriptDataGetCallbackType());

switch (callbackType) {
case SCRIPT_PANEL_INIT:
initializeScreen();
break;
case SCRIPT_PANEL_PUSHBUTTON:
handlePushbutton (returnt);
break;
case SCRIPT_PANEL_CLICK:
setSvpDataRecon(returnt);
//3 67-99
svpDataRecon.handleCellClick(returnt);
break;
case SCRIPT_PANEL_DBLCLICK:
setSvpDataRecon(returnt);
svpDataRecon.handleCellDoubleClick(returnt);
break;
case SCRIPT_PANEL_RV_MESSAGE:
handleMessage(returnt);
break;
default:
break;
}
}

private void setSvpDataRecon (Table returnt) throws OException {
String tableTitle = returnt.getTableTitle();
if (tableTitle.equals(TBL_TAE_RPT))
svpDataRecon = new DealMigrationReconciliationTradeAttributesPhys();
}

private void handleMessage(Table t) throws OException {
String msgSubType = t.scriptDataGetMsgSubType();
if (Str.containsSubString (msgSubType, t.getTableName()) == 1) {
t.scriptDataSetRefreshType (SCRIPT_PANEL_REFRESH_ENUM.SCRIPT_PANEL_REFRESH_PANEL.toInt());
}
}

private void handlePushbutton(Table returnt) throws OException {
returnt.scriptDataSetRefreshType (SCRIPT_PANEL_REFRESH_ENUM.SCRIPT_PANEL_REFRESH_ALL.toInt());
String callbackName = returnt.scriptDataGetCallbackName();
if (callbackName.equals(WIDGET_RECON_RUN_BUTTON)) {
handleRunRecon (returnt);
}
//4 100-132
if (callbackName.equals(WIDGET_RECON_RUN_IDS_BUTTON)) {
handleReconRunIds(returnt);
}
else if (callbackName.equals(WIDGET_RECON_VIEW_DETAILS_BUTTON)) {
Table extraDataTable = returnt.scriptDataGetExtraDataTable();
if (extraDataTable != null)
extraDataTable.viewTable(1);
}
}

protected void handleReconRunIds (Table returnt) throws OException {
Table askTable = Table.tableNew();
try {
Ask.setTextEdit (askTable, "Success Run Id's", "", ASK_TEXT_DATA_TYPES.ASK_STRING, "Filename", 1);
int retval = Ask.viewTable (askTable, "Success Run Id's ( Comma seperated run id's string )", "");
String returnValueRunIds = askTable.getTable("return_value", 1).getString(1,1);
attributeReconIds = returnValueRunIds;
OConsole.oprint (returnValueRunIds);
} catch (OException e) {
e.printStackTrace();
}
finally {
if (askTable != null) {
askTable.destroy();
}
}
}

protected void handleRunRecon (Table returnt) throws OException{
Table reconTypeMenu = returnt.scriptDataGetWidgetMenu(WIDGET_RECON_TYPE_COMBOBOX);
Table reconMenuTypeSelect = returnt.scriptDataGetWidgetMenuSelect(WIDGET_RECON_TYPE_COMBOBOX);
reconTypeStr = getUtil().getMenuDisplayString(reconTypeMenu, reconMenuTypeSelect);
//5 133-163
if (reconTypeStr == null || reconTypeStr.isEmpty()) return;
Table reconPeriodMenu = returnt.scriptDataGetWidgetMenu(WIDGET_RECON_PERIOD_COMBOBOX);
Table reconPeriodMenuSelect = returnt.scriptDataGetWidgetMenuSelect(WIDGET_RECON_PERIOD_COMBOBOX);
reconPeriodStr = getUtil().getMenuDisplayString(reconPeriodMenu, reconPeriodMenuSelect);
if (reconPeriodStr == null || reconPeriodStr.isEmpty()) return;

Table reconTranStatusMenu = returnt.scriptDataGetWidgetMenu(WIDGET_RECON_TRAN_STATUS_COMBOBOX);
Table reconTranStatusMenuSelect = returnt.scriptDataGetWidgetMenuSelect (WIDGET_RECON_TRAN_STATUS_COMBOBOX);
reconTranStatusStr = getUtil().getMenuDisplayString (reconTranStatusMenu, reconTranStatusMenuSelect);
if (reconTranStatusStr == null || reconTranStatusStr.isEmpty()) return;

Table reconHideDrilldownDetailsMenu = returnt.scriptDataGetWidgetMenu(WIDGET_RECON_HIDE_DRILLDOWN_DETAILS_COMBOBOX);
Table reconHideDrilldownDetailsMenuSelect = returnt.scriptDataGetWidgetMenuSelect(WIDGET_RECON_HIDE_DRILLDOWN_DETAILS_COMBOBOX);
reconHideDrilldownDetailsStr = getUtil().getMenuDisplayString(reconHideDrilldownDetailsMenu, reconHideDrilldownDetailsMenuSelect);
if (reconHideDrilldownDetailsStr == null || reconHideDrilldownDetailsStr.isEmpty()) return;

reconDateStr = returnt.scriptDataGetWidgetString(WIDGET_RECON_DATE_COMBOBOX);
if (reconDateStr == null || reconDateStr.isEmpty()) return;

int reconDate = OCalendar.parseStringWithHolId(reconDateStr, -1);
int reconPeriod = Str.strToInt(reconPeriodStr);
int reconTranStatus = Ref.getValue(SHM_USR_TABLES_ENUM.TRANS_STATUS_TABLE, reconTranStatusStr);
int reconHideDrilldownDetails = Ref.getValue(SHM_USR_TABLES_ENUM.NO_YES_TABLE, reconHideDrilldownDetailsStr);

if (reconTypeStr.equals(TRADE_ATTRIBUTES_FIN_RECON) || reconTypeStr.equals(TRADE_ATTRIBUTES_PHYS_RECON) ||
reconTypeStr.equals(TRADE_ATTRIBUTES_REC_RECON) || reconTypeStr.equals(TRADE_ATTRIBUTES_GAS_RECON)) {
handleReconRunIds (returnt); // Accepting recon runids has input
}

String reconDataFile = getOtpReconData (reconTypeStr);
if (reconDataFile == null) return;
//6 164-196
if (reconTypeStr.equals(MTM_RECON) && ! reconTranStatusStr.equals (VALIDATED_STATUS)) {
 Ask.ok(MTM_RECON + " can only be ran using "+ VALIDATED_STATUS + " recon tran status");
return;
}

Table srcTable = null;
OConsole.message(" ---> START - "+ reconTypeStr + "\n");

try {

if(reconTypeStr.equals(TRADE_ATTRIBUTES_PHYS_RECON)) {
svpDataRecon = new DealMigrationReconciliationTradeAttributesPhys (reconDataFile, reconDate, reconPeriod, reconTranStatus, reconHideDrilldownDetails, attributeReconIds);
srcTable = svpDataRecon.getReconDetails();
}
else if(reconTypeStr.equals(TRADE_ATTRIBUTES_FIN_RECON)) {
svpDataRecon = new DealMigrationReconciliationTradeAttributesFin(reconDataFile, reconDate, reconPeriod, reconTranStatus, reconHideDrilldownDetails, attributeReconIds);
srcTable = svpDataRecon.getReconDetails();
}
else if(reconTypeStr.equals(TRADE_ATTRIBUTES_GAS_RECON)) {
svpDataRecon = new DealMigrationReconciliationTradeAttributesGas(reconDataFile, reconDate, reconPeriod, reconTranStatus, reconHideDrilldownDetails, attributeReconIds);
srcTable = svpDataRecon.getReconDetails();
}
else if(reconTypeStr.equals(TRADE_ATTRIBUTES_REC_RECON)) {
svpDataRecon = new DealMigrationReconciliationTradeAttributesRecs (reconDataFile, reconDate, reconPeriod,
reconTranStatus, reconHideDrilldownDetails, attributeReconIds);
srcTable = svpDataRecon.getReconDetails();
}
else if(reconTypeStr.equals (EXPOSURE_RECON)) {
svpDataRecon = new DealMigrationReconciliationExposure (reconDataFile, reconDate, reconPeriod, reconTranStatus, reconHideDrilldownDetails);
//7 197-228
srcTable = svpDataRecon.getReconDetails();
}
} catch (Exception e) {
String msg = e.getLocalizedMessage();
throw new OException (msg);
}

if (srcTable != null) {
//srcTable.viewTable();
refreshDataFromToTable(srcTable, returnt);
returnt.scriptDataSetRefreshType (SCRIPT_PANEL_REFRESH_ENUM.SCRIPT_PANEL_REFRESH_ALL.toInt());
srcTable.destroy();
}
OConsole.message(" ---> END - "+ reconTypeStr + "\n");
}
// TODO zzZZZZZZZZZZZ
// PNL needs 3 recon files from OTP
// Total YTD PNL for all delivery dates
// Total YTD PNL for before 7/17 delivery date
// Total L/YTD PNL for on and after 7/17 delivery date
private String getOtpReconData (String recon) throws OException {
Table askTable = new Table();
Ask.setTextEdit (askTable, "Endur V16 " + recon + " file", "", ASK_TEXT_DATA_TYPES.ASK_FILENAME, "Filename", 1);
int retval = Ask.viewTable (askTable, "Select Endur V16  "+ recon, recon);
if (retval <= 0) {
askTable.destroy();
return null;
}
String file = askTable.getTable(2,1).getString(1, 1);
return file;
}
//8 229-263
protected void refreshDataFromToTable (Table srcTable, Table destTable) throws OException {
Table extraDataTable = destTable.scriptDataGetExtraDataTable();
if (extraDataTable != null) {
int numCols = extraDataTable.getNumCols();
int numRows = extraDataTable.getNumRows();
for (int col=1; col<=numCols; col++) {
COL_TYPE_ENUM colType = COL_TYPE_ENUM.fromInt(extraDataTable.getColType(col));
if (colType == COL_TYPE_ENUM.COL_TABLE) {
for (int row=1; row<=numRows; row++) {
Table t = extraDataTable.getTable(col, row);
if (t != null) t.destroy();
}
}
}
extraDataTable.destroy();
destTable.scriptDataSetExtraData ((Table) null);
}
destTable.clearRows();
destTable.insertCol("XXXX", 1, COL_TYPE_ENUM.COL_STRING);
for (int col=destTable.getNumCols(); col>1; col--) // cannot delete all columns due to bug in core code
destTable.delCol(col);
for (int col=1; col<=srcTable.getNumCols(); col++) {
destTable.addCol(srcTable.getColName(col), COL_TYPE_ENUM.fromInt(srcTable.getColType(col)), srcTable.getColTitle(col));
srcTable.copyColFormat(col, destTable, col+1);
destTable.setColHideStatus(col+1, srcTable.getColHideStatus (col));
}
Table srcExtraDataTable = srcTable.scriptDataGetExtraDataTable();
if (srcExtraDataTable != null)
extraDataTable = srcTable.scriptDataGetExtraDataTable().copyTable();
if (extraDataTable != null) {
destTable.scriptDataSetExtraData (extraDataTable);
srcTable.scriptDataSetExtraData(null);
}
//9 264-297
destTable.delCol(1);
srcTable.copyRowAddAll (destTable);
String srcTableName = srcTable.getTableName();
destTable.setTableTitle(srcTableName);
}
private Table getReconTypeMenuTable() throws OException {
Table t = new Table("Recon Type");
t.addCol(WIDGET_RECON_TYPE_COMBOBOX, COL_TYPE_ENUM.COL_STRING, "Recon Type");
t.addNumRows(5);
t.setString(1, 1, TRADE_ATTRIBUTES_PHYS_RECON);
t.setString(1, 2, TRADE_ATTRIBUTES_FIN_RECON);
t.setString(1, 3, TRADE_ATTRIBUTES_GAS_RECON);
t.setString(1, 4, TRADE_ATTRIBUTES_REC_RECON);
t.setString(1, 5, EXPOSURE_RECON);
return t;
}

private Table getReconPeriodMenuTable() throws OException {
Table t = new Table("Recon Period");
t.addCol(WIDGET_RECON_PERIOD_COMBOBOX, COL_TYPE_ENUM.COL_STRING, "Recon Period");
int numRows = 9;
t.addNumRows (numRows);
for (int row=1; row<=numRows; row++) {
t.setString(1, row, Str.intToStr(row));
}
t.sortCol(1);
return t;
}

private Table getReconTranStatusMenuTable() throws OException {
Table t = new Table("Recon Tran Status");
t.addCol(WIDGET_RECON_TRAN_STATUS_COMBOBOX, COL_TYPE_ENUM.COL_STRING, "Recon Tran Status");
t.addNumRows(2);
//10 298-331
t.setString(1, 1, VALIDATED_STATUS);
t.setString(1, 2, PROPOSED_STATUS);
return t;
}
private Table getHideDrilldownDetailsMenuTable() throws OException {
Table t = new Table("Hide Drill-down Details");
t.addCol("yes_no", COL_TYPE_ENUM.COL_STRING, "Yes/No");
t.addNumRows(2);
t.setString(1, 1, YES);
t.setString(1, 2, NO);
return t;
}

protected void initializeScreen() throws OException {
getUtil().clearCache();
Table displayTable = new Table();
String tableName = "SVP Data Recon - " + UUID.randomUUID();
displayTable.setTableName (tableName);

int reconDate = OCalendar.today();
String reconDateString = OCalendar.formatJd(reconDate, DATE_FORMAT.DATE_FORMAT_DMLY_NOSLASH);
Table reconTypeMenu = getReconTypeMenuTable();
Table reconTypeMenuSelect = getUtil().getMenuSelectTable().copyTable();
getUtil().fillMenuSelect (TRADE_ATTRIBUTES_PHYS_RECON, reconTypeMenu, 1, reconTypeMenuSelect);
String reconType = getUtil().getMenuDisplayString(reconTypeMenu, reconTypeMenuSelect);

Table reconPeriodMenu = getReconPeriodMenuTable();
Table reconPeriodMenuSelect = getUtil().getMenuSelectTable().copyTable();
getUtil().fillMenuSelect("5", reconPeriodMenu, 1, reconPeriodMenuSelect);
String reconPeriod = getUtil().getMenuDisplayString(reconPeriodMenu, reconPeriodMenuSelect);
Table reconTranStatusMenu = getReconTranStatusMenuTable();
//11 332-365
Table reconTranStatusMenuSelect = getUtil().getMenuSelectTable().copyTable();
getUtil().fillMenuSelect (VALIDATED_STATUS, reconTranStatusMenu, 1, reconTranStatusMenuSelect);
String reconTranStatus = getUtil().getMenuDisplayString(reconTranStatusMenu, reconTranStatusMenuSelect);

Table hideDrilldownDetailsMenu = getHideDrilldownDetailsMenuTable();
Table hideDrilldownDetailsMenuSelect = getUtil().getMenuSelectTable().copyTable();
getUtil().fillMenuSelect (YES, hideDrilldownDetailsMenu, 1, hideDrilldownDetailsMenuSelect);
String hideDrillDownDetails = getUtil().getMenuDisplayString(hideDrilldownDetailsMenu, hideDrilldownDetailsMenuSelect);

displayTable.scriptDataMessageSubscribe (NOTIFY_MSG_DATA_TYPE.MSG_DATA_TABLE.toInt(),
MSG_TYPE_ENUM.USER_SCRIPT_MSG.toInt(), displayTable.getTableName(),
ECOM_SCOPE.LOCAL_MSG.toInt());

/***** Text Labels ********/

/******* First Column ************************/

displayTable.scriptDataAddWidget(
WIDGET_RECON_TYPE_LABEL,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_LABEL_WIDGET.toInt(),
"x=5, y=20, h=15,w=95", "just=RIGHT,label=Recon Type", null, null);

displayTable.scriptDataAddWidget(
WIDGET_RECON_PERIOD_LABEL, SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_LABEL_WIDGET.toInt(), 
"x=5, y=40, h=15, w=95", 
"just=RIGHT, label=Recon Period (yrs)", null, null);

/************************ Second Column ************************/

displayTable.scriptDataAddWidget(
WIDGET_RECON_DATE_LABEL, 
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_LABEL_WIDGET.toInt(), 
"x=240, y=20, h=15, w=95",
"just=RIGHT, label=Recon Date", null, null);
displayTable.scriptDataAddWidget(

//12 366-398
WIDGET_RECON_TRAN_STATUS_LABEL,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_LABEL_WIDGET.toInt(), 
"x=240, y=40, h=15,w=95", 
"just=RIGHT,label=Recon Tran Status", null, null);

/******* Third Column ************************/

displayTable.scriptDataAddWidget(
WIDGET_RECON_HIDE_DRILLDOWN_DETAILS_LABEL, 
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_LABEL_WIDGET.toInt(),
"x=475,y=20,h=15,w=130", 
"just=RIGHT,label=Hide Drilldown Details", null, null);

/******** Pick lists *************/

/************************ First Column ************************/

displayTable.scriptDataAddWidget(
WIDGET_RECON_TYPE_COMBOBOX,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_COMBOBOX_WIDGET.toInt(), 
"x=110, y=20, h=15, w=110", 
"just=LEFT, label=" + reconType, reconTypeMenu, reconTypeMenuSelect);

displayTable.scriptDataAddWidget(
WIDGET_RECON_PERIOD_COMBOBOX, 
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_COMBOBOX_WIDGET.toInt(),
 "x=110, y=40, h=15, w=110", 
"just=LEFT,label=" + reconPeriod, reconPeriodMenu, reconPeriodMenuSelect);

/************************ Second Column ************************/

displayTable.scriptDataAddWidget(
WIDGET_RECON_DATE_COMBOBOX,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_COMBOBOX_WIDGET.toInt(), 
"x=340, y=20, h=15, w=110",
" CALENDAR, just=LEFT, label=" + reconDateString);
//13 399-430

displayTable.scriptDataAddWidget(
WIDGET_RECON_TRAN_STATUS_COMBOBOX,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_COMBOBOX_WIDGET.toInt(),
"x=340, y=40, h=15, w=110",
"just=LEFT, label=" + reconTranStatus, reconTranStatusMenu, reconTranStatusMenuSelect);

/********* Third Column ************************/
displayTable.scriptDataAddWidget(
WIDGET_RECON_HIDE_DRILLDOWN_DETAILS_COMBOBOX,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_COMBOBOX_WIDGET.toInt(),
"x=610, y=20, h=15, w=110",
"just=LEFT, label=" + hideDrillDownDetails, hideDrilldownDetailsMenu, hideDrilldownDetailsMenuSelect);
/**************** Buttons**********/
displayTable.scriptDataAddWidget(
WIDGET_RECON_RUN_BUTTON,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_PUSHBUTTON_WIDGET.toInt(),
"x=-175, y=18, h=30, w=100",
"label=Run Recon", null, null);

displayTable.scriptDataAddWidget(
WIDGET_RECON_VIEW_DETAILS_BUTTON,
SCRIPT_PANEL_WIDGET_TYPE_ENUM.SCRIPT_PANEL_PUSHBUTTON_WIDGET.toInt(),
"x=-50, y=18, h=30, w=100",
"label=View Details", null, null);

displayTable.scriptDataMoveListBox("top=75,left=3, right=3,bottom=3");

displayTable.viewTable();
}
}

