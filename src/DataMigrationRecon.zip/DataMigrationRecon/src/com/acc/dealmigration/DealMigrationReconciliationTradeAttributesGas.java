//1 1-31
package com.acc.dealmigration.recon;

import java.util.HashSet;
import java.util.Set;

import com.olf.openjvs.*;
import com.olf.openjvs.enums.*;

public class DealMigrationReconciliationTradeAttributesGas extends DealMigrationReconciliation implements DealMigrationReconciliationConstants {

private Table metricsTable = null;
private Table dealNumsTable = null;
private Table dataSourceEndurTable = null;
private Table dataSourceOtpTable = null;
private Table userSvpDataReconTaFieldsTable = null;

private static String RPT_LEVEL_1_INDENT = "     ";
private static int RPT_START_COL_NUM = 11;

//Constructors
public DealMigrationReconciliationTradeAttributesGas () throws OException {
}

public DealMigrationReconciliationTradeAttributesGas (String reconDataFile, int reconDate, int reconPeriod, int reconTranStatus, int
reconHideDrilldownDetails, String attributeReconIds) throws OException {
this.reconDataFile = reconDataFile;
this.reconDate = reconDate;
this.reconPeriod = reconPeriod;
this.reconTranStatus = reconTranStatus;
this.reconHideDrilldownDetails = reconHideDrilldownDetails;
//2 32-66
this.reconRunIds = attributeReconIds;
}

//Public Methods
public Table getReconDetails() throws Exception {
Table reconDetails = null;
try {
reconDetails = createReportTable();
} catch (OException e) {
throw new OException(e.getLocalizedMessage());
} finally {
clearCache();
}
return reconDetails;
}

//Protected Methods
protected void clearCache() throws OException {
super.clearCache();
if (metricsTable != null) metricsTable.destroy();
if (dealNumsTable != null) dealNumsTable.destroy();
if (dataSourceOtpTable != null) dataSourceOtpTable.destroy();
if (dataSourceEndurTable != null) dataSourceEndurTable.destroy();
if (userSvpDataReconTaFieldsTable != null) userSvpDataReconTaFieldsTable.destroy();
}

//Private Methods
private enum ENUM_TA_FIELD_CAT {
DEAL("deal");
private String string;

ENUM_TA_FIELD_CAT (String string) {
this.string = string;
}
//3 68-98
public String toString() {
return this.string;
}
}

private Table getSvpDataReconTaFieldsTable() throws OException {
if (userSvpDataReconTaFieldsTable == null) {
OConsole.message(" ---> Running getSvpDataReconTaFieldsTable()\n");
userSvpDataReconTaFieldsTable = new Table (USER_SVP_DATA_RECON_TA_FIELDS);

String sql = "\nSELECT * FROM "+ USER_SVP_DATA_RECON_TA_FIELDS + " WHERE deal_type = 'Physical'";
try {
DBaseTable.execISql(userSvpDataReconTaFieldsTable, sql);
} catch (OException e) {
throw new OException("Error when querying "+ USER_SVP_DATA_RECON_TA_FIELDS + " table");
}
if (userSvpDataReconTaFieldsTable.getNumRows() < 1)
 throw new OException (USER_SVP_DATA_RECON_TA_FIELDS +" table is empty");

userSvpDataReconTaFieldsTable.clearGroupBy();
userSvpDataReconTaFieldsTable.addGroupBy("ta_field_category");
userSvpDataReconTaFieldsTable.addGroupBy("order_num");
userSvpDataReconTaFieldsTable.groupBy();
}
return userSvpDataReconTaFieldsTable;
}

private Table getDataSourceEndurTable() throws OException {
if (dataSourceEndurTable == null) {
OConsole.message(" ---> Running getDataSourceEndurTable()\n");
dataSourceEndurTable = new Table(TBL_TAE_DATASOURCE_ENDUR);
//4 99-131
String sql = "\n SELECT DISTINCT "
+ "\n abt.internal_portfolio as internal_portfolio_id,"
+ "\n abt.deal_tracking_num as v24_deal_tracking_num,"
+ "\n abt.tran_num,"
+ "\n insp.ins_num,"
+ "\n utr.legacy_deal_id v16_deal_tracking_num, \n"
+ "\n insp.param_seq_num as v24_param_seq_num,"
+ "\n abt.internal_bunit as internal_bunit_id,"
+ "\n abt.internal_lentity as internal_lentity_id,"
+ "\n abt.internal_portfolio as internal_portfolio_id,"
+ "\n abt.external_bunit as external_bunit_id,"
+ "\n abt.external_lentity as external_lentity_id,"
+ "\n abt.external_portfolio as external_portfolio_id,"
+ "\n abt.ins_type as ins_type_id,"
+ "\n abt.reference as v24_reference,"
+ "\n abt.buy_sell as buy_sell_id,"
+ "\n abt.start_date as v24_start_date,"
+ "\n abt.maturity_date as v24_maturity_date,"
+ "\n (select sum(prf.notnl) from profile prf where prf.ins_num = abt.ins_num and prf.notnl > 0) as OHD_v24_position,"
+ "\n abt.price as v24_price,"
+ "\n abt.rate as v24_rate,"
+ "\n prh.ref_source as id_number,"
+ "\n prh.index_loc_id as index_loc_id,"
+ "\n prmt.proj_index as proj_index_id,"
+ "\n insp.daily_volume as v24_daily_volume,"
+ "\n insp.notnl as v24_notnl,"
+ "\n insp.unit as unit_id,"
+ "\n insp.price_unit as price_unit_id,"
+ "\n insp.float_spd as v24_float_spd,"
+ "\n insp.index_multiplier as v24_index_multiplier,"
+ "\n insp.roll_conv as roll_conv_id,"
+ "\n insp.pymt_date_offset as v24_pymt_date_offset,"
+ "\n insp.payment_conv as payment_conv_id,"
//5 132-165
+ "\n insp.currency as currency_id,"
+ "\n insp.disc_index as disc_index_id"
+ "\n FROM AB_TRAN abt"
+ "\n JOIN ins_parameter insp ON insp.ins_num = abt.ins_num"
+ "\n JOIN parameter prmt ON prmt.ins_num = insp.ins_num and insp.param_seq_num = prmt.param_seq_num"
+ "\n JOIN param_reset_header prh ON prh.ins_num = insp.ins_num and prh.param_seq_num = insp.param_seq_num"
+ "\n JOIN user_tran_regulatory utr on abt.tran_num = utr.tran_num"
+ "\n WHERE abt.DEAL_TRACKING_NUM IN ("
+ "\n SELECT endur_deal_num FROM user_audit_deal_migration_dtl WHERE run_id in ( " + reconRunIds + ") and status = 'SUCCESS' \n"
+ "\n)"
+ "\n AND abt.current_flag = 1"
+ "\n AND abt.tran_status not in (5,14)";
try {
DBaseTable.execISql(dataSourceEndurTable, sql);
} catch (OException e) {
throw new OException("Query failed in getDataSourceEndurTable()\n SQL = " + sql);
}

// Adding new columns in front of their respective id columns, which will be further used to resolve to actual values //
dataSourceEndurTable.insertCol("v24_internal_bunit", "internal_bunit_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_internal_lentity", "internal_lentity_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_internal_portfolio", "internal_portfolio_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_external_bunit", "external_bunit_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_external_lentity", "external_lentity_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_external_portfolio", "external_portfolio_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_ins_type", "ins_type_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_buy_sell", "buy_sell_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_proj_index", "proj_index_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_unit", "unit_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_price_unit", "price_unit_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_roll_conv", "roll_conv_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_payment_conv", "payment_conv_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_currency", "currency_id", COL_TYPE_ENUM.COL_STRING);
//6 166-199
dataSourceEndurTable.insertCol("v24_disc_index", "disc_index_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_product", "product_id", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_ref_source", "id_number", COL_TYPE_ENUM.COL_STRING);
dataSourceEndurTable.insertCol("v24_index_location", "index_loc_id", COL_TYPE_ENUM.COL_STRING);

// Copying the reference values for given id column value //
dataSourceEndurTable.copyColFromRef("internal_bunit_id", "v24_internal_bunit", SHM_USR_TABLES_ENUM.PARTY_TABLE);
dataSourceEndurTable.copyColFromRef("internal_lentity_id", "v24_internal_lentity", SHM_USR_TABLES_ENUM.PARTY_TABLE);
dataSourceEndurTable.copyColFromRef("internal_portfolio_id", "v24_internal_portfolio", SHM_USR_TABLES_ENUM.PORTFOLIO_TABLE);
dataSourceEndurTable.copyColFromRef("external_bunit_id", "v24_external_bunit", SHM_USR_TABLES_ENUM.PARTY_TABLE);
dataSourceEndurTable.copyColFromRef("external_lentity_id", "v24_external_lentity", SHM_USR_TABLES_ENUM.PARTY_TABLE);
dataSourceEndurTable.copyColFromRef("external_portfolio_id", "v24_external_portfolio", SHM_USR_TABLES_ENUM.PORTFOLIO_TABLE);
dataSourceEndurTable.copyColFromRef("ins_type_id", "v24_ins_type", SHM_USR_TABLES_ENUM.INSTRUMENTS_TABLE);
dataSourceEndurTable.copyColFromRef("buy_sell_id", "v24_buy_sell", SHM_USR_TABLES_ENUM.BUY_SELL_TABLE);
dataSourceEndurTable.copyColFromRef("proj_index_id", "v24_proj_index", SHM_USR_TABLES_ENUM.INDEX_TABLE);
dataSourceEndurTable.copyColFromRef("unit_id", "v24_unit", SHM_USR_TABLES_ENUM.IDX_UNIT_TABLE);
dataSourceEndurTable.copyColFromRef("price_unit_id", "v24_price_unit", SHM_USR_TABLES_ENUM.IDX_UNIT_TABLE);
dataSourceEndurTable.copyColFromRef("roll_conv_id", "v24_roll_conv", SHM_USR_TABLES_ENUM.ROLL_CONV_TABLE);
dataSourceEndurTable.copyColFromRef("payment_conv_id", "v24_payment_conv", SHM_USR_TABLES_ENUM.PAYMENT_CONV_TABLE);
dataSourceEndurTable.copyColFromRef("currency_id", "v24_currency", SHM_USR_TABLES_ENUM.CURRENCY_TABLE);
dataSourceEndurTable.copyColFromRef("disc_index_id", "v24_disc_index", SHM_USR_TABLES_ENUM.INDEX_TABLE);
dataSourceEndurTable.copyColFromRef("product_id", "v24_product", SHM_USR_TABLES_ENUM.PWR_PRODUCT_TABLE);
dataSourceEndurTable.copyColFromRef("id_number", "v24_ref_source", SHM_USR_TABLES_ENUM.REF_SOURCE_TABLE);
dataSourceEndurTable.copyColFromRef("index_loc_id", "v24_index_location", SHM_USR_TABLES_ENUM.INDEX_LOCATION_TABLE);

// Removing the id columns after resolving the to reference values has we don't need them anymore //
dataSourceEndurTable.delCol("internal_bunit_id");
dataSourceEndurTable.delCol("internal_lentity_id");
dataSourceEndurTable.delCol("internal_portfolio_id");
dataSourceEndurTable.delCol("external_bunit_id");
dataSourceEndurTable.delCol("external_lentity_id");
dataSourceEndurTable.delCol("external_portfolio_id");
dataSourceEndurTable.delCol("ins_type_id");
dataSourceEndurTable.delCol("buy_sell_id");
//7 200-233
dataSourceEndurTable.delCol("proj_index_id");
dataSourceEndurTable.delCol("unit_id");
dataSourceEndurTable.delCol("price_unit_id");
dataSourceEndurTable.delCol("roll_conv_id");
dataSourceEndurTable.delCol("payment_conv_id");
dataSourceEndurTable.delCol("currency_id");
dataSourceEndurTable.delCol("disc_index_id");
dataSourceEndurTable.delCol("product_id");
dataSourceEndurTable.delCol("id_number");
dataSourceEndurTable.delCol("index_loc_id");

dataSourceEndurTable.setColFormatAsDate("v24_start_date", DATE_FORMAT.DATE_FORMAT_MDY_SLASH, DATE_LOCALE.DATE_LOCALE_EUROPE);
dataSourceEndurTable.setColFormatAsDate("v24_maturity_date", DATE_FORMAT.DATE_FORMAT_MDY_SLASH, DATE_LOCALE.DATE_LOCALE_EUROPE);

dataSourceEndurTable.clearGroupBy();
dataSourceEndurTable.addGroupBy("v24_internal_portfolio");
dataSourceEndurTable.addGroupBy("v24_deal_tracking_num");
dataSourceEndurTable.addGroupBy("v24_param_seq_num");
dataSourceEndurTable.groupBy();
}
return dataSourceEndurTable;
}

private Table getDealNumsTable() throws OException {
if (dealNumsTable == null) {
OConsole.message(" ---> Running getDealNumsTable()\n");
dealNumsTable = new Table (TRADE_ATTRIBUTES_FIN_RECON +" Deal Nums Table"); 
Table dataSourceEndurTableCopy = getDataSourceEndurTable().copyTable();
try {
dealNumsTable.select(dataSourceEndurTableCopy, "DISTINCT, v16_deal_tracking_num, v24_buy_sell, v24_deal_tracking_num,v24_param_seq_num, tran_num, ins_num", "v24_deal_tracking_num GT 0");
} catch (OException e) {
throw new OException("Table select failed in getDealNumsTable()\n" + e.getLocalizedMessage());
//8  234-267
} finally {
if (dataSourceEndurTableCopy != null) dataSourceEndurTableCopy.destroy();
}
dealNumsTable.clearGroupBy();
dealNumsTable.addGroupBy("v16_deal_tracking_num");
dealNumsTable.addGroupBy("v24_param_seq_num");
dealNumsTable.addGroupBy("v24_buy_sell");
dealNumsTable.groupBy();
}
return dealNumsTable;
}

private Table getMetricsTable() throws OException {
if (metricsTable == null) {
OConsole.message(" ---> Running getMetricsTable()\n");
metricsTable = new Table (TRADE_ATTRIBUTES_FIN_RECON +" Metrics Table");

Table dsOtpCopy = null;
Table tempMetrics = null;
try {
dsOtpCopy = getDataSourceOtpTable().copyTable();
tempMetrics = new Table ("Temp Metrics");
tempMetrics.select(dsOtpCopy, "DISTINCT, v16_internal_portfolio_name, v16_deal_tracking_num, v16_param_seq_num,v16_buy_sell", "v16_internal_portfolio GT 0");

Table userSvpDataReconParameters = getSvpDataReconParameters();
int cnUserStart = userSvpDataReconParameters.findString("endurv16_type", "Internal Portfolio", SEARCH_ENUM.FIRST_IN_GROUP);
int cnUserEnd = userSvpDataReconParameters.findString("endurv16_type", "Internal Portfolio", SEARCH_ENUM.LAST_IN_GROUP);
int numTempMetricsRows = tempMetrics.getNumRows();
for (int row=numTempMetricsRows; row>0; row--) {
String chainNumber = tempMetrics.getString("v16_internal_portfolio_name", row);
int validChainRow = userSvpDataReconParameters.findStringRange("endurv16_value", cnUserStart, cnUserEnd,
chainNumber, SEARCH_ENUM.FIRST_IN_GROUP);
//9 268-301
if (validChainRow < 1)
tempMetrics.delRow(row);
}

tempMetrics.clearGroupBy();
tempMetrics.addGroupBy("v16_internal_portfolio_name");
tempMetrics.addGroupBy("v16_deal_tracking_num");
tempMetrics.addGroupBy("v16_param_seq_num");
tempMetrics.addGroupBy("v16_buy_sell");
tempMetrics.groupBy();

int cnTempMetricsCol = tempMetrics.getColNum("v16_internal_portfolio_name");
int psnTempMetricsCol = tempMetrics.getColNum("v16_param_seq_num");
int orTempMetricsCol = tempMetrics.getColNum("v16_deal_tracking_num");
int bsTempMetricsCol = tempMetrics.getColNum("v16_buy_sell");

numTempMetricsRows = tempMetrics.getNumRows();
Set<String> chainNumbers = new HashSet<String>();
for (int row=1; row<=numTempMetricsRows; row++) {
String chainNumber = tempMetrics.getString(cnTempMetricsCol, row); 
if (chainNumber != null && !chainNumber.isEmpty())
chainNumbers.add(chainNumber);
}
metricsTable.addCol("metric", COL_TYPE_ENUM.COL_STRING);
metricsTable.addCol("v16_internal_portfolio", COL_TYPE_ENUM.COL_STRING);
metricsTable.addCol("v24_internal_portfolio", COL_TYPE_ENUM.COL_STRING);
metricsTable.addCol("deal_reference", COL_TYPE_ENUM.COL_STRING);
metricsTable.addCol("param_seq_num", COL_TYPE_ENUM.COL_STRING);
metricsTable.addCol("buy_sell_metric", COL_TYPE_ENUM.COL_STRING);
metricsTable.addCol(COL_EXPANDED, COL_TYPE_ENUM.COL_INT);
metricsTable.addCol(COL_GROUP, COL_TYPE_ENUM.COL_INT);

int mtMetricsCol = metricsTable.getColNum("metric");
int v16ipMetricsCol = metricsTable.getColNum("v16_internal_portfolio");
int v24ipMetricsCol = metricsTable.getColNum("v24_internal_portfolio");
//10 302-332
int drMetricsCol = metricsTable.getColNum("deal_reference");
int psnMetricsCol = metricsTable.getColNum("param_seq_num");
int bsmMetricsCol = metricsTable.getColNum("buy_sell_metric");

int ceMetricsCol = metricsTable.getColNum (COL_EXPANDED);
int cgMetricsCol = metricsTable.getColNum (COL_GROUP);

for (String chainNumber: chainNumbers) {
int cnUserEndurValueRow = userSvpDataReconParameters.findStringRange("endurv16_value", cnUserStart, 
cnUserEnd, chainNumber, SEARCH_ENUM.FIRST_IN_GROUP);
String internalPortfolio = userSvpDataReconParameters.getString("endurv24_value", cnUserEndurValueRow);
String metric = chainNumber + " / " + internalPortfolio;
int metricRow = metricsTable.addRow();
metricsTable.setString(mtMetricsCol, metricRow, metric);
metricsTable.setString(v16ipMetricsCol, metricRow, chainNumber);
metricsTable.setString(v24ipMetricsCol, metricRow, internalPortfolio);
metricsTable.setInt(ceMetricsCol, metricRow, NOT_EXPANDED);
metricsTable.setInt(cgMetricsCol, metricRow, RPT_LEVEL_2_GROUP);

int cnTempMetStart = tempMetrics.findString(cnTempMetricsCol, chainNumber, SEARCH_ENUM.FIRST_IN_GROUP);
int cnTempMetEnd = tempMetrics.findString(cnTempMetricsCol, chainNumber, SEARCH_ENUM.LAST_IN_GROUP);

for (int cnTempMetRow=cnTempMetStart; cnTempMetRow<=cnTempMetEnd; cnTempMetRow++) {
String orderReference = tempMetrics.getString(orTempMetricsCol, cnTempMetRow);
String paramSeNum = tempMetrics.getString(psnTempMetricsCol, cnTempMetRow);
String buySell = tempMetrics.getString(bsTempMetricsCol, cnTempMetRow);
metric = orderReference + " - " + buySell + " - Leg" + paramSeNum;
metricRow = metricsTable.addRow();

metricsTable.setString(mtMetricsCol, metricRow, metric);
metricsTable.setString(v16ipMetricsCol, metricRow, chainNumber);
metricsTable.setString(v24ipMetricsCol, metricRow, internalPortfolio);
//11 333-364
metricsTable.setString(drMetricsCol, metricRow, orderReference);
metricsTable.setString(psnMetricsCol, metricRow, paramSeNum);
metricsTable.setString(bsmMetricsCol, metricRow, buySell);
metricsTable.setInt(cgMetricsCol, metricRow, RPT_LEVEL_1_GROUP);
}
}
} catch (OException e) {
throw new OException("Error found in getMetricsTable()\n" + e.getLocalizedMessage());
} finally {
if (dsOtpCopy != null) dsOtpCopy.destroy();
if (tempMetrics != null) tempMetrics.destroy();
}
}
return metricsTable;
}

private String renameColName (String colName) throws OException {
String newColName1 = colName.trim().toLowerCase().replaceAll("[\\s|\\/]", "_").replaceAll("[\\.|\\(|\\)]", "");
String newColName2 = newColName1.replaceAll("[^a-zA-Z0-9_]", "");
return newColName2.trim();
}

private Table getDataSourceOtpTable() throws OException {
if (dataSourceOtpTable == null) {
OConsole.message(" ---> Running getDataSourceOtpTable()\n");
dataSourceOtpTable = getUtil().readCsvIntoTable(getReconDataFile());
dataSourceOtpTable.setTableName (TBL_TAE_DATASOURCE_OTP);

if (dataSourceOtpTable == null || dataSourceOtpTable.getNumRows() < 1) {
throw new OException (TBL_TAE_DATASOURCE_OTP + " is empty");
}
int numCols = dataSourceOtpTable.getNumCols();
//12 365-396
for (int col=1; col<=numCols; col++) {
String colName = renameColName (dataSourceOtpTable.getColName(col));
String colTitle = dataSourceOtpTable.getColTitle(col);
dataSourceOtpTable.setColName (col, colName);
dataSourceOtpTable.setColTitle (col, colTitle);
}
int numRows = dataSourceOtpTable.getNumRows();
int cnSvpParamStartRow = 0, cnSvpParamEndRow = 0;
cnSvpParamStartRow = getSvpDataReconParameters().findString("endurv16_type", "Internal Portfolio", SEARCH_ENUM.FIRST_IN_GROUP);
cnSvpParamEndRow = getSvpDataReconParameters().findString("endurv16_type", "Internal Portfolio", SEARCH_ENUM.LAST_IN_GROUP);
for (int row=numRows; row>0; row--) {
String internalPortfolioName = dataSourceOtpTable.getString("v16_internal_portfolio_name", row);
if (getSvpDataReconParameters().findStringRange("endurv16_value", cnSvpParamStartRow, cnSvpParamEndRow,
internalPortfolioName, SEARCH_ENUM.FIRST_IN_GROUP) < 1)
dataSourceOtpTable.delRow(row);
}
dataSourceOtpTable.colHide("v16_internal_portfolio");
dataSourceOtpTable.clearGroupBy();
dataSourceOtpTable.addGroupBy("v16_internal_portfolio_name");
dataSourceOtpTable.addGroupBy("v16_deal_tracking_num");
dataSourceOtpTable.addGroupBy("v16_param_seq_num");
dataSourceOtpTable.addGroupBy("v16_buy_sell");
dataSourceOtpTable.groupBy();
}
return dataSourceOtpTable;
}

private String getChainNumber (String chain) throws OException {
String retString = chain.replaceAll("[A-Za-z]", "").replaceAll("\\s", "").replaceAll("^0+", "");
return retString;
}
//13 398-429
private Table createReportTable() throws OException {
Table reportTable = new Table (TBL_TAE_RPT);
reportTable.setTableTitle (reportTable.getTableName());

for (ENUM_RPT_TAE_COL e : ENUM_RPT_TAE_COL.values()) {
reportTable.addCol(e.toColName(), e.toColType(), e.toColTitle());
}
reportTable.addCol(COL_EXPANDED, COL_TYPE_ENUM.COL_INT);
reportTable.addCol(COL_GROUP, COL_TYPE_ENUM.COL_INT);

createExtraDataTable (reportTable, getDataSourceOtpTable(), getDataSourceEndurTable());

populateMetricsOtpColumns (reportTable);
addTradeAttributesReconColumns(reportTable);
populateOtpTradeAttributesColumns(reportTable);
populateEndurTradeAttributesColumns (reportTable);

flagIssues(reportTable);
hideColumns(reportTable);

return reportTable;
}

private void flagIssues (Table reportTable) throws OException {
OConsole.message(" ---> Running flagMissingEndurInfo()\n");
int rptMetricCol = reportTable.getColNum(ENUM_RPT_TAE_COL.METRIC.toColName());
int rptDealNumCol = reportTable.getColNum(ENUM_RPT_TAE_COL.DEAL_NUM.toColName());
int rptGroupCol = reportTable.getColNum (COL_GROUP);

int rptOtpPositionCol = reportTable.getColNum("v16_position");
int rptEndurPositionCol = reportTable.getColNum("v24_position");
int rptOtpPriceCol = reportTable.getColNum("v16_price");
//14 430-461
int rptEndurPriceCol = reportTable.getColNum("v24_price");
int rptOtpNotnlCol = reportTable.getColNum("v16_notnl");
int rptEndurNotnlCol = reportTable.getColNum("v24_notnl");
int rptOtpFloatSpdCol = reportTable.getColNum("v16_float_spd");
int rptEndurFloatSpdCol = reportTable.getColNum("v24_float_spd");

int numRows = reportTable.getNumRows();
for (int row=1; row<=numRows; row++) {
try {
int group = reportTable.getInt(rptGroupCol, row);
if (group == RPT_LEVEL_1_GROUP) {
int dealNum = reportTable.getInt(rptDealNumCol, row);
if (dealNum == 0) {
String dealReference = reportTable.getCellString(rptMetricCol, row);
String cellFormat = reportTable.getCellFormat(rptMetricCol, row);
dealReference +=" (Endur deal missing)";
reportTable.setCellString(rptMetricCol, row, dealReference, cellFormat);
} else if (dealNum > 0){
double otpPosition = getDoubleFromCell(reportTable, rptOtpPositionCol, row);
double endurPosition = getDoubleFromCell(reportTable, rptEndurPositionCol, row);
if (!doublesAreSame (otpPosition, endurPosition)) {
String otpCellFormat = reportTable.getCellFormat(rptOtpPositionCol, 
row).replaceAll(CELL_COLOR_FMT_PALEGREEN, CELL_COLOR_FMT_RED);
String endurCellFormat = reportTable.getCellFormat(rptEndurPositionCol, 
row).replaceAll(CELL_COLOR_FMT_LIGHTBLUE, CELL_COLOR_FMT_RED); 
reportTable.setCellDouble (rptOtpPositionCol, row, otpPosition, otpCellFormat);
reportTable.setCellDouble (rptEndurPositionCol, row, endurPosition, endurCellFormat);
}
double otpPrice = getDoubleFromCell(reportTable, rptOtpPriceCol, row);
double endurPrice = getDoubleFromCell (reportTable, rptEndurPriceCol, row);
if (!doublesAreSame (otpPrice, endurPrice)) {
//15 462-493
String otpCellFormat = reportTable.getCellFormat(rptOtpPriceCol, 
row).replaceAll(CELL_COLOR_FMT_PALEGREEN, CELL_COLOR_FMT_RED);
String endurCellFormat = reportTable.getCellFormat(rptEndurPriceCol, 
row).replaceAll(CELL_COLOR_FMT_LIGHTBLUE, CELL_COLOR_FMT_RED);
reportTable.setCellDouble (rptOtpPriceCol, row, otpPrice, otpCellFormat); 
reportTable.setCellDouble (rptEndurPriceCol, row, endurPrice, endurCellFormat);
}
double otpNotnl = getDoubleFromCell(reportTable, rptOtpNotnlCol, row);
double endurNotnl = getDoubleFromCell(reportTable, rptEndurNotnlCol, row);
if (!doublesAreSame(otpNotnl, endurNotnl)) {
String otpCellFormat = reportTable.getCellFormat(rptOtpNotnlCol, row)
.replaceAll(CELL_COLOR_FMT_PALEGREEN, CELL_COLOR_FMT_RED);
String endurCellFormat = reportTable.getCellFormat(rptEndurNotnlCol, row)
.replaceAll(CELL_COLOR_FMT_LIGHTBLUE, CELL_COLOR_FMT_RED);
reportTable.setCellDouble (rptOtpNotnlCol, row, otpNotnl, otpCellFormat);
reportTable.setCellDouble (rptEndurNotnlCol, row, endurNotnl, endurCellFormat);
}
double otpFloatSpd = getDoubleFromCell(reportTable, rptOtpFloatSpdCol, row);
double endurFloatSpd = getDoubleFromCell (reportTable, rptEndurFloatSpdCol, row);
if (!doublesAreSame (otpFloatSpd, endurFloatSpd)) {
String otpCellFormat = reportTable.getCellFormat(rptOtpFloatSpdCol, row).replaceAll(CELL_COLOR_FMT_PALEGREEN, CELL_COLOR_FMT_RED); 
String endurCellFormat = reportTable.getCellFormat(rptEndurFloatSpdCol, row).replaceAll(CELL_COLOR_FMT_LIGHTBLUE, CELL_COLOR_FMT_RED); reportTable.setCellDouble (rptOtpFloatSpdCol, row, otpFloatSpd, otpCellFormat); 
reportTable.setCellDouble (rptEndurFloatSpdCol, row, endurFloatSpd, endurCellFormat);
}
}
}
}
catch(Exception ex) {
OConsole.message(" ---> Running flagIssues() reulted in error\n");
}
//16  494-525
}
}

private void populateEndurTradeAttributesColumns (Table reportTable) throws OException {
OConsole.message(" ---> Running populateEndurTradeAttributesColumns()\n");
Table dataSourceEndurTable = getDataSourceEndurTable();
Table svpDataReconTaFieldsTable = getSvpDataReconTaFieldsTable();

int rptNumCols = reportTable.getNumCols();
int rptNumRows = reportTable.getNumRows();
int rptGroupCol = reportTable.getColNum (COL_GROUP);

int rptIntPfolioCol = reportTable.getColNum("v24_internal_portfolio");
int rptDealNumCol = reportTable.getColNum("deal_num");
int rptParamSeqCol = reportTable.getColNum("param_seq_num");

int taFieldCatCol = svpDataReconTaFieldsTable.getColNum("ta_field_category");
int endurTaFieldNameCol = svpDataReconTaFieldsTable.getColNum("endurv24_ta_field_name");

int taFieldCatStartRow = 0, taFieldCatEndRow = 0;
taFieldCatStartRow = svpDataReconTaFieldsTable.findString(taFieldCatCol, ENUM_TA_FIELD_CAT.DEAL.toString(), SEARCH_ENUM.FIRST_IN_GROUP);
taFieldCatEndRow = svpDataReconTaFieldsTable.findString (taFieldCatCol, ENUM_TA_FIELD_CAT.DEAL.toString(), SEARCH_ENUM.LAST_IN_GROUP);
for (int taFieldRow=taFieldCatStartRow; taFieldRow<=taFieldCatEndRow; taFieldRow++) {
String taFieldName = svpDataReconTaFieldsTable.getString(endurTaFieldNameCol, taFieldRow);

for (int rptCol=RPT_START_COL_NUM; rptCol<=rptNumCols; rptCol++) {
COL_TYPE_ENUM rptColType = COL_TYPE_ENUM.fromInt(reportTable.getColType(rptCol));
if (rptColType != COL_TYPE_ENUM.COL_CELL) continue;

String rptColName = reportTable.getColName (rptCol);

//17 526-557
if (rptColName.equals(taFieldName)) {
for (int rptRow=1; rptRow<=rptNumRows; rptRow++) {
int group = reportTable.getInt(rptGroupCol, rptRow);
if (group == RPT_LEVEL_2_GROUP) continue;

String internalPortfolio = reportTable.getString(rptIntPfolioCol, rptRow);
int intPfolioStartRow = 0, intPfolioEndRow = 0;
if ((intPfolioStartRow = dataSourceEndurTable.findString("v24_internal_portfolio",  internalPortfolio, SEARCH_ENUM.FIRST_IN_GROUP)) < 1) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
intPfolioEndRow = dataSourceEndurTable.findString("v24_internal_portfolio", internalPortfolio, SEARCH_ENUM.LAST_IN_GROUP);

int dealNum = reportTable.getInt(rptDealNumCol, rptRow);
int dealNumStartRow = 0, dealNumEndRow = 0;
if ((dealNumStartRow = dataSourceEndurTable.findIntRange("v24_deal_tracking_num", intPfolioStartRow, intPfolioEndRow, dealNum, SEARCH_ENUM.FIRST_IN_GROUP)) < 1) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
dealNumEndRow = dataSourceEndurTable.findIntRange("v24_deal_tracking_num", intPfolioStartRow, intPfolioEndRow, dealNum, SEARCH_ENUM.LAST_IN_GROUP);

int paramSeqNum = reportTable.getInt(rptParamSeqCol, rptRow);
int paramSeqNumRow = 0;
if ((paramSeqNumRow = dataSourceEndurTable.findIntRange("v24_param_seq_num", dealNumStartRow,
dealNumEndRow, paramSeqNum, SEARCH_ENUM.FIRST_IN_GROUP)) < 1) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
//18 558-588
String cellFormat = CELL_COLOR_FMT_LIGHTBLUE + "," + CELL_DBLCLICK_DRILLDOWN;
String dataSourceColName = getDataSourceColNameFromTaField (taFieldName, dataSourceEndurTable);
setReportCellValue(reportTable, rptCol, rptRow, dataSourceEndurTable, dataSourceColName,
paramSeqNumRow, cellFormat);
addDrilldownDetail(TBL_TAE_DATASOURCE_ENDUR, TBL_TAE_EXTRA_DATA, paramSeqNumRow, paramSeqNumRow,
rptCol, rptRow);
}
}
}
}
}

private void hideColumns (Table reportTable) throws OException {
OConsole.message(" ---> Running hideColumns()\n");
for (ENUM_RPT_TAE_COL e : ENUM_RPT_TAE_COL.values()) {
if (e == ENUM_RPT_TAE_COL.METRIC) continue;
reportTable.colHide(e.toColName());
}
reportTable.colHide (COL_EXPANDED);
reportTable.colHide (COL_GROUP);
}

private void addTradeAttributesReconColumns (Table reportTable) throws OException {
OConsole.message(" ---> Running addTradeAttributesReconColumns()\n");
Table svpDataReconTaFieldsTable = getSvpDataReconTaFieldsTable();

int taFieldCatCol = svpDataReconTaFieldsTable.getColNum("ta_field_category");
int otpTaFieldNameCol = svpDataReconTaFieldsTable.getColNum("endurv16_ta_field_name");
int otpTaFieldTitleCol = svpDataReconTaFieldsTable.getColNum("endurv16_ta_field_title");
int endurTaFieldNameCol = svpDataReconTaFieldsTable.getColNum("endurv24_ta_field_name"); 
int endurTaFieldTitleCol = svpDataReconTaFieldsTable.getColNum("endurv24_ta_field_title");
//19  590-621
for (ENUM_TA_FIELD_CAT e: ENUM_TA_FIELD_CAT.values()) {
int startRow = svpDataReconTaFieldsTable.findString(taFieldCatCol, e.toString(), SEARCH_ENUM.FIRST_IN_GROUP);
int endRow = svpDataReconTaFieldsTable.findString(taFieldCatCol, e.toString(), SEARCH_ENUM.LAST_IN_GROUP);
for (int row=startRow; row<=endRow; row++) {
String otpColName = svpDataReconTaFieldsTable.getString(otpTaFieldNameCol, row);
String otpColTitle = svpDataReconTaFieldsTable.getString (otpTaFieldTitleCol, row);
String endurColName = svpDataReconTaFieldsTable.getString(endurTaFieldNameCol, row);
String endurColTitle = svpDataReconTaFieldsTable.getString(endurTaFieldTitleCol, row);
reportTable.addCol(otpColName, COL_TYPE_ENUM.COL_CELL, otpColTitle);
reportTable.addCol(endurColName, COL_TYPE_ENUM.COL_CELL, endurColTitle);
}
}
}

private void populateOtpTradeAttributesColumns (Table reportTable) throws OException {
OConsole.message(" ---> Running populateOtpTradeAttributesColumns()\n");
Table dataSourceOtpTable = getDataSourceOtpTable();
Table svpDataReconTaFieldsTable = getSvpDataReconTaFieldsTable();

int rptNumCols = reportTable.getNumCols();
int rptNumRows = reportTable.getNumRows();

int rptChainNumberCol = reportTable.getColNum("v16_internal_portfolio");
int rptDealRefCol = reportTable.getColNum("deal_reference");
int rptParamSeqCol = reportTable.getColNum("param_seq_num");
int rptBuySellMetricCol = reportTable.getColNum("buy_sell_metric");
int rptGroupCol = reportTable.getColNum(COL_GROUP);

int taFieldCatCol = svpDataReconTaFieldsTable.getColNum("ta_field_category");

int otpTaFieldNameCol = svpDataReconTaFieldsTable.getColNum("endurv16_ta_field_name");

for (ENUM_TA_FIELD_CAT e: ENUM_TA_FIELD_CAT.values()) {
//20 622-654
int taFieldCatStartRow = 0, taFieldCatEndRow = 0;
taFieldCatStartRow = svpDataReconTaFieldsTable.findString (taFieldCatCol, e.toString(), SEARCH_ENUM.FIRST_IN_GROUP); 
taFieldCatEndRow = svpDataReconTaFieldsTable.findString(taFieldCatCol, e.toString(), SEARCH_ENUM.LAST_IN_GROUP);

for (int taFieldRow=taFieldCatStartRow; taFieldRow<=taFieldCatEndRow; taFieldRow++) {
String taFieldName = svpDataReconTaFieldsTable.getString (otpTaFieldNameCol, taFieldRow);

for (int rptCol=RPT_START_COL_NUM; rptCol<=rptNumCols; rptCol++) {
COL_TYPE_ENUM rptColType = COL_TYPE_ENUM.fromInt(reportTable.getColType(rptCol));
if (rptColType != COL_TYPE_ENUM.COL_CELL) continue;

String rptColName = reportTable.getColName (rptCol);
if (rptColName.equals(taFieldName)) {

for (int rptRow=1; rptRow<=rptNumRows; rptRow++) {
int group = reportTable.getInt(rptGroupCol, rptRow);
if (group != RPT_LEVEL_1_GROUP) continue;

String chainNumber = reportTable.getString(rptChainNumberCol, rptRow);
String dealReference = reportTable.getString(rptDealRefCol, rptRow);
Integer paramSeqNum = reportTable.getInt(rptParamSeqCol, rptRow);
String buySellMetric = reportTable.getString(rptBuySellMetricCol, rptRow);

if (chainNumber == null || chainNumber.isEmpty()) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
int cnNumberStartRow = 0, cnNumberEndRow = 0;
if ((cnNumberStartRow = dataSourceOtpTable.findString("v16_internal_portfolio_name",
chainNumber, SEARCH_ENUM.FIRST_IN_GROUP)) < 1) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
//21- 655-686
cnNumberEndRow = dataSourceOtpTable.findString("v16_internal_portfolio_name", 
chainNumber, SEARCH_ENUM.LAST_IN_GROUP);

if (dealReference == null || dealReference.isEmpty()) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
int orNumberStartRow = 0, orNumberEndRow = 0;
if ((orNumberStartRow = dataSourceOtpTable.findStringRange("v16_deal_tracking_num", 
cnNumberStartRow, cnNumberEndRow, dealReference, SEARCH_ENUM.FIRST_IN_GROUP)) < 1) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
orNumberEndRow = dataSourceOtpTable.findStringRange("v16_deal_tracking_num", 
cnNumberStartRow, cnNumberEndRow, dealReference, SEARCH_ENUM.LAST_IN_GROUP);

int bsNumberStartRow = 0, bsNumberEndRow = 0;
if ((bsNumberStartRow = dataSourceOtpTable.findStringRange("v16_buy_sell",
orNumberStartRow, orNumberEndRow, buySellMetric, SEARCH_ENUM.FIRST_IN_GROUP)) < 1) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}

bsNumberEndRow = dataSourceOtpTable.findStringRange("v16_buy_sell", 
orNumberStartRow, orNumberEndRow, buySellMetric, SEARCH_ENUM.LAST_IN_GROUP);

if (buySellMetric == null || buySellMetric.isEmpty()) {
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
int paramSeqNumRow = 0;
if ((paramSeqNumRow = dataSourceOtpTable.findStringRange("v16_param_seq_num", 
bsNumberStartRow, bsNumberEndRow, paramSeqNum.toString(), SEARCH_ENUM.FIRST_IN_GROUP)) < 1) {
//22 687-718
reportTable.setCellString(rptCol, rptRow, DATA_NOT_FOUND, CELL_COLOR_FMT_WHEAT);
continue;
}
String cellFormat = CELL_COLOR_FMT_PALEGREEN + "," + CELL_DBLCLICK_DRILLDOWN;
String dataSourceColName = getDataSourceColNameFromTaField (taFieldName, dataSourceOtpTable);
setReportCellValue (reportTable, rptCol, rptRow, dataSourceOtpTable, dataSourceColName, 
paramSeqNumRow, cellFormat);
addDrilldownDetail(TBL_TAE_DATASOURCE_OTP, TBL_TAE_EXTRA_DATA, paramSeqNumRow, 
paramSeqNumRow, rptCol, rptRow);
}
}
}
}
}
}

private void populateMetricsOtpColumns(Table reportTable) throws OException {
OConsole.message(" ---> Running populateMetricsOtpColumns()\n");
Table metricsTable = getMetricsTable();
if (metricsTable.getNumRows() < 1) {
 throw new OException (metricsTable.getTableName() +" is empty\n");
}
Table dealNumsTable = getDealNumsTable();

int metMetricCol = metricsTable.getColNum("metric");
int metv16InternalPortfolioCol= metricsTable.getColNum("v16_internal_portfolio");
int metv24InternalPortfolioCol = metricsTable.getColNum("v24_internal_portfolio");
int metDealReferenceCol= metricsTable.getColNum("deal_reference");
int metParamSeqCol= metricsTable.getColNum("param_seq_num");
int metBuySellMetricCol= metricsTable.getColNum("buy_sell_metric");
int metExpandedCol = metricsTable.getColNum (COL_EXPANDED);
int metGroupCol = metricsTable.getColNum (COL_GROUP);
//23 720-751
int rptMetricCol = reportTable.getColNum(ENUM_RPT_TAE_COL.METRIC.toColName());
int rptv16InternalPortfolioCol = reportTable.getColNum(ENUM_RPT_TAE_COL.V16_INTERNAL_PORTFOLIO.toColName());
int rptv24InternalPortfolioCol = reportTable.getColNum(ENUM_RPT_TAE_COL.V24_INTERNAL_PORTFOLIO.toColName());
int rptDealNumCol = reportTable.getColNum (ENUM_RPT_TAE_COL.DEAL_NUM.toColName());
int rptDealReferenceCol= reportTable.getColNum(ENUM_RPT_TAE_COL.DEAL_REFERENCE.toColName());
int rptParamSeqCol = reportTable.getColNum (ENUM_RPT_TAE_COL.PARAM_SEQ_NUM.toColName());
int rptTranNumCol = reportTable.getColNum(ENUM_RPT_TAE_COL.TRAN_NUM.toColName());
int rptInsNumCol = reportTable.getColNum(ENUM_RPT_TAE_COL.INS_NUM.toColName());
int rptBuySellMetricCol = reportTable.getColNum (ENUM_RPT_TAE_COL.BUY_SELL_METRIC.toColName());

int rptExpandedCol = reportTable.getColNum (COL_EXPANDED);
int rptGroupCol = reportTable.getColNum (COL_GROUP);

int numMetricsRows = metricsTable.getNumRows();
for (int metRow=1; metRow<=numMetricsRows; metRow++) {
String metricCellFormat = ENUM_RPT_TAE_COL.METRIC.toCellFormat();
String metric= metricsTable.getString(metMetricCol, metRow);
String v16internalPortfolio = metricsTable.getString (metv16InternalPortfolioCol, metRow);
String v24internalPortfolio= metricsTable.getString (metv24InternalPortfolioCol, metRow);
int expandedValue = metricsTable.getInt(metExpandedCol, metRow); 

int group = metricsTable.getInt(metGroupCol, metRow);
if (group == RPT_LEVEL_1_GROUP)
metric = RPT_LEVEL_1_INDENT + metric;

int rptRow = reportTable.addRow();
if (group == RPT_LEVEL_2_GROUP)
metricCellFormat = CELL_CLICK_EXPAND_COLLAPSE + CELL_SYMBOL_PLUS + metricCellFormat;

reportTable.setCellString(rptMetricCol, rptRow, metric, metricCellFormat);
reportTable.setString(rptv16InternalPortfolioCol, rptRow, v16internalPortfolio);
reportTable.setString(rptv24InternalPortfolioCol, rptRow, v24internalPortfolio);
//24 753-784
reportTable.setInt(rptExpandedCol, rptRow, expandedValue);
reportTable.setInt(rptGroupCol, rptRow, group);
if (group == RPT_LEVEL_1_GROUP)
reportTable.setRowHideStatus (rptRow, HIDE);

String dealReference = metricsTable.getString(metDealReferenceCol, metRow);
if (dealReference != null && ! dealReference.isEmpty()) {
reportTable.setString(rptDealReferenceCol, rptRow, dealReference);

String paramSeq = metricsTable.getString (metParamSeqCol, metRow);
if (paramSeq != null && !paramSeq.isEmpty()) {
reportTable.setString(metParamSeqCol, rptRow, paramSeq);

String buySellMetric = metricsTable.getString(metBuySellMetricCol, metRow);
if (buySellMetric != null && ! buySellMetric.isEmpty()) {
reportTable.setString(rptBuySellMetricCol, rptRow, buySellMetric);
}
int dealReferenceStartRow = 0, dealReferenceEndRow = 0;
if ((dealReferenceStartRow = dealNumsTable.findInt("v16_deal_tracking_num", Integer.parseInt(dealReference),
SEARCH_ENUM.FIRST_IN_GROUP)) > 0) {
dealReferenceEndRow = dealNumsTable.findInt("v16_deal_tracking_num", Integer.parseInt(dealReference),
SEARCH_ENUM.LAST_IN_GROUP);

int buySellStartRow = 0, buySellEndRow = 0;
if ((buySellStartRow = dealNumsTable.findStringRange("v24_buy_sell", dealReferenceStartRow, dealReferenceEndRow, buySellMetric, SEARCH_ENUM.FIRST_IN_GROUP)) > 0) {
buySellEndRow = dealNumsTable.findStringRange("v24_buy_sell", dealReferenceStartRow,
dealReferenceEndRow, buySellMetric, SEARCH_ENUM.LAST_IN_GROUP);

int paramSeqNumRow = 0;
if ((paramSeqNumRow = dealNumsTable.findIntRange("v24_param_seq_num", buySellStartRow,
buySellEndRow, Integer.parseInt(paramSeq), SEARCH_ENUM.FIRST_IN_GROUP)) > 0) {
//25 785-801
int dealNum = dealNumsTable.getInt("v24_deal_tracking_num", paramSeqNumRow);
int tranNum = dealNumsTable.getInt("tran_num", paramSeqNumRow);
int insNum = dealNumsTable.getInt("ins_num", paramSeqNumRow);

reportTable.setInt(rptDealNumCol, rptRow, dealNum);
reportTable.setInt(rptParamSeqCol, rptRow, Integer.parseInt(paramSeq));
reportTable.setInt(rptTranNumCol, rptRow, tranNum);
reportTable.setInt(rptInsNumCol, rptRow, insNum);
}
}
}
}
} 
}
}
}