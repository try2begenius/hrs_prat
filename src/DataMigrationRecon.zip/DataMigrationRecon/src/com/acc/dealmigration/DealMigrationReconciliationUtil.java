//1 1-34
package com.acc.dealmigration;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.olf.openjvs.*;
import com.olf.openjvs.enums.*;

public class DealMigrationReconciliationUtil implements DealMigrationReconciliationConstants {
private Table menuSelectTable = null;
public void clearCache() throws OException {
menuSelectTable = clearCacheItem (menuSelectTable);
}
private Table clearCacheItem (Table cacheTable) throws OException {
if (cacheTable != null) {
OConsole.message("CLEARING CACHE ITEM "+ cacheTable.getTableName() + "\n");
cacheTable.destroy();
}
return null;
}

public String getRowNumberFormat(double value) throws OException {
String retStr = (value < 0) ? "," + CELL_NUM_FMT_NEGATIVE : "," + CELL_NUM_FMT_POSITIVE;
return retStr;
}

public Table getMenuSelectTable() throws OException {
if (menuSelectTable == null) {
//2 35-68
menuSelectTable = new Table ("menu_select");
menuSelectTable.addCol("source_name", COL_TYPE_ENUM.COL_INT);
menuSelectTable.addNumRows(1);
}
menuSelectTable.setInt(1, 1, 0);
return menuSelectTable;
}

public String getMenuDisplayString (Table menu, Table menuSelect) throws OException {
String s = "";
if (menuSelect == null || menuSelect.getNumRows() == 0)
return s;

int colMenuString = 0;
if (menu.getColType(1) == COL_TYPE_ENUM.COL_STRING.toInt())
colMenuString = 1;
else if (menu.getColType(2) == COL_TYPE_ENUM.COL_STRING.toInt())
colMenuString = 2;
else
throw new OException("Invalid menu (" + menu.getTableName() + ") passed to getMenuDisplayString()");

int menuSelectRows = menuSelect.getNumRows();
for (int row=1; row<=menuSelectRows; row++) {
int mrow = menuSelect.getInt(1, row);
if (mrow < 1)
continue;
if (row > 1)
s += ", ";
s += menu.getString(colMenuString, mrow);
}
//3  69-102
return s;
}

public void fillMenuSelect(String s, Table menu, int menuStringCol, Table menuSelect) throws OException{
if (s == null)
return;
int irow = menu.unsortedFindString (menuStringCol, s, SEARCH_CASE_ENUM.CASE_INSENSITIVE);
if (irow > 0) {
menuSelect.setInt(1, 1, irow);
} else if (!s.isEmpty()) {
menu.printTable();
throw new OException("fillMenuSelect failed - s= " + s + ", menuStringCol= "+ menuStringCol);
}
}

public Set<String> getOtpDealReferences (Table dataSourceOtpTable, String otpDealReferenceColName) throws OException {
Set<String>otpDealReferences = new HashSet<String>();
int numRow = dataSourceOtpTable.getNumRows();
for (int row=1; row<=numRow; row++) {
String dealReference = dataSourceOtpTable.getString(otpDealReferenceColName, row);
if (dealReference != null && ! dealReference.isEmpty()) otpDealReferences.add(dealReference);
}
return otpDealReferences;
}

public Table readCsvIntoTable (String importFilename) throws OException {
Table t = new Table();
t.inputFromCSVFile(importFilename);
if (t.getNumRows() < 2) {
t.destroy();
throw new OException("No data in recon file "+ importFilename);
}
//4 103-134
int numCols = t.getNumCols();
for (int col=1; col<=numCols; col++) {
String result = null;
String text = t.getString(col, 1);
if (ENUM_DS_EXCEPTION_COL.fromTitle(text) != null) {
result = ENUM_DS_EXCEPTION_COL.fromTitle(text).toColName();
} else {
result = camelToUnderscore(text);
}
t.setColName (col, result);
}
//t.viewTable();
t.delRow(1);
t.makeTableUnique();
return t;
}
public boolean csvFileColumnInDateFormat (Table t, String colName) throws OException {
if (t == null || t.getNumRows() < 1) return false;
int numRows = t.getNumRows();
int colNum = t.getColNum(colName);
boolean result = true;
for (int row=1; row<=numRows; row++) {
String str = t.getString(colNum, row);
result = result && getDateFormat(str) != null;
if (result == false) {
OConsole.print(" -----> csvFileColumnInDateFormat() result is false: str = " + str + " row = "+ row + "\n");
}
}
return result;
}
//5 135-167
//  private boolean isInRightDateFormat(String str) throws OException {
//      if (str == null || str.length() < 1)
//    throw new OException("isInRightDateFormat() parameter is either null or blank");
//  boolean matchFound = false;
//Pattern p = Pattern.compile("^\\d{2}\\-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)$");
////Matcher m = p.matcher (str);
//matchFound = m.matches();
//if (!matchFound) {
//p = Pattern.compile("^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\-\\d{2}$");
//m = p.matcher(str);//}
//return m.matches();
//}

public ENUM_MONTH_YEAR_FORMAT getDateFormat(String str) throws OException {
if (str == null || str.length() < 1)
return null;

for (ENUM_MONTH_YEAR_FORMAT e : ENUM_MONTH_YEAR_FORMAT.values()) {
Pattern p = Pattern.compile(e.toPattern());
Matcher m = p.matcher(str);
if (m.matches()) {
return e;
}
}
return null;
}

public int getNumberOfMonths(int fromDate, int toDate) throws OException {
int monthCount = 0;
//6 168-200
int fromMonth = OCalendar.getMonth(fromDate);
int fromYear = OCalendar.getYear(fromDate);
int toMonth = OCalendar.getMonth(toDate);
int toYear = OCalendar.getYear(toDate);

monthCount = 12 * (toYear - fromYear) + toMonth - fromMonth + 1;
return monthCount;
}

public String camelToUnderscore (String value) throws OException {
String result = value.replace(" ", "_");
result = result.replaceAll("([a-z])([A-Z])", "$1_$2");
result = result.replace(".", "_");
result = result.toLowerCase();
return result;
}

public void convertCsvTableColumnType(Table t, String colName, COL_TYPE_ENUM colType) throws OException {
if (t == null || t.getNumRows() < 1) return;

int colNum = t.getColNum(colName);
t.insertCol(colName + "_new", colNum, colType);

int numRows = t.getNumRows();
for (int row=1; row<=numRows; row++) {
String str = t.getString(colNum + 1, row);
if (str == null || str.isEmpty()) continue;

switch (colType) {
case COL_INT:
t.setInt(colNum, row, Integer.valueOf(str));
break;
case COL_DOUBLE:
//7 201-212
t.setDouble(colNum, row, Double.parseDouble(str));
break;
default:
break;
}
}

t.delCol(colName);
t.setColName (colNum, colName);
}
}