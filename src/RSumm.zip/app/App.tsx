import { ClipboardCheck, Target } from 'lucide-react';
import { useState } from 'react';

export default function App() {
  const [showFLUEscalation, setShowFLUEscalation] = useState(false);
  const [showTRMSOnly, setShowTRMSOnly] = useState(false);
  const [showTRMSFromFLUAML, setShowTRMSFromFLUAML] = useState(false);

  return (
    <div className="size-full flex flex-col p-8 bg-white">
      <div className="w-full max-w-5xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-full border border-gray-100">
        {/* Top section with buttons - fixed at top */}
        <div className="flex items-center justify-between gap-3 px-6 py-4 border-b border-gray-200 bg-white flex-shrink-0">
          <h1 className="text-gray-900 text-xl font-semibold">Case Review Form</h1>
          <div className="flex gap-3">
            <button className="px-5 py-2.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-all shadow-md hover:shadow-lg font-medium">
              Save
            </button>
            <button className="px-5 py-2.5 rounded-lg bg-green-500 text-white hover:bg-green-600 transition-all shadow-md hover:shadow-lg font-medium">
              Submit
            </button>
            <button className="px-5 py-2.5 rounded-lg bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 transition-all font-medium">
              Cancel
            </button>
          </div>
        </div>
        
        {/* Card content area - scrollable */}
        <div className="p-6 overflow-y-auto flex-1">
          <div className="mb-6 bg-white p-5 rounded-xl border border-blue-200">
            <label htmlFor="textInput" className="block mb-2 text-gray-800 font-semibold">
              Text Input
            </label>
            <input
              type="text"
              id="textInput"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm transition-all"
              placeholder="Enter text here..."
            />
          </div>
          
          <div className="mb-6 bg-white p-5 rounded-xl border border-purple-200">
            <label htmlFor="riskMitigants" className="block mb-2 text-gray-800 font-semibold">
              Risk Mitigants Summary
            </label>
            <textarea
              id="riskMitigants"
              rows={5}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-vertical shadow-sm transition-all"
              placeholder="Enter risk mitigants summary..."
            />
            <div className="mt-3 flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-lg p-3">
              <span className="text-amber-600 text-sm">⚠️</span>
              <p className="text-sm text-amber-800">
                Please do not enter any sensitive information in the Risk Mitigant Summary section
              </p>
            </div>
          </div>

          {/* Analysts Manager Input Section */}
          <div className="mb-6 border-2 border-blue-200 rounded-xl p-6 bg-white shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center gap-3 mb-4 pb-3 border-b-2 border-blue-300">
              <div className="p-2 bg-blue-600 rounded-lg">
                <ClipboardCheck className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-gray-900 font-semibold text-lg">Analysts Manager Input (Recommendation)</h3>
            </div>
            <div className="space-y-3">
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 cursor-pointer"
                />
                <span className="text-gray-700 leading-relaxed">Risk factors have been approved as part of most recent refresh and/or client activity monitoring and no additional factors have been identified or have already been properly escalated</span>
              </label>
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 cursor-pointer"
                />
                <span className="text-gray-700 leading-relaxed">I have reviewed additional risk factors and/or triggers which have been identified and believe no further escalation is required</span>
              </label>
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 cursor-pointer"
                  onChange={(e) => setShowFLUEscalation(e.target.checked)}
                />
                <span className="text-gray-700 leading-relaxed">I have reviewed additional risk factors and/or triggers which have been identified and have further escalated to the FLU AML team</span>
              </label>
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 cursor-pointer"
                  onChange={(e) => setShowTRMSOnly(e.target.checked)}
                />
                <span className="text-gray-700 leading-relaxed">I have reviewed additional risk factors and/or triggers which have been identified and believe further escalation is required and TRMS has been filed</span>
              </label>
              <div className="pt-4 mt-4 border-t-2 border-blue-200">
                <label className="flex items-start gap-3 p-4 rounded-lg bg-blue-100 border-2 border-blue-300 hover:bg-blue-200 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-5 h-5 mt-0.5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 cursor-pointer"
                  />
                  <span className="text-gray-900 font-semibold leading-relaxed">I confirm that all data has been reviewed and the responses to the above questions are accurate</span>
                </label>
              </div>
            </div>
          </div>

          {/* FLU Escalation Section - Conditional */}
          {showFLUEscalation && (
            <div className="mb-6 border-2 border-orange-300 rounded-xl p-6 bg-gradient-to-br from-orange-50 to-amber-100/50 shadow-lg animate-in fade-in duration-300">
              <h3 className="mb-4 text-gray-900 font-semibold text-lg pb-3 border-b-2 border-orange-300">🔥 FLU Escalation</h3>
              
              <div className="space-y-3 mb-5">
                <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-5 h-5 mt-0.5 text-orange-600 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                  />
                  <span className="text-gray-700 leading-relaxed">High Number of Risk attributes</span>
                </label>
                
                <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-5 h-5 mt-0.5 text-orange-600 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                  />
                  <span className="text-gray-700 leading-relaxed">Specific Combination of Risk Attributes</span>
                </label>
                
                <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-5 h-5 mt-0.5 text-orange-600 border-gray-300 rounded focus:ring-orange-500 cursor-pointer"
                  />
                  <span className="text-gray-700 leading-relaxed">Additional Risk Factors Present</span>
                </label>
              </div>

              <div className="pt-4 border-t-2 border-orange-300">
                <h4 className="mb-3 text-gray-900 font-semibold">
                  TRMS Tracking Number <span className="text-red-600 text-lg">*</span>
                </h4>
                <input
                  type="text"
                  id="trmsTracking"
                  required
                  className="w-full px-4 py-3 border-2 border-orange-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white shadow-sm transition-all"
                  placeholder="Enter TRMS tracking number..."
                />
              </div>
            </div>
          )}

          {/* TRMS Tracking Number Only - Conditional */}
          {showTRMSOnly && !showFLUEscalation && (
            <div className="mb-6 border-2 border-orange-300 rounded-xl p-6 bg-gradient-to-br from-orange-50 to-amber-100/50 shadow-lg animate-in fade-in duration-300">
              <h4 className="mb-3 text-gray-900 font-semibold text-lg">
                TRMS Tracking Number <span className="text-red-600 text-lg">*</span>
              </h4>
              <input
                type="text"
                id="trmsTrackingOnly"
                required
                className="w-full px-4 py-3 border-2 border-orange-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white shadow-sm transition-all"
                placeholder="Enter TRMS tracking number..."
              />
            </div>
          )}

          {/* FLU AML Input Section */}
          <div className="mb-6 border-2 border-green-200 rounded-xl p-6 bg-white shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center gap-3 mb-4 pb-3 border-b-2 border-green-300">
              <div className="p-2 bg-green-600 rounded-lg">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-gray-900 font-semibold text-lg">FLU AML Input (AML FLU Outcome)</h3>
            </div>
            <div className="space-y-3">
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-green-600 border-gray-300 rounded focus:ring-green-500 cursor-pointer"
                />
                <span className="text-gray-700 leading-relaxed">I have reviewed additional risk factors and/or triggers which have been identified and believe no further escalation is required</span>
              </label>
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-green-600 border-gray-300 rounded focus:ring-green-500 cursor-pointer"
                />
                <span className="text-gray-700 leading-relaxed">I have reviewed additional risk factors and/or triggers which have been identified and have confirmed with the client owner or client owner representative that the risk factors are acceptable</span>
              </label>
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-green-600 border-gray-300 rounded focus:ring-green-500 cursor-pointer"
                  onChange={(e) => setShowTRMSFromFLUAML(e.target.checked)}
                />
                <span className="text-gray-700 leading-relaxed">I have reviewed additional risk factors and/or triggers which have been identified and believe further escalation is required and TRMS has been filed</span>
              </label>
              <label className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors cursor-pointer">
                <input
                  type="checkbox"
                  className="w-5 h-5 mt-0.5 text-green-600 border-gray-300 rounded focus:ring-green-500 cursor-pointer"
                />
                <span className="text-gray-700 leading-relaxed">I have reviewed additional risk factors and/or triggers which have been identified and have confirmed with the client owner or client owner representative that the client will be exited.</span>
              </label>
              <div className="pt-4 mt-4 border-t-2 border-green-200">
                <label className="flex items-start gap-3 p-4 rounded-lg bg-green-100 border-2 border-green-300 hover:bg-green-200 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-5 h-5 mt-0.5 text-green-600 border-gray-300 rounded focus:ring-green-500 cursor-pointer"
                  />
                  <span className="text-gray-900 font-semibold leading-relaxed">I confirm that all data has been reviewed and the responses to the above questions are accurate</span>
                </label>
              </div>
            </div>
          </div>

          {/* TRMS Tracking Number from FLU AML - Conditional */}
          {showTRMSFromFLUAML && (
            <div className="mb-6 border-2 border-orange-300 rounded-xl p-6 bg-gradient-to-br from-orange-50 to-amber-100/50 shadow-lg animate-in fade-in duration-300">
              <h4 className="mb-3 text-gray-900 font-semibold text-lg">
                TRMS Tracking Number <span className="text-red-600 text-lg">*</span>
              </h4>
              <input
                type="text"
                id="trmsTrackingFromFLUAML"
                required
                className="w-full px-4 py-3 border-2 border-orange-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white shadow-sm transition-all"
                placeholder="Enter TRMS tracking number..."
              />
            </div>
          )}
        </div>

        {/* Bottom section with action buttons - fixed at bottom */}
        <div className="px-6 py-5 border-t-2 border-gray-200 bg-gradient-to-r from-gray-50 to-slate-50 flex-shrink-0">
          <div className="flex items-start gap-2 bg-white border-l-4 border-blue-400 rounded-lg p-3 mb-4">
            <span className="text-blue-600 text-lg">ℹ️</span>
            <p className="text-sm text-blue-800 font-medium">
              Note: FLU cannot reject if they have started to fill items
            </p>
          </div>
          <div className="flex gap-4">
            <button className="px-6 py-3 rounded-lg bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg hover:shadow-xl font-semibold transform hover:scale-105">
              Reject Return Case to Analyst
            </button>
            <button className="px-6 py-3 rounded-lg bg-gradient-to-r from-red-500 to-red-600 text-white hover:from-red-600 hover:to-red-700 transition-all shadow-lg hover:shadow-xl font-semibold transform hover:scale-105">
              Cancel Case
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}