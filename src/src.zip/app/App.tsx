import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Dashboard } from './components/Dashboard';
import { Toaster } from 'sonner';

export default function App() {
  return (
    <BrowserRouter>
      <div className="size-full bg-gray-50">
        <Toaster position="top-right" />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/case/:caseId" element={<CaseDetail />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

// Placeholder component for case detail page
function CaseDetail() {
  return (
    <div className="p-8">
      <h1 className="text-3xl mb-4">Case Detail</h1>
      <p>Case detail page - functionality coming soon...</p>
    </div>
  );
}
