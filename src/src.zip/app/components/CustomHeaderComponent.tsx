import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical } from 'lucide-react';
import NotificationService from '../../services/NotificationService';

export const CustomHeaderComponent = (props: any) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };

    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [menuOpen]);

  if (!props.column || !props.api) {
    return <div className="ag-header-cell-label">{props.displayName}</div>;
  }

  const columnId = props.column.getColId();
  const isPinned = props.column.isPinned();
  const displayName = props.displayName;

  const handleSortAsc = () => {
    props.api.applyColumnState({
      state: [{ colId: columnId, sort: 'asc' }],
      defaultState: { sort: null },
    });
    setMenuOpen(false);
  };

  const handleSortDesc = () => {
    props.api.applyColumnState({
      state: [{ colId: columnId, sort: 'desc' }],
      defaultState: { sort: null },
    });
    setMenuOpen(false);
  };

  const handlePinColumn = () => {
    props.api.applyColumnState({
      state: [{ colId: columnId, pinned: isPinned ? null : 'left' }],
      defaultState: { pinned: null },
    });
    setMenuOpen(false);
  };

  const handleAutosizeThis = () => {
    props.api.autoSizeColumns([columnId]);
    NotificationService.success(`Column "${displayName}" auto-sized`);
    setMenuOpen(false);
  };

  const handleAutosizeAll = () => {
    props.api.autoSizeAllColumns();
    NotificationService.success('All columns auto-sized');
    setMenuOpen(false);
  };

  const handleHideColumn = () => {
    props.api.applyColumnState({
      state: [{ colId: columnId, hide: true }],
      defaultState: { hide: false },
    });
    NotificationService.warning(`Column "${displayName}" hidden`);
    setMenuOpen(false);
  };

  return (
    <div className="ag-header-cell-comp-wrapper" style={{ display: 'flex', alignItems: 'center', width: '100%', justifyContent: 'space-between' }}>
      <div className="ag-header-cell-label" style={{ flex: 1 }}>
        <span className="ag-header-cell-text">{displayName}</span>
      </div>
      <div style={{ position: 'relative' }} ref={menuRef}>
        <button
          className="ag-header-icon"
          onClick={(e) => {
            e.stopPropagation();
            setMenuOpen(!menuOpen);
          }}
          style={{
            border: 'none',
            background: 'transparent',
            cursor: 'pointer',
            padding: '4px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <MoreVertical size={16} />
        </button>
        {menuOpen && (
          <div
            style={{
              position: 'absolute',
              top: '100%',
              right: 0,
              backgroundColor: 'white',
              border: '1px solid #ccc',
              borderRadius: '4px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
              zIndex: 10000,
              minWidth: '180px',
              marginTop: '4px',
            }}
          >
            <button
              onClick={handleSortAsc}
              style={{
                width: '100%',
                padding: '8px 12px',
                textAlign: 'left',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                fontSize: '14px',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f0f0f0')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              ↑ Sort Ascending
            </button>
            <button
              onClick={handleSortDesc}
              style={{
                width: '100%',
                padding: '8px 12px',
                textAlign: 'left',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                fontSize: '14px',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f0f0f0')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              ↓ Sort Descending
            </button>
            <div style={{ borderTop: '1px solid #e0e0e0', margin: '4px 0' }} />
            <button
              onClick={handlePinColumn}
              style={{
                width: '100%',
                padding: '8px 12px',
                textAlign: 'left',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                fontSize: '14px',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f0f0f0')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              📌 {isPinned ? 'Unpin Column' : 'Pin Column'}
            </button>
            <div style={{ borderTop: '1px solid #e0e0e0', margin: '4px 0' }} />
            <button
              onClick={handleAutosizeThis}
              style={{
                width: '100%',
                padding: '8px 12px',
                textAlign: 'left',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                fontSize: '14px',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f0f0f0')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              ⇔ Autosize This Column
            </button>
            <button
              onClick={handleAutosizeAll}
              style={{
                width: '100%',
                padding: '8px 12px',
                textAlign: 'left',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                fontSize: '14px',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f0f0f0')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              ⇔ Autosize All Columns
            </button>
            <div style={{ borderTop: '1px solid #e0e0e0', margin: '4px 0' }} />
            <button
              onClick={handleHideColumn}
              style={{
                width: '100%',
                padding: '8px 12px',
                textAlign: 'left',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                fontSize: '14px',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f0f0f0')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
            >
              👁️ Hide Column
            </button>
          </div>
        )}
      </div>
    </div>
  );
};