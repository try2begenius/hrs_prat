import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import type { PaginationChangedEvent } from "ag-grid-community";
import {
  ModuleRegistry,
  type ColDef,
  type GridReadyEvent,
  type ITextFilterParams,
  themeQuartz,
  type IDateFilterParams,
  ClientSideRowModelModule,
  CsvExportModule,
  TextFilterModule,
  DateFilterModule,
  NumberFilterModule,
  PaginationModule,
  RowSelectionModule,
  CellStyleModule,
  ValidationModule,
} from "ag-grid-community";

ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  CsvExportModule,
  TextFilterModule,
  DateFilterModule,
  NumberFilterModule,
  PaginationModule,
  RowSelectionModule,
  CellStyleModule,
  ValidationModule,
]);

import "./dashboardStyles.css";
import { exportExcel, postData } from "../../services/dashboardService";
import {
  CircleCheckBig,
  CircleX,
  UserRoundPlus,
  UserCheck,
} from "lucide-react";
import {
  convertDateFormat,
  convertDateFormatServer,
  convertDateToLocal,
} from "../../shared/utils/dateAndTimeConvertUtils";
import Cards from "../../shared/components/Cards";
import NotificationService from "../../services/NotificationService";
import { GridWrapper } from "./GridWrapper";
import { Card, CardContent } from "./ui/card";
import { CustomHeaderComponent } from "./CustomHeaderComponent";

export function Dashboard() {
  const myTheme = themeQuartz.withParams({
    headerTextColor: "black",
    headerBackgroundColor: "rgba(23, 184, 212, 0.2)",
    headerCellHoverBackgroundColor: "rgba(80, 40, 240, 0.65)",
    headerCellMovingBackgroundColor: "rgb(80, 40, 140)",
    accentColor: "red",
  });

  // const navigate = useNavigate();
  const pageNumber = useRef(0);
  const gridApi = useRef<any>(null);
  const searchCriteriaPayload = useRef<any[]>([]);
  const paginationPageSize = useRef<number>(1000);
  const sortPayload = useRef<boolean>(false);
  const sortedListData = useRef<any>([
    {
      fieldName: "caseModificationDate",
      direction: "DESC",
    },
  ]);
  const payload = useRef<any>({
    pageNumber: pageNumber.current,
    pageSize: paginationPageSize.current,
    sort: sortedListData.current,
    searchCriteria: searchCriteriaPayload.current,
  });

  const [scope, setScope] = useState<"MY_QUEUE" | "MY_BASKET">("MY_QUEUE");
  const [loading, setLoading] = useState(false);
  const [selectedCase, setSelectedCase] = useState<any>(null);
  const [queryData, setQueryData] = useState({
    scope: scope,
  });
  const [rowData, setRowData] = useState<any[]>([]);
  const [apiResponseData, setApiResponseData] = useState<any>(null);

  useEffect(() => {
    setQueryData((prev) => ({ ...prev, scope }));
  }, [scope]);

  // Load data on mount and when scope changes
  useEffect(() => {
    console.log("Loading data with queryData:", queryData);
    loadData();
  }, [queryData]);

  const loadData = async () => {
    console.log("loadData called, setting loading to true");
    setLoading(true);
    try {
      console.log("Calling postData with payload:", payload.current, "queryData:", queryData);
      const response = await postData(payload.current, queryData);
      console.log("Response received:", response);
      setApiResponseData(response);

      const hrsMainGridData = response.content.map((item: any) =>
        Object.assign({}, item, {
          caseOutcomeDecidedTimestamp: convertDateToLocal(
            item.caseOutcomeDecidedTimestamp
          ),
          caseStatusTimestamp: convertDateToLocal(
            item.caseStatusTimestamp
          ),
          pendingWithDueDate: convertDateFormat(
            item.pendingWithDueDate,
            "dd-MMM-yyyy"
          ),
          caseModificationDate: convertDateToLocal(
            item.caseModificationDate
          ),
          caseCreationDate: convertDateToLocal(item.caseCreationDate),
          caseDueDate: convertDateFormat(item.caseDueDate, "dd-MMM-yyyy"),
          trmsDate: convertDateFormat(item.trmsDate, "dd-MMM-yyyy"),
          refreshDate: convertDateFormat(item.refreshDate, "dd-MMM-yyyy"),
        })
      );

      console.log("Processed grid data:", hrsMainGridData);
      setRowData(hrsMainGridData);
    } catch (error) {
      console.error("Error fetching data:", error);
      setRowData([]);
    } finally {
      console.log("Setting loading to false");
      setLoading(false);
    }
  };

  const getRowStyle = (params: any) => {
    let classNameSelected;

    if (params.value === "COMPLETED") {
      classNameSelected = (
        <div className="badge badge-success">
          <CircleCheckBig size={16} />
          {params.value}
        </div>
      );
    } else if (
      params.value === "FLU request REJECTED" ||
      params.value === "Cancellation Rejected" ||
      params.value === "CANCELED" ||
      params.value === "Returned"
    ) {
      classNameSelected = (
        <div className="badge badge-error">
          <CircleX size={16} />
          {params.value}
        </div>
      );
    } else {
      classNameSelected = (
        <div className="badge badge-info">
          <UserRoundPlus size={16} />
          {params.value}
        </div>
      );
    }

    return classNameSelected;
  };

  const columnDefs: ColDef[] = [
    {
      // Remove deprecated properties - using rowSelection config instead
      pinned: "left",
      sortable: false,
      filter: false,
      width: 50,
      suppressColumnsToolPanel: true,
      suppressHeaderMenuButton: true,
      resizable: false,
      lockPosition: true,
      headerClass: "no-border",
      cellClass: "no-border",
      headerComponent: undefined,
    },
    {
      headerName: "Case ID",
      field: "caseId",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
      cellStyle: {
        color: "#154C9E",
        textDecoration: "underline",
        cursor: "pointer",
      },
      onCellClicked: (params: any) => {
        setSelectedCase(params.data);
      },
    },
    {
      headerName: "Client Legal Name",
      field: "clientLegalName",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Client GCI",
      field: "clientGci",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "PID",
      field: "pid",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Coper ID",
      field: "coperId",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "HRS Analyst",
      field: "hrsAnalyst",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "HRS Analyst Name",
      field: "hrsAnalystName",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "HRS Manager",
      field: "hrsManager",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "HRS Manager Name",
      field: "hrsManagerName",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Status",
      field: "caseStatus",
      width: 200,
      cellRenderer: getRowStyle,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Pending With",
      field: "pendingWith",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Creation Date",
      field: "caseCreationDate",
      filter: "agDateColumnFilter",
      width: 250,
      filterParams: { applyButton: true, debounceMs: 400 } as IDateFilterParams,
    },
    {
      headerName: "Version",
      field: "version",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "LOB",
      field: "lob",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Client Type",
      field: "clientType",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Entity Type",
      field: "entityType",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Cycle",
      field: "caseCycle",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Primary Flu",
      field: "primaryFlu",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Additional Flu",
      field: "additionalFlu",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Refresh System Of Record",
      field: "refreshSystemOfRecord",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Refresh Date",
      field: "refreshDate",
      filter: "agDateColumnFilter",
      width: 250,
      filterParams: { applyButton: true, debounceMs: 400 } as IDateFilterParams,
    },
    {
      headerName: "Refresh Risk Rating",
      field: "refreshRiskRating",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "TRMS Filled",
      field: "trmsFilled",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "TRMS Date",
      field: "trmsDate",
      filter: "agDateColumnFilter",
      width: 250,
      filterParams: { applyButton: true, debounceMs: 400 } as IDateFilterParams,
    },
    {
      headerName: "TRMS Number",
      field: "trmsNumber",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Created By",
      field: "caseCreatedBy",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Created By Name",
      field: "caseCreatedByName",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Modification Date",
      field: "caseModificationDate",
      filter: "agDateColumnFilter",
      width: 250,
      filterParams: { applyButton: true, debounceMs: 400 } as IDateFilterParams,
    },
    {
      headerName: "Case Modified By",
      field: "caseModifiedBy",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Modified By Name",
      field: "caseModifiedByName",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Modified By Role",
      field: "caseModifiedByRole",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Type",
      field: "caseType",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Autocomplete",
      field: "autocomplete",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Auto Complete Reason",
      field: "autocompleteReason",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Due Date",
      field: "caseDueDate",
      filter: "agDateColumnFilter",
      width: 250,
      filterParams: { applyButton: true, debounceMs: 400 } as IDateFilterParams,
    },
    {
      headerName: "Case Outcome Decided By Role",
      field: "caseOutcomeDecidedByRole",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Outcome Decided Timestamp",
      field: "caseOutcomeDecidedTimestamp",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Outcome Decided By Name",
      field: "caseOutcomeDecidedByName",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Outcome Decided By",
      field: "caseOutcomeDecidedBy",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Outcome",
      field: "caseOutcome",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case InProcess With Team",
      field: "caseInProcessWithTeam",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Case Status Timestamp",
      field: "caseStatusTimestamp",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Status Reason",
      field: "statusReason",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Booking Jurisdictions",
      field: "bookingJurisdictions",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Pending With Name",
      field: "pendingWithName",
      width: 150,
      filter: "agTextColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as ITextFilterParams,
    },
    {
      headerName: "Pending With Due Date",
      field: "pendingWithDueDate",
      width: 250,
      filter: "agDateColumnFilter",
      filterParams: { applyButton: true, debounceMs: 400 } as IDateFilterParams,
    },
  ];

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      sortable: true,
      filter: true,
      width: 200,
      resizable: true,
      floatingFilter: true,
      wrapHeaderText: true,
      headerComponent: CustomHeaderComponent,
      headerComponentParams: {
        enableMenu: true,
      },
    };
  }, []);

  const noRowsOverlayComponent = useMemo(() => {
    return () => <div className="grid-overlay">No Data Found</div>;
  }, []);

  const paginationPageSizeSelector = useMemo(() => {
    return [100, 500, 1000];
  }, []);

  const gridOptions = useMemo(() => {
    return {
      defaultColDef: defaultColDef,
      maxBlocksInCache: 1,
      suppressServerSideFullWidthLoadingRow: true,
      noRowsOverlayComponent: noRowsOverlayComponent,
      noRowsOverlayComponentParams: {
        noRowsMessageFunc: () => "No Data Found",
      },
      alwaysMultiSort: true,
    };
  }, [defaultColDef, noRowsOverlayComponent]);

  const onPaginationChanged = useCallback(
    (event: PaginationChangedEvent) => {
      if (event.newPageSize) {
        paginationPageSize.current = event.api.paginationGetPageSize();
        payload.current.pageSize = event.api.paginationGetPageSize();

        const selectedNode = event.api.getSelectedNodes();
        selectedNode.forEach((node: any) => node.setSelected(true));
      }
    },
    []
  );

  const onFilterChanged = (data: any): any => {
    let filterRow = data.api.getFilterModel();

    if (filterRow) {
      gridApi.current.api.deselectAll();
      searchCriteriaPayload.current = [];

      for (const key in filterRow) {
        if (filterRow.hasOwnProperty(key)) {
          if (
            filterRow[key].operator === undefined &&
            filterRow[key].dateFrom === undefined &&
            filterRow[key].filterType === "text"
          ) {
            searchCriteriaPayload.current.push({
              fieldName: key,
              condition: filterRow[key].type,
              primaryValue: filterRow[key].filter,
              secondaryValue: filterRow[key].filterTo,
              logicalOperator: "and",
            });
          }

          if (
            filterRow[key].operator !== undefined &&
            filterRow[key].dateFrom === undefined &&
            filterRow[key].filterType === "text"
          ) {
            searchCriteriaPayload.current.push({
              fieldName: key,
              condition: filterRow[key].conditions[0].type,
              primaryValue: filterRow[key].conditions[0].filter,
              secondaryValue: filterRow[key].conditions[0].filterTo,
              logicalOperator: filterRow[key].operator,
            });

            searchCriteriaPayload.current.push({
              fieldName: key,
              condition: filterRow[key].conditions[1].type,
              primaryValue: filterRow[key].conditions[1].filter,
              secondaryValue: filterRow[key].conditions[1].filterTo,
              logicalOperator: filterRow[key].operator,
            });
          }

          if (
            filterRow[key].operator !== undefined &&
            filterRow[key].dateFrom !== undefined &&
            filterRow[key].filterType !== "text"
          ) {
            searchCriteriaPayload.current.push(
              {
                fieldName: key,
                condition: filterRow[key].conditions[0].type,
                primaryValue: convertDateFormatServer(
                  filterRow[key].conditions[0].dateFrom,
                  "yyyy-MM-dd HH:mm:ss"
                ),
                secondaryValue: convertDateFormatServer(
                  filterRow[key].conditions[0].dateTo,
                  "yyyy-MM-dd HH:mm:ss"
                ),
                logicalOperator: filterRow[key].operator,
              },
              {
                fieldName: key,
                condition: filterRow[key].conditions[1].type,
                primaryValue: convertDateFormatServer(
                  filterRow[key].conditions[1].dateFrom,
                  "yyyy-MM-dd HH:mm:ss"
                ),
                secondaryValue: convertDateFormatServer(
                  filterRow[key].conditions[1].dateTo,
                  "yyyy-MM-dd HH:mm:ss"
                ),
                logicalOperator: filterRow[key].operator,
              }
            );
          }

          if (
            filterRow[key].operator === undefined &&
            filterRow[key].dateFrom !== undefined
          ) {
            searchCriteriaPayload.current.push({
              fieldName: key,
              condition: filterRow[key].type,
              primaryValue: convertDateFormatServer(
                filterRow[key].dateFrom,
                "yyyy-MM-dd HH:mm:ss"
              ),
              secondaryValue: convertDateFormatServer(
                filterRow[key].dateTo,
                "yyyy-MM-dd HH:mm:ss"
              ),
              logicalOperator: "and",
            });
          }

          if (filterRow[key].filterType === "set") {
            searchCriteriaPayload.current.push({
              fieldName: key,
              condition: "in",
              primaryValue: filterRow[key].values,
              logicalOperator: "and",
            });
          }
        }
      }

      payload.current.searchCriteria = searchCriteriaPayload.current;
    }
  };

  const onSortChanged = (data: any): any => {
    if (!data.api || typeof data.api.getColumnState !== 'function') {
      console.warn('getColumnState is not available');
      return;
    }

    let sortData = data.api.getColumnState();
    
    if (!sortData) {
      console.warn('getColumnState returned null or undefined');
      return;
    }

    sortedListData.current = [];
    let sortIndexBasedData = sortData.sort(
      (a: any, b: any) => a.sortIndex - b.sortIndex
    );

    sortIndexBasedData.forEach((item: any) => {
      if (item.sort) {
        sortPayload.current = true;
        sortedListData.current.push({
          fieldName: item.colId,
          direction: String(item.sort).toUpperCase(),
        });
      }
    });

    if (!sortPayload.current) {
      sortedListData.current.push({
        fieldName: "caseModificationDate",
        direction: "DESC",
      });
    }

    payload.current.sort = sortedListData.current;
  };

  const getDisplayedColumnData = (): any[] => {
    if (!gridApi.current || !gridApi.current.api) {
      return [];
    }
    
    const displayedColumns = gridApi.current.api.getAllDisplayedColumns();
    const querySelectedData: any = [];

    if (!displayedColumns) {
      return [];
    }

    displayedColumns.forEach((col: any) => {
      if (col.colId !== "") {
        querySelectedData.push(col.colId);
      }
    });

    return querySelectedData;
  };

  const excelFileGenerate = () => {
    if (!gridApi.current || !gridApi.current.api) {
      NotificationService.error("Grid not ready for export");
      return;
    }

    const fileName = `${scope}-Export.csv`;
    
    NotificationService.warning("File Download in process ...");

    try {
      gridApi.current.api.exportDataAsCsv({
        fileName: fileName,
        columnKeys: getDisplayedColumnData(),
        allColumns: false,
      });
      
      NotificationService.success("File Downloaded");
    } catch (error) {
      console.error("Error downloading file:", error);
      NotificationService.error("File download failed");
    }
  };

  const rowSelection = useMemo(() => {
    return {
      mode: "multiRow" as const,
      checkboxes: true,
      headerCheckbox: true,
      enableClickSelection: true,
    };
  }, []);

  const onGridReady = useCallback(
    (params: GridReadyEvent) => {
      gridApi.current = params;
    },
    []
  );

  const resetSortAndFilter = () => {
    if (gridApi.current) {
      gridApi.current.api.setFilterModel(null);
      gridApi.current.api.setSortModel(null);
    }
  };

  const handleReassign = () => {
    const selectedRows = gridApi.current?.api?.getSelectedRows();
    if (!selectedRows || selectedRows.length === 0) {
      NotificationService.error("Please select at least one case to reassign");
      return;
    }
    
    NotificationService.success(`Re-assigning ${selectedRows.length} case(s)...`);
    console.log("Cases to reassign:", selectedRows);
    // TODO: Implement reassignment logic
  };

  const handleFilterCards = (filter: string) => {
    console.log("Filter clicked:", filter);
  };

  const getMainMenuItems = useCallback((params: any) => {
    const columnId = params.column.getColId();
    const isPinned = params.column.isPinned();
    
    return [
      {
        name: 'Sort Ascending',
        action: () => {
          params.api.applyColumnState({
            state: [{ colId: columnId, sort: 'asc' }],
            defaultState: { sort: null },
          });
        },
        icon: '<span class="ag-icon ag-icon-asc" unselectable="on" role="presentation"></span>',
      },
      {
        name: 'Sort Descending',
        action: () => {
          params.api.applyColumnState({
            state: [{ colId: columnId, sort: 'desc' }],
            defaultState: { sort: null },
          });
        },
        icon: '<span class="ag-icon ag-icon-desc" unselectable="on" role="presentation"></span>',
      },
      'separator',
      {
        name: isPinned ? 'Unpin Column' : 'Pin Column',
        action: () => {
          params.api.applyColumnState({
            state: [{ colId: columnId, pinned: isPinned ? null : 'left' }],
            defaultState: { pinned: null },
          });
        },
        icon: '<span class="ag-icon ag-icon-pin" unselectable="on" role="presentation"></span>',
      },
      'separator',
      {
        name: 'Autosize This Column',
        action: () => {
          params.api.autoSizeColumns([columnId]);
          NotificationService.success(`Column "${params.column.getColDef().headerName}" auto-sized`);
        },
        icon: '<span class="ag-icon ag-icon-small-left" unselectable="on" role="presentation"></span>',
      },
      {
        name: 'Autosize All Columns',
        action: () => {
          params.api.autoSizeAllColumns();
          NotificationService.success('All columns auto-sized');
        },
        icon: '<span class="ag-icon ag-icon-small-right" unselectable="on" role="presentation"></span>',
      },
      'separator',
      {
        name: 'Hide Column',
        action: () => {
          params.api.applyColumnState({
            state: [{ colId: columnId, hide: true }],
            defaultState: { hide: false },
          });
          NotificationService.warning(`Column "${params.column.getColDef().headerName}" hidden`);
        },
        icon: '<span class="ag-icon ag-icon-eye-slash" unselectable="on" role="presentation"></span>',
      },
    ];
  }, []);

  return (
    <>
      {apiResponseData && (
        <Cards value={apiResponseData} onRefresh={handleFilterCards} />
      )}

      <div className="flex flex-row-reverse gap-2 m-3">
        <label className="flex items-center gap-2">
          <span>Scope:</span>
          <select
            className="px-3 py-2 border rounded"
            value={scope}
            onChange={(e) => {
              const next =
                e.target.value === "MY_QUEUE" ? "MY_QUEUE" : "MY_BASKET";
              setScope(next as "MY_QUEUE" | "MY_BASKET");
            }}
          >
            <option value="MY_QUEUE">MY_QUEUE</option>
            <option value="MY_BASKET">MY_BASKET</option>
          </select>
        </label>
      </div>

      <div className="m-3">
        <Card className="gap-0">
          <CardContent className="p-0">
            <div className="px-4 py-3 border-b bg-white flex justify-between items-center">
              <h2 className="text-lg font-semibold">
                {scope} ({rowData.length} Cases)
              </h2>
              <div className="flex gap-2">
                <button
                  className="bg-white border border-gray-300 text-gray-900 hover:bg-gray-100 h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5 whitespace-nowrap flex items-center transition-colors"
                  onClick={handleReassign}
                >
                  <UserCheck size={16} />
                  Re-assign
                </button>
                <button
                  className="bg-white border border-gray-300 text-gray-900 hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50 h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5 whitespace-nowrap flex items-center transition-colors"
                  onClick={excelFileGenerate}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 15V3" />
                    <path d="M7 10L12 15L17 10" />
                    <path d="M21 21H3" />
                  </svg>
                  Export
                </button>
                <button
                  className="bg-white border border-gray-300 text-gray-900 hover:bg-gray-100 h-8 rounded-md px-3 whitespace-nowrap transition-colors"
                  onClick={resetSortAndFilter}
                >
                  Clear Filter
                </button>
              </div>
            </div>
            <div style={{ height: "calc(100vh - 400px)", minHeight: "500px", width: "100%" }} className="grid-box">
              <GridWrapper
                theme={myTheme}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                rowData={rowData}
                rowModelType="clientSide"
                pagination={true}
                paginationPageSize={100}
                paginationPageSizeSelector={paginationPageSizeSelector}
                noRowsOverlayComponent={noRowsOverlayComponent}
                alwaysMultiSort={true}
                onFilterChanged={onFilterChanged}
                onSortChanged={onSortChanged}
                onGridReady={onGridReady}
                rowSelection={rowSelection}
                getRowId={(params) => params.data.caseId}
                loading={loading}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {selectedCase && (
        <div className="m-3">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">Case Details</h2>
                <button
                  onClick={() => setSelectedCase(null)}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  Close
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <span className="font-semibold">Case ID:</span>
                  <p className="text-blue-600">{selectedCase.caseId}</p>
                </div>
                <div>
                  <span className="font-semibold">Client Legal Name:</span>
                  <p>{selectedCase.clientLegalName || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Client GCI:</span>
                  <p>{selectedCase.clientGci || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">PID:</span>
                  <p>{selectedCase.pid || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Case Status:</span>
                  <div className="mt-1">{getRowStyle({ value: selectedCase.caseStatus })}</div>
                </div>
                <div>
                  <span className="font-semibold">Pending With:</span>
                  <p>{selectedCase.pendingWith || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">HRS Analyst:</span>
                  <p>{selectedCase.hrsAnalystName || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">HRS Manager:</span>
                  <p>{selectedCase.hrsManagerName || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Case Creation Date:</span>
                  <p>{selectedCase.caseCreationDate || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Case Modification Date:</span>
                  <p>{selectedCase.caseModificationDate || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Case Due Date:</span>
                  <p>{selectedCase.caseDueDate || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">LOB:</span>
                  <p>{selectedCase.lob || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Client Type:</span>
                  <p>{selectedCase.clientType || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Entity Type:</span>
                  <p>{selectedCase.entityType || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Case Cycle:</span>
                  <p>{selectedCase.caseCycle || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Primary Flu:</span>
                  <p>{selectedCase.primaryFlu || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Case Type:</span>
                  <p>{selectedCase.caseType || "N/A"}</p>
                </div>
                <div>
                  <span className="font-semibold">Case Outcome:</span>
                  <p>{selectedCase.caseOutcome || "N/A"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}