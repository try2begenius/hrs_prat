import { AgGridReact } from "ag-grid-react";
import type { AgGridReactProps } from "ag-grid-react";
import { useMemo } from "react";

// This wrapper component isolates AG Grid from any parent data attributes
export function GridWrapper(props: any) {
  // List of valid AG Grid props we want to pass through
  const validKeys = useMemo(() => [
    'theme',
    'columnDefs',
    'defaultColDef',
    'rowData',
    'rowModelType',
    'pagination',
    'paginationPageSize',
    'paginationPageSizeSelector',
    'cacheBlockSize',
    'maxBlocksInCache',
    'suppressServerSideFullWidthLoadingRow',
    'noRowsOverlayComponent',
    'alwaysMultiSort',
    'onPaginationChanged',
    'onSortChanged',
    'onFilterChanged',
    'getContextMenuItems',
    'getMainMenuItems',
    'onGridReady',
    'rowSelection',
    'getRowId',
    'gridOptions',
    'serverSideDatasource',
    'overlayNoRowsTemplate',
    'overlayLoadingTemplate',
    'loading',
  ], []);
  
  // Only copy valid AG Grid props - filter out all data-* attributes
  const cleanProps = useMemo(() => {
    const filtered: any = {};
    Object.keys(props).forEach(key => {
      // Only include if it's in our whitelist and not a data attribute
      if (validKeys.includes(key) && !key.startsWith('data-')) {
        filtered[key] = props[key];
      }
    });
    return filtered;
  }, [props, validKeys]);

  return (
    <div style={{ height: "100%", width: "100%", "--ag-header-background-color": "white" } as React.CSSProperties}>
      <AgGridReact {...cleanProps} />
    </div>
  );
}