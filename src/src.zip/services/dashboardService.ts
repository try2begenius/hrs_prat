// Mock service for dashboard data

// Mock data arrays for realistic variety
const clientNames = [
  'Acme Corporation',
  'Global Industries Inc',
  'Tech Solutions Ltd',
  'Financial Services Group',
  'Manufacturing Partners',
  'Retail Enterprises',
  'Healthcare Systems',
  'Energy Corporation',
  'Consulting Services LLC',
  'Media & Entertainment Co',
  'Transportation Holdings',
  'Real Estate Ventures',
  'Food & Beverage Corp',
  'Telecommunications Inc',
  'Pharmaceutical Labs',
];

const analystNames = [
  'John Smith',
  'Sarah Johnson',
  'Michael Brown',
  'Emily Davis',
  'David Wilson',
  'Jessica Martinez',
  'James Anderson',
  'Jennifer Taylor',
  'Robert Thomas',
  'Lisa Garcia',
];

const managerNames = [
  'William Moore',
  'Mary Jackson',
  'Richard White',
  'Patricia Harris',
  'Thomas Martin',
];

const statuses = [
  'COMPLETED',
  'IN_PROGRESS',
  'PENDING',
  'FLU request REJECTED',
  'CANCELED',
  'Returned',
];

const lobs = [
  'Banking & Finance',
  'Insurance',
  'Asset Management',
  'Wealth Management',
  'Corporate Services',
];

const clientTypes = [
  'Corporate',
  'Individual',
  'Partnership',
  'Trust',
  'Government Entity',
];

const entityTypes = [
  'Legal Entity',
  'Branch',
  'Subsidiary',
  'Joint Venture',
];

const riskRatings = ['High', 'Medium', 'Low', 'Very High', 'Very Low'];

const jurisdictions = [
  'US, UK',
  'US, EU',
  'APAC',
  'US, Canada',
  'EU',
  'Global',
  'Americas',
  'UK, Switzerland',
];

const statusReasons = [
  'Awaiting documentation',
  'Under review',
  'Compliance check in progress',
  'Pending client response',
  'Risk assessment required',
  'Legal review needed',
  'Approved by manager',
  'Rejected - incomplete information',
  'Escalated to senior management',
  'Routine processing',
];

const outcomes = [
  'Approved',
  'Rejected',
  'Approved with conditions',
  'Pending review',
  'Escalated',
];

export const postData = async (payload: any, queryData: any) => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Generate mock data
  const mockData = [];
  const totalElements = 250; // Increased to 250 cases
  const pageSize = payload.pageSize || 1000;
  const pageNumber = payload.pageNumber || 0;
  
  const startIndex = pageNumber * pageSize;
  const endIndex = Math.min(startIndex + pageSize, totalElements);
  
  for (let i = startIndex; i < endIndex; i++) {
    const statusIndex = i % statuses.length;
    const analystIndex = i % analystNames.length;
    const managerIndex = i % managerNames.length;
    const clientIndex = i % clientNames.length;
    
    // Create dates with more variety
    const creationDate = new Date(2024, Math.floor(i / 30) % 12, (i % 28) + 1);
    const modificationDate = new Date(creationDate);
    modificationDate.setDate(modificationDate.getDate() + Math.floor(Math.random() * 30));
    
    const dueDate = new Date(creationDate);
    dueDate.setDate(dueDate.getDate() + 45);
    
    mockData.push({
      caseId: `CASE-${(i + 1).toString().padStart(5, '0')}`,
      clientLegalName: clientNames[clientIndex],
      clientGci: `GCI-${(Math.floor(Math.random() * 9000) + 1000)}`,
      pid: `PID-${(i + 1).toString().padStart(6, '0')}`,
      coperId: `COPER-${(i + 1).toString().padStart(4, '0')}`,
      hrsAnalyst: analystNames[analystIndex].toLowerCase().replace(' ', '.'),
      hrsAnalystName: analystNames[analystIndex],
      hrsManager: managerNames[managerIndex].toLowerCase().replace(' ', '.'),
      hrsManagerName: managerNames[managerIndex],
      caseStatus: statuses[statusIndex],
      pendingWith: i % 2 === 0 ? analystNames[analystIndex] : managerNames[managerIndex],
      caseCreationDate: creationDate.toISOString(),
      version: `v${(i % 5) + 1}.${Math.floor(i / 10) % 10}`,
      lob: lobs[i % lobs.length],
      clientType: clientTypes[i % clientTypes.length],
      entityType: entityTypes[i % entityTypes.length],
      caseCycle: `Q${(Math.floor(i / 60) % 4) + 1} 2024`,
      primaryFlu: `FLU-${(i % 20) + 100}`,
      additionalFlu: i % 3 === 0 ? `FLU-${(i % 15) + 200}` : '',
      refreshSystemOfRecord: ['Salesforce', 'Oracle', 'SAP', 'Custom System'][i % 4],
      refreshDate: new Date(2024, (i % 12), 1).toISOString(),
      refreshRiskRating: riskRatings[i % riskRatings.length],
      trmsFilled: i % 3 === 0 ? 'Yes' : 'No',
      trmsDate: i % 3 === 0 ? creationDate.toISOString() : null,
      trmsNumber: i % 3 === 0 ? `TRMS-${(i + 1).toString().padStart(6, '0')}` : '',
      caseCreatedBy: analystNames[analystIndex].toLowerCase().replace(' ', '.'),
      caseCreatedByName: analystNames[analystIndex],
      caseModificationDate: modificationDate.toISOString(),
      caseModifiedBy: i % 2 === 0 ? analystNames[analystIndex].toLowerCase().replace(' ', '.') : managerNames[managerIndex].toLowerCase().replace(' ', '.'),
      caseModifiedByName: i % 2 === 0 ? analystNames[analystIndex] : managerNames[managerIndex],
      caseModifiedByRole: i % 2 === 0 ? 'Analyst' : 'Manager',
      caseType: ['Standard Review', 'Enhanced Due Diligence', 'Periodic Review', 'Event Driven'][i % 4],
      autocomplete: i % 5 === 0 ? 'Yes' : 'No',
      autocompleteReason: i % 5 === 0 ? 'System auto-completed based on criteria' : '',
      caseDueDate: dueDate.toISOString(),
      caseOutcomeDecidedByRole: statuses[statusIndex] === 'COMPLETED' ? 'Manager' : 'Analyst',
      caseOutcomeDecidedTimestamp: statuses[statusIndex] === 'COMPLETED' ? modificationDate.toISOString() : null,
      caseOutcomeDecidedByName: statuses[statusIndex] === 'COMPLETED' ? managerNames[managerIndex] : '',
      caseOutcomeDecidedBy: statuses[statusIndex] === 'COMPLETED' ? managerNames[managerIndex].toLowerCase().replace(' ', '.') : '',
      caseOutcome: statuses[statusIndex] === 'COMPLETED' ? outcomes[i % outcomes.length] : '',
      caseInProcessWithTeam: `Team ${String.fromCharCode(65 + (i % 5))}`,
      caseStatusTimestamp: modificationDate.toISOString(),
      statusReason: statusReasons[i % statusReasons.length],
      bookingJurisdictions: jurisdictions[i % jurisdictions.length],
      pendingWithName: i % 2 === 0 ? analystNames[analystIndex] : managerNames[managerIndex],
      pendingWithDueDate: statuses[statusIndex] === 'PENDING' || statuses[statusIndex] === 'IN_PROGRESS' ? dueDate.toISOString() : null,
    });
  }
  
  // Apply filters if provided
  let filteredData = mockData;
  if (payload.searchCriteria && payload.searchCriteria.length > 0) {
    filteredData = mockData.filter(item => {
      return payload.searchCriteria.every((criteria: any) => {
        const fieldValue = String(item[criteria.fieldName as keyof typeof item] || '').toLowerCase();
        const searchValue = String(criteria.primaryValue || '').toLowerCase();
        
        switch (criteria.condition) {
          case 'contains':
            return fieldValue.includes(searchValue);
          case 'equals':
            return fieldValue === searchValue;
          case 'startsWith':
            return fieldValue.startsWith(searchValue);
          case 'endsWith':
            return fieldValue.endsWith(searchValue);
          default:
            return true;
        }
      });
    });
  }
  
  // Apply sorting if provided
  if (payload.sort && payload.sort.length > 0) {
    filteredData.sort((a, b) => {
      for (const sortItem of payload.sort) {
        const aValue = a[sortItem.fieldName as keyof typeof a];
        const bValue = b[sortItem.fieldName as keyof typeof b];
        
        if (aValue < bValue) return sortItem.direction === 'ASC' ? -1 : 1;
        if (aValue > bValue) return sortItem.direction === 'ASC' ? 1 : -1;
      }
      return 0;
    });
  }
  
  return {
    content: filteredData,
    totalElements: filteredData.length,
    pageNumber,
    pageSize,
  };
};

export const exportExcel = async (payload: any, queryData: any) => {
  // Mock Excel export
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Create a more comprehensive CSV content
  const headers = [
    'Case ID',
    'Client Legal Name',
    'Status',
    'HRS Analyst',
    'HRS Manager',
    'Case Creation Date',
    'LOB',
    'Client Type',
    'Risk Rating',
  ];
  
  const rows = [
    'CASE-00001,Acme Corporation,COMPLETED,John Smith,William Moore,2024-01-01,Banking & Finance,Corporate,High',
    'CASE-00002,Global Industries Inc,IN_PROGRESS,Sarah Johnson,Mary Jackson,2024-01-02,Insurance,Individual,Medium',
    'CASE-00003,Tech Solutions Ltd,PENDING,Michael Brown,Richard White,2024-01-03,Asset Management,Partnership,Low',
  ];
  
  const csvContent = headers.join(',') + '\n' + rows.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv' });
  
  return blob;
};
