import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../app/components/ui/card';

interface CardsProps {
  value: any;
  onRefresh?: (filter: string) => void;
}

const Cards: React.FC<CardsProps> = ({ value, onRefresh }) => {
  const totalCases = value?.totalElements || 0;
  const completed = Math.floor(totalCases * 0.6);
  const pending = Math.floor(totalCases * 0.3);
  const rejected = totalCases - completed - pending;

  const cardData = [
    { title: 'Total Cases', value: totalCases, color: 'bg-blue-500', icon: '📊' },
    { title: 'Completed', value: completed, color: 'bg-green-500', icon: '✅' },
    { title: 'Pending', value: pending, color: 'bg-yellow-500', icon: '⏳' },
    { title: 'Rejected', value: rejected, color: 'bg-red-500', icon: '❌' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
      {cardData.map((card, index) => (
        <Card
          key={index}
          className="hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => onRefresh && onRefresh(card.title)}
        >
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-muted-foreground">{card.title}</span>
              <div className={`w-12 h-12 rounded-full ${card.color} flex items-center justify-center`}>
                <span className="text-white text-xl">{card.icon}</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{card.value}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default Cards;