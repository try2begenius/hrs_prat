import { format, parseISO } from 'date-fns';

export const convertDateToLocal = (dateString: string): string => {
  if (!dateString) return '';
  try {
    const date = parseISO(dateString);
    return format(date, 'dd-MMM-yyyy HH:mm:ss');
  } catch (error) {
    return dateString;
  }
};

export const convertDateFormat = (dateString: string, formatString: string): string => {
  if (!dateString) return '';
  try {
    const date = parseISO(dateString);
    return format(date, formatString);
  } catch (error) {
    return dateString;
  }
};

export const convertDateFormatServer = (dateString: string, formatString: string): string => {
  if (!dateString) return '';
  try {
    const date = parseISO(dateString);
    return format(date, formatString);
  } catch (error) {
    return dateString;
  }
};
